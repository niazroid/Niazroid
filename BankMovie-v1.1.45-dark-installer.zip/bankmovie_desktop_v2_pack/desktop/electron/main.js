const { app, BrowserWindow, ipcMain, dialog, shell, session, safeStorage, Notification } = require('electron');
const path = require('path');
const { pathToFileURL } = require('url');
const fs = require('fs');
const crypto = require('crypto');
const { spawn, execFile, execFileSync } = require('child_process');
const RUNTIME = require('./runtime.generated');

// Production identity: prevents Windows toast/notification attribution from falling back to Electron.
try {
  app.setName('BankMovie');
  if (process.platform === 'win32') app.setAppUserModelId('top.bankmovie.desktop');
} catch {}

function bmRuntimeValue(name, fallback = '') {
  const direct = RUNTIME && RUNTIME[name];
  if (direct) return String(direct);
  const encoded = RUNTIME && RUNTIME[name + 'B64'];
  if (encoded) { try { return Buffer.from(String(encoded), 'base64').toString('utf8'); } catch {} }
  return String(fallback);
}

const BM_CONTROLLER_DOMAIN = bmRuntimeValue('controllerDomain', 'https://bankmoviez.top').replace(/\/$/,'');
const BM_CONTENT_DOMAIN = bmRuntimeValue('contentDomain', bmRuntimeValue('domain', 'https://bankmovie.top')).replace(/\/$/,'');
const DEFAULT = Object.freeze({
  controllerDomain: BM_CONTROLLER_DOMAIN,
  controllerUrl: `${BM_CONTROLLER_DOMAIN}/v1/desktop_config.php`,
  challengeUrl: `${BM_CONTROLLER_DOMAIN}/v1/device_challenge.php`,
  tokenUrl: `${BM_CONTROLLER_DOMAIN}/v1/device_token.php`,
  domain: BM_CONTENT_DOMAIN,
  apiBaseUrl: `${BM_CONTENT_DOMAIN}/v1`,
  apiUrl: `${BM_CONTENT_DOMAIN}/v1/desktop_api.php`,
  fallbackApiUrl: `${BM_CONTENT_DOMAIN}/v1/desktop_api.php`,
  accountApiUrl: `${BM_CONTENT_DOMAIN}/v1/desktop_user_api.php`,
  configPublicKey: String(RUNTIME.configPublicKey || '')
});


let win = null;
let runtimeConfig = null;
let bmDeviceIdentityMemory = null;
// When OS-protected encryption is unavailable, keep account token in RAM only.
let bmMemoryOnlyAuthToken = '';
// Player discovery invokes Windows registry/where; cache briefly to avoid UI stalls.
let bmPlayersCache = null;
let bmPlayersCacheUntil = 0;
let bmDeviceAccess = { token: '', exp: 0, jti: '' };
let bmDeviceAccessPromise = null;
let bmDeviceRefreshTimer = null;
let bmDeviceRefreshRetryMs = 15000;
const pendingDownloadMeta = new Map(); // id -> meta
const pendingDownloadUrl = new Map();  // original URL -> id
const cancelledPendingDownloads = new Set();
const downloadItems = new Map();
const downloadState = new Map();
const downloadMonitors = new Map();
const forcedPausedDownloads = new Set();
const childWindows = new Set();
let bmRemoteSessionLocked = false;

/* ===== BankMovie Desktop v1.1.33 — IDM-like queue manager / downloader settings ===== */
const downloadQueue = [];
const heldQueuedDownloads = new Set();
const downloadMetaStore = new Map();
const downloadRetryTimers = new Map();
const startingDownloads = new Set();
let downloadQueuePaused = false;
let downloadQueueTicker = null;
let downloadJournalTimer = null;

/* ===== BankMovie Desktop v1.1.36 — persistent download cover cache ===== */
function downloadCoverDir(){ return path.join(app.getPath('userData'),'download-covers-v1'); }
function safeDownloadCoverPath(filePath){
  try{
    const root=path.resolve(downloadCoverDir())+path.sep;
    const full=path.resolve(String(filePath||''));
    return full.startsWith(root);
  }catch{return false}
}
function downloadCoverFileUrl(filePath){
  try{return safeDownloadCoverPath(filePath)&&fs.existsSync(filePath)?pathToFileURL(filePath).href:''}catch{return ''}
}
function removeDownloadCoverFile(row){
  const p=String(row?.posterCachePath||'');
  if(!p||!safeDownloadCoverPath(p))return false;
  try{if(fs.existsSync(p))fs.unlinkSync(p);return true}catch{return false}
}
function coverExtension(posterUrl,contentType=''){
  const ct=String(contentType||'').toLowerCase();
  if(ct.includes('png'))return '.png';
  if(ct.includes('webp'))return '.webp';
  if(ct.includes('gif'))return '.gif';
  if(ct.includes('avif'))return '.avif';
  if(ct.includes('jpeg')||ct.includes('jpg'))return '.jpg';
  try{
    const ext=path.extname(new URL(String(posterUrl||'')).pathname).toLowerCase();
    if(['.jpg','.jpeg','.png','.webp','.gif','.avif'].includes(ext))return ext==='.jpeg'?'.jpg':ext;
  }catch{}
  return '.jpg';
}
async function cacheDownloadPoster(id,posterUrl){
  id=String(id||'');posterUrl=String(posterUrl||'').trim();
  if(!id||!/^https?:\/\//i.test(posterUrl))return '';
  const current=downloadState.get(id)||downloadMetaStore.get(id)||{};
  const existing=String(current.posterCachePath||'');
  if(existing&&downloadCoverFileUrl(existing)){
    const localUrl=downloadCoverFileUrl(existing);
    if(downloadState.has(id))publishDownloadState(id,{posterCachePath:existing,posterCacheUrl:localUrl});
    return localUrl;
  }
  const controller=new AbortController();
  const timeout=setTimeout(()=>controller.abort(),12000);
  let target='';
  try{
    const res=await fetch(posterUrl,{signal:controller.signal,headers:{'accept':'image/avif,image/webp,image/png,image/jpeg,image/*;q=0.8,*/*;q=0.2','user-agent':'BankMovie-Windows/1.1.36'}});
    if(!res.ok)throw new Error(`cover http ${res.status}`);
    const type=String(res.headers.get('content-type')||'').toLowerCase();
    if(type&&!type.startsWith('image/'))throw new Error('not an image');
    const declared=Number(res.headers.get('content-length')||0);
    if(declared>8*1024*1024)throw new Error('cover too large');
    const body=Buffer.from(await res.arrayBuffer());
    if(!body.length||body.length>8*1024*1024)throw new Error('cover size invalid');
    if(!downloadState.has(id)&&!downloadMetaStore.has(id))return '';
    const dir=downloadCoverDir();fs.mkdirSync(dir,{recursive:true});
    const ext=coverExtension(posterUrl,type);
    target=path.join(dir,`${id}${ext}`);
    const tmp=`${target}.tmp-${process.pid}-${Date.now()}`;
    fs.writeFileSync(tmp,body);
    try{fs.renameSync(tmp,target)}catch{fs.copyFileSync(tmp,target);try{fs.unlinkSync(tmp)}catch{}}
    const before=downloadState.get(id)||downloadMetaStore.get(id)||{};
    if(!downloadState.has(id)&&!downloadMetaStore.has(id)){try{fs.unlinkSync(target)}catch{};return ''}
    const previous=String(before.posterCachePath||'');
    if(previous&&previous!==target&&safeDownloadCoverPath(previous)){try{if(fs.existsSync(previous))fs.unlinkSync(previous)}catch{}}
    const localUrl=pathToFileURL(target).href;
    const meta={...(downloadMetaStore.get(id)||{}),poster:posterUrl,posterCachePath:target,posterCacheUrl:localUrl};
    downloadMetaStore.set(id,meta);
    if(downloadState.has(id))publishDownloadState(id,{poster:posterUrl,posterCachePath:target,posterCacheUrl:localUrl});
    else persistDownloadJournalSoon(150);
    return localUrl;
  }catch{
    if(target&&safeDownloadCoverPath(target)&&!downloadState.has(id)){try{if(fs.existsSync(target))fs.unlinkSync(target)}catch{}}
    return '';
  }finally{clearTimeout(timeout)}
}
async function backfillDownloadCovers(){
  const rows=[...downloadState.values()]
    .filter(row=>/^https?:\/\//i.test(String(row?.poster||''))&&!downloadCoverFileUrl(String(row?.posterCachePath||'')))
    .sort((a,b)=>Number(b.at||b.queuedAt||0)-Number(a.at||a.queuedAt||0))
    .slice(0,400);
  let cursor=0;
  async function worker(){
    while(cursor<rows.length){const row=rows[cursor++];await cacheDownloadPoster(row.id,row.poster)}
  }
  await Promise.all(Array.from({length:Math.min(4,rows.length)},()=>worker()));
}
function purgeDownloadRecord(id){
  id=String(id||'');
  const row=downloadState.get(id)||downloadMetaStore.get(id)||{};
  removeDownloadCoverFile(row);
  clearDownloadMonitor(id);
  clearRetryTimer(id);
  removeQueuedId(id);
  heldQueuedDownloads.delete(id);
  startingDownloads.delete(id);
  forcedPausedDownloads.delete(id);
  pendingDownloadMeta.delete(id);
  cancelledPendingDownloads.delete(id);
  for(const [u,mappedId] of [...pendingDownloadUrl.entries()])if(mappedId===id)pendingDownloadUrl.delete(u);
  downloadItems.delete(id);
  downloadState.delete(id);
  downloadMetaStore.delete(id);
  persistDownloadJournalNow();
  return {id,removed:true};
}
function downloadJournalPath(){ return path.join(app.getPath('userData'),'downloads-state-v1.json'); }
function downloadStableOrderAt(row={}){
  return Number(row.orderAt||row.queuedAt||row.createdAt||row.startedAt||row.finishedAt||row.at||0);
}
function serializableDownloadRows(){
  return [...downloadState.values()]
    .sort((a,b)=>downloadStableOrderAt(b)-downloadStableOrderAt(a))
    .slice(0,1200)
    .map(row=>{
      const out={...row};
      delete out.speed; delete out.eta; delete out.posterCacheUrl;
      return out;
    });
}
function persistDownloadJournalNow(){
  if(!app.isReady())return false;
  try{
    const target=downloadJournalPath(),tmp=`${target}.tmp`;
    fs.mkdirSync(path.dirname(target),{recursive:true});
    const payload={version:1,savedAt:Date.now(),queue:[...downloadQueue],paused:Boolean(downloadQueuePaused),rows:serializableDownloadRows()};
    fs.writeFileSync(tmp,JSON.stringify(payload,null,2),'utf8');
    try{fs.renameSync(tmp,target)}catch{fs.copyFileSync(tmp,target);fs.unlinkSync(tmp)}
    return true;
  }catch{return false}
}
function persistDownloadJournalSoon(delay=900){
  if(downloadJournalTimer)clearTimeout(downloadJournalTimer);
  downloadJournalTimer=setTimeout(()=>{downloadJournalTimer=null;persistDownloadJournalNow()},delay);
}
function recoverLegacyDownloadFiles(){
  if(!app.isReady())return 0;
  const st=readState();
  if(st.downloadHistoryMigratedV1135)return 0;
  let recovered=0;
  try{
    const folder=String(settings().downloadDir||'');
    if(!folder||!fs.existsSync(folder)){writeState({downloadHistoryMigratedV1135:true});return 0}
    const entries=fs.readdirSync(folder,{withFileTypes:true}).filter(x=>x.isFile()).slice(0,5000);
    const rows=[];
    for(const ent of entries){
      if(!/\.(?:mp4|mkv|avi|mov|m4v|webm|wmv|mp3|m4a|aac|flac|wav|ogg)$/i.test(ent.name))continue;
      const stem=path.basename(ent.name,path.extname(ent.name));
      const parts=stem.split(' - ').map(x=>x.trim()).filter(Boolean);
      if(parts.length<3)continue; // BankMovie naming format: title - source - quality (series may include season/episode too)
      const full=path.join(folder,ent.name);let stat;try{stat=fs.statSync(full)}catch{continue}
      if(!stat.isFile()||stat.size<=0)continue;
      const id=`legacy-${crypto.createHash('sha1').update(full.toLowerCase()).digest('hex').slice(0,18)}`;
      rows.push({id,url:'',fileName:ent.name,title:parts[0]||ent.name,quality:parts.slice(-2).join(' • '),poster:'',mediaType:/S\d{1,3}(?:E\d{1,4})?/i.test(stem)?'series':'movie',state:'completed',received:stat.size,total:stat.size,paused:false,savePath:full,queuedAt:stat.mtimeMs,finishedAt:stat.mtimeMs,at:stat.mtimeMs,restoredLegacy:true});
    }
    rows.sort((a,b)=>b.at-a.at).slice(0,600).forEach(row=>{downloadState.set(row.id,row);downloadMetaStore.set(row.id,{...row});recovered++});
  }catch{}
  writeState({downloadHistoryMigratedV1135:true});
  return recovered;
}
function restoreDownloadJournal(){
  if(!app.isReady())return;
  let raw={};
  try{raw=JSON.parse(fs.readFileSync(downloadJournalPath(),'utf8'))||{}}catch{recoverLegacyDownloadFiles();persistDownloadJournalSoon(250);return}
  downloadQueuePaused=Boolean(raw.paused);
  const rows=Array.isArray(raw.rows)?raw.rows:[];
  const queuedOrder=Array.isArray(raw.queue)?raw.queue.map(String):[];
  const queuedSet=new Set(queuedOrder);
  for(const entry of rows){
    if(!entry||!entry.id)continue;
    const id=String(entry.id),next={...entry,id,speed:0,eta:0};
    const cachedCover=String(next.posterCachePath||'');
    next.posterCacheUrl=downloadCoverFileUrl(cachedCover);
    if(!next.posterCacheUrl)next.posterCachePath='';
    const savePath=String(next.savePath||'');
    let existingSize=-1;
    if(savePath){try{existingSize=fs.statSync(savePath).size}catch{}}
    const total=Number(next.total||0);
    if(String(next.state)==='completed'){
      if(existingSize<0){next.state='interrupted';next.lastError='فایل دانلودشده در مسیر قبلی پیدا نشد';next.restoredAfterUpdate=true}
    }else if(!terminalDownloadState(next.state)){
      if(existingSize>=0&&total>0&&existingSize>=total){
        next.state='completed';next.received=existingSize;next.finishedAt=next.finishedAt||Date.now();next.restoredAfterUpdate=true;
      }else if(String(next.state)==='queued'&&!next.startedAt&&!savePath){
        next.state='queued';next.paused=Boolean(next.paused);next.restoredAfterUpdate=true;
      }else{
        next.state='interrupted';next.paused=false;next.restoredAfterUpdate=true;
        next.lastError='BankMovie بسته یا بروزرسانی شد؛ برای شروع دوباره روی تلاش مجدد بزنید';
      }
    }
    downloadState.set(id,next);
    downloadMetaStore.set(id,{...next,url:String(next.url||'')});
  }
  for(const id of queuedOrder){
    const st=downloadState.get(id);
    if(st&&st.state==='queued'&&downloadMetaStore.get(id)?.url&&!downloadQueue.includes(id))downloadQueue.push(id);
  }
  for(const [id,st] of downloadState.entries()){
    if(st.state==='queued'&&!queuedSet.has(id)&&downloadMetaStore.get(id)?.url&&!downloadQueue.includes(id))downloadQueue.push(id);
    if(st.state==='queued'&&st.paused)heldQueuedDownloads.add(id);
  }
  persistDownloadJournalSoon(1500);
}

function clampInt(v,min,max,fallback){
  const n=Number(v);
  if(!Number.isFinite(n))return fallback;
  return Math.max(min,Math.min(max,Math.round(n)));
}
function validClock(v,fallback='00:00'){
  const x=String(v||'').trim();
  return /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(x)?x:fallback;
}
function boolSetting(v,fallback=false){
  if(v===undefined||v===null)return fallback;
  return v===true||v===1||v==='1'||v==='true';
}
function downloaderSettings(){
  const s=readState();
  return {
    downloadMode:String(s.downloadMode||'concurrent')==='sequential'?'sequential':'concurrent',
    downloadConcurrency:clampInt(s.downloadConcurrency,1,100,3),
    downloadNotifications:boolSetting(s.downloadNotifications,true),
    downloadAutoRetry:boolSetting(s.downloadAutoRetry,true),
    downloadRetryCount:clampInt(s.downloadRetryCount,0,10,4),
    downloadRetryDelaySec:clampInt(s.downloadRetryDelaySec,1,300,8),
    downloadScheduleEnabled:boolSetting(s.downloadScheduleEnabled,false),
    downloadScheduleStart:validClock(s.downloadScheduleStart,'00:00'),
    downloadScheduleEnd:validClock(s.downloadScheduleEnd,'23:59'),
    downloadConflict:String(s.downloadConflict||'rename')==='overwrite'?'overwrite':'rename',
    downloadPowerEnabled:boolSetting(s.downloadPowerEnabled,false)
  };
}
function sanitizeSettingsPatch(patch={}){
  const out={};
  if(Object.prototype.hasOwnProperty.call(patch,'downloadDir'))out.downloadDir=String(patch.downloadDir||'').trim();
  if(Object.prototype.hasOwnProperty.call(patch,'preferredArchive'))out.preferredArchive=clampInt(patch.preferredArchive,1,5,1);
  if(Object.prototype.hasOwnProperty.call(patch,'preferredPlayer'))out.preferredPlayer=String(patch.preferredPlayer||'auto');
  if(Object.prototype.hasOwnProperty.call(patch,'language'))out.language=String(patch.language||'fa')==='en'?'en':'fa';
  if(Object.prototype.hasOwnProperty.call(patch,'downloadMode'))out.downloadMode=String(patch.downloadMode||'concurrent')==='sequential'?'sequential':'concurrent';
  if(Object.prototype.hasOwnProperty.call(patch,'downloadConcurrency'))out.downloadConcurrency=clampInt(patch.downloadConcurrency,1,100,3);
  if(Object.prototype.hasOwnProperty.call(patch,'downloadNotifications'))out.downloadNotifications=Boolean(patch.downloadNotifications);
  if(Object.prototype.hasOwnProperty.call(patch,'downloadAutoRetry'))out.downloadAutoRetry=Boolean(patch.downloadAutoRetry);
  if(Object.prototype.hasOwnProperty.call(patch,'downloadRetryCount'))out.downloadRetryCount=clampInt(patch.downloadRetryCount,0,10,4);
  if(Object.prototype.hasOwnProperty.call(patch,'downloadRetryDelaySec'))out.downloadRetryDelaySec=clampInt(patch.downloadRetryDelaySec,1,300,8);
  if(Object.prototype.hasOwnProperty.call(patch,'downloadScheduleEnabled'))out.downloadScheduleEnabled=Boolean(patch.downloadScheduleEnabled);
  if(Object.prototype.hasOwnProperty.call(patch,'downloadScheduleStart'))out.downloadScheduleStart=validClock(patch.downloadScheduleStart,'00:00');
  if(Object.prototype.hasOwnProperty.call(patch,'downloadScheduleEnd'))out.downloadScheduleEnd=validClock(patch.downloadScheduleEnd,'23:59');
  if(Object.prototype.hasOwnProperty.call(patch,'downloadConflict'))out.downloadConflict=String(patch.downloadConflict||'rename')==='overwrite'?'overwrite':'rename';
  if(Object.prototype.hasOwnProperty.call(patch,'downloadPowerEnabled'))out.downloadPowerEnabled=Boolean(patch.downloadPowerEnabled);
  return out;
}
function clockMinutes(clock){
  const m=validClock(clock,'00:00').split(':').map(Number);
  return m[0]*60+m[1];
}
function scheduleAllowsNewStarts(now=new Date()){
  const ds=downloaderSettings();
  if(!ds.downloadScheduleEnabled)return true;
  const start=clockMinutes(ds.downloadScheduleStart),end=clockMinutes(ds.downloadScheduleEnd);
  if(start===end)return true;
  const cur=now.getHours()*60+now.getMinutes();
  return start<end ? (cur>=start&&cur<end) : (cur>=start||cur<end);
}
function nextScheduleStartAt(now=new Date()){
  const ds=downloaderSettings();
  if(!ds.downloadScheduleEnabled||scheduleAllowsNewStarts(now))return 0;
  const [h,m]=ds.downloadScheduleStart.split(':').map(Number);
  const d=new Date(now);d.setHours(h,m,0,0);
  if(d<=now)d.setDate(d.getDate()+1);
  return d.getTime();
}
function effectiveDownloadConcurrency(){
  const ds=downloaderSettings();
  return ds.downloadMode==='sequential'?1:ds.downloadConcurrency;
}
function startedDownloadCount(){
  return downloadItems.size+startingDownloads.size;
}
function queuedIds(){
  return downloadQueue.filter(id=>{
    const st=downloadState.get(String(id));
    return st && !terminalDownloadState(st.state) && !startingDownloads.has(String(id)) && !downloadItems.has(String(id));
  });
}
function downloadQueueStatus(extra={}){
  const ds=downloaderSettings();
  return {
    paused:downloadQueuePaused,
    activeCount:downloadItems.size,
    startingCount:startingDownloads.size,
    queuedCount:queuedIds().length,
    order:queuedIds(),
    limit:effectiveDownloadConcurrency(),
    mode:ds.downloadMode,
    scheduleEnabled:ds.downloadScheduleEnabled,
    scheduleOpen:scheduleAllowsNewStarts(),
    nextStartAt:nextScheduleStartAt(),
    ...extra
  };
}
function publishQueueStatus(extra={}){
  const st=downloadQueueStatus(extra);
  sendToMainWindow('download:queue-status',st);
  persistDownloadJournalSoon();
  return st;
}
function enqueueDownloadId(id,{front=false}={}){
  id=String(id||'');if(!id)return;
  const idx=downloadQueue.indexOf(id);
  if(idx>=0)downloadQueue.splice(idx,1);
  if(front)downloadQueue.unshift(id);else downloadQueue.push(id);
}
function removeQueuedId(id){
  id=String(id||'');let changed=false;
  for(let i=downloadQueue.length-1;i>=0;i--)if(downloadQueue[i]===id){downloadQueue.splice(i,1);changed=true}
  return changed;
}
function inFlightSameUrl(id,url){
  const raw=String(url||'');
  if(!raw)return false;
  for(const other of startingDownloads){
    if(other!==id&&String(downloadMetaStore.get(other)?.url||'')===raw)return true;
  }
  for(const other of downloadItems.keys()){
    if(other!==id&&String(downloadMetaStore.get(other)?.url||'')===raw)return true;
  }
  return false;
}
function uniqueDownloadPath(folder,fileName,behavior='rename'){
  const safe=safeFileName(fileName||'BankMovie-download');
  const base=path.join(folder,safe);
  if(behavior==='overwrite')return base;
  const reserved=new Set();
  for(const item of downloadItems.values()){
    try{const p=item.getSavePath();if(p)reserved.add(String(p).toLowerCase())}catch{}
  }
  if(!fs.existsSync(base)&&!reserved.has(base.toLowerCase()))return base;
  const ext=path.extname(safe),stem=path.basename(safe,ext);
  for(let i=1;i<10000;i++){
    const p=path.join(folder,`${stem} (${i})${ext}`);
    if(!fs.existsSync(p)&&!reserved.has(p.toLowerCase()))return p;
  }
  return path.join(folder,`${stem}-${Date.now()}${ext}`);
}
function launchQueuedDownload(id){
  id=String(id||'');
  const meta=downloadMetaStore.get(id);
  if(!meta||!meta.url)return false;
  if(inFlightSameUrl(id,meta.url))return false;
  removeQueuedId(id);
  startingDownloads.add(id);
  pendingDownloadMeta.set(id,{...meta,id});
  pendingDownloadUrl.set(meta.url,id);
  publishDownloadState(id,{...meta,id,state:'starting',paused:false,startedAt:Date.now(),retryAt:0});
  try{
    if(win&&!win.isDestroyed()&&win.webContents&&!win.webContents.isDestroyed())win.webContents.downloadURL(meta.url);
    else session.defaultSession.downloadURL(meta.url);
  }catch(err){
    startingDownloads.delete(id);
    pendingDownloadMeta.delete(id);
    if(pendingDownloadUrl.get(meta.url)===id)pendingDownloadUrl.delete(meta.url);
    handleDownloadInterruption(id,null,null,String(err?.message||err||'start failed'));
    return false;
  }
  setTimeout(()=>{
    if(!startingDownloads.has(id))return;
    startingDownloads.delete(id);
    pendingDownloadMeta.delete(id);
    if(pendingDownloadUrl.get(meta.url)===id)pendingDownloadUrl.delete(meta.url);
    if(cancelledPendingDownloads.has(id)){
      cancelledPendingDownloads.delete(id);
      pumpDownloadQueue();
      return;
    }
    handleDownloadInterruption(id,null,null,'download start timeout');
    pumpDownloadQueue();
  },30000);
  return true;
}
function pumpDownloadQueue(){
  if(downloadQueuePaused){publishQueueStatus();return}
  if(!scheduleAllowsNewStarts()){publishQueueStatus();return}
  const limit=effectiveDownloadConcurrency();
  let guard=downloadQueue.length+5;
  while(startedDownloadCount()<limit&&downloadQueue.length&&guard-->0){
    let picked='';
    for(const id of downloadQueue){
      if(heldQueuedDownloads.has(id))continue;
      const meta=downloadMetaStore.get(id);
      if(!meta)continue;
      if(inFlightSameUrl(id,meta.url))continue;
      picked=id;break;
    }
    if(!picked)break;
    launchQueuedDownload(picked);
  }
  publishQueueStatus();
}
function clearRetryTimer(id){
  const t=downloadRetryTimers.get(String(id));if(t)clearTimeout(t);
  downloadRetryTimers.delete(String(id));
}
function scheduleRetry(id,reason=''){
  id=String(id||'');
  const meta=downloadMetaStore.get(id);
  if(!meta)return false;
  const ds=downloaderSettings();
  const prev=downloadState.get(id)||{};
  if(terminalDownloadState(prev.state))return false;
  const attempt=Number(prev.retryAttempt||0)+1;
  if(!ds.downloadAutoRetry||attempt>ds.downloadRetryCount)return false;
  clearRetryTimer(id);
  const retryAt=Date.now()+ds.downloadRetryDelaySec*1000;
  publishDownloadState(id,{...meta,state:'retry_wait',paused:false,retryAttempt:attempt,retryAt,lastError:String(reason||'interrupted')});
  const t=setTimeout(()=>{
    downloadRetryTimers.delete(id);
    const st=downloadState.get(id);
    if(!st||terminalDownloadState(st.state))return;
    enqueueDownloadId(id,{front:true});
    publishDownloadState(id,{state:'queued',paused:false,retryAt:0});
    pumpDownloadQueue();
  },ds.downloadRetryDelaySec*1000);
  downloadRetryTimers.set(id,t);
  publishQueueStatus();
  return true;
}
function handleDownloadInterruption(id,item,sourceWebContents,reason='interrupted'){
  id=String(id||'');
  if(scheduleRetry(id,reason))return true;
  const meta=downloadMetaStore.get(id)||{};
  const snapshot={
    ...meta,state:'interrupted',
    received:item?.getReceivedBytes?.()||Number(downloadState.get(id)?.received||0),
    total:item?.getTotalBytes?.()||Number(downloadState.get(id)?.total||0),
    paused:false,
    savePath:item?.getSavePath?.()||downloadState.get(id)?.savePath||'',
    finishedAt:Date.now(),
    lastError:String(reason||'interrupted')
  };
  publishDownloadState(id,snapshot,sourceWebContents);
  nativeDownloadNotification('دانلود متوقف شد',meta.title||meta.fileName||'BankMovie');
  return false;
}
function moveQueuedDownload(id,dir){
  id=String(id||'');const i=downloadQueue.indexOf(id);if(i<0)return false;
  const j=dir==='up'?i-1:i+1;if(j<0||j>=downloadQueue.length)return false;
  [downloadQueue[i],downloadQueue[j]]=[downloadQueue[j],downloadQueue[i]];
  publishQueueStatus();return true;
}
function startDownloadQueueTicker(){
  if(downloadQueueTicker)clearInterval(downloadQueueTicker);
  downloadQueueTicker=setInterval(()=>pumpDownloadQueue(),10000);
}

/* ===== BankMovie Desktop v1.1.32 — local-only safe Windows shutdown scheduler ===== */
let powerTimer = null;
let powerPlan = { mode:'off', armedAt:0, targetAt:0, countdownUntil:0, trackedIds:[], reason:'' };

function powerSupported(){ return process.platform === 'win32'; }
// Only the main frame of our packaged index.html can request privileged IPC.
// Other file:// documents, iframes and remote child windows are never trusted.
function bmAppIndexUrl(){ return pathToFileURL(path.resolve(__dirname, '../src/index.html')).href; }
function bmIsAppIndexUrl(raw){
  try { return String(raw || '').split('#', 1)[0] === bmAppIndexUrl(); }
  catch { return false; }
}
function trustedMainRenderer(event){
  try {
    if (!win || win.isDestroyed() || !event?.sender || !event?.senderFrame) return false;
    const webContents = win.webContents;
    if (event.sender.id !== webContents.id || webContents.isDestroyed()) return false;
    const frame = event.senderFrame, mainFrame = webContents.mainFrame;
    if (!frame || !mainFrame || frame.processId !== mainFrame.processId || frame.routingId !== mainFrame.routingId) return false;
    return bmIsAppIndexUrl(webContents.getURL()) && bmIsAppIndexUrl(frame.url);
  } catch { return false; }
}
// Guard both asynchronous invokes and one-way events, without changing the
// renderer/preload API signatures.
function bmHandle(channel, callback){
  return ipcMain.handle(channel, (event, ...args) => {
    if (!trustedMainRenderer(event)) throw new Error('درخواست از پنجره نامعتبر رد شد');
    return callback(event, ...args);
  });
}
function bmOn(channel, callback){
  return ipcMain.on(channel, (event, ...args) => {
    if (!trustedMainRenderer(event)) return;
    return callback(event, ...args);
  });
}
function terminalDownloadState(state){ return ['completed','cancelled','interrupted'].includes(String(state||'')); }
function activeDownloadIds(){
  const ids = new Set();
  for (const id of pendingDownloadMeta.keys()) ids.add(String(id));
  for (const [id, st] of downloadState.entries()) if (!terminalDownloadState(st?.state)) ids.add(String(id));
  return [...ids];
}
function powerPublicStatus(extra={}){
  return {
    supported: powerSupported(),
    mode: powerPlan.mode,
    armed: powerPlan.mode!=='off',
    armedAt:Number(powerPlan.armedAt||0),
    targetAt:Number(powerPlan.targetAt||0),
    countdownUntil:Number(powerPlan.countdownUntil||0),
    trackedCount:Array.isArray(powerPlan.trackedIds)?powerPlan.trackedIds.length:0,
    activeDownloads:activeDownloadIds().length,
    reason:String(powerPlan.reason||''),
    now:Date.now(),
    ...extra
  };
}
function publishPowerStatus(extra={}){
  const st=powerPublicStatus(extra);
  sendToMainWindow('power:status', st);
  return st;
}
function clearPowerTimer(){ if(powerTimer){ clearTimeout(powerTimer); powerTimer=null; } }
function resetPowerPlan(reason=''){
  clearPowerTimer();
  powerPlan={mode:'off',armedAt:0,targetAt:0,countdownUntil:0,trackedIds:[],reason:String(reason||'')};
  return publishPowerStatus();
}
function scheduleAtTimestamp(targetAt){
  clearPowerTimer();
  powerTimer=setTimeout(()=>beginWindowsShutdownCountdown('time'),Math.max(0,Number(targetAt||0)-Date.now()));
}
function runShutdownExe(args){
  return new Promise((resolve,reject)=>{
    execFile('shutdown.exe',args,{windowsHide:true},(err,stdout,stderr)=>{
      if(err)return reject(new Error(String(stderr||err.message||'shutdown.exe failed').trim()));
      resolve(String(stdout||''));
    });
  });
}
async function beginWindowsShutdownCountdown(reason='downloads'){
  if(!powerSupported())return resetPowerPlan('unsupported');
  if(powerPlan.mode==='countdown')return powerPublicStatus();
  clearPowerTimer();
  powerPlan={...powerPlan,mode:'countdown',countdownUntil:Date.now()+60_000,reason:String(reason||'downloads')};
  publishPowerStatus();
  nativePowerNotification('خاموشی خودکار BankMovie','ویندوز تا ۶۰ ثانیه دیگر خاموش می‌شود؛ از صفحه دانلودها می‌توانید لغو کنید.');
  try{
    await runShutdownExe(['/s','/t','60','/c','BankMovie: scheduled shutdown. Open BankMovie Downloads to cancel.']);
  }catch(err){
    resetPowerPlan('shutdown_failed');
    nativePowerNotification('خاموشی انجام نشد',String(err?.message||err||'خطای ویندوز'));
  }
  return powerPublicStatus();
}
function evaluateAfterDownloadsPlan(){
  if(powerPlan.mode!=='after_downloads')return;
  const ids=Array.isArray(powerPlan.trackedIds)?powerPlan.trackedIds:[];
  if(!ids.length)return;
  let waiting=false;
  for(const id of ids){
    const st=downloadState.get(String(id));
    const state=String(st?.state||'');
    if(state==='cancelled'||state==='interrupted'){
      resetPowerPlan('download_not_completed');
      nativePowerNotification('خاموشی خودکار لغو شد','حداقل یک دانلود کامل نشد یا لغو شد.');
      return;
    }
    if(state!=='completed')waiting=true;
  }
  if(!waiting)beginWindowsShutdownCountdown('downloads');
}
function powerTrackDownloadId(id){
  if(powerPlan.mode!=='after_downloads')return;
  const v=String(id||'');if(!v||powerPlan.trackedIds.includes(v))return;
  powerPlan={...powerPlan,trackedIds:[...powerPlan.trackedIds,v]};
  publishPowerStatus();
}
function parseLocalClockTarget(clock){
  const m=String(clock||'').trim().match(/^(\d{2}):(\d{2})$/);if(!m)return 0;
  const hh=Number(m[1]),mm=Number(m[2]);if(hh>23||mm>59)return 0;
  const now=new Date();const d=new Date(now);d.setHours(hh,mm,0,0);
  if(d.getTime()<=now.getTime()+30_000)d.setDate(d.getDate()+1);
  return d.getTime();
}
async function armPowerPlan(event,payload={}){
  if(!trustedMainRenderer(event))throw new Error('درخواست خاموشی از پنجره معتبر نیست');
  if(!win?.isFocused())throw new Error('برای فعال‌سازی خاموشی، پنجره BankMovie باید فعال باشد');
  if(!powerSupported())throw new Error('خاموشی خودکار فقط در نسخه Windows فعال است');
  if(!settings().downloadPowerEnabled)throw new Error('ابتدا گزینه خاموشی خودکار را در تنظیمات دانلود روشن کنید');
  const mode=String(payload.mode||'');
  if(!['after_downloads','at_time'].includes(mode))throw new Error('حالت خاموشی معتبر نیست');
  if(powerPlan.mode==='countdown')throw new Error('خاموشی ویندوز در حال شمارش معکوس است؛ ابتدا آن را لغو کنید');

  if(mode==='after_downloads'){
    const ids=activeDownloadIds();
    if(!ids.length)throw new Error('هیچ دانلود فعالی برای انتظار وجود ندارد');
    const confirm=await dialog.showMessageBox(win,{type:'question',buttons:['فعال کن','انصراف'],defaultId:1,cancelId:1,title:'خاموشی بعد از دانلودها',message:`بعد از کامل‌شدن ${ids.length} دانلود فعال، ویندوز خاموش شود؟`,detail:'اگر دانلودی لغو یا متوقف شود، خاموشی خودکار لغو می‌شود. قبل از خاموشی ۶۰ ثانیه فرصت لغو دارید.'});
    if(confirm.response!==0)return powerPublicStatus({cancelled:true});
    powerPlan={mode:'after_downloads',armedAt:Date.now(),targetAt:0,countdownUntil:0,trackedIds:ids,reason:'downloads'};
    publishPowerStatus();
    evaluateAfterDownloadsPlan();
    return powerPublicStatus();
  }

  const targetAt=parseLocalClockTarget(payload.time);
  if(!targetAt)throw new Error('زمان معتبر وارد کنید');
  const when=new Date(targetAt).toLocaleString('fa-IR');
  const confirm=await dialog.showMessageBox(win,{type:'warning',buttons:['زمان‌بندی کن','انصراف'],defaultId:1,cancelId:1,title:'خاموشی زمان‌بندی‌شده',message:`ویندوز در ${when} خاموش شود؟`,detail:'این حالت در زمان تعیین‌شده اجرا می‌شود حتی اگر دانلودی هنوز فعال باشد. قبل از خاموشی ۶۰ ثانیه فرصت لغو دارید.'});
  if(confirm.response!==0)return powerPublicStatus({cancelled:true});
  powerPlan={mode:'at_time',armedAt:Date.now(),targetAt,countdownUntil:0,trackedIds:[],reason:'time'};
  scheduleAtTimestamp(targetAt);
  return publishPowerStatus();
}
async function cancelPowerPlan(event){
  if(!trustedMainRenderer(event))throw new Error('درخواست لغو از پنجره معتبر نیست');
  const hadCountdown=powerPlan.mode==='countdown'&&Number(powerPlan.countdownUntil||0)>Date.now();
  clearPowerTimer();
  if(hadCountdown&&powerSupported()){
    try{await runShutdownExe(['/a']);}catch{}
  }
  return resetPowerPlan('cancelled_by_user');
}

function statePath() { return path.join(app.getPath('userData'), 'desktop-state.json'); }
function readState() {
  try { return JSON.parse(fs.readFileSync(statePath(), 'utf8')); } catch { return {}; }
}
function writeState(next) {
  const current = readState();
  const merged = { ...current, ...next };
  fs.mkdirSync(path.dirname(statePath()), { recursive: true });
  fs.writeFileSync(statePath(), JSON.stringify(merged, null, 2));
  return merged;
}
function saveToken(token) {
  token = String(token || '');
  if (!token) { bmMemoryOnlyAuthToken = ''; return writeState({ authToken:'', authEncrypted:false }); }
  if (safeStorage.isEncryptionAvailable()) {
    const encrypted = safeStorage.encryptString(token).toString('base64');
    bmMemoryOnlyAuthToken = '';
    return writeState({ authToken:encrypted, authEncrypted:true });
  }
  // Do not persist a readable account token when Windows safeStorage is unavailable.
  bmMemoryOnlyAuthToken = token;
  return writeState({ authToken:'', authEncrypted:false });
}
function loadToken() {
  if (bmMemoryOnlyAuthToken) return bmMemoryOnlyAuthToken;
  const s = readState();
  if (!s.authToken) return '';
  try {
    if (s.authEncrypted) return safeStorage.isEncryptionAvailable()
      ? safeStorage.decryptString(Buffer.from(s.authToken, 'base64')) : '';
    // One-time migration from legacy plaintext state, without forcing logout.
    if (!safeStorage.isEncryptionAvailable()) return '';
    const legacy = String(s.authToken);
    saveToken(legacy);
    return legacy;
  } catch { return ''; }
}
function settings() {
  const s = readState();
  return {
    downloadDir: s.downloadDir || app.getPath('downloads'),
    preferredArchive: Number(s.preferredArchive || 1),
    preferredPlayer: String(s.preferredPlayer || 'auto'),
    language: String(s.language || 'fa') === 'en' ? 'en' : 'fa',
    ...downloaderSettings()
  };
}
function normalizeBase(url, fallback) {
  try { const u = new URL(url || fallback); return u.toString(); } catch { return fallback; }
}
function bmB64UrlEncode(input) {
  return Buffer.from(input).toString('base64').replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
}
function bmB64UrlDecode(input) {
  const s = String(input || '').replace(/-/g,'+').replace(/_/g,'/');
  return Buffer.from(s + '='.repeat((4 - (s.length % 4)) % 4), 'base64');
}
function bmSha256(input) { return crypto.createHash('sha256').update(input).digest('hex'); }
function bmPublicKeyDer(publicKeyPem) {
  return crypto.createPublicKey(publicKeyPem).export({ type:'spki', format:'der' });
}
function bmDeviceId(publicKeyPem) { return bmSha256(bmPublicKeyDer(publicKeyPem)); }
function bmReadDeviceIdentityFromState() {
  const s = readState();
  if (!s.bmDevicePublicKey || !s.bmDevicePrivateKey) return null;
  try {
    let privateKey = '';
    if (s.bmDevicePrivateEncrypted && safeStorage.isEncryptionAvailable()) {
      privateKey = safeStorage.decryptString(Buffer.from(String(s.bmDevicePrivateKey), 'base64'));
    } else if (!s.bmDevicePrivateEncrypted) {
      // v1.1.40 never persists new plaintext private keys. This branch only
      // supports an already-created current-session identity if present.
      return null;
    }
    const publicKey = String(s.bmDevicePublicKey);
    const deviceId = bmDeviceId(publicKey);
    if (!privateKey || (s.bmDeviceId && String(s.bmDeviceId) !== deviceId)) return null;
    return { privateKey, publicKey, deviceId };
  } catch { return null; }
}
function bmCreateDeviceIdentity() {
  const pair = crypto.generateKeyPairSync('ec', {
    namedCurve: 'prime256v1',
    publicKeyEncoding: { type:'spki', format:'pem' },
    privateKeyEncoding: { type:'pkcs8', format:'pem' }
  });
  const identity = { privateKey: pair.privateKey, publicKey: pair.publicKey, deviceId: bmDeviceId(pair.publicKey) };
  if (safeStorage.isEncryptionAvailable()) {
    writeState({
      bmDeviceId: identity.deviceId,
      bmDevicePublicKey: identity.publicKey,
      bmDevicePrivateKey: safeStorage.encryptString(identity.privateKey).toString('base64'),
      bmDevicePrivateEncrypted: true
    });
  }
  return identity;
}
function bmDeviceIdentity() {
  if (bmDeviceIdentityMemory) return bmDeviceIdentityMemory;
  bmDeviceIdentityMemory = bmReadDeviceIdentityFromState() || bmCreateDeviceIdentity();
  return bmDeviceIdentityMemory;
}
function bmClearDeviceRefreshTimer() {
  if (bmDeviceRefreshTimer) { clearTimeout(bmDeviceRefreshTimer); bmDeviceRefreshTimer = null; }
}
function bmScheduleDeviceAccessRefresh(exp) {
  bmClearDeviceRefreshTimer();
  const now = Math.floor(Date.now() / 1000);
  // Refresh roughly 3 minutes before expiry. If the token is very short lived,
  // refresh at about 70% of its remaining lifetime instead of waiting for a 401.
  const remaining = Math.max(1, Number(exp || 0) - now);
  const refreshInSec = Math.max(30, remaining > 360 ? remaining - 180 : Math.floor(remaining * 0.70));
  bmDeviceRefreshTimer = setTimeout(async () => {
    try {
      await bmEnsureDeviceAccess(true);
      bmDeviceRefreshRetryMs = 15000;
    } catch {
      const retry = Math.min(60000, Math.max(5000, bmDeviceRefreshRetryMs));
      bmDeviceRefreshRetryMs = Math.min(60000, retry * 2);
      bmDeviceRefreshTimer = setTimeout(() => bmEnsureDeviceAccess(true).catch(() => {}), retry);
      if (bmDeviceRefreshTimer && typeof bmDeviceRefreshTimer.unref === 'function') bmDeviceRefreshTimer.unref();
    }
  }, refreshInSec * 1000);
  if (bmDeviceRefreshTimer && typeof bmDeviceRefreshTimer.unref === 'function') bmDeviceRefreshTimer.unref();
}
function bmDecodeJwtPayload(token) {
  try {
    const parts = String(token || '').split('.');
    if (parts.length !== 3) return {};
    return JSON.parse(bmB64UrlDecode(parts[1]).toString('utf8'));
  } catch { return {}; }
}
function bmVerifyControllerEnvelope(envelope) {
  if (!DEFAULT.configPublicKey) throw new Error('کلید عمومی کنترلر ویندوز تنظیم نشده است');
  if (!envelope || envelope.schema !== 'bm-win-config-envelope-v1' || envelope.alg !== 'RS256') throw new Error('Remote config envelope نامعتبر است');
  const payload = bmB64UrlDecode(envelope.payload || '');
  const signature = bmB64UrlDecode(envelope.signature || '');
  const ok = crypto.verify('RSA-SHA256', payload, DEFAULT.configPublicKey, signature);
  if (!ok) throw new Error('امضای Remote Config معتبر نیست');
  const cfg = JSON.parse(payload.toString('utf8'));
  if (!cfg || typeof cfg !== 'object') throw new Error('Remote config نامعتبر است');
  const content = String(cfg.content_domain || cfg.active_domain || '').replace(/\/$/, '');
  if (content !== DEFAULT.domain) throw new Error('دامنه محتوای Remote Config مجاز نیست');
  const apiBase = String(cfg.api_base_url || `${content}/v1`).replace(/\/$/, '');
  if (apiBase !== `${DEFAULT.domain}/v1`) throw new Error('مسیر API خارج از دامنه مجاز است');
  return cfg;
}
function bmRequestBodyBuffer(body) {
  if (body === undefined || body === null) return Buffer.alloc(0);
  if (Buffer.isBuffer(body)) return body;
  if (typeof body === 'string') return Buffer.from(body, 'utf8');
  if (body instanceof URLSearchParams) return Buffer.from(body.toString(), 'utf8');
  if (ArrayBuffer.isView(body)) return Buffer.from(body.buffer, body.byteOffset, body.byteLength);
  if (body instanceof ArrayBuffer) return Buffer.from(body);
  throw new Error('نوع Body برای کانال امن ویندوز پشتیبانی نمی‌شود');
}
async function bmPlainJson(url, options = {}, timeoutMs = 12000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...options, redirect:'error', signal: ctrl.signal, headers: { 'Accept':'application/json', ...(options.headers || {}) } });
    const text = await res.text();
    let data;
    try { data = JSON.parse(text); } catch { throw new Error(`پاسخ JSON معتبر نیست (${res.status})`); }
    if (!res.ok || data?.status === 'error') throw new Error(data?.message || `HTTP ${res.status}`);
    return data;
  } finally { clearTimeout(timer); }
}
async function bmEnsureDeviceAccess(force = false) {
  const now = Math.floor(Date.now() / 1000);
  if (!force && bmDeviceAccess.token && Number(bmDeviceAccess.exp || 0) > now + 180) return bmDeviceAccess;
  if (bmDeviceAccessPromise) return bmDeviceAccessPromise;
  bmDeviceAccessPromise = (async () => {
    const identity = bmDeviceIdentity();
    const challenge = await bmPlainJson(DEFAULT.challengeUrl, {
      method:'POST', cache:'no-store',
      headers:{ 'Content-Type':'application/json', 'X-BM-Client':'windows', 'X-BM-Client-Version':app.getVersion() },
      body:JSON.stringify({ device_id:identity.deviceId, public_key:identity.publicKey, version:app.getVersion(), protocol:2 })
    }, 12000);
    const canonical = ['BM-WIN-CHALLENGE-1', String(challenge.challenge_id || ''), String(challenge.challenge || ''), identity.deviceId, app.getVersion()].join('\n');
    const signature = bmB64UrlEncode(crypto.sign('sha256', Buffer.from(canonical, 'utf8'), identity.privateKey));
    const issued = await bmPlainJson(DEFAULT.tokenUrl, {
      method:'POST', cache:'no-store',
      headers:{ 'Content-Type':'application/json', 'X-BM-Client':'windows', 'X-BM-Client-Version':app.getVersion() },
      body:JSON.stringify({ challenge_id:challenge.challenge_id, device_id:identity.deviceId, public_key:identity.publicKey, signature, version:app.getVersion(), protocol:2 })
    }, 12000);
    const token = String(issued.access_token || '');
    const payload = bmDecodeJwtPayload(token);
    if (!token || !Number(payload.exp) || String(payload.did || '') !== identity.deviceId) throw new Error('توکن امن ویندوز معتبر نیست');
    bmDeviceAccess = { token, exp:Number(payload.exp), jti:String(payload.jti || '') };
    bmScheduleDeviceAccessRefresh(bmDeviceAccess.exp);
    return bmDeviceAccess;
  })();
  try { return await bmDeviceAccessPromise; }
  finally { bmDeviceAccessPromise = null; }
}
function isWindowsV1ContentUrl(rawUrl) {
  try {
    const u = new URL(String(rawUrl || ''));
    const expected = new URL(DEFAULT.domain);
    return u.protocol === 'https:' && u.hostname === expected.hostname && (u.port || '') === (expected.port || '') && /^\/v1\//.test(u.pathname);
  } catch { return false; }
}
async function windowsV1AuthHeaders(rawUrl, options = {}) {
  if (!isWindowsV1ContentUrl(rawUrl)) return {};
  const identity = bmDeviceIdentity();
  const access = await bmEnsureDeviceAccess(false);
  const u = new URL(String(rawUrl));
  const ts = String(Math.floor(Date.now() / 1000));
  const nonce = bmB64UrlEncode(crypto.randomBytes(18));
  const method = String(options.method || 'GET').toUpperCase();
  const pathQuery = `${u.pathname}${u.search || ''}`;
  const bodyHash = bmSha256(bmRequestBodyBuffer(options.body));
  const canonical = ['BM-WIN-DPOP-1', method, pathQuery, ts, nonce, bodyHash, access.jti].join('\n');
  const proof = bmB64UrlEncode(crypto.sign('sha256', Buffer.from(canonical, 'utf8'), identity.privateKey));
  return {
    'X-BM-Device-Token': access.token,
    'X-BM-Device-ID': identity.deviceId,
    'X-BM-DPoP-Ts': ts,
    'X-BM-DPoP-Nonce': nonce,
    'X-BM-DPoP': proof,
    'X-BM-Client': 'windows',
    'X-BM-Client-Version': app.getVersion()
  };
}
function windowsV1ApiBase(cfg = {}) {
  const base = String(cfg.api_base_url || cfg.desktop?.api_base_url || DEFAULT.apiBaseUrl).replace(/\/$/, '');
  if (base !== DEFAULT.apiBaseUrl) throw new Error('API Base خارج از دامنه امن ویندوز است');
  return base;
}
async function fetchJson(url, options = {}, timeoutMs = 22000, allowSecurityRetry = true) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const authHeaders = await windowsV1AuthHeaders(url, options);
    const res = await fetch(url, { ...options, redirect:'error', signal: ctrl.signal, headers: { 'Accept':'application/json', ...(options.headers || {}), 'X-BM-Client':'windows', ...authHeaders } });
    const text = await res.text();
    let data;
    try { data = JSON.parse(text); } catch { throw new Error(`پاسخ JSON معتبر نیست (${res.status})`); }
    if (res.status === 401 && isWindowsV1ContentUrl(url) && allowSecurityRetry) {
      bmClearDeviceRefreshTimer();
      bmDeviceAccess = { token:'', exp:0, jti:'' };
      await bmEnsureDeviceAccess(true);
      return await fetchJson(url, options, timeoutMs, false);
    }
    if (!res.ok && !data?.success) throw new Error(data?.message || `HTTP ${res.status}`);
    return data;
  } finally { clearTimeout(timer); }
}
async function loadRemoteConfig(force = false) {
  if (runtimeConfig && !force) return runtimeConfig;
  const controller = normalizeBase(DEFAULT.controllerUrl, DEFAULT.controllerUrl);
  try {
    const envelope = await bmPlainJson(controller, { cache:'no-store', headers:{ 'X-BM-Client':'windows', 'X-BM-Client-Version':app.getVersion() } }, 12000);
    const remote = bmVerifyControllerEnvelope(envelope);
    const domain = DEFAULT.domain;
    const apiBase = DEFAULT.apiBaseUrl;
    runtimeConfig = {
      ...remote,
      active_domain: domain,
      content_domain: domain,
      api_base_url: apiBase,
      api_url: `${apiBase}/desktop_api.php`,
      desktop_api_url: `${apiBase}/desktop_api.php`,
      account_api_url: `${apiBase}/desktop_user_api.php`,
      controller_url: controller,
      _online: true,
      _verified: true
    };
    writeState({ bmVerifiedRemoteConfig:null, bmVerifiedRemoteConfigEnvelope:envelope, bmVerifiedRemoteConfigAt:Date.now() });
  } catch (error) {
    const state = readState();
    let saved = null;
    try {
      const ageMs = Date.now() - Number(state.bmVerifiedRemoteConfigAt || 0);
      if (ageMs >= 0 && ageMs <= 7 * 24 * 60 * 60 * 1000) {
        saved = bmVerifyControllerEnvelope(state.bmVerifiedRemoteConfigEnvelope);
      }
    } catch { saved = null; }
    if (saved) {
      runtimeConfig = {
        ...saved, active_domain:DEFAULT.domain, content_domain:DEFAULT.domain,
        api_base_url:DEFAULT.apiBaseUrl, api_url:DEFAULT.apiUrl,
        desktop_api_url:DEFAULT.apiUrl, account_api_url:DEFAULT.accountApiUrl,
        controller_url:controller, _online:false, _verified:true, _stale:true,
        _error:String(error?.message || error)
      };
    } else {
      runtimeConfig = {
        platform:'windows', active_domain:DEFAULT.domain, content_domain:DEFAULT.domain,
        api_base_url:DEFAULT.apiBaseUrl, api_url:DEFAULT.apiUrl, desktop_api_url:DEFAULT.apiUrl,
        account_api_url:DEFAULT.accountApiUrl, controller_url:controller,
        features:{}, desktop:{ enabled:true, features:{} }, _online:false, _verified:false,
        _error:String(error?.message || error)
      };
    }
  }
  return runtimeConfig;
}
function queryUrl(base, params = {}) {
  const u = new URL(base);
  Object.entries(params).forEach(([k,v]) => {
    if (v === undefined || v === null || v === '') return;
    if (Array.isArray(v)) v.forEach(x => u.searchParams.append(k, String(x)));
    else u.searchParams.set(k, String(v));
  });
  return u;
}
function contentRequestTimeoutMs(action, params = {}) {
  const a = String(action || '').toLowerCase();
  // Large series can return hundreds/thousands of episode/source rows.
  // The website can legitimately need 20-30s, so Detail must not inherit
  // the short generic JSON timeout.
  if (a === 'detail') return 90000;
  if (a === 'play') return 65000;
  if (a === 'boot') return 35000;
  return 30000;
}
async function contentRequest(action, params = {}) {
  const cfg = await loadRemoteConfig();
  // Desktop calls the server-side facade. Static API signing secrets never ship in the EXE.
  const candidates = [cfg.desktop_api_url, cfg.api_url, DEFAULT.apiUrl].filter(Boolean);
  let last;
  for (const base of [...new Set(candidates)]) {
    const url = queryUrl(base, { action, ...params }).toString();
    try {
      const token = loadToken();
      const headers = {
        'X-BM-Client': 'windows',
        'X-BM-Download-System': '2'
      };
      if (token) {
        headers.Authorization = `Bearer ${token}`;
        headers['X-BM-User-Token'] = token;
      }
      return await fetchJson(url, { cache: 'no-store', headers }, contentRequestTimeoutMs(action, params));
    } catch (e) { last = e; }
  }
  const msg = String(last?.message || '');
  if (/\.php\b|https?:\/\/|bankmovie|runtime|api\d*[_-]?lib|source[_ -]?unavailable/i.test(msg)) {
    throw new Error('ارتباط با این بخش برقرار نشد. لطفاً دوباره تلاش کنید.');
  }
  throw last || new Error('سرور محتوا در دسترس نیست');
}
// The weekly schedule is served by the existing DPoP-protected Windows API origin.
async function weeklyScheduleRequest() {
  const cfg = await loadRemoteConfig();
  const base = windowsV1ApiBase(cfg);
  const url = `${base}/weekly_schedule.php`;
  return fetchJson(url, { cache:'no-store', headers:{ 'X-BM-Client':'windows' } }, 18000);
}

const searchOptionsCache = new Map();
async function searchOptionsRequest(archive = 3) {
  const a = Number(archive) || 3;
  if (a !== 3) return { success: true, archive: a };
  const hit = searchOptionsCache.get(a);
  if (hit && Date.now() - hit.at < 4 * 60 * 60 * 1000) return hit.data;
  const cfg = await loadRemoteConfig();
  const apiBase = windowsV1ApiBase(cfg);
  const url = queryUrl(`${apiBase}/api6.php`, { search_options: 1, client: 'app' }).toString();
  try {
    const raw = await fetchJson(url, { cache: 'no-store', headers: { 'X-BM-Client': 'windows' } }, 14000);
    const data = raw?.options || raw?.data || raw || {};
    const result = { success: raw?.success !== false, archive: a, ...data };
    searchOptionsCache.set(a, { at: Date.now(), data: result });
    return result;
  } catch (error) {
    return { success: false, archive: a, message: String(error?.message || 'search options unavailable') };
  }
}


async function advancedSearchRequest(params = {}) {
  const a = Number(params.archive) || 1;
  const page = Math.max(1, Number(params.page) || 1);
  const limit = Math.max(1, Math.min(60, Number(params.limit) || 36));
  const q = String(params.q || params.s || '').trim();
  const type = String(params.type || 'all').trim() || 'all';
  const genre = String(params.genre || '').trim();
  const country = String(params.country || '').trim();
  const director = String(params.director || '').trim();
  const actor = String(params.actor || '').trim();
  const yearFrom = String(params.yearFrom || params.fromYear || params.year_from || '').trim();
  const yearTo = String(params.yearTo || params.toYear || params.year_to || '').trim();
  const exactYear = String(params.exactYear || params.year || params.yearse || '').trim();
  const rating = String(params.rating || params.imdbScore || params.imdbrate || '').trim();
  const sort = String(params.sort || params.sortby || '').trim();
  const language = String(params.language || params.lang || '').trim();
  const dubbed = Boolean(params.dubbed);
  const subtitle = Boolean(params.subtitle);

  // Archive 3 uses the real API6 contract directly, exactly like the site/app source.
  if (a === 3) {
    const cfg = await loadRemoteConfig();
    const apiBase = windowsV1ApiBase(cfg);
    const url = queryUrl(`${apiBase}/api6.php`, {
      client: 'app', q, s: q, type, genre, country, director, actor,
      year: exactYear, yearse: exactYear, fromYear: yearFrom, toYear: yearTo,
      imdbScore: rating, sort: sort || 'newest', lang: language,
      dubbed: dubbed ? 1 : '', subtitle: subtitle ? 1 : '', page
    }).toString();
    const raw = await fetchJson(url, { cache: 'no-store', headers: { 'X-BM-Client': 'windows' } }, 18000);
    const items = raw?.movies || raw?.items || raw?.results || [];
    return {
      ...raw,
      status: raw?.status || 'success',
      archive: 3,
      page: Number(raw?.page || page) || page,
      items,
      results: items,
      total: Number(raw?.total ?? raw?.total_count ?? raw?.count ?? items.length) || items.length,
      total_count: Number(raw?.total_count ?? raw?.total ?? raw?.count ?? items.length) || items.length
    };
  }

  // Archive 1: use the same current API2 search contract as the website.
  // No typing/live dropdown exists in Windows; actor discovery is resolved only
  // when the user submits Search, then actor filmography uses API2 pagination.
  if (a === 1) {
    return archive1SearchRequest({
      q, page, limit, type, genre, country, director, actor, rating, sort,
      yearFrom, yearTo, dubbed, subtitle
    });
  }

  // Archive 2 is the site-owned DB catalogue behind app_api.php.
  if (a === 2) {
    return contentRequest('search', {
      archive: 2, q, page, limit, type: type === 'all' ? '' : type,
      genre, country, year_from: yearFrom, year_to: yearTo,
      rating, sort: sort || 'newest',
      dubbed: dubbed ? 1 : '', subtitle: subtitle ? 1 : ''
    });
  }

  // Archive 4 desktop bridge mirrors api4.php/site query names.
  if (a === 4) {
    return contentRequest('search', {
      archive: 4, q, s: q, page, limit, type,
      genre, country, director, actor,
      year: exactYear, yearse: exactYear, fromYear: yearFrom, toYear: yearTo,
      imdbScore: rating, rating, sort: sort || 'newest', lang: language,
      dubbed: dubbed ? 1 : '', subtitle: subtitle ? 1 : ''
    });
  }

  // Archive 5 has no verified advanced-search contract in the Android/site sources.
  // Keep only real basic search instead of pretending unsupported filters worked.
  return contentRequest('search', { archive: a, q, page, limit, type: type === 'all' ? '' : type });
}


/* ===== BankMovie Desktop v1.1.31 — Archive 1 site-synced submitted search + actor pagination ===== */
function archive1ActorSlug(value = '') {
  let raw = String(value || '').trim();
  if (!raw) return '';
  try {
    const u = new URL(raw, 'https://bankmovie.top');
    const m = u.pathname.match(/\/actors\/([^/]+)/i);
    if (m) return decodeURIComponent(m[1]);
  } catch {}
  const m = raw.match(/(?:^|\/)actors\/([^/?#]+)/i);
  if (m) raw = m[1];
  return raw.replace(/^\/+|\/+$/g, '').replace(/^actors\//i, '').trim();
}
function archive1NormalizeActor(row = {}) {
  const title = String(row?.name || row?.title || '').trim();
  const url = String(row?.source_url || row?.url || '').trim();
  const slug = String(row?.slug || archive1ActorSlug(url || title)).trim();
  return {
    archive: 1,
    kind: 'actor',
    entity_type: 'actor',
    is_actor: true,
    id: row?.term_id || row?.id || slug,
    term_id: row?.term_id || row?.id || null,
    slug,
    name: title,
    title,
    image: String(row?.image || row?.poster || row?.thumbnail || '').trim(),
    poster: String(row?.poster || row?.image || row?.thumbnail || '').trim(),
    url,
    meta_data: String(row?.meta_data || 'بازیگر').trim()
  };
}
function archive1HasText(value = '') { return String(value || '').trim() !== ''; }
async function archive1SearchRequest(params = {}) {
  const cfg = await loadRemoteConfig();
  const apiBase = windowsV1ApiBase(cfg);
  const page = Math.max(1, Number(params.page) || 1);
  const limit = Math.max(1, Math.min(60, Number(params.limit) || 36));
  const typedQ = String(params.q || '').trim();
  const actorQ = String(params.actor || '').trim();
  const directorQ = String(params.director || '').trim();
  // Match the website: actor/director becomes the text query only when the main title query is empty.
  const q = typedQ || actorQ || directorQ;
  const rawType = String(params.type || 'all').trim().toLowerCase();
  const type = rawType === 'movie' ? 'movie' : (rawType === 'series' ? 'series' : 'both');

  // Keep the simple request simple, exactly like the current website/API2 fix:
  // ?s=TITLE&type=both. Optional filters are appended only when the user selected them.
  const searchParams = { client: 'app', s: q, type };
  const genre = String(params.genre || '').trim();
  const country = String(params.country || '').trim();
  const sort = String(params.sort || '').trim();
  const rating = String(params.rating || '').trim();
  const yearFrom = String(params.yearFrom || '').trim();
  const yearTo = String(params.yearTo || '').trim();
  if (/^\d+$/.test(genre) && Number(genre) > 0) searchParams.genre = genre;
  if (/^\d+$/.test(country) && Number(country) > 0) searchParams.country = country;
  if (sort && sort !== 'newest') searchParams.sortby = sort;
  if (rating && Number(rating) > 0) searchParams.imdbrate = rating;
  if (yearFrom && Number(yearFrom) > 1800) searchParams.min_year = yearFrom;
  if (yearTo && Number(yearTo) > 0 && Number(yearTo) < new Date().getFullYear()) searchParams.max_year = yearTo;
  if (params.dubbed) searchParams.dubbed = 1;
  if (params.subtitle) searchParams.subtitle = 1;
  if (page > 1) searchParams.page = page;

  const url = queryUrl(`${apiBase}/api2.php`, searchParams).toString();
  const raw = await fetchJson(url, { cache: 'no-store', headers: { 'X-BM-Client': 'windows' } }, 24000);
  const mediaRows = raw?.movies || raw?.items || raw?.results || [];
  const items = (Array.isArray(mediaRows) ? mediaRows : []).slice(0, limit).map(it => ({ ...it, archive: 1 }));

  // There is NO live-search UI in Windows. On submit/page 1 only, ask the website's
  // own API2 quick-search endpoint for actor entities so actor results stay in sync
  // with the website without the desktop talking to the upstream source directly.
  let actors = [];
  const actorLookup = actorQ || typedQ;
  if (page === 1 && actorLookup.length >= 2) {
    try {
      const peopleUrl = queryUrl(`${apiBase}/api2.php`, { live_search: actorLookup, limit: 20, client: 'app' }).toString();
      const quick = await fetchJson(peopleUrl, { cache: 'no-store', headers: { 'X-BM-Client': 'windows' } }, 12000);
      const people = Array.isArray(quick?.people) ? quick.people : (Array.isArray(quick?.results) ? quick.results : []);
      actors = people
        .filter(row => String(row?.entity_type || row?.kind || '').toLowerCase() === 'actor' || /\/actors\//i.test(String(row?.source_url || row?.url || '')))
        .map(archive1NormalizeActor)
        .filter(a => a.name && a.slug)
        .slice(0, 8);
    } catch {}
  }

  const hasMore = raw?.has_more === true || raw?.next_page != null || items.length >= Math.min(20, limit);
  return {
    ...raw,
    status: raw?.status || 'success',
    success: raw?.success !== false,
    archive: 1,
    source: 'api2-site-search',
    query: q,
    page,
    items,
    results: items,
    movies: items,
    actors,
    people: actors,
    count: items.length,
    total: Number(raw?.total ?? raw?.total_count ?? items.length) || items.length,
    total_count: Number(raw?.total_count ?? raw?.total ?? items.length) || items.length,
    has_more: hasMore,
    next_page: raw?.next_page ?? (hasMore ? page + 1 : null)
  };
}
async function archive1ActorRequest(params = {}) {
  const cfg = await loadRemoteConfig();
  const apiBase = windowsV1ApiBase(cfg);
  const page = Math.max(1, Number(params.page) || 1);
  const slug = archive1ActorSlug(params.slug || params.url || params.name || '');
  if (!slug) throw new Error('شناسه بازیگر نامعتبر است');
  try {
    const url = queryUrl(`${apiBase}/api2.php`, { actor: slug, page, client: 'app' }).toString();
    const raw = await fetchJson(url, { cache: 'no-store', headers: { 'X-BM-Client': 'windows' } }, 24000);
    const items = (raw?.items || raw?.movies || raw?.results || []).map(it => ({ ...it, archive: 1 }));
    const actor = raw?.actor || raw?.person || { name: params.name || slug, slug };
    const current = Number(raw?.page || raw?.current_page || page) || page;
    const totalPages = Number(raw?.total_pages || raw?.pages || raw?.last_page || 0) || 0;
    const total = Number(raw?.total || raw?.total_count || actor?.count || items.length) || items.length;
    const hasMore = raw?.has_more === true || raw?.next_page != null || (totalPages > current);
    return { ...raw, success: raw?.success !== false, archive: 1, actor, items, movies: items, page: current, total, total_count: total, total_pages: totalPages, has_more: hasMore };
  } catch (directError) {
    const fallback = await contentRequest('actor', { archive: 1, slug, name: params.name || '', page });
    const items = (fallback?.items || fallback?.movies || fallback?.results || []).map(it => ({ ...it, archive: 1 }));
    return { ...fallback, archive: 1, items, movies: items, page: Number(fallback?.page || page) || page };
  }
}

async function userRequest(action, body = {}, method = 'POST') {
  const cfg = await loadRemoteConfig();
  const url = queryUrl(cfg.account_api_url || DEFAULT.accountApiUrl, method === 'GET' ? { action, ...body } : {});
  const token = loadToken();
  const headers = {
    'X-BM-Client': 'windows',
    'X-BM-Notification-Protocol': '2',
    'Content-Type': 'application/json'
  };
  if (token) {
    headers.Authorization = `Bearer ${token}`;
    headers['X-BM-User-Token'] = token;
  }
  const opts = { method, headers, cache: 'no-store' };
  if (method !== 'GET') opts.body = JSON.stringify({ action, ...body });
  const data = await fetchJson(url.toString(), opts);
  if ((action === 'login' || action === 'register') && data?.token) saveToken(data.token);
  if (action === 'logout') saveToken('');
  return data;
}
function safeFileName(name) {
  return String(name || 'BankMovie').replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/\s+/g, ' ').trim().slice(0, 150) || 'BankMovie';
}

const PLAYER_DEFS = [
  {
    id: 'potplayer', name: 'PotPlayer', score: 100,
    exes: ['PotPlayerMini64.exe','PotPlayerMini.exe','PotPlayer.exe'],
    paths: [
      ['ProgramFiles','DAUM','PotPlayer','PotPlayerMini64.exe'],
      ['ProgramFiles','PotPlayer','PotPlayerMini64.exe'],
      ['ProgramFiles(x86)','DAUM','PotPlayer','PotPlayerMini.exe'],
      ['ProgramFiles(x86)','PotPlayer','PotPlayerMini.exe']
    ]
  },
  {
    id: 'vlc', name: 'VLC', score: 95,
    exes: ['vlc.exe'],
    paths: [
      ['ProgramFiles','VideoLAN','VLC','vlc.exe'],
      ['ProgramFiles(x86)','VideoLAN','VLC','vlc.exe']
    ]
  },
  {
    id: 'kmplayer', name: 'KMPlayer', score: 80,
    exes: ['KMPlayer64.exe','KMPlayer.exe'],
    paths: [
      ['ProgramFiles','KMPlayer 64X','KMPlayer64.exe'],
      ['ProgramFiles','KMPlayer','KMPlayer.exe'],
      ['ProgramFiles(x86)','The KMPlayer','KMPlayer.exe'],
      ['ProgramFiles(x86)','KMPlayer','KMPlayer.exe']
    ]
  }
];

function uniqExisting(paths) {
  const seen = new Set();
  return paths.filter(p => {
    if (!p) return false;
    const q = path.resolve(p);
    if (seen.has(q.toLowerCase()) || !fs.existsSync(q)) return false;
    seen.add(q.toLowerCase());
    return true;
  });
}
function appPathFromRegistry(exe) {
  if (process.platform !== 'win32') return '';
  const roots = ['HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\App Paths', 'HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\App Paths'];
  for (const root of roots) {
    try {
      const out = execFileSync('reg.exe', ['query', `${root}\\${exe}`, '/ve'], { encoding:'utf8', windowsHide:true, timeout:1800 });
      const m = out.match(/REG_(?:EXPAND_)?SZ\s+(.+)$/mi);
      if (m && fs.existsSync(m[1].trim())) return m[1].trim();
    } catch {}
  }
  return '';
}
function appPathFromWhere(exe) {
  if (process.platform !== 'win32') return '';
  try {
    const out = execFileSync('where.exe', [exe], { encoding:'utf8', windowsHide:true, timeout:1800 });
    return out.split(/\r?\n/).map(x=>x.trim()).find(x=>x && fs.existsSync(x)) || '';
  } catch { return ''; }
}
function detectPlayers() {
  if (process.platform !== 'win32') return [];
  const now = Date.now();
  if (bmPlayersCache && now < bmPlayersCacheUntil) return bmPlayersCache.map(p=>({...p}));
  const found = [];
  for (const def of PLAYER_DEFS) {
    const candidates = [];
    for (const parts of def.paths) {
      const root = process.env[parts[0]];
      if (root) candidates.push(path.join(root, ...parts.slice(1)));
    }
    for (const exe of def.exes) {
      candidates.push(appPathFromRegistry(exe));
      candidates.push(appPathFromWhere(exe));
    }
    const existing = uniqExisting(candidates);
    if (existing.length) {
      const executable = existing.find(x => /64\.exe$/i.test(x)) || existing[0];
      found.push({ id:def.id, name:def.name, path:executable, score:def.score, subtitleSupport:def.id !== 'kmplayer' });
    }
  }
  bmPlayersCache = found.sort((a,b)=>b.score-a.score);
  bmPlayersCacheUntil = Date.now() + 60000;
  return bmPlayersCache.map(p=>({...p}));
}
function selectedPlayer(preferred = 'auto') {
  const players = detectPlayers();
  if (!players.length) return null;
  if (preferred && preferred !== 'auto') return players.find(p=>p.id===preferred) || players[0];
  return players[0];
}
async function materializeSubtitle(url) {
  if (!url || !/^https?:\/\//i.test(url)) return '';
  const ctrl = new AbortController();
  const timer = setTimeout(()=>ctrl.abort(), 15000);
  try {
    const res = await fetch(url, { signal:ctrl.signal, redirect:'follow' });
    if (!res.ok) return '';
    const buf = Buffer.from(await res.arrayBuffer());
    if (!buf.length || buf.length > 8 * 1024 * 1024) return '';
    let ext = '.srt';
    try {
      const e = path.extname(new URL(url).pathname).toLowerCase();
      if (['.srt','.vtt','.ass','.ssa','.sub'].includes(e)) ext = e;
    } catch {}
    const dir = path.join(app.getPath('temp'), 'BankMovie', 'subtitles');
    fs.mkdirSync(dir, { recursive:true });
    const file = path.join(dir, `${crypto.createHash('sha1').update(url).digest('hex')}${ext}`);
    fs.writeFileSync(file, buf);
    return file;
  } catch { return ''; }
  finally { clearTimeout(timer); }
}
async function launchExternalPlayer(meta = {}) {
  const url = String(meta.url || '');
  if (!/^https?:\/\//i.test(url)) throw new Error('لینک پخش معتبر نیست');
  const pref = String(meta.preferredPlayer || settings().preferredPlayer || 'auto');
  const player = selectedPlayer(pref);
  if (!player) throw new Error('هیچ‌کدام از VLC، PotPlayer یا KMPlayer روی ویندوز پیدا نشد. یکی از آن‌ها را نصب کن.');
  const subtitlePath = await materializeSubtitle(String(meta.subtitleUrl || ''));
  const args = [];
  if (player.id === 'vlc') {
    args.push(url, '--one-instance');
    if (subtitlePath) args.push(`--sub-file=${subtitlePath}`);
  } else if (player.id === 'potplayer') {
    args.push(url);
    if (subtitlePath) args.push(`/sub=${subtitlePath}`);
  } else {
    args.push(url);
  }
  try {
    const child = spawn(player.path, args, { detached:true, stdio:'ignore', windowsHide:false });
    child.unref();
  } catch (e) {
    throw new Error(`اجرای ${player.name} ناموفق بود: ${e.message}`);
  }
  return { ok:true, player:{ id:player.id, name:player.name, path:player.path }, subtitleApplied:Boolean(subtitlePath && player.subtitleSupport) };
}


function isLocalPlayableFile(filePath){
  return /\.(?:mp4|mkv|avi|mov|m4v|webm|wmv|mp3|m4a|aac|flac|wav|ogg)$/i.test(String(filePath||''));
}
function launchPreferredLocalFile(filePath){
  const target=String(filePath||'');
  if(!target||!fs.existsSync(target))return false;
  const player=selectedPlayer(settings().preferredPlayer||'auto');
  if(!player||!isLocalPlayableFile(target))return false;
  try{
    const child=spawn(player.path,[target],{detached:true,stdio:'ignore',windowsHide:false});
    child.unref();
    return {ok:true,player:{id:player.id,name:player.name,path:player.path}};
  }catch{return false}
}


async function fetchBoxOffice(){
  const cfg = await loadRemoteConfig();
  const apiBase = windowsV1ApiBase(cfg);
  const url = `${apiBase}/api_boxoffice.php?mode=weekend`;
  return fetchJson(url, { cache:'no-store', headers:{ 'Accept':'application/json', 'X-BM-Client':'windows' } });
}

async function probeMediaContentType(raw){
  if(/\.(mp4|webm|ogg|mov|m4v)(?:$|[?#])/i.test(raw)) return 'video/direct';
  if(/\.(mp3|m4a|aac|wav)(?:$|[?#])/i.test(raw)) return 'audio/direct';
  try{
    const ctrl=new AbortController();const timer=setTimeout(()=>ctrl.abort(),5000);
    const res=await fetch(raw,{method:'HEAD',redirect:'follow',signal:ctrl.signal,headers:{'User-Agent':'BankMovieDesktop/1.9.3'}});
    clearTimeout(timer);
    return String(res.headers.get('content-type')||'').toLowerCase();
  }catch{return ''}
}
function mediaPlayerHtml(raw,title){
  const safeUrl=JSON.stringify(String(raw||'')).replace(/</g,'\\u003c');
  const safeTitle=JSON.stringify(String(title||'BankMovie Trailer')).replace(/</g,'\\u003c');
  return `<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${String(title||'BankMovie Trailer').replace(/[<>&"]/g,'')}</title><style>
  html,body{margin:0;width:100%;height:100%;background:#03060b;color:#fff;font-family:Segoe UI,Tahoma,sans-serif;overflow:hidden}
  .wrap{width:100%;height:100%;display:flex;flex-direction:column;background:radial-gradient(circle at 50% 0,#0d1d33,#03060b 58%)}
  header{height:52px;display:flex;align-items:center;justify-content:space-between;padding:0 18px;border-bottom:1px solid rgba(78,161,255,.18);background:#050911}
  header strong{font-size:14px}header span{font-size:11px;color:#6eb5ff}
  main{flex:1;display:grid;place-items:center;min-height:0;padding:16px}
  video{width:100%;height:100%;max-width:1500px;max-height:calc(100vh - 84px);background:#000;border-radius:14px;box-shadow:0 18px 60px rgba(0,0,0,.55);outline:none}
  </style></head><body><div class="wrap"><header><strong id="ttl"></strong><span>BankMovie Trailer</span></header><main><video id="v" controls autoplay playsinline preload="auto"></video></main></div><script>
  const u=${safeUrl},t=${safeTitle};document.getElementById('ttl').textContent=t;const v=document.getElementById('v');v.src=u;v.play().catch(()=>{});
  </script></body></html>`;
}
async function openWebWindow(url, title='BankMovie'){
  const raw=String(url||'').trim();
  let parsed;
  try { parsed = new URL(raw); } catch { throw new Error('لینک وب معتبر نیست'); }
  if (!['http:','https:'].includes(parsed.protocol) || parsed.username || parsed.password || raw.length > 16000) throw new Error('لینک وب معتبر نیست');
  // In-memory partition: remote pages never share the privileged app session.
  const remoteSession = session.fromPartition('bm-remote-viewer');
  if (!bmRemoteSessionLocked) {
    remoteSession.setPermissionRequestHandler((_webContents, _permission, callback)=>callback(false));
    remoteSession.on('will-download', event=>event.preventDefault());
    bmRemoteSessionLocked = true;
  }
  const child=new BrowserWindow({
    width:1180,height:760,minWidth:900,minHeight:620,
    parent:win||undefined,modal:false,show:false,
    backgroundColor:'#05070b',title:String(title||'BankMovie'),
    autoHideMenuBar:true,
    webPreferences:{contextIsolation:true,nodeIntegration:false,sandbox:true,partition:'bm-remote-viewer'}
  });
  child.webContents.setWindowOpenHandler(()=>({action:'deny'}));
  child.webContents.on('will-navigate',(event,nextUrl)=>{
    try { if (!['https:','http:'].includes(new URL(nextUrl).protocol)) event.preventDefault(); }
    catch { event.preventDefault(); }
  });
  childWindows.add(child);
  child.once('closed',()=>childWindows.delete(child));
  child.setMenuBarVisibility(false);
  child.once('ready-to-show',()=>{ if(!child.isDestroyed()) child.show(); });
  const ctype=await probeMediaContentType(raw);
  const direct=/^video\//i.test(ctype)||ctype==='video/direct'||/\.(mp4|webm|ogg|mov|m4v)(?:$|[?#])/i.test(raw);
  if(direct){
    const html=mediaPlayerHtml(raw,title);
    await child.loadURL('data:text/html;charset=utf-8,'+encodeURIComponent(html));
  }else{
    await child.loadURL(raw);
  }
  if(!child.isDestroyed()){child.show();child.focus();}
  return true;
}


function sendToMainWindow(channel, payload) {
  if (win && !win.isDestroyed() && win.webContents && !win.webContents.isDestroyed()) {
    try { win.webContents.send(channel, payload); } catch {}
  }
}
function showNativeNotification(title, body) {
  try {
    if (Notification.isSupported()) {
      new Notification({
        title: String(title || 'BankMovie'),
        body: String(body || ''),
        icon: path.join(__dirname, '../src/assets/bankmovie-icon.png'),
        silent: false
      }).show();
    }
  } catch {}
}
function nativeDownloadNotification(title, body) {
  if (!downloaderSettings().downloadNotifications) return;
  showNativeNotification(title, body);
}
function nativePowerNotification(title, body) {
  showNativeNotification(title, body);
}


function mergeDownloadState(id, patch = {}) {
  const prev = downloadState.get(id) || {};
  // orderAt is immutable UI/history ordering. `at` remains the live update timestamp.
  // Keeping them separate prevents concurrent downloads from swapping rows on every progress event.
  const orderAt = Number(prev.orderAt||prev.queuedAt||patch.queuedAt||prev.createdAt||patch.createdAt||prev.startedAt||Date.now());
  const next = { ...prev, ...patch, id, orderAt, at: Date.now() };
  downloadState.set(id, next);
  persistDownloadJournalSoon();
  return next;
}
function publishDownloadState(id, patch = {}, preferredWebContents = null) {
  const next = mergeDownloadState(id, patch);
  const targets = [];
  if (preferredWebContents && typeof preferredWebContents.isDestroyed === 'function' && !preferredWebContents.isDestroyed()) targets.push(preferredWebContents);
  if (win && !win.isDestroyed() && win.webContents && !win.webContents.isDestroyed() && !targets.includes(win.webContents)) targets.push(win.webContents);
  for (const target of targets) {
    try { target.send('download:update', next); } catch {}
  }
  if (terminalDownloadState(next.state)) setTimeout(evaluateAfterDownloadsPlan, 0);
  return next;
}
function downloadSnapshot() {
  return [...downloadState.values()].sort((a,b)=>downloadStableOrderAt(b)-downloadStableOrderAt(a));
}
function clearDownloadMonitor(id) {
  const timer = downloadMonitors.get(id);
  if (timer) clearInterval(timer);
  downloadMonitors.delete(id);
}
function startDownloadMonitor(id, item, sourceWebContents) {
  clearDownloadMonitor(id);
  let lastBytes = item.getReceivedBytes();
  let lastAt = Date.now();
  const timer = setInterval(() => {
    if (!downloadItems.has(id)) { clearDownloadMonitor(id); return; }
    const now = Date.now();
    if (forcedPausedDownloads.has(id) && !item.isPaused()) { try { item.pause(); } catch {} }
    const received = item.getReceivedBytes();
    const dt = Math.max(.05, (now-lastAt)/1000);
    const speed = Math.max(0, received-lastBytes)/dt;
    lastBytes = received;
    lastAt = now;
    publishDownloadState(id, {
      state: item.isPaused() ? 'progressing' : 'progressing',
      received,
      total: item.getTotalBytes(),
      paused: forcedPausedDownloads.has(id) || item.isPaused(),
      savePath: item.getSavePath(),
      speed
    }, sourceWebContents);
  }, 500);
  downloadMonitors.set(id, timer);
}

function installDownloadHooks() {
  session.defaultSession.on('will-download', (_event, item, sourceWebContents) => {
    const url = item.getURL();
    const chain = typeof item.getURLChain === 'function' ? item.getURLChain() : [url];

    let id = '';
    for (const u of chain) {
      if (pendingDownloadUrl.has(u)) { id = pendingDownloadUrl.get(u); break; }
    }
    if (!id && pendingDownloadUrl.has(url)) id = pendingDownloadUrl.get(url);
    if (!id && sourceWebContents === win?.webContents && pendingDownloadMeta.size === 1) {
      const first = pendingDownloadMeta.keys().next();
      if (!first.done) id = first.value; // CDN redirect of the sole queued download
    }
    if (!id || !pendingDownloadMeta.has(id)) {
      _event.preventDefault(); // never auto-save an unqueued browser download
      return;
    }
    const meta = pendingDownloadMeta.get(id) || {};

    startingDownloads.delete(id);
    pendingDownloadMeta.delete(id);
    for (const [u, mappedId] of [...pendingDownloadUrl.entries()]) {
      if (mappedId === id) pendingDownloadUrl.delete(u);
    }

    const folder = settings().downloadDir;
    fs.mkdirSync(folder, { recursive: true });
    let ext = '.mp4';
    try { ext = path.extname(new URL(url).pathname) || '.mp4'; } catch {}
    const requestedName = meta.fileName || item.getFilename() || `BankMovie-${id}${ext}`;
    item.setSavePath(uniqueDownloadPath(folder, requestedName, downloaderSettings().downloadConflict));
    downloadItems.set(id, item);
    publishQueueStatus();

    if (cancelledPendingDownloads.has(id)) {
      cancelledPendingDownloads.delete(id);
      try { item.cancel(); } catch {}
      publishDownloadState(id, { url, ...meta, state:'cancelled', received:0, total:item.getTotalBytes(), paused:false, savePath:item.getSavePath() }, sourceWebContents);
      downloadItems.delete(id);
      heldQueuedDownloads.delete(id);
      pumpDownloadQueue();
      return;
    }

    publishDownloadState(id, { url, ...meta, state:'starting', received:item.getReceivedBytes(), total:item.getTotalBytes(), paused:false, savePath:item.getSavePath() }, sourceWebContents);
    startDownloadMonitor(id, item, sourceWebContents);

    // Delay the native "started" notification slightly so a request that fails
    // immediately does not show both "started" and an error at the same time.
    const notifyTimer=setTimeout(()=>{
      const st=downloadState.get(id);
      if(st && !['cancelled','interrupted','completed'].includes(st.state)){
        nativeDownloadNotification('دانلود شروع شد', meta.title || meta.fileName || 'BankMovie');
      }
    },700);

    item.on('updated', (_e, state) => {
      if (forcedPausedDownloads.has(id) && !item.isPaused()) { try { item.pause(); } catch {} }
      publishDownloadState(id, {
        state,
        received:item.getReceivedBytes(),
        total:item.getTotalBytes(),
        paused:forcedPausedDownloads.has(id) || item.isPaused(),
        savePath:item.getSavePath()
      }, sourceWebContents);
    });

    item.once('done', (_e, state) => {
      clearTimeout(notifyTimer);
      clearDownloadMonitor(id);
      downloadItems.delete(id);
      forcedPausedDownloads.delete(id);
      heldQueuedDownloads.delete(id);
      const common={
        received:item.getReceivedBytes(),
        total:item.getTotalBytes(),
        paused:false,
        savePath:item.getSavePath(),
        finishedAt:Date.now()
      };
      if (state === 'completed') {
        clearRetryTimer(id);
        publishDownloadState(id,{...common,state:'completed'},sourceWebContents);
        nativeDownloadNotification('دانلود کامل شد', meta.title || item.getFilename() || 'BankMovie');
      } else if (state === 'cancelled') {
        clearRetryTimer(id);
        publishDownloadState(id,{...common,state:'cancelled'},sourceWebContents);
        nativeDownloadNotification('دانلود لغو شد', meta.title || item.getFilename() || 'BankMovie');
      } else {
        handleDownloadInterruption(id,item,sourceWebContents,state||'interrupted');
      }
      pumpDownloadQueue();
    });
  });
}
function bmSafeExternalUrl(raw){
  try{
    const u=new URL(String(raw||''));
    if(!['https:','http:','mailto:','tg:'].includes(u.protocol))return '';
    return u.toString();
  }catch{return ''}
}
function createWindow() {
  win = new BrowserWindow({
    width: 1480, height: 920, minWidth: 1100, minHeight: 700,
    frame: false, backgroundColor: '#060708', show: false,
    icon: path.join(__dirname, '../src/assets/bankmovie-icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  win.loadFile(path.join(__dirname, '../src/index.html'));
  win.webContents.setWindowOpenHandler(({url})=>{
    const safe=bmSafeExternalUrl(url);
    if(safe) setTimeout(()=>shell.openExternal(safe).catch(()=>{}),0);
    return {action:'deny'};
  });
  win.webContents.on('will-navigate',(event,url)=>{
    if (!bmIsAppIndexUrl(url)) event.preventDefault();
  });
  const sendFullscreenState = () => {
    if (win && !win.isDestroyed() && win.webContents && !win.webContents.isDestroyed()) {
      win.webContents.send('window:fullscreen-state', win.isFullScreen());
    }
  };
  win.on('enter-full-screen', sendFullscreenState);
  win.on('leave-full-screen', sendFullscreenState);
  win.once('ready-to-show', () => { win.show(); sendFullscreenState(); });
}

app.whenReady().then(() => { restoreDownloadJournal(); installDownloadHooks(); createWindow(); startDownloadQueueTicker(); setTimeout(()=>pumpDownloadQueue(),800); setTimeout(()=>bmEnsureDeviceAccess(false).catch(()=>{}),900); setTimeout(()=>backfillDownloadCovers().catch(()=>{}),6000); app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); }); });
app.on('before-quit',()=>persistDownloadJournalNow());
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

bmHandle('bootstrap', async () => ({ config: await loadRemoteConfig(true), settings: settings(), players: detectPlayers(), hasToken: Boolean(loadToken()), version: app.getVersion() }));
bmHandle('content:request', (_e, action, params) => contentRequest(action, params));
bmHandle('weekly-schedule:get', () => weeklyScheduleRequest());
bmHandle('search:options', (_e, archive) => searchOptionsRequest(archive));
bmHandle('search:advanced', (_e, params) => advancedSearchRequest(params || {}));
bmHandle('archive1:actor', (_e, params) => archive1ActorRequest(params || {}));
bmHandle('user:request', (_e, action, body, method) => userRequest(action, body || {}, method || 'POST'));
bmHandle('auth:clear', () => { saveToken(''); return true; });
bmHandle('settings:get', () => settings());
bmHandle('settings:set', (_e, patch) => {
  writeState(sanitizeSettingsPatch(patch || {}));
  runtimeConfig = null;
  setTimeout(()=>{pumpDownloadQueue();publishQueueStatus()},0);
  return settings();
});
bmHandle('settings:choose-download-dir', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openDirectory', 'createDirectory'], defaultPath: settings().downloadDir });
  if (r.canceled || !r.filePaths[0]) return settings().downloadDir;
  writeState({ downloadDir: r.filePaths[0] }); return r.filePaths[0];
});
bmHandle('download:add', (_e, meta) => {
  if (!meta?.url || !/^https?:\/\//i.test(meta.url)) throw new Error('لینک دانلود معتبر نیست');
  const id = crypto.randomUUID();
  const payload = { ...meta, id, poster:String(meta.poster||''), posterCachePath:'', posterCacheUrl:'', queuedAt: Date.now(), state:'queued', received:0, total:0, paused:false, retryAttempt:0 };
  downloadMetaStore.set(id,payload);
  enqueueDownloadId(id);
  powerTrackDownloadId(id);
  publishDownloadState(id,payload);
  if(payload.poster)cacheDownloadPoster(id,payload.poster).catch(()=>{});
  pumpDownloadQueue();
  return { id, state:downloadState.get(id), queue:downloadQueueStatus() };
});
bmHandle('download:list', () => downloadSnapshot());
bmHandle('download:queue-status', () => downloadQueueStatus());
bmHandle('download:queue-action', (_e, action, payload={}) => {
  const a=String(action||'');
  if(a==='pause'){
    downloadQueuePaused=true;return publishQueueStatus();
  }
  if(a==='resume'){
    downloadQueuePaused=false;pumpDownloadQueue();return publishQueueStatus();
  }
  if(a==='clear_completed'){
    for(const [id,st] of [...downloadState.entries()]){
      if(['completed','cancelled','interrupted'].includes(String(st?.state||''))){
        removeDownloadCoverFile(st);
        downloadState.delete(id);downloadMetaStore.delete(id);clearRetryTimer(id);removeQueuedId(id);heldQueuedDownloads.delete(id);
      }
    }
    persistDownloadJournalNow();
    return publishQueueStatus();
  }
  if(a==='move_up'||a==='move_down'){
    moveQueuedDownload(String(payload?.id||''),a==='move_up'?'up':'down');
    return downloadQueueStatus();
  }
  if(a==='start_now'){
    downloadQueuePaused=false;
    pumpDownloadQueue();
    return publishQueueStatus({manual:true});
  }
  return downloadQueueStatus();
});
bmHandle('power:status', (event) => { if(!trustedMainRenderer(event)) throw new Error('پنجره نامعتبر'); return powerPublicStatus(); });
bmHandle('power:schedule', (event, payload) => armPowerPlan(event, payload || {}));
bmHandle('power:cancel', (event) => cancelPowerPlan(event));
bmHandle('download:action', (_e, id, action) => {
  id=String(id||'');
  const item = downloadItems.get(id);
  if (!item) {
    if(action==='remove'){
      const existed=downloadState.has(id)||downloadMetaStore.has(id);
      const result=purgeDownloadRecord(id);
      publishQueueStatus();
      return existed?result:{id,removed:true};
    }
    const queued=downloadQueue.includes(id)||startingDownloads.has(id)||String(downloadState.get(id)?.state||'')==='retry_wait';
    if (action === 'cancel' && queued) {
      const wasStarting=startingDownloads.has(id);
      clearRetryTimer(id);
      removeQueuedId(id);
      heldQueuedDownloads.delete(id);
      const meta = downloadMetaStore.get(id) || pendingDownloadMeta.get(id) || {};
      if(wasStarting){
        cancelledPendingDownloads.add(id);
        // Keep the pending URL/id mapping until will-download fires so the native item can be cancelled safely.
      }else{
        pendingDownloadMeta.delete(id);
        for (const [u, mappedId] of [...pendingDownloadUrl.entries()]) if (mappedId === id) pendingDownloadUrl.delete(u);
      }
      const out=publishDownloadState(id,{...meta,state:'cancelled',received:Number(downloadState.get(id)?.received||0),total:Number(downloadState.get(id)?.total||0),paused:false,finishedAt:Date.now()});
      pumpDownloadQueue();
      return out;
    }
    if(action==='pause'&&queued){
      heldQueuedDownloads.add(id);
      const out=publishDownloadState(id,{state:'queued',paused:true});
      publishQueueStatus();return out;
    }
    if(action==='resume'&&queued){
      heldQueuedDownloads.delete(id);
      if(!downloadQueue.includes(id)&&!startingDownloads.has(id))enqueueDownloadId(id,{front:true});
      const out=publishDownloadState(id,{state:'queued',paused:false});
      pumpDownloadQueue();return out;
    }
    if(action==='retry'){
      const prev=downloadState.get(id)||{};
      const meta=downloadMetaStore.get(id)||prev;
      if(!meta?.url||!/^https?:\/\//i.test(String(meta.url||'')))return prev;
      clearRetryTimer(id);heldQueuedDownloads.delete(id);removeQueuedId(id);
      downloadMetaStore.set(id,{...meta,id,retryAttempt:0});
      const out=publishDownloadState(id,{...meta,id,state:'queued',paused:false,received:0,total:0,speed:0,eta:0,retryAttempt:0,retryAt:0,savePath:'',queuedAt:Date.now(),finishedAt:0,lastError:''});
      enqueueDownloadId(id,{front:true});pumpDownloadQueue();return out;
    }
    return downloadState.get(id) || null;
  }
  if (action === 'remove') {
    try { if (item && !item.isDestroyed?.()) item.cancel(); } catch {}
    const result=purgeDownloadRecord(id);
    pumpDownloadQueue();
    publishQueueStatus();
    return result;
  }
  if (action === 'pause') {
    forcedPausedDownloads.add(id);
    try { item.pause(); } catch {}
    return publishDownloadState(id, { state:'progressing', received:item.getReceivedBytes(), total:item.getTotalBytes(), paused:true, savePath:item.getSavePath() });
  }
  if (action === 'resume') {
    forcedPausedDownloads.delete(id);
    try { item.resume(); } catch {}
    return publishDownloadState(id, { state:'progressing', received:item.getReceivedBytes(), total:item.getTotalBytes(), paused:false, savePath:item.getSavePath() });
  }
  if (action === 'cancel') {
    forcedPausedDownloads.delete(id);
    try { item.cancel(); } catch {}
    clearDownloadMonitor(id);
    const snapshot=publishDownloadState(id, { state:'cancelled', received:item.getReceivedBytes(), total:item.getTotalBytes(), paused:false, savePath:item.getSavePath(), finishedAt:Date.now() });
    downloadItems.delete(id);
    pumpDownloadQueue();
    return snapshot;
  }
  return downloadState.get(id) || null;
});
bmHandle('file:open', async (_e, filePath) => {
  if (!filePath || !fs.existsSync(filePath)) return false;
  const preferred=launchPreferredLocalFile(filePath);
  if(preferred)return preferred;
  const err = await shell.openPath(filePath);
  return err === '' ? {ok:true,player:null} : false;
});
bmHandle('player:list', () => detectPlayers());
bmHandle('player:play', (_e, meta) => launchExternalPlayer(meta || {}));
bmHandle('boxoffice:get', () => fetchBoxOffice());
bmHandle('browser:open', (_e, url, title) => openWebWindow(url, title));
bmHandle('shell:open', (_e, url) => { const safe=bmSafeExternalUrl(url); if(!safe) throw new Error('لینک خارجی مجاز نیست'); return shell.openExternal(safe); });
bmHandle('shell:show-item', (_e, filePath) => { shell.showItemInFolder(filePath); return true; });
bmOn('window:minimize', () => win?.minimize());
bmOn('window:maximize', () => win?.isMaximized() ? win.unmaximize() : win?.maximize());
bmHandle('window:fullscreen', () => {
  if (!win || win.isDestroyed()) return false;
  const next = !win.isFullScreen();
  win.setFullScreen(next);
  return next;
});
bmOn('window:close', () => win?.close());
