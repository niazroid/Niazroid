; BankMovie NSIS dark installer theme (cosmetic only).
; Keep electron-builder's standard assisted installer, install mode, upgrade and uninstaller.
;
; IMPORTANT: MUI settings and GUIINIT callback must be defined BEFORE page macros
; are expanded. customInit runs from .onInit BEFORE a usable wizard HWND exists,
; so it must not attempt to recolor the installer window.

!ifndef BUILD_UNINSTALLER
  !ifdef MUI_BGCOLOR
    !undef MUI_BGCOLOR
  !endif
  !ifdef MUI_TEXTCOLOR
    !undef MUI_TEXTCOLOR
  !endif
  !ifdef MUI_INSTFILESPAGE_COLORS
    !undef MUI_INSTFILESPAGE_COLORS
  !endif
  !define MUI_BGCOLOR "0B0F17"
  !define MUI_TEXTCOLOR "EDF3FB"
  !define MUI_INSTFILESPAGE_COLORS "EDF3FB 0B0F17"

  ; MUI calls this once when the actual wizard HWND has been created.
  !define MUI_CUSTOMFUNCTION_GUIINIT BM_DarkGuiInit
!endif

!macro customHeader
  !ifndef BUILD_UNINSTALLER
    Function BM_DarkGuiInit
      Push $0
      ; Optional Windows 10/11 dark caption. Unsupported versions ignore this.
      System::Call 'dwmapi::DwmSetWindowAttribute(p $HWNDPARENT, i 20, *i 1, i 4)i.r0'
      ; Older Windows 10 builds use attribute 19. Harmless when unsupported.
      System::Call 'dwmapi::DwmSetWindowAttribute(p $HWNDPARENT, i 19, *i 1, i 4)i.r0'

      ; Color the MUI wizard shell. No custom controls or changed install logic.
      SetCtlColors $HWNDPARENT EDF3FB 0B0F17
      GetDlgItem $0 $HWNDPARENT 1034 ; header background
      StrCmp $0 0 +2
        SetCtlColors $0 EDF3FB 0B0F17
      GetDlgItem $0 $HWNDPARENT 1037 ; header title
      StrCmp $0 0 +2
        SetCtlColors $0 EDF3FB 0B0F17
      GetDlgItem $0 $HWNDPARENT 1038 ; header subtitle
      StrCmp $0 0 +2
        SetCtlColors $0 A6B6C9 0B0F17
      GetDlgItem $0 $HWNDPARENT 1028 ; branding background
      StrCmp $0 0 +2
        SetCtlColors $0 8392A6 0B0F17
      GetDlgItem $0 $HWNDPARENT 1256 ; branding text
      StrCmp $0 0 +2
        SetCtlColors $0 8392A6 0B0F17
      Pop $0
    FunctionEnd

    ; Called AFTER electron-builder creates its existing all-users / current-user
    ; controls, before showing the page. Radio buttons keep their real behaviour.
    Function BM_DarkInstallMode
      SetCtlColors $MultiUser.InstallModePage EDF3FB 0B0F17
      SetCtlColors $MultiUser.InstallModePage.Text EDF3FB 0B0F17
      SetCtlColors $MultiUser.InstallModePage.AllUsers EDF3FB 0B0F17
      SetCtlColors $MultiUser.InstallModePage.CurrentUser EDF3FB 0B0F17
      SetCtlColors $RadioButtonLabel1 A6B6C9 0B0F17
    FunctionEnd
  !endif
!macroend

; This callback is scoped ONLY to the original install-mode page. We deliberately
; do not add a welcome page or change install mode, elevation or upgrade rules.
!macro customWelcomePage
  !ifndef BUILD_UNINSTALLER
    !define MUI_PAGE_CUSTOMFUNCTION_SHOW BM_DarkInstallMode
  !endif
!macroend
