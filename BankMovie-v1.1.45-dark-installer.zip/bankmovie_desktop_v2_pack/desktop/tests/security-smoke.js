'use strict';
// Standalone source-level behavior smoke checks. No Electron install or server needed.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const vm = require('node:vm');
const { pathToFileURL } = require('node:url');
const crypto = require('node:crypto');
const {publicKey:testPublicKey, privateKey:testPrivateKey} = crypto.generateKeyPairSync('rsa', { modulusLength:2048, publicKeyEncoding:{type:'spki',format:'pem'}, privateKeyEncoding:{type:'pkcs8',format:'pem'} });

const root = path.resolve(__dirname, '..');
const source = fs.readFileSync(path.join(root, 'electron/main.js'),'utf8');
const work = fs.mkdtempSync(path.join(os.tmpdir(), 'bm-v145-smoke-'));
let encrypted = false, minimized=0, commands=0;
const handlers = new Map(), events = new Map();
const mockApp = {
  setName(){}, setAppUserModelId(){},
  getVersion(){ return '1.1.45'; },
  getPath(which){ return which === 'userData' ? work : work; },
  whenReady(){ return new Promise(()=>{}); }, // prevent Electron window creation
  on(){}, isReady(){return true;}
};
const mockElectron = {
  app:mockApp, BrowserWindow:function(){},
  ipcMain:{handle:(k,fn)=>handlers.set(k,fn),on:(k,fn)=>events.set(k,fn)},
  dialog:{},shell:{},session:{},Notification:{},
  safeStorage:{
    isEncryptionAvailable:()=>encrypted,
    encryptString:s=>Buffer.from('mock:'+s),
    decryptString:buf=>buf.toString().slice(5)
  }
};
const clonedProcess = {platform:process.platform,env:{...process.env},pid:process.pid};
const realChild = require('node:child_process');
const requireMock=(name)=>{
  if(name==='electron') return mockElectron;
  if(name==='./runtime.generated') return {...require(path.join(root,'electron/runtime.generated.js')), configPublicKey:testPublicKey};
  if(name==='child_process') return {...realChild,execFileSync(){commands++;return '';}};
  return require(name);
};
const ctx=vm.createContext({
  require:requireMock, __dirname:path.join(root,'electron'),__filename:path.join(root,'electron/main.js'),
  module:{exports:{}},exports:{},process:clonedProcess,Buffer,URL,URLSearchParams,AbortController,
  setTimeout,clearTimeout,setInterval,clearInterval,console,fetch:()=>{throw new Error('Network must not be used by smoke tests');}
});
try {
  vm.runInContext(source,ctx,{filename:'electron/main.js',timeout:5000});
  assert.equal(handlers.size,27,'all privileged handle IPC channels registered');
  assert.equal(events.size,3,'all one-way window IPC channels registered');
  const index=pathToFileURL(path.join(root,'src/index.html')).href;
  const web={id:9,isDestroyed:()=>false,getURL:()=>index,mainFrame:{processId:33,routingId:44}};
  ctx.__testWindow={isDestroyed:()=>false,webContents:web,minimize:()=>{minimized++;}};
  vm.runInContext('win = __testWindow',ctx);
  const valid={sender:web,senderFrame:{processId:33,routingId:44,url:index}};
  const wrongFrame={sender:web,senderFrame:{processId:33,routingId:45,url:index}};
  const wrongFile={sender:web,senderFrame:{processId:33,routingId:44,url:'file:///tmp/evil.html'}};
  const wrongWin={sender:{...web,id:10},senderFrame:{processId:33,routingId:44,url:index}};
  async function rejectsAll(event){
    for(const [channel,fn] of handlers){
      await assert.rejects(async()=>fn(event),/نامعتبر/,`blocked IPC ${channel}`);
    }
  }
  (async()=>{
    await rejectsAll(wrongFrame);
    await rejectsAll(wrongFile);
    await rejectsAll(wrongWin);
    const settings=await handlers.get('settings:get')(valid);
    assert.ok(settings && typeof settings==='object','valid main-frame IPC allowed');
    events.get('window:minimize')(wrongFrame);
    assert.equal(minimized,0,'subframe send ignored');
    events.get('window:minimize')(valid);
    assert.equal(minimized,1,'trusted main frame send accepted');

    // With OS storage unavailable, token must NOT appear in desktop-state.json.
    vm.runInContext("saveToken('smoke-secret-123')",ctx);
    let state=JSON.parse(fs.readFileSync(path.join(work,'desktop-state.json'),'utf8'));
    assert.equal(state.authToken,'','no plaintext disk token');
    assert.equal(vm.runInContext('loadToken()',ctx),'smoke-secret-123','session continues in RAM');
    vm.runInContext("saveToken('')",ctx);
    assert.equal(vm.runInContext('loadToken()',ctx),'','logout clears RAM token');

    encrypted=true;
    vm.runInContext("saveToken('safe-storage-token')",ctx);
    state=JSON.parse(fs.readFileSync(path.join(work,'desktop-state.json'),'utf8'));
    assert.equal(state.authEncrypted,true,'encrypted account token marked');
    assert.equal(vm.runInContext('loadToken()',ctx),'safe-storage-token','OS-protected token roundtrip');
    fs.writeFileSync(path.join(work,'desktop-state.json'),JSON.stringify({authEncrypted:false,authToken:'old-plaintext-token'}));
    assert.equal(vm.runInContext('loadToken()',ctx),'old-plaintext-token','legacy token loads');
    state=JSON.parse(fs.readFileSync(path.join(work,'desktop-state.json'),'utf8'));
    assert.equal(state.authEncrypted,true,'legacy plaintext automatically migrated');
    assert.notEqual(state.authToken,'old-plaintext-token','legacy secret no longer plaintext');

    // Offline config must be reconstructed from a *signed* envelope; an
    // unsigned or altered cache can never earn a _verified flag.
    const cfg={content_domain:'https://bankmovie.top',api_base_url:'https://bankmovie.top/v1',features:{weekly_schedule_enabled:true}};
    const payload=Buffer.from(JSON.stringify(cfg));
    const envelope={schema:'bm-win-config-envelope-v1',alg:'RS256',payload:payload.toString('base64url'),signature:crypto.sign('RSA-SHA256',payload,testPrivateKey).toString('base64url')};
    fs.writeFileSync(path.join(work,'desktop-state.json'),JSON.stringify({bmVerifiedRemoteConfigEnvelope:envelope,bmVerifiedRemoteConfigAt:Date.now()}));
    const offline=await vm.runInContext('loadRemoteConfig(true)',ctx);
    assert.equal(offline._verified,true,'offline signed config verified');
    assert.equal(offline.features.weekly_schedule_enabled,true,'offline features preserved');
    envelope.payload=Buffer.from(JSON.stringify({...cfg,features:{weekly_schedule_enabled:false}})).toString('base64url');
    fs.writeFileSync(path.join(work,'desktop-state.json'),JSON.stringify({bmVerifiedRemoteConfigEnvelope:envelope,bmVerifiedRemoteConfigAt:Date.now()}));
    const tampered=await vm.runInContext('loadRemoteConfig(true)',ctx);
    assert.equal(tampered._verified,false,'tampered offline config rejected');

    // Lightweight performance guard: registry/where discovery must be cached.
    clonedProcess.platform='win32';
    vm.runInContext('detectPlayers()',ctx);
    const firstCalls=commands;
    assert.ok(firstCalls>0,'initial player discovery ran');
    vm.runInContext('detectPlayers()',ctx);
    assert.equal(commands,firstCalls,'second discovery used cache');

    // Critical API calls must not follow redirects with bearer/DPoP headers.
    assert.match(source,/await fetch\(url, \{ \.\.\.options, redirect:'error', signal: ctrl\.signal/);
    assert.match(source,/bmVerifyControllerEnvelope\(state\.bmVerifiedRemoteConfigEnvelope\)/);
    assert.match(source,/remoteSession\.on\('will-download', event=>event\.preventDefault\(\)\)/);
    console.log(`PASS: ${handlers.size} invoke channels + ${events.size} event channels guarded; account tokens, signed config & player cache checks passed.`);
  })().catch(e=>{console.error(e);process.exitCode=1;}).finally(()=>fs.rmSync(work,{recursive:true,force:true}));
} catch(e) { fs.rmSync(work,{recursive:true,force:true}); throw e; }
