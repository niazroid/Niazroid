'use strict';
// Static guard: installer changes must not redefine install/elevation/upgrade flow.
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const base = path.join(__dirname, '..');
const pkg = JSON.parse(fs.readFileSync(path.join(base, 'package.json'), 'utf8'));
const nsis = pkg.build.nsis;
const theme = fs.readFileSync(path.join(base, 'build-assets/installer-black.nsh'), 'utf8');
assert.strictEqual(pkg.version, '1.1.45');
assert.strictEqual(pkg.build.appId, 'top.bankmovie.desktop');
assert.strictEqual(nsis.oneClick, false);
assert.strictEqual(nsis.allowToChangeInstallationDirectory, true);
assert.strictEqual(nsis.createStartMenuShortcut, true);
assert.strictEqual(nsis.include, 'build-assets/installer-black.nsh');
assert.match(theme, /MUI_CUSTOMFUNCTION_GUIINIT BM_DarkGuiInit/);
assert.match(theme, /MUI_PAGE_CUSTOMFUNCTION_SHOW BM_DarkInstallMode/);
assert.match(theme, /\$MultiUser\.InstallModePage\.AllUsers/);
assert.match(theme, /\$MultiUser\.InstallModePage\.CurrentUser/);
assert.doesNotMatch(theme, /!macro\s+(preInit|customInit|customInstallMode|customInstall|customUnInstall)\b/i);
assert.doesNotMatch(theme, /nsDialogs::CreateTimer/);
assert.doesNotMatch(theme, /SetShellVarContext|UAC_RunElevated|WriteReg|DeleteReg|RMDir|SetOutPath/);
for (const file of ['installer-header-black.bmp','installer-sidebar-black.bmp','bankmovie-installer.ico']) {
  assert.ok(fs.statSync(path.join(base, 'build-assets', file)).size > 2000, file);
}
console.log('Installer-theme static guards: PASS');
