package ir.bankmoviee.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.PathInterpolator
import kotlin.math.min

/** Day/night switch based on the supplied sun, moon, clouds and stars design. */
class BmThemeSwitchView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var progress = 0f // 0 = light/day, 1 = dark/night
    private var animator: ValueAnimator? = null
    private var listener: ((Boolean) -> Unit)? = null
    var dark: Boolean = true
        private set

    init {
        isClickable = true
        isFocusable = true
        setOnClickListener { setDark(!dark, true, true) }
    }

    fun setOnDarkChangeListener(block: (Boolean) -> Unit) { listener = block }

    fun setDark(value: Boolean, animate: Boolean = false, notify: Boolean = false) {
        dark = value
        val target = if (value) 1f else 0f
        animator?.cancel()
        if (animate) {
            animator = ValueAnimator.ofFloat(progress, target).apply {
                duration = 480L
                interpolator = PathInterpolator(0f, -0.02f, 0.4f, 1.25f)
                addUpdateListener { progress = it.animatedValue as Float; invalidate() }
                start()
            }
        } else {
            progress = target
            invalidate()
        }
        contentDescription = if (dark) "تم مشکی" else "تم روشن"
        if (notify) listener?.invoke(value)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val r = h / 2f
        rect.set(0f, 0f, w, h)
        paint.style = Paint.Style.FILL
        paint.color = blend(Color.rgb(61, 126, 174), Color.rgb(29, 31, 44), progress)
        canvas.drawRoundRect(rect, r, r, paint)

        // Clouds slide down as night arrives.
        val cloudY = h * (0.73f + progress * 1.0f)
        paint.color = Color.argb((235 * (1f - progress)).toInt(), 243, 253, 255)
        val cloudR = h * 0.18f
        for (i in 0..4) {
            canvas.drawCircle(w * (0.10f + i * 0.19f), cloudY - (i % 2) * cloudR * 0.35f, cloudR, paint)
        }

        // Stars descend into view.
        paint.color = Color.argb((255 * progress).toInt(), 255, 255, 255)
        val starPath = Path()
        val starY = h * (0.20f + (1f - progress) * -0.8f)
        listOf(0.14f to 0.8f, 0.29f to 1.0f, 0.43f to 0.65f).forEach { (xF, scale) ->
            val x = w * xF
            val sr = h * 0.055f * scale
            starPath.reset()
            starPath.moveTo(x, starY - sr)
            starPath.lineTo(x + sr * 0.28f, starY - sr * 0.28f)
            starPath.lineTo(x + sr, starY)
            starPath.lineTo(x + sr * 0.28f, starY + sr * 0.28f)
            starPath.lineTo(x, starY + sr)
            starPath.lineTo(x - sr * 0.28f, starY + sr * 0.28f)
            starPath.lineTo(x - sr, starY)
            starPath.lineTo(x - sr * 0.28f, starY - sr * 0.28f)
            starPath.close()
            canvas.drawPath(starPath, paint)
        }

        val circleD = h * 1.28f
        val x = h * 0.5f + (w - h) * progress
        paint.color = Color.argb(28, 255, 255, 255)
        canvas.drawCircle(x, h / 2f, circleD * 0.5f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = h * 0.12f
        paint.color = Color.argb(24, 255, 255, 255)
        canvas.drawCircle(x, h / 2f, circleD * 0.62f, paint)
        paint.style = Paint.Style.FILL

        val bodyR = h * 0.32f
        paint.color = blend(Color.rgb(236, 202, 47), Color.rgb(196, 201, 209), progress)
        paint.setShadowLayer(h * 0.07f, 0f, h * 0.04f, Color.argb(85, 0, 0, 0))
        setLayerType(LAYER_TYPE_SOFTWARE, paint)
        canvas.drawCircle(x, h / 2f, bodyR, paint)
        paint.clearShadowLayer()

        // Moon craters fade in.
        paint.color = Color.argb((180 * progress).toInt(), 149, 157, 177)
        canvas.drawCircle(x - bodyR * 0.35f, h / 2f + bodyR * 0.20f, bodyR * 0.22f, paint)
        canvas.drawCircle(x + bodyR * 0.28f, h / 2f + bodyR * 0.05f, bodyR * 0.12f, paint)
        canvas.drawCircle(x - bodyR * 0.02f, h / 2f - bodyR * 0.38f, bodyR * 0.08f, paint)
    }

    private fun blend(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )
}
