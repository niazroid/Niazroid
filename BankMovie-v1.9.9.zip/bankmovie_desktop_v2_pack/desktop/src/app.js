const $ = (q, root=document) => root.querySelector(q);
const $$ = (q, root=document) => [...root.querySelectorAll(q)];
const esc = (v='') => String(v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const cleanUrl = (v='') => /^https?:\/\//i.test(String(v)) ? String(v) : '';
const fmtBytes = n => !n ? '—' : n > 1073741824 ? `${(n/1073741824).toFixed(1)} GB` : n > 1048576 ? `${(n/1048576).toFixed(1)} MB` : `${(n/1024).toFixed(0)} KB`;
const pct = (a,b) => b > 0 ? Math.min(100, Math.round(a/b*100)) : 0;
const sleep = ms => new Promise(r => setTimeout(r,ms));


const ICONS = {
  download:`<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path opacity=".5" d="M2 12C2 7.28595 2 4.92893 3.46447 3.46447C4.92893 2 7.28595 2 12 2C16.714 2 19.0711 2 20.5355 3.46447C22 4.92893 22 7.28595 22 12C22 16.714 22 19.0711 20.5355 20.5355C19.0711 22 16.714 22 12 22C7.28595 22 4.92893 22 3.46447 20.5355C2 19.0711 2 16.714 2 12Z" fill="currentColor"/><path d="M12.75 7C12.75 6.58579 12.4142 6.25 12 6.25C11.5858 6.25 11.25 6.58579 11.25 7L11.25 12.1893L9.53033 10.4697C9.23744 10.1768 8.76256 10.1768 8.46967 10.4697C8.17678 10.7626 8.17678 11.2374 8.46967 11.5303L11.4697 14.5303C11.6103 14.671 11.8011 14.75 12 14.75C12.1989 14.75 12.3897 14.671 12.5303 14.5303L15.5303 11.5303C15.8232 11.2374 15.8232 10.7626 15.5303 10.4697C15.2374 10.1768 14.7626 10.1768 14.4697 10.4697L12.75 12.1893V7Z" fill="currentColor"/><path d="M8 16.25C7.58579 16.25 7.25 16.5858 7.25 17C7.25 17.4142 7.58579 17.75 8 17.75H16C16.4142 17.75 16.75 17.4142 16.75 17C16.75 16.5858 16.4142 16.25 16 16.25H8Z" fill="currentColor"/></svg>`,
  filter:`<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M5 3H19L8.81562 13.1844C8.65593 12.7689 8.39992 12.4122 8.03751 12.0976C7.80967 11.8998 7.49146 11.7206 6.85504 11.3624L3.94202 9.72255C2.99347 9.18858 2.5192 8.9216 2.2596 8.49142C2 8.06124 2 7.54232 2 6.50448V5.81466C2 4.48782 2 3.8244 2.43934 3.4122C2.87868 3 3.58579 3 5 3Z" fill="currentColor"/><path opacity=".5" d="M21.9998 6.50448V5.81466C21.9998 4.48782 21.9998 3.8244 21.5605 3.4122C21.1211 3 20.414 3 18.9998 3L8.81543 13.1844C8.86481 13.3129 8.90498 13.447 8.93625 13.5872C8.99981 13.8722 8.99981 14.2058 8.99981 14.8729L8.99981 17.5424C8.99981 18.452 8.99981 18.9067 9.25173 19.2613C9.50366 19.6158 9.95109 19.7907 10.846 20.1406C12.7246 20.875 13.6639 21.2422 14.3319 20.8244C14.9998 20.4066 14.9998 19.4519 14.9998 17.5424V14.8729C14.9998 14.2058 14.9998 13.8722 15.0634 13.5872C15.1957 12.9935 15.4878 12.5095 15.9623 12.0976C16.1901 11.8998 16.5083 11.7206 17.1448 11.3624L20.0578 9.72255C21.0063 9.18858 21.4806 8.9216 21.7402 8.49142C21.9998 8.06124 21.9998 7.54232 21.9998 6.50448Z" fill="currentColor"/></svg>`,
  play:`<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M18.7 8.97989L4.14 17.7099C4.05 17.3799 4 17.0299 4 16.6699V7.32989C4 4.24989 7.33 2.32989 10 3.86989L14.04 6.19989L18.09 8.53989C18.31 8.66989 18.52 8.80989 18.7 8.97989Z" fill="currentColor"/><path opacity=".4" d="M18.0907 15.4598L14.0407 17.7998L10.0007 20.1298C8.0907 21.2298 5.8407 20.5698 4.7207 18.9598L5.1407 18.7098L19.5807 10.0498C20.5807 11.8498 20.0907 14.3098 18.0907 15.4598Z" fill="currentColor"/></svg>`,
  bookmark:`<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path opacity=".4" d="M16.8203 2H7.18031C5.05031 2 3.32031 3.74 3.32031 5.86V19.95C3.32031 21.75 4.61031 22.51 6.19031 21.64L11.0703 18.93C11.5903 18.64 12.4303 18.64 12.9403 18.93L17.8203 21.64C19.4003 22.52 20.6903 21.76 20.6903 19.95V5.86C20.6803 3.74 18.9503 2 16.8203 2Z" fill="currentColor"/><path d="M14.5 9.89996H12.75V8.20996C12.75 7.79996 12.41 7.45996 12 7.45996C11.59 7.45996 11.25 7.79996 11.25 8.20996V9.89996H9.5C9.09 9.89996 8.75 10.24 8.75 10.65C8.75 11.06 9.09 11.4 9.5 11.4H11.25V13.21C11.25 13.62 11.59 13.96 12 13.96C12.41 13.96 12.75 13.62 12.75 13.21V11.4H14.5C14.91 11.4 15.25 11.06 15.25 10.65C15.25 10.24 14.91 9.89996 14.5 9.89996Z" fill="currentColor"/></svg>`,
  settings:`<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path opacity=".34" d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M2 12.8799V11.1199C2 10.0799 2.85 9.21994 3.9 9.21994C5.71 9.21994 6.45 7.93994 5.54 6.36994C5.02 5.46994 5.33 4.29994 6.24 3.77994L7.97 2.78994C8.76 2.31994 9.78 2.59994 10.25 3.38994L10.36 3.57994C11.26 5.14994 12.74 5.14994 13.65 3.57994L13.76 3.38994C14.23 2.59994 15.25 2.31994 16.04 2.78994L17.77 3.77994C18.68 4.29994 18.99 5.46994 18.47 6.36994C17.56 7.93994 18.3 9.21994 20.11 9.21994C21.15 9.21994 22.01 10.0699 22.01 11.1199V12.8799C22.01 13.9199 21.16 14.7799 20.11 14.7799C18.3 14.7799 17.56 16.0599 18.47 17.6299C18.99 18.5399 18.68 19.6999 17.77 20.2199L16.04 21.2099C15.25 21.6799 14.23 21.3999 13.76 20.6099L13.65 20.4199C12.75 18.8499 11.27 18.8499 10.36 20.4199L10.25 20.6099C9.78 21.3999 8.76 21.6799 7.97 21.2099L6.24 20.2199C5.33 19.6999 5.02 18.5299 5.54 17.6299C6.45 16.0599 5.71 14.7799 3.9 14.7799C2.85 14.7799 2 13.9199 2 12.8799Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  bell:`<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path opacity=".4" d="M20.3992 16.3298C20.1192 17.0798 19.5292 17.6498 18.7592 17.9098C17.6792 18.2698 16.5692 18.5398 15.4492 18.7298C15.3392 18.7498 15.2292 18.7698 15.1192 18.7798C14.9392 18.8098 14.7592 18.8298 14.5792 18.8498C14.3592 18.8798 14.1292 18.8998 13.8992 18.9198C13.2692 18.9698 12.6492 18.9998 12.0192 18.9998C11.3792 18.9998 10.7392 18.9698 10.1092 18.9098C9.83923 18.8898 9.57923 18.8598 9.31923 18.8198C9.16923 18.7998 9.01923 18.7798 8.87923 18.7598C8.76923 18.7398 8.65923 18.7298 8.54923 18.7098C7.43923 18.5298 6.33923 18.2598 5.26923 17.8998C4.46923 17.6298 3.85923 17.0598 3.58923 16.3298C3.31923 15.6098 3.41923 14.7698 3.84923 14.0498L4.97923 12.1698C5.21923 11.7598 5.43923 10.9698 5.43923 10.4898V8.6298C5.43923 4.9998 8.38923 2.0498 12.0192 2.0498C15.6392 2.0498 18.5892 4.9998 18.5892 8.6298V10.4898C18.5892 10.9698 18.8092 11.7598 19.0592 12.1698L20.1892 14.0498C20.5992 14.7498 20.6792 15.5698 20.3992 16.3298Z" fill="currentColor"/><path d="M12.0002 10.7601C11.5802 10.7601 11.2402 10.4201 11.2402 10.0001V6.90014C11.2402 6.48014 11.5802 6.14014 12.0002 6.14014C12.4202 6.14014 12.7602 6.48014 12.7602 6.90014V10.0001C12.7502 10.4201 12.4102 10.7601 12.0002 10.7601Z" fill="currentColor"/><path d="M14.8297 20.01C14.4097 21.17 13.2997 22 11.9997 22C11.2097 22 10.4297 21.68 9.87969 21.11C9.55969 20.81 9.31969 20.41 9.17969 20C9.30969 20.02 9.43969 20.03 9.57969 20.05C9.80969 20.08 10.0497 20.11 10.2897 20.13C10.8597 20.18 11.4397 20.21 12.0197 20.21C12.5897 20.21 13.1597 20.18 13.7197 20.13C13.9297 20.11 14.1397 20.1 14.3397 20.07C14.4997 20.05 14.6597 20.03 14.8297 20.01Z" fill="currentColor"/></svg>`,
  search:`<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M11.5 21C16.7467 21 21 16.7467 21 11.5C21 6.25329 16.7467 2 11.5 2C6.25329 2 2 6.25329 2 11.5C2 16.7467 6.25329 21 11.5 21Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path opacity=".4" d="M22 22L20 20" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>`,
  user:`<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle opacity=".5" cx="12" cy="9" r="3" stroke="currentColor" stroke-width="1.5"/><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="1.5"/><path opacity=".5" d="M17.9691 20C17.81 17.1085 16.9247 15 11.9999 15C7.07521 15 6.18991 17.1085 6.03076 20" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>`,
  back:`<svg viewBox="0 0 100 100" aria-hidden="true"><path fill="currentColor" d="M33.934 54.458l30.822 27.938c.383.348.864.519 1.344.519.545 0 1.087-.222 1.482-.657.741-.818.68-2.083-.139-2.824L37.801 52.564 64.67 22.921c.742-.818.68-2.083-.139-2.824-.817-.742-2.082-.679-2.824.139L33.768 51.059c-.439.485-.59 1.126-.475 1.723-.059.608.153 1.235.641 1.676z"/></svg>`,
  refresh:`<svg viewBox="0 0 20 20" aria-hidden="true"><path fill="currentColor" d="M19.295 12c.389-.003.705.315.705.709v3.204c0 .392-.313.709-.7.709s-.7-.317-.7-.709l.001-1.125C16.778 17.844 13.398 20 9.756 20c-4.409 0-8.106-2.721-9.709-6.915a.708.708 0 0 1 1.305-.512c1.4 3.662 4.589 6.009 8.404 6.009 3.371 0 6.52-2.181 7.987-5.153l-1.472.01a.709.709 0 0 1-.009-1.418L19.295 12zM10.244 0c4.409 0 8.106 2.721 9.709 6.915a.708.708 0 0 1-1.305.512c-1.4-3.662-4.589-6.009-8.404-6.009-3.371 0-6.52 2.181-7.987 5.153l1.472-.01a.709.709 0 0 1 .009 1.418L.705 8A.708.708 0 0 1 0 7.291V4.087c0-.392.313-.709.7-.709s.7.317.7.709l-.001 1.125C3.222 2.156 6.602 0 10.244 0z"/></svg>`,
  imdb:`<svg viewBox="0 0 512 512" aria-label="IMDb"><rect width="512" height="512" rx="15%" fill="#f5c518"/><path fill="#111" d="M104 328V184H64v144zM189 184l-9 67-5-36-5-31h-50v144h34v-95l14 95h25l13-97v97h34V184zM256 328V184h62c15 0 26 11 26 25v94c0 14-11 25-26 25zm47-118l-9-1v94c5 0 9-1 10-3 2-2 2-8 2-18v-56-12l-3-4zM419 220h3c14 0 26 11 26 25v58c0 14-12 25-26 25h-3c-8 0-16-4-21-11l-2 9h-36V184h38v46c5-6 13-10 21-10zm-8 70v-34l-1-11c-1-2-4-3-6-3s-5 1-6 3v57c1 2 4 3 6 3s6-1 6-3l1-12z"/></svg>`,
  vip:`<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12.9873 5.73973C13.5921 5.39577 14 4.74552 14 4C14 2.89543 13.1046 2 12 2C10.8954 2 10 2.89543 10 4C10 4.7472 10.4097 5.39869 11.0168 5.74205L11.0078 5.76034C10.3521 7.12693 9.44232 9.08475 8.03664 9.81975C6.88336 10.4228 5.22628 10.1194 3.99634 9.8944C3.94215 9.11525 3.29293 8.5 2.5 8.5C1.67157 8.5 1 9.17157 1 10C1 10.7347 1.52815 11.346 2.22548 11.4749L5.17264 19.0836C5.62005 20.2387 6.7314 21 7.97011 21H16.0299C17.2686 21 18.3799 20.2387 18.8274 19.0836L21.7745 11.4749C22.4718 11.346 23 10.7347 23 10C23 9.17157 22.3284 8.5 21.5 8.5C20.7223 8.5 20.0828 9.09186 20.0074 9.84973C18.7483 10.013 17.1251 10.2213 15.9634 9.61387C14.5859 8.89364 13.6634 7.07077 12.9873 5.73973Z" fill="currentColor"/></svg>`,
  mic:`<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path opacity=".5" fill-rule="evenodd" clip-rule="evenodd" d="M12.0003 2C8.55914 2 5.76953 4.81123 5.76953 8.27907V12.9302C5.76953 16.3981 8.55914 19.2093 12.0003 19.2093C15.4415 19.2093 18.2311 16.3981 18.2311 12.9302V8.27907C18.2311 4.81124 15.4415 2 12.0003 2Z" fill="currentColor"/><path fill-rule="evenodd" clip-rule="evenodd" d="M3.69231 10.3721C4.07466 10.3721 4.38462 10.6844 4.38462 11.0697V12.9302C4.38462 17.1687 7.79414 20.6046 12 20.6046C16.2059 20.6046 19.6154 17.1687 19.6154 12.9302V11.0697C19.6154 10.6844 19.9253 10.3721 20.3077 10.3721C20.69 10.3721 21 10.6844 21 11.0697V12.9302C21 17.9393 16.9706 22 12 22C7.02944 22 3 17.9393 3 12.9302V11.0697C3 10.6844 3.30996 10.3721 3.69231 10.3721Z" fill="currentColor"/></svg>`,
  subtitle:`<svg viewBox="0 0 512 512" aria-hidden="true"><path fill="currentColor" d="M472 64H40a24.028 24.028 0 0 0-24 24v336a24.028 24.028 0 0 0 24 24h432a24.028 24.028 0 0 0 24-24V88a24.028 24.028 0 0 0-24-24Zm-8 352H48V96h416Z"/><path fill="currentColor" d="M184 344a87.108 87.108 0 0 0 54.484-18.891l-19.825-25.119A55.41 55.41 0 0 1 184 312a56 56 0 0 1 0-112 55.41 55.41 0 0 1 34.659 12.01l19.825-25.119A87.108 87.108 0 0 0 184 168a88 88 0 0 0 0 176Z"/><path fill="currentColor" d="M347.429 344a87.108 87.108 0 0 0 54.484-18.891l-19.825-25.119A55.414 55.414 0 0 1 347.429 312a56 56 0 0 1 0-112 55.414 55.414 0 0 1 34.659 12.01l19.825-25.119A87.108 87.108 0 0 0 347.429 168a88 88 0 0 0 0 176Z"/></svg>`
};
function icon(name,cls=''){return `<span class="svg-icon ${cls}">${ICONS[name]||''}</span>`}
function hydrateStaticIcons(root=document){$$('[data-svg-icon]',root).forEach(el=>{const name=el.dataset.svgIcon;if(ICONS[name])el.innerHTML=ICONS[name]})}
function searchLoaderHtml(text='در حال جستجو'){return `<div class="search-loader-wrap"><div id="wifi-loader"><svg class="circle-outer" viewBox="0 0 86 86"><circle class="back" cx="43" cy="43" r="40"></circle><circle class="front" cx="43" cy="43" r="40"></circle></svg><svg class="circle-middle" viewBox="0 0 60 60"><circle class="back" cx="30" cy="30" r="27"></circle><circle class="front" cx="30" cy="30" r="27"></circle></svg><svg class="circle-inner" viewBox="0 0 34 34"><circle class="back" cx="17" cy="17" r="14"></circle><circle class="front" cx="17" cy="17" r="14"></circle></svg><div class="text" data-text="${esc(text)}"></div></div></div>`}

const mockItems = Array.from({length:12},(_,i)=>({
  archive:1,id:`demo-${i+1}`,type:i%3===0?'series':'movie',title:`Midnight ${i+1}`,title_fa:`عنوان نمایشی ${i+1}`,
  year:2026-(i%4),rating:(8.7-i*.08).toFixed(1),poster:'',backdrop:'',description:'نسخه مرورگر فقط برای پیش‌نمایش رابط کاربری است.'
}));
const mockBridge = () => ({
  bootstrap: async()=>({config:{_online:false,active_domain:'https://bankmovie.top',features:{},desktop:{enabled:true,features:{}},app_archive_policy:{},home:{archive1_sections:['updated_movies','updated_series']}},settings:{downloadDir:'Downloads',preferredArchive:1,preferredPlayer:'auto'},players:[],hasToken:false,version:'preview'}),
  content: async(action,p={})=> action==='boot'?{status:'success',sliders:mockItems.slice(0,4),collections:[],archives:[1,2,3,4,5]}:action==='detail'?{status:'success',item:{...mockItems[0],description:'این پیش‌نمایش آفلاین است. در Electron داده واقعی از bankmovie.top خوانده می‌شود.',genres:['درام','معمایی'],play:{links:[{quality:'1080P',display_label:'1080P • سافت‌ساب',url:'',is_playable:false,is_download:false}]},related:mockItems.slice(1,7)}}:{status:'success',items:mockItems,page:1,has_more:false},
  user:async(a)=>a==='config'?{success:true,features:{},vip:{plans:[]}}:{success:false,message:'در حالت مرورگر حساب کاربری غیرفعال است'},
  getSettings:async()=>({downloadDir:'Downloads',preferredArchive:1,preferredPlayer:'auto'}), setSettings:async x=>x, chooseDownloadDir:async()=>'Downloads', download:async()=>({id:'demo'}), downloadAction:async()=>true, getPlayers:async()=>[], playExternal:async()=>{throw new Error('پلیر خارجی فقط در نسخه ویندوز فعال است')}, openExternal:async()=>true, showItem:async()=>true, openFile:async()=>true, onDownload:()=>{}, logoutLocal:async()=>true,
  window:{minimize(){},maximize(){},toggleFullscreen:async()=>false,onFullscreenState(){},close(){}}
});
const bridge = window.bankmovie || mockBridge();

const state = {
  config:null, settings:null, appVersion:'', user:null, stats:null, userConfig:null,
  archive:1, currentDetail:null, watchlist:[], downloads:new Map(), party:null, partyTimer:null, players:[],
  lastView:'home', homeCache:{}, searchPage:1, heroIndex:0, heroTimer:null, detailSeason:null, detailEpisode:null, visibleSources:[], recentViews:[], theme:'dark'
};

const SECTION_LABELS = {
  updated_movies:'جدیدترین فیلم‌ها',updated_series:'سریال‌های آپدیت‌شده',new_movies:'فیلم‌های جدید',new_series:'سریال‌های جدید',
  korean_series:'سریال‌های کره‌ای',dubbed:'دوبله فارسی',dubbed_fa:'دوبله فارسی',chinese_series:'سریال‌های چینی',top_2026:'برترین‌های ۲۰۲۶',top_movies:'Top 250 فیلم',top_series:'Top 250 سریال',anime:'انیمه',turkish:'فیلم و سریال ترکی',collections:'کالکشن‌ها',
  animation:'انیمیشن و انیمه',animations:'انیمیشن',action:'اکشن',drama:'درام',updated_animations:'انیمیشن‌های به‌روز شده',updated_anime:'انیمه‌های به‌روز شده',dubbed_movies:'فیلم‌های دوبله',subtitled_movies:'فیلم‌های زیرنویس',dubbed_series:'سریال‌های دوبله',subtitled_series:'سریال‌های زیرنویس',mini_series:'مینی‌سریال',turkish_series:'سریال‌های ترکی'
};
const ARCHIVE_NAMES={1:'آرشیو ۱',2:'آرشیو ۲',3:'آرشیو ۳',4:'آرشیو ۴',5:'آرشیو ۵'};
const ARCHIVE_DESCRIPTIONS={
  1:'هاردساب، دوبله، محتوای آسیایی و آپدیت سریع',
  2:'آرشیو بانک‌مووی؛ فیلم، سریال، دوبله و ژانرهای منتخب',
  3:'فیلم و سریال با تفکیک دوبله، زیرنویس و محتوای ویژه',
  4:'فیلم، سریال، انیمه و نسخه‌های دوبله/زیرنویس',
  5:'فیلم و سریال جدید، محتوای ترکی و انیمیشن'
};
const ARCHIVE_FALLBACK_SECTIONS={
  1:['updated_movies','updated_series','korean_series','dubbed','chinese_series','top_2026','anime','turkish','collections'],
  2:['updated_movies','updated_series','dubbed','animation','action','drama','collections'],
  3:['new_movies','new_series','updated_animations','updated_anime','dubbed_movies','subtitled_movies','dubbed_series','subtitled_series','mini_series','korean_series','turkish_series','collections'],
  4:['new_movies','new_series','updated_animations','updated_anime','dubbed_movies','subtitled_movies','collections'],
  5:['new_movies','new_series','turkish','animation']
};

const RECENT_KEY='bankmovie_recent_views_v1';
const THEME_KEY='bankmovie_theme_v1';
function loadRecentViews(){
  try{const rows=JSON.parse(localStorage.getItem(RECENT_KEY)||'[]');return Array.isArray(rows)?rows.slice(0,30):[]}catch{return[]}
}
function rememberRecentView(item){
  if(!item)return;const id=itemId(item);if(!id)return;
  const entry={archive:Number(item.archive||state.archive)||state.archive,id,type:item.type||'movie',title:item.title||'',title_fa:item.title_fa||'',poster:cleanUrl(item.poster||item.image||''),year:item.year||'',rating:itemRating(item),imdb_code:item.imdb_code||'',timestamp:Date.now()};
  state.recentViews=[entry,...state.recentViews.filter(x=>watchKey(x)!==watchKey(entry))].slice(0,30);
  try{localStorage.setItem(RECENT_KEY,JSON.stringify(state.recentViews))}catch{}
}
function applyTheme(theme){
  state.theme=theme==='light'?'light':'dark';document.documentElement.dataset.theme=state.theme;
  try{localStorage.setItem(THEME_KEY,state.theme)}catch{}
  const b=$('#themeToggle');if(b)b.classList.toggle('light-active',state.theme==='light');
}
function toggleTheme(){applyTheme(state.theme==='light'?'dark':'light')}
function setHeaderActive(view){
  $$('[data-header-view]').forEach(b=>b.classList.toggle('active',b.dataset.headerView===view));
}

function toast(message,type=''){
  const el=$('#toast'); el.textContent=message; el.className=`toast show ${type}`; clearTimeout(toast.t); toast.t=setTimeout(()=>el.className='toast',2600);
}
function setLoading(text='در حال دریافت اطلاعات…'){$('#view').innerHTML=`<div class="loading-screen"><div class="spinner"></div><p>${esc(text)}</p></div>`}
function feature(name, fallback=true){
  const desktop=state.config?.desktop?.features || {}; if(Object.prototype.hasOwnProperty.call(desktop,name)) return !!desktop[name];
  const common=state.config?.features || {}; if(Object.prototype.hasOwnProperty.call(common,name)) return !!common[name]; return fallback;
}
function archivePolicy(no){
  const key=`archive${Number(no)}`; const p=state.config?.app_archive_policy?.[key] || state.config?.archive_policy?.[key] || {};
  const d=state.config?.desktop?.archives?.[key] || {}; return {...p,...d};
}
function enabledArchives(){
  return [1,2,3,4,5].filter(n=>{const p=archivePolicy(n);return p.hidden!==true && p.enabled!==false});
}
function setActiveNav(view){
  if(view!=='home'&&state.heroTimer){clearInterval(state.heroTimer);state.heroTimer=null}
  state.lastView=view;document.body.classList.toggle('home-active',view==='home');setHeaderActive(view);
}
function img(url,alt='',cls=''){return cleanUrl(url)?`<img class="${cls}" src="${esc(url)}" alt="${esc(alt)}" loading="lazy" onerror="this.style.display='none'">`:''}
function itemTitle(it){return it?.title_fa || it?.title || 'بدون عنوان'}
function itemId(it){return it?.target_id || it?.detail_id || it?.id || it?.slug || it?.imdb_code || ''}
function itemRating(it){
  const values=[it?.rating,it?.imdb_rating,it?.imdb_score,it?.score];
  for(const value of values){
    const raw=String(value??'').trim();
    if(!raw)continue;
    const m=raw.replace(',', '.').match(/(?:^|\s)(10(?:\.0+)?|[0-9](?:\.\d+)?)(?:\s*\/\s*10)?(?:$|\s)/);
    if(m)return m[1];
  }
  const imdb=String(it?.imdb??'').trim();
  if(/^\d(?:\.\d+)?$/.test(imdb)||/^10(?:\.0+)?$/.test(imdb))return imdb;
  return '';
}
function card(it){
  const poster=cleanUrl(it.poster||it.image||'');const type=(it.type==='series'?'سریال':'فیلم');const rating=itemRating(it);
  const payload=encodeURIComponent(JSON.stringify({archive:it.archive||state.archive,id:itemId(it),type:it.type||'movie',title:it.title||'',title_fa:it.title_fa||'',poster:poster,year:it.year||'',rating:rating,source:it.source||'',imdb_code:it.imdb_code||''}));
  return `<article class="media-card" data-card='${payload}'>
    <div class="poster">${poster?img(poster,itemTitle(it)):`<div class="poster-fallback">BM</div>`}<span class="type-badge">${type}</span>${rating?`<span class="poster-imdb">${icon('imdb')}<b>${esc(rating)}</b></span>`:''}</div>
    <div class="card-info"><strong>${esc(itemTitle(it))}</strong><small><span>${esc(it.year||'')} · ${type}</span><span>${rating?'★ '+esc(rating):''}</span></small></div>
  </article>`;
}
function bindCards(root=document){
  $$('[data-card]',root).forEach(el=>el.addEventListener('click',()=>{try{openDetail(JSON.parse(decodeURIComponent(el.dataset.card)))}catch(e){toast(e.message,'error')}}));
}
function sectionLabel(section){return SECTION_LABELS[section]||String(section||'').replaceAll('_',' ')}
function sectionHtml(title,items,archive,section){
  if(!items?.length)return '';
  return `<section class="section archive-section" data-home-section="${esc(section)}"><div class="section-head"><div><h2>${esc(title)}</h2><small>${esc(ARCHIVE_NAMES[archive]||'')} • ${esc(ARCHIVE_DESCRIPTIONS[archive]||'')}</small></div><button class="link-btn" data-browse-section="${esc(section)}" data-archive="${archive}">مشاهده همه ‹</button></div><div class="rail">${items.map(card).join('')}</div></section>`;
}
function sectionPolicy(archive,section){
  const key=`archive${archive}`;return state.config?.home_section_policy?.[key]?.[section]||{};
}
function homeSectionsFor(archive){
  const key=`archive${archive}_sections`; const configured=state.config?.home?.[key];
  const raw=(Array.isArray(configured)&&configured.length)?configured:(ARCHIVE_FALLBACK_SECTIONS[archive]||[]);
  const aliases={dubbed_fa:'dubbed',animations:'animation'};
  const out=[];
  for(const value of raw){const sec=aliases[String(value)]||String(value);if(!sec||out.includes(sec))continue;const p=sectionPolicy(archive,sec);if(p.enabled===false||p.access_scope==='disabled')continue;out.push(sec)}
  return out;
}
function archiveSwitcherHtml(active=state.archive,context='home'){
  const archives=enabledArchives();
  return `<div class="archive-hub ${context==='search'?'search-archive-hub':''}"><div class="archive-hub-copy"><strong>${esc(ARCHIVE_NAMES[active])}</strong><span>${esc(ARCHIVE_DESCRIPTIONS[active]||'')}</span></div><div class="archive-tabs">${archives.map(n=>`<button class="archive-tab ${n===active?'active':''}" data-archive-switch="${n}" data-context="${context}"><b>${esc(ARCHIVE_NAMES[n])}</b></button>`).join('')}</div></div>`;
}
function archiveCategoryNavHtml(archive){
  const sections=homeSectionsFor(archive).filter(x=>x!=='collections');
  return sections.length?`<div class="archive-category-strip">${sections.map(sec=>`<button data-home-category="${esc(sec)}" data-archive="${archive}">${esc(sectionLabel(sec))}</button>`).join('')}</div>`:'';
}
function renderTopCategories(){
  const host=$('#topCategoryMenu');if(!host)return;
  const sections=homeSectionsFor(state.archive).filter(x=>x!=='collections').slice(0,9);
  host.innerHTML=`<button class="top-menu-item home-shortcut ${state.lastView==='home'?'active':''}" data-top-home>خانه</button>${sections.map(sec=>`<button class="top-menu-item" data-top-category="${esc(sec)}">${esc(sectionLabel(sec))}</button>`).join('')}`;
  const home=host.querySelector('[data-top-home]');if(home)home.onclick=()=>showHome(false);
  host.querySelectorAll('[data-top-category]').forEach(b=>b.onclick=()=>showBrowseSection(state.archive,b.dataset.topCategory));
}
async function switchArchive(next,context='home'){
  const n=Number(next);if(!enabledArchives().includes(n))return;state.archive=n;
  const sel=$('#archiveSelect');if(sel)sel.value=String(n);await bridge.setSettings({preferredArchive:n});updateSearchPlaceholder();renderTopCategories();
  if(context==='search'||state.lastView==='search')return showSearch($('#searchQuery')?.value||'');
  if(context==='categories'||state.lastView==='categories')return showCategories();
  if(context==='collections'||state.lastView==='collections')return showCollections();
  if(context==='boxoffice'||state.lastView==='boxoffice')return showBoxOffice();
  if(state.lastView==='movies'||state.lastView==='series')return showBrowse(state.lastView);
  return showHome(false);
}
function bindArchiveSwitcher(root=document){$$('[data-archive-switch]',root).forEach(b=>b.onclick=()=>switchArchive(b.dataset.archiveSwitch,b.dataset.context||'home'))}
function updateSearchPlaceholder(){const q=$('#quickSearch');if(q)q.placeholder=`جستجو در ${ARCHIVE_NAMES[state.archive]}…`}


async function init(){
  state.recentViews=loadRecentViews();state.theme=localStorage.getItem(THEME_KEY)||'dark';applyTheme(state.theme);
  hydrateStaticIcons();
  bindWindowButtons();
  try{
    const boot=await bridge.bootstrap(); state.config=boot.config||{}; state.settings=boot.settings||{}; state.players=boot.players||[]; state.appVersion=boot.version||''; state.archive=Number(state.settings.preferredArchive||enabledArchives()[0]||1);
    setupArchiveSelect(); applyRemoteNotice(); renderTopCategories(); bridge.onDownload(onDownloadUpdate);
    if(boot.hasToken) await refreshMe(false); await loadUserConfig(); updateProfile(); bindGlobalUI(); await showHome();
  }catch(e){setLoading('خطا در راه‌اندازی');toast(e.message||'خطای راه‌اندازی','error')}
}
function bindWindowButtons(){
  $$('[data-win]').forEach(b=>b.addEventListener('click',()=>{const a=b.dataset.win;if(a==='min')bridge.window.minimize();if(a==='max')bridge.window.maximize();if(a==='close')bridge.window.close()}));
}
function setupArchiveSelect(){
  const s=$('#archiveSelect');
  updateSearchPlaceholder();
  if(!s)return;
  s.innerHTML=enabledArchives().map(n=>`<option value="${n}" ${n===state.archive?'selected':''}>${ARCHIVE_NAMES[n]}</option>`).join('');
  s.onchange=()=>switchArchive(Number(s.value),state.lastView==='search'?'search':'home');
}
function applyRemoteNotice(){
  const n=state.config?.desktop?.notice || state.config?.notice || {}; const el=$('#notice');
  if(n.enabled && (n.message||n.title)){el.innerHTML=`<strong>${esc(n.title||'اطلاعیه')}</strong> ${esc(n.message||'')}`;el.classList.remove('hidden')} else el.classList.add('hidden');
}
async function loadUserConfig(){try{state.userConfig=await bridge.user('config',{},'POST')}catch{state.userConfig={features:{}}}}
async function refreshMe(noisy=true){
  try{
    const r=await bridge.user('me',{},'POST');
    if(r?.success){
      state.user=r.user;state.stats=r.stats||null;
      state.userConfig={...(state.userConfig||{}),features:r.features||state.userConfig?.features||{},vip:r.vip||state.userConfig?.vip||{}};
    }else state.user=null;
  }catch(e){state.user=null;if(noisy)toast(e.message,'error')}
  updateProfile();return state.user;
}
function updateProfile(){
  const name=$('#profileName'),hint=$('#profileHint'),av=$('#profileAvatar');
  if(state.user){
    name.textContent=state.user.full_name||state.user.username||'کاربر';
    const days=Number(state.user.vip_remaining_days||0);
    hint.textContent=state.user.is_vip?(state.user.vip_lifetime?'VIP مادام‌العمر':(days>0?`VIP • ${days.toLocaleString('fa-IR')} روز باقی‌مانده`:'VIP فعال')):(state.user.email||'حساب کاربری');
    av.innerHTML=cleanUrl(state.user.avatar)?img(state.user.avatar,'avatar'):esc((state.user.username||'BM').slice(0,2).toUpperCase())
  } else {name.textContent='حساب کاربری';hint.textContent='ورود / ثبت‌نام';av.innerHTML=ICONS.user}
  const vipBtn=$('#vipHeader'),vipTitle=$('#vipHeaderTitle'),vipHint=$('#vipHeaderHint');
  if(vipBtn&&vipTitle&&vipHint){
    const active=!!state.user?.is_vip,days=Number(state.user?.vip_remaining_days||0);
    vipBtn.classList.toggle('active-vip',active);
    vipTitle.textContent=active?'اشتراک فعال':'خرید اشتراک';
    vipHint.textContent=active?(state.user?.vip_lifetime?'VIP مادام‌العمر':(days>0?`${days.toLocaleString('fa-IR')} روز باقی‌مانده`:'BankMovie VIP')):'BankMovie VIP';
  }
}
function bindGlobalUI(){
  $('#headerHome').onclick=()=>route('home');
  $$('[data-header-view]').forEach(b=>b.onclick=()=>route(b.dataset.headerView));
  $('#profileNav').onclick=()=>showProfile();
  $('#vipHeader').onclick=()=>state.user?.is_vip?showProfile():showVipPlansModal();
  $('#downloadsHeader').onclick=()=>route('downloads');
  $('#watchlistHeader').onclick=()=>route('watchlist');
  $('#notificationsHeader').onclick=()=>route('notifications');
  $('#themeToggle').onclick=toggleTheme;
  const toggleFullscreen=async()=>{
    try{
      const active=await bridge.window.toggleFullscreen();
      document.body.classList.toggle('fullscreen-mode',!!active);
      $('#fullscreenBtn')?.classList.toggle('active',!!active);
    }catch(e){toast(e.message||String(e),'error')}
  };
  $('#fullscreenBtn').onclick=toggleFullscreen;
  bridge.window.onFullscreenState?.(active=>{document.body.classList.toggle('fullscreen-mode',!!active);$('#fullscreenBtn')?.classList.toggle('active',!!active)});
  const form=$('#headerSearchForm'),input=$('#headerSearchInput');
  form.onsubmit=e=>{e.preventDefault();const q=input.value.trim();showSearch(q)};
  document.addEventListener('keydown',e=>{
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();input.focus();input.select()}
    if(e.key==='F11'){e.preventDefault();toggleFullscreen()}
  });
  $('#modal').addEventListener('click',e=>{if(e.target.matches('[data-close-modal]'))closeModal()});
  const scroller=$('#mainScroller');scroller.addEventListener('scroll',()=>document.body.classList.toggle('header-scrolled',scroller.scrollTop>36));
}
async function route(view,force=false){
  setActiveNav(view);if(view==='home')return showHome(force);if(view==='search')return showSearch('');
  if(view==='categories')return showCategories();if(view==='collections')return showCollections();if(view==='boxoffice')return showBoxOffice();
  if(view==='watchlist')return showWatchlist();if(view==='downloads')return showDownloads();if(view==='notifications')return showNotifications();if(view==='settings')return showSettings();if(view==='profile')return showProfile();
}

async function loadHomeSection(archive,section){
  if(section==='collections'){
    try{const r=await bridge.content('collections',{archive,page:1,limit:14});return {a:archive,sec:section,items:r.items||[]}}catch{return {a:archive,sec:section,items:[]}}
  }
  try{const r=await bridge.content('section',{archive,section,page:1,limit:14});return {a:archive,sec:section,items:r.items||[]}}catch{return {a:archive,sec:section,items:[]}}
}
async function showHome(force=false){
  setActiveNav('home'); setLoading(`در حال بارگذاری ${ARCHIVE_NAMES[state.archive]}…`);
  try{
    const cacheKey=String(state.archive);
    if(force)delete state.homeCache[cacheKey];
    if(!state.homeCache[cacheKey]){
      const boot=await bridge.content('boot',{limit:18});
      const sections=homeSectionsFor(state.archive);
      const rails=(await Promise.all(sections.map(sec=>loadHomeSection(state.archive,sec)))).filter(r=>r.items?.length);
      state.homeCache[cacheKey]={boot,rails,archive:state.archive,sections};
    }
    renderHome(state.homeCache[cacheKey]);
  }catch(e){$('#view').innerHTML=`<div class="empty">${esc(e.message)}</div>`;toast(e.message,'error')}
}
function sliderMediaItem(it){
  const out={...it,archive:Number(it?.target_archive||it?.archive||2)||2,id:it?.target_id||'',type:it?.target_type||it?.type||'movie',poster:it?.poster||it?.image||''};
  const raw=String(it?.link_abs||it?.link||'').trim();
  if(raw){
    try{
      const u=new URL(raw,'https://bankmovie.top');
      const arc=Number(u.searchParams.get('arc')||0);if(arc>=1&&arc<=5)out.archive=arc;
      const type=u.searchParams.get('type');if(type)out.type=/series|serial|tv/i.test(type)?'series':'movie';
      const qid=u.searchParams.get('slug')||u.searchParams.get('imdb');if(qid)out.id=qid;
      const p=decodeURIComponent(u.pathname||'');
      const am=p.match(/\/movie\/arc([1-5])-([^/?#]+)/i);if(am){out.archive=Number(am[1]);out.id=am[2]}
      else {const pm=p.match(/\/movie\/([^/?#]+)/i);if(pm){out.archive=2;out.id=pm[1]}}
    }catch{}
  }
  if(!out.id)out.id=it?.id||'';
  return out;
}
function heroSlide(hero,i){
  const bg=cleanUrl(hero.backdrop||hero.background||hero.image||hero.poster||'');const rating=itemRating(hero);
  const year=hero.year?`<span>${esc(hero.year)}</span>`:'';
  return `<div class="hero-slide ${i===0?'active':''}" data-hero-slide="${i}">${bg?`<div class="hero-bg" style="background-image:url('${esc(bg)}')"></div>`:''}<div class="hero-center" dir="rtl"><div class="hero-copy-meta">${rating?`<span class="hero-rating">${icon('imdb','imdb-mark')}<b>${esc(rating)}</b></span>`:''}${year}</div><h1>${esc(itemTitle(hero))}</h1>${hero.subtitle_fa?`<p>${esc(hero.subtitle_fa)}</p>`:(hero.title&&hero.title!==itemTitle(hero)?`<p>${esc(hero.title)}</p>`:'')}<div class="hero-actions"><button class="btn hero-watch" data-hero-open="${i}">${icon('play')}<span>مشاهده</span></button></div></div></div>`;
}
function activateHero(index,sliders){
  if(!sliders.length)return;state.heroIndex=(index+sliders.length)%sliders.length;
  $$('[data-hero-slide]').forEach((el,i)=>el.classList.toggle('active',i===state.heroIndex));
  $$('[data-hero-dot]').forEach((el,i)=>el.classList.toggle('active',i===state.heroIndex));
  $$('[data-hero-thumb]').forEach((el,i)=>el.classList.toggle('active',i===state.heroIndex));
}
function bindHeroSlider(sliders){
  if(state.heroTimer){clearInterval(state.heroTimer);state.heroTimer=null}state.heroIndex=0;activateHero(0,sliders);
  $$('[data-hero-open]').forEach(b=>b.onclick=async()=>{
    const raw=sliders[Number(b.dataset.heroOpen)];const target=sliderMediaItem(raw);
    if(target.id)return openDetail(target);
    const link=cleanUrl(raw?.link_abs||raw?.link||'');
    if(link)return bridge.openExternal(link);
    toast('برای این اسلاید مقصدی ثبت نشده است','error');
  });
  $$('[data-hero-dot]').forEach(b=>b.onclick=()=>activateHero(Number(b.dataset.heroDot),sliders));
  $$('[data-hero-thumb]').forEach(b=>b.onclick=()=>activateHero(Number(b.dataset.heroThumb),sliders));
  const prev=$('#heroPrev'),next=$('#heroNext');if(prev)prev.onclick=()=>activateHero(state.heroIndex-1,sliders);if(next)next.onclick=()=>activateHero(state.heroIndex+1,sliders);
  if(sliders.length>1)state.heroTimer=setInterval(()=>{if(state.lastView==='home')activateHero(state.heroIndex+1,sliders)},6500);
}
function renderHome({boot,rails,archive,sections}){
  const active=Number(archive||state.archive);
  const sliders=(Array.isArray(boot?.sliders)?boot.sliders:[]).slice().sort((a,b)=>Number(a?.order??a?.slide_order??0)-Number(b?.order??b?.slide_order??0)).slice(0,12);
  const thumbs=sliders.map((x,i)=>{const poster=cleanUrl(x.poster||x.thumb||x.image||x.backdrop||'');return `<button class="hero-thumb ${i===0?'active':''}" data-hero-thumb="${i}" aria-label="${esc(itemTitle(x))}">${poster?`<img src="${esc(poster)}" alt="${esc(itemTitle(x))}">`:`<span>BM</span>`}</button>`}).join('');
  const hero=sliders.length?`<section class="hero site-hero" dir="ltr"><div class="hero-stage">${sliders.map(heroSlide).join('')}</div>${sliders.length>1?`<button class="hero-arrow prev" id="heroPrev" aria-label="اسلاید قبلی">${icon('back')}</button><button class="hero-arrow next" id="heroNext" aria-label="اسلاید بعدی">${icon('back')}</button><div class="hero-thumbnails">${thumbs}</div><div class="hero-dots">${sliders.map((_,i)=>`<button class="hero-dot ${i===0?'active':''}" data-hero-dot="${i}"></button>`).join('')}</div>`:''}</section>`:'';
  $('#view').innerHTML=`${hero}<div class="home-content">${archiveSwitcherHtml(active,'home')}${archiveCategoryNavHtml(active)}${rails.map(r=>sectionHtml(sectionLabel(r.sec),r.items,active,r.sec)).join('')}</div>`;
  if(sliders.length)bindHeroSlider(sliders);bindCards();bindArchiveSwitcher();renderTopCategories();
  $$('[data-home-category]').forEach(b=>b.onclick=()=>showBrowseSection(Number(b.dataset.archive),b.dataset.homeCategory));
  $$('[data-browse-section]').forEach(b=>b.onclick=()=>showBrowseSection(Number(b.dataset.archive),b.dataset.browseSection));
}


async function showBrowse(kind='movies'){
  setActiveNav(kind);setLoading();const type=kind==='series'?'series':'movie';const sec=type==='series'?(state.archive<=2?'updated_series':'new_series'):(state.archive<=2?'updated_movies':'new_movies');
  try{const r=await bridge.content('section',{archive:state.archive,section:sec,page:1,limit:48});renderGridPage(kind==='series'?'سریال‌ها':'فیلم‌ها',`${ARCHIVE_NAMES[state.archive]} • ${sectionLabel(sec)}`,r.items||[])}catch(e){renderError(e)}
}
async function showBrowseSection(archive,section){
  state.archive=archive;const archiveSelect=$('#archiveSelect');if(archiveSelect)archiveSelect.value=String(archive);bridge.setSettings({preferredArchive:archive});updateSearchPlaceholder();renderTopCategories();setActiveNav(section.includes('series')?'series':'movies');setLoading();
  try{const r=await bridge.content('section',{archive,section,page:1,limit:60});renderGridPage(sectionLabel(section),ARCHIVE_NAMES[archive],r.items||[])}catch(e){renderError(e)}
}
function renderGridPage(title,sub,items){$('#view').innerHTML=`<div class="page-title"><div><h1>${esc(title)}</h1><p>${esc(sub)}</p></div><span class="chip">${items.length} عنوان</span></div>${items.length?`<div class="grid">${items.map(card).join('')}</div>`:'<div class="empty">موردی پیدا نشد.</div>'}`;bindCards()}

async function showCategories(){
  setActiveNav('categories');const sections=homeSectionsFor(state.archive).filter(x=>x!=='collections');
  $('#view').innerHTML=`<div class="page-shell"><div class="page-title"><div><h1>دسته‌بندی‌ها</h1><p>${esc(ARCHIVE_NAMES[state.archive])} • انتخاب دسته برای نمایش محتوای همان آرشیو</p></div></div>${archiveSwitcherHtml(state.archive,'categories')}<div class="category-grid">${sections.map(sec=>`<button class="category-tile" data-category-open="${esc(sec)}"><strong>${esc(sectionLabel(sec))}</strong><span>${esc(ARCHIVE_NAMES[state.archive])}</span></button>`).join('')}</div></div>`;
  bindArchiveSwitcher();$$('[data-category-open]').forEach(b=>b.onclick=()=>showBrowseSection(state.archive,b.dataset.categoryOpen));
}
async function showCollections(){
  setActiveNav('collections');setLoading('در حال دریافت کالکشن‌ها…');
  try{const r=await bridge.content('collections',{archive:state.archive,page:1,limit:60});renderGridPage('کالکشن‌ها',ARCHIVE_NAMES[state.archive],r.items||[])}catch(e){renderError(e)}
}
async function showBoxOffice(){
  setActiveNav('boxoffice');setLoading('در حال دریافت عناوین برتر…');
  const candidates=['top_2026','top_movies','updated_movies'];let last=null;
  for(const section of candidates){try{const r=await bridge.content('section',{archive:state.archive,section,page:1,limit:60});const items=r.items||[];if(items.length){renderGridPage('باکس آفیس و برترین‌ها',`${ARCHIVE_NAMES[state.archive]} • ${sectionLabel(section)}`,items);return}}catch(e){last=e}}
  if(last)renderError(last);else renderGridPage('باکس آفیس','موردی پیدا نشد',[])
}

async function showSearch(initial=''){
  setActiveNav('search');
  const sections=homeSectionsFor(state.archive).filter(x=>x!=='collections');
  $('#view').innerHTML=`<div class="search-page">${archiveSwitcherHtml(state.archive,'search')}<section class="search-hero-panel"><span class="search-badge">جستجوی سریع</span><h1>فیلم و سریال را در ${esc(ARCHIVE_NAMES[state.archive])} پیدا کن</h1><p>نتایج فقط از همین آرشیو دریافت می‌شوند؛ برای منبع دیگر، آرشیو را از بالا تغییر بده.</p><form id="searchForm" class="site-search-form"><div class="site-search-input">${icon('search','search-field-icon')}<input id="searchQuery" name="q" autocomplete="off" placeholder="جستجو در ${esc(ARCHIVE_NAMES[state.archive])}…" value="${esc(initial)}"><button class="site-search-button">${icon('search')}<span>جستجو</span></button></div><div class="advanced-search-title">${icon('filter')}<span>فیلترهای پیشرفته</span></div><div class="advanced-search-row"><select name="type"><option value="">فیلم و سریال</option><option value="movie">فقط فیلم</option><option value="series">فقط سریال</option></select><input name="genre" placeholder="ژانر (اختیاری)"><input name="country" placeholder="کشور (اختیاری)"></div><input type="hidden" name="archive" value="${state.archive}"></form><div class="search-category-links">${sections.map(sec=>`<button type="button" data-search-category="${esc(sec)}">${esc(sectionLabel(sec))}</button>`).join('')}</div></section><div id="searchResults"><div class="empty search-empty">عبارت جستجو را وارد کن؛ نتیجه‌ها فقط از ${esc(ARCHIVE_NAMES[state.archive])} نمایش داده می‌شوند.</div></div></div>`;
  bindArchiveSwitcher();
  $$('[data-search-category]').forEach(b=>b.onclick=()=>showBrowseSection(state.archive,b.dataset.searchCategory));
  const f=$('#searchForm');f.onsubmit=async e=>{e.preventDefault();await performSearch(new FormData(f))};if(initial)performSearch(new FormData(f));
}
async function performSearch(fd){
  const out=$('#searchResults');out.innerHTML=searchLoaderHtml('در حال جستجو');
  const p=Object.fromEntries(fd.entries());p.archive=state.archive;p.page=1;p.limit=60;
  try{const r=await bridge.content('search',p);const items=r.items||r.results||[];out.innerHTML=items.length?`<div class="search-result-head"><div><strong>نتایج ${esc(ARCHIVE_NAMES[state.archive])}</strong><small>${items.length} عنوان پیدا شد</small></div></div><div class="grid">${items.map(card).join('')}</div>`:`<div class="empty">در ${esc(ARCHIVE_NAMES[state.archive])} نتیجه‌ای پیدا نشد.</div>`;bindCards(out)}catch(e){out.innerHTML=`<div class="empty">${esc(e.message)}</div>`}
}

async function openDetail(item){
  setLoading('در حال دریافت جزئیات…');
  try{
    const r=await bridge.content('detail',{archive:item.target_archive||item.archive||state.archive,id:itemId(item),type:item.target_type||item.type||''});
    const detail=r.item||r;state.currentDetail={...item,...detail,archive:Number(detail?.archive||item.target_archive||item.archive||state.archive)||state.archive};state.detailSeason=null;state.detailEpisode=null;state.visibleSources=[];
    rememberRecentView(state.currentDetail);commentsCache=[];bm19CommentsLoadedKey='';renderDetail(state.currentDetail);
  }catch(e){renderError(e)}
}
function sourceTypeLabel(s){
  if(s?.type_fa)return s.type_fa;
  const t=String(s?.type||'').toLowerCase();
  if(t==='dub')return 'دوبله فارسی';if(t==='softsub')return 'سافت‌ساب';if(t==='hardsub')return 'هاردساب';if(t==='subtitle')return 'زیرنویس';if(t==='audio')return 'صوت دوبله';if(t==='nosub')return 'بدون زیرنویس';return 'نسخه رسانه';
}
function subtitleUrlOf(s){return cleanUrl(s?.subtitle_url||s?.subtitleUrl||s?.subtitle||s?.sub_url||s?.subtitle_link||'')}
function trailerUrlOf(d){return cleanUrl(d?.trailer_url||d?.trailer||d?.trailerUrl||d?.video_trailer||d?.trailer_link||'')}
function seriesStructure(d,links){
  const map=new Map();
  const flat=dedupeSources(links);
  if(flat.length){
    for(const l of flat){
      const sn=Number(l.season||1)||1,en=Number(l.episode||0)||0;
      if(!map.has(sn))map.set(sn,new Map());const eps=map.get(sn);if(!eps.has(en))eps.set(en,[]);eps.get(en).push(l);
    }
  }else{
    const apiSeasons=Array.isArray(d?.play?.seasons)?d.play.seasons:[];
    for(const sx of apiSeasons){
      const sn=Number(sx.season||1)||1;if(!map.has(sn))map.set(sn,new Map());const eps=map.get(sn);
      for(const ex of (Array.isArray(sx.episodes)?sx.episodes:[])){const en=Number(ex.episode||0)||0;if(!eps.has(en))eps.set(en,[]);eps.get(en).push(...(Array.isArray(ex.links)?ex.links:[]))}
    }
  }
  const epRank=n=>n===0?999999:n;
  return [...map.entries()].sort((a,b)=>a[0]-b[0]).map(([season,eps])=>({season,episodes:[...eps.entries()].sort((a,b)=>epRank(a[0])-epRank(b[0])).map(([episode,ls])=>({episode,links:ls}))}));
}
function sourceRow(s,i,series=false){
  const sub=subtitleUrlOf(s);const label=sourceTypeLabel(s);const playable=s.is_playable!==false&&!!s.url&&!s.is_folder;const downloadable=s.is_download!==false&&!!s.url;
  const t=String(s?.type||'').toLowerCase();const isDub=/dub|audio/.test(t)||/دوبله|صوت/.test(label);const hasSub=sub||/softsub|hardsub|subtitle/.test(t)||/زیرنویس|ساب/.test(label);
  const kindIcon=isDub?icon('mic','source-kind-icon'):hasSub?icon('subtitle','source-kind-icon'):'';
  const meta=[s.size||'',sub&&!/سافت|هارد|زیرنویس|ساب/.test(label)?'زیرنویس جداگانه':'',s.is_folder?'پوشه':''].filter(Boolean).join(' • ');
  return `<div class="source-row"><div class="source-main"><span class="quality">${esc(s.quality||'AUTO')}</span><span><strong>${kindIcon}${esc(label)}</strong>${meta?`<small>${esc(meta)}</small>`:''}</span></div><div class="source-actions">${playable?`<button class="btn ghost slim" data-${series?'series-':''}source-play="${i}">${icon('play')}<span>پخش</span></button>`:''}${downloadable?`<button class="btn primary slim" data-${series?'series-':''}source-download="${i}">${icon('download')}<span>دانلود</span></button>`:''}</div></div>`;
}
function renderSeriesSources(d,links){
  const seasons=seriesStructure(d,links);if(!seasons.length)return '<div class="empty">قسمتی برای این سریال ثبت نشده است.</div>';
  if(!seasons.some(x=>x.season===Number(state.detailSeason)))state.detailSeason=seasons[0].season;
  const season=seasons.find(x=>x.season===Number(state.detailSeason))||seasons[0];
  if(!season.episodes.some(x=>x.episode===Number(state.detailEpisode)))state.detailEpisode=season.episodes[0]?.episode??0;
  const episode=season.episodes.find(x=>x.episode===Number(state.detailEpisode))||season.episodes[0];
  state.visibleSources=episode?.links||[];
  const seasonTabs=seasons.map(x=>`<button class="season-tab ${x.season===season.season?'active':''}" data-season="${x.season}">فصل ${x.season}</button>`).join('');
  const episodeTabs=season.episodes.map(x=>`<button class="episode-pill ${x.episode===episode?.episode?'active':''}" data-episode="${x.episode}">${x.episode>0?x.episode:'ویژه'}</button>`).join('');
  const rows=state.visibleSources.length?state.visibleSources.map((s,i)=>sourceRow(s,i,true)).join(''):'<div class="empty">برای این قسمت کیفیتی ثبت نشده است.</div>';
  return `<div class="series-sources"><div class="series-picker"><div><span class="picker-label">فصل</span><div class="season-tabs">${seasonTabs}</div></div><div><span class="picker-label">قسمت</span><div class="episode-tabs">${episodeTabs}</div></div></div><div class="episode-heading"><strong>فصل ${season.season} • ${episode?.episode>0?`قسمت ${episode.episode}`:'قسمت ویژه'}</strong><small>کیفیت، دوبله و زیرنویس فقط مربوط به همین قسمت هستند.</small></div><div class="sources">${rows}</div></div>`;
}
function renderDetail(d){
  const bg=cleanUrl(d.backdrop||d.background||d.poster||'');const poster=cleanUrl(d.poster||'');const links=dedupeSources(d.play?.links||d.downloads||d.links||[]);const related=d.related||[];
  const inList=state.watchlist.some(w=>watchKey(w)===watchKey(d));
  $('#view').innerHTML=`<div class="detail"><section class="detail-hero">${bg?`<div class="detail-bg" style="background-image:url('${esc(bg)}')"></div>`:''}<div class="detail-inner"><div class="detail-copy"><div class="eyebrow">${esc(ARCHIVE_NAMES[d.archive]||'BANKMOVIE')}</div><h1 class="detail-title">${esc(itemTitle(d))}</h1><div class="meta"><span class="chip imdb-detail-chip">${icon('imdb','imdb-detail-icon')}<b>${esc(itemRating(d)||'—')}</b></span><span class="chip">${esc(d.year||'')}</span><span class="chip">${d.type==='series'?'سریال':'فیلم'}</span>${(d.genres||[]).slice(0,3).map(g=>`<span class="chip">${esc(typeof g==='string'?g:(g.name||g.title||''))}</span>`).join('')}</div><p class="description">${esc(d.long_description||d.description||'توضیحی ثبت نشده است.')}</p><div class="actions"><button class="btn red" id="playBest">${icon('play')}<span>پخش</span></button><button class="btn ghost" id="watchBtn">${icon('bookmark')}<span>${inList?'حذف از لیست':'افزودن به لیست'}</span></button>${trailerUrlOf(d)?'<button class="btn trailer-cta" id="trailerBtn">'+icon('play')+'<span>مشاهده تریلر</span></button>':''}</div></div>${poster?`<img class="detail-poster" src="${esc(poster)}">`:''}</div></section><div class="detail-body"><div class="tabs"><button class="tab active" data-detail-tab="sources">پخش و دانلود</button><button class="tab" data-detail-tab="comments">دیدگاه‌ها</button><button class="tab" data-detail-tab="info">اطلاعات</button></div><div id="detailTab">${renderSources(d,links)}</div>${related.length?`<section class="section"><div class="section-head"><h2>پیشنهادهای مشابه</h2></div><div class="rail">${related.map(card).join('')}</div></section>`:''}</div></div>`;
  bindCards();$('#watchBtn').onclick=()=>quickWatchlist(d,true);if($('#trailerBtn'))$('#trailerBtn').onclick=()=>bridge.openExternal(d.trailer_url);
  bindSourceButtons(d,links);
  $('#playBest').onclick=()=>{const pool=state.visibleSources?.length?state.visibleSources:links;const s=pool.find(x=>x.is_playable!==false&&x.url&&!x.is_folder)||pool.find(x=>x.url&&!x.is_folder);s?playSource(s):toast('لینک پخش موجود نیست','error')};
  $$('[data-detail-tab]').forEach(t=>t.onclick=()=>switchDetailTab(t.dataset.detailTab,d,links,t));
}
function dedupeSources(links){
  const seen=new Set(),out=[];
  for(const s of (Array.isArray(links)?links:[])){
    const key=[
      Number(s?.season||0)||0,Number(s?.episode||0)||0,
      String(s?.quality||'').trim().toLowerCase(),
      String(s?.type||s?.type_fa||'').trim().toLowerCase(),
      String(s?.url||'').trim(),subtitleUrlOf(s)
    ].join('|');
    if(seen.has(key))continue;
    seen.add(key);out.push(s);
  }
  return out;
}
function renderSources(d,links){
  links=dedupeSources(links);
  if(!links.length)return '<div class="empty">برای این عنوان لینک پخش یا دانلودی موجود نیست.</div>';
  if(d.type==='series'||d.type==='tv'||d.play?.has_series_structure)return renderSeriesSources(d,links);
  state.visibleSources=links;
  return `<div class="sources">${links.map((s,i)=>sourceRow(s,i,false)).join('')}</div>`;
}
function rerenderSources(d,links){const box=$('#detailTab');if(!box)return;box.innerHTML=renderSources(d,links);bindSourceButtons(d,links)}
function switchDetailTab(name,d,links,tab){$$('[data-detail-tab]').forEach(x=>x.classList.remove('active'));tab.classList.add('active');const box=$('#detailTab');if(name==='sources'){box.innerHTML=renderSources(d,links);bindSourceButtons(d,links)}if(name==='comments')renderCommentsBox(d);if(name==='info')box.innerHTML=renderInfo(d)}
function bindSourceButtons(d,links){
  $$('[data-source-play]').forEach(b=>b.onclick=()=>playSource(links[Number(b.dataset.sourcePlay)]));
  $$('[data-source-download]').forEach(b=>b.onclick=()=>downloadSource(links[Number(b.dataset.sourceDownload)],d));
  $$('[data-series-source-play]').forEach(b=>b.onclick=()=>playSource(state.visibleSources[Number(b.dataset.seriesSourcePlay)]));
  $$('[data-series-source-download]').forEach(b=>b.onclick=()=>downloadSource(state.visibleSources[Number(b.dataset.seriesSourceDownload)],d));
  $$('[data-season]').forEach(b=>b.onclick=()=>{state.detailSeason=Number(b.dataset.season);state.detailEpisode=null;rerenderSources(d,links)});
  $$('[data-episode]').forEach(b=>b.onclick=()=>{state.detailEpisode=Number(b.dataset.episode);rerenderSources(d,links)});
}
const BM199_INFO_ICONS={
  year:`<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M3 10C3 8.11438 3 7.17157 3.58579 6.58579C4.17157 6 5.11438 6 7 6H17C18.8856 6 19.8284 6 20.4142 6.58579C21 7.17157 21 8.11438 21 10H3Z" fill="currentColor" opacity=".22"/><rect x="3" y="6" width="18" height="15" rx="2" stroke="currentColor" stroke-width="1.2"/><path d="M7 3V6M17 3V6" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/><rect x="7" y="12" width="4" height="2" rx=".5" fill="currentColor"/><rect x="7" y="16" width="4" height="2" rx=".5" fill="currentColor"/><rect x="13" y="12" width="4" height="2" rx=".5" fill="currentColor"/><rect x="13" y="16" width="4" height="2" rx=".5" fill="currentColor"/></svg>`,
  country:`<svg viewBox="0 0 433.654 433.654" aria-hidden="true"><path fill="currentColor" d="M394.264 80.435c0-18.813-15.307-34.119-34.121-34.119-18.813 0-34.118 15.306-34.118 34.119s15.306 34.119 34.118 34.119c18.814 0 34.121-15.306 34.121-34.119zm-50.24 0c0-8.888 7.23-16.119 16.118-16.119 8.89 0 16.121 7.231 16.121 16.119s-7.231 16.119-16.121 16.119c-8.887 0-16.118-7.231-16.118-16.119zm-8.378 119.343c3.546 7.438 8.904 18.677 24.496 18.677 15.591 0 20.95-11.237 24.496-18.672.46-.963 9.37-18.556 9.37-18.556 19.182-37.698 39.646-79.686 39.646-100.792 0-40.533-32.978-73.51-73.512-73.51-40.533 0-73.509 32.977-73.509 73.51 0 21.11 20.463 63.096 39.644 100.792 0 0 8.911 17.589 9.369 18.551zm24.497-174.853c30.609 0 55.512 24.901 55.512 55.51 0 18.559-25.455 68.587-37.688 92.63 0 0-9.058 17.887-9.574 18.969-3.603 7.555-4.451 8.421-8.249 8.421-3.797 0-4.646-.866-8.248-8.423-.516-1.081-9.574-18.968-9.574-18.968-12.232-24.041-37.687-74.067-37.687-92.629-.001-30.609 24.9-55.51 55.508-55.51zM396.063 215.199c-4.971 0-9 4.029-9 9 0 14.65-1.715 28.902-4.957 42.576-35.125 7.549-71.319 12.826-108.217 15.79 1.415-18.803 2.153-38.386 2.153-58.365 0-17.28-.552-34.257-1.616-50.697 2.841-.258 5.671-.531 8.495-.82 4.944-.505 8.544-4.923 8.038-9.868-.506-4.944-4.927-8.552-9.868-8.038-2.676.273-5.358.532-8.05.778-3.813-42.447-11.128-80.407-21.214-109.229 3.542.979 7.057 2.066 10.54 3.26 4.703 1.608 9.819-.895 11.432-5.598 1.61-4.702-.896-9.82-5.598-11.431-21.089-7.225-43.184-10.888-65.67-10.888-12.242 0-24.231 1.091-35.881 3.183-.263.036-.524.083-.783.142C99.31 37.211 44.026 82.084 17.293 142.322c-.279.499-.514 1.03-.698 1.591C5.921 168.54 0 195.693 0 224.199c0 17.981 2.356 35.425 6.775 52.035.067.316.15.627.25.933 20.215 74.53 82.014 132.135 158.839 146.238.26.059.523.107.788.143 11.649 2.091 23.637 3.182 35.878 3.182s24.236-1.092 35.886-3.184c.259-.036.515-.082.769-.14 76.831-14.104 138.646-71.721 158.857-146.26.095-.292.175-.59.239-.892 4.422-16.615 6.78-34.067 6.78-52.055.002-4.971-4.028-9-8.998-9zM258.042 224.199c0 20.49-.784 40.515-2.283 59.632-17.608 1.047-35.366 1.573-53.228 1.573-17.862 0-35.62-.526-53.229-1.573-1.499-19.117-2.283-39.143-2.283-59.632 0-16.811.528-33.313 1.545-49.254 17.733 1.188 35.732 1.783 53.966 1.783 18.072 0 36.136-.607 53.964-1.809 1.02 15.949 1.548 32.458 1.548 49.28zM174.181 41.842c9.244-1.431 18.711-2.174 28.35-2.174 9.545 0 19.013.724 28.343 2.162 11.675 28.187 20.096 68.747 24.248 115.142-17.373 1.167-34.975 1.757-52.591 1.757-17.771 0-35.319-.579-52.593-1.731 4.15-46.398 12.57-86.962 24.243-115.156zM153.223 46.356c-10.081 28.826-17.395 66.791-21.205 109.23-32.429-2.945-63.84-7.952-93.971-14.99 23.27-45.591 64.954-80.297 115.176-94.24zm-13.862 301.363c-23.089-11.856-42.442-29.997-55.783-52.151 16.243 2.178 32.654 3.905 49.198 5.177 1.674 16.497 3.883 32.245 6.585 46.974zM18 224.199c0-23.575 4.446-46.137 12.54-66.881 32.056 7.671 65.524 13.088 100.095 16.217-1.063 16.426-1.614 33.4-1.614 50.665 0 19.978.738 39.563 2.153 58.365-19.333-1.553-38.469-3.74-57.362-6.557-6.469-16.015-10.032-33.503-10.032-51.808 0-4.971-4.029-9-9-9s-9 4.029-9 9c0 16.924 2.697 33.233 7.682 48.514-10.249-1.792-20.421-3.771-30.504-5.938C19.715 253.101 18 238.849 18 224.199zm10.778 62.177c10.771 2.18 21.627 4.15 32.575 5.914 16.912 34.927 46.402 62.662 82.559 77.291 2.763 11.759 5.876 22.638 9.311 32.46-57.83-16.055-104.332-59.626-124.445-115.665zm202.102 120.18c-9.244 1.431-18.71 2.174-28.349 2.174s-19.106-.743-28.35-2.174c-3.705-8.949-7.082-19.142-10.099-30.375 12.308 3.116 25.186 4.77 38.449 4.77 4.971 0 9-4.029 9-9s-4.029-9-9-9c-15.092 0-29.626-2.421-43.24-6.897-3.481-16.549-6.283-34.75-8.325-54.096 34.137 1.926 68.992 1.926 103.129 0-1.931 41.981-9.937 78.566-20.715 104.598zm20.959-4.514c9.449-27.018 16.467-62.06 20.446-101.296 35.386-2.72 70.15-7.521 103.999-14.369-20.112 56.038-66.615 99.609-124.445 115.665z"/></svg>`,
  language:`<svg viewBox="0 0 22 22" fill="none" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M5 2V1C5 .44772 5.44771 0 6 0s1 .44772 1 1v1h1.9828A1 1 0 0 1 9.0147 2H11a1 1 0 1 1 0 2H9.8447C9.3486 6.53262 8.2812 8.87025 6.65107 11.0085c1.06908 1.1855 2.35593 2.2294 3.86353 3.134a1 1 0 0 1-1.029 1.715c-1.5922-.9553-2.97206-2.0593-4.13691-3.3101-1.07723 1.1531-2.33355 2.2421-3.76745 3.2663a1 1 0 1 1-1.16248-1.6274c1.40923-1.0066 2.62388-2.0716 3.64584-3.1959C3.25727 9.8802 2.59248 8.67348 2.07164 7.37139a1 1 0 0 1 1.85695-.74278c.39021.97551.87152 1.88989 1.44481 2.74369C6.56501 7.70225 7.37246 5.9124 7.80118 4H1a1 1 0 1 1 0-2h4zm13.3901 15h-4.7802l-1.6766 4.359a1 1 0 1 1-1.8666-.718l5-13a1 1 0 0 1 1.8666 0l5 13a1 1 0 1 1-1.8666.718L18.3901 17zm-.7692-2L16 10.7857 14.3791 15h3.2418z" fill="currentColor"/></svg>`,
  runtime:`<svg viewBox="0 0 512 512" aria-hidden="true"><path fill="currentColor" d="M256 0C114.6 0 0 114.6 0 256s114.6 256 256 256c141.4 0 256-114.6 256-256S397.4 0 256 0zm0 469.3C138.2 469.3 42.7 373.8 42.7 256 42.7 138.2 138.2 42.7 256 42.7c117.8 0 213.3 95.5 213.3 213.3 0 117.8-95.5 213.3-213.3 213.3zm-21.3-234.6L149.3 320l32 32 96-96V85.3h-42.7v149.4z"/></svg>`
};

function renderInfo(d){
  const en=(state.language||bm191Language)==='en';
  const country=Array.isArray(d.country)?d.country.join(en?', ': '، '):(d.country||'—');
  const info=[
    ['year',en?'Year':'سال',d.year||'—'],
    ['country',en?'Country':'کشور',country],
    ['language',en?'Language':'زبان',d.language||'—'],
    ['runtime',en?'Runtime':'مدت',d.runtime||'—']
  ];
  return `<div class="panel bm199-info-panel"><div class="bm199-info-head"><div><small>${en?'DETAILS':'مشخصات'}</small><h3>${en?'Title information':'مشخصات فیلم و سریال'}</h3></div></div><div class="bm199-spec-grid">${info.map(([key,label,value])=>`<div class="bm199-spec-card bm199-spec-${key}"><span class="bm199-spec-icon">${BM199_INFO_ICONS[key]}</span><span class="bm199-spec-copy"><small>${esc(label)}</small><strong>${esc(value)}</strong></span></div>`).join('')}</div><div class="bm199-extra-info"><div class="field"><label>${en?'Original title':'عنوان اصلی'}</label><div>${esc(d.title||'—')}</div></div><div class="field"><label>${en?'Network':'شبکه'}</label><div>${esc(d.network||'—')}</div></div></div></div>`
}
async function playSource(s){
  if(!s?.url)return toast('لینک پخش معتبر نیست','error');
  try{
    const result=await bridge.playExternal({url:s.url,subtitleUrl:subtitleUrlOf(s),preferredPlayer:state.settings?.preferredPlayer||'auto',title:itemTitle(state.currentDetail),quality:s.quality||'',season:s.season||null,episode:s.episode||null});
    const suffix=subtitleUrlOf(s)&&!result?.subtitleApplied?' • زیرنویس جداگانه توسط این پلیر تضمین نمی‌شود':'';
    toast(`در ${result?.player?.name||'پلیر خارجی'} باز شد${suffix}`,'ok');
  }catch(e){toast(e.message||String(e),'error')}
}
async function downloadSource(s,d){try{const ext=(()=>{try{const x=new URL(s.url).pathname.split('.').pop().split(/[?#]/)[0];return x&&x.length<6?x:'mp4'}catch{return'mp4'}})();const name=`${itemTitle(d)}${s.season?` - S${s.season}`:''}${s.episode?`E${s.episode}`:''} - ${sourceTypeLabel(s)} - ${s.quality||'video'}.${ext}`;await bridge.download({url:s.url,fileName:name,title:itemTitle(d),quality:`${s.quality||''} ${sourceTypeLabel(s)}`.trim(),poster:d.poster||'',season:s.season||null,episode:s.episode||null});toast('دانلود به صف اضافه شد','ok');bm194SetDownloadCount(String(Math.max(1,state.downloads.size)))}catch(e){toast(e.message,'error')}}

function watchKey(it){return it?.storage_key||it?._key||`${it?.archive||1}|${it?.type||'movie'}|${itemId(it)}`}
async function ensureWatchlist(){if(!state.user)return[];try{const r=await bridge.user('watchlist_list',{},'POST');state.watchlist=r.items||[];return state.watchlist}catch{return[]}}
async function quickWatchlist(item,rerender=false){
  if(!state.user){showAuthModal();return}await ensureWatchlist();const key=watchKey(item);const old=state.watchlist.find(x=>watchKey(x)===key);
  try{const body=old?{removed_keys:[watchKey(old)],items:[]}:{removed_keys:[],items:[item]};const r=await bridge.user('watchlist_sync',body,'POST');state.watchlist=r.items||[];toast(old?'از لیست حذف شد':'به لیست اضافه شد','ok');if(rerender&&state.currentDetail)renderDetail(state.currentDetail)}catch(e){toast(e.message,'error')}
}
async function showWatchlist(){setActiveNav('watchlist');if(!state.user)return showAuthGate('برای دیدن لیست شخصی وارد حساب شو.');setLoading();await ensureWatchlist();renderGridPage('لیست من','همگام با حساب BankMovie',state.watchlist)}

let commentsCache=[];
async function loadComments(d){try{const r=await bridge.user('comments_list',{item:d,page:1,limit:20,sort:'latest'},'POST');commentsCache=r.items||r.comments||[]}catch{commentsCache=[]}}
function renderCommentsBox(d){
  const box=$('#detailTab');box.innerHTML=`${state.user?`<div class="comment-form"><textarea class="form-control" id="commentText" placeholder="دیدگاهت را بنویس…"></textarea><button class="btn primary" id="sendComment">ارسال</button></div>`:'<div class="panel" style="margin-bottom:10px">برای ثبت دیدگاه وارد حساب شو.</div>'}<div id="commentsList" class="comments">${commentsCache.length?commentsCache.map(c=>commentHtml(c,0)).join(''):'<div class="empty">هنوز دیدگاهی ثبت نشده است.</div>'}</div>`;
  if($('#sendComment'))$('#sendComment').onclick=async()=>{const text=$('#commentText').value.trim();if(text.length<3)return toast('متن دیدگاه کوتاه است','error');try{await bridge.user('comment_add',{item:d,comment:text,rating:0,spoiler:0},'POST');$('#commentText').value='';await reloadComments(d,'دیدگاه ثبت شد')}catch(e){toast(e.message,'error')}};
  $$('[data-comment-action]').forEach(b=>b.onclick=()=>commentAction(b.dataset.commentAction,Number(b.dataset.commentId),b.dataset.commentText||'',d));
}
function commentHtml(c,depth=0){
  const buttons=state.user?`<div class="source-actions" style="margin-top:8px;justify-content:flex-start;flex-wrap:wrap"><button class="btn ghost slim" data-comment-action="like" data-comment-id="${c.id}">👍 ${c.like_count||0}</button><button class="btn ghost slim" data-comment-action="dislike" data-comment-id="${c.id}">👎 ${c.dislike_count||0}</button><button class="btn ghost slim" data-comment-action="reply" data-comment-id="${c.id}">پاسخ</button>${c.can_report?`<button class="btn ghost slim" data-comment-action="report" data-comment-id="${c.id}">گزارش</button>`:''}${c.can_edit?`<button class="btn ghost slim" data-comment-action="edit" data-comment-id="${c.id}" data-comment-text="${esc(c.comment_raw||c.comment||'')}">ویرایش</button>`:''}${c.can_pin?`<button class="btn ghost slim" data-comment-action="pin" data-comment-id="${c.id}">${c.is_pinned?'برداشتن پین':'پین'}</button>`:''}${c.can_delete?`<button class="btn ghost slim" data-comment-action="delete" data-comment-id="${c.id}">حذف</button>`:''}</div>`:'';
  return `<div class="comment" style="margin-right:${Math.min(depth,3)*18}px"><div class="comment-head"><strong>${esc(c.username||c.user?.username||'کاربر')} ${c.badge?`• ${esc(c.badge)}`:''}</strong><span>${esc(c.date_text||c.created_at||'')}</span></div><p>${c.spoiler?'⚠️ Spoiler — ':''}${esc(c.comment||c.text||'')}</p>${buttons}${(c.replies||[]).map(r=>commentHtml(r,depth+1)).join('')}</div>`
}
async function reloadComments(d,message=''){await loadComments(d);renderCommentsBox(d);if(message)toast(message,'ok')}
async function commentAction(action,id,text,d){
  if(!state.user)return showAuthModal();
  try{
    if(action==='like'||action==='dislike')await bridge.user('comment_vote',{item:d,comment_id:id,type:action},'POST');
    else if(action==='reply'){const v=prompt('متن پاسخ:');if(!v)return;await bridge.user('comment_reply',{item:d,parent_id:id,comment:v,rating:0,spoiler:0},'POST')}
    else if(action==='report'){const v=prompt('توضیح گزارش (اختیاری):','');if(v===null)return;await bridge.user('comment_report',{item:d,comment_id:id,reason:'other',details:v},'POST')}
    else if(action==='edit'){const v=prompt('ویرایش دیدگاه:',text);if(!v)return;await bridge.user('comment_edit',{item:d,comment_id:id,comment:v,spoiler:0},'POST')}
    else if(action==='pin')await bridge.user('comment_pin',{item:d,comment_id:id},'POST');
    else if(action==='delete'){if(!confirm('دیدگاه حذف شود؟'))return;await bridge.user('comment_delete',{item:d,comment_id:id},'POST')}
    await reloadComments(d,action==='report'?'گزارش ثبت شد':'انجام شد');
  }catch(e){toast(e.message,'error')}
}

function onDownloadUpdate(d){state.downloads.set(d.id,d);bm194SetDownloadCount([...state.downloads.values()].filter(x=>!['completed','cancelled','interrupted'].includes(x.state)).length||'');if(state.lastView==='downloads')renderDownloads()}
function showDownloads(){setActiveNav('downloads');renderDownloads()}
function renderDownloads(){
  const arr=[...state.downloads.values()];$('#view').innerHTML=`<div class="page-title"><div><h1>دانلودها</h1><p>${esc(state.settings?.downloadDir||'')}</p></div><button class="btn ghost" id="chooseFolder">تغییر پوشه</button></div><div id="downloadRows">${arr.length?arr.map(downloadHtml).join(''):'<div class="empty">هنوز دانلودی در این نشست شروع نشده است.</div>'}</div>`;
  $('#chooseFolder').onclick=async()=>{state.settings.downloadDir=await bridge.chooseDownloadDir();renderDownloads()};$$('[data-dl-action]').forEach(b=>b.onclick=()=>bridge.downloadAction(b.dataset.id,b.dataset.dlAction));$$('[data-show-file]').forEach(b=>b.onclick=()=>bridge.showItem(b.dataset.showFile));
}
function downloadHtml(d){const p=pct(d.received,d.total);return `<div class="download-row"><div><strong>${esc(d.title||d.fileName||'دانلود')}</strong><small>${esc(d.quality||'')} • ${fmtBytes(d.received)} / ${fmtBytes(d.total)}</small><div class="progress"><i style="width:${p}%"></i></div></div><div><span class="chip">${esc(d.state||'شروع')}</span></div><div class="source-actions">${d.state==='progressing'&&!d.paused?`<button class="btn ghost slim" data-dl-action="pause" data-id="${d.id}">توقف</button>`:''}${d.paused?`<button class="btn primary slim" data-dl-action="resume" data-id="${d.id}">ادامه</button>`:''}${d.state==='completed'&&d.savePath?`<button class="btn ghost slim" data-show-file="${esc(d.savePath)}">فایل</button>`:`<button class="btn ghost slim" data-dl-action="cancel" data-id="${d.id}">لغو</button>`}</div></div>`}

async function showNotifications(){
  setActiveNav('notifications');if(!state.user)return showAuthGate('اعلان‌ها بعد از ورود به حساب نمایش داده می‌شوند.');setLoading();
  try{const r=await bridge.user('notifications_list',{page:1,limit:40},'POST');const items=r.items||[];state.stats=r.stats||state.stats;$('#notifCount').textContent=state.stats?.unread_notifications??state.stats?.notifications_unread??'';$('#view').innerHTML=`<div class="page-title"><div><h1>اعلان‌ها</h1><p>پیام‌های شخصی و مدیریتی</p></div><button class="btn ghost" id="readAll">خواندن همه</button></div>${items.length?`<div class="comments">${items.map(n=>`<div class="comment"><div class="comment-head"><strong>${esc(n.title||'اعلان')}</strong><span>${esc(n.date_text||'')}</span></div><p>${esc(n.message||'')}</p></div>`).join('')}</div>`:'<div class="empty">اعلان جدیدی نداری.</div>'}`;$('#readAll').onclick=async()=>{await bridge.user('notifications_read_all',{},'POST');toast('همه اعلان‌ها خوانده شد','ok');showNotifications()}}catch(e){renderError(e)}
}

async function showParty(){
  setActiveNav('party');setLoading('در حال آماده‌سازی Watch Party…');
  try{const st=await bridge.user('watch_party_status',{},'POST');if(!st.enabled)return renderGridPage('Watch Party','این قابلیت غیرفعال است',[]);renderPartyLobby(st)}catch(e){renderError(e)}
}
function renderPartyLobby(st){
  $('#view').innerHTML=`<div class="page-title"><div><h1>Watch Party</h1><p>تماشای همزمان، چت و کنترل میزبان</p></div><span class="chip ${st.is_vip?'gold':''}">${st.is_vip?'VIP':'حساب عادی'}</span></div><div class="settings-grid"><div class="panel"><h3>ورود به اتاق</h3><div class="field"><label>کد اتاق</label><input id="roomCode" placeholder="مثلاً ABC123"></div><div style="margin-top:10px"><button class="btn primary" id="joinRoom">ورود</button></div></div><div class="panel"><h3>ساخت اتاق</h3><p style="color:#858990;font-size:11px;line-height:1.8">ساخت اتاق برای VIP فعال است. اگر از صفحه جزئیات وارد شوی، عنوان فعلی خودکار به اتاق منتقل می‌شود.</p><button class="btn ghost" id="createRoom" ${st.is_vip?'':'disabled'}>ساخت برای عنوان فعلی</button></div></div>`;
  $('#joinRoom').onclick=()=>joinParty($('#roomCode').value.trim());$('#createRoom').onclick=()=>createParty();
}
async function createParty(){if(!state.currentDetail)return toast('اول یک فیلم یا سریال باز کن','error');try{const d=state.currentDetail;const source=(d.play?.links||[]).find(x=>x.url)||{};const r=await bridge.user('watch_party_create',{movie_id:Number(d.db_id||d.movie_id||0),archive_no:Number(d.archive||1),media_type:d.type||'movie',source_ref:itemId(d),source_url:source.url||'',subtitle_url:'',content_title:itemTitle(d),poster_url:d.poster||''},'POST');const code=r.room?.invite_code||r.room?.room_code;if(code)openPartyRoom(code,r.room)}catch(e){toast(e.message,'error')}}
async function joinParty(code){if(!code)return toast('کد اتاق را وارد کن','error');try{const r=await bridge.user('watch_party_join',{room_code:code},'POST');openPartyRoom(code,r.membership||{})}catch(e){toast(e.message,'error')}}
function openPartyRoom(code,meta={}){state.party={code,afterEvent:0,afterMessage:0};renderPartyRoom(code,meta);pollParty();state.partyTimer=setInterval(pollParty,3500)}
function renderPartyRoom(code,meta){$('#view').innerHTML=`<div class="page-title"><div><h1>اتاق ${esc(code)}</h1><p>${esc(meta.content_title||'Watch Party فعال')}</p></div><button class="btn ghost" id="leaveParty">خروج</button></div><div class="party-shell"><div class="panel"><h3>وضعیت پخش</h3><div id="partyState" class="empty" style="padding:40px">در حال همگام‌سازی…</div></div><div class="panel party-chat"><h3>گفتگو</h3><div class="chat-list" id="chatList"></div><div class="chat-compose"><input class="form-control" id="chatText" placeholder="پیام…"><button class="btn primary" id="sendChat">ارسال</button></div></div></div>`;$('#leaveParty').onclick=async()=>{try{await bridge.user('watch_party_leave',{room_code:code},'POST')}catch{}state.party=null;clearInterval(state.partyTimer);state.partyTimer=null;showParty()};$('#sendChat').onclick=sendPartyMessage}
async function pollParty(){if(!state.party)return;try{const r=await bridge.user('watch_party_poll',{room_code:state.party.code,after_event_id:state.party.afterEvent,after_message_id:state.party.afterMessage},'POST');const ev=r.events||[];const msg=r.messages||[];if(ev.length)state.party.afterEvent=Math.max(state.party.afterEvent,...ev.map(x=>Number(x.id||x.event_id||0)));if(msg.length){state.party.afterMessage=Math.max(state.party.afterMessage,...msg.map(x=>Number(x.id||x.message_id||0)));const list=$('#chatList');if(list){msg.forEach(m=>list.insertAdjacentHTML('beforeend',`<div class="chat-msg"><strong>${esc(m.username||m.display_name||'کاربر')}:</strong> ${esc(m.text||m.message||'')}</div>`));list.scrollTop=list.scrollHeight}}if($('#partyState')){const s=r.state||{};$('#partyState').innerHTML=`<div class="meta"><span class="chip">${s.is_paused?'⏸ توقف':'▶ در حال پخش'}</span><span class="chip">${Math.round(Number(s.position_seconds||0))} ثانیه</span><span class="chip">${esc(r.member_role||'guest')}</span></div>`}}catch(e){console.warn(e)}}
async function sendPartyMessage(){const input=$('#chatText');const m=input?.value.trim();if(!m||!state.party)return;try{await bridge.user('watch_party_message',{room_code:state.party.code,message:m,client_message_id:`win-${Date.now()}`},'POST');input.value='';await pollParty()}catch(e){toast(e.message,'error')}}

function vipConfig(){return state.userConfig?.vip||{plans:[],features:[],telegram_username:'bankmovie_supp',purchase_enabled:true,purchase_message_template:'سلام، برای خرید اشتراک {plan} بانک‌مووی به مبلغ {price} هزار تومان پیام می‌دهم.',section_title:'BankMovie VIP',section_description:''}}
function isVip(){return !!state.user?.is_vip}
function vipScope(value){return ['vip','premium','special','members','member'].includes(String(value||'').trim().toLowerCase())}
function archiveActionNeedsVip(archive,mode='browse'){
  const n=Number(archive)||1,p=archivePolicy(n),legacy=state.config?.features?.archives||{};
  if(mode==='browse')return vipScope(p.access_scope);
  if(mode==='stream')return vipScope(p.stream_access_scope)||legacy[`archive${n}_stream_vip`]===true;
  if(mode==='download')return vipScope(p.download_access_scope)||legacy[`archive${n}_download_vip`]===true;
  return false;
}
function sectionNeedsVip(archive,section){return vipScope(sectionPolicy(Number(archive)||1,section)?.access_scope)}
function faDate(value){if(!value)return '—';try{return new Intl.DateTimeFormat('fa-IR',{year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(String(value).replace(' ','T')))}catch{return String(value)}}
function vipRemainingText(user=state.user){if(!user?.is_vip)return 'اشتراک ویژه فعال نیست';if(user.vip_lifetime)return 'اشتراک مادام‌العمر';const d=Number(user.vip_remaining_days||0);return d>0?`${d.toLocaleString('fa-IR')} روز باقی‌مانده`:'اشتراک فعال'}
function vipHeroStatusHtml(){
  if(!state.user)return '';
  const active=isVip(),days=Number(state.user.vip_remaining_days||0),expiry=faDate(state.user.vip_expires_at);
  return `<section class="vip-status-card ${active?'is-active':'is-inactive'}"><div class="vip-status-icon">${icon('vip')}</div><div class="vip-status-copy"><span>${active?'BANKMOVIE VIP':'BANKMOVIE MEMBERSHIP'}</span><h2>${active?'اشتراک ویژه شما فعال است':'امکانات ویژه BankMovie'}</h2><p>${active?(state.user.vip_lifetime?'عضویت شما بدون تاریخ انقضا فعال است.':`باقی‌مانده اشتراک: ${days.toLocaleString('fa-IR')} روز • تاریخ پایان: ${esc(expiry)}`):'برای دسترسی به آرشیوها و قابلیت‌هایی که از پنل سایت VIP شده‌اند، اشتراک را فعال کن.'}</p></div><div class="vip-status-side">${active?`<strong>${state.user.vip_lifetime?'∞':days.toLocaleString('fa-IR')}</strong><small>${state.user.vip_lifetime?'بدون انقضا':'روز باقی‌مانده'}</small>`:`<button class="btn vip-buy" id="profileVipBtn">${icon('vip')}<span>مشاهده پلن‌ها و خرید VIP</span></button>`}${active?'<button class="btn ghost vip-renew" id="profileVipBtn">تمدید اشتراک</button>':''}</div></section>`;
}
async function showProfile(){
  setActiveNav('profile');setLoading('در حال همگام‌سازی پروفایل…');
  try{await loadUserConfig();if(state.user)await refreshMe(false)}catch{}
  renderProfile();
}
function renderProfile(){
  const logged=!!state.user,recent=state.recentViews||[],vip=vipConfig();
  $('#view').innerHTML=`<div class="page-shell profile-page profile-v17">
    <section class="profile-cover-v17"><div class="profile-cover-glow"></div><div class="profile-avatar-v17">${cleanUrl(state.user?.avatar)?img(state.user.avatar,'avatar'):ICONS.user}</div><div class="profile-identity-v17"><span>${logged?(isVip()?'عضو ویژه BankMovie':'حساب BankMovie'):'BANKMOVIE ACCOUNT'}</span><h1>${esc(logged?(state.user.full_name||state.user.username):'پروفایل BankMovie')}</h1><p>${esc(logged?(state.user.email||''):'برای همگام‌سازی حساب، اشتراک، آواتار و لیست‌ها وارد شوید.')}</p>${logged?`<div class="profile-mini-meta"><b>@${esc(state.user.username||'user')}</b>${isVip()?`<i>${icon('vip')} ${esc(vipRemainingText())}</i>`:'<i>عضویت عادی</i>'}</div>`:''}</div>${logged?`<button class="avatar-change-fab" id="avatarBtn">${icon('user')}<span>انتخاب آواتار</span></button>`:`<button class="btn primary" id="profileLoginBtn">ورود / ثبت‌نام</button>`}</section>
    ${logged?vipHeroStatusHtml():''}
    <div class="profile-actions profile-actions-v17"><button data-profile-route="watchlist">${icon('bookmark')}<span>لیست من</span><small>${Number(state.stats?.watchlist_count??state.stats?.watchlist??0).toLocaleString('fa-IR')}</small></button><button data-profile-route="downloads">${icon('download')}<span>دانلودها</span></button><button data-profile-route="notifications">${icon('bell')}<span>اعلان‌ها</span><small>${Number(state.stats?.unread_notifications??state.stats?.notifications_unread??0).toLocaleString('fa-IR')}</small></button><button data-profile-route="settings">${icon('settings')}<span>تنظیمات</span></button></div>
    ${logged?`<div class="profile-info-grid-v17"><section class="profile-info-card"><header><div>${icon('user')}<span><b>حساب کاربری</b><small>همگام با سایت و Android</small></span></div><button class="btn ghost slim" id="refreshProfileBtn">بروزرسانی</button></header><dl><div><dt>نام کاربری</dt><dd>${esc(state.user.username||'—')}</dd></div><div><dt>نوع عضویت</dt><dd>${isVip()?'VIP فعال':'کاربر رایگان'}</dd></div><div><dt>باقی‌مانده</dt><dd>${isVip()?esc(vipRemainingText()):'—'}</dd></div><div><dt>تاریخ پایان</dt><dd>${isVip()?esc(state.user.vip_lifetime?'بدون انقضا':faDate(state.user.vip_expires_at)):'—'}</dd></div></dl><div class="actions"><button class="btn ghost" id="avatarBtn2">تغییر آواتار</button><button class="btn ghost" id="logoutBtn">خروج از حساب</button></div></section><section class="profile-info-card profile-vip-features"><header><div>${icon('vip')}<span><b>${esc(vip.section_title||'BankMovie VIP')}</b><small>${isVip()?'مزایای عضویت شما':'پلن‌های سایت همیشه به‌روز'}</small></span></div></header><p>${esc(vip.section_description||'')}</p><div class="vip-feature-chips">${(vip.features||[]).slice(0,8).map(f=>`<span>${icon('vip')} ${esc(f)}</span>`).join('')}</div><button class="btn vip-buy" id="profileVipPlans">${icon('vip')}<span>${isVip()?'مشاهده پلن‌ها / تمدید':'خرید اشتراک VIP'}</span></button></section></div>`:''}
    <section class="section recent-section"><div class="section-head"><div><h2>بازدیدهای اخیر</h2><small>آخرین عنوان‌هایی که در این دستگاه باز کرده‌ای</small></div>${recent.length?'<button class="link-btn" id="clearRecentBtn">پاک کردن</button>':''}</div>${recent.length?`<div class="rail">${recent.map(card).join('')}</div>`:'<div class="empty">هنوز عنوانی در بازدیدهای اخیر نیست.</div>'}</section>
  </div>`;
  bindCards();$$('[data-profile-route]').forEach(b=>b.onclick=()=>route(b.dataset.profileRoute));
  if($('#profileLoginBtn'))$('#profileLoginBtn').onclick=showAuthModal;
  [$('#avatarBtn'),$('#avatarBtn2')].filter(Boolean).forEach(b=>b.onclick=showAvatarModal);
  [$('#profileVipBtn'),$('#profileVipPlans')].filter(Boolean).forEach(b=>b.onclick=showVipPlansModal);
  if($('#refreshProfileBtn'))$('#refreshProfileBtn').onclick=async()=>{await loadUserConfig();await refreshMe(true);renderProfile();toast('وضعیت حساب و اشتراک بروزرسانی شد','ok')};
  if($('#logoutBtn'))$('#logoutBtn').onclick=async()=>{try{await bridge.user('logout',{},'POST')}catch{}await bridge.logoutLocal();state.user=null;state.watchlist=[];updateProfile();renderProfile();toast('از حساب خارج شدی','ok')};
  if($('#clearRecentBtn'))$('#clearRecentBtn').onclick=()=>{state.recentViews=[];localStorage.removeItem(RECENT_KEY);renderProfile();toast('بازدیدهای اخیر پاک شد','ok')};
}
function vipPlanToneClass(tone){const t=String(tone||'blue').toLowerCase();return ['blue','purple','gold','pink','cyan'].includes(t)?`tone-${t}`:'tone-blue'}
function purchaseMessage(plan){const v=vipConfig();return String(v.purchase_message_template||'سلام، برای خرید اشتراک {plan} بانک‌مووی به مبلغ {price} هزار تومان پیام می‌دهم.').replaceAll('{plan}',plan?.name||'VIP').replaceAll('{price}',plan?.price||'')}
function buyVipPlan(plan){const v=vipConfig(),user=String(v.telegram_username||'bankmovie_supp').replace(/^@/,'');if(!user)return toast('آیدی پشتیبانی خرید تنظیم نشده است','error');const url=`https://t.me/${encodeURIComponent(user)}?text=${encodeURIComponent(purchaseMessage(plan))}`;bridge.openExternal(url)}
function showVipPlansModal(){
  const v=vipConfig(),plans=Array.isArray(v.plans)?v.plans:[];
  openModal(`<div class="vip-plans-modal"><button class="vip-modal-close" data-close-vip>×</button><div class="vip-modal-head"><div class="vip-modal-crown">${icon('vip')}</div><span>BANKMOVIE VIP</span><h2>${esc(v.section_title||'اشتراک ویژه BankMovie')}</h2><p>${esc(v.section_description||'پلن مورد نظرت را انتخاب کن. قیمت و متن‌ها مستقیماً از سایت همگام می‌شوند.')}</p></div>${plans.length?`<div class="vip-plans-grid">${plans.map((p,i)=>`<article class="vip-plan-card ${vipPlanToneClass(p.tone)} ${p.featured?'featured':''}" data-vip-plan="${i}">${p.featured?'<em>محبوب‌ترین انتخاب</em>':''}<div class="vip-plan-top"><span>${esc(p.latin||'VIP')}</span><strong>${esc(p.name||'اشتراک')}</strong></div><div class="vip-plan-body"><small>${esc(p.badge||'BankMovie VIP')}</small><div class="vip-price"><b>${esc(p.price||'—')}</b><span>هزار تومان</span></div><p>${esc(p.period||'')}</p>${p.saving?`<i>${esc(p.saving)}</i>`:''}<button class="vip-plan-buy" type="button">خرید و پیام در تلگرام</button></div></article>`).join('')}</div>`:'<div class="empty">پلن فعالی از سایت دریافت نشد.</div>'}<div class="vip-modal-features">${(v.features||[]).map(f=>`<span>${icon('vip')}<b>${esc(f)}</b></span>`).join('')}</div></div>`,true);
  $('[data-close-vip]').onclick=closeModal;$$('[data-vip-plan]').forEach(el=>el.onclick=e=>{if(e.target.closest('button')||e.currentTarget===el)buyVipPlan(plans[Number(el.dataset.vipPlan)])});
}
function showVipGateModal(title='بخش ویژه اعضای VIP',message='برای استفاده از این قابلیت اشتراک VIP فعال لازم است.'){
  if(isVip())return false;
  const logged=!!state.user;
  openModal(`<div class="vip-gate-v17"><button class="vip-modal-close" data-close-vip-gate>×</button><div class="vip-gate-crown">${icon('vip')}</div><span>BANKMOVIE VIP</span><h2>${esc(title)}</h2><p>${esc(message)}</p><div class="vip-gate-note">${icon('vip')}<span>${logged?'اگر اشتراکت تازه فعال شده، وضعیت حساب را بروزرسانی کن.':'ابتدا وارد حساب شو یا رایگان ثبت‌نام کن، سپس پلن VIP را انتخاب کن.'}</span></div><button class="btn vip-buy vip-gate-buy" id="vipGatePlans">${icon('vip')}<span>مشاهده پلن‌ها و خرید VIP</span></button>${logged?'<button class="btn ghost" id="vipGateRefresh">بروزرسانی وضعیت اشتراک</button>':'<div class="vip-gate-auth"><button class="btn ghost" id="vipGateRegister">ثبت‌نام رایگان</button><button class="btn ghost" id="vipGateLogin">ورود به حساب</button></div>'}<button class="vip-no-thanks" data-close-vip-gate>فعلاً نه</button></div>`);
  $$('[data-close-vip-gate]').forEach(b=>b.onclick=closeModal);$('#vipGatePlans').onclick=showVipPlansModal;
  if($('#vipGateLogin'))$('#vipGateLogin').onclick=showAuthModal;if($('#vipGateRegister'))$('#vipGateRegister').onclick=()=>{showAuthModal();setTimeout(()=>$$('[data-auth-tab]').find(x=>x.dataset.authTab==='register')?.click(),30)};
  if($('#vipGateRefresh'))$('#vipGateRefresh').onclick=async()=>{await refreshMe(true);if(isVip()){closeModal();toast('اشتراک VIP فعال است','ok')}else toast('هنوز اشتراک VIP فعالی روی حساب دیده نشد','error')};
  return true;
}
async function ensureVipAccess(archive,mode='browse',section=''){
  const need=(mode==='browse'&&section?sectionNeedsVip(archive,section):false)||archiveActionNeedsVip(archive,mode);
  if(!need)return true;if(isVip())return true;
  if(state.user){try{await refreshMe(false)}catch{}if(isVip())return true}
  const names={browse:'این آرشیو ویژه اعضای VIP است',stream:'پخش آنلاین ویژه اعضای VIP',download:'دانلود ویژه اعضای VIP'};
  showVipGateModal(names[mode]||'بخش ویژه اعضای VIP',`دسترسی ${mode==='download'?'دانلود':mode==='stream'?'پخش':'این بخش'} در ${ARCHIVE_NAMES[Number(archive)||1]} طبق تنظیمات سایت فقط برای کاربران VIP فعال است.`);return false;
}
async function showAvatarModal(){
  try{await loadUserConfig()}catch{}
  const avatars=state.userConfig?.avatars||[],selected=state.user?.avatar_key||'';
  openModal(`<div class="avatar-picker-v17"><button class="vip-modal-close" data-close-avatar>×</button><div class="avatar-picker-head-v17"><div>${icon('user')}</div><span><h2>انتخاب آواتار</h2><p>آواتارهای رایگان سایت؛ انتخابت روی وب، Android و Windows همگام می‌شود.</p></span></div><div class="avatar-grid-v17">${avatars.map(a=>`<button class="avatar-choice-v17 ${a.key===selected?'selected':''}" data-avatar="${esc(a.key)}">${img(a.url,a.label)}<strong>${esc(a.label||a.key)}</strong>${a.key===selected?'<i>انتخاب‌شده</i>':''}</button>`).join('')}</div>${state.user?.can_upload_avatar?`<div class="custom-avatar-v17"><div><b>آواتار اختصاصی VIP</b><small>PNG / JPG / WEBP / GIF تا ۴ مگابایت</small></div><label class="btn vip-buy"><input type="file" id="avatarFile" accept="image/png,image/jpeg,image/webp,image/gif" hidden>${icon('vip')}<span>آپلود تصویر شخصی</span></label></div>`:'<div class="custom-avatar-v17 locked"><div><b>آواتار اختصاصی</b><small>آپلود تصویر شخصی فقط برای اعضای VIP فعال است.</small></div><button class="btn ghost" id="avatarVipBtn">VIP</button></div>'}</div>`,true);
  $('[data-close-avatar]').onclick=closeModal;$$('[data-avatar]').forEach(b=>b.onclick=async()=>{try{const r=await bridge.user('avatar_update',{avatar_key:b.dataset.avatar},'POST');state.user=r.user;updateProfile();closeModal();toast('آواتار روی حساب ذخیره و همگام شد','ok');if(state.lastView==='profile')renderProfile()}catch(e){toast(e.message,'error')}});
  if($('#avatarVipBtn'))$('#avatarVipBtn').onclick=showVipPlansModal;
  if($('#avatarFile'))$('#avatarFile').onchange=e=>{const f=e.target.files?.[0];if(!f)return;const rd=new FileReader();rd.onload=async()=>{try{const r=await bridge.user('avatar_upload',{image_base64:rd.result},'POST');state.user=r.user;updateProfile();closeModal();toast('آواتار اختصاصی ذخیره و همگام شد','ok');if(state.lastView==='profile')renderProfile()}catch(err){toast(err.message,'error')}};rd.readAsDataURL(f)};
}
function showAuthGate(text){$('#view').innerHTML=`<div class="empty"><p>${esc(text)}</p><button class="btn primary" id="authGateBtn">ورود / ثبت‌نام</button></div>`;$('#authGateBtn').onclick=showAuthModal}
function showAuthModal(){
  openModal(`<button class="icon-btn close-modal" data-close-auth>×</button><div style="min-width:min(470px,80vw)"><div class="page-title"><div><h1>حساب BankMovie</h1><p>ورود و لیست شخصی روی همه دستگاه‌ها</p></div></div><div class="tabs"><button class="tab active" data-auth-tab="login">ورود</button><button class="tab" data-auth-tab="register">ثبت‌نام</button></div><div id="authBody">${loginForm()}</div></div>`);$('[data-close-auth]').onclick=closeModal;$$('[data-auth-tab]').forEach(t=>t.onclick=()=>{$$('[data-auth-tab]').forEach(x=>x.classList.remove('active'));t.classList.add('active');$('#authBody').innerHTML=t.dataset.authTab==='login'?loginForm():registerForm();bindAuthForms()});bindAuthForms();
}
function loginForm(){return `<form id="loginForm" class="form-grid"><div class="field full"><label>نام کاربری یا ایمیل</label><input name="identity" required></div><div class="field full"><label>رمز عبور</label><input name="password" type="password" required></div><div class="field full"><button class="btn primary">ورود</button></div></form>`}
function registerForm(){return `<form id="registerForm" class="form-grid"><div class="field full"><label>نام کاربری</label><input name="username" required></div><div class="field full"><label>ایمیل</label><input name="email" type="email" required></div><div class="field"><label>رمز عبور</label><input name="password" type="password" required></div><div class="field"><label>تکرار رمز</label><input name="confirm_password" type="password" required></div><div class="field full"><button class="btn primary">ساخت حساب</button></div></form>`}
function bindAuthForms(){
  if($('#loginForm'))$('#loginForm').onsubmit=async e=>{e.preventDefault();const b=Object.fromEntries(new FormData(e.currentTarget));try{const r=await bridge.user('login',b,'POST');if(!r.success)throw new Error(r.message||'ورود انجام نشد');state.user=r.user;state.stats=r.stats;closeModal();updateProfile();toast('خوش آمدی','ok');route(state.lastView||'home')}catch(err){toast(err.message,'error')}};
  if($('#registerForm'))$('#registerForm').onsubmit=async e=>{e.preventDefault();const b=Object.fromEntries(new FormData(e.currentTarget));try{const r=await bridge.user('register',b,'POST');if(!r.success)throw new Error(r.message||'ثبت‌نام انجام نشد');state.user=r.user;state.stats=r.stats;closeModal();updateProfile();toast('حساب ساخته شد','ok')}catch(err){toast(err.message,'error')}};
}

async function showSettings(){
  setActiveNav('settings');state.settings=await bridge.getSettings();state.players=await bridge.getPlayers();const cfg=state.config||{};const df=cfg.desktop?.features||{};
  const playerOptions=`<option value="auto">خودکار (پیشنهادی)</option>${state.players.map(p=>`<option value="${esc(p.id)}" ${state.settings.preferredPlayer===p.id?'selected':''}>${esc(p.name)}</option>`).join('')}`;
  const playerStatus=state.players.length?state.players.map((p,i)=>`<span class="chip ${i===0?'gold':''}">${i===0?'پیشنهادی: ':''}${esc(p.name)}</span>`).join(''):'<span class="chip">هیچ پلیر پشتیبانی‌شده‌ای پیدا نشد</span>';
  $('#view').innerHTML=`<div class="page-title"><div><h1>تنظیمات</h1><p>نسخه ${esc(state.appVersion)} • ${esc(cfg.active_domain||'bankmovie.top')}</p></div></div><div class="settings-grid"><div class="panel"><h3>پخش و دانلود</h3><div class="field"><label>پلیر خارجی</label><select id="preferredPlayer">${playerOptions}</select><small style="color:#70757d">برنامه فقط VLC / PotPlayer / KMPlayer نصب‌شده روی ویندوز را استفاده می‌کند؛ پلیر مرورگری حذف شده است.</small></div><div class="meta">${playerStatus}</div><div class="field" style="margin-top:14px"><label>پوشه دانلود</label><input id="downloadDir" value="${esc(state.settings.downloadDir||'')}" readonly></div><div style="margin-top:8px"><button class="btn ghost" id="chooseDir">انتخاب پوشه</button></div></div><div class="panel"><h3>کنترل ریموت</h3><div class="field"><label>Controller</label><input id="controllerUrl" dir="ltr" value="${esc(state.settings.controllerUrl||'https://bankmovie.top/desktop_config.php')}"></div><div class="meta"><span class="chip">API: ${esc(cfg.api_url||'')}</span></div><div class="actions"><button class="btn primary" id="saveSettings">ذخیره و اتصال مجدد</button></div></div><div class="panel"><h3>قابلیت‌های فعال</h3><div class="meta">${Object.entries({...cfg.features,...df}).filter(([,v])=>typeof v==='boolean'&&v).slice(0,18).map(([k])=>`<span class="chip">${esc(k.replaceAll('_',' '))}</span>`).join('')}</div></div><div class="panel"><h3>آرشیوها</h3>${enabledArchives().map(n=>{const p=archivePolicy(n);return `<div class="source-row"><div class="source-main"><span class="quality">${n}</span><span><strong>${ARCHIVE_NAMES[n]}</strong><small>${esc(p.access_scope||'public')} • download: ${esc(p.download_access_scope||'public')}</small></span></div></div>`}).join('')}</div></div>`;
  $('#chooseDir').onclick=async()=>{$('#downloadDir').value=await bridge.chooseDownloadDir()};
  $('#saveSettings').onclick=async()=>{state.settings=await bridge.setSettings({preferredPlayer:$('#preferredPlayer').value,controllerUrl:$('#controllerUrl').value.trim()});toast('تنظیمات ذخیره شد.','ok')};
}

function openModal(html,wide=false){const m=$('#modal'),b=$('#modalBox');b.innerHTML=html;b.style.maxWidth=wide?'min(1150px,94vw)':'';b.style.padding=wide?'10px':'19px';m.classList.remove('hidden')}
function closeModal(){$('#modal').classList.add('hidden');const v=$('#modal video');if(v){v.pause();v.removeAttribute('src')}}
function renderError(e){$('#view').innerHTML=`<div class="empty"><h3>ارتباط با سرور انجام نشد</h3><p>${esc(e.message||e)}</p><button class="btn ghost" id="retryBtn">تلاش دوباره</button></div>`;$('#retryBtn').onclick=()=>route(state.lastView,true);toast(e.message||String(e),'error')}

document.addEventListener('DOMContentLoaded',init);

/* ===== BankMovie Desktop v1.6.0 UX refinement overrides ===== */
const BM_GENRES = [
  ['action','اکشن'],['adventure','ماجراجویی'],['animation','انیمیشن'],['anime','انیمه'],['biography','بیوگرافی'],['comedy','کمدی'],['crime','جنایی'],['documentary','مستند'],['drama','درام'],['family','خانوادگی'],['fantasy','فانتزی'],['history','تاریخی'],['horror','ترسناک'],['music','موزیک'],['mystery','معمایی'],['romance','عاشقانه'],['science','علمی'],['sci_fi','علمی‌تخیلی'],['school','مدرسه‌ای'],['short','کوتاه'],['sport','ورزشی'],['supernatural','ماورایی'],['thriller','هیجان‌انگیز'],['war','جنگی'],['western','وسترن']
];
const BM_CATEGORY_CARDS = [
  {key:'genres',title:'ژانرها',eyebrow:'GENRES',desc:'اکشن، عاشقانه، ترسناک، علمی‌تخیلی و ژانرهای واقعی آرشیو.',image:'https://bankmovie.top/assets/categories/genres-cover.webp'},
  {key:'collections',title:'کالکشن‌ها',eyebrow:'COLLECTIONS',desc:'مجموعه‌های دنباله‌دار و فرنچایزهای محبوب، مرتب و یکجا.',image:'https://bankmovie.top/assets/categories/collections-cover.webp'},
  {key:'top_movies',title:'۲۵۰ فیلم برتر',eyebrow:'TOP 250 MOVIES',desc:'فیلم‌های برتر IMDb با صفحه‌بندی واقعی.',image:'https://bankmovie.top/assets/categories/top-250-movies.webp'},
  {key:'top_series',title:'۲۵۰ سریال برتر',eyebrow:'TOP 250 SERIES',desc:'سریال‌های برتر IMDb با صفحه‌بندی واقعی.',image:'https://bankmovie.top/assets/categories/top-250-series.webp'}
];

function card(it){
  const poster=cleanUrl(it.poster||it.cover_image||it.cover||it.image||it.local_poster||'');
  const type=(it.type==='series'?'سریال':'فیلم');const rating=itemRating(it);
  const payload=encodeURIComponent(JSON.stringify({archive:it.archive||state.archive,id:itemId(it),type:it.type||'movie',title:it.title||'',title_fa:it.title_fa||'',poster:poster,year:it.year||'',rating:rating,source:it.source||'',imdb_code:it.imdb_code||''}));
  return `<article class="media-card" data-card='${payload}'>
    <div class="poster">${poster?img(poster,itemTitle(it)):`<div class="poster-fallback">BM</div>`}<span class="type-badge">${type}</span>${rating?`<span class="poster-imdb">${icon('imdb')}<b>${esc(rating)}</b></span>`:''}<button class="poster-open" type="button" tabindex="-1">${icon('play')}<span>مشاهده</span></button></div>
    <div class="card-info"><strong>${esc(itemTitle(it))}</strong><small><span>${esc(it.year||'')} · ${type}</span><span>${rating?'★ '+esc(rating):''}</span></small></div>
  </article>`;
}

function collectionCard(it){
  const cover=cleanUrl(it.cover_image||it.cover||it.image||it.poster||'');
  return `<article class="collection-card" data-collection-open="${esc(it.slug||it.id||'')}">
    <div class="collection-cover">${cover?img(cover,itemTitle(it)):`<div class="poster-fallback">BM</div>`}<span class="collection-count">${Number(it.movie_count||0)} فیلم</span></div>
    <div class="collection-card-copy"><div><strong>${esc(itemTitle(it))}</strong><small>${esc(it.first_year||'')}${it.last_year&&it.last_year!==it.first_year?` — ${esc(it.last_year)}`:''}</small></div><button class="btn ghost slim" type="button">مشاهده کالکشن</button></div>
  </article>`;
}
function bindCollectionCards(root=document){$$('[data-collection-open]',root).forEach(el=>el.onclick=()=>openCollection(el.dataset.collectionOpen,1));}

function pagerHtml(page,hasMore,total=0){
  const p=Math.max(1,Number(page)||1);const canPrev=p>1;const canNext=!!hasMore;
  if(!canPrev&&!canNext&&!(Number(total)>0))return '';
  return `<nav class="pager" aria-label="صفحه‌بندی"><button class="btn ghost" id="pagePrev" ${canPrev?'':'disabled'}>‹ قبلی</button><span><b>صفحه ${p}</b>${Number(total)>0?`<small>${Number(total).toLocaleString('fa-IR')} عنوان</small>`:''}</span><button class="btn ghost" id="pageNext" ${canNext?'':'disabled'}>بعدی ›</button></nav>`;
}
function bindPager(page,hasMore,onPage){const prev=$('#pagePrev'),next=$('#pageNext');if(prev&&!prev.disabled)prev.onclick=()=>onPage(Math.max(1,page-1));if(next&&!next.disabled)next.onclick=()=>onPage(page+1);}
function renderPagedGrid(title,sub,payload,onPage){
  const items=payload?.items||[];const page=Number(payload?.page||1)||1;const total=Number(payload?.total_count??payload?.total??0)||0;const hasMore=payload?.has_more===true||payload?.next_page!=null;
  $('#view').innerHTML=`<div class="page-title"><div><h1>${esc(title)}</h1><p>${esc(sub)}</p></div><span class="chip">${total||items.length} عنوان</span></div>${items.length?`<div class="grid">${items.map(card).join('')}</div>`:'<div class="empty">موردی پیدا نشد.</div>'}${pagerHtml(page,hasMore,total)}`;
  bindCards();bindPager(page,hasMore,onPage);
}

function bindGlobalUI(){
  $('#headerHome').onclick=()=>route('home');
  $$('[data-header-view]').forEach(b=>b.onclick=()=>route(b.dataset.headerView));
  $$('[data-category-dest]').forEach(b=>b.onclick=e=>{e.stopPropagation();const d=b.dataset.categoryDest;if(d==='genres')showGenres();else if(d==='collections')showCollections(1);else if(d==='top_movies')showBrowseSection(1,'top_movies',1);else if(d==='top_series')showBrowseSection(1,'top_series',1)});
  $('#profileNav').onclick=()=>showProfile();$('#watchlistHeader').onclick=()=>route('watchlist');$('#notificationsHeader').onclick=()=>route('notifications');$('#themeToggle').onclick=toggleTheme;
  const toggleFullscreen=async()=>{try{const active=await bridge.window.toggleFullscreen();document.body.classList.toggle('fullscreen-mode',!!active);$('#fullscreenBtn')?.classList.toggle('active',!!active)}catch(e){toast(e.message||String(e),'error')}};
  $('#fullscreenBtn').onclick=toggleFullscreen;bridge.window.onFullscreenState?.(active=>{document.body.classList.toggle('fullscreen-mode',!!active);$('#fullscreenBtn')?.classList.toggle('active',!!active)});
  const form=$('#headerSearchForm'),input=$('#headerSearchInput');form.onsubmit=e=>{e.preventDefault();showSearch(input.value.trim())};
  document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();input.focus();input.select()}if(e.key==='F11'){e.preventDefault();toggleFullscreen()}});
  $('#modal').addEventListener('click',e=>{if(e.target.matches('[data-close-modal]'))closeModal()});
  const scroller=$('#mainScroller');
  const syncHeader=()=>{const hero=$('.site-hero');const threshold=state.lastView==='home'&&hero?Math.max(120,hero.offsetHeight-4):0;document.body.classList.toggle('header-scrolled',state.lastView!=='home'||scroller.scrollTop>=threshold)};
  scroller.addEventListener('scroll',syncHeader,{passive:true});window.addEventListener('resize',syncHeader);setTimeout(syncHeader,80);
}

function heroSlide(hero,i){
  const bg=cleanUrl(hero.backdrop||hero.background||hero.image||hero.poster||'');const rating=itemRating(hero);const year=hero.year?`<span>${esc(hero.year)}</span>`:'';
  return `<div class="hero-slide ${i===0?'active':''}" data-hero-slide="${i}">${bg?`<div class="hero-bg" style="background-image:url('${esc(bg)}')"></div>`:''}<div class="hero-center" dir="rtl"><div class="hero-copy-meta">${rating?`<span class="hero-rating">${icon('imdb','imdb-mark')}<b>${esc(rating)}</b></span>`:''}${year}</div><h1>${esc(itemTitle(hero))}</h1>${hero.subtitle_fa?`<p>${esc(hero.subtitle_fa)}</p>`:(hero.title&&hero.title!==itemTitle(hero)?`<p>${esc(hero.title)}</p>`:'')}<div class="hero-actions"><button class="btn hero-watch" data-hero-open="${i}">${icon('play')}<span>مشاهده</span></button><button class="btn hero-search-more" data-hero-search="${i}">${icon('search')}<span>جستجوی مشابه</span></button></div></div></div>`;
}
function bindHeroSlider(sliders){
  if(state.heroTimer){clearInterval(state.heroTimer);state.heroTimer=null}state.heroIndex=0;activateHero(0,sliders);
  $$('[data-hero-open]').forEach(b=>b.onclick=async()=>{const raw=sliders[Number(b.dataset.heroOpen)];const target=sliderMediaItem(raw);if(target.id)return openDetail(target);const link=cleanUrl(raw?.link_abs||raw?.link||'');if(link)return bridge.openExternal(link);toast('برای این اسلاید مقصدی ثبت نشده است','error')});
  $$('[data-hero-search]').forEach(b=>b.onclick=()=>{const raw=sliders[Number(b.dataset.heroSearch)];showSearch(itemTitle(raw))});
  $$('[data-hero-dot]').forEach(b=>b.onclick=()=>activateHero(Number(b.dataset.heroDot),sliders));$$('[data-hero-thumb]').forEach(b=>b.onclick=()=>activateHero(Number(b.dataset.heroThumb),sliders));
  const prev=$('#heroPrev'),next=$('#heroNext');if(prev)prev.onclick=()=>activateHero(state.heroIndex-1,sliders);if(next)next.onclick=()=>activateHero(state.heroIndex+1,sliders);
  if(sliders.length>1)state.heroTimer=setInterval(()=>{if(state.lastView==='home')activateHero(state.heroIndex+1,sliders)},6500);
}

function renderHome({boot,rails,archive,sections}){
  const active=Number(archive||state.archive);const sliders=(Array.isArray(boot?.sliders)?boot.sliders:[]).slice().sort((a,b)=>Number(a?.order??a?.slide_order??0)-Number(b?.order??b?.slide_order??0)).slice(0,12);
  const thumbs=sliders.map((x,i)=>{const poster=cleanUrl(x.poster||x.thumb||x.image||x.backdrop||'');return `<button class="hero-thumb ${i===0?'active':''}" data-hero-thumb="${i}" aria-label="${esc(itemTitle(x))}">${poster?`<img src="${esc(poster)}" alt="${esc(itemTitle(x))}">`:`<span>BM</span>`}</button>`}).join('');
  const hero=sliders.length?`<section class="hero site-hero" dir="ltr"><div class="hero-stage">${sliders.map(heroSlide).join('')}</div>${sliders.length>1?`<button class="hero-arrow prev" id="heroPrev">${icon('back')}</button><button class="hero-arrow next" id="heroNext">${icon('back')}</button><div class="hero-thumbnails">${thumbs}</div><div class="hero-dots">${sliders.map((_,i)=>`<button class="hero-dot ${i===0?'active':''}" data-hero-dot="${i}"></button>`).join('')}</div>`:''}</section>`:'';
  $('#view').innerHTML=`${hero}<div class="home-content">${archiveSwitcherHtml(active,'home')}${archiveCategoryNavHtml(active)}${rails.map(r=>sectionHtml(sectionLabel(r.sec),r.items,active,r.sec)).join('')}</div>`;
  if(sliders.length)bindHeroSlider(sliders);bindCards();bindArchiveSwitcher();renderTopCategories();$$('[data-home-category]').forEach(b=>b.onclick=()=>showBrowseSection(Number(b.dataset.archive),b.dataset.homeCategory,1));$$('[data-browse-section]').forEach(b=>b.onclick=()=>showBrowseSection(Number(b.dataset.archive),b.dataset.browseSection,1));
  $('#mainScroller').scrollTop=0;document.body.classList.remove('header-scrolled');
}

async function showBrowseSection(archive,section,page=1){
  state.archive=Number(archive)||state.archive;bridge.setSettings({preferredArchive:state.archive});updateSearchPlaceholder();renderTopCategories();setActiveNav(section.includes('series')?'series':'movies');setLoading();
  try{const r=await bridge.content('section',{archive:state.archive,section,page,limit:36});renderPagedGrid(sectionLabel(section),ARCHIVE_NAMES[state.archive],r,p=>showBrowseSection(state.archive,section,p))}catch(e){renderError(e)}
}

function categoryCardHtml(c){return `<button class="site-category-card" data-category-card="${esc(c.key)}" style="--cover:url('${esc(c.image)}')"><span class="site-category-meta">${esc(c.eyebrow)}</span><span class="site-category-copy"><strong>${esc(c.title)}</strong><small>${esc(c.desc)}</small><em>مشاهده ${icon('back')}</em></span></button>`;}
async function showCategories(){setActiveNav('categories');$('#view').innerHTML=`<div class="page-shell categories-page"><div class="page-title"><div><h1>دسته‌بندی</h1><p>همان مسیرهای اصلی سایت BankMovie</p></div></div><div class="site-category-grid">${BM_CATEGORY_CARDS.map(categoryCardHtml).join('')}</div></div>`;$$('[data-category-card]').forEach(b=>b.onclick=()=>{const k=b.dataset.categoryCard;if(k==='genres')showGenres();if(k==='collections')showCollections(1);if(k==='top_movies')showBrowseSection(1,'top_movies',1);if(k==='top_series')showBrowseSection(1,'top_series',1)});}
function showGenres(){setActiveNav('categories');$('#view').innerHTML=`<div class="page-shell"><div class="page-title"><div><h1>ژانرها</h1><p>ژانرهای واقعی استفاده‌شده در سایت</p></div></div><div class="genre-grid">${BM_GENRES.map(([slug,label])=>`<button class="genre-card" data-genre="${esc(slug)}" data-label="${esc(label)}" style="--genre:url('https://bankmovie.top/assets/genres/archive2/${esc(slug)}.webp')"><span>${esc(label)}</span><small>مشاهده آثار</small></button>`).join('')}</div></div>`;$$('[data-genre]').forEach(b=>b.onclick=()=>showGenre(b.dataset.genre,b.dataset.label,1));}
async function showGenre(slug,label,page=1){setActiveNav('categories');setLoading(`در حال دریافت ژانر ${label}…`);try{const r=await bridge.content('search',{archive:2,q:'',genre:slug,page,limit:36});renderPagedGrid(label,'ژانر • آرشیو بانک‌مووی',r,p=>showGenre(slug,label,p))}catch(e){renderError(e)}}

async function showCollections(page=1){
  setActiveNav('collections');setLoading('در حال دریافت کالکشن‌ها…');
  try{const r=await bridge.content('collections',{archive:2,page,limit:20});const items=r.items||[];$('#view').innerHTML=`<div class="page-shell collections-page"><div class="page-title"><div><h1>کالکشن‌ها</h1><p>مجموعه‌های دنباله‌دار بانک‌مووی</p></div><span class="chip">${items.length} کالکشن در این صفحه</span></div>${items.length?`<div class="collections-grid">${items.map(collectionCard).join('')}</div>`:'<div class="empty">کالکشنی پیدا نشد.</div>'}${pagerHtml(Number(r.page||page),r.has_more,0)}</div>`;bindCollectionCards();bindPager(Number(r.page||page),r.has_more,p=>showCollections(p))}catch(e){renderError(e)}
}
async function openCollection(slug,page=1){setActiveNav('collections');setLoading('در حال باز کردن کالکشن…');try{const r=await bridge.content('collection',{slug,page,limit:36,sort:'default'});const c=r.collection||{};const cover=cleanUrl(c.cover_image||'');$('#view').innerHTML=`<div class="collection-detail">${cover?`<section class="collection-hero"><div style="background-image:url('${esc(cover)}')"></div><span><small>COLLECTION</small><h1>${esc(itemTitle(c))}</h1><p>${esc(c.description||'مجموعه کامل فیلم‌ها')}</p></span></section>`:''}<div class="page-title"><div><h1>${esc(itemTitle(c))}</h1><p>${esc(c.movie_count||r.items?.length||0)} عنوان</p></div><button class="btn ghost" id="backCollections">بازگشت به کالکشن‌ها</button></div>${(r.items||[]).length?`<div class="grid">${r.items.map(card).join('')}</div>`:'<div class="empty">عنوانی ثبت نشده است.</div>'}${pagerHtml(Number(r.page||page),r.has_more,Number(c.movie_count||0))}</div>`;bindCards();$('#backCollections').onclick=()=>showCollections(1);bindPager(Number(r.page||page),r.has_more,p=>openCollection(slug,p))}catch(e){renderError(e)}}

async function showBoxOffice(){
  setActiveNav('boxoffice');setLoading('در حال دریافت باکس آفیس واقعی سایت…');
  try{const r=bridge.boxOffice?await bridge.boxOffice():null;if(!r?.success)throw new Error(r?.message||'باکس آفیس در دسترس نیست');const items=r.items||[];const leader=items[0]||{};const poster=cleanUrl(leader.local_poster||leader.image||'');$('#view').innerHTML=`<div class="boxoffice-page"><section class="boxoffice-hero">${poster?`<img src="${esc(poster)}" alt="${esc(leader.title||'')}">`:''}<div><span>BOX OFFICE</span><h1>باکس آفیس واقعی</h1><p>داده زنده از سرویس باکس آفیس سایت BankMovie</p><div class="boxoffice-stats"><b>#1 ${esc(leader.title_fa||leader.title||'—')}</b><b>${esc(leader.weekend||'')}</b></div></div></section><div class="boxoffice-list">${items.map((x,i)=>`<article class="boxoffice-row" data-box-local="${esc(x.local_url||'')}"><strong>#${esc(x.rank||i+1)}</strong>${cleanUrl(x.local_poster||x.image||'')?`<img src="${esc(x.local_poster||x.image)}">`:''}<span><b>${esc(x.title_fa||x.title||'')}</b><small>${esc(x.weekend||'')} • فروش کل ${esc(x.gross||'—')} • ${esc(x.weeks||0)} هفته</small></span>${x.local_match?'<button class="btn ghost slim">مشاهده</button>':''}</article>`).join('')}</div></div>`;$$('[data-box-local]').forEach(el=>el.onclick=()=>{const u=el.dataset.boxLocal;if(!u)return;const m=u.match(/[?&]arc=(\d+).*?[?&]slug=([^&]+)/);if(m)openDetail({archive:Number(m[1]),id:decodeURIComponent(m[2]),type:/series/i.test(u)?'series':'movie'});else bridge.openExternal(`https://bankmovie.top${u.startsWith('/')?u:'/'+u}`)})}catch(e){renderError(e)}
}

async function showSearch(initial=''){
  setActiveNav('search');const sections=homeSectionsFor(state.archive).filter(x=>x!=='collections');
  $('#view').innerHTML=`<div class="search-page"><section class="search-hero-panel"><span class="search-badge">جستجوی سریع</span><h1>در ${esc(ARCHIVE_NAMES[state.archive])} جستجو کن</h1><p>فیلم، سریال، بازیگر و عنوان مورد نظر را پیدا کن.</p><form id="searchForm" class="site-search-form"><div class="site-search-input">${icon('search','search-field-icon')}<input id="searchQuery" name="q" autocomplete="off" placeholder="جستجو…" value="${esc(initial)}"><button class="site-search-button">${icon('search')}<span>جستجو</span></button></div><div class="advanced-search-title">${icon('filter')}<span>فیلترهای پیشرفته</span></div><div class="advanced-search-row"><select name="type"><option value="">فیلم و سریال</option><option value="movie">فقط فیلم</option><option value="series">فقط سریال</option></select><input name="genre" placeholder="ژانر"><input name="country" placeholder="کشور"></div></form><div class="search-category-links">${sections.slice(0,10).map(sec=>`<button type="button" data-search-category="${esc(sec)}">${esc(sectionLabel(sec))}</button>`).join('')}<button type="button" id="searchGenresBtn">همه ژانرها</button></div></section><div id="searchResults"><div class="empty search-empty">عبارت جستجو را وارد کن.</div></div></div>`;
  $$('[data-search-category]').forEach(b=>b.onclick=()=>showBrowseSection(state.archive,b.dataset.searchCategory,1));$('#searchGenresBtn').onclick=showGenres;const f=$('#searchForm');f.onsubmit=async e=>{e.preventDefault();state.searchFormData=Object.fromEntries(new FormData(f).entries());await performSearch(new FormData(f),1)};if(initial){state.searchFormData=Object.fromEntries(new FormData(f).entries());performSearch(new FormData(f),1)}
}
async function performSearch(fd,page=1){
  const out=$('#searchResults');out.innerHTML=searchLoaderHtml('در حال جستجو');const p=fd instanceof FormData?Object.fromEntries(fd.entries()):{...(fd||state.searchFormData||{})};p.archive=state.archive;p.page=page;p.limit=36;state.searchFormData={...p};
  try{const r=await bridge.content('search',p);const items=r.items||r.results||[];const total=Number(r.total_count??r.total??0)||0;out.innerHTML=items.length?`<div class="search-result-head"><div><strong>نتایج جستجو</strong><small>${total||items.length} عنوان</small></div><button class="btn ghost" id="searchAllGenres">مشاهده ژانرها</button></div><div class="grid">${items.map(card).join('')}</div>${pagerHtml(Number(r.page||page),r.has_more,total)}`:`<div class="empty">نتیجه‌ای پیدا نشد.</div>`;bindCards(out);if($('#searchAllGenres'))$('#searchAllGenres').onclick=showGenres;bindPager(Number(r.page||page),r.has_more,pn=>performSearch(state.searchFormData,pn))}catch(e){out.innerHTML=`<div class="empty">${esc(e.message)}</div>`}
}

function actorKey(a){return a?.slug||a?.url||a?.bankmovie_url||a?.name||''}
function actorsHtml(d){const actors=Array.isArray(d.actors)?d.actors.filter(a=>a&&a.name).slice(0,12):[];if(!actors.length)return '';return `<section class="detail-actors"><div class="section-head"><div><h2>بازیگران</h2><small>برای دیدن فیلم‌شناسی روی بازیگر کلیک کن</small></div></div><div class="actor-rail">${actors.map(a=>{const payload=encodeURIComponent(JSON.stringify({name:a.name||'',role:a.role||'',image:a.image||'',slug:a.slug||'',url:a.url||'',bankmovie_url:a.bankmovie_url||''}));return `<button class="actor-chip" data-actor="${payload}">${cleanUrl(a.image)?`<img src="${esc(a.image)}" alt="${esc(a.name)}">`:`<span>${esc((a.name||'?').slice(0,1))}</span>`}<strong>${esc(a.name)}</strong>${a.role?`<small>${esc(a.role)}</small>`:''}</button>`}).join('')}</div></section>`}
async function openActor(actor){setActiveNav('actor');setLoading('در حال دریافت صفحه بازیگر…');try{const id=actor?.slug||actor?.url||actor?.bankmovie_url||actor?.name||'';const r=await bridge.content('actor',{slug:id,name:actor?.name||''});const a=r.actor||{};const items=r.items||r.movies||[];const photo=cleanUrl(a.photo||a.image||actor?.image||'');$('#view').innerHTML=`<div class="actor-page"><section class="actor-hero">${photo?`<div class="actor-backdrop" style="background-image:url('${esc(photo)}')"></div>`:''}<div class="actor-profile">${photo?`<img src="${esc(photo)}" alt="${esc(a.name||actor?.name||'')}">`:`<div class="actor-avatar-fallback">${esc((a.name||actor?.name||'?').slice(0,1))}</div>`}<div><small>بازیگر / هنرمند</small><h1>${esc(a.name||actor?.name||'بازیگر')}</h1><p>${Number(a.count||items.length)} عنوان در فیلم‌شناسی</p></div></div></section><section class="actor-filmography"><div class="section-head"><div><h2>فیلم‌شناسی</h2><small>آثار مرتبط با ${esc(a.name||actor?.name||'')}</small></div></div>${items.length?`<div class="grid">${items.map(card).join('')}</div>`:'<div class="empty">اثری برای این بازیگر پیدا نشد.</div>'}</section></div>`;bindCards()}catch(e){renderError(e)}}

function renderDetail(d){
  const bg=cleanUrl(d.backdrop||d.background||d.poster||'');const poster=cleanUrl(d.poster||'');const links=dedupeSources(d.play?.links||d.downloads||d.links||[]);const related=d.related||[];const inList=state.watchlist.some(w=>watchKey(w)===watchKey(d));
  $('#view').innerHTML=`<div class="detail"><section class="detail-hero">${bg?`<div class="detail-bg" style="background-image:url('${esc(bg)}')"></div>`:''}<div class="detail-inner"><div class="detail-copy"><div class="eyebrow">BANKMOVIE</div><h1 class="detail-title">${esc(itemTitle(d))}</h1><div class="meta"><span class="chip imdb-detail-chip">${icon('imdb','imdb-detail-icon')}<b>${esc(itemRating(d)||'—')}</b></span><span class="chip">${esc(d.year||'')}</span><span class="chip">${d.type==='series'?'سریال':'فیلم'}</span>${(d.genres||[]).slice(0,4).map(g=>`<span class="chip">${esc(typeof g==='string'?g:(g.name||g.title||''))}</span>`).join('')}</div><p class="description">${esc(d.long_description||d.description||'توضیحی ثبت نشده است.')}</p><div class="actions"><button class="btn red" id="playBest">${icon('play')}<span>پخش</span></button><button class="btn ghost" id="watchBtn">${icon('bookmark')}<span>${inList?'حذف از لیست':'افزودن به لیست'}</span></button>${d.trailer_url?'<button class="btn ghost" id="trailerBtn">تریلر</button>':''}</div></div>${poster?`<img class="detail-poster" src="${esc(poster)}">`:''}</div></section><div class="detail-body">${actorsHtml(d)}<div class="tabs"><button class="tab active" data-detail-tab="sources">پخش و دانلود</button><button class="tab" data-detail-tab="comments">دیدگاه‌ها</button><button class="tab" data-detail-tab="info">اطلاعات</button></div><div id="detailTab">${renderSources(d,links)}</div>${related.length?`<section class="section"><div class="section-head"><div><h2>پیشنهادهای مشابه</h2></div><button class="link-btn" id="relatedSearch">جستجوی بیشتر ‹</button></div><div class="rail">${related.map(card).join('')}</div></section>`:''}</div></div>`;
  bindCards();$$('[data-actor]').forEach(b=>b.onclick=()=>{try{openActor(JSON.parse(decodeURIComponent(b.dataset.actor)))}catch(e){toast(e.message,'error')}});$('#watchBtn').onclick=()=>quickWatchlist(d,true);if($('#trailerBtn'))$('#trailerBtn').onclick=()=>{const u=trailerUrlOf(d);if(!u)return toast('تریلر برای این عنوان ثبت نشده','error');return bridge.openWeb?bridge.openWeb(u,itemTitle(d)+' • Trailer'):bridge.openExternal(u)};if($('#relatedSearch'))$('#relatedSearch').onclick=()=>showSearch(itemTitle(d));bindSourceButtons(d,links);$('#playBest').onclick=()=>{const pool=state.visibleSources?.length?state.visibleSources:links;const s=pool.find(x=>x.is_playable!==false&&x.url&&!x.is_folder)||pool.find(x=>x.url&&!x.is_folder);s?playSource(s):toast('لینک پخش موجود نیست','error')};$$('[data-detail-tab]').forEach(t=>t.onclick=()=>switchDetailTab(t.dataset.detailTab,d,links,t));
}


/* ===== BankMovie Desktop v1.7.0 VIP/Profile Sync ===== */
const _bm17SwitchArchive=switchArchive;
switchArchive=async function(next,context='home'){
  const n=Number(next);if(!enabledArchives().includes(n))return;
  if(!(await ensureVipAccess(n,'browse')))return;
  return _bm17SwitchArchive(n,context);
};
const _bm17ShowHome=showHome;
showHome=async function(force=false){
  if(archiveActionNeedsVip(state.archive,'browse')&&!isVip()){
    const fallback=enabledArchives().find(n=>!archiveActionNeedsVip(n,'browse'))||1;
    if(fallback!==state.archive){state.archive=fallback;await bridge.setSettings({preferredArchive:fallback});updateSearchPlaceholder();renderTopCategories()}
  }
  return _bm17ShowHome(force);
};
const _bm17ShowBrowseSection=showBrowseSection;
showBrowseSection=async function(archive,section,page=1){
  if(!(await ensureVipAccess(Number(archive)||1,'browse',section)))return;
  return _bm17ShowBrowseSection(archive,section,page);
};
const _bm17PlaySource=playSource;
playSource=async function(s){
  const archive=Number(s?.archive||state.currentDetail?.archive||state.archive)||1;
  if(!(await ensureVipAccess(archive,'stream')))return;
  return _bm17PlaySource(s);
};
const _bm17DownloadSource=downloadSource;
downloadSource=async function(s,d){
  const archive=Number(s?.archive||d?.archive||state.currentDetail?.archive||state.archive)||1;
  if(!(await ensureVipAccess(archive,'download')))return;
  return _bm17DownloadSource(s,d);
};
const _bm17SourceRow=sourceRow;
sourceRow=function(s,i,series=false){
  const archive=Number(s?.archive||state.currentDetail?.archive||state.archive)||1,streamLocked=archiveActionNeedsVip(archive,'stream')&&!isVip(),downloadLocked=archiveActionNeedsVip(archive,'download')&&!isVip();
  let html=_bm17SourceRow(s,i,series);
  if(streamLocked)html=html.replace(/(<button[^>]+source-play="[^"]+"[^>]*>)([\s\S]*?<span>)پخش(<\/span>)/,`$1${icon('vip')}$2پخش VIP$3`);
  if(downloadLocked)html=html.replace(/(<button[^>]+source-download="[^"]+"[^>]*>)([\s\S]*?<span>)دانلود(<\/span>)/,`$1${icon('vip')}$2دانلود VIP$3`);
  return html;
};
const _bm17ArchiveSwitcher=archiveSwitcherHtml;
archiveSwitcherHtml=function(active=state.archive,context='home'){
  const archives=enabledArchives();
  return `<div class="archive-hub ${context==='search'?'search-archive-hub':''}"><div class="archive-hub-copy"><strong>${esc(ARCHIVE_NAMES[active])}</strong><span>${esc(ARCHIVE_DESCRIPTIONS[active]||'')}</span></div><div class="archive-tabs">${archives.map(n=>{const p=archivePolicy(n),lock=archiveActionNeedsVip(n,'browse'),premium=lock||archiveActionNeedsVip(n,'stream')||archiveActionNeedsVip(n,'download');return `<button class="archive-tab ${n===active?'active':''} ${premium?'premium-archive':''}" data-archive-switch="${n}" data-context="${context}"><b>${esc(ARCHIVE_NAMES[n])}</b>${premium?`<small>${icon('vip')} VIP</small>`:''}</button>`}).join('')}</div></div>`;
};


/* ===== BankMovie Desktop v1.8.0 Archive/Privacy/Downloader Hotfix ===== */
function publicUiError(error){
  const raw=String(error?.message||error||'').trim();
  if(!raw)return 'خطایی رخ داد. دوباره تلاش کنید.';
  if(/\.php\b|https?:\/\/|bankmovie\.top|api\d*[_-]?lib|runtime|source[_ -]?unavailable|content:request/i.test(raw))
    return 'ارتباط با این بخش برقرار نشد. لطفاً دوباره تلاش کنید.';
  return raw.length>180?raw.slice(0,177)+'…':raw;
}
renderError=function(e){
  const msg=publicUiError(e);
  $('#view').innerHTML=`<div class="empty"><h3>ارتباط با این بخش انجام نشد</h3><p>${esc(msg)}</p><button class="btn ghost" id="retryBtn">تلاش دوباره</button></div>`;
  $('#retryBtn').onclick=()=>route(state.lastView,true);toast(msg,'error');
};

archivePolicy=function(no){
  const key=`archive${Number(no)}`;
  const desktop=state.config?.desktop?.archives?.[key]||{};
  const site=state.config?.app_archive_policy?.[key]||state.config?.archive_policy?.[key]||{};
  const merged={...desktop,...site}; // site/Android policy is authoritative
  const legacy=state.config?.features?.archives||{};
  if(legacy[`${key}_stream_vip`]===true)merged.stream_access_scope='vip';
  if(legacy[`${key}_download_vip`]===true)merged.download_access_scope='vip';
  if(legacy[`${key}_hidden`]===true)merged.hidden=true;
  if(legacy[`${key}_enabled`]===false)merged.enabled=false;
  return merged;
};

function parseApiTarget(raw,out){
  if(!raw)return out;
  try{
    const u=new URL(String(raw),'https://local.invalid');
    const arc=Number(u.searchParams.get('archive')||u.searchParams.get('arc')||0);
    if(arc>=1&&arc<=5)out.archive=arc;
    const id=u.searchParams.get('id')||u.searchParams.get('slug')||u.searchParams.get('imdb');
    if(id)out.id=id;
    const type=u.searchParams.get('type');
    if(type)out.type=/series|serial|tv/i.test(type)?'series':'movie';
  }catch{}
  return out;
}
sliderMediaItem=function(it){
  const out={
    ...it,
    archive:Number(it?.target_archive||it?.archive||1)||1,
    id:String(it?.target_id||'').trim(),
    type:it?.target_type||it?.type||'movie',
    poster:it?.poster||it?.image||''
  };
  parseApiTarget(it?.api_detail,out);
  const raw=String(it?.link_abs||it?.link||'').trim();
  if(raw){
    try{
      const u=new URL(raw,'https://local.invalid');
      const arc=Number(u.searchParams.get('arc')||u.searchParams.get('archive')||0);
      if(arc>=1&&arc<=5)out.archive=arc;
      const type=u.searchParams.get('type');if(type)out.type=/series|serial|tv/i.test(type)?'series':'movie';
      const qid=u.searchParams.get('slug')||u.searchParams.get('id')||u.searchParams.get('imdb');if(qid)out.id=qid;
      const p=decodeURIComponent(u.pathname||'');
      let m=p.match(/\/movie\/arc([1-5])-([^/?#]+)/i);
      if(m){out.archive=Number(m[1]);out.id=m[2]}
      else if((m=p.match(/\/(?:movie|series|serial)\/([^/?#]+)/i))){
        if(/series|serial/i.test(p))out.type='series';
        out.id=m[1];
      }
    }catch{}
  }
  return out;
};
async function openSliderItem(raw){
  const target=sliderMediaItem(raw);
  if(target.id){await openDetail(target);return}
  const title=itemTitle(raw);
  if(title){
    for(const archive of enabledArchives()){
      try{
        const r=await bridge.content('search',{archive,q:title,page:1,limit:8});
        const first=(r.items||r.results||[])[0];
        if(first){await openDetail(first);return}
      }catch{}
    }
  }
  toast('برای این اسلاید هنوز مقصد معتبری ثبت نشده است','error');
}
bindHeroSlider=function(sliders){
  if(state.heroTimer){clearInterval(state.heroTimer);state.heroTimer=null}
  state.heroIndex=0;activateHero(0,sliders);
  $$('[data-hero-open]').forEach(b=>b.onclick=()=>openSliderItem(sliders[Number(b.dataset.heroOpen)]));
  $$('[data-hero-search]').forEach(b=>b.onclick=()=>showSearch(itemTitle(sliders[Number(b.dataset.heroSearch)])));
  $$('[data-hero-dot]').forEach(b=>b.onclick=()=>activateHero(Number(b.dataset.heroDot),sliders));
  $$('[data-hero-thumb]').forEach(b=>b.onclick=()=>activateHero(Number(b.dataset.heroThumb),sliders));
  const prev=$('#heroPrev'),next=$('#heroNext');if(prev)prev.onclick=()=>activateHero(state.heroIndex-1,sliders);if(next)next.onclick=()=>activateHero(state.heroIndex+1,sliders);
  if(sliders.length>1)state.heroTimer=setInterval(()=>{if(state.lastView==='home')activateHero(state.heroIndex+1,sliders)},6500);
};

function collectionSectionHtml(items){
  if(!items?.length)return '';
  return `<section class="section home-collection-section"><div class="section-head"><div><h2>کالکشن‌ها</h2><small>مجموعه‌های منتخب BankMovie</small></div><button class="link-btn" data-home-collections>مشاهده همه ‹</button></div><div class="collection-home-rail">${items.map(collectionCard).join('')}</div></section>`;
}
const _bm18RenderHome=renderHome;
renderHome=function(payload){
  const {boot,rails,archive}=payload;const active=Number(archive||state.archive);
  const sliders=(Array.isArray(boot?.sliders)?boot.sliders:[]).slice().sort((a,b)=>Number(a?.order??a?.slide_order??0)-Number(b?.order??b?.slide_order??0)).slice(0,12);
  const thumbs=sliders.map((x,i)=>{const poster=cleanUrl(x.poster||x.thumb||x.image||x.backdrop||'');return `<button class="hero-thumb ${i===0?'active':''}" data-hero-thumb="${i}" aria-label="${esc(itemTitle(x))}">${poster?`<img src="${esc(poster)}" alt="${esc(itemTitle(x))}">`:`<span>BM</span>`}</button>`}).join('');
  const hero=sliders.length?`<section class="hero site-hero" dir="ltr"><div class="hero-stage">${sliders.map(heroSlide).join('')}</div>${sliders.length>1?`<button class="hero-arrow prev" id="heroPrev">${icon('back')}</button><button class="hero-arrow next" id="heroNext">${icon('back')}</button><div class="hero-thumbnails">${thumbs}</div><div class="hero-dots">${sliders.map((_,i)=>`<button class="hero-dot ${i===0?'active':''}" data-hero-dot="${i}"></button>`).join('')}</div>`:''}</section>`:'';
  const sections=rails.map(r=>r.sec==='collections'?collectionSectionHtml(r.items):sectionHtml(sectionLabel(r.sec),r.items,active,r.sec)).join('');
  $('#view').innerHTML=`${hero}<div class="home-content">${archiveSwitcherHtml(active,'home')}${archiveCategoryNavHtml(active)}${sections}</div>`;
  if(sliders.length)bindHeroSlider(sliders);bindCards();bindCollectionCards();bindArchiveSwitcher();renderTopCategories();
  $$('[data-home-category]').forEach(b=>b.onclick=()=>showBrowseSection(Number(b.dataset.archive),b.dataset.homeCategory,1));
  $$('[data-browse-section]').forEach(b=>b.onclick=()=>showBrowseSection(Number(b.dataset.archive),b.dataset.browseSection,1));
  const all=$('[data-home-collections]');if(all)all.onclick=()=>showCollections(1);
  $('#mainScroller').scrollTop=0;document.body.classList.remove('header-scrolled');
};

const _bm18DownloadSource=downloadSource;
downloadSource=async function(s,d){
  const archive=Number(s?.archive||d?.archive||state.currentDetail?.archive||state.archive)||1;
  if(!(await ensureVipAccess(archive,'download')))return;
  try{
    const ext=(()=>{try{const x=new URL(s.url).pathname.split('.').pop().split(/[?#]/)[0];return x&&x.length<6?x:'mp4'}catch{return'mp4'}})();
    const name=`${itemTitle(d)}${s.season?` - S${s.season}`:''}${s.episode?`E${s.episode}`:''} - ${sourceTypeLabel(s)} - ${s.quality||'video'}.${ext}`;
    const meta={url:s.url,fileName:name,title:itemTitle(d),quality:`${s.quality||''} ${sourceTypeLabel(s)}`.trim(),poster:d.poster||d.image||'',season:s.season||null,episode:s.episode||null,mediaType:d.type==='series'?'series':'movie',archive};
    const r=await bridge.download(meta);
    if(r?.id&&!state.downloads.has(r.id))state.downloads.set(r.id,{...meta,id:r.id,state:'queued',received:0,total:0,paused:false,at:Date.now()});
    toast('دانلود شروع شد','ok');bm194SetDownloadCount(String(Math.max(1,[...state.downloads.values()].filter(x=>!['completed','cancelled','interrupted'].includes(x.state)).length)));
  }catch(e){toast(publicUiError(e),'error')}
};

function speedText(bytesPerSec){
  const n=Number(bytesPerSec||0);if(n<=0)return 'در حال محاسبه سرعت…';
  return `${fmtBytes(n)}/s`;
}
function etaText(seconds){
  const s=Math.max(0,Math.round(Number(seconds)||0));if(!s||!Number.isFinite(s))return '';
  if(s<60)return `${s} ثانیه`;
  if(s<3600)return `${Math.ceil(s/60)} دقیقه`;
  return `${Math.floor(s/3600)} ساعت ${Math.ceil((s%3600)/60)} دقیقه`;
}
onDownloadUpdate=function(d){
  const prev=state.downloads.get(d.id)||{};
  const now=Number(d.at||Date.now()),prevAt=Number(prev._sampleAt||prev.at||now),prevBytes=Number(prev._sampleBytes??prev.received??0);
  const deltaT=Math.max(.05,(now-prevAt)/1000),deltaB=Math.max(0,Number(d.received||0)-prevBytes);
  const instant=deltaB/deltaT;
  const oldSpeed=Number(prev.speed||0);const speed=instant>0?(oldSpeed>0?(oldSpeed*.68+instant*.32):instant):oldSpeed;
  const total=Number(d.total||prev.total||0),received=Number(d.received||0);const eta=speed>0&&total>received?(total-received)/speed:0;
  const merged={...prev,...d,speed,eta,_sampleAt:now,_sampleBytes:received};
  state.downloads.set(d.id,merged);
  const active=[...state.downloads.values()].filter(x=>!['completed','cancelled','interrupted'].includes(x.state)).length;
  bm194SetDownloadCount(active?String(active):'');
  if(state.lastView==='downloads')renderDownloads();
};
function downloadStateLabel(d){
  if(d.state==='completed')return 'کامل شد';
  if(d.state==='cancelled')return 'لغو شد';
  if(d.state==='interrupted')return 'متوقف شد';
  if(d.paused)return 'مکث';
  if(d.state==='queued')return 'در صف';
  if(d.state==='starting')return 'در حال شروع';
  return 'در حال دانلود';
}
function downloadRowV18(d){
  const p=pct(d.received,d.total),poster=cleanUrl(d.poster||'');
  const ep=d.mediaType==='series'?`فصل ${d.season||'—'}${d.episode?` • قسمت ${d.episode}`:''}`:'فیلم';
  const active=!['completed','cancelled','interrupted'].includes(d.state);
  return `<article class="download-card-v18 ${d.state==='completed'?'done':''} ${d.state==='cancelled'?'cancelled':''}">
    <div class="download-poster-v18">${poster?img(poster,d.title||'', 'download-poster-img'):'<div class="poster-fallback">BM</div>'}<span>${d.mediaType==='series'?'سریال':'فیلم'}</span></div>
    <div class="download-main-v18">
      <div class="download-title-v18"><div><strong>${esc(d.title||d.fileName||'دانلود')}</strong><small>${esc(ep)}${d.quality?` • ${esc(d.quality)}`:''}</small></div><span class="download-state-v18">${esc(downloadStateLabel(d))}</span></div>
      <div class="progress download-progress-v18"><i style="width:${p}%"></i></div>
      <div class="download-stats-v18"><span>${p}%</span><span>${fmtBytes(d.received)} / ${fmtBytes(d.total)}</span>${active?`<span>${speedText(d.speed)}</span>${d.eta?`<span>باقی‌مانده ${etaText(d.eta)}</span>`:''}`:''}</div>
    </div>
    <div class="download-actions-v18">
      ${active&&!d.paused?`<button class="btn ghost slim" data-dl-action="pause" data-id="${esc(d.id)}">مکث</button>`:''}
      ${active&&d.paused?`<button class="btn primary slim" data-dl-action="resume" data-id="${esc(d.id)}">ادامه</button>`:''}
      ${active?`<button class="btn danger-soft slim" data-dl-action="cancel" data-id="${esc(d.id)}">لغو</button>`:''}
      ${d.state==='completed'&&d.savePath?`<button class="btn primary slim" data-open-file="${esc(d.savePath)}">باز کردن</button><button class="btn ghost slim" data-show-file="${esc(d.savePath)}">نمایش پوشه</button>`:''}
    </div>
  </article>`;
}
function downloadGroupV18(title,items){
  return `<section class="download-group-v18"><div class="download-group-head"><h2>${esc(title)}</h2><span>${items.length.toLocaleString('fa-IR')} مورد</span></div>${items.length?`<div class="download-list-v18">${items.map(downloadRowV18).join('')}</div>`:'<div class="empty small-empty">موردی در این بخش نیست.</div>'}</section>`;
}
renderDownloads=function(){
  const arr=[...state.downloads.values()].sort((a,b)=>Number(b.at||b.queuedAt||0)-Number(a.at||a.queuedAt||0));
  const series=arr.filter(x=>x.mediaType==='series'),movies=arr.filter(x=>x.mediaType!=='series');
  const active=arr.filter(x=>!['completed','cancelled','interrupted'].includes(x.state)).length;
  $('#view').innerHTML=`<div class="downloads-page-v18"><div class="page-title"><div><h1>مدیریت دانلود</h1><p>فیلم و سریال جدا، کنترل لحظه‌ای، سرعت و وضعیت کامل</p></div><div class="download-head-actions"><span class="chip">${active.toLocaleString('fa-IR')} فعال</span><button class="btn ghost" id="chooseFolder">تغییر پوشه</button></div></div>${downloadGroupV18('سریال‌ها',series)}${downloadGroupV18('فیلم‌ها',movies)}</div>`;
  $('#chooseFolder').onclick=async()=>{state.settings.downloadDir=await bridge.chooseDownloadDir();toast('پوشه دانلود تغییر کرد','ok')};
  $$('[data-dl-action]').forEach(b=>b.onclick=async()=>{
    b.disabled=true;
    const ok=await bridge.downloadAction(b.dataset.id,b.dataset.dlAction);
    if(!ok)toast('این دانلود دیگر در صف فعال نیست','error');
    setTimeout(()=>{if(document.body.contains(b))b.disabled=false},300);
  });
  $$('[data-show-file]').forEach(b=>b.onclick=()=>bridge.showItem(b.dataset.showFile));
  $$('[data-open-file]').forEach(b=>b.onclick=()=>bridge.openFile?bridge.openFile(b.dataset.openFile):bridge.showItem(b.dataset.openFile));
};
showDownloads=function(){setActiveNav('downloads');renderDownloads()};

showAvatarModal=async function(){
  const avatars=state.userConfig?.avatars||[],selected=state.user?.avatar_key||'';
  openModal(`<div class="avatar-picker-v17"><button class="vip-modal-close" data-close-avatar>×</button><div class="avatar-picker-head-v17"><div>${icon('user')}</div><span><h2>انتخاب آواتار</h2><p>انتخابت فوراً روی حساب ذخیره و بین دستگاه‌ها همگام می‌شود.</p></span></div><div class="avatar-grid-v17">${avatars.length?avatars.map(a=>`<button class="avatar-choice-v17 ${a.key===selected?'selected':''}" data-avatar="${esc(a.key)}">${cleanUrl(a.url)?`<img src="${esc(a.url)}" alt="${esc(a.label||a.key)}" loading="eager" decoding="async">`:''}<strong>${esc(a.label||a.key)}</strong>${a.key===selected?'<i>انتخاب‌شده</i>':''}</button>`).join(''):'<div class="avatar-inline-loading">در حال دریافت آواتارها…</div>'}</div>${state.user?.can_upload_avatar?`<div class="custom-avatar-v17"><div><b>آواتار اختصاصی VIP</b><small>PNG / JPG / WEBP / GIF تا ۴ مگابایت</small></div><label class="btn vip-buy"><input type="file" id="avatarFile" accept="image/png,image/jpeg,image/webp,image/gif" hidden>${icon('vip')}<span>آپلود تصویر شخصی</span></label></div>`:'<div class="custom-avatar-v17 locked"><div><b>آواتار اختصاصی</b><small>آپلود تصویر شخصی فقط برای اعضای VIP فعال است.</small></div><button class="btn ghost" id="avatarVipBtn">VIP</button></div>'}</div>`,true);
  $('[data-close-avatar]').onclick=closeModal;
  const bindChoices=()=>$$('[data-avatar]').forEach(b=>b.onclick=async()=>{try{b.disabled=true;const r=await bridge.user('avatar_update',{avatar_key:b.dataset.avatar},'POST');state.user=r.user;updateProfile();closeModal();toast('آواتار همگام شد','ok');if(state.lastView==='profile')renderProfile()}catch(e){b.disabled=false;toast(publicUiError(e),'error')}});
  bindChoices();
  if(!avatars.length){
    loadUserConfig().then(()=>{if($('#modal').classList.contains('hidden'))return;showAvatarModal()}).catch(()=>{});
  }
  if($('#avatarVipBtn'))$('#avatarVipBtn').onclick=showVipPlansModal;
  if($('#avatarFile'))$('#avatarFile').onchange=e=>{const f=e.target.files?.[0];if(!f)return;const rd=new FileReader();rd.onload=async()=>{try{const r=await bridge.user('avatar_upload',{image_base64:rd.result},'POST');state.user=r.user;updateProfile();closeModal();toast('آواتار اختصاصی همگام شد','ok');if(state.lastView==='profile')renderProfile()}catch(err){toast(publicUiError(err),'error')}};rd.readAsDataURL(f)};
};

showSettings=async function(){
  setActiveNav('settings');state.settings=await bridge.getSettings();state.players=await bridge.getPlayers();
  const playerOptions=`<option value="auto">خودکار (پیشنهادی)</option>${state.players.map(p=>`<option value="${esc(p.id)}" ${state.settings.preferredPlayer===p.id?'selected':''}>${esc(p.name)}</option>`).join('')}`;
  const playerStatus=state.players.length?state.players.map(p=>`<span class="chip">${esc(p.name)}</span>`).join(''):'<span class="chip">پلیر سازگار نصب نشده</span>';
  $('#view').innerHTML=`<div class="page-title"><div><h1>تنظیمات</h1><p>نسخه ${esc(state.appVersion||'')}</p></div></div><div class="settings-grid"><div class="panel"><h3>پخش</h3><div class="field"><label>پلیر خارجی</label><select id="preferredPlayer">${playerOptions}</select><small>انتخاب خودکار بر اساس پلیرهای نصب‌شده روی ویندوز</small></div><div class="meta">${playerStatus}</div></div><div class="panel"><h3>دانلود</h3><div class="field"><label>پوشه دانلود</label><input id="downloadDir" value="${esc(state.settings.downloadDir||'')}" readonly></div><button class="btn ghost" id="chooseDir" style="margin-top:10px">انتخاب پوشه</button></div><div class="panel"><h3>ظاهر و تجربه کاربری</h3><p class="settings-safe-copy">تنظیمات شبکه و کلیدهای سرویس در رابط کاربری نمایش داده نمی‌شوند.</p><div class="actions"><button class="btn primary" id="saveSettings">ذخیره تنظیمات</button></div></div></div>`;
  $('#chooseDir').onclick=async()=>{$('#downloadDir').value=await bridge.chooseDownloadDir()};
  $('#saveSettings').onclick=async()=>{state.settings=await bridge.setSettings({preferredPlayer:$('#preferredPlayer').value});toast('تنظیمات ذخیره شد','ok')};
};


/* ===== BankMovie Desktop v1.9.0 Live Downloader / Fast Comments / Trailer Fix ===== */
let bm19DownloadPollTimer=null;
let bm19CommentsSeq=0;
let bm19CommentsLoadedKey='';
let bm19CommentsLoading=false;

async function bm19SyncDownloads(){
  if(typeof bridge.downloads!=='function')return;
  try{
    const rows=await bridge.downloads();
    if(!Array.isArray(rows))return;
    for(const row of rows){
      if(!row?.id)continue;
      const prev=state.downloads.get(row.id)||{};
      state.downloads.set(row.id,{...prev,...row});
    }
    const active=[...state.downloads.values()].filter(x=>!['completed','cancelled','interrupted'].includes(x.state)).length;
    bm194SetDownloadCount(active?String(active):'');
    if(state.lastView==='downloads')bm19RenderDownloadsNow();
  }catch{}
}
function bm19StopDownloadPoll(){
  if(bm19DownloadPollTimer){clearInterval(bm19DownloadPollTimer);bm19DownloadPollTimer=null}
}
function bm19StartDownloadPoll(){
  bm19StopDownloadPoll();
  bm19SyncDownloads();
  bm19DownloadPollTimer=setInterval(()=>{if(state.lastView==='downloads')bm19SyncDownloads();else bm19StopDownloadPoll()},700);
}
const _bm19SetActiveNav=setActiveNav;
setActiveNav=function(view){
  if(view!=='downloads')bm19StopDownloadPoll();
  return _bm19SetActiveNav(view);
};

onDownloadUpdate=function(d){
  if(!d?.id)return;
  const prev=state.downloads.get(d.id)||{};
  // Main process is authoritative and already computes a live transfer speed.
  // Merge it directly instead of going through the legacy renderer handler,
  // which used to trigger two full repaints per progress event.
  const merged={...prev,...d};
  const speed=Number(d.speed||prev.speed||0);
  const total=Number(d.total||prev.total||0),received=Number(d.received||prev.received||0);
  merged.speed=speed;
  merged.eta=speed>0&&total>received?(total-received)/speed:0;
  state.downloads.set(d.id,merged);
  const active=[...state.downloads.values()].filter(x=>!['completed','cancelled','interrupted'].includes(x.state)).length;
  bm194SetDownloadCount(active?String(active):'');
  if(state.lastView==='downloads')requestAnimationFrame(bm19RenderDownloadsNow);
};

function bm19ApplyOptimisticDownloadAction(id,action){
  const d=state.downloads.get(id);if(!d)return;
  if(action==='pause')state.downloads.set(id,{...d,paused:true,state:'progressing',at:Date.now()});
  if(action==='resume')state.downloads.set(id,{...d,paused:false,state:'progressing',at:Date.now()});
  if(action==='cancel')state.downloads.set(id,{...d,paused:false,state:'cancelled',finishedAt:Date.now(),at:Date.now()});
}
function bm19RenderDownloadsNow(){
  if(state.lastView!=='downloads')return;
  const scroller=$('#mainScroller');
  const keepTop=scroller?scroller.scrollTop:0;
  const arr=[...state.downloads.values()].sort((a,b)=>Number(b.at||b.queuedAt||0)-Number(a.at||a.queuedAt||0));
  const series=arr.filter(x=>x.mediaType==='series'),movies=arr.filter(x=>x.mediaType!=='series');
  const active=arr.filter(x=>!['completed','cancelled','interrupted'].includes(x.state)).length;
  $('#view').innerHTML=`<div class="downloads-page-v18 downloads-page-v19"><div class="page-title"><div><h1>مدیریت دانلود</h1><p>وضعیت زنده، کنترل فوری و تفکیک فیلم و سریال</p></div><div class="download-head-actions"><span class="chip live-chip"><i></i>${active.toLocaleString('fa-IR')} فعال</span><button class="btn ghost" id="chooseFolder">تغییر پوشه</button></div></div>${downloadGroupV18('سریال‌ها',series)}${downloadGroupV18('فیلم‌ها',movies)}</div>`;
  const choose=$('#chooseFolder');if(choose)choose.onclick=async()=>{state.settings.downloadDir=await bridge.chooseDownloadDir();toast('پوشه دانلود تغییر کرد','ok')};
  $$('[data-dl-action]').forEach(b=>b.onclick=async()=>{
    const id=b.dataset.id,action=b.dataset.dlAction;
    bm19ApplyOptimisticDownloadAction(id,action);
    bm19RenderDownloadsNow();
    try{
      const snapshot=await bridge.downloadAction(id,action);
      if(snapshot?.id){
        const prev=state.downloads.get(snapshot.id)||{};
        state.downloads.set(snapshot.id,{...prev,...snapshot});
        bm19RenderDownloadsNow();
      }else if(!snapshot){
        toast('این دانلود دیگر فعال نیست','error');
        await bm19SyncDownloads();
      }
    }catch(e){
      toast(publicUiError(e),'error');
      await bm19SyncDownloads();
    }
  });
  $$('[data-show-file]').forEach(b=>b.onclick=()=>bridge.showItem(b.dataset.showFile));
  $$('[data-open-file]').forEach(b=>b.onclick=()=>bridge.openFile?bridge.openFile(b.dataset.openFile):bridge.showItem(b.dataset.openFile));
  if(scroller)scroller.scrollTop=keepTop;
}
renderDownloads=bm19RenderDownloadsNow;
showDownloads=async function(){
  setActiveNav('downloads');
  await bm19SyncDownloads();
  bm19RenderDownloadsNow();
  bm19StartDownloadPoll();
};

downloadSource=async function(s,d){
  const archive=Number(s?.archive||d?.archive||state.currentDetail?.archive||state.archive)||1;
  if(!(await ensureVipAccess(archive,'download')))return;
  try{
    const ext=(()=>{try{const x=new URL(s.url).pathname.split('.').pop().split(/[?#]/)[0];return x&&x.length<6?x:'mp4'}catch{return'mp4'}})();
    const name=`${itemTitle(d)}${s.season?` - S${s.season}`:''}${s.episode?`E${s.episode}`:''} - ${sourceTypeLabel(s)} - ${s.quality||'video'}.${ext}`;
    const r=await bridge.download({
      url:s.url,fileName:name,title:itemTitle(d),
      quality:`${s.quality||''} ${sourceTypeLabel(s)}`.trim(),
      poster:d.poster||d.image||'',season:s.season||null,episode:s.episode||null,
      mediaType:d.type==='series'?'series':'movie',archive
    });
    if(r?.id){
      const base={id:r.id,url:s.url,fileName:name,title:itemTitle(d),quality:`${s.quality||''} ${sourceTypeLabel(s)}`.trim(),poster:d.poster||d.image||'',season:s.season||null,episode:s.episode||null,mediaType:d.type==='series'?'series':'movie',archive,state:'queued',received:0,total:0,paused:false,queuedAt:Date.now()};
      state.downloads.set(r.id,{...base,...(r.state||{})});
      bm194SetDownloadCount(String(Math.max(1,[...state.downloads.values()].filter(x=>!['completed','cancelled','interrupted'].includes(x.state)).length)));
    }
    // Avoid a second "started" toast here. The main process owns native start /
    // completion notifications and the download row shows the live state.
  }catch(e){toast(publicUiError(e),'error')}
};

function bm19PendingCommentHtml(c){
  return `<div class="comment pending-comment" data-pending-comment="${esc(c._pendingId)}"><div class="comment-head"><strong>${esc(c.username||'شما')}</strong><span>در حال ارسال…</span></div><p>${esc(c.comment||'')}</p><div class="comment-send-state"><i></i> ارسال در پس‌زمینه</div></div>`;
}
const _bm19CommentHtml=commentHtml;
commentHtml=function(c,depth=0){
  if(c?._pendingId)return bm19PendingCommentHtml(c);
  return _bm19CommentHtml(c,depth);
};
const _bm19RenderCommentsBox=renderCommentsBox;
renderCommentsBox=function(d){
  const box=$('#detailTab');
  box.innerHTML=`${state.user?`<div class="comment-form"><textarea class="form-control" id="commentText" placeholder="دیدگاهت را بنویس…"></textarea><button class="btn primary" id="sendComment">ارسال</button></div>`:'<div class="panel" style="margin-bottom:10px">برای ثبت دیدگاه وارد حساب شو.</div>'}<div id="commentsList" class="comments">${commentsCache.length?commentsCache.map(c=>commentHtml(c,0)).join(''):'<div class="empty">هنوز دیدگاهی ثبت نشده است.</div>'}</div>`;
  if($('#sendComment'))$('#sendComment').onclick=()=>{
    const input=$('#commentText'),text=input.value.trim();
    if(text.length<3)return toast('متن دیدگاه کوتاه است','error');
    input.value='';
    const pendingId=`pending-${Date.now()}-${++bm19CommentsSeq}`;
    const pending={_pendingId:pendingId,username:state.user?.username||'شما',comment:text,date_text:'',like_count:0,dislike_count:0};
    commentsCache=[pending,...commentsCache];
    renderCommentsBox(d);
    toast('دیدگاه در حال ارسال است','ok');
    bridge.user('comment_add',{item:d,comment:text,rating:0,spoiler:0},'POST').then(async()=>{
      // Remove the optimistic row immediately; refresh in the background without
      // blocking the user on a second API round-trip.
      commentsCache=commentsCache.filter(x=>x._pendingId!==pendingId);
      if(state.currentDetail&&watchKey(state.currentDetail)===watchKey(d)){
        renderCommentsBox(d);
      }
      toast('دیدگاه ثبت شد','ok');
      try{
        await loadComments(d);
        bm19CommentsLoadedKey=watchKey(d);
        if(state.currentDetail&&watchKey(state.currentDetail)===watchKey(d)&&$('#detailTab'))renderCommentsBox(d);
      }catch{}
    }).catch(e=>{
      const row=commentsCache.find(x=>x._pendingId===pendingId);
      if(row){row._pendingId='';row.pending_failed=true;row.date_text='ارسال ناموفق';}
      if(state.currentDetail&&watchKey(state.currentDetail)===watchKey(d))renderCommentsBox(d);
      toast(publicUiError(e),'error');
    });
  };
  $$('[data-comment-action]').forEach(b=>b.onclick=()=>commentAction(b.dataset.commentAction,Number(b.dataset.commentId),b.dataset.commentText||'',d));
  // Fetch comments after the UI is already visible. This removes the perceived
  // 20–30 second freeze on slower account APIs.
  const currentKey=watchKey(d);
  if(bm19CommentsLoadedKey!==currentKey && !bm19CommentsLoading){
    bm19CommentsLoading=true;
    Promise.resolve().then(()=>loadComments(d)).then(()=>{
      bm19CommentsLoadedKey=currentKey;
      if(state.currentDetail&&watchKey(state.currentDetail)===currentKey&&$('#detailTab'))renderCommentsBox(d);
    }).catch(()=>{}).finally(()=>{bm19CommentsLoading=false});
  }
};

// Pull an authoritative snapshot after startup as well. This keeps the badge and
// download state correct even when the first event arrived before the UI bound.
document.addEventListener('DOMContentLoaded',()=>setTimeout(bm19SyncDownloads,1200));


/* ===== BankMovie Desktop v1.9.1 — English / Settings / Uiverse control pass ===== */
const BM191_LANG_KEY='bankmovie_language_v2';
let bm191Language='fa';
const bm191TextOriginal=new WeakMap();
const bm191AttrOriginal=new WeakMap();
const BM191_FA_EN={
  'خانه':'Home','کالکشن‌ها':'Collections','دسته‌بندی':'Categories','ژانرها':'Genres','باکس آفیس':'Box Office',
  '۲۵۰ فیلم برتر IMDb':'IMDb Top 250 Movies','۲۵۰ سریال برتر IMDb':'IMDb Top 250 Series','برترین فیلم‌ها':'Top movies','برترین سریال‌ها':'Top series','مجموعه‌های دنباله‌دار':'Collections',
  'لیست من':'My List','اعلان‌ها':'Notifications','تنظیمات':'Settings','حساب کاربری':'Account','ورود / ثبت‌نام':'Sign in / Register',
  'پخش':'Play','دانلود':'Download','پخش و دانلود':'Play & Download','دیدگاه‌ها':'Comments','اطلاعات':'Information','تریلر':'Trailer',
  'افزودن به لیست':'Add to My List','حذف از لیست':'Remove from My List','پیشنهادهای مشابه':'More Like This','جستجوی بیشتر ‹':'Search more ‹',
  'عنوان اصلی':'Original title','سال':'Year','زبان':'Language','کشور':'Country','شبکه':'Network','مدت':'Runtime',
  'فصل':'Season','قسمت':'Episode','ویژه':'Special','قسمت ویژه':'Special episode','سریال':'Series','فیلم':'Movie',
  'دیدگاهت را بنویس…':'Write a comment…','ارسال':'Send','پاسخ':'Reply','گزارش':'Report','ویرایش':'Edit','حذف':'Delete','پین':'Pin','برداشتن پین':'Unpin',
  'هنوز دیدگاهی ثبت نشده است.':'No comments yet.','برای ثبت دیدگاه وارد حساب شو.':'Sign in to post a comment.',
  'مدیریت دانلود':'Download Manager','وضعیت زنده، کنترل فوری و تفکیک فیلم و سریال':'Live status, instant controls, separated movies and series',
  'سریال‌ها':'Series','فیلم‌ها':'Movies','تغییر پوشه':'Change folder','باز کردن':'Open','نمایش پوشه':'Show in folder','مکث':'Pause','ادامه':'Resume','لغو':'Cancel',
  'کامل شد':'Completed','لغو شد':'Cancelled','متوقف شد':'Interrupted','در صف':'Queued','در حال شروع':'Starting','در حال دانلود':'Downloading',
  'تنظیمات پخش':'Playback settings','زبان و ظاهر':'Language & Appearance','پوشه دانلود':'Download folder','انتخاب پوشه':'Choose folder',
  'پلیر خارجی':'External player','خودکار (پیشنهادی)':'Auto (Recommended)','پلیر پیشنهادی':'Recommended player','پلیرهای شناسایی‌شده':'Detected players',
  'انتخاب خودکار بهترین پلیر نصب‌شده را بر اساس سازگاری و زیرنویس انجام می‌دهد.':'Auto selects the best installed player based on compatibility and subtitle support.',
  'فارسی':'Persian','انگلیسی':'English','زبان رابط':'Interface language','تم برنامه':'App theme','روشن':'Light','تیره':'Dark',
  'ذخیره تنظیمات':'Save settings','ظاهر و تجربه کاربری':'Appearance & experience','قابلیت‌های فعال':'Enabled features','آرشیوها':'Archives',
  'هیچ پلیر سازگاری پیدا نشد':'No supported player detected','هیچ پلیر پشتیبانی‌شده‌ای پیدا نشد':'No supported player detected',
  'جستجو':'Search','جستجو…':'Search…','جستجو در BankMovie…':'Search BankMovie…','جستجوی مشابه':'Find similar','مشاهده':'View','مشاهده همه':'View all',
  'در حال آماده‌سازی BankMovie…':'Preparing BankMovie…','ارتباط با سرور انجام نشد':'Could not connect to server','تلاش دوباره':'Try again',
  'پروفایل':'Profile','بازدیدهای اخیر':'Recent views','خرید / تمدید اشتراک':'Buy / Renew subscription','خرید اشتراک':'Buy subscription',
  'انتخاب آواتار':'Choose avatar','آپلود تصویر شخصی':'Upload custom image','انتخاب‌شده':'Selected','در حال دریافت آواتارها…':'Loading avatars…',
  'کالکشن':'Collection','مشاهده کالکشن':'View collection','فیلم‌شناسی':'Filmography','بازیگران':'Cast','بازیگر / هنرمند':'Actor / Artist',
  'فعال':'Active','مورد':'item','قبلی':'Previous','بعدی':'Next','صفحه':'Page','عنوان':'title'
};
function bm191TranslateText(raw){
  const lead=raw.match(/^\s*/)?.[0]||'',trail=raw.match(/\s*$/)?.[0]||'',t=raw.trim();
  if(!t)return raw;
  if(BM191_FA_EN[t])return lead+BM191_FA_EN[t]+trail;
  let m;
  if((m=t.match(/^فصل\s+([۰-۹0-9]+)$/)))return `${lead}Season ${m[1]}${trail}`;
  if((m=t.match(/^قسمت\s+([۰-۹0-9]+)$/)))return `${lead}Episode ${m[1]}${trail}`;
  if((m=t.match(/^فصل\s+([۰-۹0-9]+)\s*•\s*قسمت\s+([۰-۹0-9]+)$/)))return `${lead}Season ${m[1]} • Episode ${m[2]}${trail}`;
  if((m=t.match(/^صفحه\s+([۰-۹0-9]+)$/)))return `${lead}Page ${m[1]}${trail}`;
  if((m=t.match(/^([۰-۹0-9,]+)\s+عنوان$/)))return `${lead}${m[1]} titles${trail}`;
  if((m=t.match(/^([۰-۹0-9,]+)\s+مورد$/)))return `${lead}${m[1]} items${trail}`;
  if((m=t.match(/^([۰-۹0-9,]+)\s+فعال$/)))return `${lead}${m[1]} active${trail}`;
  if((m=t.match(/^باقی‌مانده\s+(.+)$/)))return `${lead}Remaining ${m[1]}${trail}`;
  if((m=t.match(/^نسخه\s+(.+)$/)))return `${lead}Version ${m[1]}${trail}`;
  return raw;
}
function bm191Localize(root=document.body){
  if(!root)return;
  const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode(n){
    const p=n.parentElement;if(!p||['SCRIPT','STYLE','TEXTAREA'].includes(p.tagName))return NodeFilter.FILTER_REJECT;
    return n.nodeValue?.trim()?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT;
  }});
  const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);
  for(const n of nodes){if(!bm191TextOriginal.has(n))bm191TextOriginal.set(n,n.nodeValue);const original=bm191TextOriginal.get(n);n.nodeValue=bm191Language==='en'?bm191TranslateText(original):original;}
  root.querySelectorAll?.('[placeholder],[title],[aria-label]').forEach(el=>{
    if(!bm191AttrOriginal.has(el))bm191AttrOriginal.set(el,{});
    const store=bm191AttrOriginal.get(el);
    for(const a of ['placeholder','title','aria-label'])if(el.hasAttribute(a)){
      if(store[a]===undefined)store[a]=el.getAttribute(a);
      el.setAttribute(a,bm191Language==='en'?bm191TranslateText(store[a]):store[a]);
    }
  });
}
function applyLanguage(lang){
  bm191Language=lang==='en'?'en':'fa';state.language=bm191Language;
  document.documentElement.lang=bm191Language;document.documentElement.dir=bm191Language==='en'?'ltr':'rtl';document.documentElement.dataset.lang=bm191Language;
  try{localStorage.setItem(BM191_LANG_KEY,bm191Language)}catch{}
  bm191Localize(document.body);
}
function bm191ThemeSwitchHtml(){return `<label class="theme-switch settings-theme-switch" title="تم برنامه"><input class="theme-switch__checkbox" id="settingsThemeSwitch" type="checkbox" ${state.theme==='dark'?'checked':''}/><div class="theme-switch__container"><div class="theme-switch__clouds"></div><div class="theme-switch__stars-container"><svg fill="none" viewBox="0 0 144 55" xmlns="http://www.w3.org/2000/svg"><path fill="currentColor" d="M135.831 3.00688C135.055 3.85027 134.111 4.29946 133 4.35447C134.111 4.40947 135.055 4.85867 135.831 5.71123C136.607 6.55462 136.996 7.56303 136.996 8.72727C136.996 7.95722 137.172 7.25134 137.525 6.59129C137.886 5.93124 138.372 5.39954 138.98 5.00535C139.598 4.60199 140.268 4.39114 141 4.35447C139.88 4.2903 138.936 3.85027 138.16 3.00688C137.384 2.16348 136.996 1.16425 136.996 0C136.996 1.16425 136.607 2.16348 135.831 3.00688Z"/></svg></div><div class="theme-switch__circle-container"><div class="theme-switch__sun-moon-container"><div class="theme-switch__moon"><div class="theme-switch__spot"></div><div class="theme-switch__spot"></div><div class="theme-switch__spot"></div></div></div></div><div class="theme-switch__shooting-star"></div><div class="theme-switch__shooting-star-2"></div><div class="theme-switch__meteor"></div><div class="theme-switch__stars-cluster"><div class="star"></div><div class="star"></div><div class="star"></div><div class="star"></div><div class="star"></div></div><div class="theme-switch__aurora"></div><div class="theme-switch__comets"><div class="comet"></div><div class="comet"></div></div></div></label>`}
function bm191PauseIcon(){return `<svg viewBox="0 0 24 24" fill="none"><path d="M2 6C2 4.114 2 3.172 2.586 2.586C3.172 2 4.114 2 6 2s2.828 0 3.414.586C10 3.172 10 4.114 10 6v12c0 1.886 0 2.828-.586 3.414C8.828 22 7.886 22 6 22s-2.828 0-3.414-.586C2 20.828 2 19.886 2 18V6Z" stroke="currentColor" stroke-width="1.5"/><path opacity=".5" d="M14 6c0-1.886 0-2.828.586-3.414C15.172 2 16.114 2 18 2s2.828 0 3.414.586C22 3.172 22 4.114 22 6v12c0 1.886 0 2.828-.586 3.414C20.828 22 19.886 22 18 22s-2.828 0-3.414-.586C14 20.828 14 19.886 14 18V6Z" stroke="currentColor" stroke-width="1.5"/></svg>`}
function bm191BinIcon(){return `<span class="bm-bin-icon"><svg class="bin-top" viewBox="0 0 39 7" fill="none"><line y1="5" x2="39" y2="5" stroke="currentColor" stroke-width="4"/><line x1="12" y1="1.5" x2="26.0357" y2="1.5" stroke="currentColor" stroke-width="3"/></svg><svg class="bin-bottom" viewBox="0 0 33 39" fill="none"><path d="M4 2h25v33a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4V2Z" stroke="currentColor" stroke-width="4"/><path d="M12 8v23M21 8v23" stroke="currentColor" stroke-width="4"/></svg></span>`}
function bm191FeedbackSvg(kind){return kind==='like'?`<svg class="icon" viewBox="0 0 27 27" fill="currentColor"><path fill-rule="evenodd" clip-rule="evenodd" d="M.723 26.5h5.2V10.901h-5.2V26.5Zm25.907-11.238-2.258 8.495A3.555 3.555 0 0 1 20.907 26.5H8.523V10.928l2.234-8.055A2.798 2.798 0 0 1 16.323 3.3v7.6h6.842c2.287.001 3.98 2.134 3.465 4.362Z"/></svg>`:`<svg class="icon" viewBox="0 0 27 27" fill="currentColor"><path fill-rule="evenodd" clip-rule="evenodd" d="M26.723.5h-5.2v15.599h5.2V.5ZM.816 11.738l2.258-8.495A3.555 3.555 0 0 1 6.539.5h12.384v15.572l-2.235 8.055a2.798 2.798 0 0 1-5.565-.425v-7.6H4.281c-2.287-.001-3.98-2.134-3.465-4.364Z"/></svg>`}

// Source row: supplied animated Download CTA.
sourceRow=function(s,i,series=false){
  const sub=subtitleUrlOf(s),label=sourceTypeLabel(s),playable=s.is_playable!==false&&!!s.url&&!s.is_folder,downloadable=s.is_download!==false&&!!s.url;
  const t=String(s?.type||'').toLowerCase(),isDub=/dub|audio/.test(t)||/دوبله|صوت/.test(label),hasSub=sub||/softsub|hardsub|subtitle/.test(t)||/زیرنویس|ساب/.test(label);
  const kindIcon=isDub?icon('mic','source-kind-icon'):hasSub?icon('subtitle','source-kind-icon'):'';
  const meta=[s.size||'',sub&&!/سافت|هارد|زیرنویس|ساب/.test(label)?'زیرنویس جداگانه':'',s.is_folder?'پوشه':''].filter(Boolean).join(' • ');
  return `<div class="source-row"><div class="source-main"><span class="quality">${esc(s.quality||'AUTO')}</span><span><strong>${kindIcon}${esc(label)}</strong>${meta?`<small>${esc(meta)}</small>`:''}</span></div><div class="source-actions">${playable?`<button class="btn ghost slim" data-${series?'series-':''}source-play="${i}">${icon('play')}<span>پخش</span></button>`:''}${downloadable?`<button class="bm-download-button" data-${series?'series-':''}source-download="${i}"><span class="texto">دانلود</span><span class="mysvg">${icon('download')}</span></button>`:''}</div></div>`;
};

// Comment feedback controls using the supplied like/dislike visual language.
commentHtml=function(c,depth=0){
  if(c?._pendingId)return bm19PendingCommentHtml(c);
  const feedback=state.user?`<div class="comment-actions-v191"><div class="like-unlike-radio"><button class="feedback-label ${c.user_vote==='like'?'selected':''}" data-comment-action="like" data-comment-id="${c.id}">${bm191FeedbackSvg('like')}<span>${c.like_count||0}</span></button><button class="feedback-label ${c.user_vote==='dislike'?'selected':''}" data-comment-action="dislike" data-comment-id="${c.id}">${bm191FeedbackSvg('dislike')}<span>${c.dislike_count||0}</span></button></div><div class="comment-secondary-actions"><button class="btn ghost slim" data-comment-action="reply" data-comment-id="${c.id}">پاسخ</button>${c.can_report?`<button class="btn ghost slim" data-comment-action="report" data-comment-id="${c.id}">گزارش</button>`:''}${c.can_edit?`<button class="btn ghost slim" data-comment-action="edit" data-comment-id="${c.id}" data-comment-text="${esc(c.comment_raw||c.comment||'')}">ویرایش</button>`:''}${c.can_pin?`<button class="btn ghost slim" data-comment-action="pin" data-comment-id="${c.id}">${c.is_pinned?'برداشتن پین':'پین'}</button>`:''}${c.can_delete?`<button class="bm-mini-bin" title="حذف" data-comment-action="delete" data-comment-id="${c.id}">${bm191BinIcon()}</button>`:''}</div></div>`:'';
  return `<div class="comment" style="margin-right:${Math.min(depth,3)*18}px"><div class="comment-head"><strong>${esc(c.username||c.user?.username||'کاربر')} ${c.badge?`• ${esc(c.badge)}`:''}</strong><span>${esc(c.date_text||c.created_at||'')}</span></div><p>${c.spoiler?'⚠️ Spoiler — ':''}${esc(c.comment||c.text||'')}</p>${feedback}${(c.replies||[]).map(r=>commentHtml(r,depth+1)).join('')}</div>`;
};

function downloadRowV18(d){
  const p=pct(d.received,d.total),poster=cleanUrl(d.poster||''),active=!['completed','cancelled','interrupted'].includes(d.state);
  const ep=d.mediaType==='series'?`فصل ${d.season||'—'}${d.episode?` • قسمت ${d.episode}`:''}`:'فیلم';
  const completed=d.state==='completed';
  return `<article class="download-card-v18 ${completed?'done':''} ${d.state==='cancelled'?'cancelled':''}">
    <div class="download-poster-v18">${poster?img(poster,d.title||'','download-poster-img'):'<div class="poster-fallback">BM</div>'}<span>${d.mediaType==='series'?'سریال':'فیلم'}</span></div>
    <div class="download-main-v18"><div class="download-title-v18"><div><strong>${esc(d.title||d.fileName||'دانلود')}</strong><small>${esc(ep)}${d.quality?` • ${esc(d.quality)}`:''}</small></div><span class="download-state-v18">${completed?`<label class="bm-complete-check" title="کامل شد"><input type="checkbox" checked disabled><span class="checkmark"></span></label>`:esc(downloadStateLabel(d))}</span></div><div class="progress download-progress-v18"><i style="width:${p}%"></i></div><div class="download-stats-v18"><span>${p}%</span><span>${fmtBytes(d.received)} / ${fmtBytes(d.total)}</span>${active?`<span>${speedText(d.speed)}</span>${d.eta?`<span>باقی‌مانده ${etaText(d.eta)}</span>`:''}`:''}</div></div>
    <div class="download-actions-v18">${active&&!d.paused?`<button class="bm-icon-action pause" title="مکث" data-dl-action="pause" data-id="${esc(d.id)}">${bm191PauseIcon()}<span>مکث</span></button>`:''}${active&&d.paused?`<button class="bm-icon-action resume" title="ادامه" data-dl-action="resume" data-id="${esc(d.id)}">${icon('play')}<span>ادامه</span></button>`:''}${active?`<button class="bm-bin-button" title="لغو" data-dl-action="cancel" data-id="${esc(d.id)}">${bm191BinIcon()}</button>`:''}${completed&&d.savePath?`<button class="btn primary slim" data-open-file="${esc(d.savePath)}">باز کردن</button><button class="btn ghost slim" data-show-file="${esc(d.savePath)}">نمایش پوشه</button>`:''}${!active?`<button class="bm-bin-button compact" title="حذف از لیست" data-dl-action="remove" data-id="${esc(d.id)}">${bm191BinIcon()}</button>`:''}</div>
  </article>`;
}

// Live download renderer with instant remove/cancel/pause/resume.
bm19ApplyOptimisticDownloadAction=function(id,action){
  const d=state.downloads.get(id);if(!d)return;
  if(action==='remove'){state.downloads.delete(id);return}
  if(action==='pause')state.downloads.set(id,{...d,paused:true,state:'progressing',at:Date.now()});
  if(action==='resume')state.downloads.set(id,{...d,paused:false,state:'progressing',at:Date.now()});
  if(action==='cancel')state.downloads.set(id,{...d,paused:false,state:'cancelled',finishedAt:Date.now(),at:Date.now()});
};
bm19RenderDownloadsNow=function(){
  if(state.lastView!=='downloads')return;const scroller=$('#mainScroller'),keepTop=scroller?scroller.scrollTop:0;
  const arr=[...state.downloads.values()].sort((a,b)=>Number(b.at||b.queuedAt||0)-Number(a.at||a.queuedAt||0)),series=arr.filter(x=>x.mediaType==='series'),movies=arr.filter(x=>x.mediaType!=='series'),active=arr.filter(x=>!['completed','cancelled','interrupted'].includes(x.state)).length;
  $('#view').innerHTML=`<div class="downloads-page-v18 downloads-page-v19"><div class="page-title"><div><h1>مدیریت دانلود</h1><p>وضعیت زنده، کنترل فوری و تفکیک فیلم و سریال</p></div><div class="download-head-actions"><span class="chip live-chip"><i></i>${active.toLocaleString('fa-IR')} فعال</span><button class="btn ghost" id="chooseFolder">تغییر پوشه</button></div></div>${downloadGroupV18('سریال‌ها',series)}${downloadGroupV18('فیلم‌ها',movies)}</div>`;
  $('#chooseFolder').onclick=async()=>{state.settings.downloadDir=await bridge.chooseDownloadDir();toast('پوشه دانلود تغییر کرد','ok')};
  $$('[data-dl-action]').forEach(b=>b.onclick=async()=>{const id=b.dataset.id,action=b.dataset.dlAction;bm19ApplyOptimisticDownloadAction(id,action);bm19RenderDownloadsNow();try{const snapshot=await bridge.downloadAction(id,action);if(snapshot?.removed){state.downloads.delete(id);bm19RenderDownloadsNow();return}if(snapshot?.id){const prev=state.downloads.get(snapshot.id)||{};state.downloads.set(snapshot.id,{...prev,...snapshot});bm19RenderDownloadsNow()}else if(!snapshot&&action!=='remove'){toast('این دانلود دیگر فعال نیست','error');await bm19SyncDownloads()}}catch(e){toast(publicUiError(e),'error');await bm19SyncDownloads()}});
  $$('[data-show-file]').forEach(b=>b.onclick=()=>bridge.showItem(b.dataset.showFile));$$('[data-open-file]').forEach(b=>b.onclick=()=>bridge.openFile?bridge.openFile(b.dataset.openFile):bridge.showItem(b.dataset.openFile));if(scroller)scroller.scrollTop=keepTop;bm191Localize($('#view'));
};
renderDownloads=bm19RenderDownloadsNow;

showSettings=async function(){
  setActiveNav('settings');state.settings=await bridge.getSettings();state.players=await bridge.getPlayers();
  const recommended=state.players[0]||null,current=state.settings.preferredPlayer||'auto';
  const playerOptions=`<option value="auto" ${current==='auto'?'selected':''}>خودکار (پیشنهادی${recommended?`: ${esc(recommended.name)}`:''})</option>${state.players.map(p=>`<option value="${esc(p.id)}" ${current===p.id?'selected':''}>${esc(p.name)}</option>`).join('')}`;
  const playerStatus=state.players.length?state.players.map((p,i)=>`<button class="player-detect-chip ${i===0?'recommended':''}" type="button" data-player-pick="${esc(p.id)}"><strong>${esc(p.name)}</strong><small>${i===0?'پلیر پیشنهادی':p.subtitleSupport?'زیرنویس پشتیبانی می‌شود':'پشتیبانی پایه'}</small></button>`).join(''):'<span class="chip">هیچ پلیر سازگاری پیدا نشد</span>';
  const lang=state.settings.language||localStorage.getItem(BM191_LANG_KEY)||'fa';
  $('#view').innerHTML=`<div class="page-title"><div><h1>تنظیمات</h1><p>نسخه ${esc(state.appVersion||'')}</p></div></div><div class="settings-grid settings-grid-v191">
    <div class="panel settings-appearance-v191"><h3>زبان و ظاهر</h3><div class="setting-line-v191"><div><strong>زبان رابط</strong><small>فارسی / English</small></div><select id="languageSelect"><option value="fa" ${lang==='fa'?'selected':''}>فارسی</option><option value="en" ${lang==='en'?'selected':''}>English</option></select></div><div class="setting-line-v191"><div><strong>تم برنامه</strong><small>ماه / خورشید</small></div>${bm191ThemeSwitchHtml()}</div></div>
    <div class="panel"><h3>تنظیمات پخش</h3><div class="field"><label>پلیر خارجی</label><select id="preferredPlayer">${playerOptions}</select><small>انتخاب خودکار بهترین پلیر نصب‌شده را بر اساس سازگاری و زیرنویس انجام می‌دهد.</small></div><div class="player-detect-grid">${playerStatus}</div></div>
    <div class="panel"><h3>دانلود</h3><div class="field"><label>پوشه دانلود</label><input id="downloadDir" value="${esc(state.settings.downloadDir||'')}" readonly></div><button class="btn ghost" id="chooseDir" style="margin-top:10px">انتخاب پوشه</button></div>
    <div class="panel"><h3>حریم خصوصی</h3><p class="settings-safe-copy">دامنه، آدرس API و کلیدهای سرویس در رابط کاربری نمایش داده نمی‌شوند.</p><div class="meta"><span class="chip">BankMovie Desktop ${esc(state.appVersion||'')}</span>${recommended?`<span class="chip gold">Auto → ${esc(recommended.name)}</span>`:''}</div></div>
  </div>`;
  const save=async patch=>{state.settings=await bridge.setSettings(patch);return state.settings};
  $('#chooseDir').onclick=async()=>{$('#downloadDir').value=await bridge.chooseDownloadDir()};
  $('#preferredPlayer').onchange=async e=>{await save({preferredPlayer:e.target.value});toast(e.target.value==='auto'?'انتخاب خودکار فعال شد':'پلیر انتخاب شد','ok')};
  $$('[data-player-pick]').forEach(b=>b.onclick=async()=>{$('#preferredPlayer').value=b.dataset.playerPick;await save({preferredPlayer:b.dataset.playerPick});toast(`${b.querySelector('strong')?.textContent||'پلیر'} انتخاب شد`,'ok')});
  $('#languageSelect').onchange=async e=>{const language=e.target.value==='en'?'en':'fa';await save({language});applyLanguage(language);setTimeout(()=>showSettings(),0)};
  $('#settingsThemeSwitch').onchange=e=>{applyTheme(e.target.checked?'dark':'light');bm191Localize($('#view'))};
  applyLanguage(lang);
};

// Keep language synchronized across all dynamically rendered views.
document.addEventListener('DOMContentLoaded',()=>{
  const initial=localStorage.getItem(BM191_LANG_KEY)||'fa';applyLanguage(initial);
  bridge.getSettings?.().then(s=>applyLanguage(s?.language||initial)).catch(()=>{});
  const obs=new MutationObserver(muts=>{if(!muts.some(m=>m.addedNodes?.length))return;requestAnimationFrame(()=>bm191Localize(document.body))});
  obs.observe(document.body,{childList:true,subtree:true});
});

/* ===== BankMovie Desktop v1.9.2 — Cinamatic / comments / progress rails / themes ===== */
const BM192_THEME_KEY='bankmovie_theme_v2';
const BM192_STICKERS=['🔥','😂','❤️','😍','😎','🤯','😭','🍿','🎬','👑','👏','💙'];
let bm192CommentSort='latest';
let bm192CommentRating=0;
let bm192CommentSpoiler=false;

const _bm192OldApplyTheme=applyTheme;
applyTheme=function(theme){
  let next=String(theme||'blue').toLowerCase();
  if(next==='dark')next='blue';
  if(!['blue','oled','light','violet'].includes(next))next='blue';
  state.theme=next;
  document.documentElement.dataset.theme=next;
  try{localStorage.setItem(BM192_THEME_KEY,next);localStorage.setItem(THEME_KEY,next)}catch{}
  const b=$('#themeToggle');if(b)b.classList.toggle('light-active',next==='light');
};
toggleTheme=function(){applyTheme(state.theme==='light'?'blue':'light')};
bm191ThemeSwitchHtml=function(){return `<label class="theme-switch settings-theme-switch" title="تم برنامه"><input class="theme-switch__checkbox" id="settingsThemeSwitch" type="checkbox" ${state.theme!=='light'?'checked':''}/><div class="theme-switch__container"><div class="theme-switch__clouds"></div><div class="theme-switch__stars-container"><svg fill="none" viewBox="0 0 144 55" xmlns="http://www.w3.org/2000/svg"><path fill="currentColor" d="M135.831 3.00688C135.055 3.85027 134.111 4.29946 133 4.35447C134.111 4.40947 135.055 4.85867 135.831 5.71123C136.607 6.55462 136.996 7.56303 136.996 8.72727C136.996 7.95722 137.172 7.25134 137.525 6.59129C137.886 5.93124 138.372 5.39954 138.98 5.00535C139.598 4.60199 140.268 4.39114 141 4.35447C139.88 4.2903 138.936 3.85027 138.16 3.00688C137.384 2.16348 136.996 1.16425 136.996 0C136.996 1.16425 136.607 2.16348 135.831 3.00688Z"/></svg></div><div class="theme-switch__circle-container"><div class="theme-switch__sun-moon-container"><div class="theme-switch__moon"><div class="theme-switch__spot"></div><div class="theme-switch__spot"></div><div class="theme-switch__spot"></div></div></div></div><div class="theme-switch__shooting-star"></div><div class="theme-switch__shooting-star-2"></div><div class="theme-switch__meteor"></div><div class="theme-switch__stars-cluster"><div class="star"></div><div class="star"></div><div class="star"></div><div class="star"></div><div class="star"></div></div><div class="theme-switch__aurora"></div><div class="theme-switch__comets"><div class="comet"></div><div class="comet"></div></div></div></label>`};

function bm192ThemeChoices(){
  const rows=[['blue','BankMovie Blue','پیش‌فرض'],['oled','OLED','مشکی سینمایی'],['light','Light','سفید'],['violet','Violet','بنفش']];
  return `<div class="bm-theme-choices">${rows.map(([id,name,sub])=>`<button type="button" class="bm-theme-choice ${state.theme===id?'active':''}" data-bm-theme="${id}"><i class="theme-dot ${id}"></i><span><strong>${name}</strong><small>${sub}</small></span></button>`).join('')}</div>`;
}
const _bm192ShowSettings=showSettings;
showSettings=async function(){
  await _bm192ShowSettings();
  const appearance=$('.settings-appearance-v191');
  if(appearance&&!appearance.querySelector('.bm-theme-choices')){
    const holder=document.createElement('div');holder.className='bm-theme-palette';holder.innerHTML=`<div class="setting-line-v191 theme-palette-head"><div><strong>رنگ و استایل</strong><small>تم پیش‌فرض BankMovie آبی است</small></div></div>${bm192ThemeChoices()}`;appearance.appendChild(holder);
    $$('[data-bm-theme]').forEach(b=>b.onclick=()=>{applyTheme(b.dataset.bmTheme);showSettings()});
  }
  const sw=$('#settingsThemeSwitch');if(sw)sw.onchange=e=>{applyTheme(e.target.checked?(state.theme==='violet'?'violet':'blue'):'light');showSettings()};
  bm191Localize($('#view'));
};

document.addEventListener('DOMContentLoaded',()=>{
  const saved=localStorage.getItem(BM192_THEME_KEY)||localStorage.getItem(THEME_KEY)||'blue';
  applyTheme(saved==='dark'?'blue':saved);
});

// Animate the Download CTA only after an actual click, never on hover.
function bm192PulseDownloadButton(btn){
  if(!btn)return;btn.classList.remove('is-clicked');void btn.offsetWidth;btn.classList.add('is-clicked');
  clearTimeout(btn._bmPulse);btn._bmPulse=setTimeout(()=>btn.classList.remove('is-clicked'),1050);
}
const _bm192BindSourceButtons=bindSourceButtons;
bindSourceButtons=function(d,links){
  _bm192BindSourceButtons(d,links);
  $$('[data-source-download]').forEach(b=>b.onclick=async()=>{bm192PulseDownloadButton(b);await new Promise(r=>setTimeout(r,160));return downloadSource(links[Number(b.dataset.sourceDownload)],d)});
  $$('[data-series-source-download]').forEach(b=>b.onclick=async()=>{bm192PulseDownloadButton(b);await new Promise(r=>setTimeout(r,160));return downloadSource(state.visibleSources[Number(b.dataset.seriesSourceDownload)],d)});
};

// Reusable draggable progress scrollbar for every horizontal media rail.
function bm192LogicalScroll(rail){const max=Math.max(0,rail.scrollWidth-rail.clientWidth),rtl=getComputedStyle(rail).direction==='rtl';return {max,rtl,pos:Math.min(max,Math.max(0,rtl?Math.abs(rail.scrollLeft):rail.scrollLeft))}}
function bm192AttachProgressRail(rail){
  if(!rail||rail.dataset.bmProgressRail==='1')return;rail.dataset.bmProgressRail='1';
  const wrap=document.createElement('div');wrap.className='bm-rail-wrap';rail.parentNode.insertBefore(wrap,rail);wrap.appendChild(rail);
  const track=document.createElement('div');track.className='bm-progress-scrollbar';track.innerHTML='<div class="bm-progress-thumb"></div>';wrap.appendChild(track);
  const thumb=track.firstElementChild;
  const update=()=>{
    const {max,rtl,pos}=bm192LogicalScroll(rail);const tw=track.clientWidth;
    if(max<=2||tw<=0){track.classList.add('is-hidden');return}track.classList.remove('is-hidden');
    const width=Math.max(32,Math.min(tw,tw*(rail.clientWidth/rail.scrollWidth)));const range=Math.max(0,tw-width);const ratio=max?pos/max:0;const x=range*(rtl?1-ratio:ratio);
    thumb.style.width=`${width}px`;thumb.style.transform=`translateX(${x}px)`;
  };
  rail.addEventListener('scroll',update,{passive:true});
  const ro=new ResizeObserver(update);ro.observe(rail);ro.observe(track);
  let drag=null;
  thumb.addEventListener('pointerdown',e=>{e.preventDefault();thumb.setPointerCapture(e.pointerId);const {max,rtl,pos}=bm192LogicalScroll(rail);const tw=track.clientWidth,w=thumb.getBoundingClientRect().width,range=Math.max(1,tw-w),startRatio=max?pos/max:0;drag={id:e.pointerId,startX:e.clientX,range,max,rtl,startVisual:range*(rtl?1-startRatio:startRatio)}});
  thumb.addEventListener('pointermove',e=>{if(!drag||drag.id!==e.pointerId)return;const visual=Math.max(0,Math.min(drag.range,drag.startVisual+(e.clientX-drag.startX))),visualRatio=visual/drag.range,ratio=drag.rtl?1-visualRatio:visualRatio,target=ratio*drag.max;rail.scrollLeft=drag.rtl?-target:target});
  const end=e=>{if(drag&&drag.id===e.pointerId)drag=null};thumb.addEventListener('pointerup',end);thumb.addEventListener('pointercancel',end);
  track.addEventListener('pointerdown',e=>{if(e.target===thumb)return;const r=track.getBoundingClientRect(),w=thumb.getBoundingClientRect().width,range=Math.max(1,r.width-w),visual=Math.max(0,Math.min(range,e.clientX-r.left-w/2)),rtl=getComputedStyle(rail).direction==='rtl',ratio=rtl?1-visual/range:visual/range,max=Math.max(0,rail.scrollWidth-rail.clientWidth);rail.scrollTo({left:rtl?-(ratio*max):ratio*max,behavior:'smooth'})});
  requestAnimationFrame(update);
}
function bm192ScanRails(root=document){root.querySelectorAll?.('.rail,.collection-home-rail').forEach(bm192AttachProgressRail)}
document.addEventListener('DOMContentLoaded',()=>{bm192ScanRails();const mo=new MutationObserver(()=>requestAnimationFrame(()=>bm192ScanRails()));mo.observe(document.body,{childList:true,subtree:true})});

function bm192AvatarUrl(obj){return cleanUrl(obj?.avatar_url||obj?.avatar||obj?.user?.avatar_url||obj?.user?.avatar||obj?.profile?.avatar_url||'')}
function bm192RatingStars(value=0){const n=Math.max(0,Math.min(5,Number(value)||0));return `<span class="comment-rating-read">${[1,2,3,4,5].map(i=>`<span class="${i<=n?'on':''}">☆</span>`).join('')}</span>`}
function bm192CommentProfile(c){const avatar=bm192AvatarUrl(c),name=c.username||c.user?.username||c.name||'کاربر',verified=!!(c.verified||c.is_verified||c.is_admin||c.user?.is_admin||String(c.badge||'').toLowerCase().includes('admin'));return `<div class="bm-comment-profile">${avatar?`<img src="${esc(avatar)}" alt="${esc(name)}">`:`<span class="bm-comment-avatar-fallback">${esc(String(name).slice(0,1).toUpperCase())}</span>`}<div><strong>${esc(name)}${verified?'<i class="bm-verified">✓</i>':''}</strong><small>${esc(c.date_text||c.created_at||'')}</small></div></div>`}
function bm192StickerPicker(targetId){return `<div class="bm-sticker-picker hidden" data-sticker-picker="${esc(targetId)}">${BM192_STICKERS.map(s=>`<button type="button" data-sticker="${s}" data-sticker-target="${esc(targetId)}">${s}</button>`).join('')}</div>`}
function bm192ComposerHtml(d){const avatar=bm192AvatarUrl(state.user),name=state.user?.username||'شما';return `<section class="bm-comment-composer"><div class="bm-comment-composer-head">${avatar?`<img src="${esc(avatar)}">`:'<span class="bm-comment-avatar-fallback">'+esc(String(name).slice(0,1).toUpperCase())+'</span>'}<div><strong>${esc(name)}</strong><small>برای امتیاز دادن روی ستاره‌ها بزنید</small></div><div class="bm-comment-stars" id="commentStars">${[1,2,3,4,5].map(i=>`<button type="button" data-comment-star="${i}">☆</button>`).join('')}</div></div><div class="bm-comment-tools"><label class="bm-spoiler-check"><input type="checkbox" id="commentSpoiler"><span></span> کامنت اسپویل دارد؟</label><button class="btn ghost slim" type="button" id="commentSticker">☺ استیکر</button></div>${bm192StickerPicker('commentText')}<textarea class="form-control bm-comment-textarea" id="commentText" placeholder="دیدگاهت را درباره این عنوان بنویس…"></textarea><button class="bm-comment-send" id="sendComment"><span class="send-plane">➤</span><span>ارسال دیدگاه</span><i></i></button></section>`}

loadComments=async function(d){try{const r=await bridge.user('comments_list',{item:d,page:1,limit:30,sort:bm192CommentSort},'POST');commentsCache=r.items||r.comments||[]}catch{commentsCache=[]}}
commentHtml=function(c,depth=0){
  if(c?._pendingId)return `<article class="bm-comment-card pending-comment"><div class="bm-comment-card-head">${bm192CommentProfile(c)}<span class="comment-send-state"><i></i>در حال ارسال…</span></div><div class="bm-comment-body">${esc(c.comment||'')}</div></article>`;
  const id=Number(c.id||0),spoiler=!!c.spoiler,body=esc(c.comment||c.text||''),sticker=c.sticker_url?`<img class="bm-comment-sticker-image" src="${esc(cleanUrl(c.sticker_url))}">`:'';
  const actions=state.user?`<div class="comment-actions-v191 bm-comment-actions"><div class="like-unlike-radio"><button class="feedback-label ${c.user_vote==='like'?'selected':''}" data-comment-action="like" data-comment-id="${id}">${bm191FeedbackSvg('like')}<span>${c.like_count||0}</span></button><button class="feedback-label ${c.user_vote==='dislike'?'selected':''}" data-comment-action="dislike" data-comment-id="${id}">${bm191FeedbackSvg('dislike')}<span>${c.dislike_count||0}</span></button></div><div class="comment-secondary-actions"><button class="btn ghost slim" data-comment-action="reply" data-comment-id="${id}">پاسخ</button>${c.can_report?`<button class="btn ghost slim" data-comment-action="report" data-comment-id="${id}">گزارش تخلف</button>`:''}${c.can_edit?`<button class="btn ghost slim" data-comment-action="edit" data-comment-id="${id}" data-comment-text="${esc(c.comment_raw||c.comment||'')}">ویرایش</button>`:''}${c.can_pin?`<button class="btn ghost slim" data-comment-action="pin" data-comment-id="${id}">${c.is_pinned?'برداشتن پین':'پین'}</button>`:''}${c.can_delete?`<button class="bm-mini-bin" title="حذف" data-comment-action="delete" data-comment-id="${id}">${bm191BinIcon()}</button>`:''}</div></div>`:'';
  return `<article class="bm-comment-card ${c.is_pinned?'pinned':''}" data-comment-card="${id}" style="--reply-depth:${Math.min(depth,4)}"><div class="bm-comment-card-head">${bm192CommentProfile(c)}${bm192RatingStars(c.rating||c.score||0)}</div><div class="bm-comment-body ${spoiler?'is-spoiler':''}">${spoiler?`<button type="button" class="bm-spoiler-reveal" data-spoiler-reveal="${id}">⚠ نمایش اسپویل</button><span class="bm-spoiler-content">${body}</span>`:body}${sticker}</div>${actions}<div class="bm-inline-reply-slot" data-reply-slot="${id}"></div>${(c.replies||[]).map(r=>commentHtml(r,depth+1)).join('')}</article>`;
}

function bm192BindStickerPickers(root=document){
  root.querySelectorAll?.('[data-sticker]').forEach(b=>b.onclick=()=>{const target=document.getElementById(b.dataset.stickerTarget);if(!target)return;const start=target.selectionStart??target.value.length,end=target.selectionEnd??target.value.length;target.value=target.value.slice(0,start)+b.dataset.sticker+target.value.slice(end);target.focus();target.selectionStart=target.selectionEnd=start+b.dataset.sticker.length});
}
function bm192ReplyComposer(id,d){
  const slot=document.querySelector(`[data-reply-slot="${id}"]`);if(!slot)return;const tid=`replyText-${id}`;slot.innerHTML=`<div class="bm-reply-composer"><textarea id="${tid}" class="form-control" placeholder="پاسخ خود را بنویس…"></textarea><div class="bm-reply-tools"><label class="bm-spoiler-check"><input type="checkbox" id="replySpoiler-${id}"><span></span> اسپویل</label><button type="button" class="btn ghost slim" data-reply-sticker="${id}">☺ استیکر</button><button type="button" class="btn primary slim" data-reply-send="${id}">ارسال پاسخ</button><button type="button" class="btn ghost slim" data-reply-close="${id}">بستن</button></div>${bm192StickerPicker(tid)}</div>`;
  const picker=slot.querySelector('[data-sticker-picker]');slot.querySelector(`[data-reply-sticker="${id}"]`).onclick=()=>picker.classList.toggle('hidden');slot.querySelector(`[data-reply-close="${id}"]`).onclick=()=>slot.innerHTML='';bm192BindStickerPickers(slot);
  slot.querySelector(`[data-reply-send="${id}"]`).onclick=async e=>{const text=document.getElementById(tid).value.trim();if(text.length<2)return toast('متن پاسخ کوتاه است','error');const btn=e.currentTarget;btn.disabled=true;btn.textContent='در حال ارسال…';try{await bridge.user('comment_reply',{item:d,parent_id:id,comment:text,rating:0,spoiler:document.getElementById(`replySpoiler-${id}`).checked?1:0},'POST');toast('پاسخ ثبت شد','ok');await loadComments(d);renderCommentsBox(d)}catch(err){toast(publicUiError(err),'error');btn.disabled=false;btn.textContent='ارسال پاسخ'}};
}
commentAction=async function(action,id,text,d){
  if(!state.user)return showAuthModal();
  try{
    if(action==='reply'){bm192ReplyComposer(id,d);return}
    if(action==='like'||action==='dislike')await bridge.user('comment_vote',{item:d,comment_id:id,type:action},'POST');
    else if(action==='report'){const v=prompt('توضیح گزارش (اختیاری):','');if(v===null)return;await bridge.user('comment_report',{item:d,comment_id:id,reason:'other',details:v},'POST')}
    else if(action==='edit'){const v=prompt('ویرایش دیدگاه:',text);if(!v)return;await bridge.user('comment_edit',{item:d,comment_id:id,comment:v,spoiler:0},'POST')}
    else if(action==='pin')await bridge.user('comment_pin',{item:d,comment_id:id},'POST');
    else if(action==='delete'){if(!confirm('دیدگاه حذف شود؟'))return;await bridge.user('comment_delete',{item:d,comment_id:id},'POST')}
    await loadComments(d);renderCommentsBox(d);if(action==='report')toast('گزارش ثبت شد','ok');
  }catch(e){toast(publicUiError(e),'error')}
}

renderCommentsBox=function(d){
  const box=$('#detailTab');if(!box)return;
  box.innerHTML=`<div class="bm-comments-shell"><div class="bm-comments-toolbar"><div><h3>نظرات کاربران</h3><span class="chip">${commentsCache.filter(x=>!x._pendingId).length.toLocaleString('fa-IR')} دیدگاه</span></div><label>مرتب‌سازی <select id="commentSort"><option value="latest" ${bm192CommentSort==='latest'?'selected':''}>جدیدترین</option><option value="top" ${bm192CommentSort==='top'?'selected':''}>محبوب‌ترین</option></select></label></div>${state.user?bm192ComposerHtml(d):'<div class="panel" style="margin-bottom:14px">برای ثبت دیدگاه وارد حساب شو.</div>'}<div id="commentsList" class="bm-comments-list">${commentsCache.length?commentsCache.map(c=>commentHtml(c,0)).join(''):'<div class="empty">هنوز دیدگاهی ثبت نشده است.</div>'}</div></div>`;
  $('#commentSort').onchange=async e=>{bm192CommentSort=e.target.value;await loadComments(d);renderCommentsBox(d)};
  if($('#commentSticker')){$('#commentSticker').onclick=()=>document.querySelector('[data-sticker-picker="commentText"]')?.classList.toggle('hidden');bm192BindStickerPickers(box)}
  $$('[data-comment-star]').forEach(b=>b.onclick=()=>{bm192CommentRating=Number(b.dataset.commentStar);$$('[data-comment-star]').forEach(x=>x.classList.toggle('on',Number(x.dataset.commentStar)<=bm192CommentRating))});
  $('#commentSpoiler')?.addEventListener('change',e=>bm192CommentSpoiler=!!e.target.checked);
  $('#sendComment')?.addEventListener('click',()=>{
    const input=$('#commentText'),text=input.value.trim();if(text.length<3)return toast('متن دیدگاه کوتاه است','error');
    const btn=$('#sendComment');btn.classList.add('loading');btn.disabled=true;input.value='';const pendingId=`pending-${Date.now()}-${++bm19CommentsSeq}`;const pending={_pendingId:pendingId,username:state.user?.username||'شما',avatar_url:bm192AvatarUrl(state.user),comment:text,rating:bm192CommentRating,spoiler:bm192CommentSpoiler};commentsCache=[pending,...commentsCache];renderCommentsBox(d);
    bridge.user('comment_add',{item:d,comment:text,rating:bm192CommentRating,spoiler:bm192CommentSpoiler?1:0},'POST').then(async()=>{commentsCache=commentsCache.filter(x=>x._pendingId!==pendingId);toast('دیدگاه ثبت شد','ok');try{await loadComments(d)}catch{}if(state.currentDetail&&watchKey(state.currentDetail)===watchKey(d))renderCommentsBox(d)}).catch(err=>{commentsCache=commentsCache.filter(x=>x._pendingId!==pendingId);toast(publicUiError(err),'error');if(state.currentDetail&&watchKey(state.currentDetail)===watchKey(d))renderCommentsBox(d)});
  });
  $$('[data-comment-action]').forEach(b=>b.onclick=()=>commentAction(b.dataset.commentAction,Number(b.dataset.commentId),b.dataset.commentText||'',d));
  $$('[data-spoiler-reveal]').forEach(b=>b.onclick=()=>b.closest('.bm-comment-body')?.classList.add('revealed'));
  const currentKey=watchKey(d);if(bm19CommentsLoadedKey!==currentKey&&!bm19CommentsLoading){bm19CommentsLoading=true;Promise.resolve().then(()=>loadComments(d)).then(()=>{bm19CommentsLoadedKey=currentKey;if(state.currentDetail&&watchKey(state.currentDetail)===currentKey&&$('#detailTab'))renderCommentsBox(d)}).catch(()=>{}).finally(()=>bm19CommentsLoading=false)}
  bm191Localize(box);
};

// Site-like trailer CTA without changing the existing trailer opening flow.
const bm192UiObserver=new MutationObserver(()=>{
  const t=$('#trailerBtn');if(t&&!t.classList.contains('bm-trailer-site-btn')){t.classList.add('bm-trailer-site-btn');t.innerHTML='<span class="trailer-clap">▣</span><span>مشاهده تریلر</span>'}
});
document.addEventListener('DOMContentLoaded',()=>bm192UiObserver.observe(document.body,{childList:true,subtree:true}));


/* ===== BankMovie Desktop v1.9.4 — VIP click-gate + header actions ===== */
function bm194SetDownloadCount(value){const el=$('#downloadCount');if(el)el.textContent=value==null?'':String(value)}
function bm194SourceArchive(s){return Number(s?.archive||state.currentDetail?.archive||state.archive)||1}
function bm194HasSourceDescriptor(s){return !!String(s?.quality||s?.display_label||s?.label||s?.type||s?.type_fa||s?.size||'').trim()}
function bm194HiddenVipSource(s,mode='stream'){
  if(isVip())return false;
  const archive=bm194SourceArchive(s);
  if(archiveActionNeedsVip(archive,mode))return true;
  // Archive 4's Android/site endpoint intentionally withholds the real media URL
  // from non-VIP users while still returning quality rows. Treat those rows as
  // gated actions so Windows mirrors the site's Archive 5 behaviour.
  if(archive===4 && !String(s?.url||'').trim() && bm194HasSourceDescriptor(s))return true;
  return false;
}
function bm194VipGateForSource(s,mode){
  const archive=bm194SourceArchive(s);
  const names={stream:'پخش آنلاین ویژه اعضای VIP',download:'دانلود ویژه اعضای VIP'};
  showVipGateModal(names[mode]||'بخش ویژه اعضای VIP',`برای ${mode==='download'?'دانلود':'پخش'} این کیفیت در ${ARCHIVE_NAMES[archive]||'این آرشیو'} اشتراک VIP فعال لازم است.`);
}
sourceRow=function(s,i,series=false){
  const sub=subtitleUrlOf(s),label=sourceTypeLabel(s),hasUrl=!!String(s?.url||'').trim()&&!s.is_folder;
  const streamLocked=bm194HiddenVipSource(s,'stream'),downloadLocked=bm194HiddenVipSource(s,'download');
  const playable=!streamLocked&&s.is_playable!==false&&hasUrl,downloadable=!downloadLocked&&s.is_download!==false&&!!String(s?.url||'').trim();
  const t=String(s?.type||'').toLowerCase(),isDub=/dub|audio/.test(t)||/دوبله|صوت/.test(label),hasSub=sub||/softsub|hardsub|subtitle/.test(t)||/زیرنویس|ساب/.test(label);
  const kindIcon=isDub?icon('mic','source-kind-icon'):hasSub?icon('subtitle','source-kind-icon'):'';
  const meta=[s.size||'',sub&&!/سافت|هارد|زیرنویس|ساب/.test(label)?'زیرنویس جداگانه':'',s.is_folder?'پوشه':''].filter(Boolean).join(' • ');
  const playBtn=(playable||streamLocked)?`<button class="btn ghost slim ${streamLocked?'vip-locked-action':''}" data-${series?'series-':''}source-play="${i}" ${streamLocked?'data-vip-lock="stream"':''}>${streamLocked?icon('vip'):icon('play')}<span>${streamLocked?'پخش VIP':'پخش'}</span></button>`:'';
  const dlBtn=(downloadable||downloadLocked)?`<button class="bm-download-button ${downloadLocked?'vip-locked-action':''}" data-${series?'series-':''}source-download="${i}" ${downloadLocked?'data-vip-lock="download"':''}><span class="texto">${downloadLocked?'دانلود VIP':'دانلود'}</span><span class="mysvg">${downloadLocked?icon('vip'):icon('download')}</span></button>`:'';
  return `<div class="source-row ${streamLocked||downloadLocked?'has-vip-lock':''}"><div class="source-main"><span class="quality">${esc(s.quality||'AUTO')}</span><span><strong>${kindIcon}${esc(label)}</strong>${meta?`<small>${esc(meta)}</small>`:''}</span></div><div class="source-actions">${playBtn}${dlBtn}</div></div>`;
};
const _bm194BindSourceButtons=bindSourceButtons;
bindSourceButtons=function(d,links){
  _bm194BindSourceButtons(d,links);
  $$('[data-vip-lock="stream"]').forEach(b=>b.onclick=()=>{const i=Number(b.dataset.sourcePlay??b.dataset.seriesSourcePlay);const s=b.hasAttribute('data-series-source-play')?state.visibleSources[i]:links[i];bm194VipGateForSource(s,'stream')});
  $$('[data-vip-lock="download"]').forEach(b=>b.onclick=()=>{const i=Number(b.dataset.sourceDownload??b.dataset.seriesSourceDownload);const s=b.hasAttribute('data-series-source-download')?state.visibleSources[i]:links[i];bm194VipGateForSource(s,'download')});
};
function bm194DetailNeedsVip(mode){
  if(isVip())return false;
  const archive=Number(state.currentDetail?.archive||state.archive)||1;
  if(archiveActionNeedsVip(archive,mode))return true;
  if(archive===4){
    const pool=(state.visibleSources?.length?state.visibleSources:dedupeSources(state.currentDetail?.play?.links||state.currentDetail?.downloads||state.currentDetail?.links||[]));
    if(pool.length && !pool.some(s=>String(s?.url||'').trim()))return true;
  }
  return false;
}
async function bm194OpenVipHeader(){
  try{await loadUserConfig()}catch{}
  if(state.user){try{await refreshMe(false)}catch{}}
  if(isVip())return showProfile();
  return showVipPlansModal();
}
function bm194BindHeaderActions(){
  const vip=$('#vipHeader'),downloads=$('#downloadsHeader');
  if(vip)vip.onclick=e=>{e.preventDefault();e.stopPropagation();bm194OpenVipHeader()};
  if(downloads)downloads.onclick=e=>{e.preventDefault();e.stopPropagation();route('downloads')};
}
document.addEventListener('click',e=>{
  const best=e.target.closest?.('#playBest');
  if(best&&bm194DetailNeedsVip('stream')){e.preventDefault();e.stopImmediatePropagation();showVipGateModal('پخش آنلاین ویژه اعضای VIP',`پخش این عنوان در ${ARCHIVE_NAMES[Number(state.currentDetail?.archive||state.archive)||1]} برای اعضای VIP فعال است.`)}
},true);
document.addEventListener('DOMContentLoaded',()=>{bm194BindHeaderActions();const mo=new MutationObserver(()=>bm194BindHeaderActions());mo.observe(document.body,{childList:true,subtree:true})});


/* ===== BankMovie Desktop v1.9.5 — readability / hero CTA / site auth / update ===== */
function bm195VersionParts(v){return String(v||'0').replace(/^v/i,'').split(/[.-]/).slice(0,4).map(x=>Number(String(x).replace(/\D/g,''))||0)}
function bm195VersionCompare(a,b){const A=bm195VersionParts(a),B=bm195VersionParts(b);for(let i=0;i<Math.max(A.length,B.length,3);i++){const d=(A[i]||0)-(B[i]||0);if(d)return d>0?1:-1}return 0}
function bm195ActiveHeroBackground(){const el=document.querySelector('.hero-slide.active .hero-bg')||document.querySelector('.hero-bg');const bg=el?.style?.backgroundImage||'';return bg&&bg!=='none'?bg:'linear-gradient(135deg,#06162d,#0b326e)'}

const bm195OpenModalBase=openModal;
openModal=function(html,wide=false){
  const modal=$('#modal'),box=$('#modalBox');
  modal?.classList.remove('auth-mode','update-mode','update-force-mode');
  box?.classList.remove('auth-site-modal','update-site-modal');
  if(box)box.style.removeProperty('--auth-backdrop');
  bm195OpenModalBase(html,wide);
};
const bm195CloseModalBase=closeModal;
closeModal=function(){
  const modal=$('#modal');
  if(modal?.classList.contains('update-force-mode'))return;
  modal?.classList.remove('auth-mode','update-mode','update-force-mode');
  $('#modalBox')?.classList.remove('auth-site-modal','update-site-modal');
  bm195CloseModalBase();
};

function bm195RenderAuth(tab='login'){
  const isRegister=tab==='register';
  const brandTitle=isRegister?'به جمع ما<br><b>خوش اومدی.</b>':'خوش اومدی؛<br><b>ادامه بده.</b>';
  const title=isRegister?'ساخت حساب <b>بانک مووی</b>':'ورود به <b>بانک مووی</b>';
  const subtitle=isRegister?'چند ثانیه تا ساخت داشبورد سینمایی شما.':'برای ادامه تماشا و مدیریت حساب وارد شوید.';
  return `<button class="auth-site-close" data-close-auth aria-label="بستن">×</button><div class="auth-site-shell ${isRegister?'register-mode':''}"><section class="auth-site-panel form-side"><div class="auth-site-form-head"><img src="assets/bankmovie-logo.webp" alt="BankMovie"><h1>${title}</h1><p>${subtitle}</p></div><div class="tabs"><button class="tab ${!isRegister?'active':''}" data-auth-tab="login">ورود</button><button class="tab ${isRegister?'active':''}" data-auth-tab="register">ثبت‌نام</button></div><div id="authBody">${isRegister?registerForm():loginForm()}</div></section><aside class="auth-site-panel brand-side"><div class="auth-site-brand-copy"><span>${isRegister?'عضویت رایگان':'سینمای شخصی بانک مووی'}</span><h2>${brandTitle}</h2><p>${isRegister?'حساب بساز، نشان‌ها و تنظیمات خودت را نگه دار و هر زمان خواستی اشتراک VIP را فعال کن.':'نشان‌ها، تنظیمات، دیدگاه‌ها، بازدیدهای اخیر و امکانات VIP بعد از ورود در دسترس هستند.'}</p></div></aside></div>`;
}
showAuthModal=function(initial='login'){
  const modal=$('#modal'),box=$('#modalBox');
  const render=(tab)=>{
    box.innerHTML=bm195RenderAuth(tab);
    box.classList.add('auth-site-modal');
    modal.classList.add('auth-mode');
    modal.style.setProperty('--auth-backdrop',bm195ActiveHeroBackground());
    $('[data-close-auth]')?.addEventListener('click',()=>{modal.classList.remove('auth-mode');bm195CloseModalBase()});
    $$('[data-auth-tab]').forEach(t=>t.onclick=()=>render(t.dataset.authTab));
    bindAuthForms();
    if(typeof bm191Localize==='function')bm191Localize(box);
  };
  bm195OpenModalBase('',true);
  render(initial);
};

async function bm195CommitDetail(item,detail){
  state.currentDetail={...item,...detail,archive:Number(detail?.archive||item?.target_archive||item?.archive||state.archive)||state.archive};
  state.detailSeason=null;state.detailEpisode=null;state.visibleSources=[];commentsCache=[];bm19CommentsLoadedKey='';
  rememberRecentView(state.currentDetail);renderDetail(state.currentDetail);return true;
}
async function bm195TryDetail(item){
  const id=itemId(item);if(!id)return false;
  const r=await bridge.content('detail',{archive:Number(item.target_archive||item.archive||state.archive)||state.archive,id,type:item.target_type||item.type||''});
  const d=r?.item||r;if(!d||(!itemId(d)&&!itemTitle(d)))throw new Error('detail not resolved');
  return bm195CommitDetail(item,d);
}
function bm195NormTitle(s){return String(s||'').toLowerCase().replace(/[\u200c\u200f\u202a-\u202e]/g,' ').replace(/\b(19|20)\d{2}\b/g,' ').replace(/[^\p{L}\p{N}]+/gu,' ').trim()}
openSliderItem=async function(raw){
  const target=sliderMediaItem(raw),title=itemTitle(raw),wanted=bm195NormTitle(title);
  setLoading('در حال باز کردن عنوان…');
  const attempts=[];const seen=new Set();
  const add=(x)=>{const k=`${x.archive}|${itemId(x)}|${x.type||''}`;if(itemId(x)&&!seen.has(k)){seen.add(k);attempts.push(x)}};
  add(target);
  if(itemId(target))enabledArchives().forEach(a=>add({...target,archive:a,target_archive:a}));
  for(const c of attempts){try{if(await bm195TryDetail(c))return}catch{}}
  if(title){
    const order=[Number(target.archive)||state.archive,...enabledArchives()].filter((v,i,a)=>a.indexOf(v)===i);
    for(const archive of order){
      try{
        const r=await bridge.content('search',{archive,q:title,page:1,limit:12});const items=r?.items||r?.results||[];
        if(!items.length)continue;
        const exact=items.find(x=>bm195NormTitle(itemTitle(x))===wanted)||items.find(x=>bm195NormTitle(itemTitle(x)).includes(wanted)||wanted.includes(bm195NormTitle(itemTitle(x))))||items[0];
        if(exact){try{if(await bm195TryDetail({...exact,archive:Number(exact.archive||archive)||archive}))return}catch{}}
      }catch{}
    }
  }
  await showHome(false);toast('مقصد این اسلاید هنوز در API قابل تشخیص نیست','error');
};
bindHeroSlider=function(sliders){
  if(state.heroTimer){clearInterval(state.heroTimer);state.heroTimer=null}state.heroIndex=0;activateHero(0,sliders);
  $$('[data-hero-open]').forEach(b=>b.onclick=async e=>{e.preventDefault();e.stopPropagation();if(b.dataset.busy==='1')return;b.dataset.busy='1';b.disabled=true;try{await openSliderItem(sliders[Number(b.dataset.heroOpen)])}finally{b.dataset.busy='0';b.disabled=false}});
  $$('[data-hero-search]').forEach(b=>b.onclick=()=>showSearch(itemTitle(sliders[Number(b.dataset.heroSearch)])));
  $$('[data-hero-dot]').forEach(b=>b.onclick=()=>activateHero(Number(b.dataset.heroDot),sliders));
  $$('[data-hero-thumb]').forEach(b=>b.onclick=()=>activateHero(Number(b.dataset.heroThumb),sliders));
  const prev=$('#heroPrev'),next=$('#heroNext');if(prev)prev.onclick=()=>activateHero(state.heroIndex-1,sliders);if(next)next.onclick=()=>activateHero(state.heroIndex+1,sliders);
  if(sliders.length>1)state.heroTimer=setInterval(()=>{if(state.lastView==='home')activateHero(state.heroIndex+1,sliders)},6500);
};

let bm195UpdateChecked=false;
function bm195UpdateNotes(desktop){
  const note=desktop?.notice||{};const raw=[note?.title,note?.message,desktop?.release_notes,desktop?.changelog].filter(Boolean).join('\n');
  const lines=raw.split(/\n|•|،/).map(x=>String(x).trim()).filter(x=>x.length>3).slice(0,8);
  return lines.length?lines:['بهبود خوانایی و اندازه متن‌ها','اصلاح دکمه مشاهده اسلایدر','بهبود تم روشن و جستجو','بازطراحی ورود و ثبت‌نام','بهبود پایداری و تجربه کاربری'];
}
function bm195ShowUpdate(desktop){
  const current=state.appVersion||'—',latest=desktop.latest_version||current,force=!!desktop.force_update||bm195VersionCompare(desktop.minimum_version||'0',current)>0,url=cleanUrl(desktop.download_url||'');
  const notes=bm195UpdateNotes(desktop);
  bm195OpenModalBase(`<section class="bm-update-screen"><div class="bm-update-logo"><img src="assets/bankmovie-icon.png"><strong>BANKMOVIE</strong></div><div class="bm-update-content"><h1><b>آپدیت</b> جدید آماده است</h1><div class="bm-update-version">نسخه ${esc(latest)}</div><p>نسخه جدید BankMovie منتشر شده است. برای دسترسی به امکانات جدید و بهبود عملکرد برنامه، لطفاً آن را بروزرسانی کنید.</p><div class="bm-update-changes"><h3>تغییرات این نسخه</h3><ul>${notes.map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div><div class="bm-update-versions"><span>نسخه فعلی<br><b>${esc(current)}</b></span><strong>←</strong><span>نسخه جدید<br><b>${esc(latest)}</b></span></div><button class="bm-update-download" id="bmUpdateDownload">دریافت و نصب آپدیت ←</button>${force?'<p class="bm-update-force">ⓘ این آپدیت اجباری است</p>':'<button class="bm-update-later" id="bmUpdateLater">بعداً یادآوری کن</button>'}</div></section>`,true);
  const modal=$('#modal'),box=$('#modalBox');modal.classList.add('update-mode');if(force)modal.classList.add('update-force-mode');box.classList.add('update-site-modal');
  $('#bmUpdateDownload').onclick=()=>{if(url)bridge.openExternal(url);else toast('لینک دریافت نسخه جدید در پنل ثبت نشده است','error')};
  if($('#bmUpdateLater'))$('#bmUpdateLater').onclick=()=>{modal.classList.remove('update-mode','update-force-mode');box.classList.remove('update-site-modal');bm195CloseModalBase()};
}
function bm195MaybeShowUpdate(){
  if(bm195UpdateChecked||!state.appVersion||!state.config?.desktop)return false;
  const d=state.config.desktop,latest=String(d.latest_version||'').trim(),minimum=String(d.minimum_version||'').trim();
  bm195UpdateChecked=true;
  if((latest&&bm195VersionCompare(latest,state.appVersion)>0)||d.force_update||(minimum&&bm195VersionCompare(minimum,state.appVersion)>0)){bm195ShowUpdate(d);return true}
  return false;
}
document.addEventListener('DOMContentLoaded',()=>{let tries=0;const t=setInterval(()=>{tries++;if(state.appVersion&&state.config?.desktop){clearInterval(t);setTimeout(bm195MaybeShowUpdate,350)}else if(tries>30)clearInterval(t)},350)});


/* ===== BankMovie Desktop v1.9.6 — Archive 5 normalization / Top 250 / back-stack motion ===== */
function bm196First(...values){for(const v of values){if(v!==undefined&&v!==null&&String(v).trim()!=='')return v}return ''}
function bm196Poster(it){return cleanUrl(bm196First(it?.poster,it?.poster_url,it?.posterUrl,it?.image,it?.cover,it?.cover_url,it?.thumbnail,it?.thumb))}
function bm196Year(it){const raw=String(bm196First(it?.year,it?.release_year,it?.releaseYear,it?.published_year,it?.date)||'');const m=raw.match(/(?:19|20)\d{2}/);return m?m[0]:raw.slice(0,4)}
function bm196Type(it){const raw=String(bm196First(it?.type,it?.media_type,it?.content_type,it?.kind,it?.category)||'').toLowerCase();if(it?.is_series===true||/series|serial|tv|show/.test(raw))return 'series';return 'movie'}
const bm196ItemTitleBase=itemTitle;
itemTitle=function(it){return String(bm196First(it?.title_fa,it?.fa_title,it?.titleFa,it?.name_fa,it?.nameFa,it?.name,it?.title,it?.original_title,it?.originalTitle,bm196ItemTitleBase(it))||'بدون عنوان')}
const bm196ItemIdBase=itemId;
itemId=function(it){return String(bm196First(it?.target_id,it?.detail_id,it?.id,it?.movie_id,it?.media_id,it?.slug,it?.imdb_code,it?.imdb_id,it?.imdbId,bm196ItemIdBase(it))||'')}
itemRating=function(it){
  const vals=[it?.rating,it?.imdb_rating,it?.imdbRating,it?.imdb_score,it?.imdbScore,it?.rating_imdb,it?.imdb_rate,it?.rate_imdb,it?.score,it?.rate,it?.ratings?.imdb,it?.rating?.imdb];
  for(const value of vals){
    if(value===undefined||value===null||value==='')continue;
    const raw=typeof value==='object'?String(value?.value??value?.score??''):String(value);
    const m=raw.replace(',','.').match(/(?:^|[^0-9])(10(?:\.0+)?|[0-9](?:\.\d{1,2})?)(?:\s*\/\s*10)?(?:[^0-9]|$)/);
    if(m){const n=Number(m[1]);if(Number.isFinite(n)&&n>=0&&n<=10)return n.toFixed(n%1?1:0)}
  }
  const imdb=String(it?.imdb??'').trim();
  if(!/^tt\d+/i.test(imdb)){const m=imdb.replace(',','.').match(/(?:^|[^0-9])(10(?:\.0+)?|[0-9](?:\.\d{1,2})?)(?:[^0-9]|$)/);if(m){const n=Number(m[1]);if(n>=0&&n<=10)return n.toFixed(n%1?1:0)}}
  return '';
};
card=function(it){
  const poster=bm196Poster(it),type=bm196Type(it),typeFa=type==='series'?'سریال':'فیلم',rating=itemRating(it),year=bm196Year(it),archive=Number(it?.archive||state.archive)||state.archive;
  const payload=encodeURIComponent(JSON.stringify({archive,id:itemId(it),type,title:it?.title||'',title_fa:itemTitle(it),poster,year,rating,source:it?.source||'',imdb_code:it?.imdb_code||it?.imdb_id||''}));
  return `<article class="media-card ${archive===5?'archive5-card':''}" data-card='${payload}'>
    <div class="poster">${poster?img(poster,itemTitle(it)):`<div class="poster-fallback">BM</div>`}<span class="type-badge">${typeFa}</span><span class="poster-imdb ${rating?'':'missing'}">${icon('imdb')}<b>${esc(rating||'—')}</b></span></div>
    <div class="card-info"><strong>${esc(itemTitle(it))}</strong><small><span>${esc(year||'—')} · ${typeFa}</span><span class="card-imdb-mini">IMDb ${esc(rating||'—')}</span></small></div>
  </article>`;
};

const bm196HomeSectionsForBase=homeSectionsFor;
homeSectionsFor=function(archive){
  const base=bm196HomeSectionsForBase(archive),n=Number(archive);
  if(n!==5)return base;
  const extras=['updated_movies','updated_series','new_movies','new_series','dubbed_movies','subtitled_movies','dubbed_series','subtitled_series','mini_series','korean_series','turkish_series','turkish','animation','updated_animations','top_movies','top_series','collections'];
  const out=[...base];
  for(const sec of extras){if(out.includes(sec))continue;const p=sectionPolicy(5,sec);if(p.enabled===false||p.access_scope==='disabled')continue;out.push(sec)}
  return out;
};

async function bm196ShowTop250(kind='movies'){
  const section=kind==='series'?'top_series':'top_movies',title=kind==='series'?'۲۵۰ سریال برتر IMDb':'۲۵۰ فیلم برتر IMDb';
  setActiveNav('categories');setLoading(`در حال دریافت ${title}…`);
  const order=[Number(state.archive)||1,...enabledArchives()].filter((v,i,a)=>a.indexOf(v)===i);let last=null;
  for(const archive of order){try{const r=await bridge.content('section',{archive,section,page:1,limit:60});const items=r?.items||[];if(items.length){state.archive=archive;renderGridPage(title,`${ARCHIVE_NAMES[archive]} • IMDb Top 250`,items);document.querySelector(kind==='series'?'#top250SeriesHeader':'#top250MoviesHeader')?.classList.add('active');return true}}catch(e){last=e}}
  if(last)renderError(last);else renderGridPage(title,'موردی پیدا نشد',[]);return false;
}

/* Navigation stack. This recreates the smooth forward/back feel without using code or assets from the reference app. */
state.bm196NavStack=[];state.bm196NavCurrent={kind:'route',view:'home',archive:state.archive,scroll:0};
let bm196NavLock=false;
function bm196Scroller(){return $('#mainScroller')}
function bm196Snapshot(){const c={...(state.bm196NavCurrent||{kind:'route',view:state.lastView||'home'})};c.archive=Number(c.archive||state.archive)||state.archive;c.scroll=bm196Scroller()?.scrollTop||0;return c}
function bm196UpdateBack(){const b=$('#backHeader');if(b)b.disabled=!state.bm196NavStack.length}
function bm196SetCurrent(ctx){state.bm196NavCurrent={...ctx,archive:Number(ctx?.archive||state.archive)||state.archive,scroll:0};bm196UpdateBack()}
function bm196PushCurrent(){if(bm196NavLock)return;const cur=bm196Snapshot();const last=state.bm196NavStack.at(-1);const key=x=>JSON.stringify({...x,scroll:0});if(!last||key(last)!==key(cur))state.bm196NavStack.push(cur);if(state.bm196NavStack.length>40)state.bm196NavStack.shift();bm196UpdateBack()}
async function bm196Motion(direction,job){const v=$('#view');if(v){v.classList.remove('bm-page-enter-forward','bm-page-enter-back');v.classList.add(direction==='back'?'bm-page-leave-back':'bm-page-leave-forward');await sleep(125);v.classList.remove('bm-page-leave-forward','bm-page-leave-back')}const out=await job();if(v){void v.offsetWidth;v.classList.add(direction==='back'?'bm-page-enter-back':'bm-page-enter-forward');setTimeout(()=>v.classList.remove('bm-page-enter-forward','bm-page-enter-back'),380)}return out}

const bm196RouteBase=route;
const bm196BrowseSectionBase=showBrowseSection;
const bm196SearchBase=showSearch;
const bm196ProfileBase=showProfile;
const bm196OpenDetailBase=openDetail;
const bm196SliderOpenBase=openSliderItem;
const bm196ActorBase=openActor;
const bm196GenresBase=showGenres;
const bm196GenreBase=showGenre;
const bm196CollectionsBase=showCollections;
const bm196CollectionBase=openCollection;

route=async function(view,force=false){if(bm196NavLock)return bm196RouteBase(view,force);bm196PushCurrent();return bm196Motion('forward',async()=>{bm196NavLock=true;try{const r=await bm196RouteBase(view,force);bm196SetCurrent({kind:'route',view,archive:state.archive});return r}finally{bm196NavLock=false}})};
showBrowseSection=async function(archive,section,page=1){if(bm196NavLock)return bm196BrowseSectionBase(archive,section,page);bm196PushCurrent();return bm196Motion('forward',async()=>{bm196NavLock=true;try{const r=await bm196BrowseSectionBase(archive,section,page);bm196SetCurrent({kind:'section',archive:Number(archive)||state.archive,section,page});return r}finally{bm196NavLock=false}})};
showSearch=async function(initial=''){if(bm196NavLock)return bm196SearchBase(initial);bm196PushCurrent();return bm196Motion('forward',async()=>{bm196NavLock=true;try{const r=await bm196SearchBase(initial);bm196SetCurrent({kind:'search',archive:state.archive,q:initial});return r}finally{bm196NavLock=false}})};
showProfile=async function(){if(bm196NavLock)return bm196ProfileBase();bm196PushCurrent();return bm196Motion('forward',async()=>{bm196NavLock=true;try{const r=await bm196ProfileBase();bm196SetCurrent({kind:'route',view:'profile',archive:state.archive});return r}finally{bm196NavLock=false}})};
openDetail=async function(item){if(bm196NavLock)return bm196OpenDetailBase(item);bm196PushCurrent();return bm196Motion('forward',async()=>{bm196NavLock=true;try{const r=await bm196OpenDetailBase(item);bm196SetCurrent({kind:'detail',archive:Number(state.currentDetail?.archive||item?.archive||state.archive)||state.archive,item:{...(state.currentDetail||item)}});return r}finally{bm196NavLock=false}})};
openSliderItem=async function(raw){if(bm196NavLock)return bm196SliderOpenBase(raw);bm196PushCurrent();return bm196Motion('forward',async()=>{bm196NavLock=true;try{const r=await bm196SliderOpenBase(raw);if(state.currentDetail)bm196SetCurrent({kind:'detail',archive:Number(state.currentDetail.archive||state.archive)||state.archive,item:{...state.currentDetail}});return r}finally{bm196NavLock=false}})};
openActor=async function(actor){if(bm196NavLock)return bm196ActorBase(actor);bm196PushCurrent();return bm196Motion('forward',async()=>{bm196NavLock=true;try{const r=await bm196ActorBase(actor);bm196SetCurrent({kind:'actor',archive:state.archive,actor});return r}finally{bm196NavLock=false}})};
showGenres=async function(){if(bm196NavLock)return bm196GenresBase();bm196PushCurrent();return bm196Motion('forward',async()=>{bm196NavLock=true;try{const r=await bm196GenresBase();bm196SetCurrent({kind:'genres',archive:state.archive});return r}finally{bm196NavLock=false}})};
showGenre=async function(slug,label,page=1){if(bm196NavLock)return bm196GenreBase(slug,label,page);bm196PushCurrent();return bm196Motion('forward',async()=>{bm196NavLock=true;try{const r=await bm196GenreBase(slug,label,page);bm196SetCurrent({kind:'genre',archive:state.archive,slug,label,page});return r}finally{bm196NavLock=false}})};
showCollections=async function(page=1){if(bm196NavLock)return bm196CollectionsBase(page);bm196PushCurrent();return bm196Motion('forward',async()=>{bm196NavLock=true;try{const r=await bm196CollectionsBase(page);bm196SetCurrent({kind:'collections',archive:state.archive,page});return r}finally{bm196NavLock=false}})};
openCollection=async function(slug,page=1){if(bm196NavLock)return bm196CollectionBase(slug,page);bm196PushCurrent();return bm196Motion('forward',async()=>{bm196NavLock=true;try{const r=await bm196CollectionBase(slug,page);bm196SetCurrent({kind:'collection',archive:state.archive,slug,page});return r}finally{bm196NavLock=false}})};

async function bm196Top250Navigate(kind){if(bm196NavLock)return bm196ShowTop250(kind);bm196PushCurrent();return bm196Motion('forward',async()=>{bm196NavLock=true;try{const r=await bm196ShowTop250(kind);bm196SetCurrent({kind:'top250',archive:state.archive,topKind:kind});return r}finally{bm196NavLock=false}})}
async function bm196GoBack(){if(!state.bm196NavStack.length)return;const prev=state.bm196NavStack.pop();bm196UpdateBack();return bm196Motion('back',async()=>{bm196NavLock=true;try{state.archive=Number(prev.archive||state.archive)||state.archive;let r;if(prev.kind==='detail')r=await bm196OpenDetailBase(prev.item||{});else if(prev.kind==='section')r=await bm196BrowseSectionBase(prev.archive,prev.section,prev.page||1);else if(prev.kind==='search')r=await bm196SearchBase(prev.q||'');else if(prev.kind==='actor')r=await bm196ActorBase(prev.actor||{});else if(prev.kind==='genres')r=await bm196GenresBase();else if(prev.kind==='genre')r=await bm196GenreBase(prev.slug,prev.label,prev.page||1);else if(prev.kind==='collections')r=await bm196CollectionsBase(prev.page||1);else if(prev.kind==='collection')r=await bm196CollectionBase(prev.slug,prev.page||1);else if(prev.kind==='top250')r=await bm196ShowTop250(prev.topKind||'movies');else r=await bm196RouteBase(prev.view||'home',false);bm196SetCurrent(prev);requestAnimationFrame(()=>{if(bm196Scroller())bm196Scroller().scrollTop=Number(prev.scroll||0)});return r}finally{bm196NavLock=false}})}

document.addEventListener('DOMContentLoaded',()=>{
  $('#backHeader')?.addEventListener('click',bm196GoBack);
  $('#top250MoviesHeader')?.addEventListener('click',()=>bm196Top250Navigate('movies'));
  $('#top250SeriesHeader')?.addEventListener('click',()=>bm196Top250Navigate('series'));
  document.addEventListener('keydown',e=>{if(e.altKey&&e.key==='ArrowLeft'){e.preventDefault();bm196GoBack()}});
  bm196UpdateBack();
});


/* ===== BankMovie Desktop v1.9.7 — no-jump navigation / in-page back / English pass / IMDb cleanup ===== */
const BM197_BACK_SVG=`<svg viewBox="0 0 72 72" aria-hidden="true"><g><path fill="currentColor" d="M48.252,69.253c-2.271,0-4.405-0.884-6.011-2.489L17.736,42.258c-1.646-1.645-2.546-3.921-2.479-6.255c-0.068-2.337,0.833-4.614,2.479-6.261L42.242,5.236c1.605-1.605,3.739-2.489,6.01-2.489c2.271,0,4.405,0.884,6.01,2.489c3.314,3.314,3.314,8.707,0,12.021L35.519,36l18.743,18.742c3.314,3.314,3.314,8.707,0,12.021C52.656,68.369,50.522,69.253,48.252,69.253z M48.252,6.747c-1.202,0-2.332,0.468-3.182,1.317L21.038,32.57c-0.891,0.893-0.833,2.084-0.833,3.355c0,0.051,0,0.101,0,0.151c0,1.271-0.058,2.461,0.833,3.353l24.269,24.506c0.85,0.85,1.862,1.317,3.063,1.317c1.203,0,2.273-0.468,3.123-1.317c1.755-1.755,1.725-4.61-0.03-6.365L31.292,37.414c-0.781-0.781-0.788-2.047-0.007-2.828L51.438,14.43c1.754-1.755,1.753-4.61-0.001-6.365C50.587,7.215,49.454,6.747,48.252,6.747z"/></g></svg>`;

/* Prefer the original/English title when the interface is English. */
const bm197ItemTitleFaBase=itemTitle;
itemTitle=function(it){
  if((state.language||bm191Language)==='en'){
    return String(bm196First(it?.title,it?.original_title,it?.originalTitle,it?.name,it?.english_title,it?.title_en,it?.name_en,it?.title_fa,bm197ItemTitleFaBase(it))||'Untitled');
  }
  return String(bm196First(it?.title_fa,it?.fa_title,it?.titleFa,it?.name_fa,it?.nameFa,it?.name,it?.title,it?.original_title,it?.originalTitle,bm197ItemTitleFaBase(it))||'بدون عنوان');
};

/* Cards: never invent an IMDb score. On posters the yellow badge is number-only. */
card=function(it){
  const poster=bm196Poster(it),type=bm196Type(it),isEn=(state.language||bm191Language)==='en',typeLabel=type==='series'?(isEn?'Series':'سریال'):(isEn?'Movie':'فیلم'),rating=itemRating(it),year=bm196Year(it),archive=Number(it?.archive||state.archive)||state.archive;
  const payload=encodeURIComponent(JSON.stringify({archive,id:itemId(it),type,title:it?.title||'',title_fa:it?.title_fa||'',poster,year,rating,source:it?.source||'',imdb_code:it?.imdb_code||it?.imdb_id||''}));
  return `<article class="media-card ${archive===5?'archive5-card':''}" data-card='${payload}'>
    <div class="poster">${poster?img(poster,itemTitle(it)):`<div class="poster-fallback">BM</div>`}<span class="type-badge">${typeLabel}</span>${rating?`<span class="poster-imdb poster-imdb-number"><b>${esc(rating)}</b></span>`:''}</div>
    <div class="card-info"><strong>${esc(itemTitle(it))}</strong><small><span>${esc(year||'—')} · ${typeLabel}</span></small></div>
  </article>`;
};

/* English coverage for static/dynamic UI strings. Movie descriptions/user content are not machine-translated. */
Object.assign(BM191_FA_EN,{
  'جدیدترین فیلم‌ها':'Latest Movies','سریال‌های آپدیت‌شده':'Updated Series','فیلم‌های جدید':'New Movies','سریال‌های جدید':'New Series',
  'سریال‌های کره‌ای':'Korean Series','دوبله فارسی':'Persian Dubbed','سریال‌های چینی':'Chinese Series','برترین‌های ۲۰۲۶':'Best of 2026',
  'Top 250 فیلم':'Top 250 Movies','Top 250 سریال':'Top 250 Series','انیمه':'Anime','فیلم و سریال ترکی':'Turkish Movies & Series',
  'انیمیشن و انیمه':'Animation & Anime','انیمیشن':'Animation','اکشن':'Action','انیمیشن‌های به‌روز شده':'Updated Animation','انیمه‌های به‌روز شده':'Updated Anime',
  'فیلم‌های دوبله':'Dubbed Movies','فیلم‌های زیرنویس':'Subtitled Movies','سریال‌های دوبله':'Dubbed Series','سریال‌های زیرنویس':'Subtitled Series',
  'مینی‌سریال':'Mini Series','سریال‌های ترکی':'Turkish Series','موردی پیدا نشد.':'Nothing found.','موردی پیدا نشد':'Nothing found',
  'در حال دریافت اطلاعات…':'Loading information…','در حال دریافت جزئیات…':'Loading details…','در حال دریافت کالکشن‌ها…':'Loading collections…',
  'در حال دریافت عناوین برتر…':'Loading top titles…','در حال جستجو':'Searching','در حال باز کردن کالکشن…':'Opening collection…',
  'در حال دریافت صفحه بازیگر…':'Loading actor page…','در حال دریافت باکس آفیس واقعی سایت…':'Loading box office…',
  'بدون عنوان':'Untitled','کاربر':'User','حساب عادی':'Free account','حساب BankMovie':'BankMovie Account','پروفایل BankMovie':'BankMovie Profile',
  'VIP مادام‌العمر':'Lifetime VIP','VIP فعال':'VIP Active','اشتراک فعال':'Active subscription','اشتراک ویژه فعال نیست':'VIP subscription is inactive',
  'اشتراک مادام‌العمر':'Lifetime subscription','اشتراک ویژه شما فعال است':'Your VIP subscription is active','امکانات ویژه BankMovie':'BankMovie VIP benefits',
  'عضو ویژه BankMovie':'BankMovie VIP Member','کاربر رایگان':'Free user','بدون انقضا':'No expiration','مزایای عضویت شما':'Your membership benefits',
  'پلن‌های سایت همیشه به‌روز':'Plans synced with the website','مشاهده پلن‌ها / تمدید':'View plans / Renew','خرید اشتراک VIP':'Buy VIP subscription',
  'اشتراک ویژه BankMovie':'BankMovie VIP','پلن مورد نظرت را انتخاب کن. قیمت و متن‌ها مستقیماً از سایت همگام می‌شوند.':'Choose a plan. Prices and details are synced directly from the website.',
  'محبوب‌ترین انتخاب':'Most popular','بخش ویژه اعضای VIP':'VIP Members Only','برای استفاده از این قابلیت اشتراک VIP فعال لازم است.':'An active VIP subscription is required for this feature.',
  'اگر اشتراکت تازه فعال شده، وضعیت حساب را بروزرسانی کن.':'If you just activated VIP, refresh your account status.',
  'ابتدا وارد حساب شو یا رایگان ثبت‌نام کن، سپس پلن VIP را انتخاب کن.':'Sign in or register for free, then choose a VIP plan.',
  'بروزرسانی وضعیت اشتراک':'Refresh subscription status','ثبت‌نام رایگان':'Register free','ورود به حساب':'Sign in','اشتراک VIP فعال است':'VIP subscription is active',
  'هنوز اشتراک VIP فعالی روی حساب دیده نشد':'No active VIP subscription was found','این آرشیو ویژه اعضای VIP است':'This archive is for VIP members',
  'پخش آنلاین ویژه اعضای VIP':'VIP streaming only','دانلود ویژه اعضای VIP':'VIP download only','آواتار روی حساب ذخیره و همگام شد':'Avatar saved and synced',
  'ورود انجام نشد':'Sign in failed','خوش آمدی':'Welcome','ثبت‌نام انجام نشد':'Registration failed','حساب ساخته شد':'Account created',
  'برای این اسلاید مقصدی ثبت نشده است':'No destination is set for this slide','برای این اسلاید هنوز مقصد معتبری ثبت نشده است':'This slide has no valid destination yet',
  'اسلاید قبلی':'Previous slide','اسلاید بعدی':'Next slide','ژانر (اختیاری)':'Genre (optional)','کشور (اختیاری)':'Country (optional)',
  'سافت‌ساب':'Softsub','هاردساب':'Hardsub','زیرنویس':'Subtitle','صوت دوبله':'Dubbed audio','بدون زیرنویس':'No subtitles','نسخه رسانه':'Media version',
  'زیرنویس جداگانه':'External subtitle','پوشه':'Folder','قسمت ویژه':'Special episode','توضیحی ثبت نشده است.':'No description is available.',
  'مشاهده تریلر':'Watch Trailer','لینک پخش موجود نیست':'No playable link is available','لینک پخش معتبر نیست':'Invalid playback link',
  'دانلود به صف اضافه شد':'Added to download queue','از لیست حذف شد':'Removed from My List','به لیست اضافه شد':'Added to My List',
  'برای دیدن لیست شخصی وارد حساب شو.':'Sign in to view your personal list.','همگام با حساب BankMovie':'Synced with your BankMovie account',
  'متن دیدگاه کوتاه است':'Comment is too short','دیدگاه ثبت شد':'Comment posted','توضیح گزارش (اختیاری):':'Report details (optional):','ویرایش دیدگاه:':'Edit comment:',
  'دیدگاه حذف شود؟':'Delete this comment?','گزارش ثبت شد':'Report submitted','انجام شد':'Done','دانلود شروع شد':'Download started',
  'اعلان‌ها بعد از ورود به حساب نمایش داده می‌شوند.':'Notifications appear after signing in.','اعلان جدیدی نداری.':'No new notifications.','همه اعلان‌ها خوانده شد':'All notifications marked as read',
  'در حال آماده‌سازی Watch Party…':'Preparing Watch Party…','این قابلیت غیرفعال است':'This feature is disabled','مثلاً ABC123':'e.g. ABC123',
  'اول یک فیلم یا سریال باز کن':'Open a movie or series first','کد اتاق را وارد کن':'Enter the room code','Watch Party فعال':'Watch Party active','پیام…':'Message…',
  'در حال همگام‌سازی پروفایل…':'Syncing profile…','برای همگام‌سازی حساب، اشتراک، آواتار و لیست‌ها وارد شوید.':'Sign in to sync your account, subscription, avatar and lists.',
  'پاک کردن':'Clear','هنوز عنوانی در بازدیدهای اخیر نیست.':'No recent views yet.','وضعیت حساب و اشتراک بروزرسانی شد':'Account and subscription status updated',
  'از حساب خارج شدی':'Signed out','بازدیدهای اخیر پاک شد':'Recent views cleared','آیدی پشتیبانی خرید تنظیم نشده است':'Purchase support ID is not configured',
  'ماجراجویی':'Adventure','بیوگرافی':'Biography','کمدی':'Comedy','جنایی':'Crime','مستند':'Documentary','خانوادگی':'Family','فانتزی':'Fantasy','تاریخی':'History',
  'ترسناک':'Horror','موزیک':'Music','عاشقانه':'Romance','علمی':'Science','علمی‌تخیلی':'Sci-Fi','مدرسه‌ای':'School','کوتاه':'Short','ورزشی':'Sport',
  'ماورایی':'Supernatural','هیجان‌انگیز':'Thriller','جنگی':'War','وسترن':'Western','۲۵۰ فیلم برتر':'Top 250 Movies','۲۵۰ سریال برتر':'Top 250 Series',
  'بازیگر':'Actor','بازیگران':'Cast','اثری برای این بازیگر پیدا نشد.':'No titles found for this actor.','تریلر برای این عنوان ثبت نشده':'No trailer is available for this title',
  'خطایی رخ داد. دوباره تلاش کنید.':'Something went wrong. Please try again.','ارتباط با این بخش برقرار نشد. لطفاً دوباره تلاش کنید.':'Could not connect to this section. Please try again.',
  'در حال محاسبه سرعت…':'Calculating speed…','این دانلود دیگر در صف فعال نیست':'This download is no longer active in the queue','پلیر سازگار نصب نشده':'No compatible player installed',
  'دیدگاه در حال ارسال است':'Sending comment','ارسال ناموفق':'Send failed','حریم خصوصی':'Privacy','دانلود':'Download','پوشه دانلود تغییر کرد':'Download folder changed',
  'کیفیت، دوبله و زیرنویس فقط مربوط به همین قسمت هستند.':'Quality, dubbing and subtitles apply only to this episode.',
  'برای این قسمت کیفیتی ثبت نشده است.':'No quality is available for this episode.','قسمتی برای این سریال ثبت نشده است.':'No episodes are available for this series.',
  'برای این عنوان لینک پخش یا دانلودی موجود نیست.':'No streaming or download link is available for this title.',
  'هیچ پلیر سازگاری پیدا نشد':'No compatible player found','پشتیبانی پایه':'Basic support','زیرنویس پشتیبانی می‌شود':'Subtitle supported',
  'ماه / خورشید':'Moon / Sun','پوشه دانلود':'Download folder','حریم خصوصی':'Privacy','دانلودها':'Downloads','مدیریت دانلود':'Download Manager',
  'خرید اشتراک':'Buy subscription','لیست من':'My List','تغییر تم':'Change theme','تمام صفحه':'Fullscreen','بازگشت':'Back'
});

const bm197TranslateBase=bm191TranslateText;
bm191TranslateText=function(raw){
  let out=bm197TranslateBase(raw);
  if(out!==raw)return out;
  const lead=raw.match(/^\s*/)?.[0]||'',trail=raw.match(/\s*$/)?.[0]||'',t=raw.trim();
  if(!t)return raw;
  let m;
  if((m=t.match(/^آرشیو\s*([۰-۹0-9]+)$/)))return `${lead}Archive ${m[1]}${trail}`;
  if((m=t.match(/^در حال دریافت\s+(.+?)…?$/)))return `${lead}Loading ${m[1]}…${trail}`;
  if((m=t.match(/^برای این عنوان\s+(.+)$/)))return `${lead}For this title: ${m[1]}${trail}`;
  /* Translate compound metadata one token at a time, without touching prose/content. */
  if(/[•·]/.test(t)){
    const parts=t.split(/([•·])/);let changed=false;
    const mapped=parts.map(p=>{if(p==='•'||p==='·')return p;const q=p.trim(),r=BM191_FA_EN[q]||q;if(r!==q)changed=true;return p.replace(q,r)}).join('');
    if(changed)return lead+mapped.trim()+trail;
  }
  return raw;
};

function bm197MountBackButton(){
  const v=$('#view');if(!v)return;
  v.querySelector('.bm-page-back-btn')?.remove();
  if(!state.bm196NavStack?.length)return;
  const btn=document.createElement('button');btn.type='button';btn.className='bm-page-back-btn';btn.setAttribute('aria-label',(state.language||bm191Language)==='en'?'Back':'بازگشت');btn.setAttribute('title',(state.language||bm191Language)==='en'?'Back':'بازگشت');btn.innerHTML=BM197_BACK_SVG;btn.onclick=e=>{e.preventDefault();e.stopPropagation();bm196GoBack()};
  v.appendChild(btn);
}

/* Header no longer owns navigation state; every destination page gets its own back control. */
bm196UpdateBack=function(){requestAnimationFrame(bm197MountBackButton)};

/* Keep the previous page painted while the next page fetches/renders. This removes the black/loading jump seen in the supplied recording. */
bm196Motion=async function(direction,job){
  const v=$('#view');let ghost=null;
  if(v&&v.childElementCount){
    const rect=v.getBoundingClientRect();
    ghost=v.cloneNode(true);ghost.removeAttribute('id');ghost.querySelectorAll('[id]').forEach(x=>x.removeAttribute('id'));
    ghost.className=`${v.className||'view'} bm-nav-ghost`;
    Object.assign(ghost.style,{left:`${rect.left}px`,top:`${rect.top}px`,width:`${rect.width}px`,height:`${Math.max(rect.height,window.innerHeight-rect.top)}px`});
    document.body.appendChild(ghost);v.classList.add('bm-nav-rendering');
  }
  let out;
  try{out=await job()}catch(e){throw e}finally{if(v)v.classList.remove('bm-nav-rendering')}
  if(v){v.classList.remove('bm-page-enter-forward','bm-page-enter-back');void v.offsetWidth;v.classList.add(direction==='back'?'bm-page-enter-back':'bm-page-enter-forward');setTimeout(()=>v.classList.remove('bm-page-enter-forward','bm-page-enter-back'),300)}
  if(ghost){void ghost.offsetWidth;ghost.classList.add(direction==='back'?'bm-nav-ghost-back':'bm-nav-ghost-forward');setTimeout(()=>ghost.remove(),240)}
  bm197MountBackButton();bm191Localize(v);return out;
};

/* Remove empty IMDb detail chips too; a missing provider score should render nothing, not a dash. */
function bm197CleanDetailImdb(){document.querySelectorAll('.imdb-detail-chip').forEach(chip=>{const val=chip.querySelector('b')?.textContent?.trim();if(!val||val==='—'||val==='-')chip.remove()})}

/* New render observer: localize dynamic UI, keep page back in-page, and clean empty IMDb. */
document.addEventListener('DOMContentLoaded',()=>{
  const headerOldBack=$('#backHeader');headerOldBack?.remove();$('#top250MoviesHeader')?.remove();$('#top250SeriesHeader')?.remove();
  /* v1.9.8 deliberately removes the extra full-view MutationObserver added in 1.9.7. */
  bm197MountBackButton();bm197CleanDetailImdb();
});


/* ===== BankMovie Desktop v1.9.8 — restore native navigation / persistent page back / ESC back+exit ===== */
/* v1.9.6/v1.9.7 experimented with cloned page layers and custom enter/leave motion.
   Restore the app's original render behavior: navigation itself adds no animation or delay. */
bm196Motion=async function(_direction,job){return await job()};

function bm198EnsurePageBack(){
  const host=document.body;if(!host)return null;
  let btn=$('#bm198PageBack');
  if(!btn){
    btn=document.createElement('button');
    btn.id='bm198PageBack';btn.type='button';btn.className='bm198-page-back';
    btn.innerHTML=BM197_BACK_SVG;
    btn.onclick=e=>{e.preventDefault();e.stopPropagation();bm196GoBack()};
    host.appendChild(btn);
  }
  const hasBack=!!state.bm196NavStack?.length;
  const en=(state.language||bm191Language)==='en';
  btn.hidden=!hasBack;
  btn.setAttribute('aria-label',en?'Back':'بازگشت');
  btn.setAttribute('title',en?'Back':'بازگشت');
  return btn;
}

/* Old v1.9.7 per-render button is disabled; one lightweight persistent control covers every page. */
bm197MountBackButton=function(){return bm198EnsurePageBack()};
bm196UpdateBack=function(){bm198EnsurePageBack()};

function bm198ExitPrompt(){
  const en=(state.language||bm191Language)==='en';
  const ok=window.confirm(en?'Are you sure you want to close BankMovie?':'مطمئنی می‌خوای BankMovie رو ببندی؟');
  if(ok)bridge.window.close();
}
function bm198EscapeModal(){
  const modal=$('#modal');if(!modal||modal.classList.contains('hidden'))return false;
  if(modal.classList.contains('update-force-mode')){bm198ExitPrompt();return true}
  const authClose=modal.querySelector('[data-close-auth]');if(authClose){authClose.click();return true}
  const later=modal.querySelector('#bmUpdateLater');if(later){later.click();return true}
  modal.classList.remove('auth-mode','update-mode','update-force-mode');
  $('#modalBox')?.classList.remove('auth-site-modal','update-site-modal');
  closeModal();return true;
}

/* ESC = modal back -> page back -> exit confirmation. Alt+Left keeps working too. */
document.addEventListener('keydown',e=>{
  if(e.key!=='Escape'||e.defaultPrevented||e.repeat)return;
  e.preventDefault();e.stopImmediatePropagation();
  if(bm198EscapeModal())return;
  if(state.bm196NavStack?.length){bm196GoBack();return}
  bm198ExitPrompt();
},true);

document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('.bm-page-back-btn,.bm-nav-ghost').forEach(x=>x.remove());
  bm198EnsurePageBack();
  /* Keep only the existing lightweight language observer from v1.9.1; do not clone/localize the whole view twice. */
});
