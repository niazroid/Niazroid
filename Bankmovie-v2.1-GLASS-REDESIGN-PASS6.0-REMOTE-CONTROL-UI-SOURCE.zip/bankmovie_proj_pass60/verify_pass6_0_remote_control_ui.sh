#!/usr/bin/env bash
set -euo pipefail

MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
CONFIG='app/src/main/java/ir/bankmoviee/app/AppConfig.kt'

grep -F 'const val CONFIG_URL_PRIMARY = "https://bankmoviee.ir/app_config.php"' "$CONFIG"
grep -F 'val ARCHIVE4_API_URL' "$CONFIG"
grep -F 'private var archive4ApiBase' "$MAIN"
grep -F '4 -> "$archive4ApiBase?q=' "$MAIN"
grep -F 'private val archivePolicies' "$MAIN"
grep -F 'private fun archivePlaybackEnabled' "$MAIN"
grep -F 'private fun archiveDownloadsEnabled' "$MAIN"
grep -F 'automaticPageLimit = 10' "$MAIN"
grep -F 'activePlayableSheet?.dismiss()' "$MAIN"
grep -F 'bottomMargin = dp(30)' "$MAIN"

test -s server-required/api4.php
test -s server-required/includes/api4_lib.php
test -s server-required/includes/archive_control.php
test -s server-required/includes/download_redirect.php
test -s server-required/includes/remote_delivery_control.php
test -s server-required/admin_app_control.php
test -s server-required/admin_vip_manager.php
test -s server-required/download-subdomain/index.php
test -s server-required/download-subdomain/.htaccess

python3 -m json.tool server-required/bankmovie_remote_config.json.sample >/dev/null

if command -v php >/dev/null 2>&1; then
  php -l server-required/app_config.php
  php -l server-required/admin_app_control.php
  php -l server-required/includes/remote_delivery_control.php
  php -l server-required/includes/download_redirect.php
  php -l server-required/api4.php
fi

echo PASS6_0_REMOTE_CONTROL_UI_OK
