<?php
/**
 * BankMovie DL10 redirect endpoint - path-resilient edition.
 *
 * This endpoint never proxies file bytes. It only decrypts the short-lived
 * BankMovie token and returns HTTP 302 to the original download URL.
 */

/** Resolve the main BankMovie helper without assuming the subdomain's
 * DocumentRoot lives inside the main site's public_html directory. */
function bm_dl10_find_helper(): string|false
{
    $candidates = [];

    // Best option when the host supports environment variables.
    $envRoot = trim((string)(getenv('BANKMOVIE_APP_ROOT') ?: ''));
    if ($envRoot !== '') {
        $candidates[] = rtrim($envRoot, "/\\") . '/includes/download_redirect.php';
    }

    $here = realpath(__DIR__) ?: __DIR__;

    // Walk ancestors. Covers /public_html/dl10 and many cPanel layouts.
    $dir = $here;
    for ($i = 0; $i < 6; $i++) {
        $candidates[] = $dir . '/includes/download_redirect.php';
        $candidates[] = $dir . '/public_html/includes/download_redirect.php';
        $parent = dirname($dir);
        if ($parent === $dir) break;
        $dir = $parent;
    }

    // Common DirectAdmin layout:
    // /home/USER/domains/dl10.bankmovie.top/public_html
    // /home/USER/domains/bankmovie.top/public_html
    $dir = $here;
    for ($i = 0; $i < 6; $i++) {
        if (basename($dir) === 'domains') {
            $candidates[] = $dir . '/bankmovie.top/public_html/includes/download_redirect.php';
            break;
        }
        $parent = dirname($dir);
        if ($parent === $dir) break;
        $dir = $parent;
    }

    // Common separate-subdomain cPanel layout:
    // /home/USER/dl10.bankmovie.top -> main site in /home/USER/public_html
    $dir = $here;
    for ($i = 0; $i < 5; $i++) {
        $candidates[] = dirname($dir) . '/public_html/includes/download_redirect.php';
        $parent = dirname($dir);
        if ($parent === $dir) break;
        $dir = $parent;
    }

    foreach (array_unique($candidates) as $candidate) {
        if (!is_file($candidate) || !is_readable($candidate)) continue;
        $real = realpath($candidate);
        if ($real !== false) return $real;
    }

    return false;
}

$helper = bm_dl10_find_helper();
if ($helper === false) {
    http_response_code(503);
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-BM-DL10-Error: helper_missing');
    echo 'redirect_not_configured';
    exit;
}

require_once $helper;

header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store, private, max-age=0');
header('Pragma: no-cache');

$path = (string)(parse_url((string)($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH) ?: '/');

// Safe health check. Does not expose paths, keys, tokens, or destinations.
if ($path === '/health' || isset($_GET['health'])) {
    $key = function_exists('bm_dl_key') ? bm_dl_key() : false;
    if (is_string($key) && strlen($key) === 32 && function_exists('openssl_decrypt')) {
        http_response_code(200);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'dl10_ok';
    } else {
        http_response_code(503);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'dl10_key_not_ready';
    }
    exit;
}

// New pretty links carry the authenticated token in ?sig=... .
// Legacy /r/<token> and ?t=<token> links remain valid for rollback/backward compatibility.
$token = trim((string)($_GET['sig'] ?? $_GET['t'] ?? ''));
if ($token === '' && preg_match('~^/r/([A-Za-z0-9_-]+)$~', $path, $m)) {
    $token = $m[1];
}

if ($token === '' || strlen($token) > 12000) {
    http_response_code(404);
    exit;
}

$data = bm_dl_decode_token($token);
if (!is_array($data) || empty($data['url'])) {
    http_response_code(410);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'download_link_expired';
    exit;
}

// Redirect only; the media body never traverses BankMovie.
header('Location: ' . $data['url'], true, 302);
header('X-BM-Redirect: 1');
header('X-BM-Expires: ' . (int)$data['exp']);
exit;
