<?php
declare(strict_types=1);

require_once __DIR__ . '/security_bootstrap.php';

function bm_delivery_defaults(): array {
    return [
        'version' => 1,
        'controller_domain' => 'https://bankmoviee.ir',
        'download_proxy_enabled' => true,
        'download_proxy_path' => '/download.php',
        'download_redirect_base' => 'https://dl10.bankmovie.top',
        'hide_origin_links' => true,
        'allowed_download_hosts' => [],
        'url_rewrites' => [],
        'archives' => array_fill_keys(['archive1','archive2','archive3','archive4'], [
            'enabled' => true,
            'hidden' => false,
            'access_scope' => 'public',
            'online_playback' => true,
            'downloads' => true,
            'links_visible' => true,
            'vip_unlock' => false,
        ]),
        'updated_at' => null,
    ];
}

function bm_delivery_path(): string {
    return bm_security_private_path('app-delivery-control.json');
}

function bm_delivery_bool($value, bool $fallback): bool {
    if ($value === null) return $fallback;
    return filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) ?? $fallback;
}

function bm_delivery_normalize(array $input): array {
    $out = array_replace_recursive(bm_delivery_defaults(), $input);
    $controller = trim((string)($out['controller_domain'] ?? ''));
    $out['controller_domain'] = preg_match('~^https://[a-z0-9.-]+(?::\d+)?$~i', rtrim($controller, '/')) ? rtrim($controller, '/') : 'https://bankmoviee.ir';
    $proxyPath = '/' . ltrim(trim((string)($out['download_proxy_path'] ?? '/download.php')), '/');
    $out['download_proxy_path'] = preg_match('~^/[a-zA-Z0-9_./-]+$~', $proxyPath) ? $proxyPath : '/download.php';
    $redirectBase = rtrim(trim((string)($out['download_redirect_base'] ?? '')), '/');
    $out['download_redirect_base'] = preg_match('~^https://[a-z0-9.-]+(?::\d+)?$~i', $redirectBase) ? $redirectBase : 'https://dl10.bankmovie.top';
    $out['download_proxy_enabled'] = bm_delivery_bool($out['download_proxy_enabled'] ?? true, true);
    $out['hide_origin_links'] = bm_delivery_bool($out['hide_origin_links'] ?? true, true);
    $out['allowed_download_hosts'] = array_values(array_unique(array_filter(array_map(static function ($host) {
        $host = strtolower(trim((string)$host));
        return preg_match('~^[a-z0-9.-]+$~', $host) ? $host : '';
    }, (array)($out['allowed_download_hosts'] ?? [])))));
    $rules = [];
    foreach ((array)($out['url_rewrites'] ?? []) as $rule) {
        if (!is_array($rule)) continue;
        $from = trim((string)($rule['from'] ?? ''));
        $to = trim((string)($rule['to'] ?? ''));
        if ($from === '' || $to === '' || !str_starts_with($to, 'https://')) continue;
        $rules[] = ['from'=>$from, 'to'=>rtrim($to, '/'), 'mode'=>'replace', 'enabled'=>bm_delivery_bool($rule['enabled'] ?? true, true)];
    }
    $out['url_rewrites'] = array_slice($rules, 0, 30);
    foreach (['archive1','archive2','archive3','archive4'] as $id) {
        $row = (array)($out['archives'][$id] ?? []);
        $scope = strtolower(trim((string)($row['access_scope'] ?? 'public')));
        if (!in_array($scope, ['public','member','vip','admin'], true)) $scope = 'public';
        $out['archives'][$id] = [
            'enabled'=>bm_delivery_bool($row['enabled'] ?? true, true),
            'hidden'=>bm_delivery_bool($row['hidden'] ?? false, false),
            'access_scope'=>$scope,
            'online_playback'=>bm_delivery_bool($row['online_playback'] ?? true, true),
            'downloads'=>bm_delivery_bool($row['downloads'] ?? true, true),
            'links_visible'=>bm_delivery_bool($row['links_visible'] ?? true, true),
            'vip_unlock'=>bm_delivery_bool($row['vip_unlock'] ?? false, false),
        ];
    }
    $out['version'] = 1;
    $out['updated_at'] = gmdate('c');
    return $out;
}

function bm_delivery_settings(bool $refresh = false): array {
    static $cache = null;
    if (!$refresh && is_array($cache)) return $cache;
    $raw = is_file(bm_delivery_path()) ? @file_get_contents(bm_delivery_path()) : false;
    $decoded = is_string($raw) ? json_decode($raw, true) : null;
    return $cache = bm_delivery_normalize(is_array($decoded) ? $decoded : []);
}

function bm_delivery_save(array $input): bool {
    $normalized = bm_delivery_normalize($input);
    $json = json_encode($normalized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if (!is_string($json)) return false;
    $path = bm_delivery_path();
    $tmp = $path . '.tmp-' . bin2hex(random_bytes(4));
    if (@file_put_contents($tmp, $json . "\n", LOCK_EX) === false) return false;
    @chmod($tmp, 0600);
    if (@rename($tmp, $path)) return true;
    @unlink($tmp);
    return false;
}

function bm_delivery_public_payload(): array {
    $settings = bm_delivery_settings();
    return [
        'controller_domain'=>$settings['controller_domain'],
        'download_proxy'=>[
            'enabled'=>$settings['download_proxy_enabled'],
            'path'=>$settings['download_proxy_path'],
            'hide_origin_links'=>$settings['hide_origin_links'],
        ],
        'download_redirect_base'=>$settings['download_redirect_base'],
        'url_rewrites'=>$settings['url_rewrites'],
        'archive_policies'=>$settings['archives'],
        'updated_at'=>$settings['updated_at'],
    ];
}
