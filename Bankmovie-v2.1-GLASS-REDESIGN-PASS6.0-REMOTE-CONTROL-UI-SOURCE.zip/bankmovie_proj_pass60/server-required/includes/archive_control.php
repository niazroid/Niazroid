<?php
require_once __DIR__ . '/security_bootstrap.php';
require_once __DIR__ . '/vip_features.php';
/**
 * BankMovie Archive/API control helper
 * Shared by /, movie.php, /view_all, api4.php and admin.php.
 */
if (!function_exists('bm_archive_control_defaults')) {
    function bm_archive_control_defaults(): array {
        return [
            'archives' => [
                'archive1' => [
                    'label' => 'آرشیو ۱',
                    'enabled' => true,
                    'access_scope' => 'public',
                    'disabled_mode' => 'visible',
                    'disabled_message' => 'آرشیو ۱ موقتاً در دسترس نیست و به‌زودی برمی‌گردد.',
                ],
                'archive2' => [
                    'label' => 'آرشیو ۲',
                    'enabled' => true,
                    'access_scope' => 'public',
                    'disabled_mode' => 'visible',
                    'disabled_message' => 'آرشیو ۲ موقتاً در دسترس نیست و به‌زودی برمی‌گردد.',
                ],
                'archive3' => [
                    'label' => 'آرشیو ۳',
                    'enabled' => true,
                    'access_scope' => 'public',
                    'disabled_mode' => 'visible',
                    'disabled_message' => 'آرشیو ۳ موقتاً در دسترس نیست و به‌زودی برمی‌گردد.',
                ],
                'archive4' => [
                    'label' => 'آرشیو ۴',
                    'enabled' => true,
                    'access_scope' => 'public',
                    'disabled_mode' => 'visible',
                    'disabled_message' => 'آرشیو ۴ موقتاً در دسترس نیست و به‌زودی برمی‌گردد.',
                ],
            ],
            'audience_schema_version' => 3,
            'updated_at' => null,
        ];
    }
}

if (!function_exists('bm_archive_control_path')) {
    function bm_archive_control_path(): string {
        // Store settings outside public_html when possible. Old public file remains as read-only fallback.
        if (function_exists('bm_security_private_path')) {
            return bm_security_private_path('archive_api_settings.json');
        }
        return dirname(__DIR__) . '/archive_api_settings.json';
    }
}

if (!function_exists('bm_archive_control_legacy_path')) {
    function bm_archive_control_legacy_path(): string {
        return dirname(__DIR__) . '/archive_api_settings.json';
    }
}

if (!function_exists('bm_archive_control_normalize')) {
    function bm_archive_control_normalize(array $settings): array {
        $defaults = bm_archive_control_defaults();
        if (!isset($settings['archives']) || !is_array($settings['archives'])) $settings['archives'] = [];
        foreach ($defaults['archives'] as $id => $def) {
            $row = isset($settings['archives'][$id]) && is_array($settings['archives'][$id]) ? $settings['archives'][$id] : [];
            $label = trim((string)($row['label'] ?? $def['label']));
            $mode = trim((string)($row['disabled_mode'] ?? $def['disabled_mode']));
            if (!in_array($mode, ['visible', 'hide'], true)) $mode = 'visible';
            $scope = trim((string)($row['access_scope'] ?? $def['access_scope'] ?? 'public'));
            if (!in_array($scope, ['public', 'member', 'vip', 'admin'], true)) $scope = 'public';
            $msg = trim((string)($row['disabled_message'] ?? $def['disabled_message']));
            $settings['archives'][$id] = [
                'label' => $label !== '' ? $label : $def['label'],
                'enabled' => filter_var($row['enabled'] ?? $def['enabled'], FILTER_VALIDATE_BOOLEAN),
                'access_scope' => $scope,
                'disabled_mode' => $mode,
                'disabled_message' => $msg !== '' ? $msg : $def['disabled_message'],
            ];
        }
        $settings['audience_schema_version'] = max(0, (int)($settings['audience_schema_version'] ?? 0));
        if (!isset($settings['updated_at'])) $settings['updated_at'] = null;
        return $settings;
    }
}

if (!function_exists('bm_archive_get_settings')) {
    function bm_archive_get_settings(): array {
        $settings = [];
        $paths = [bm_archive_control_path()];
        if (function_exists('bm_archive_control_legacy_path')) $paths[] = bm_archive_control_legacy_path();
        foreach (array_values(array_unique($paths)) as $path) {
            if (is_file($path)) {
                $raw = @file_get_contents($path);
                $json = is_string($raw) ? json_decode($raw, true) : null;
                if (is_array($json)) { $settings = $json; break; }
            }
        }

        // Audience schema migration.
        // v2 introduced Public/Admin. v3 adds Member/VIP while preserving every
        // existing administrator choice instead of resetting scopes.
        $audienceVersion = (int)($settings['audience_schema_version'] ?? 0);
        if ($audienceVersion < 2) {
            if (!isset($settings['archives']) || !is_array($settings['archives'])) $settings['archives'] = [];
            foreach (['archive1','archive2','archive3','archive4'] as $aid) {
                if (!isset($settings['archives'][$aid]) || !is_array($settings['archives'][$aid])) $settings['archives'][$aid] = [];
                $settings['archives'][$aid]['access_scope'] = 'public';
            }
        }
        if ($audienceVersion < 3) {
            $settings['audience_schema_version'] = 3;
            $normalized = bm_archive_control_normalize($settings);
            @bm_archive_save_settings($normalized);
            return $normalized;
        }
        return bm_archive_control_normalize($settings);
    }
}

if (!function_exists('bm_archive_save_settings')) {
    function bm_archive_save_settings(array $settings): bool {
        $settings = bm_archive_control_normalize($settings);
        $settings['audience_schema_version'] = 3;
        $settings['updated_at'] = date('c');
        $json = json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) return false;

        $paths = [bm_archive_control_path()];
        if (function_exists('bm_archive_control_legacy_path')) {
            $paths[] = bm_archive_control_legacy_path();
        }

        foreach (array_values(array_unique($paths)) as $path) {
            $dir = dirname($path);
            if (!is_dir($dir) && !@mkdir($dir, 0700, true)) continue;
            $tmp = $path . '.tmp.' . getmypid() . '.' . bin2hex(random_bytes(3));
            if (@file_put_contents($tmp, $json . PHP_EOL, LOCK_EX) === false) {
                @unlink($tmp);
                continue;
            }
            @chmod($tmp, 0600);
            if (@rename($tmp, $path)) {
                @chmod($path, 0600);
                clearstatcache(true, $path);
                return true;
            }
            @unlink($tmp);
        }
        return false;
    }
}

if (!function_exists('bm_archive_get_config')) {
    function bm_archive_get_config(string $archiveId): array {
        $settings = bm_archive_get_settings();
        return $settings['archives'][$archiveId] ?? bm_archive_control_defaults()['archives'][$archiveId] ?? [];
    }
}

if (!function_exists('bm_archive_is_enabled')) {
    function bm_archive_is_enabled(string $archiveId): bool {
        $cfg = bm_archive_get_config($archiveId);
        return !empty($cfg['enabled']);
    }
}

if (!function_exists('bm_archive_user_is_admin')) {
    function bm_archive_user_is_admin($user = null): bool {
        if ($user === null && isset($GLOBALS['currentUser'])) $user = $GLOBALS['currentUser'];
        if (!is_array($user)) return false;
        $role = strtolower(trim((string)($user['role'] ?? '')));
        return in_array($role, ['admin', 'administrator'], true);
    }
}

/**
 * Professional archive audience gate.
 *
 * public = everybody
 * member = any signed-in account
 * vip    = active VIP + administrators
 * admin  = administrators only
 *
 * Unauthorized audiences are always hidden from UI render helpers and direct
 * API/detail requests are rejected by their existing bm_archive_user_can_access()
 * checks.
 */
if (!function_exists('bm_archive_access_scope')) {
    function bm_archive_access_scope(string $archiveId): string {
        $cfg = bm_archive_get_config($archiveId);
        $scope = strtolower(trim((string)($cfg['access_scope'] ?? 'public')));
        return in_array($scope, ['public','member','vip','admin'], true) ? $scope : 'public';
    }
}

if (!function_exists('bm_archive_resolve_user')) {
    function bm_archive_resolve_user($user = null): ?array {
        if ($user === null && isset($GLOBALS['currentUser']) && is_array($GLOBALS['currentUser'])) {
            $user = $GLOBALS['currentUser'];
        }
        return is_array($user) ? $user : null;
    }
}

if (!function_exists('bm_archive_user_is_member')) {
    function bm_archive_user_is_member($user = null): bool {
        $user = bm_archive_resolve_user($user);
        if (!is_array($user)) return false;
        if (bm_archive_user_is_admin($user)) return true;
        if (!empty($user['id'])) return true;
        $role = strtolower(trim((string)($user['role'] ?? '')));
        return $role !== '' && !in_array($role, ['guest','anonymous'], true);
    }
}

if (!function_exists('bm_archive_user_is_vip')) {
    function bm_archive_user_is_vip($user = null): bool {
        $user = bm_archive_resolve_user($user);
        if (!is_array($user)) return false;
        if (bm_archive_user_is_admin($user)) return true;

        if (function_exists('bm_vip_user_is_active')) {
            return bm_vip_user_is_active($user);
        }

        // Defensive fallback if VIP helper is unavailable on an unusual route.
        $role = strtolower(trim((string)($user['role'] ?? '')));
        if (!in_array($role, ['vip','premium','special'], true)) return false;
        $expiry = trim((string)($user['vip_expires_at'] ?? ''));
        if ($expiry === '') return true;
        $ts = strtotime($expiry);
        return $ts !== false && $ts > time();
    }
}

if (!function_exists('bm_archive_user_can_access')) {
    function bm_archive_user_can_access(string $archiveId, $user = null): bool {
        $scope = bm_archive_access_scope($archiveId);
        if ($scope === 'public') return true;
        if ($scope === 'member') return bm_archive_user_is_member($user);
        if ($scope === 'vip') return bm_archive_user_is_vip($user);
        if ($scope === 'admin') return bm_archive_user_is_admin(bm_archive_resolve_user($user));
        return false;
    }
}

if (!function_exists('bm_archive_access_scope_label')) {
    function bm_archive_access_scope_label(string $archiveId): string {
        $scope = bm_archive_access_scope($archiveId);
        return [
            'public' => 'همه کاربران',
            'member' => 'فقط کاربران واردشده',
            'vip' => 'فقط VIP فعال',
            'admin' => 'فقط مدیر',
        ][$scope] ?? 'همه کاربران';
    }
}

if (!function_exists('bm_archive_should_render_tab')) {
    function bm_archive_should_render_tab(string $archiveId): bool {
        if (!bm_archive_user_can_access($archiveId)) return false;
        $cfg = bm_archive_get_config($archiveId);
        return !empty($cfg['enabled']) || (($cfg['disabled_mode'] ?? 'visible') !== 'hide');
    }
}

if (!function_exists('bm_archive_disabled_message')) {
    function bm_archive_disabled_message(string $archiveId): string {
        $cfg = bm_archive_get_config($archiveId);
        return trim((string)($cfg['disabled_message'] ?? 'این آرشیو موقتاً در دسترس نیست و به‌زودی برمی‌گردد.'));
    }
}

if (!function_exists('bm_archive_label')) {
    function bm_archive_label(string $archiveId, string $fallback = ''): string {
        $cfg = bm_archive_get_config($archiveId);
        $label = trim((string)($cfg['label'] ?? ''));
        return $label !== '' ? $label : $fallback;
    }
}

if (!function_exists('bm_archive_public_config')) {
    function bm_archive_public_config(): array {
        $settings = bm_archive_get_settings();
        $out = [];
        foreach ($settings['archives'] as $id => $cfg) {
            $canAccess = bm_archive_user_can_access((string)$id);
            $out[$id] = [
                'label' => (string)($cfg['label'] ?? ''),
                'enabled' => $canAccess && !empty($cfg['enabled']),
                'access_scope' => (string)($cfg['access_scope'] ?? 'public'),
                'disabled_mode' => (string)($cfg['disabled_mode'] ?? 'visible'),
                'disabled_message' => (string)($cfg['disabled_message'] ?? ''),
                'render_tab' => $canAccess && (!empty($cfg['enabled']) || (($cfg['disabled_mode'] ?? 'visible') !== 'hide')),
                'preview_admin_only' => (($cfg['access_scope'] ?? 'public') === 'admin'),
                'preview_vip_only' => (($cfg['access_scope'] ?? 'public') === 'vip'),
                'preview_members_only' => (($cfg['access_scope'] ?? 'public') === 'member'),
                'access_scope_label' => function_exists('bm_archive_access_scope_label') ? bm_archive_access_scope_label((string)$id) : (string)($cfg['access_scope'] ?? 'public'),
            ];
        }
        return $out;
    }
}

if (!function_exists('bm_archive_default_mode')) {
    function bm_archive_default_mode(): string {
        $map = ['archive1' => 'arc1', 'archive2' => 'local', 'archive3' => 'arc3', 'archive4' => 'arc4'];
        foreach (['archive1','archive2','archive3','archive4'] as $id) {
            if (bm_archive_is_enabled($id) && bm_archive_should_render_tab($id)) return $map[$id];
        }
        return 'local';
    }
}

if (!function_exists('bm_archive_cookie_file')) {
    function bm_archive_cookie_file(string $archiveId): ?string {
        if ($archiveId !== 'archive4') return null;
        $name = 'api4_cookie.txt';
        if (function_exists('bm_security_private_path')) return bm_security_private_path($name);
        return dirname(__DIR__) . '/' . $name;
    }
}

if (!function_exists('bm_archive_cookie_legacy_file')) {
    function bm_archive_cookie_legacy_file(string $archiveId): ?string {
        if ($archiveId === 'archive4') return dirname(__DIR__) . '/api4_cookie.txt';
        return null;
    }
}

if (!function_exists('bm_archive_cookie_status')) {
    function bm_archive_cookie_status(string $archiveId): array {
        $file = bm_archive_cookie_file($archiveId);
        if (!$file) return ['supported'=>false, 'exists'=>false, 'bytes'=>0, 'updated'=>null, 'preview'=>'', 'storage'=>'none'];
        $readFile = $file;
        $exists = is_file($readFile);
        $raw = $exists ? (string)@file_get_contents($readFile) : '';
        $raw = trim($raw);
        $preview = '';
        if ($raw !== '') $preview = substr($raw, 0, 28) . '••••' . substr($raw, -16);
        return [
            'supported'=>true,
            'exists'=>$exists,
            'bytes'=>strlen($raw),
            'updated'=>$exists ? @date('Y-m-d H:i:s', (int)@filemtime($readFile)) : null,
            'preview'=>$preview,
            'storage'=>($readFile === $file ? 'private' : 'legacy'),
        ];
    }
}

if (!function_exists('bm_archive_write_cookie')) {
    function bm_archive_write_cookie(string $archiveId, string $cookie): bool {
        $file = bm_archive_cookie_file($archiveId);
        if (!$file) return false;
        $cookie = function_exists('bm_security_normalize_cookie') ? bm_security_normalize_cookie($cookie) : trim($cookie);
        if ($cookie === '') return false;
        $dir = dirname($file);
        if (!is_dir($dir)) @mkdir($dir, 0700, true);
        $ok = (bool)@file_put_contents($file, $cookie . PHP_EOL, LOCK_EX);
        if ($ok) @chmod($file, 0600);
        return $ok;
    }
}

if (!function_exists('bm_archive_clear_cookie')) {
    function bm_archive_clear_cookie(string $archiveId): bool {
        $ok = false;
        foreach ([bm_archive_cookie_file($archiveId), function_exists('bm_archive_cookie_legacy_file') ? bm_archive_cookie_legacy_file($archiveId) : null] as $file) {
            if (!$file) continue;
            $dir = dirname($file);
            if (!is_dir($dir)) @mkdir($dir, 0700, true);
            $ok = (bool)@file_put_contents($file, '', LOCK_EX) || $ok;
            if (is_file($file)) @chmod($file, 0600);
        }
        return $ok;
    }
}
