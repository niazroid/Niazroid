<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/includes/admin_guard.php';
require_once __DIR__ . '/includes/remote_delivery_control.php';
require_once __DIR__ . '/includes/vip_sales.php';
require_admin();
admin_enforce_csrf();
$csrf = admin_csrf_token();
$ok = null;
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $archives = [];
    foreach (['archive1','archive2','archive3','archive4'] as $id) {
        $archives[$id] = [
            'enabled'=>isset($_POST[$id.'_enabled']), 'hidden'=>isset($_POST[$id.'_hidden']),
            'access_scope'=>$_POST[$id.'_access_scope'] ?? 'public',
            'online_playback'=>isset($_POST[$id.'_online_playback']), 'downloads'=>isset($_POST[$id.'_downloads']),
            'links_visible'=>isset($_POST[$id.'_links_visible']), 'vip_unlock'=>isset($_POST[$id.'_vip_unlock']),
        ];
    }
    $rewrites = [];
    foreach (preg_split('/\R+/', (string)($_POST['url_rewrites'] ?? '')) ?: [] as $line) {
        $parts = array_map('trim', explode('=>', $line, 2));
        if (count($parts) === 2 && $parts[0] !== '' && $parts[1] !== '') $rewrites[] = ['from'=>$parts[0], 'to'=>$parts[1], 'enabled'=>true];
    }
    $ok = bm_delivery_save([
        'controller_domain'=>$_POST['controller_domain'] ?? '',
        'download_proxy_enabled'=>isset($_POST['download_proxy_enabled']), 'hide_origin_links'=>isset($_POST['hide_origin_links']),
        'download_proxy_path'=>$_POST['download_proxy_path'] ?? '/download.php',
        'download_redirect_base'=>$_POST['download_redirect_base'] ?? '',
        'allowed_download_hosts'=>preg_split('/[\s,]+/', (string)($_POST['allowed_download_hosts'] ?? ''), -1, PREG_SPLIT_NO_EMPTY),
        'url_rewrites'=>$rewrites, 'archives'=>$archives,
    ]);
}
$s = bm_delivery_settings(true);
function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>کنترل اپ بانک‌مووی</title>
<style>body{margin:0;background:#05070c;color:#f6f7fb;font-family:Tahoma;padding:24px}.wrap{max-width:1100px;margin:auto}.card{background:#11151f;border:1px solid #303746;border-radius:22px;padding:20px;margin:14px 0}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}.archive{background:#171c27;border:1px solid #343d4e;border-radius:18px;padding:16px}label{display:block;margin:9px 0}input,select,textarea{box-sizing:border-box;width:100%;background:#0b0e15;color:#fff;border:1px solid #3a4354;border-radius:12px;padding:11px}input[type=checkbox]{width:auto}button{background:linear-gradient(90deg,#2684ff,#7a3cff);border:0;border-radius:14px;color:#fff;padding:14px 26px;font-weight:bold}.ok{color:#62dc9f}</style></head><body><main class="wrap"><h1>کنترل ریموت اپ بانک‌مووی</h1><?php if($ok!==null):?><p class="ok"><?= $ok?'ذخیره شد':'ذخیره ناموفق بود' ?></p><?php endif;?><form method="post"><input type="hidden" name="csrf_token" value="<?=h($csrf)?>"><section class="card"><h2>دامنه و لینک‌های دانلود</h2><div class="grid"><label>دامنه کنترلر<input dir="ltr" name="controller_domain" value="<?=h($s['controller_domain'])?>"></label><label>ساب‌دامین ریدایرکت دانلود<input dir="ltr" name="download_redirect_base" value="<?=h($s['download_redirect_base'])?>"></label><label>مسیر پروکسی دانلود<input dir="ltr" name="download_proxy_path" value="<?=h($s['download_proxy_path'])?>"></label></div><label><input type="checkbox" name="download_proxy_enabled" <?=$s['download_proxy_enabled']?'checked':''?>> پروکسی دانلود فعال</label><label><input type="checkbox" name="hide_origin_links" <?=$s['hide_origin_links']?'checked':''?>> آدرس واقعی لینک‌ها از اپ مخفی شود</label><label>دامنه‌های مجاز دانلود<textarea dir="ltr" name="allowed_download_hosts"><?=h(implode("\n",$s['allowed_download_hosts']))?></textarea></label><label>تعویض دامنه‌ها؛ هر خط: old.example => https://new.example<textarea dir="ltr" name="url_rewrites"><?php foreach($s['url_rewrites'] as $r) echo h($r['from'].' => '.$r['to'])."\n";?></textarea></label></section><section class="card"><h2>کنترل کامل آرشیوها</h2><div class="grid"><?php foreach($s['archives'] as $id=>$a):?><div class="archive"><h3><?=h(str_replace('archive','آرشیو ',$id))?></h3><label><input type="checkbox" name="<?=$id?>_enabled" <?=$a['enabled']?'checked':''?>> فعال</label><label><input type="checkbox" name="<?=$id?>_hidden" <?=$a['hidden']?'checked':''?>> مخفی کامل</label><label>سطح دسترسی<select name="<?=$id?>_access_scope"><?php foreach(['public'=>'عمومی','member'=>'عضو','vip'=>'VIP','admin'=>'مدیر'] as $v=>$l):?><option value="<?=$v?>" <?=$a['access_scope']===$v?'selected':''?>><?=$l?></option><?php endforeach;?></select></label><label><input type="checkbox" name="<?=$id?>_online_playback" <?=$a['online_playback']?'checked':''?>> پخش آنلاین</label><label><input type="checkbox" name="<?=$id?>_downloads" <?=$a['downloads']?'checked':''?>> دانلود</label><label><input type="checkbox" name="<?=$id?>_links_visible" <?=$a['links_visible']?'checked':''?>> نمایش لینک‌ها</label><label><input type="checkbox" name="<?=$id?>_vip_unlock" <?=$a['vip_unlock']?'checked':''?>> بازشدن با VIP</label></div><?php endforeach;?></div></section><button>ذخیره تنظیمات</button> <a style="color:#ffd66b" href="admin_vip_manager.php">مدیریت قیمت و پلن VIP</a></form></main></body></html>
