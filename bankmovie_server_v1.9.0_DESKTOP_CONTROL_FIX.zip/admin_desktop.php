<?php
declare(strict_types=1);
require_once __DIR__.'/includes/security_bootstrap.php';
require_once __DIR__.'/includes/admin_guard.php';
require_once __DIR__.'/includes/desktop_config_lib.php';
require_admin();
admin_enforce_csrf();

$cfg=bm_desktop_config_load();
$site=bm_desktop_site_remote_config();
$message='';$error='';
$archiveIds=['archive1','archive2','archive3','archive4','archive5'];
$featureLabels=[
 'registration_enabled'=>'ثبت‌نام','login_enabled'=>'ورود','comments_enabled'=>'دیدگاه‌ها','comment_replies_enabled'=>'پاسخ دیدگاه',
 'comment_votes_enabled'=>'رأی دیدگاه','comment_reports_enabled'=>'گزارش دیدگاه','comment_spoiler_enabled'=>'هشدار اسپویل',
 'notification_center_enabled'=>'مرکز اعلان','internal_downloader_enabled'=>'دانلودر داخلی','multipart_download_enabled'=>'دانلود چندبخشی',
 'download_path_selection_enabled'=>'انتخاب پوشه دانلود','advanced_search_enabled'=>'جستجوی پیشرفته','categories_enabled'=>'دسته‌بندی',
 'watchlist_enabled'=>'لیست من','continue_watching_enabled'=>'ادامه تماشا','watch_party_enabled'=>'Watch Party','external_player_fallback_enabled'=>'پلیر خارجی'
];
$scopeLabels=['public'=>'عمومی','member'=>'کاربر واردشده','vip'=>'VIP','admin'=>'فقط مدیر','disabled'=>'غیرفعال'];

if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'){
  try{
    $action=(string)($_POST['desktop_action']??'save');
    if($action==='save'){
      $cfg['enabled']=isset($_POST['enabled']);
      $cfg['latest_version']=trim((string)($_POST['latest_version']??$cfg['latest_version']));
      $cfg['minimum_version']=trim((string)($_POST['minimum_version']??$cfg['minimum_version']));
      $cfg['force_update']=isset($_POST['force_update']);
      $cfg['download_url']=trim((string)($_POST['download_url']??''));
      $cfg['notice']['enabled']=isset($_POST['notice_enabled']);
      $cfg['notice']['title']=trim((string)($_POST['notice_title']??''));
      $cfg['notice']['message']=trim((string)($_POST['notice_message']??''));
      foreach($featureLabels as $key=>$label)$cfg['features'][$key]=isset($_POST['feature'][$key]);
      foreach($archiveIds as $id){
        $cfg['archives'][$id]['inherit_site_policy']=isset($_POST['archive'][$id]['inherit_site_policy']);
        $cfg['archives'][$id]['enabled']=isset($_POST['archive'][$id]['enabled']);
        $cfg['archives'][$id]['hidden']=isset($_POST['archive'][$id]['hidden']);
        $cfg['archives'][$id]['access_scope']=(string)($_POST['archive'][$id]['access_scope']??'public');
        $cfg['archives'][$id]['stream_access_scope']=(string)($_POST['archive'][$id]['stream_access_scope']??'public');
        $cfg['archives'][$id]['download_access_scope']=(string)($_POST['archive'][$id]['download_access_scope']??'public');
      }
      if(!bm_desktop_config_save($cfg))throw new RuntimeException('ذخیره تنظیمات دسکتاپ انجام نشد.');
      $cfg=bm_desktop_config_load();$message='تنظیمات نسخه Windows ذخیره شد.';
    }elseif($action==='sync_site'){
      $sitePolicies=(array)($site['app_archive_policy']??[]);
      foreach($archiveIds as $id){
        $s=(array)($sitePolicies[$id]??[]);
        foreach(['enabled','hidden','access_scope','stream_access_scope','download_access_scope'] as $field){if(array_key_exists($field,$s))$cfg['archives'][$id][$field]=$s[$field];}
        $cfg['archives'][$id]['inherit_site_policy']=true;
      }
      if(!bm_desktop_config_save($cfg))throw new RuntimeException('همگام‌سازی سیاست آرشیوها انجام نشد.');
      $cfg=bm_desktop_config_load();$message='سیاست آرشیوها با تنظیمات فعلی سایت همگام شد.';
    }
  }catch(Throwable $e){$error=$e->getMessage();}
}
$effective=bm_desktop_effective_archive_policies($cfg,$site);
function h($v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function checked($v):string{return !empty($v)?' checked':'';}
function opt(array $labels,string $value,bool $allowDisabled=true):string{$out='';foreach($labels as $k=>$label){if(!$allowDisabled&&$k==='disabled')continue;$out.='<option value="'.h($k).'"'.($k===$value?' selected':'').'>'.h($label).'</option>'; }return $out;}
$sitePolicy=(array)($site['app_archive_policy']??[]);
?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>کنترل دسکتاپ | BankMovie</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><style>
:root{--bg:#070a10;--panel:#0d131f;--panel2:#101827;--line:#22324b;--text:#edf5ff;--muted:#8fa3bd;--blue:#2f7cff;--cyan:#45c7ff;--gold:#eabf59;--red:#ff5f67;--green:#34d399}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 80% 0,rgba(47,124,255,.11),transparent 30%),var(--bg);color:var(--text);font-family:Tahoma,Arial,sans-serif}.top{position:sticky;top:0;z-index:20;height:66px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;border-bottom:1px solid #1d2a3f;background:rgba(7,10,16,.96);backdrop-filter:blur(12px)}.brand{display:flex;align-items:center;gap:12px}.brand b{font-size:16px;letter-spacing:.4px}.brand i{width:34px;height:34px;border-radius:11px;display:grid;place-items:center;background:linear-gradient(135deg,#1f7cff,#54d2ff);box-shadow:0 0 28px rgba(47,124,255,.25);font-style:normal;font-weight:900}.top a{color:#b8c7da;text-decoration:none;border:1px solid #26364e;padding:9px 13px;border-radius:10px}.wrap{max-width:1440px;margin:0 auto;padding:28px}.hero{display:flex;justify-content:space-between;align-items:center;gap:20px;padding:24px;border:1px solid #21324b;border-radius:24px;background:linear-gradient(135deg,rgba(47,124,255,.12),rgba(13,19,31,.92));margin-bottom:20px}.hero h1{margin:0 0 8px;font-size:28px}.hero p{margin:0;color:var(--muted);line-height:1.9}.status{display:flex;gap:8px;flex-wrap:wrap}.pill{border:1px solid #2a3c57;border-radius:999px;padding:7px 11px;color:#c9d8ea;background:#0a101a;font-size:11px}.pill.ok{color:#baf8df;border-color:rgba(52,211,153,.3)}.msg{padding:13px 16px;border-radius:13px;margin:0 0 16px}.msg.ok{background:rgba(52,211,153,.1);border:1px solid rgba(52,211,153,.28);color:#baf8df}.msg.err{background:rgba(255,95,103,.1);border:1px solid rgba(255,95,103,.28);color:#ffd1d4}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.panel{border:1px solid #1d2b40;border-radius:20px;background:linear-gradient(180deg,#0d131f,#090e17);padding:18px}.panel.full{grid-column:1/-1}.panel h2{font-size:17px;margin:0 0 15px}.row{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.field{display:flex;flex-direction:column;gap:7px;margin-bottom:12px}.field label{font-size:11px;color:#b7c7d9;font-weight:800}.field input[type=text],.field input[type=url],.field textarea,.field select{width:100%;background:#080d15;color:#edf5ff;border:1px solid #26364e;border-radius:11px;padding:11px 12px;outline:0}.field textarea{min-height:90px;resize:vertical}.toggle{display:flex;align-items:center;gap:9px;padding:9px 10px;border:1px solid #203047;border-radius:11px;background:#0a1019;font-size:11px}.toggle input{accent-color:#2f7cff}.features{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:9px}.archive-card{border:1px solid #22324b;border-radius:16px;background:#0a1019;padding:14px}.archive-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}.archive-head strong{font-size:15px}.site-mini{font-size:9px;color:#7f95b0}.archive-controls{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}.archive-flags{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px}.effective{margin-top:10px;padding:9px;border-radius:10px;background:#07121f;color:#9fc7ff;font-size:10px;line-height:1.8}.actions{position:sticky;bottom:0;z-index:15;display:flex;gap:10px;justify-content:flex-start;padding:14px;margin-top:18px;border:1px solid #21314a;border-radius:16px;background:rgba(8,12,19,.95);backdrop-filter:blur(10px)}button{font:inherit}.btn{border:0;border-radius:11px;padding:11px 16px;font-weight:900;cursor:pointer}.btn.primary{background:linear-gradient(135deg,#2f7cff,#4cc7ff);color:#fff}.btn.ghost{background:#111a28;color:#d6e3f3;border:1px solid #2a3b55}.hint{font-size:10px;color:#7f92aa;line-height:1.8}@media(max-width:1000px){.grid,.row{grid-template-columns:1fr}.features{grid-template-columns:repeat(2,1fr)}.archive-controls{grid-template-columns:1fr}.panel.full{grid-column:auto}}
</style></head><body>
<header class="top"><div class="brand"><i>BM</i><div><b>BankMovie Desktop Control</b><div class="hint">پنل مستقل نسخه Windows</div></div></div><div style="display:flex;gap:8px"><a href="admin.php">پنل اصلی</a><a href="bm_admin.php">کنترل اپ</a></div></header>
<main class="wrap"><section class="hero"><div><h1>کنترل نسخه دسکتاپ</h1><p>آرشیوها، VIP، قابلیت‌ها، نسخه و اطلاعیه Windows را بدون دست‌زدن به Android مدیریت کن.</p></div><div class="status"><span class="pill ok">Desktop Config v2</span><span class="pill">آخرین بروزرسانی: <?=h($cfg['updated_at']??'—')?></span></div></section>
<?php if($message):?><div class="msg ok"><?=h($message)?></div><?php endif;?><?php if($error):?><div class="msg err"><?=h($error)?></div><?php endif;?>
<form method="post"><?=admin_csrf_input()?><input type="hidden" name="desktop_action" value="save">
<div class="grid">
<section class="panel"><h2>نسخه و انتشار</h2><div class="row"><div class="field"><label>آخرین نسخه</label><input name="latest_version" type="text" value="<?=h($cfg['latest_version'])?>"></div><div class="field"><label>حداقل نسخه</label><input name="minimum_version" type="text" value="<?=h($cfg['minimum_version'])?>"></div></div><div class="field"><label>لینک دانلود نسخه جدید</label><input name="download_url" type="url" value="<?=h($cfg['download_url'])?>" placeholder="https://..."></div><div class="archive-flags"><label class="toggle"><input type="checkbox" name="enabled"<?=checked($cfg['enabled'])?>> اپ Windows فعال</label><label class="toggle"><input type="checkbox" name="force_update"<?=checked($cfg['force_update'])?>> بروزرسانی اجباری</label></div></section>
<section class="panel"><h2>اطلاعیه داخل برنامه</h2><label class="toggle" style="margin-bottom:12px"><input type="checkbox" name="notice_enabled"<?=checked($cfg['notice']['enabled'])?>> نمایش اطلاعیه</label><div class="field"><label>عنوان</label><input name="notice_title" type="text" value="<?=h($cfg['notice']['title'])?>"></div><div class="field"><label>متن</label><textarea name="notice_message"><?=h($cfg['notice']['message'])?></textarea></div></section>
<section class="panel full"><h2>قابلیت‌های Windows</h2><div class="features"><?php foreach($featureLabels as $key=>$label):?><label class="toggle"><input type="checkbox" name="feature[<?=h($key)?>]"<?=checked($cfg['features'][$key]??false)?>> <?=h($label)?></label><?php endforeach;?></div></section>
<section class="panel full"><div style="display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:14px"><div><h2 style="margin:0 0 5px">آرشیوها و دسترسی VIP</h2><div class="hint">اگر «همگام با سایت» فعال باشد، سیاست سایت/Android مرجع است. با خاموش‌کردنش Desktop مستقل کنترل می‌شود.</div></div><button class="btn ghost" type="submit" name="desktop_action" value="sync_site">همگام‌سازی با سایت</button></div><div class="grid">
<?php foreach($archiveIds as $id):$n=(int)preg_replace('/\D+/','',$id);$r=$cfg['archives'][$id];$e=$effective[$id];$sp=(array)($sitePolicy[$id]??[]);?>
<div class="archive-card"><div class="archive-head"><strong>آرشیو <?=$n?></strong><span class="site-mini">سایت: <?=h($sp['stream_access_scope']??'public')?> / <?=h($sp['download_access_scope']??'public')?></span></div><div class="archive-flags"><label class="toggle"><input type="checkbox" name="archive[<?=$id?>][inherit_site_policy]"<?=checked($r['inherit_site_policy'])?>> همگام با سایت</label><label class="toggle"><input type="checkbox" name="archive[<?=$id?>][enabled]"<?=checked($r['enabled'])?>> فعال</label><label class="toggle"><input type="checkbox" name="archive[<?=$id?>][hidden]"<?=checked($r['hidden'])?>> مخفی</label></div><div class="archive-controls"><div class="field"><label>ورود به آرشیو</label><select name="archive[<?=$id?>][access_scope]"><?=opt($scopeLabels,(string)$r['access_scope'],false)?></select></div><div class="field"><label>پخش</label><select name="archive[<?=$id?>][stream_access_scope]"><?=opt($scopeLabels,(string)$r['stream_access_scope'],true)?></select></div><div class="field"><label>دانلود</label><select name="archive[<?=$id?>][download_access_scope]"><?=opt($scopeLabels,(string)$r['download_access_scope'],true)?></select></div></div><div class="effective">وضعیت مؤثر Desktop: ورود <b><?=h($e['access_scope'])?></b> • پخش <b><?=h($e['stream_access_scope'])?></b> • دانلود <b><?=h($e['download_access_scope'])?></b></div></div>
<?php endforeach;?></div></section>
</div><div class="actions"><button class="btn primary" type="submit">ذخیره تنظیمات Desktop</button><a class="btn ghost" style="text-decoration:none" href="admin.php">بازگشت</a></div></form></main></body></html>
