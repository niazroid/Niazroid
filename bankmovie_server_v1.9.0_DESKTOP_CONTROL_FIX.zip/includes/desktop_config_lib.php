<?php
declare(strict_types=1);

function bm_desktop_config_defaults(): array {
    $archives=[];
    foreach(['archive1','archive2','archive3','archive4','archive5'] as $id){
        $archives[$id]=[
            'inherit_site_policy'=>$id!=='archive5',
            'enabled'=>true,
            'hidden'=>false,
            'access_scope'=>'public',
            'download_access_scope'=>$id==='archive5'?'vip':'public',
            'stream_access_scope'=>$id==='archive5'?'vip':'public',
        ];
    }
    return [
        'schema_version'=>2,
        'enabled'=>true,
        'active_domain'=>'https://bankmovie.top',
        'desktop_api_path'=>'/desktop_api.php',
        'account_api_path'=>'/desktop_user_api.php',
        'latest_version'=>'1.9.0',
        'minimum_version'=>'1.9.0',
        'force_update'=>false,
        'download_url'=>'',
        'notice'=>['enabled'=>false,'title'=>'','message'=>''],
        'features'=>[
            'registration_enabled'=>true,
            'login_enabled'=>true,
            'comments_enabled'=>true,
            'comment_replies_enabled'=>true,
            'comment_votes_enabled'=>true,
            'comment_reports_enabled'=>true,
            'comment_spoiler_enabled'=>true,
            'notification_center_enabled'=>true,
            'internal_downloader_enabled'=>true,
            'multipart_download_enabled'=>true,
            'download_path_selection_enabled'=>true,
            'advanced_search_enabled'=>true,
            'categories_enabled'=>true,
            'watchlist_enabled'=>true,
            'continue_watching_enabled'=>false,
            'watch_party_enabled'=>false,
            'external_player_fallback_enabled'=>true,
        ],
        'archives'=>$archives,
        'updated_at'=>gmdate('c'),
    ];
}
function bm_desktop_config_path(): string {
    if (function_exists('bm_security_private_path')) return bm_security_private_path('desktop-app-config.json');
    return dirname(__DIR__) . '/bankmovie_desktop_config.json';
}
function bm_desktop_bool($v, bool $fallback): bool {
    if ($v === null) return $fallback;
    return filter_var($v, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) ?? $fallback;
}
function bm_desktop_scope(string $value, string $fallback='public', bool $feature=false): string {
    $v=strtolower(trim($value));
    $allowed=$feature?['public','member','vip','admin','disabled']:['public','member','vip','admin'];
    return in_array($v,$allowed,true)?$v:$fallback;
}
function bm_desktop_config_normalize(array $raw): array {
    $sourceSchema=(int)($raw['schema_version']??0);
    $hadLegacyConfig=!empty($raw);
    $cfg=array_replace_recursive(bm_desktop_config_defaults(),$raw);
    // v1.8 used local public defaults that could mask the live site policy.
    // Migrate an existing legacy Desktop config back to site inheritance so
    // Windows follows the same archive access rules as Web/Android.
    if($hadLegacyConfig && $sourceSchema>0 && $sourceSchema<2){
        foreach(['archive1','archive2','archive3','archive4','archive5'] as $legacyId){
            $cfg['archives'][$legacyId]['inherit_site_policy']=true;
        }
    }
    $domain=rtrim(trim((string)($cfg['active_domain']??'')),'/');
    if(!preg_match('~^https://[a-z0-9.-]+(?::\d+)?$~i',$domain))$domain='https://bankmovie.top';
    $cfg['active_domain']=$domain;
    foreach(['desktop_api_path'=>'/desktop_api.php','account_api_path'=>'/desktop_user_api.php'] as $k=>$fallback){
        $v='/' . ltrim(trim((string)($cfg[$k]??$fallback)),'/');
        $cfg[$k]=preg_match('~^/[A-Za-z0-9_./-]+\.php$~',$v)?$v:$fallback;
    }
    $cfg['enabled']=bm_desktop_bool($cfg['enabled']??true,true);
    $cfg['force_update']=bm_desktop_bool($cfg['force_update']??false,false);
    $cfg['latest_version']=substr(trim((string)($cfg['latest_version']??'1.9.0')),0,40);
    $cfg['minimum_version']=substr(trim((string)($cfg['minimum_version']??'1.9.0')),0,40);
    $dl=trim((string)($cfg['download_url']??''));
    $cfg['download_url']=$dl===''||preg_match('~^https://~i',$dl)?$dl:'';
    foreach((array)$cfg['features'] as $k=>$v)$cfg['features'][$k]=bm_desktop_bool($v,true);
    foreach(['archive1','archive2','archive3','archive4','archive5'] as $id){
        $r=(array)($cfg['archives'][$id]??[]);
        $r['inherit_site_policy']=bm_desktop_bool($r['inherit_site_policy']??true,true);
        $r['enabled']=bm_desktop_bool($r['enabled']??true,true);
        $r['hidden']=bm_desktop_bool($r['hidden']??false,false);
        $r['access_scope']=bm_desktop_scope((string)($r['access_scope']??'public'));
        $r['download_access_scope']=bm_desktop_scope((string)($r['download_access_scope']??'public'),'public',true);
        $r['stream_access_scope']=bm_desktop_scope((string)($r['stream_access_scope']??'public'),'public',true);
        $cfg['archives'][$id]=$r;
    }
    $cfg['notice']['enabled']=bm_desktop_bool($cfg['notice']['enabled']??false,false);
    $cfg['notice']['title']=substr(trim((string)($cfg['notice']['title']??'')),0,120);
    $cfg['notice']['message']=substr(trim((string)($cfg['notice']['message']??'')),0,1000);
    $cfg['schema_version']=2;
    return $cfg;
}
function bm_desktop_config_load(): array {
    $path=bm_desktop_config_path();
    $raw=is_file($path)?@file_get_contents($path):'';
    $data=is_string($raw)?json_decode($raw,true):null;
    return bm_desktop_config_normalize(is_array($data)?$data:[]);
}
function bm_desktop_config_save(array $cfg): bool {
    $cfg=bm_desktop_config_normalize($cfg);$cfg['updated_at']=gmdate('c');
    $path=bm_desktop_config_path();$dir=dirname($path);
    if(!is_dir($dir)&&!@mkdir($dir,0750,true)&&!is_dir($dir))return false;
    $tmp=$path.'.tmp.'.bin2hex(random_bytes(4));
    $json=json_encode($cfg,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
    if(!is_string($json)||@file_put_contents($tmp,$json,LOCK_EX)===false)return false;
    @chmod($tmp,0640);return @rename($tmp,$path);
}
function bm_desktop_site_remote_config(): array {
    $file=dirname(__DIR__).'/bankmovie_remote_config.json';
    if(!is_file($file))return [];
    $data=json_decode((string)@file_get_contents($file),true);
    return is_array($data)?$data:[];
}
function bm_desktop_effective_archive_policies(?array $desktop=null, ?array $site=null): array {
    $desktop=$desktop??bm_desktop_config_load();
    $site=$site??bm_desktop_site_remote_config();
    $sitePolicies=(array)($site['app_archive_policy']??[]);
    $legacy=(array)($site['features']['archives']??[]);
    $out=[];
    foreach(['archive1','archive2','archive3','archive4','archive5'] as $id){
        $d=(array)($desktop['archives'][$id]??[]);
        $s=(array)($sitePolicies[$id]??[]);
        if(!empty($d['inherit_site_policy'])){
            $row=array_replace($d,$s);
            $row['inherit_site_policy']=true;
        }else{
            $row=$d;
            $row['inherit_site_policy']=false;
        }
        if(!empty($legacy[$id.'_stream_vip']))$row['stream_access_scope']='vip';
        if(!empty($legacy[$id.'_download_vip']))$row['download_access_scope']='vip';
        if(!empty($legacy[$id.'_hidden'])){$row['hidden']=true;$row['enabled']=false;}
        if(array_key_exists($id.'_enabled',$legacy)&&!$legacy[$id.'_enabled'])$row['enabled']=false;
        $out[$id]=[
            'inherit_site_policy'=>(bool)($row['inherit_site_policy']??false),
            'enabled'=>(bool)($row['enabled']??true),
            'hidden'=>(bool)($row['hidden']??false),
            'access_scope'=>bm_desktop_scope((string)($row['access_scope']??'public')),
            'download_access_scope'=>bm_desktop_scope((string)($row['download_access_scope']??'public'),'public',true),
            'stream_access_scope'=>bm_desktop_scope((string)($row['stream_access_scope']??'public'),'public',true),
        ];
    }
    return $out;
}
