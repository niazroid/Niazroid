<?php
declare(strict_types=1);

require_once __DIR__.'/desktop_config_lib.php';

function bm_desktop_json(array $payload, int $code=200): never {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, max-age=0');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}
function bm_desktop_header(string $name): string {
    $key='HTTP_'.strtoupper(str_replace('-','_',$name));
    return trim((string)($_SERVER[$key]??''));
}
function bm_desktop_viewer(): ?array {
    static $done=false,$viewer=null;if($done)return $viewer;$done=true;
    $token=bm_desktop_header('X-BM-User-Token');
    if($token===''){
        $auth=bm_desktop_header('Authorization');
        if(preg_match('/^Bearer\s+(.+)$/i',$auth,$m))$token=trim((string)$m[1]);
    }
    if($token==='')return null;
    $cfg=dirname(__DIR__).'/config.php';if(is_file($cfg))require_once $cfg;
    if(!isset($pdo)||!($pdo instanceof PDO)||!class_exists('User'))return null;
    try{$u=(new User($pdo))->checkSession($token);if(is_array($u))$viewer=$u;}catch(Throwable $e){}
    return $viewer;
}
function bm_desktop_scope_allows(string $scope, ?array $viewer): bool {
    $scope=strtolower(trim($scope));
    if($scope==='public'||$scope==='')return true;
    if($scope==='disabled')return false;
    if($scope==='member')return is_array($viewer)&&!empty($viewer['id']);
    if($scope==='vip')return is_array($viewer)&&(!empty($viewer['is_vip'])||!empty($viewer['vip_lifetime'])||((int)($viewer['vip_remaining_days']??0)>0));
    if($scope==='admin')return is_array($viewer)&&(!empty($viewer['is_admin'])||(($viewer['role']??'')==='admin'));
    return false;
}
function bm_desktop_arc4_policy(): array {
    $rows=bm_desktop_effective_archive_policies();return (array)($rows['archive4']??[]);
}
function bm_desktop_arc4_person($value): array {
    if(is_array($value))return ['name'=>(string)($value['name']??$value['title']??''),'role'=>(string)($value['role']??''),'image'=>(string)($value['image']??''),'url'=>(string)($value['url']??'')];
    return ['name'=>trim((string)$value),'role'=>'','image'=>'','url'=>''];
}
function bm_desktop_arc4_card(array $m): array {
    $id=(string)($m['detail_id']??$m['slug']??$m['id']??'');
    return [
        'archive'=>4,'id'=>$id,'detail_id'=>$id,'slug'=>(string)($m['slug']??$id),'type'=>(string)($m['type']??'movie'),
        'title'=>(string)($m['title']??''),'title_fa'=>(string)($m['title_fa']??''),'year'=>$m['year']??'',
        'poster'=>(string)($m['poster']??''),'backdrop'=>(string)($m['poster']??''),'rating'=>$m['rating']??null,
        'genres'=>(array)($m['genres']??[]),'description'=>(string)($m['description']??''),
        'has_dubbed'=>!empty($m['has_dubbed']),'has_subtitle'=>!empty($m['has_subtitle']),'has_online'=>!empty($m['has_online']),
        'api_detail'=>'desktop_api.php?action=detail&archive=4&id='.rawurlencode($id).'&type='.rawurlencode((string)($m['type']??''))
    ];
}
function bm_desktop_arc4_link(array $d, array $policy, ?array $viewer): array {
    $streamAllowed=bm_desktop_scope_allows((string)($policy['stream_access_scope']??'public'),$viewer);
    $downloadAllowed=bm_desktop_scope_allows((string)($policy['download_access_scope']??'public'),$viewer);
    $row=$d;$row['archive']=4;
    $row['is_playable']=$streamAllowed&&!empty($row['url']);
    $row['is_download']=$downloadAllowed&&!empty($row['url']);
    if(!$streamAllowed&&!$downloadAllowed)$row['url']='';
    return $row;
}
function bm_desktop_archive4_try_handle(): bool {
    $archive=strtolower(trim((string)($_GET['archive']??$_POST['archive']??'')));
    if(!in_array($archive,['4','archive4','arc4','cinamatic'],true))return false;
    $action=strtolower(trim((string)($_GET['action']??$_POST['action']??'home')));
    if(!in_array($action,['section','search','live_search','detail','play'],true))return false;

    $policy=bm_desktop_arc4_policy();$viewer=bm_desktop_viewer();
    if(empty($policy['enabled'])||!empty($policy['hidden']))bm_desktop_json(['status'=>'disabled','archive'=>4,'items'=>[]],404);
    if(!bm_desktop_scope_allows((string)($policy['access_scope']??'public'),$viewer)){
        bm_desktop_json(['status'=>'vip_required','archive'=>4,'access_scope'=>$policy['access_scope']??'vip','items'=>[]],403);
    }
    $lib=__DIR__.'/api4_lib.php';
    if(!is_file($lib))bm_desktop_json(['status'=>'error','message'=>'آرشیو ۴ موقتاً در دسترس نیست.'],503);
    require_once $lib;

    $page=max(1,(int)($_GET['page']??$_POST['page']??1));
    $limit=max(1,min(60,(int)($_GET['limit']??$_POST['limit']??24)));
    try{
        if($action==='section'){
            $section=trim((string)($_GET['section']??$_POST['section']??'new_movies'));
            if($section==='series')$section='new_series';if($section==='movie'||$section==='movies')$section='new_movies';
            if($section==='anime')$section='updated_anime';if($section==='animation'||$section==='animations')$section='updated_animations';
            $raw=api4_search(api4_section_params($section,$page));
            $items=[];foreach((array)($raw['movies']??[]) as $m){$items[]=bm_desktop_arc4_card((array)$m);if(count($items)>=$limit)break;}
            bm_desktop_json(['status'=>'success','action'=>'section','archive'=>4,'section'=>$section,'page'=>$page,'count'=>count($items),'has_more'=>!empty($raw['has_more']),'next_page'=>$raw['next_page']??null,'items'=>$items,'archive_policy'=>$policy]);
        }
        if($action==='search'||$action==='live_search'){
            $params=['s'=>(string)($_GET['q']??$_GET['s']??$_POST['q']??$_POST['s']??''),'page'=>$page];
            foreach(['type','genre','country','year','sort'] as $k){$v=trim((string)($_GET[$k]??$_POST[$k]??''));if($v!=='')$params[$k]=$v;}
            $raw=api4_search($params);$items=[];foreach((array)($raw['movies']??[]) as $m){$items[]=bm_desktop_arc4_card((array)$m);if(count($items)>=$limit)break;}
            bm_desktop_json(['status'=>'success','action'=>'search','archive'=>4,'query'=>$params['s'],'page'=>$page,'count'=>count($items),'has_more'=>!empty($raw['has_more']),'next_page'=>$raw['next_page']??null,'items'=>$items,'archive_policy'=>$policy]);
        }
        $id=trim((string)($_GET['id']??$_GET['slug']??$_POST['id']??$_POST['slug']??''));
        if($id==='')bm_desktop_json(['status'=>'error','message'=>'شناسه عنوان ارسال نشده است.'],400);
        $d=api4_get_details($id);$links=[];
        foreach((array)($d['downloads']??[]) as $row)$links[]=bm_desktop_arc4_link((array)$row,$policy,$viewer);
        $actors=[];foreach((array)($d['actors']??[]) as $a){$x=bm_desktop_arc4_person($a);if($x['name']!=='')$actors[]=$x;}
        $d['archive']=4;$d['actors']=$actors;$d['downloads']=$links;$d['links']=$links;$d['play']=['links'=>$links,'has_series_structure'=>($d['type']??'')==='series'];
        $d['archive_policy']=$policy;$d['download_access_scope']=$policy['download_access_scope']??'public';$d['stream_access_scope']=$policy['stream_access_scope']??'public';
        if($action==='play')bm_desktop_json(['status'=>'success','action'=>'play','archive'=>4,'id'=>$d['id']??$id,'title'=>$d['title']??'','title_fa'=>$d['title_fa']??'','type'=>$d['type']??'movie','poster'=>$d['poster']??'','play'=>$d['play'],'archive_policy'=>$policy]);
        bm_desktop_json(['status'=>'success','action'=>'detail','archive'=>4,'item'=>$d,'archive_policy'=>$policy]);
    }catch(Throwable $e){
        error_log('BankMovie Desktop Archive4: '.$e->getMessage());
        bm_desktop_json(['status'=>'error','message'=>'آرشیو ۴ موقتاً پاسخ نداد. دوباره تلاش کنید.'],503);
    }
}
