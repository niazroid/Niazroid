<?php
declare(strict_types=1);

/**
 * Server-only helper for Desktop facades.
 * It reuses the existing app credentials already configured in the target API
 * without copying those values into the Windows client or public build files.
 */
function bm_desktop_proxy_read_const(string $file, string $name): string {
    $src = @file_get_contents($file);
    if (!is_string($src) || $src === '') return '';
    $quoted = preg_quote($name, '/');
    if (!preg_match('/\bconst\s+' . $quoted . '\s*=\s*([\'\"])(.*?)\1\s*;/s', $src, $m)) return '';
    return stripcslashes((string)$m[2]);
}

function bm_desktop_proxy_apply_signature(string $targetFile, string $keyConst, string $secretConst): void {
    $key = bm_desktop_proxy_read_const($targetFile, $keyConst);
    $secret = bm_desktop_proxy_read_const($targetFile, $secretConst);
    if ($key === '' || $secret === '') {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'status' => 'error',
            'message' => 'Desktop gateway is not configured.'
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $ts = (string)time();
    $uri = (string)($_SERVER['REQUEST_URI'] ?? '');
    $path = (string)(parse_url($uri, PHP_URL_PATH) ?: '');
    $query = (string)(parse_url($uri, PHP_URL_QUERY) ?: '');
    $pathQuery = $path . ($query !== '' ? ('?' . $query) : '');

    $_SERVER['HTTP_X_BM_APP_KEY'] = $key;
    $_SERVER['HTTP_X_BM_TS'] = $ts;
    $_SERVER['HTTP_X_BM_SIGN'] = hash_hmac('sha256', $ts . '|' . $pathQuery, $secret);
    $_SERVER['HTTP_X_BM_CLIENT'] = 'windows';
}
