<?php
declare(strict_types=1);
$root=$argv[1]??dirname(__DIR__);$file=rtrim($root,'/\\').'/admin.php';
if(!is_file($file)){fwrite(STDERR,"admin.php not found\n");exit(1);} $s=(string)file_get_contents($file);
if(strpos($s,'admin_desktop.php')!==false){echo "Desktop menu already installed.\n";exit(0);}
$needle='<a href="bm_admin.php"><i class="fas fa-mobile-screen-button"></i> کنترل اپ</a>';
if(strpos($s,$needle)===false){fwrite(STDERR,"Menu anchor not found.\n");exit(2);} 
$replacement=$needle."\n    <a href=\"admin_desktop.php\"><i class=\"fas fa-desktop\"></i> کنترل دسکتاپ</a>";
$backup=$file.'.desktop-menu-backup-'.date('Ymd-His');copy($file,$backup);
file_put_contents($file,str_replace($needle,$replacement,$s));
echo "Installed. Backup: $backup\n";
