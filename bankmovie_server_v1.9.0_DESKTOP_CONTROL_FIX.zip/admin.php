<?php
require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/includes/admin_guard.php';
require_once __DIR__ . '/includes/archive_control.php';
require_once __DIR__ . '/includes/bm_analytics.php';
require_once __DIR__ . '/includes/watch_party.php';
require_once __DIR__ . '/includes/vip_features.php';
require_once __DIR__ . '/includes/sticker_packs.php';
require_once __DIR__ . '/includes/vip_sales.php';
require_once __DIR__ . '/includes/public_assets.php';
require_once __DIR__ . '/includes/notification_center.php';
require_once __DIR__ . '/includes/vip_gifts.php';
require_once __DIR__ . '/includes/movie_release_updates.php';
require_once __DIR__ . '/includes/bankmovie_comment_upgrade.php';
require_admin();
require_once __DIR__ . '/includes/admin_panel_bootstrap.php';
require_once __DIR__ . '/includes/download_domain_manager.php';
require_once __DIR__ . '/includes/episode_stats.php';
$adminPanelHealth = admin_panel_bootstrap($pdo);
try { bm_site_comment_upgrade_schema($pdo); } catch (Throwable $e) { error_log('admin comment schema: '.$e->getMessage()); }
$csrf_token = admin_csrf_token();
try { bm_movie_update_schema($pdo); } catch (Throwable $e) { error_log('movie release update schema: '.$e->getMessage()); }
admin_enforce_csrf();
admin_enforce_get_csrf(['delete_movie','delete_story','add_to_admin_pick','remove_from_admin_pick','approve_comment','reject_comment','delete_comment','delete_request']);
bm_watch_party_user_vip_schema($pdo);

// Security v2.2 — primary Anti-Spam controls live directly in admin.php.
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && isset($_POST['admin_security_action'])) {
    $securityAction = trim((string)$_POST['admin_security_action']);
    $securityRedirect = static function(string $message): never {
        header('Location: admin.php?admin_section=securityCenterSection&msg=' . urlencode($message) . '#securityCenterSection');
        exit;
    };
    try {
        if ($securityAction === 'toggle') {
            $cfg = function_exists('bm_security_global_rate_settings') ? bm_security_global_rate_settings() : [];
            $cfg['enabled'] = empty($cfg['enabled']);
            if (!function_exists('bm_security_global_rate_save_settings') || !bm_security_global_rate_save_settings($cfg)) {
                throw new RuntimeException('تغییر وضعیت سیستم امنیتی انجام نشد.');
            }
            $securityRedirect(!empty($cfg['enabled']) ? 'سیستم امنیتی فعال شد.' : 'سیستم امنیتی خاموش شد.');
        }
        if ($securityAction === 'save') {
            $settings = [
                'enabled' => isset($_POST['rate_enabled']),
                'limit' => max(1, min(5000, (int)($_POST['rate_limit'] ?? 20))),
                'search_limit' => max(1, min(5000, (int)($_POST['rate_search_limit'] ?? 40))),
                'error_abuse_enabled' => isset($_POST['rate_error_abuse_enabled']),
                'error_limit' => max(1, min(5000, (int)($_POST['rate_error_limit'] ?? 40))),
                'asset_error_limit' => max(10, min(5000, (int)($_POST['rate_asset_error_limit'] ?? 120))),
                'probe_error_limit' => max(1, min(100, (int)($_POST['rate_probe_error_limit'] ?? 8))),
                'file_protection_enabled' => isset($_POST['file_protection_enabled']),
                'file_block_backups' => isset($_POST['file_block_backups']),
                'file_block_archives' => isset($_POST['file_block_archives']),
                'file_block_secrets' => isset($_POST['file_block_secrets']),
                'file_block_directory_listing' => isset($_POST['file_block_directory_listing']),
                'file_block_upload_exec' => isset($_POST['file_block_upload_exec']),
                'window' => max(10, min(3600, (int)($_POST['rate_window'] ?? 60))),
                'penalty' => max(60, min(86400, (int)($_POST['rate_penalty'] ?? 300))),
                'page_views_only' => true,
                'challenge_enabled' => isset($_POST['rate_challenge_enabled']),
                'challenge_ttl' => max(60, min(900, (int)($_POST['rate_challenge_ttl'] ?? 300))),
                'challenge_min_age_ms' => max(700, min(10000, (int)($_POST['rate_challenge_min_age_ms'] ?? 1200))),
                'captcha_attempts' => max(1, min(10, (int)($_POST['rate_captcha_attempts'] ?? 3))),
                'captcha_pass_ttl' => max(60, min(3600, (int)($_POST['rate_captcha_pass_ttl'] ?? 600))),
                'visitor_limit' => max(1, min(5000, (int)($_POST['rate_limit'] ?? 20))),
                'session_limit' => max(1, min(5000, (int)($_POST['rate_limit'] ?? 20))),
                'user_limit' => max(1, min(5000, (int)($_POST['rate_limit'] ?? 20))),
                'escalation_enabled' => isset($_POST['rate_escalation_enabled']),
                'escalation_duration' => max(300, min(86400, (int)($_POST['rate_escalation_duration'] ?? 3600))),
                'escalation_multiplier' => max(2, min(10, (int)($_POST['rate_escalation_multiplier'] ?? 3))),
                'escalation_max_penalty' => max(60, min(86400, (int)($_POST['rate_escalation_max_penalty'] ?? 3600))),
                'endpoint_global_block' => isset($_POST['rate_endpoint_global_block']),
                'privileged_bypass' => isset($_POST['rate_privileged_bypass']),
                'live_search_bypass' => true,
                'api_background_bypass' => true,
                'app_bypass' => isset($_POST['rate_app_bypass']),
                'log_enabled' => isset($_POST['rate_log_enabled']),
                'whitelist' => preg_split('/[\r\n,;]+/', (string)($_POST['rate_whitelist'] ?? ''), -1, PREG_SPLIT_NO_EMPTY) ?: [],
                'blacklist' => preg_split('/[\r\n,;]+/', (string)($_POST['rate_blacklist'] ?? ''), -1, PREG_SPLIT_NO_EMPTY) ?: [],
            ];
            if (!function_exists('bm_security_global_rate_save_settings') || !bm_security_global_rate_save_settings($settings)) {
                throw new RuntimeException('ذخیره تنظیمات امنیتی انجام نشد.');
            }
            $securityRedirect('تنظیمات Security / Anti-Spam ذخیره شد.');
        }
        if ($securityAction === 'unblock') {
            $ip = trim((string)($_POST['rate_ip'] ?? ''));
            if (!filter_var($ip, FILTER_VALIDATE_IP)) throw new RuntimeException('IP نامعتبر است.');
            if (!function_exists('bm_security_global_rate_unblock') || !bm_security_global_rate_unblock($ip)) throw new RuntimeException('رفع مسدودی انجام نشد.');
            $securityRedirect('مسدودی IP ' . $ip . ' برداشته شد.');
        }
        if ($securityAction === 'manual_block') {
            $ip = trim((string)($_POST['rate_ip'] ?? ''));
            $minutes = max(1, min(1440, (int)($_POST['rate_minutes'] ?? 5)));
            if (!filter_var($ip, FILTER_VALIDATE_IP)) throw new RuntimeException('IP نامعتبر است.');
            if (!function_exists('bm_security_global_rate_block_ip') || !bm_security_global_rate_block_ip($ip, $minutes * 60, 'admin.php security center')) throw new RuntimeException('مسدودسازی انجام نشد.');
            $securityRedirect('IP ' . $ip . ' برای ' . $minutes . ' دقیقه مسدود شد.');
        }
        if ($securityAction === 'reset') {
            $count = function_exists('bm_security_global_rate_reset_states') ? bm_security_global_rate_reset_states() : 0;
            $securityRedirect(number_format((int)$count) . ' رکورد شمارنده/بلاک موقت پاک شد.');
        }
    } catch (Throwable $securityError) {
        $securityRedirect('خطای Security: ' . $securityError->getMessage());
    }
}

// ============================================
// ابزارهای امن برای ماژول‌های حرفه‌ای پنل
// ============================================
if(!function_exists('admin_ident_safe')){
  function admin_ident_safe(string $name): ?string {
    return preg_match('/^[A-Za-z0-9_]+$/', $name) ? '`' . $name . '`' : null;
  }
}
if(!function_exists('admin_table_exists_safe')){
  function admin_table_exists_safe(PDO $pdo, string $table): bool {
    if(!preg_match('/^[A-Za-z0-9_]+$/', $table)) return false;
    try {
      $stmt = $pdo->prepare('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1');
      $stmt->execute([$table]);
      return (bool)$stmt->fetchColumn();
    } catch(Throwable $e){
      error_log('admin_table_exists_safe('.$table.'): '.$e->getMessage());
      return false;
    }
  }
}
if(!function_exists('admin_column_exists_safe')){
  function admin_column_exists_safe(PDO $pdo, string $table, string $column): bool {
    if(!preg_match('/^[A-Za-z0-9_]+$/', $table) || !preg_match('/^[A-Za-z0-9_]+$/', $column)) return false;
    try {
      $stmt = $pdo->prepare('SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1');
      $stmt->execute([$table, $column]);
      return (bool)$stmt->fetchColumn();
    } catch(Throwable $e){
      error_log('admin_column_exists_safe('.$table.'.'.$column.'): '.$e->getMessage());
      return false;
    }
  }
}
if(!function_exists('admin_safe_count')){
  function admin_safe_count(PDO $pdo, string $sql, array $params = []): int {
    try { $stmt = $pdo->prepare($sql); $stmt->execute($params); return (int)$stmt->fetchColumn(); }
    catch(Throwable $e){ return 0; }
  }
}
if(!function_exists('admin_safe_fetch_all')){
  function admin_safe_fetch_all(PDO $pdo, string $sql, array $params = []): array {
    try { $stmt = $pdo->prepare($sql); $stmt->execute($params); return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: []; }
    catch(Throwable $e){ return []; }
  }
}
if(!function_exists('admin_safe_exec')){
  function admin_safe_exec(PDO $pdo, string $sql, array $params = []): bool {
    try { $stmt = $pdo->prepare($sql); return $stmt->execute($params); }
    catch(Throwable $e){ return false; }
  }
}

// BankMovie V148.60.12: normalize request statuses across legacy/current schemas.
if(!function_exists('admin_request_status_key')){
  function admin_request_status_key($raw): string {
    $value = strtolower(trim((string)$raw));
    if(in_array($value, ['approved','answered','accepted','accept','done','completed','complete','success','1'], true)) return 'approved';
    if(in_array($value, ['rejected','declined','denied','reject','failed','2'], true)) return 'rejected';
    return 'pending';
  }
}
if(!function_exists('admin_request_status_db_value')){
  function admin_request_status_db_value(PDO $pdo, string $canonical): string {
    $canonical = admin_request_status_key($canonical);
    $candidates = [
      'pending'  => ['pending','new','reviewing','review','0'],
      'approved' => ['approved','answered','accepted','done','completed','1'],
      'rejected' => ['rejected','declined','denied','2'],
    ];
    try {
      $stmt = $pdo->query("SHOW COLUMNS FROM movie_requests LIKE 'status'");
      $column = $stmt ? $stmt->fetch(PDO::FETCH_ASSOC) : false;
      $type = strtolower((string)($column['Type'] ?? ''));
      if(preg_match('/^(?:tinyint|smallint|mediumint|int|bigint)/', $type)) {
        return $canonical === 'approved' ? '1' : ($canonical === 'rejected' ? '2' : '0');
      }
      if(str_starts_with($type, 'enum(')) {
        preg_match_all("/'((?:[^'\\]|\\.)*)'/", $type, $matches);
        $allowed = array_map(static fn($v) => stripcslashes($v), $matches[1] ?? []);
        foreach($candidates[$canonical] as $candidate) {
          if(in_array($candidate, $allowed, true)) return $candidate;
        }
      }
    } catch(Throwable $e) {
      error_log('Request status schema detect: ' . $e->getMessage());
    }
    return $canonical;
  }
}
if(!function_exists('admin_request_status_label')){
  function admin_request_status_label($raw): string {
    $key = admin_request_status_key($raw);
    return $key === 'approved' ? 'پذیرفته شد' : ($key === 'rejected' ? 'رد شد' : 'در حال بررسی');
  }
}

if(!function_exists('admin_safe_upload_check')){
  function admin_safe_upload_check(array $file, array $exts, array $mimes, int $maxBytes = 5242880): void {
    if(function_exists('bm_security_allowed_upload')){
      list($ok, $msg) = bm_security_allowed_upload($file, $exts, $mimes, $maxBytes);
      if(!$ok) throw new Exception($msg ?: 'فایل مجاز نیست');
      return;
    }
    $ext = strtolower(pathinfo((string)($file['name'] ?? ''), PATHINFO_EXTENSION));
    if(!in_array($ext, $exts, true)) throw new Exception('پسوند فایل مجاز نیست');
  }
}
if(!function_exists('admin_safe_image_upload')){
  function admin_safe_image_upload(array $file, string $targetDir, string $key, int $quality = 82): string {
    admin_safe_upload_check($file, ['jpg','jpeg','png','webp'], ['image/jpeg','image/png','image/webp'], 6*1024*1024);
    $dir = __DIR__ . '/' . trim($targetDir, '/') . '/';
    if(!is_dir($dir) && !mkdir($dir, 0755, true)) throw new Exception('ایجاد پوشه آپلود ناموفق بود');
    $safeKey = preg_replace('/[^A-Za-z0-9_-]/', '', $key);
    if($safeKey === '') $safeKey = bin2hex(random_bytes(8));
    $target = $dir . $safeKey . '.webp';
    if(function_exists('imagecreatefromstring') && function_exists('imagewebp')){
      $img = @imagecreatefromstring((string)file_get_contents($file['tmp_name']));
      if($img){ imagewebp($img, $target, $quality); imagedestroy($img); @chmod($target, 0644); return trim($targetDir,'/') . '/' . $safeKey . '.webp'; }
    }
    $ext = strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION));
    $target = $dir . $safeKey . '.' . $ext;
    if(!move_uploaded_file($file['tmp_name'], $target)) throw new Exception('ذخیره فایل ناموفق بود');
    @chmod($target, 0644);
    return trim($targetDir,'/') . '/' . basename($target);
  }
}
if(!function_exists('admin_init_activity_log')){
  function admin_init_activity_log(PDO $pdo): bool {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS admin_activity_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        admin_name VARCHAR(120) NULL,
        action VARCHAR(120) NOT NULL,
        target_type VARCHAR(80) NULL,
        target_id INT NULL,
        details TEXT NULL,
        ip_address VARCHAR(64) NULL,
        user_agent VARCHAR(255) NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX(created_at), INDEX(action), INDEX(target_type)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
      return true;
    } catch(Throwable $e){ return false; }
  }
}

if(!function_exists('admin_init_enhanced_tables')){
  function admin_init_enhanced_tables(PDO $pdo): bool {
    try {
      $pdo->exec("CREATE TABLE IF NOT EXISTS admin_banners (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(190) NOT NULL,
        position VARCHAR(80) NOT NULL DEFAULT 'home_top',
        image_path VARCHAR(255) NULL,
        mobile_image_path VARCHAR(255) NULL,
        link_url VARCHAR(500) NULL,
        alt_text VARCHAR(255) NULL,
        badge_text VARCHAR(80) NULL,
        cta_text VARCHAR(80) NULL,
        custom_class VARCHAR(120) NULL,
        custom_css MEDIUMTEXT NULL,
        object_fit VARCHAR(20) NOT NULL DEFAULT 'contain',
        show_desktop TINYINT(1) NOT NULL DEFAULT 1,
        show_mobile TINYINT(1) NOT NULL DEFAULT 1,
        open_new_tab TINYINT(1) NOT NULL DEFAULT 1,
        show_badge TINYINT(1) NOT NULL DEFAULT 1,
        show_cta TINYINT(1) NOT NULL DEFAULT 1,
        priority INT NOT NULL DEFAULT 0,
        starts_at DATETIME NULL,
        ends_at DATETIME NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NULL,
        INDEX(position), INDEX(is_active), INDEX(starts_at), INDEX(ends_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

      $pdo->exec("CREATE TABLE IF NOT EXISTS admin_quick_replies (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(120) NOT NULL,
        message TEXT NOT NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NULL,
        INDEX(is_active)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
      $pdo->exec("CREATE TABLE IF NOT EXISTS admin_recycle_bin (
        id INT AUTO_INCREMENT PRIMARY KEY,
        item_type VARCHAR(40) NOT NULL,
        item_id INT NOT NULL,
        title VARCHAR(255) NULL,
        payload LONGTEXT NOT NULL,
        deleted_by VARCHAR(120) NULL,
        restored_at DATETIME NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX(item_type), INDEX(item_id), INDEX(restored_at), INDEX(created_at)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
      return true;
    } catch(Throwable $e){ return false; }
  }
}
if(!function_exists('admin_seed_quick_replies')){
  function admin_seed_quick_replies(PDO $pdo): void {
    try {
      if(!admin_table_exists_safe($pdo, 'admin_quick_replies')) return;
      $count = (int)$pdo->query('SELECT COUNT(*) FROM admin_quick_replies')->fetchColumn();
      if($count > 0) return;
      $rows = [
        ['به‌زودی اضافه می‌شود', 'درخواست شما ثبت شد و در اولویت بررسی قرار گرفت. در صورت آماده شدن نسخه مناسب، به سایت اضافه می‌شود.'],
        ['در سایت موجود است', 'این عنوان در سایت موجود است. لطفاً از بخش جستجوی سایت نام فیلم/سریال را بررسی کنید.'],
        ['نسخه مناسب پیدا نشد', 'فعلاً نسخه قابل قبول برای این عنوان پیدا نشد. در صورت انتشار نسخه بهتر، دوباره بررسی می‌شود.'],
        ['لینک دانلود اضافه شد', 'درخواست شما بررسی شد و لینک دانلود به صفحه مربوطه اضافه شد.'],
        ['اطلاعات ناقص است', 'برای بررسی دقیق‌تر لطفاً نام انگلیسی، سال انتشار یا کد IMDb عنوان موردنظر را ارسال کنید.']
      ];
      $stmt = $pdo->prepare('INSERT INTO admin_quick_replies (title, message, is_active) VALUES (?, ?, 1)');
      foreach($rows as $r){ $stmt->execute($r); }
    } catch(Throwable $e){ }
  }
}
if(!function_exists('admin_insert_row_safe')){
  function admin_insert_row_safe(PDO $pdo, string $table, array $row): bool {
    $ident = admin_ident_safe($table); if(!$ident || !$row) return false;
    $cols = []; $vals = [];
    foreach($row as $k=>$v){ if(admin_column_exists_safe($pdo, $table, (string)$k)){ $cols[] = '`' . str_replace('`','', (string)$k) . '`'; $vals[] = $v; } }
    if(!$cols) return false;
    $ph = implode(',', array_fill(0, count($cols), '?'));
    $sql = "INSERT INTO $ident (" . implode(',', $cols) . ") VALUES ($ph)";
    $stmt = $pdo->prepare($sql);
    return $stmt->execute($vals);
  }
}
if(!function_exists('admin_remote_image_to_webp')){
  function admin_remote_image_to_webp(string $url, string $dir, string $key, int $quality = 82): array {
    $url = trim($url);
    if(!filter_var($url, FILTER_VALIDATE_URL)) return ['success'=>false, 'message'=>'آدرس پوستر معتبر نیست.'];
    $key = preg_replace('/[^A-Za-z0-9_\-]/', '', $key);
    if($key === '') return ['success'=>false, 'message'=>'کلید ذخیره‌سازی کاور معتبر نیست.'];
    if(!function_exists('imagecreatefromstring') || !function_exists('imagewebp')) return ['success'=>false, 'message'=>'افزونه GD/WebP روی سرور فعال نیست.'];
    $raw = '';
    try {
      if(function_exists('curl_init')){
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_FOLLOWLOCATION=>true, CURLOPT_MAXREDIRS=>4, CURLOPT_CONNECTTIMEOUT=>8, CURLOPT_TIMEOUT=>18, CURLOPT_SSL_VERIFYPEER=>true, CURLOPT_USERAGENT=>'BankMovieAdminPosterFetcher/1.0']);
        $raw = curl_exec($ch) ?: '';
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if($code < 200 || $code >= 400) return ['success'=>false, 'message'=>'دانلود پوستر ناموفق بود. HTTP ' . $code];
      } else {
        $raw = @file_get_contents($url) ?: '';
      }
      if(strlen($raw) < 64) return ['success'=>false, 'message'=>'فایل پوستر دریافت نشد.'];
      $img = @imagecreatefromstring($raw);
      if(!$img) return ['success'=>false, 'message'=>'فرمت تصویر پوستر قابل پردازش نیست.'];
      $fullDir = rtrim(__DIR__ . '/' . trim($dir, '/'), '/') . '/';
      if(!is_dir($fullDir)) @mkdir($fullDir, 0755, true);
      $target = $fullDir . $key . '.webp';
      $ok = imagewebp($img, $target, $quality);
      imagedestroy($img);
      if(!$ok || !is_file($target)) return ['success'=>false, 'message'=>'تبدیل پوستر به WebP ناموفق بود.'];
      return ['success'=>true, 'path'=>trim($dir, '/') . '/' . $key . '.webp', 'message'=>'پوستر دانلود و به WebP تبدیل شد.'];
    } catch(Throwable $e){ return ['success'=>false, 'message'=>$e->getMessage()]; }
  }
}
if(!function_exists('admin_cleanup_deleted_movie_assets')){
  function admin_cleanup_deleted_movie_assets(PDO $pdo, array $movie): void {
    try {
      $movieId = (int)($movie['id'] ?? 0);
      $imdbCode = trim((string)($movie['imdb_code'] ?? ''));
      $posterKey = $imdbCode !== '' ? $imdbCode : (string)$movieId;
      $canDeleteSharedAssets = true;
      if($imdbCode !== ''){
        $canDeleteSharedAssets = admin_safe_count($pdo, 'SELECT COUNT(*) FROM movies WHERE imdb_code = ?', [$imdbCode]) < 1;
        if($canDeleteSharedAssets && admin_table_exists_safe($pdo, 'movie_extra_info')){
          $pdo->prepare('DELETE FROM movie_extra_info WHERE imdb_code = ?')->execute([$imdbCode]);
        }
      }
      if($posterKey !== '' && $canDeleteSharedAssets){
        foreach(['webp','jpg','jpeg','png'] as $ext) admin_safe_unlink('posters/' . $posterKey . '.' . $ext, ['posters/']);
      }
    } catch(Throwable $e){
      error_log('[BankMovie admin cleanup] ' . $e->getMessage());
    }
  }
}

if(!function_exists('admin_movie_payload_for_trash')){
  function admin_movie_payload_for_trash(PDO $pdo, int $movieId): array {
    $movie = [];
    try { $st=$pdo->prepare('SELECT * FROM movies WHERE id=?'); $st->execute([$movieId]); $movie=$st->fetch(PDO::FETCH_ASSOC) ?: []; } catch(Throwable $e){}
    if(!$movie) return [];

    $movieTables = ['softsub_links','dubbed_links','comments','admin_picks','watchlist','watch_history','collection_movies','movie_ratings'];
    $payload = ['movie'=>$movie, 'comment_likes'=>[]];
    foreach($movieTables as $tbl){
      $payload[$tbl] = [];
      if(admin_table_exists_safe($pdo, $tbl)){
        $payload[$tbl] = admin_safe_fetch_all($pdo, "SELECT * FROM `$tbl` WHERE movie_id = ?", [$movieId]);
      }
    }

    if(!empty($payload['comments']) && admin_table_exists_safe($pdo, 'comment_likes')){
      $commentIds = array_values(array_unique(array_filter(array_map(static fn($row)=>(int)($row['id'] ?? 0), $payload['comments']))));
      if($commentIds){
        $ph = implode(',', array_fill(0, count($commentIds), '?'));
        $payload['comment_likes'] = admin_safe_fetch_all($pdo, "SELECT * FROM comment_likes WHERE comment_id IN ($ph)", $commentIds);
      }
    }
    return $payload;
  }
}
if(!function_exists('admin_move_movie_to_trash')){
  function admin_move_movie_to_trash(PDO $pdo, int $movieId): array {
    $payload = admin_movie_payload_for_trash($pdo, $movieId);
    if(!$payload) return ['success'=>false, 'message'=>'فیلم پیدا نشد.'];
    $title = (string)($payload['movie']['title_fa'] ?: $payload['movie']['title'] ?: ('Movie #' . $movieId));
    try {
      $pdo->beginTransaction();
      $adminName = $_SESSION['admin_username'] ?? $_SESSION['username'] ?? $_SESSION['admin'] ?? 'admin';
      $stmt = $pdo->prepare('INSERT INTO admin_recycle_bin (item_type, item_id, title, payload, deleted_by) VALUES (?, ?, ?, ?, ?)');
      $stmt->execute(['movie', $movieId, $title, json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), (string)$adminName]);

      if(admin_table_exists_safe($pdo, 'comment_likes') && admin_table_exists_safe($pdo, 'comments')){
        $pdo->prepare('DELETE cl FROM comment_likes cl INNER JOIN comments c ON c.id = cl.comment_id WHERE c.movie_id = ?')->execute([$movieId]);
      }
      foreach(['softsub_links','dubbed_links','comments','watchlist','watch_history','admin_picks','collection_movies','movie_ratings'] as $tbl){
        if(admin_table_exists_safe($pdo, $tbl)) $pdo->prepare("DELETE FROM `$tbl` WHERE movie_id = ?")->execute([$movieId]);
      }
      $pdo->prepare('DELETE FROM movies WHERE id = ?')->execute([$movieId]);
      $pdo->commit();
      return ['success'=>true, 'message'=>'فیلم به سطل بازیافت منتقل شد.'];
    } catch(Throwable $e){
      if($pdo->inTransaction()) $pdo->rollBack();
      return ['success'=>false, 'message'=>$e->getMessage()];
    }
  }
}
if(!function_exists('admin_restore_movie_from_trash')){
  function admin_restore_movie_from_trash(PDO $pdo, int $trashId): array {
    try {
      $stmt = $pdo->prepare("SELECT * FROM admin_recycle_bin WHERE id = ? AND item_type = 'movie' AND restored_at IS NULL");
      $stmt->execute([$trashId]); $trash = $stmt->fetch(PDO::FETCH_ASSOC);
      if(!$trash) return ['success'=>false, 'message'=>'آیتم قابل بازیابی پیدا نشد.'];
      $payload = json_decode((string)$trash['payload'], true);
      if(!is_array($payload) || empty($payload['movie'])) return ['success'=>false, 'message'=>'داده بازیابی خراب است.'];
      $movieId = (int)($payload['movie']['id'] ?? 0);
      if($movieId > 0 && admin_safe_count($pdo, 'SELECT COUNT(*) FROM movies WHERE id = ?', [$movieId]) > 0){
        return ['success'=>false, 'message'=>'شناسه این فیلم دوباره استفاده شده؛ بازیابی خودکار امن نیست.'];
      }

      $pdo->beginTransaction();
      if(!admin_insert_row_safe($pdo, 'movies', $payload['movie'])) throw new RuntimeException('بازگردانی رکورد اصلی فیلم انجام نشد.');
      foreach(['softsub_links','dubbed_links','comments','admin_picks','watchlist','watch_history','collection_movies','movie_ratings'] as $tbl){
        if(!empty($payload[$tbl]) && admin_table_exists_safe($pdo, $tbl)){
          foreach($payload[$tbl] as $row){
            if(!admin_insert_row_safe($pdo, $tbl, $row)) throw new RuntimeException('بازگردانی جدول ' . $tbl . ' کامل نشد.');
          }
        }
      }
      if(!empty($payload['comment_likes']) && admin_table_exists_safe($pdo, 'comment_likes')){
        foreach($payload['comment_likes'] as $row){
          if(!admin_insert_row_safe($pdo, 'comment_likes', $row)) throw new RuntimeException('بازگردانی پسندهای دیدگاه کامل نشد.');
        }
      }
      $pdo->prepare('UPDATE admin_recycle_bin SET restored_at = NOW() WHERE id = ?')->execute([$trashId]);
      $pdo->commit();
      return ['success'=>true, 'message'=>'فیلم و تمام ارتباط‌های ذخیره‌شده از سطل بازیافت برگردانده شد.'];
    } catch(Throwable $e){
      if($pdo->inTransaction()) $pdo->rollBack();
      return ['success'=>false, 'message'=>$e->getMessage()];
    }
  }
}


if(!function_exists('admin_text_cut')){
  function admin_text_cut($text, int $length): string {
    $text = (string)$text;
    if(function_exists('mb_substr')) return mb_substr($text, 0, $length, 'UTF-8');
    return substr($text, 0, $length);
  }
}
if(!function_exists('admin_text_len')){
  function admin_text_len($text): int {
    $text = (string)$text;
    if(function_exists('mb_strlen')) return mb_strlen($text, 'UTF-8');
    return strlen($text);
  }
}

if(!function_exists('admin_split_list_values')){
  function admin_split_list_values($value): array {
    if(is_array($value)){
      $raw = [];
      foreach($value as $v){ $raw = array_merge($raw, admin_split_list_values($v)); }
    } else {
      $raw = preg_split('/[,،|\/]+/u', (string)$value) ?: [];
    }
    $out = [];
    foreach($raw as $item){
      $item = trim((string)$item);
      if($item !== '' && strtoupper($item) !== 'N/A') $out[] = $item;
    }
    return array_values(array_unique($out));
  }
}
if(!function_exists('admin_join_list_values')){
  function admin_join_list_values(...$groups): string {
    $all = [];
    foreach($groups as $group){ $all = array_merge($all, admin_split_list_values($group)); }
    return implode(', ', array_values(array_unique($all)));
  }
}
if(!function_exists('admin_clean_movie_summary')){
  function admin_clean_movie_summary($value, int $max = 2600): string {
    $text = trim((string)$value);
    $text = preg_replace('/<\s*br\s*\/?\s*>/iu', "\n", $text) ?? $text;
    $text = html_entity_decode(strip_tags($text), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = preg_replace('/[ \t]+/u', ' ', $text) ?? $text;
    $text = preg_replace('/\n{3,}/u', "\n\n", $text) ?? $text;
    $text = trim($text);
    if(function_exists('mb_substr')) return mb_substr($text,0,$max,'UTF-8');
    return substr($text,0,$max);
  }
}
if(!function_exists('admin_omdb_value')){
  function admin_omdb_value(array $data, string $key, $fallback = ''){
    $v = $data[$key] ?? $fallback;
    return (is_string($v) && strtoupper(trim($v)) === 'N/A') ? '' : $v;
  }
}
if(!function_exists('admin_fetch_omdb_data')){
  function admin_fetch_omdb_data(string $apiKey, string $query): array {
    $query = trim($query);
    if($apiKey === '') return ['success'=>false, 'message'=>'کلید OMDb تنظیم نشده است.'];
    if($query === '') return ['success'=>false, 'message'=>'عنوان یا کد IMDb خالی است.'];
    $params = ['apikey'=>$apiKey, 'plot'=>'full', 'r'=>'json'];
    if(preg_match('/^tt\d+$/i', $query)) $params['i'] = $query; else $params['t'] = $query;
    $apiUrl = 'https://www.omdbapi.com/?' . http_build_query($params);
    try {
      if(function_exists('curl_init')){
        $ch = curl_init($apiUrl);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>14, CURLOPT_SSL_VERIFYPEER=>true, CURLOPT_USERAGENT=>'BankMovieAdminOMDb/1.1']);
        $raw = curl_exec($ch) ?: '';
        $err = curl_error($ch);
        curl_close($ch);
        if($raw === '' && $err !== '') throw new Exception($err);
      } else {
        $raw = @file_get_contents($apiUrl) ?: '';
      }
      $data = json_decode($raw, true);
      if(!is_array($data) || ($data['Response'] ?? 'False') === 'False') throw new Exception($data['Error'] ?? 'نتیجه‌ای از OMDb پیدا نشد.');
      $yearRaw = (string)admin_omdb_value($data, 'Year');
      $movie = [
        'title' => (string)admin_omdb_value($data, 'Title'),
        'year' => $yearRaw !== '' ? (int)preg_replace('/\D.*/','', $yearRaw) : '',
        'imdb_code' => (string)admin_omdb_value($data, 'imdbID'),
        'imdb_rate' => (string)admin_omdb_value($data, 'imdbRating'),
        'imdb_votes' => admin_omdb_value($data, 'imdbVotes') !== '' ? (int)str_replace(',', '', (string)$data['imdbVotes']) : '',
        'description' => (string)admin_omdb_value($data, 'Plot'),
        'genres' => (string)admin_omdb_value($data, 'Genre'),
        'director' => (string)admin_omdb_value($data, 'Director'),
        'actors' => (string)admin_omdb_value($data, 'Actors'),
        'country' => (string)admin_omdb_value($data, 'Country'),
        'language' => (string)admin_omdb_value($data, 'Language'),
        'rated' => (string)admin_omdb_value($data, 'Rated'),
        'poster' => (string)admin_omdb_value($data, 'Poster'),
        'type' => strtolower((string)admin_omdb_value($data, 'Type')) === 'series' ? 'tvSeries' : 'movie',
        'runtime' => (string)admin_omdb_value($data, 'Runtime'),
        'released' => (string)admin_omdb_value($data, 'Released'),
        'production_companies' => (string)admin_omdb_value($data, 'Production')
      ];
      return ['success'=>true, 'movie'=>$movie, 'raw'=>$data];
    } catch(Throwable $e){ return ['success'=>false, 'message'=>$e->getMessage()]; }
  }

}

if(!function_exists('admin_find_movie_duplicates')){
  function admin_find_movie_duplicates(PDO $pdo, string $title = '', string $titleFa = '', string $imdbCode = '', int $year = 0, int $excludeId = 0): array {
    $title = trim($title);
    $titleFa = trim($titleFa);
    $imdbCode = trim($imdbCode);
    $clauses = [];
    $params = [];
    if($imdbCode !== ''){
      $clauses[] = "(imdb_code IS NOT NULL AND imdb_code <> '' AND LOWER(imdb_code) = LOWER(?))";
      $params[] = $imdbCode;
    }
    if($title !== '' && $year > 0){
      $clauses[] = "((LOWER(title) = LOWER(?) OR LOWER(title_fa) = LOWER(?)) AND year = ?)";
      $params[] = $title;
      $params[] = $title;
      $params[] = $year;
    }
    if($titleFa !== '' && $year > 0){
      $clauses[] = "((LOWER(title) = LOWER(?) OR LOWER(title_fa) = LOWER(?)) AND year = ?)";
      $params[] = $titleFa;
      $params[] = $titleFa;
      $params[] = $year;
    }
    if($title !== '' && $imdbCode === '' && $year <= 0){
      $clauses[] = "(LOWER(title) = LOWER(?) OR LOWER(title_fa) = LOWER(?))";
      $params[] = $title;
      $params[] = $title;
    }
    if(!$clauses) return [];
    $sql = "SELECT id, title, title_fa, year, imdb_code, imdb_rate, type FROM movies WHERE (" . implode(' OR ', $clauses) . ")";
    if($excludeId > 0){ $sql .= " AND id <> ?"; $params[] = $excludeId; }
    $sql .= " ORDER BY CASE WHEN imdb_code <> '' AND LOWER(imdb_code) = LOWER(?) THEN 0 ELSE 1 END, id DESC LIMIT 8";
    $params[] = $imdbCode;
    try {
      $stmt = $pdo->prepare($sql);
      $stmt->execute($params);
      return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch(Throwable $e){ return []; }
  }
}

if(!function_exists('admin_duplicate_match_label')){
  function admin_duplicate_match_label(array $row, string $title, string $titleFa, string $imdbCode, int $year): string {
    $rowImdb = trim((string)($row['imdb_code'] ?? ''));
    if($imdbCode !== '' && strcasecmp($rowImdb, $imdbCode) === 0) return 'کد IMDb یکسان';
    $rowYear = (int)($row['year'] ?? 0);
    $rowTitle = trim((string)($row['title'] ?? ''));
    $rowTitleFa = trim((string)($row['title_fa'] ?? ''));
    if($year > 0 && $rowYear === $year){
      if($title !== '' && (strcasecmp($rowTitle, $title) === 0 || strcasecmp($rowTitleFa, $title) === 0)) return 'عنوان و سال یکسان';
      if($titleFa !== '' && (strcasecmp($rowTitle, $titleFa) === 0 || strcasecmp($rowTitleFa, $titleFa) === 0)) return 'عنوان فارسی و سال یکسان';
    }
    return 'شباهت بالا';
  }
}

if(!function_exists('admin_upsert_movie_extra_info')){
  function admin_upsert_movie_extra_info(PDO $pdo, string $imdbCode, array $data): void {
    $imdbCode = trim($imdbCode);
    if($imdbCode === '' || !admin_table_exists_safe($pdo, 'movie_extra_info')) return;
    $allowed = ['language','production_companies','status','rated','seasons','episodes'];
    $filtered = [];
    foreach($allowed as $column){
      if(array_key_exists($column, $data) && admin_column_exists_safe($pdo, 'movie_extra_info', $column)){
        $filtered[$column] = $data[$column];
      }
    }
    if(!$filtered) return;
    $set = []; $values = [];
    foreach($filtered as $column => $value){ $set[] = '`' . $column . '` = ?'; $values[] = $value; }
    if(admin_column_exists_safe($pdo, 'movie_extra_info', 'updated_at')) $set[] = 'updated_at = NOW()';
    $updateValues = array_merge($values, [$imdbCode]);
    $update = $pdo->prepare('UPDATE movie_extra_info SET ' . implode(', ', $set) . ' WHERE imdb_code = ?');
    $update->execute($updateValues);
    if($update->rowCount() > 0 || admin_safe_count($pdo, 'SELECT COUNT(*) FROM movie_extra_info WHERE imdb_code = ?', [$imdbCode]) > 0) return;

    $columns = ['imdb_code']; $placeholders = ['?']; $insertValues = [$imdbCode];
    foreach($filtered as $column => $value){ $columns[] = '`' . $column . '`'; $placeholders[] = '?'; $insertValues[] = $value; }
    if(admin_column_exists_safe($pdo, 'movie_extra_info', 'updated_at')){ $columns[] = 'updated_at'; $placeholders[] = 'NOW()'; }
    $insert = $pdo->prepare('INSERT INTO movie_extra_info (' . implode(', ', $columns) . ') VALUES (' . implode(', ', $placeholders) . ')');
    $insert->execute($insertValues);
  }
}

if(!function_exists('admin_recalculate_movie_rating')){
  function admin_recalculate_movie_rating(PDO $pdo, int $movieId): void {
    if($movieId <= 0 || !admin_table_exists_safe($pdo, 'comments') || !admin_table_exists_safe($pdo, 'movie_ratings')) return;
    $avgStmt = $pdo->prepare("SELECT COALESCE(AVG(rating),0), COUNT(*) FROM comments WHERE movie_id = ? AND rating > 0 AND status = 'approved' AND parent_id IS NULL");
    $avgStmt->execute([$movieId]);
    [$avgRating, $totalVotes] = $avgStmt->fetch(PDO::FETCH_NUM) ?: [0,0];
    $ratingStmt = $pdo->prepare('UPDATE movie_ratings SET avg_rating = ?, total_votes = ?, updated_at = NOW() WHERE movie_id = ?');
    $ratingStmt->execute([(float)$avgRating, (int)$totalVotes, $movieId]);
    if($ratingStmt->rowCount() < 1 && admin_safe_count($pdo, 'SELECT COUNT(*) FROM movie_ratings WHERE movie_id = ?', [$movieId]) < 1){
      $pdo->prepare('INSERT INTO movie_ratings (movie_id, avg_rating, total_votes, updated_at) VALUES (?, ?, ?, NOW())')->execute([$movieId, (float)$avgRating, (int)$totalVotes]);
    }
  }
}
if(!function_exists('admin_record_activity')){
  function admin_record_activity(PDO $pdo, string $action, string $targetType = 'system', ?int $targetId = null, string $details = ''): void {
    try {
      if(!admin_table_exists_safe($pdo, 'admin_activity_logs')) return;
      $adminName = $_SESSION['admin_username'] ?? $_SESSION['username'] ?? $_SESSION['admin'] ?? 'admin';
      $stmt = $pdo->prepare("INSERT INTO admin_activity_logs (admin_name, action, target_type, target_id, details, ip_address, user_agent) VALUES (?, ?, ?, ?, ?, ?, ?)");
      $stmt->execute([
        (string)$adminName,
        admin_text_cut($action, 120),
        admin_text_cut($targetType, 80),
        $targetId,
        admin_text_cut($details, 2000),
        $_SERVER['REMOTE_ADDR'] ?? '',
        admin_text_cut($_SERVER['HTTP_USER_AGENT'] ?? '', 255)
      ]);
    } catch(Throwable $e){ /* لاگ نباید پنل را متوقف کند */ }
  }
}
if(!function_exists('admin_export_table_safe')){
  function admin_export_table_safe(PDO $pdo, string $table): array {
    if(!admin_table_exists_safe($pdo, $table)) return [];
    $ident = admin_ident_safe($table);
    if(!$ident) return [];
    try {
      $rows = $pdo->query("SELECT * FROM $ident")->fetchAll(PDO::FETCH_ASSOC) ?: [];
      $sensitive = ['password','pass','password_hash','remember_token','reset_token','token','api_key','secret'];
      foreach($rows as &$row){
        foreach(array_keys($row) as $k){
          foreach($sensitive as $bad){ if(stripos($k, $bad) !== false) $row[$k] = '[hidden]'; }
        }
      }
      unset($row);
      return $rows;
    } catch(Throwable $e){ return []; }
  }
}
$activityLogAvailable = admin_init_activity_log($pdo);
$adminEnhancedTablesAvailable = admin_init_enhanced_tables($pdo);
admin_seed_quick_replies($pdo);
$adminOmdbKey = 'f6b342c9'; // OMDb API key provided for this admin panel

// BankMovie V127: site error/slow-request center on the main dashboard.
if(!function_exists('admin_site_log_paths')){
  function admin_site_log_paths(): array {
    return [
      'slow' => __DIR__ . '/_bankmovie_private/slow-requests.log',
      'php' => __DIR__ . '/logs/php-errors.log',
      'admin' => __DIR__ . '/logs/admin-error.log',
    ];
  }
}
if(!function_exists('admin_tail_log_lines')){
  function admin_tail_log_lines(string $path, int $limit = 40): array {
    if(!is_file($path) || !is_readable($path)) return [];
    $lines = @file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if(!is_array($lines)) return [];
    return array_slice($lines, -max(1, $limit));
  }
}
if(!function_exists('admin_site_log_line_epoch')){
  function admin_site_log_line_epoch(string $line): int {
    $line = trim($line);
    if($line === '') return 0;
    $json = json_decode($line, true);
    if(is_array($json)){
      foreach(['time','timestamp','created_at','date'] as $key){
        $value = trim((string)($json[$key] ?? ''));
        if($value !== ''){ $ts = strtotime($value); if($ts !== false) return (int)$ts; }
      }
    }
    if(preg_match('/^\[([^\]]+)\]/', $line, $m)){
      $ts = strtotime(trim($m[1])); if($ts !== false) return (int)$ts;
    }
    if(preg_match('/\b(20\d{2}[-\/]\d{1,2}[-\/]\d{1,2}[ T]\d{1,2}:\d{2}(?::\d{2})?)\b/', $line, $m)){
      $ts = strtotime(str_replace('/', '-', $m[1])); if($ts !== false) return (int)$ts;
    }
    return 0;
  }
}
if(!function_exists('admin_prune_site_log_file')){
  function admin_prune_site_log_file(string $path, int $cutoff): int {
    if(!is_file($path) || !is_readable($path) || !is_writable($path)) return 0;
    $fp = @fopen($path, 'c+'); if(!$fp) return 0;
    $removed = 0;
    try {
      if(!@flock($fp, LOCK_EX)) return 0;
      rewind($fp); $raw = stream_get_contents($fp); if(!is_string($raw) || $raw === '') return 0;
      $lines = preg_split('/\r\n|\n|\r/', $raw) ?: [];
      $keep = []; $dropBlock = false;
      foreach($lines as $line){
        if(trim($line) === '') continue;
        $ts = admin_site_log_line_epoch($line);
        if($ts > 0) $dropBlock = $ts < $cutoff;
        if($dropBlock){ $removed++; continue; }
        $keep[] = $line;
      }
      if($removed > 0){
        rewind($fp); @ftruncate($fp, 0);
        if($keep) fwrite($fp, implode(PHP_EOL, $keep) . PHP_EOL);
        fflush($fp);
      }
    } finally {
      @flock($fp, LOCK_UN); fclose($fp);
    }
    return $removed;
  }
}
if(!function_exists('admin_prune_site_error_logs')){
  function admin_prune_site_error_logs(int $maxAgeSeconds = 86400): int {
    $cutoff = time() - max(3600, $maxAgeSeconds);
    $removed = 0;
    foreach(admin_site_log_paths() as $path) $removed += admin_prune_site_log_file($path, $cutoff);
    return $removed;
  }
}

if(!function_exists('admin_build_site_error_snapshot')){
  function admin_build_site_error_snapshot(): array {
    $paths = admin_site_log_paths();
    $slowLines = admin_tail_log_lines($paths['slow'], 200);
    $phpLines = admin_tail_log_lines($paths['php'], 200);
    $adminLines = admin_tail_log_lines($paths['admin'], 200);
    $recent = [];
    $fatal = 0; $db = 0; $external = 0;
    foreach(array_reverse($slowLines) as $line){
      $row = json_decode($line, true);
      if(!is_array($row)) continue;
      $notes = is_array($row['notes'] ?? null) ? $row['notes'] : [];
      $largest = is_array($row['largest_stage'] ?? null) ? $row['largest_stage'] : [];
      $stage = (string)($largest['name'] ?? 'request');
      $kind = 'کندی صفحه'; $level = 'warn';
      if(!empty($row['fatal'])) { $fatal++; $kind = 'خطای PHP'; $level = 'bad'; }
      elseif(isset($notes['db_connection_error']) || (float)($notes['db_connect_ms'] ?? 0) >= 900) { $db++; $kind = 'هاست / دیتابیس'; $level = 'bad'; }
      elseif(str_contains($stage, 'external-detail')) { $external++; $kind = 'آرشیو خارجی'; $level = 'warn'; }
      $recent[] = [
        'time' => (string)($row['time'] ?? ''),
        'kind' => $kind,
        'level' => $level,
        'summary' => number_format((float)($row['total_ms'] ?? 0), 0) . ' ms · ' . $stage,
        'uri' => (string)($row['uri'] ?? ''),
      ];
      if(count($recent) >= 8) break;
    }
    foreach(array_slice(array_reverse($phpLines), 0, max(0, 8-count($recent))) as $line){
      $recent[] = ['time'=>'', 'kind'=>'PHP log', 'level'=>'bad', 'summary'=>(function_exists('mb_substr') ? mb_substr((string)$line, 0, 180) : substr((string)$line, 0, 180)), 'uri'=>''];
    }
    return [
      'slow_count' => count($slowLines),
      'php_count' => count($phpLines),
      'admin_count' => count($adminLines),
      'fatal_count' => $fatal,
      'db_count' => $db,
      'external_count' => $external,
      'recent' => $recent,
      'total_bytes' => array_sum(array_map(static fn($path) => is_file($path) ? (int)@filesize($path) : 0, $paths)),
    ];
  }
}
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['vip_features_save'])){
  $featureInput = is_array($_POST['vip_features'] ?? null) ? $_POST['vip_features'] : [];
  $saved = bm_vip_feature_save($featureInput);
  if($saved){
    admin_record_activity($pdo, 'save_vip_features', 'vip', null, 'Updated BankMovie VIP capability switches');
    header('Location: admin.php?msg=' . urlencode('تنظیمات قابلیت‌های VIP ذخیره شد') . '#vipSection');
  } else {
    header('Location: admin.php?msg=' . urlencode('ذخیره تنظیمات VIP انجام نشد') . '#vipSection');
  }
  exit;
}

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_site_error_logs'])){
  $cleared = 0;
  foreach(admin_site_log_paths() as $path){
    $dir = dirname($path);
    if(!is_dir($dir)) @mkdir($dir, 0755, true);
    if(@file_put_contents($path, '', LOCK_EX) !== false) $cleared++;
  }
  admin_record_activity($pdo, 'reset_site_error_logs', 'system', null, 'Cleared ' . $cleared . ' diagnostic log files');
  header('Location: admin.php?site_logs_reset=1#siteErrorsDashboard');
  exit;
}

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['download_backup'])){
  $tablesForBackup = ['movies','movie_extra_info','softsub_links','dubbed_links','admin_picks','stories','comments','movie_requests','notifications','users'];
  $payload = [
    'generated_at' => date('c'),
    'site' => 'BankMovie',
    'note' => 'Sensitive fields such as passwords, tokens and secrets are masked automatically.',
    'tables' => []
  ];
  foreach($tablesForBackup as $tbl){ $payload['tables'][$tbl] = admin_export_table_safe($pdo, $tbl); }
  admin_record_activity($pdo, 'download_backup', 'system', null, 'Content/database JSON backup downloaded');
  header('Content-Type: application/json; charset=utf-8');
  header('Content-Disposition: attachment; filename="bankmovie-backup-' . date('Ymd-His') . '.json"');
  echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
  exit;
}


// ============================================
// پردازش ماژول‌های افزوده: بنر، پیام آماده، سطل بازیافت، Quick Edit، پوستر OMDb
// ============================================
// ============================================
// پردازش حرفه‌ای بنرها (رفع خطای مسیر آپلود)
// ============================================
if(!function_exists('admin_upload_banner_image')){
    function admin_upload_banner_image(array $file, string $targetDir = 'uploads/banners/'): array {
        $fullDir = __DIR__ . '/' . trim($targetDir, '/') . '/';
        if(!is_dir($fullDir) && !@mkdir($fullDir, 0755, true) && !is_dir($fullDir)){
            return ['success'=>false,'message'=>'ایجاد پوشه بنرها ناموفق بود.'];
        }
        $error=(int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if($error !== UPLOAD_ERR_OK){
            $errors=[UPLOAD_ERR_INI_SIZE=>'حجم فایل بیشتر از limit سرور است.',UPLOAD_ERR_FORM_SIZE=>'حجم فایل بیشتر از limit فرم است.',UPLOAD_ERR_PARTIAL=>'فایل فقط قسمتی آپلود شد.',UPLOAD_ERR_NO_FILE=>'هیچ فایلی انتخاب نشده.',UPLOAD_ERR_NO_TMP_DIR=>'پوشه موقت آپلود وجود ندارد.',UPLOAD_ERR_CANT_WRITE=>'خطا در نوشتن فایل روی دیسک.',UPLOAD_ERR_EXTENSION=>'آپلود توسط اکستنشن متوقف شد.'];
            return ['success'=>false,'message'=>$errors[$error] ?? 'خطای ناشناخته آپلود'];
        }
        try { admin_safe_upload_check($file, ['jpg','jpeg','png','webp','gif'], ['image/jpeg','image/png','image/webp','image/gif'], 12*1024*1024); }
        catch(Throwable $e){ return ['success'=>false,'message'=>$e->getMessage()]; }
        $checkImage=@getimagesize((string)$file['tmp_name']);
        if($checkImage===false) return ['success'=>false,'message'=>'فایل انتخاب شده یک تصویر معتبر نیست.'];
        $mime=strtolower((string)($checkImage['mime'] ?? ''));
        $extMap=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
        if(!isset($extMap[$mime])) return ['success'=>false,'message'=>'فرمت تصویر پشتیبانی نمی‌شود.'];
        $key='banner_' . date('Ymd_His') . '_' . bin2hex(random_bytes(6));

        // GIF و WebP را مستقیم نگه می‌داریم تا Animation نابود نشود.
        if(in_array($mime,['image/gif','image/webp'],true)){
            $ext=$extMap[$mime];
            $target=$fullDir.$key.'.'.$ext;
            if(!@move_uploaded_file((string)$file['tmp_name'],$target)) return ['success'=>false,'message'=>'ذخیره فایل بنر ناموفق بود.'];
            @chmod($target,0644);
            return ['success'=>true,'path'=>$targetDir.$key.'.'.$ext,'mime'=>$mime,'animated_capable'=>true];
        }

        // JPEG/PNG را در صورت امکان به WebP سبک تبدیل می‌کنیم؛ fallback فایل اصلی است.
        if(function_exists('imagecreatefromstring') && function_exists('imagewebp')){
            $imgData=@file_get_contents((string)$file['tmp_name']);
            $img=$imgData!==false ? @imagecreatefromstring($imgData) : false;
            if($img){
                $target=$fullDir.$key.'.webp';
                if(@imagewebp($img,$target,88)){
                    imagedestroy($img); @chmod($target,0644);
                    return ['success'=>true,'path'=>$targetDir.$key.'.webp','mime'=>'image/webp','animated_capable'=>false];
                }
                imagedestroy($img);
            }
        }
        $ext=$extMap[$mime];
        $target=$fullDir.$key.'.'.$ext;
        if(@move_uploaded_file((string)$file['tmp_name'],$target)){
            @chmod($target,0644);
            return ['success'=>true,'path'=>$targetDir.$key.'.'.$ext,'mime'=>$mime,'animated_capable'=>false];
        }
        return ['success'=>false,'message'=>'ذخیره فایل ناموفق بود.'];
    }
}

if(!function_exists('admin_banner_sanitize_css')){
    function admin_banner_sanitize_css(string $css): string {
        $css=trim($css);
        $css=str_ireplace(['</style','<script','javascript:','@import','expression(','behavior:','-moz-binding'],'',$css);
        // Per-banner CSS is scoped as declarations on that banner card.
        $css=str_replace(['{','}'],'',$css);
        return function_exists('mb_substr') ? mb_substr($css,0,8000,'UTF-8') : substr($css,0,8000);
    }
}


if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_banner_action'])){
  $action = (string)$_POST['admin_banner_action'];
  $newImagePath = null;
  try {
    if($action === 'create' || $action === 'update'){
      $id = max(0, (int)($_POST['banner_id'] ?? 0));
      $title = trim((string)($_POST['banner_title'] ?? '')) ?: 'بنر تبلیغاتی';
      $allowedPositions = ['home_top','home_middle','home_bottom','movie_page','mobile','custom'];
      $position = trim((string)($_POST['banner_position'] ?? 'home_top'));
      if(!in_array($position, $allowedPositions, true)) $position = 'home_top';

      $link = trim((string)($_POST['banner_link'] ?? ''));
      if($link !== ''){
        $link = admin_safe_destination_url($link);
        if($link === '') throw new RuntimeException('لینک بنر معتبر نیست.');
      }
      $altText = trim(strip_tags((string)($_POST['banner_alt_text'] ?? '')));
      $badgeText = trim(strip_tags((string)($_POST['banner_badge_text'] ?? '')));
      $ctaText = trim(strip_tags((string)($_POST['banner_cta_text'] ?? '')));
      $customClass = preg_replace('/[^a-zA-Z0-9 _-]+/', '', trim((string)($_POST['banner_custom_class'] ?? ''))) ?: '';
      $customCss = admin_banner_sanitize_css((string)($_POST['banner_custom_css'] ?? ''));
      $objectFit = strtolower(trim((string)($_POST['banner_object_fit'] ?? 'contain')));
      if(!in_array($objectFit,['contain','cover','fill'],true)) $objectFit='contain';
      $showDesktop = isset($_POST['banner_show_desktop']) ? 1 : 0;
      $showMobile = isset($_POST['banner_show_mobile']) ? 1 : 0;
      if(!$showDesktop && !$showMobile){ $showDesktop=1; $showMobile=1; }
      $openNewTab = isset($_POST['banner_open_new_tab']) ? 1 : 0;
      $showBadge = isset($_POST['banner_show_badge']) ? 1 : 0;
      $showCta = isset($_POST['banner_show_cta']) ? 1 : 0;
      $priority = max(-1000,min(1000,(int)($_POST['banner_priority'] ?? 0)));

      $starts = trim((string)($_POST['banner_starts_at'] ?? '')) ?: null;
      $ends = trim((string)($_POST['banner_ends_at'] ?? '')) ?: null;
      if($starts && strtotime($starts) === false) throw new RuntimeException('زمان شروع معتبر نیست.');
      if($ends && strtotime($ends) === false) throw new RuntimeException('زمان پایان معتبر نیست.');
      if($starts && $ends && strtotime($ends) < strtotime($starts)) throw new RuntimeException('زمان پایان باید بعد از زمان شروع باشد.');
      $active = isset($_POST['banner_active']) ? 1 : 0;

      $oldImagePath = '';
      $oldMobileImagePath = '';
      if($action === 'update'){
        if($id <= 0) throw new RuntimeException('شناسه بنر معتبر نیست.');
        $oldStmt = $pdo->prepare('SELECT image_path,mobile_image_path FROM admin_banners WHERE id=?');
        $oldStmt->execute([$id]);
        $oldRow = $oldStmt->fetch(PDO::FETCH_ASSOC);
        if(!$oldRow) throw new RuntimeException('بنر پیدا نشد.');
        $oldImagePath = (string)($oldRow['image_path'] ?? '');
        $oldMobileImagePath = (string)($oldRow['mobile_image_path'] ?? '');
      }

      $newDesktopImage = null;
      $newMobileImage = null;
      if(isset($_FILES['banner_image']) && (int)($_FILES['banner_image']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE){
        $up=admin_upload_banner_image($_FILES['banner_image'],'uploads/banners/'); if(empty($up['success'])) throw new RuntimeException((string)($up['message'] ?? 'آپلود بنر دسکتاپ ناموفق بود.')); $newDesktopImage=(string)($up['path'] ?? '');
      }
      if(isset($_FILES['banner_mobile_image']) && (int)($_FILES['banner_mobile_image']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE){
        $up=admin_upload_banner_image($_FILES['banner_mobile_image'],'uploads/banners/'); if(empty($up['success'])) throw new RuntimeException((string)($up['message'] ?? 'آپلود بنر موبایل ناموفق بود.')); $newMobileImage=(string)($up['path'] ?? '');
      }
      $imagePath = $newDesktopImage ?: $oldImagePath;
      $mobileImagePath = $newMobileImage ?: $oldMobileImagePath;
      if(isset($_POST['banner_remove_mobile_image']) && !$newMobileImage) $mobileImagePath='';
      if($action === 'create' && $imagePath === '' && $mobileImagePath === '') throw new RuntimeException('برای بنر جدید حداقل یک تصویر انتخاب کنید.');

      $pdo->beginTransaction();
      if($action === 'update'){
        $stmt = $pdo->prepare('UPDATE admin_banners SET title=?,position=?,image_path=?,mobile_image_path=?,link_url=?,alt_text=?,badge_text=?,cta_text=?,custom_class=?,custom_css=?,object_fit=?,show_desktop=?,show_mobile=?,open_new_tab=?,show_badge=?,show_cta=?,priority=?,starts_at=?,ends_at=?,is_active=?,updated_at=NOW() WHERE id=?');
        $stmt->execute([$title,$position,$imagePath,$mobileImagePath,$link,$altText,$badgeText,$ctaText,$customClass,$customCss,$objectFit,$showDesktop,$showMobile,$openNewTab,$showBadge,$showCta,$priority,$starts,$ends,$active,$id]);
        $targetId = $id;
      } else {
        $stmt = $pdo->prepare('INSERT INTO admin_banners (title,position,image_path,mobile_image_path,link_url,alt_text,badge_text,cta_text,custom_class,custom_css,object_fit,show_desktop,show_mobile,open_new_tab,show_badge,show_cta,priority,starts_at,ends_at,is_active,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())');
        $stmt->execute([$title,$position,$imagePath,$mobileImagePath,$link,$altText,$badgeText,$ctaText,$customClass,$customCss,$objectFit,$showDesktop,$showMobile,$openNewTab,$showBadge,$showCta,$priority,$starts,$ends,$active]);
        $targetId = (int)$pdo->lastInsertId();
      }
      $pdo->commit();

      if($newDesktopImage && $oldImagePath && $newDesktopImage !== $oldImagePath) admin_safe_unlink($oldImagePath, ['uploads/banners/']);
      if(($newMobileImage || isset($_POST['banner_remove_mobile_image'])) && $oldMobileImagePath && $mobileImagePath !== $oldMobileImagePath) admin_safe_unlink($oldMobileImagePath, ['uploads/banners/']);
      admin_record_activity($pdo, $action === 'update' ? 'update_banner' : 'create_banner', 'banner', $targetId, $title);
      header('Location: admin.php?msg=' . urlencode($action === 'update' ? 'بنر با موفقیت به‌روزرسانی شد' : 'بنر جدید با موفقیت اضافه شد') . '#bannersSection'); exit;
    }

    if($action === 'delete'){
      $id = max(0, (int)($_POST['banner_id'] ?? 0));
      if($id <= 0) throw new RuntimeException('شناسه بنر معتبر نیست.');
      $stmt = $pdo->prepare('SELECT image_path,mobile_image_path FROM admin_banners WHERE id=?');
      $stmt->execute([$id]);
      $imageRow = $stmt->fetch(PDO::FETCH_ASSOC);
      if(!$imageRow) throw new RuntimeException('بنر پیدا نشد.');
      $imagePath = (string)($imageRow['image_path'] ?? '');
      $mobileImagePath = (string)($imageRow['mobile_image_path'] ?? '');
      $deleteStmt = $pdo->prepare('DELETE FROM admin_banners WHERE id=?');
      $deleteStmt->execute([$id]);
      if($deleteStmt->rowCount() < 1) throw new RuntimeException('حذف بنر انجام نشد.');
      admin_safe_unlink($imagePath, ['uploads/banners/']);
      admin_safe_unlink($mobileImagePath, ['uploads/banners/']);
      admin_record_activity($pdo, 'delete_banner', 'banner', $id, 'بنر حذف شد');
      header('Location: admin.php?msg=' . urlencode('بنر حذف شد') . '#bannersSection'); exit;
    }

    if($action === 'toggle'){
      $id = max(0, (int)($_POST['banner_id'] ?? 0));
      if($id <= 0) throw new RuntimeException('شناسه بنر معتبر نیست.');
      $toggleStmt = $pdo->prepare('UPDATE admin_banners SET is_active = IF(is_active=1,0,1), updated_at=NOW() WHERE id=?');
      $toggleStmt->execute([$id]);
      if($toggleStmt->rowCount() < 1 && admin_safe_count($pdo, 'SELECT COUNT(*) FROM admin_banners WHERE id = ?', [$id]) < 1) throw new RuntimeException('بنر پیدا نشد.');
      admin_record_activity($pdo, 'toggle_banner', 'banner', $id, 'وضعیت بنر تغییر کرد');
      header('Location: admin.php?msg=' . urlencode('وضعیت بنر تغییر کرد') . '#bannersSection'); exit;
    }
    throw new RuntimeException('عملیات بنر شناخته نشد.');
  } catch(Throwable $e){
    if($pdo->inTransaction()) $pdo->rollBack();
    if($newImagePath) admin_safe_unlink($newImagePath, ['uploads/banners/']);
    header('Location: admin.php?msg=' . urlencode('خطا در مدیریت بنر: ' . $e->getMessage()) . '#bannersSection'); exit;
  }
}

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['quick_reply_action'])){
  $action = (string)$_POST['quick_reply_action'];
  try {
    if($action === 'create'){
      $title = trim((string)($_POST['qr_title'] ?? '')); $msg = trim((string)($_POST['qr_message'] ?? ''));
      if($title === '' || $msg === ''){ header('Location: admin.php?msg=' . urlencode('عنوان و متن پیام آماده الزامی است') . '#quickRepliesSection'); exit; }
      $stmt=$pdo->prepare('INSERT INTO admin_quick_replies (title, message, is_active) VALUES (?, ?, 1)');
      if(!$stmt->execute([$title,$msg])){ header('Location: admin.php?msg=' . urlencode('ذخیره پیام آماده انجام نشد') . '#quickRepliesSection'); exit; }
      admin_record_activity($pdo,'create_quick_reply','quick_reply',(int)$pdo->lastInsertId(),$title);
      header('Location: admin.php?msg=' . urlencode('پیام آماده ذخیره شد') . '#quickRepliesSection'); exit;
    }
    if($action === 'delete'){
      $id=(int)($_POST['qr_id'] ?? 0); if($id<=0) throw new RuntimeException('شناسه پیام آماده نامعتبر است.');
      $stmt=$pdo->prepare('DELETE FROM admin_quick_replies WHERE id=?'); $stmt->execute([$id]);
      if($stmt->rowCount()<1) throw new RuntimeException('پیام آماده پیدا نشد.');
      admin_record_activity($pdo,'delete_quick_reply','quick_reply',$id,'Quick reply deleted');
      header('Location: admin.php?msg=' . urlencode('پیام آماده حذف شد') . '#quickRepliesSection'); exit;
    }
    if($action === 'toggle'){
      $id=(int)($_POST['qr_id'] ?? 0); if($id<=0) throw new RuntimeException('شناسه پیام آماده نامعتبر است.');
      $stmt=$pdo->prepare('UPDATE admin_quick_replies SET is_active = 1 - is_active, updated_at=NOW() WHERE id=?'); $stmt->execute([$id]);
      if($stmt->rowCount()<1 && admin_safe_count($pdo, 'SELECT COUNT(*) FROM admin_quick_replies WHERE id = ?', [$id])<1) throw new RuntimeException('پیام آماده پیدا نشد.');
      admin_record_activity($pdo,'toggle_quick_reply','quick_reply',$id,'Quick reply status toggled');
      header('Location: admin.php?msg=' . urlencode('وضعیت پیام آماده تغییر کرد') . '#quickRepliesSection'); exit;
    }
  } catch(Throwable $e){ header('Location: admin.php?msg=' . urlencode('خطا در پیام آماده: ' . $e->getMessage()) . '#quickRepliesSection'); exit; }
}

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['trash_action'])){
  $action = (string)$_POST['trash_action'];
  try {
    if($action === 'move_movie'){
      $movieId = (int)($_POST['movie_id'] ?? 0);
      $res = $movieId ? admin_move_movie_to_trash($pdo, $movieId) : ['success'=>false,'message'=>'شناسه فیلم نامعتبر است.'];
      if($res['success']) admin_record_activity($pdo,'move_movie_to_trash','movie',$movieId,'Movie moved to recycle bin');
      header('Location: admin.php?msg=' . urlencode($res['message']) . '#trashSection'); exit;
    }
    if($action === 'restore_movie'){
      $trashId = (int)($_POST['trash_id'] ?? 0);
      $res = $trashId ? admin_restore_movie_from_trash($pdo, $trashId) : ['success'=>false,'message'=>'شناسه سطل نامعتبر است.'];
      if($res['success']) admin_record_activity($pdo,'restore_movie_from_trash','trash',$trashId,'Movie restored');
      header('Location: admin.php?msg=' . urlencode($res['message']) . '#trashSection'); exit;
    }
    if($action === 'purge'){
      $trashId=(int)($_POST['trash_id'] ?? 0);
      if($trashId<=0) throw new RuntimeException('شناسه سطل نامعتبر است.');
      $trashStmt=$pdo->prepare('SELECT item_type, payload FROM admin_recycle_bin WHERE id=?'); $trashStmt->execute([$trashId]);
      $trashRow=$trashStmt->fetch(PDO::FETCH_ASSOC); if(!$trashRow) throw new RuntimeException('آیتم سطل پیدا نشد.');
      $deleteStmt=$pdo->prepare('DELETE FROM admin_recycle_bin WHERE id=?'); $deleteStmt->execute([$trashId]);
      if(($trashRow['item_type'] ?? '') === 'movie'){
        $payload=json_decode((string)($trashRow['payload'] ?? ''),true);
        if(is_array($payload) && !empty($payload['movie'])) admin_cleanup_deleted_movie_assets($pdo,(array)$payload['movie']);
      }
      admin_record_activity($pdo,'purge_trash','trash',$trashId,'Trash item purged');
      header('Location: admin.php?msg=' . urlencode('آیتم از سطل حذف دائمی شد') . '#trashSection'); exit;
    }
  } catch(Throwable $e){ header('Location: admin.php?msg=' . urlencode('خطا در سطل بازیافت: ' . $e->getMessage()) . '#trashSection'); exit; }
}

if(isset($_POST['ajax_action']) && $_POST['ajax_action'] === 'quick_update_movie'){
  header('Content-Type: application/json; charset=utf-8');
  $id = (int)($_POST['movie_id'] ?? 0);
  if($id <= 0){ echo json_encode(['success'=>false,'message'=>'شناسه فیلم نامعتبر است'], JSON_UNESCAPED_UNICODE); exit; }
  $allowed = ['title','title_fa','type','year','imdb_rate','imdb_votes','imdb_code','description','genres','country','director','actors'];
  $set=[]; $vals=[];
  foreach($allowed as $col){ if(array_key_exists($col, $_POST) && admin_column_exists_safe($pdo, 'movies', $col)){ $set[] = '`'.$col.'` = ?'; $vals[] = trim((string)$_POST[$col]); } }
  $extraAllowed = ['language','production_companies','status','rated','seasons','episodes'];
  $extraData = [];
  foreach($extraAllowed as $col){ if(array_key_exists($col, $_POST)){ $extraData[$col] = trim((string)$_POST[$col]); } }
  if(!$set && !$extraData){ echo json_encode(['success'=>false,'message'=>'فیلدی برای ذخیره وجود ندارد'], JSON_UNESCAPED_UNICODE); exit; }
  try {
    $pdo->beginTransaction();
    if($set){
      if(admin_column_exists_safe($pdo, 'movies', 'updated_at')) $set[] = 'updated_at = NOW()';
      $vals[] = $id;
      $pdo->prepare('UPDATE movies SET ' . implode(', ', $set) . ' WHERE id = ?')->execute($vals);
    }
    if($extraData && admin_table_exists_safe($pdo, 'movie_extra_info')){
      $movieImdbCode = trim((string)($_POST['imdb_code'] ?? ''));
      if($movieImdbCode === ''){
        $st = $pdo->prepare('SELECT imdb_code FROM movies WHERE id = ?');
        $st->execute([$id]);
        $movieImdbCode = trim((string)$st->fetchColumn());
      }
      if($movieImdbCode !== ''){
        foreach(['seasons','episodes'] as $numericColumn){
          if(array_key_exists($numericColumn, $extraData) && $extraData[$numericColumn] !== '') $extraData[$numericColumn] = (int)$extraData[$numericColumn];
        }
        admin_upsert_movie_extra_info($pdo, $movieImdbCode, $extraData);
      }
    }
    $pdo->commit();
    admin_record_activity($pdo,'quick_update_movie','movie',$id,'Movie quick edited');
    echo json_encode(['success'=>true,'message'=>'ویرایش سریع ذخیره شد'], JSON_UNESCAPED_UNICODE); exit;
  } catch(Throwable $e){ if($pdo->inTransaction()) $pdo->rollBack(); echo json_encode(['success'=>false,'message'=>$e->getMessage()], JSON_UNESCAPED_UNICODE); exit; }
}

if(isset($_POST['ajax_action']) && $_POST['ajax_action'] === 'download_omdb_poster'){
  header('Content-Type: application/json; charset=utf-8');
  $url = trim((string)($_POST['poster_url'] ?? ''));
  $key = trim((string)($_POST['imdb_code'] ?? ''));
  $res = admin_remote_image_to_webp($url, 'posters/', $key, 82);
  if(!empty($res['success'])) admin_record_activity($pdo, 'download_omdb_poster', 'movie', null, $key);
  echo json_encode($res, JSON_UNESCAPED_UNICODE); exit;
}


// ============================================
// دیدگاه‌های آرشیوهای خارجی - جدول مشترک اپ/سایت/پنل
// ============================================
if (!function_exists('admin_ensure_archive1_comments')) {
  function admin_ensure_archive1_comments(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_comments (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      movie_id INT UNSIGNED NOT NULL,
      user_id INT UNSIGNED NULL,
      username VARCHAR(100) NOT NULL DEFAULT '',
      comment TEXT NOT NULL,
      rating TINYINT UNSIGNED NOT NULL DEFAULT 0,
      spoiler TINYINT(1) NOT NULL DEFAULT 0,
      parent_id BIGINT UNSIGNED NULL DEFAULT NULL,
      status VARCHAR(20) NOT NULL DEFAULT 'pending',
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_movie_parent_status (movie_id,parent_id,status),
      KEY idx_user_status (user_id,status), KEY idx_parent (parent_id), KEY idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_comment_likes (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      comment_id BIGINT UNSIGNED NOT NULL,
      user_id INT UNSIGNED NOT NULL,
      type VARCHAR(10) NOT NULL DEFAULT 'like',
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uq_comment_user (comment_id,user_id), KEY idx_comment_type (comment_id,type)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_items (
      virtual_movie_id INT UNSIGNED NOT NULL PRIMARY KEY,
      archive_no TINYINT UNSIGNED NOT NULL DEFAULT 1,
      slug VARCHAR(220) NOT NULL DEFAULT '',
      item_link VARCHAR(500) NOT NULL DEFAULT '',
      item_title VARCHAR(300) NOT NULL DEFAULT '',
      item_title_fa VARCHAR(300) NOT NULL DEFAULT '',
      item_year VARCHAR(10) DEFAULT NULL,
      item_poster VARCHAR(500) DEFAULT NULL,
      item_type VARCHAR(20) DEFAULT 'movie',
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_archive_slug (archive_no,slug)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    try {
      $cols = $pdo->query("SHOW COLUMNS FROM archive1_items")->fetchAll(PDO::FETCH_COLUMN);
      if(!in_array('archive_no',$cols ?: [],true)) $pdo->exec("ALTER TABLE archive1_items ADD COLUMN archive_no TINYINT UNSIGNED NOT NULL DEFAULT 1 AFTER virtual_movie_id");
    } catch(Throwable $e){}
  }
}
admin_ensure_archive1_comments($pdo);

// ============================================
// آمار کلی
// ============================================
$totalMovies = (int)$pdo->query("SELECT COUNT(*) FROM movies")->fetchColumn();
$totalFilms = (int)$pdo->query("SELECT COUNT(*) FROM movies WHERE type = 'movie'")->fetchColumn();
$totalSeries = (int)$pdo->query("SELECT COUNT(*) FROM movies WHERE type LIKE '%Series%'")->fetchColumn();
$totalLinks = (int)$pdo->query("SELECT (SELECT COUNT(*) FROM softsub_links) + (SELECT COUNT(*) FROM dubbed_links) as total")->fetchColumn();
$totalComments = admin_safe_count($pdo, "SELECT COUNT(*) FROM comments WHERE status = 'approved'");
$totalPendingComments = admin_safe_count($pdo, "SELECT COUNT(*) FROM comments WHERE status = 'pending'");
if(admin_table_exists_safe($pdo, 'archive1_comments')){
  $totalComments += admin_safe_count($pdo, "SELECT COUNT(*) FROM archive1_comments WHERE status = 'approved'");
  $totalPendingComments += admin_safe_count($pdo, "SELECT COUNT(*) FROM archive1_comments WHERE status = 'pending'");
}
$totalUsers = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalAdminPicks = (int)$pdo->query("SELECT COUNT(*) FROM admin_picks")->fetchColumn();

$bmAnalyticsStats = bm_analytics_summary($pdo);
$bmLiveVisitors = (int)($bmAnalyticsStats['live'] ?? 0);
$bmTodayVisits = (int)($bmAnalyticsStats['today'] ?? 0);
$bmTotalVisits = (int)($bmAnalyticsStats['total'] ?? 0);
$bmPopularVisitedMovies = bm_analytics_popular_movies($pdo, 10, 30);

$stories = $pdo->query("SELECT * FROM stories ORDER BY story_order ASC")->fetchAll();
$totalStories = count($stories);

$allMoviesList = $pdo->query("SELECT id, imdb_code, title, title_fa FROM movies ORDER BY id DESC")->fetchAll();
$missingPosters = [];
foreach($allMoviesList as $m){
  $posterKey = trim((string)($m['imdb_code'] ?? '')) !== '' ? $m['imdb_code'] : $m['id'];
  $posterPath = 'posters/' . $posterKey . '.webp';
  if(!is_file(__DIR__ . '/' . $posterPath)){
    $missingPosters[] = $m;
  }
}
$totalMissingPosters = count($missingPosters);

$allCountries = [
  'Afghanistan','Albania','Algeria','Argentina','Armenia','Australia','Austria',
  'Azerbaijan','Bangladesh','Belarus','Belgium','Brazil','Bulgaria','Canada',
  'Chile','China','Colombia','Croatia','Cuba','Czech Republic','Denmark',
  'Dominican Republic','Ecuador','Egypt','Finland','France','Georgia','Germany',
  'Greece','Hong Kong','Hungary','Iceland','India','Indonesia','Iran','Iraq',
  'Ireland','Israel','Italy','Japan','Jordan','Kazakhstan','Kenya','Kuwait',
  'Latvia','Lebanon','Lithuania','Luxembourg','Malaysia','Mauritius','Mexico',
  'Morocco','Netherlands','New Zealand','Nigeria','North Korea','Norway','Oman',
  'Pakistan','Peru','Philippines','Poland','Portugal','Qatar','Romania','Russia',
  'Saudi Arabia','Serbia','Singapore','Slovakia','Slovenia','South Africa',
  'South Korea','Soviet Union','Spain','Sri Lanka','Sudan','Sweden','Switzerland',
  'Syria','Taiwan','Tajikistan','Thailand','Tunisia','Turkey','Turkmenistan',
  'Ukraine','United Arab Emirates','United Kingdom','United States of America',
  'Uruguay','Uzbekistan','Venezuela','Vietnam','Yemen'
];
sort($allCountries);

$allLanguages = [
  'English','Persian (Farsi)','Spanish','French','German','Italian','Portuguese',
  'Russian','Arabic','Turkish','Dutch','Polish','Ukrainian','Romanian',
  'Czech','Swedish','Greek','Hungarian','Hebrew','Thai','Vietnamese',
  'Korean','Japanese','Chinese (Mandarin)','Hindi','Bengali','Urdu','Malay',
  'Indonesian','Filipino','Swahili','Afrikaans','Serbian','Croatian',
  'Bulgarian','Slovak','Slovenian','Estonian','Latvian','Lithuanian',
  'Georgian','Armenian','Azerbaijani','Kazakh','Uzbek','Turkmen','Tajik',
  'Pashto','Nepali','Sinhala','Burmese','Khmer','Lao','Mongolian'
];
sort($allLanguages);

$genresList = $pdo->query("
  SELECT DISTINCT TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(genres, ',', n), ',', -1)) as genre
  FROM movies
  CROSS JOIN (SELECT 1 n UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5) numbers
  WHERE genres IS NOT NULL AND genres != ''
  HAVING genre != '' AND genre IS NOT NULL
  ORDER BY genre
")->fetchAll(PDO::FETCH_COLUMN);

$ratedList = ['G','PG','PG-13','R','NC-17','TV-Y','TV-Y7','TV-G','TV-PG','TV-14','TV-MA'];
$statusList = ['Returning Series','Ended','Canceled','In Production','Planned'];

// ============================================
// پردازش درخواست‌ها
// ============================================
$message = '';
$messageType = '';

// ============================================
// اکشن‌های گروهی، بررسی لینک، ایمپورت متادیتا، مدیریت کاربر
// ============================================
if(isset($_POST['ajax_action']) && $_POST['ajax_action'] === 'check_duplicate_movie'){
  header('Content-Type: application/json; charset=utf-8');
  $title = trim((string)($_POST['title'] ?? ''));
  $titleFa = trim((string)($_POST['title_fa'] ?? ''));
  $imdbCode = trim((string)($_POST['imdb_code'] ?? ''));
  $year = (int)($_POST['year'] ?? 0);
  $excludeId = (int)($_POST['exclude_id'] ?? 0);
  $dups = admin_find_movie_duplicates($pdo, $title, $titleFa, $imdbCode, $year, $excludeId);
  $items = [];
  foreach($dups as $row){
    $items[] = [
      'id' => (int)($row['id'] ?? 0),
      'title' => (string)($row['title'] ?? ''),
      'title_fa' => (string)($row['title_fa'] ?? ''),
      'year' => (string)($row['year'] ?? ''),
      'imdb_code' => (string)($row['imdb_code'] ?? ''),
      'type' => (string)($row['type'] ?? ''),
      'imdb_rate' => (string)($row['imdb_rate'] ?? ''),
      'reason' => admin_duplicate_match_label($row, $title, $titleFa, $imdbCode, $year)
    ];
  }
  echo json_encode(['success'=>true, 'duplicates'=>$items, 'count'=>count($items)], JSON_UNESCAPED_UNICODE); exit;
}


if(isset($_POST['ajax_action']) && $_POST['ajax_action'] === 'admin_movies_list'){
  header('Content-Type: application/json; charset=utf-8');

  $page = max(1, (int)($_POST['page'] ?? 1));
  $perPage = max(10, min(50, (int)($_POST['per_page'] ?? 20)));
  $offset = ($page - 1) * $perPage;
  $q = trim((string)($_POST['q'] ?? ''));

  $where = '1=1';
  $params = [];
  if($q !== ''){
    $where = "(m.title LIKE ? OR m.title_fa LIKE ? OR m.imdb_code LIKE ?)";
    $like = '%' . $q . '%';
    $params = [$like, $like, $like];
  }

  try {
    $countStmt = $pdo->prepare("SELECT COUNT(*) FROM movies m WHERE {$where}");
    $countStmt->execute($params);
    $total = (int)$countStmt->fetchColumn();

    $hasExtra = admin_table_exists_safe($pdo, 'movie_extra_info');
    $extraJoin = $hasExtra ? " LEFT JOIN movie_extra_info mei ON mei.imdb_code = m.imdb_code " : "";
    $extraFields = $hasExtra ? ", mei.language, mei.production_companies, mei.status, mei.rated, mei.seasons, mei.episodes" : "";

    $sql = "SELECT m.id, m.title, m.title_fa, m.imdb_code, m.type, m.year, m.imdb_rate, m.imdb_votes, m.description, m.country, m.genres, m.director, m.actors {$extraFields}
            FROM movies m {$extraJoin}
            WHERE {$where}
            ORDER BY m.id DESC
            LIMIT ? OFFSET ?";
    $stmt = $pdo->prepare($sql);
    $i = 1;
    foreach($params as $param){ $stmt->bindValue($i++, $param, PDO::PARAM_STR); }
    $stmt->bindValue($i++, $perPage, PDO::PARAM_INT);
    $stmt->bindValue($i++, $offset, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

    foreach($rows as &$row){
      $pk = trim((string)($row['imdb_code'] ?? '')) !== '' ? $row['imdb_code'] : $row['id'];
      $row['poster'] = 'posters/' . $pk . '.webp';
      $row['has_poster'] = is_file(__DIR__ . '/posters/' . $pk . '.webp');
    }
    unset($row);

    echo json_encode([
      'success' => true,
      'movies' => $rows,
      'page' => $page,
      'per_page' => $perPage,
      'total' => $total,
      'pages' => max(1, (int)ceil($total / max(1, $perPage)))
    ], JSON_UNESCAPED_UNICODE);
    exit;
  } catch(Throwable $e) {
    echo json_encode(['success'=>false, 'message'=>'خطا در دریافت لیست فیلم‌ها: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    exit;
  }
}

if(isset($_POST['ajax_action']) && $_POST['ajax_action'] === 'admin_pick_search'){
  header('Content-Type: application/json; charset=utf-8');
  $q = trim((string)($_POST['q'] ?? ''));
  if(admin_text_len($q) < 2){
    echo json_encode(['success'=>true, 'items'=>[]], JSON_UNESCAPED_UNICODE);
    exit;
  }

  try {
    $like = '%' . $q . '%';
    $stmt = $pdo->prepare("SELECT id, title, title_fa, imdb_code, year, type
                           FROM movies
                           WHERE title LIKE ? OR title_fa LIKE ? OR imdb_code LIKE ?
                           ORDER BY id DESC
                           LIMIT 10");
    $stmt->execute([$like, $like, $like]);
    echo json_encode(['success'=>true, 'items'=>$stmt->fetchAll(PDO::FETCH_ASSOC) ?: []], JSON_UNESCAPED_UNICODE);
    exit;
  } catch(Throwable $e) {
    echo json_encode(['success'=>false, 'message'=>'خطا در جستجو: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    exit;
  }
}


if(isset($_POST['ajax_action']) && $_POST['ajax_action'] === 'check_link'){
  header('Content-Type: application/json; charset=utf-8');
  $url = trim((string)($_POST['url'] ?? ''));
  if(!filter_var($url, FILTER_VALIDATE_URL)){
    echo json_encode(['success'=>false, 'message'=>'لینک معتبر نیست'], JSON_UNESCAPED_UNICODE); exit;
  }
  $start = microtime(true); $code = 0; $error = ''; $finalUrl = $url;
  try {
    if(function_exists('curl_init')){
      $ch = curl_init($url);
      curl_setopt_array($ch, [
        CURLOPT_NOBODY => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 4,
        CURLOPT_CONNECTTIMEOUT => 7,
        CURLOPT_TIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_USERAGENT => 'BankMovieAdminLinkChecker/1.0'
      ]);
      curl_exec($ch);
      $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
      $finalUrl = (string)(curl_getinfo($ch, CURLINFO_EFFECTIVE_URL) ?: $url);
      $error = curl_error($ch);
      curl_close($ch);
      if(in_array($code, [0, 403, 405], true)){
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_FOLLOWLOCATION=>true, CURLOPT_MAXREDIRS=>4, CURLOPT_CONNECTTIMEOUT=>7, CURLOPT_TIMEOUT=>10, CURLOPT_SSL_VERIFYPEER=>true, CURLOPT_USERAGENT=>'BankMovieAdminLinkChecker/1.0']);
        curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $finalUrl = (string)(curl_getinfo($ch, CURLINFO_EFFECTIVE_URL) ?: $url); $error = curl_error($ch); curl_close($ch);
      }
    } else {
      $headers = @get_headers($url, 1);
      if(is_array($headers) && isset($headers[0]) && preg_match('/\s(\d{3})\s/', $headers[0], $m)) $code = (int)$m[1];
      else $error = 'get_headers failed';
    }
  } catch(Throwable $e){ $error = $e->getMessage(); }
  $ms = (int)round((microtime(true) - $start) * 1000);
  $ok = ($code >= 200 && $code < 400);
  echo json_encode(['success'=>true, 'ok'=>$ok, 'status'=>$code, 'time_ms'=>$ms, 'final_url'=>$finalUrl, 'message'=>$ok?'لینک سالم است':($code ? 'نیاز به بررسی' : ($error ?: 'پاسخی دریافت نشد'))], JSON_UNESCAPED_UNICODE);
  exit;
}

if(isset($_POST['ajax_action']) && $_POST['ajax_action'] === 'fetch_omdb'){
  header('Content-Type: application/json; charset=utf-8');
  $res = admin_fetch_omdb_data($adminOmdbKey, trim((string)($_POST['query'] ?? '')));
  echo json_encode($res, JSON_UNESCAPED_UNICODE); exit;
}

if(isset($_POST['ajax_action']) && $_POST['ajax_action'] === 'omdb_complete_movie'){
  header('Content-Type: application/json; charset=utf-8');
  $movieId = (int)($_POST['movie_id'] ?? 0);
  $overwrite = !empty($_POST['overwrite']);
  if($movieId <= 0){ echo json_encode(['success'=>false,'message'=>'شناسه فیلم نامعتبر است.'], JSON_UNESCAPED_UNICODE); exit; }
  try {
    $stmt = $pdo->prepare('SELECT * FROM movies WHERE id = ? LIMIT 1');
    $stmt->execute([$movieId]);
    $movieRow = $stmt->fetch(PDO::FETCH_ASSOC);
    if(!$movieRow){ echo json_encode(['success'=>false,'message'=>'فیلم پیدا نشد.'], JSON_UNESCAPED_UNICODE); exit; }
    $query = trim((string)($movieRow['imdb_code'] ?? '')) ?: trim((string)($movieRow['title'] ?? ''));
    if($query === ''){ echo json_encode(['success'=>false,'message'=>'برای این فیلم نه IMDb وجود دارد نه عنوان انگلیسی.'], JSON_UNESCAPED_UNICODE); exit; }
    $omdb = admin_fetch_omdb_data($adminOmdbKey, $query);
    if(empty($omdb['success'])){ echo json_encode($omdb, JSON_UNESCAPED_UNICODE); exit; }
    $m = $omdb['movie'];
    $map = [
      'title'=>'title', 'type'=>'type', 'year'=>'year', 'imdb_rate'=>'imdb_rate', 'imdb_votes'=>'imdb_votes',
      'imdb_code'=>'imdb_code', 'description'=>'description', 'genres'=>'genres', 'country'=>'country',
      'director'=>'director', 'actors'=>'actors'
    ];
    $set=[]; $vals=[]; $updated=[];
    foreach($map as $col=>$key){
      if(!admin_column_exists_safe($pdo, 'movies', $col)) continue;
      $newVal = $m[$key] ?? '';
      if($newVal === '' || $newVal === null) continue;
      $oldVal = trim((string)($movieRow[$col] ?? ''));
      if($overwrite || $oldVal === '' || in_array($col, ['imdb_rate','imdb_votes'], true)){
        $set[] = '`' . $col . '` = ?'; $vals[] = $newVal; $updated[] = $col;
      }
    }
    if($set){
      if(admin_column_exists_safe($pdo, 'movies', 'updated_at')) $set[] = 'updated_at = NOW()';
      $vals[] = $movieId;
      $pdo->prepare('UPDATE movies SET ' . implode(', ', $set) . ' WHERE id = ?')->execute($vals);
    }
    $extraUpdated = [];
    $imdbCode = trim((string)($m['imdb_code'] ?: ($movieRow['imdb_code'] ?? '')));
    if($imdbCode !== '' && admin_table_exists_safe($pdo, 'movie_extra_info')){
      $language = (string)($m['language'] ?? '');
      $production = (string)($m['production_companies'] ?? '');
      $rated = (string)($m['rated'] ?? '');
      $cols = ['imdb_code']; $placeholders = ['?']; $insertVals = [$imdbCode]; $updates = [];
      foreach(['language'=>$language, 'production_companies'=>$production, 'rated'=>$rated] as $col=>$val){
        if($val !== '' && admin_column_exists_safe($pdo, 'movie_extra_info', $col)){
          $cols[] = '`'.$col.'`'; $placeholders[] = '?'; $insertVals[] = $val; $updates[] = '`'.$col.'` = VALUES(`'.$col.'`)'; $extraUpdated[] = $col;
        }
      }
      if(count($cols) > 1){
        $extraPayload = [];
        foreach(['language'=>$language, 'production_companies'=>$production, 'rated'=>$rated] as $column => $value){
          if($value !== '') $extraPayload[$column] = $value;
        }
        admin_upsert_movie_extra_info($pdo, $imdbCode, $extraPayload);
      }
    }
    $poster = ['success'=>false, 'message'=>'پوستر معتبر نبود یا IMDb خالی بود.'];
    if(!empty($m['poster']) && $m['poster'] !== 'N/A' && $imdbCode !== ''){
      $posterPath = __DIR__ . '/posters/' . $imdbCode . '.webp';
      if($overwrite || !is_file($posterPath)) $poster = admin_remote_image_to_webp((string)$m['poster'], 'posters/', $imdbCode, 82);
      else $poster = ['success'=>true, 'message'=>'پوستر از قبل وجود داشت.', 'path'=>'posters/' . $imdbCode . '.webp'];
    }
    admin_record_activity($pdo, 'omdb_complete_movie', 'movie', $movieId, implode(',', array_merge($updated, $extraUpdated)));
    echo json_encode(['success'=>true, 'message'=>'اطلاعات OMDb تکمیل شد.', 'movie'=>$m, 'updated_fields'=>$updated, 'extra_fields'=>$extraUpdated, 'poster'=>$poster], JSON_UNESCAPED_UNICODE); exit;
  } catch(Throwable $e){ echo json_encode(['success'=>false,'message'=>$e->getMessage()], JSON_UNESCAPED_UNICODE); exit; }
}


if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_action'])){
  $bulkAction = trim((string)($_POST['bulk_action'] ?? ''));
  $ids = array_values(array_unique(array_filter(array_map('intval', $_POST['movie_ids'] ?? []))));
  if(!$ids){ header('Location: admin.php?msg=' . urlencode('هیچ فیلمی انتخاب نشده بود') . '#moviesSection'); exit; }
  $allowedBulk = ['add_picks','remove_picks','delete_movies','move_to_trash'];
  if(!in_array($bulkAction, $allowedBulk, true)){ header('Location: admin.php?msg=' . urlencode('اکشن گروهی نامعتبر است') . '#moviesSection'); exit; }
  try {
    $ph = implode(',', array_fill(0, count($ids), '?'));
    if($bulkAction === 'add_picks'){
      $pdo->beginTransaction();
      $check = $pdo->prepare('SELECT id FROM admin_picks WHERE movie_id = ?');
      $newPickMovieIds = [];
      foreach($ids as $movieId){ $check->execute([$movieId]); if(!$check->fetchColumn()) $newPickMovieIds[] = $movieId; }
      $added = count($newPickMovieIds);
      if($added > 0){
        $pdo->exec('UPDATE admin_picks SET pick_order = pick_order + ' . $added);
        $insert = $pdo->prepare('INSERT INTO admin_picks (movie_id, pick_order) VALUES (?, ?)');
        foreach($newPickMovieIds as $order => $movieId) $insert->execute([$movieId, $order]);
      }
      $pickRows = $pdo->query('SELECT id FROM admin_picks ORDER BY pick_order ASC, id ASC')->fetchAll(PDO::FETCH_COLUMN) ?: [];
      $pickUpdate = $pdo->prepare('UPDATE admin_picks SET pick_order = ? WHERE id = ?');
      foreach($pickRows as $order => $pickId) $pickUpdate->execute([$order, (int)$pickId]);
      $pdo->commit();
      admin_record_activity($pdo, 'bulk_add_admin_picks', 'movie', null, $added . ' movies added to admin picks');
      header('Location: admin.php?msg=' . urlencode($added . ' مورد به انتخاب ادمین اضافه شد') . '#moviesSection'); exit;
    }
    if($bulkAction === 'remove_picks'){
      $pdo->beginTransaction();
      $pdo->prepare("DELETE FROM admin_picks WHERE movie_id IN ($ph)")->execute($ids);
      $pickRows = $pdo->query('SELECT id FROM admin_picks ORDER BY pick_order ASC, id ASC')->fetchAll(PDO::FETCH_COLUMN) ?: [];
      $pickUpdate = $pdo->prepare('UPDATE admin_picks SET pick_order = ? WHERE id = ?');
      foreach($pickRows as $order => $pickId) $pickUpdate->execute([$order, (int)$pickId]);
      $pdo->commit();
      admin_record_activity($pdo, 'bulk_remove_admin_picks', 'movie', null, count($ids) . ' movies removed from admin picks');
      header('Location: admin.php?msg=' . urlencode('از انتخاب‌های ادمین حذف شدند') . '#moviesSection'); exit;
    }
    if($bulkAction === 'move_to_trash'){
      $ok = 0; $fail = 0;
      foreach($ids as $movieId){ $res = admin_move_movie_to_trash($pdo, (int)$movieId); if($res['success']) $ok++; else $fail++; }
      admin_record_activity($pdo, 'bulk_move_movies_to_trash', 'movie', null, $ok . ' movies moved to trash');
      header('Location: admin.php?msg=' . urlencode($ok . ' مورد به سطل بازیافت منتقل شد' . ($fail ? '، ' . $fail . ' ناموفق' : '')) . '#trashSection'); exit;
    }
    if($bulkAction === 'delete_movies'){
      $movieRowsStmt = $pdo->prepare("SELECT id, imdb_code FROM movies WHERE id IN ($ph)");
      $movieRowsStmt->execute($ids);
      $deletedMovieRows = $movieRowsStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
      $pdo->beginTransaction();
      if(admin_table_exists_safe($pdo, 'comment_likes') && admin_table_exists_safe($pdo, 'comments')){
        $pdo->prepare("DELETE cl FROM comment_likes cl INNER JOIN comments c ON c.id = cl.comment_id WHERE c.movie_id IN ($ph)")->execute($ids);
      }
      foreach(['softsub_links','dubbed_links','comments','watchlist','watch_history','admin_picks','collection_movies','movie_ratings'] as $tbl){
        if(admin_table_exists_safe($pdo, $tbl)) $pdo->prepare("DELETE FROM `$tbl` WHERE movie_id IN ($ph)")->execute($ids);
      }
      $pdo->prepare("DELETE FROM movies WHERE id IN ($ph)")->execute($ids);
      $pdo->commit();
      foreach($deletedMovieRows as $deletedMovieRow) admin_cleanup_deleted_movie_assets($pdo, $deletedMovieRow);
      admin_record_activity($pdo, 'bulk_delete_movies', 'movie', null, count($deletedMovieRows) . ' movies deleted');
      header('Location: admin.php?msg=' . urlencode(count($ids) . ' فیلم حذف شد') . '#moviesSection'); exit;
    }
  } catch(Throwable $e){ if($pdo->inTransaction()) $pdo->rollBack(); header('Location: admin.php?msg=' . urlencode('خطا در اکشن گروهی: ' . $e->getMessage()) . '#moviesSection'); exit; }
}

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['vip_bulk_gift'])){
  try {
    $giftDays = max(1, min(365, (int)($_POST['vip_gift_days'] ?? 1)));
    $giftNote = trim((string)($_POST['vip_gift_note'] ?? ''));
    $adminActor = admin_current_user() ?: [];
    $adminActorId = (int)($adminActor['id'] ?? 0);
    $giftResult = bm_vip_gift_all_users($pdo, $giftDays, $adminActorId > 0 ? $adminActorId : null, $giftNote);
    $giftTitle = 'هدیه VIP همگانی 🎁';
    $giftMessage = $giftDays . ' روز اشتراک VIP به حساب کاربران واجد شرایط اضافه شد.';
    if ($giftNote !== '') $giftMessage .= ' ' . mb_substr($giftNote, 0, 220, 'UTF-8');
    $giftMessage .= ' حساب‌های VIP دائمی بدون تغییر دائمی باقی می‌مانند.';
    try { if(function_exists('bm_notification_center_publish_public')) bm_notification_center_publish_public($pdo, $giftTitle, $giftMessage, ['url'=>'/vip','kind'=>'vip_gift','days'=>$giftDays]); } catch(Throwable $notifyError) { error_log('VIP bulk gift notify: '.$notifyError->getMessage()); }
    admin_record_activity($pdo, 'vip_bulk_gift', 'users', null, $giftDays . ' days | affected=' . (int)($giftResult['affected_count'] ?? 0));
    $msg = $giftDays . ' روز VIP به ' . number_format((int)($giftResult['affected_count'] ?? 0)) . ' کاربر اضافه شد';
    if((int)($giftResult['skipped_permanent'] ?? 0) > 0) $msg .= '؛ ' . number_format((int)$giftResult['skipped_permanent']) . ' VIP دائمی بدون تغییر ماند';
    header('Location: admin.php?msg=' . urlencode($msg) . '#vipSection'); exit;
  } catch(Throwable $e){
    header('Location: admin.php?msg=' . urlencode('خطا در هدیه همگانی VIP: ' . $e->getMessage()) . '#vipSection'); exit;
  }
}

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_action']) && isset($_POST['user_id'])){
  $userId = (int)$_POST['user_id'];
  $userAction = trim((string)$_POST['user_action']);
  $statusCol = admin_column_exists_safe($pdo, 'users', 'status') ? 'status' : (admin_column_exists_safe($pdo, 'users', 'is_banned') ? 'is_banned' : '');
  try {
    if($userId > 0 && $userAction === 'set_admin_badge_color'){
      if(!bm_admin_role_is_owner(admin_current_user())) throw new RuntimeException('فقط مدیر اصلی می‌تواند رنگ تیک مدیران را تغییر دهد');
      if(!admin_column_exists_safe($pdo, 'users', 'admin_badge_color')){
        try { $pdo->exec("ALTER TABLE users ADD COLUMN admin_badge_color VARCHAR(7) NULL DEFAULT NULL"); } catch(Throwable $ignore) {}
      }
      if(!admin_column_exists_safe($pdo, 'users', 'admin_badge_color')) throw new RuntimeException('ستون رنگ تیک مدیر قابل ایجاد نیست');
      $stmt = $pdo->prepare('SELECT role FROM users WHERE id=? LIMIT 1'); $stmt->execute([$userId]);
      $targetRole = strtolower(trim((string)$stmt->fetchColumn()));
      if(!in_array($targetRole, ['admin','administrator'], true)) throw new RuntimeException('رنگ تیک فقط برای حساب مدیر قابل تنظیم است');
      $badgeColor = trim((string)($_POST['admin_badge_color'] ?? ''));
      if($badgeColor === '' || strtolower($badgeColor) === 'default') $badgeColor = null;
      elseif(!preg_match('/^#[0-9a-fA-F]{6}$/', $badgeColor)) throw new RuntimeException('رنگ تیک معتبر نیست');
      $pdo->prepare('UPDATE users SET admin_badge_color=? WHERE id=?')->execute([$badgeColor,$userId]);
      admin_record_activity($pdo, 'set_admin_badge_color', 'user', $userId, $badgeColor ?: 'default');
      header('Location: admin.php?msg=' . urlencode($badgeColor ? 'رنگ تیک مدیر ذخیره شد' : 'رنگ تیک مدیر به حالت پیش‌فرض برگشت') . '#usersSection'); exit;
    }
    if($userId > 0 && $userAction === 'reset_password'){
      if(!admin_column_exists_safe($pdo, 'users', 'password')) throw new RuntimeException('ستون password در جدول users پیدا نشد');
      $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
      $stmt->execute([$userId]);
      $resetUser = $stmt->fetch(PDO::FETCH_ASSOC);
      if(!$resetUser) throw new RuntimeException('کاربر پیدا نشد');
      $resetRole = strtolower(trim((string)($resetUser['role'] ?? 'user')));
      if(in_array($resetRole, ['admin','administrator'], true)) throw new RuntimeException('برای امنیت، بازیابی رمز حساب مدیر از این بخش غیرفعال است');

      $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
      $randomPart = '';
      $alphabetMax = strlen($alphabet) - 1;
      for($i = 0; $i < 14; $i++) $randomPart .= $alphabet[random_int(0, $alphabetMax)];
      $newPassword = 'BM-' . $randomPart;
      $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
      if(!is_string($newHash) || $newHash === '') throw new RuntimeException('ساخت هش امن رمز ناموفق بود');

      $pdo->prepare('UPDATE users SET password = ? WHERE id = ?')->execute([$newHash, $userId]);
      if(admin_column_exists_safe($pdo, 'users', 'remember_token')){
        try { $pdo->prepare('UPDATE users SET remember_token = NULL WHERE id = ?')->execute([$userId]); } catch(Throwable $ignore) {}
      }
      if(admin_column_exists_safe($pdo, 'users', 'reset_token')){
        try { $pdo->prepare('UPDATE users SET reset_token = NULL WHERE id = ?')->execute([$userId]); } catch(Throwable $ignore) {}
      }

      $resetDisplayName = trim((string)($resetUser['username'] ?? ''));
      if($resetDisplayName === '') $resetDisplayName = trim((string)($resetUser['email'] ?? ''));
      if($resetDisplayName === '') $resetDisplayName = 'User #' . $userId;
      $_SESSION['admin_password_reset_flash'] = [
        'user_id' => $userId,
        'username' => $resetDisplayName,
        'password' => $newPassword,
        'created_at' => time(),
      ];
      admin_record_activity($pdo, 'reset_user_password', 'user', $userId, 'Random password generated by admin; plaintext not logged');

      $returnUserQ = trim((string)($_POST['return_user_q'] ?? ''));
      $returnUserPage = max(1, (int)($_POST['return_user_page'] ?? 1));
      $returnQuery = 'msg=' . urlencode('رمز عبور جدید برای کاربر ساخته شد') . '&user_page=' . $returnUserPage;
      if($returnUserQ !== '') $returnQuery .= '&user_q=' . urlencode($returnUserQ);
      header('Location: admin.php?' . $returnQuery . '#usersSection'); exit;
    }
    if($userId > 0 && $userAction === 'add_vip_days'){
      $giftDays = max(1, min(3650, (int)($_POST['vip_gift_days'] ?? 1)));
      $giftNote = trim((string)($_POST['vip_gift_note'] ?? ''));
      $adminActor = admin_current_user() ?: [];
      $adminActorId = (int)($adminActor['id'] ?? 0);
      $gift = bm_vip_gift_add_days_to_user($pdo, $userId, $giftDays, $adminActorId > 0 ? $adminActorId : null, $giftNote);
      if(!empty($gift['permanent'])){
        $label = 'این کاربر VIP دائمی است و نیازی به افزودن روز ندارد';
      } else {
        $left = (int)($gift['days_left'] ?? 0);
        $newExpiry = (string)($gift['new_expires_at'] ?? '');
        $label = $giftDays . ' روز هدیه اضافه شد؛ اکنون حدود ' . $left . ' روز باقی مانده';
        $messageText = $giftDays . ' روز اشتراک VIP هدیه به حساب شما اضافه شد. تاریخ پایان جدید: ' . ($newExpiry !== '' ? date('Y/m/d', strtotime($newExpiry)) : '—') . '.';
        if($giftNote !== '') $messageText .= ' ' . mb_substr($giftNote, 0, 220, 'UTF-8');
        try { bm_notification_center_insert($pdo, $userId, 'vip', 'هدیه VIP برای شما 🎁', $messageText, ['url'=>'/vip','kind'=>'vip_gift','days'=>$giftDays], 'vip-gift-user:' . $userId . ':' . time()); } catch(Throwable $notifyError) { error_log('VIP user gift notify: '.$notifyError->getMessage()); }
      }
      admin_record_activity($pdo, 'vip_user_gift', 'user', $userId, $giftDays . ' days');
      header('Location: admin.php?msg=' . urlencode($label) . '&user_q=' . urlencode((string)($_POST['return_user_q'] ?? '')) . '#user-' . $userId); exit;
    }
    if($userId > 0 && $userAction === 'make_vip'){
      $vipPlan = strtolower(trim((string)($_POST['vip_plan'] ?? '30')));
      $expiresAt = null;
      if($vipPlan === 'custom'){
        $custom = trim((string)($_POST['vip_until'] ?? ''));
        $ts = $custom !== '' ? strtotime($custom . ' 23:59:59') : false;
        if($ts === false || $ts <= time()) throw new RuntimeException('تاریخ پایان VIP معتبر نیست');
        $expiresAt = date('Y-m-d H:i:s', $ts);
      } elseif($vipPlan !== 'permanent') {
        if (preg_match('/^m(\d{1,2})$/', $vipPlan, $m)) {
          $months = max(1, min(60, (int)$m[1]));
          $expiresAt = (new DateTimeImmutable('now'))->modify('+' . $months . ' months')->format('Y-m-d H:i:s');
        } else {
          // Backward compatibility for older day-based values already posted by cached admin pages.
          $days = max(1, min(3650, (int)$vipPlan));
          $expiresAt = date('Y-m-d H:i:s', time() + ($days * 86400));
        }
      }
      $vipResult = bm_watch_party_grant_vip($pdo, $userId, $expiresAt);
      $details = $expiresAt ? ('VIP until ' . $expiresAt) : 'Permanent VIP';
      admin_record_activity($pdo, 'grant_vip', 'user', $userId, $details);
      $vipMessage = $expiresAt
        ? ('اشتراک VIP شما تا ' . date('Y/m/d', strtotime($expiresAt)) . ' فعال شد. حالا می‌توانید Watch Party خصوصی بسازید، با همراهتان Voice Call داشته باشید و هنگام فیلم دیدن استیکر و GIF بفرستید.')
        : 'اشتراک VIP دائمی شما فعال شد. Watch Party خصوصی، Voice Call، چت و استیکر/GIF هنگام فیلم دیدن برای شما فعال است.';
      bm_notification_center_insert($pdo, $userId, 'vip', 'VIP شما فعال شد 👑', $vipMessage, ['url'=>'/vip','kind'=>'vip'], 'vip-grant:' . sha1((string)($expiresAt ?: 'permanent') . '|' . time()));
      $label = $expiresAt ? ('کاربر تا ' . date('Y/m/d', strtotime($expiresAt)) . ' VIP شد') : 'کاربر به‌صورت دائمی VIP شد';
      header('Location: admin.php?msg=' . urlencode($label) . '#usersSection'); exit;
    }
    if($userId > 0 && $userAction === 'remove_vip'){
      bm_watch_party_revoke_vip($pdo, $userId);
      admin_record_activity($pdo, 'revoke_vip', 'user', $userId, 'VIP access removed');
      bm_notification_center_insert($pdo, $userId, 'vip', 'وضعیت اشتراک VIP تغییر کرد', 'اشتراک VIP حساب شما غیرفعال شده است. برای مشاهده پلن‌ها و فعال‌سازی دوباره می‌توانید وارد صفحه VIP شوید.', ['url'=>'/vip','kind'=>'vip'], 'vip-revoke:' . time());
      header('Location: admin.php?msg=' . urlencode('دسترسی VIP کاربر حذف شد') . '#usersSection'); exit;
    }
    if($userId > 0 && $userAction === 'delete_avatar' && admin_column_exists_safe($pdo, 'users', 'avatar')){
      $stmt = $pdo->prepare('SELECT avatar FROM users WHERE id = ?'); $stmt->execute([$userId]); $avatar = (string)$stmt->fetchColumn();
      if($avatar !== ''){ $path = __DIR__ . '/uploads/avatars/' . basename($avatar); if(is_file($path)) @unlink($path); }
      $pdo->prepare('UPDATE users SET avatar = NULL WHERE id = ?')->execute([$userId]);
      admin_record_activity($pdo, 'delete_user_avatar', 'user', $userId, 'Avatar removed from admin panel');
      header('Location: admin.php?msg=' . urlencode('آواتار کاربر حذف شد') . '#usersSection'); exit;
    }
    if($userId > 0 && $statusCol){
      if($userAction === 'ban'){
        $value = $statusCol === 'is_banned' ? 1 : 'banned';
        $pdo->prepare('UPDATE users SET `' . $statusCol . '` = ? WHERE id = ?')->execute([$value, $userId]);
        admin_record_activity($pdo, 'ban_user', 'user', $userId, 'User banned');
        header('Location: admin.php?msg=' . urlencode('کاربر مسدود شد') . '#usersSection'); exit;
      }
      if($userAction === 'unban'){
        $value = $statusCol === 'is_banned' ? 0 : 'active';
        $pdo->prepare('UPDATE users SET `' . $statusCol . '` = ? WHERE id = ?')->execute([$value, $userId]);
        admin_record_activity($pdo, 'unban_user', 'user', $userId, 'User unbanned');
        header('Location: admin.php?msg=' . urlencode('مسدودی کاربر برداشته شد') . '#usersSection'); exit;
      }
    }
    header('Location: admin.php?msg=' . urlencode('این اکشن با ساختار فعلی جدول users قابل انجام نیست') . '#usersSection'); exit;
  } catch(Throwable $e){ header('Location: admin.php?msg=' . urlencode('خطا در مدیریت کاربر: ' . $e->getMessage()) . '#usersSection'); exit; }
}


if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_movie'])){
  $title = trim($_POST['title'] ?? '');
  $titleFa = trim($_POST['title_fa'] ?? '');
  $type = $_POST['type'] ?? 'movie';
  $year = intval($_POST['year'] ?? 0);
  $imdbRate = floatval($_POST['imdb_rate'] ?? 0);
  $imdbVotes = intval($_POST['imdb_votes'] ?? 0);
  $imdbCode = trim($_POST['imdb_code'] ?? '');
  $description = admin_clean_movie_summary($_POST['description'] ?? '');
  $country = admin_join_list_values($_POST['countries'] ?? [], $_POST['countries_manual'] ?? '');
  $genres = admin_join_list_values($_POST['genres_list'] ?? '', $_POST['genres_manual'] ?? '');
  $director = trim($_POST['director'] ?? '');
  $actors = trim($_POST['actors'] ?? '');
  $language = admin_join_list_values($_POST['languages'] ?? [], $_POST['languages_manual'] ?? '');
  $productionCompanies = trim($_POST['production_companies'] ?? '');
  $status = trim($_POST['status'] ?? '');
  $rated = trim($_POST['rated'] ?? '');
  $seasons = !empty($_POST['seasons']) ? intval($_POST['seasons']) : null;
  $episodes = !empty($_POST['episodes']) ? intval($_POST['episodes']) : null;
  $releaseUpdate = [
    'last_season' => (int)($_POST['last_season'] ?? 0),
    'last_episode' => (int)($_POST['last_episode'] ?? 0),
    'latest_quality' => trim((string)($_POST['latest_quality'] ?? '')),
    'dubbed_added' => !empty($_POST['dubbed_added']),
    'subtitle_added' => !empty($_POST['subtitle_added']),
    'season_completed' => !empty($_POST['season_completed']),
    'series_completed' => !empty($_POST['series_completed']),
    'update_note' => trim((string)($_POST['update_note'] ?? '')),
  ];
  if(empty($title)){
    $message = "عنوان اصلی فیلم یا سریال الزامی است";
    $messageType = "error";
  } else {
    $allowDuplicate = !empty($_POST['allow_duplicate']);
    $duplicateRows = admin_find_movie_duplicates($pdo, $title, $titleFa, $imdbCode, $year);
    if($duplicateRows && !$allowDuplicate){
      $dupNames = array_map(function($r) use ($title, $titleFa, $imdbCode, $year){
        return '#' . (int)($r['id'] ?? 0) . ' - ' . (($r['title_fa'] ?? '') ?: ($r['title'] ?? '')) . ' (' . admin_duplicate_match_label($r, $title, $titleFa, $imdbCode, $year) . ')';
      }, $duplicateRows);
      $message = "این عنوان احتمالاً قبلاً ثبت شده است: " . implode('، ', array_slice($dupNames, 0, 3)) . " — اگر واقعاً می‌خواهی نسخه تکراری بسازی، در هشدار فرم گزینه ادامه با ثبت تکراری را بزن.";
      $messageType = "error";
    } else {
    try {
      if (function_exists('bm_movie_update_schema')) bm_movie_update_schema($pdo);
      $pdo->beginTransaction();
      $stmt = $pdo->prepare("INSERT INTO movies (title, title_fa, type, year, imdb_rate, imdb_votes, imdb_code, description, country, genres, director, actors, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");
      $stmt->execute([$title, $titleFa, $type, $year, $imdbRate, $imdbVotes, $imdbCode, $description, $country, $genres, $director, $actors]);
      $movieId = $pdo->lastInsertId();
      if(!empty($imdbCode)){
        admin_upsert_movie_extra_info($pdo, $imdbCode, [
          'language'=>$language, 'production_companies'=>$productionCompanies, 'status'=>$status,
          'rated'=>$rated, 'seasons'=>$seasons, 'episodes'=>$episodes
        ]);
      }
      if(isset($_POST['soft_quality']) && is_array($_POST['soft_quality'])){
        $softCols = ['movie_id','quality','url'];
        if(admin_column_exists_safe($pdo,'softsub_links','subtitle_url')) $softCols[]='subtitle_url';
        if(admin_column_exists_safe($pdo,'softsub_links','size')) $softCols[]='size';
        if(admin_column_exists_safe($pdo,'softsub_links','season')) $softCols[]='season';
        if(admin_column_exists_safe($pdo,'softsub_links','episode')) $softCols[]='episode';
        $softStmt = $pdo->prepare('INSERT INTO softsub_links (`'.implode('`,`',$softCols).'`) VALUES ('.implode(',',array_fill(0,count($softCols),'?')).')');
        for($i = 0; $i < count($_POST['soft_quality']); $i++) if(!empty($_POST['soft_url'][$i])){
          $row=['movie_id'=>$movieId,'quality'=>trim((string)($_POST['soft_quality'][$i]??'')),'url'=>bm_ddm_apply_active_url(trim((string)$_POST['soft_url'][$i])),'subtitle_url'=>bm_ddm_apply_active_url(trim((string)($_POST['soft_subtitle_url'][$i]??''))),'size'=>trim((string)($_POST['soft_size'][$i]??'')),'season'=>($type!=='movie'?(int)($_POST['soft_season'][$i]??0):null),'episode'=>($type!=='movie'?(int)($_POST['soft_episode'][$i]??0):null)];
          $softStmt->execute(array_map(static fn($c)=>$row[$c]??null,$softCols));
        }
      }
      if(isset($_POST['dub_quality']) && is_array($_POST['dub_quality'])){
        $dubCols = ['movie_id','quality','url'];
        if(admin_column_exists_safe($pdo,'dubbed_links','size')) $dubCols[]='size';
        if(admin_column_exists_safe($pdo,'dubbed_links','season')) $dubCols[]='season';
        if(admin_column_exists_safe($pdo,'dubbed_links','episode')) $dubCols[]='episode';
        $dubStmt = $pdo->prepare('INSERT INTO dubbed_links (`'.implode('`,`',$dubCols).'`) VALUES ('.implode(',',array_fill(0,count($dubCols),'?')).')');
        for($i = 0; $i < count($_POST['dub_quality']); $i++) if(!empty($_POST['dub_url'][$i])){
          $row=['movie_id'=>$movieId,'quality'=>trim((string)($_POST['dub_quality'][$i]??'')),'url'=>bm_ddm_apply_active_url(trim((string)$_POST['dub_url'][$i])),'size'=>trim((string)($_POST['dub_size'][$i]??'')),'season'=>($type!=='movie'?(int)($_POST['dub_season'][$i]??0):null),'episode'=>($type!=='movie'?(int)($_POST['dub_episode'][$i]??0):null)];
          $dubStmt->execute(array_map(static fn($c)=>$row[$c]??null,$dubCols));
        }
      }
      // For series, DB episode count is derived from distinct season+episode identities,
      // not from the number of quality/dubbed/original link rows.
      if($type !== 'movie') bm_episode_stats_sync_movie($pdo, (int)$movieId, $imdbCode, true);
      bm_movie_update_upsert($pdo, (int)$movieId, $releaseUpdate);
      if(isset($_FILES['poster']) && ($_FILES['poster']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE){
        admin_safe_image_upload($_FILES['poster'], 'posters/', (string)($imdbCode ?: $movieId), 82);
      }
      $pdo->commit();
      $message = "فیلم / سریال با موفقیت اضافه شد"; $messageType = "success";
      echo '<script>setTimeout(function(){ window.location.href = "admin.php?msg=" . encodeURIComponent("' . addslashes($message) . '"); }, 1000);</script>';
    } catch(Throwable $e){
      if($pdo->inTransaction()) $pdo->rollBack();
      $message = "خطا در افزودن فیلم: " . $e->getMessage();
      $messageType = "error";
    }
    }
  }
}

if(isset($_POST['upload_poster_ajax']) && isset($_FILES['poster_file_ajax'])){
  header('Content-Type: application/json; charset=utf-8');
  $posterKey = trim((string)($_POST['imdb_code'] ?? ''));
  if($posterKey !== ''){
    try {
      admin_safe_image_upload($_FILES['poster_file_ajax'], 'posters/', $posterKey, 82);
      echo json_encode(['success' => true, 'message' => 'کاور با موفقیت آپلود شد'], JSON_UNESCAPED_UNICODE);
      exit;
    } catch(Throwable $e) {
      echo json_encode(['success' => false, 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
      exit;
    }
  }
  echo json_encode(['success' => false, 'message' => 'شناسه کاور نامعتبر است'], JSON_UNESCAPED_UNICODE); exit;
}

if(isset($_GET['delete_movie']) && is_numeric($_GET['delete_movie'])){
  $movieId = intval($_GET['delete_movie']);
  try {
    $movieStmt = $pdo->prepare('SELECT id, imdb_code FROM movies WHERE id = ?');
    $movieStmt->execute([$movieId]);
    $deletedMovieRow = $movieStmt->fetch(PDO::FETCH_ASSOC);
    if(!$deletedMovieRow) throw new RuntimeException('فیلم پیدا نشد.');
    $pdo->beginTransaction();
    if(admin_table_exists_safe($pdo, 'comment_likes') && admin_table_exists_safe($pdo, 'comments')){
      $pdo->prepare("DELETE cl FROM comment_likes cl INNER JOIN comments c ON c.id = cl.comment_id WHERE c.movie_id = ?")->execute([$movieId]);
    }
    foreach(['softsub_links','dubbed_links','comments','watchlist','watch_history','admin_picks','collection_movies','movie_ratings'] as $tbl){
      if(admin_table_exists_safe($pdo, $tbl)) $pdo->prepare("DELETE FROM `{$tbl}` WHERE movie_id = ?")->execute([$movieId]);
    }
    $pdo->prepare("DELETE FROM movies WHERE id = ?")->execute([$movieId]);
    $pdo->commit();
    admin_cleanup_deleted_movie_assets($pdo, $deletedMovieRow);
    admin_record_activity($pdo, 'delete_movie', 'movie', $movieId, 'Movie permanently deleted');
    header("Location: admin.php?msg=" . urlencode('فیلم با موفقیت حذف شد') . "#moviesSection"); exit;
  } catch(Throwable $e){
    if($pdo->inTransaction()) $pdo->rollBack();
    header("Location: admin.php?msg=" . urlencode('خطا در حذف فیلم: ' . $e->getMessage()) . "#moviesSection"); exit;
  }
}

// حذف استوری با POST (مسیر اصلی امن) و پشتیبانی از لینک قدیمی دارای CSRF
$storyDeleteId = 0;
if($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['story_action'] ?? '') === 'delete'){
  $storyDeleteId = (int)($_POST['story_id'] ?? 0);
} elseif(isset($_GET['delete_story']) && is_numeric($_GET['delete_story'])){
  $storyDeleteId = (int)$_GET['delete_story'];
}
if($storyDeleteId > 0){
  try {
    $stmt = $pdo->prepare("SELECT file_path FROM stories WHERE id = ?");
    $stmt->execute([$storyDeleteId]);
    $storyValue = $stmt->fetchColumn();
    if($storyValue === false) throw new RuntimeException('استوری پیدا نشد.');
    $storyPath = (string)($storyValue ?: '');
    $pdo->beginTransaction();
    if(admin_table_exists_safe($pdo, 'story_views')) $pdo->prepare("DELETE FROM story_views WHERE story_id = ?")->execute([$storyDeleteId]);
    $pdo->prepare("DELETE FROM stories WHERE id = ?")->execute([$storyDeleteId]);
    $remainingStories = $pdo->query("SELECT id FROM stories ORDER BY story_order ASC, id ASC")->fetchAll(PDO::FETCH_COLUMN) ?: [];
    $reorderStory = $pdo->prepare("UPDATE stories SET story_order = ? WHERE id = ?");
    foreach($remainingStories as $order => $remainingStoryId) $reorderStory->execute([$order, (int)$remainingStoryId]);
    $pdo->commit();
    admin_safe_unlink($storyPath, ['uploads/stories/']);
    admin_record_activity($pdo, 'delete_story', 'story', $storyDeleteId, $storyPath);
    header("Location: admin.php?msg=" . urlencode('استوری با موفقیت حذف شد') . "#storiesSection"); exit;
  } catch(Throwable $e){
    if($pdo->inTransaction()) $pdo->rollBack();
    header("Location: admin.php?msg=" . urlencode('خطا در حذف استوری: ' . $e->getMessage()) . "#storiesSection"); exit;
  }
}

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_story'])){
  $caption = trim((string)($_POST['caption'] ?? ''));
  $link = trim((string)($_POST['link'] ?? ''));
  if($link !== ''){
    $safeLink = admin_safe_destination_url($link);
    if($safeLink === ''){
      header("Location: admin.php?msg=" . urlencode('لینک استوری معتبر نیست') . "#storiesSection"); exit;
    }
    $link = $safeLink;
  }

  $file = $_FILES['story_file'] ?? null;
  if(!is_array($file)){
    header("Location: admin.php?msg=" . urlencode('فایل استوری دریافت نشد') . "#storiesSection"); exit;
  }
  $uploadError = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
  if($uploadError !== UPLOAD_ERR_OK){
    header("Location: admin.php?msg=" . urlencode(admin_panel_upload_error_message($uploadError)) . "#storiesSection"); exit;
  }

  $ext = strtolower(pathinfo((string)($file['name'] ?? ''), PATHINFO_EXTENSION));
  $isVideo = in_array($ext, ['mp4', 'webm', 'mov'], true);
  try {
    if($isVideo) admin_safe_upload_check($file, ['mp4','webm','mov'], ['video/mp4','video/webm','video/quicktime','application/octet-stream'], 80*1024*1024);
    else admin_safe_upload_check($file, ['jpg','jpeg','png','webp'], ['image/jpeg','image/png','image/webp'], 8*1024*1024);

    $relativeDir = 'uploads/stories/';
    $absoluteDir = __DIR__ . '/uploads/stories/';
    if(!is_dir($absoluteDir) && !mkdir($absoluteDir, 0755, true)) throw new RuntimeException('پوشه استوری ساخته نشد.');
    if(!is_writable($absoluteDir)) throw new RuntimeException('پوشه uploads/stories قابل نوشتن نیست. Permission هاست را بررسی کنید.');

    $filename = 'story_' . date('Ymd_His') . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
    $absolutePath = $absoluteDir . $filename;
    if(!move_uploaded_file((string)$file['tmp_name'], $absolutePath)) throw new RuntimeException('ذخیره فایل استوری روی هاست انجام نشد.');
    @chmod($absolutePath, 0644);
    $relativePath = $relativeDir . $filename;

    try {
      $pdo->beginTransaction();
      $pdo->exec("UPDATE stories SET story_order = story_order + 1");
      $stmt = $pdo->prepare("INSERT INTO stories (type, file_path, caption, link, story_order, created_at) VALUES (?, ?, ?, ?, 0, NOW())");
      $stmt->execute([$isVideo ? 'video' : 'image', $relativePath, $caption, $link]);
      $storyId = (int)$pdo->lastInsertId();
      $pdo->commit();
      admin_record_activity($pdo, 'add_story', 'story', $storyId, $relativePath);
    } catch(Throwable $dbError){
      if($pdo->inTransaction()) $pdo->rollBack();
      @unlink($absolutePath);
      throw $dbError;
    }
    header("Location: admin.php?msg=" . urlencode('استوری با موفقیت اضافه شد') . "#storiesSection"); exit;
  } catch(Throwable $e){
    header("Location: admin.php?msg=" . urlencode('خطا در افزودن استوری: ' . $e->getMessage()) . "#storiesSection"); exit;
  }
}
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_site_notification'])){
  $notificationId = max(0, (int)($_POST['notification_id'] ?? 0));
  try {
    if($notificationId <= 0) throw new RuntimeException('شناسه نوتیفیکیشن نامعتبر است.');
    $pdo->beginTransaction();
    $deleted = 0;
    if(admin_table_exists_safe($pdo, 'notifications')){
      $stmt=$pdo->prepare('DELETE FROM notifications WHERE id=?');
      $stmt->execute([$notificationId]);
      $deleted=(int)$stmt->rowCount();
    }
    if(admin_table_exists_safe($pdo, 'app_notification_global_state')){
      $stmt=$pdo->prepare('DELETE FROM app_notification_global_state WHERE notification_id=?');
      $stmt->execute([$notificationId]);
    }
    if(admin_table_exists_safe($pdo, 'app_notifications')){
      $stmt=$pdo->prepare("DELETE FROM app_notifications WHERE dedupe_key=?");
      $stmt->execute(['global-admin:' . $notificationId]);
    }
    if(admin_table_exists_safe($pdo, 'app_notification_dismissals')){
      $stmt=$pdo->prepare('DELETE FROM app_notification_dismissals WHERE dedupe_key=?');
      $stmt->execute(['global-admin:' . $notificationId]);
    }
    $pdo->commit();
    admin_record_activity($pdo, 'delete_site_notification', 'notification', $notificationId, 'deleted=' . $deleted);
    $message = $deleted > 0 ? 'نوتیفیکیشن از سایت و فید اپ حذف شد' : 'نوتیفیکیشن پیدا نشد یا قبلاً حذف شده بود';
  } catch(Throwable $e){
    if($pdo->inTransaction()) $pdo->rollBack();
    $message = 'خطا در حذف نوتیفیکیشن: ' . $e->getMessage();
  }
  header('Location: admin.php?msg=' . urlencode($message) . '#notifSection'); exit;
}
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_site_notification_batch'])){
  $dedupe = trim((string)($_POST['notification_batch'] ?? ''));
  try {
    if($dedupe === '' || !str_starts_with($dedupe, 'admin:') || strlen($dedupe) > 190) throw new RuntimeException('شناسه گروه نوتیفیکیشن نامعتبر است.');
    $deleted = 0;
    if(admin_table_exists_safe($pdo, 'app_notifications')){
      $stmt=$pdo->prepare("DELETE FROM app_notifications WHERE type='admin' AND dedupe_key=?");
      $stmt->execute([$dedupe]);
      $deleted=(int)$stmt->rowCount();
    }
    if(admin_table_exists_safe($pdo, 'app_notification_dismissals')){
      $stmt=$pdo->prepare('DELETE FROM app_notification_dismissals WHERE dedupe_key=?');
      $stmt->execute([$dedupe]);
    }
    admin_record_activity($pdo, 'delete_site_notification_batch', 'notification_batch', null, $dedupe . ' | deleted=' . $deleted);
    $message = $deleted > 0 ? 'نوتیفیکیشن هدف‌دار برای همه گیرنده‌ها حذف شد' : 'نوتیفیکیشن هدف‌دار پیدا نشد';
  } catch(Throwable $e){
    $message = 'خطا در حذف گروه نوتیفیکیشن: ' . $e->getMessage();
  }
  header('Location: admin.php?msg=' . urlencode($message) . '#notifSection'); exit;
}
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_site_notifications'])){
  try {
    $pdo->beginTransaction();
    $deletedGlobal = admin_table_exists_safe($pdo, 'notifications') ? (int)$pdo->exec('DELETE FROM notifications') : 0;
    if(admin_table_exists_safe($pdo, 'app_notification_global_state')) $pdo->exec('DELETE FROM app_notification_global_state');
    $deletedTargeted = 0;
    if(admin_table_exists_safe($pdo, 'app_notifications')){
      $deletedTargeted = (int)$pdo->exec("DELETE FROM app_notifications WHERE (type='admin' AND dedupe_key LIKE 'admin:%') OR dedupe_key LIKE 'global-admin:%'");
    }
    if(admin_table_exists_safe($pdo, 'app_notification_dismissals')){
      $pdo->exec("DELETE FROM app_notification_dismissals WHERE dedupe_key LIKE 'admin:%' OR dedupe_key LIKE 'global-admin:%'");
    }
    $pdo->commit();
    admin_record_activity($pdo, 'clear_site_notifications', 'notification', null, 'global=' . $deletedGlobal . ' | targeted=' . $deletedTargeted);
    $message = 'اعلان‌های دستی سایت پاک شدند و دیگر در سایت/فید اپ نمایش داده نمی‌شوند';
  } catch(Throwable $e){
    if($pdo->inTransaction()) $pdo->rollBack();
    $message = 'خطا در پاک‌سازی اعلان‌ها: ' . $e->getMessage();
  }
  header('Location: admin.php?msg=' . urlencode($message) . '#notifSection'); exit;
}
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_notification'])){
  $notificationTitle = trim((string)($_POST['notification_title'] ?? 'پیام BankMovie'));
  $messageText = trim((string)($_POST['notification_message'] ?? ''));
  $audience = strtolower(trim((string)($_POST['notification_audience'] ?? 'all')));
  $identity = trim((string)($_POST['notification_identity'] ?? ''));
  $targetUrl = trim((string)($_POST['notification_url'] ?? ''));
  try {
    if($notificationTitle === '') $notificationTitle = 'پیام BankMovie';
    if(mb_strlen($notificationTitle, 'UTF-8') > 220) throw new RuntimeException('عنوان نوتیفیکیشن بیش از حد طولانی است.');
    if($messageText === '') throw new RuntimeException('متن نوتیفیکیشن خالی است.');
    if(mb_strlen($messageText, 'UTF-8') > 5000) throw new RuntimeException('متن نوتیفیکیشن بیش از حد طولانی است.');
    if(!in_array($audience, ['all','vip','regular','user'], true)) $audience = 'all';
    if($audience === 'user' && $identity === '') throw new RuntimeException('برای ارسال به یک کاربر، شناسه/نام کاربری/ایمیل را وارد کنید.');
    if($targetUrl !== '' && (!str_starts_with($targetUrl, '/') || str_starts_with($targetUrl, '//') || preg_match('/[\r\n]/', $targetUrl))) {
      throw new RuntimeException('لینک مقصد باید یک مسیر داخلی سایت مثل /vip باشد.');
    }
    $target = $targetUrl !== '' ? ['url'=>$targetUrl] : [];
    $sent = bm_notification_center_send_audience($pdo, $audience, $notificationTitle, $messageText, $target, $identity);
    if($sent < 1) throw new RuntimeException('کاربر واجد شرایط برای این ارسال پیدا نشد.');
    admin_record_activity($pdo, 'send_notification', 'notification', null, 'Audience=' . $audience . ' | recipients=' . $sent);
    $message = 'نوتیفیکیشن برای ' . number_format($sent) . ' کاربر ارسال شد';
  } catch(Throwable $e){
    $message = 'خطا در ارسال نوتیفیکیشن: ' . $e->getMessage();
  }
  header('Location: admin.php?msg=' . urlencode($message) . '#notifSection'); exit;
}
if(isset($_GET['add_to_admin_pick']) && is_numeric($_GET['add_to_admin_pick'])){
  $movieId = intval($_GET['add_to_admin_pick']);
  try {
    $pdo->beginTransaction();
    $check = $pdo->prepare('SELECT id FROM admin_picks WHERE movie_id = ? FOR UPDATE');
    $check->execute([$movieId]);
    if(!$check->fetch()){
      if(admin_safe_count($pdo, 'SELECT COUNT(*) FROM movies WHERE id = ?', [$movieId]) < 1) throw new RuntimeException('فیلم پیدا نشد.');
      $pdo->exec('UPDATE admin_picks SET pick_order = pick_order + 1');
      $pdo->prepare('INSERT INTO admin_picks (movie_id, pick_order) VALUES (?, 0)')->execute([$movieId]);
      $message = 'فیلم به انتخاب‌های ادمین اضافه شد';
    } else {
      $message = 'این فیلم قبلاً در لیست وجود دارد';
    }
    $pdo->commit();
    admin_record_activity($pdo, 'add_admin_pick', 'movie', $movieId, $message);
  } catch(Throwable $e){
    if($pdo->inTransaction()) $pdo->rollBack();
    $message = 'خطا در افزودن به انتخاب‌های ادمین: ' . $e->getMessage();
  }
  header('Location: admin.php?msg=' . urlencode($message) . '#picksSection'); exit;
}
if(isset($_GET['remove_from_admin_pick']) && is_numeric($_GET['remove_from_admin_pick'])){
  $movieId = intval($_GET['remove_from_admin_pick']);
  try {
    $pdo->beginTransaction();
    $pdo->prepare('DELETE FROM admin_picks WHERE movie_id = ?')->execute([$movieId]);
    $picks = $pdo->query('SELECT id FROM admin_picks ORDER BY pick_order ASC, id ASC')->fetchAll(PDO::FETCH_COLUMN) ?: [];
    $updateStmt = $pdo->prepare('UPDATE admin_picks SET pick_order = ? WHERE id = ?');
    foreach($picks as $order => $pickId) $updateStmt->execute([$order, (int)$pickId]);
    $pdo->commit();
    admin_record_activity($pdo, 'remove_admin_pick', 'movie', $movieId, 'Removed from admin picks');
    $message = 'از انتخاب‌های ادمین حذف شد';
  } catch(Throwable $e){
    if($pdo->inTransaction()) $pdo->rollBack();
    $message = 'خطا در حذف از انتخاب‌های ادمین: ' . $e->getMessage();
  }
  header('Location: admin.php?msg=' . urlencode($message) . '#picksSection'); exit;
}
if(isset($_POST['ajax_action']) && in_array($_POST['ajax_action'], ['reorder_admin_picks','reorder_stories'], true)){
  header('Content-Type: application/json; charset=utf-8');
  $action = (string)$_POST['ajax_action'];
  $idsRaw = $_POST['ids'] ?? [];
  if(!is_array($idsRaw)){
    $decoded = json_decode((string)$idsRaw, true);
    $idsRaw = is_array($decoded) ? $decoded : [];
  }
  $ids = array_values(array_unique(array_filter(array_map('intval', $idsRaw), fn($id) => $id > 0)));
  if(!$ids){
    http_response_code(400);
    echo json_encode(['success'=>false,'message'=>'ترتیب جدید معتبر نیست'], JSON_UNESCAPED_UNICODE); exit;
  }
  $table = $action === 'reorder_admin_picks' ? 'admin_picks' : 'stories';
  $column = $action === 'reorder_admin_picks' ? 'pick_order' : 'story_order';
  $baseOffset = $action === 'reorder_admin_picks' ? max(0, (int)($_POST['offset'] ?? 0)) : 0;
  try {
    $pdo->beginTransaction();
    $stmt = $pdo->prepare("UPDATE `{$table}` SET `{$column}` = ? WHERE id = ?");
    foreach($ids as $order => $id) $stmt->execute([$baseOffset + $order, $id]);
    $pdo->commit();
    echo json_encode(['success'=>true], JSON_UNESCAPED_UNICODE); exit;
  } catch(Throwable $e){
    if($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['success'=>false,'message'=>'ذخیره ترتیب انجام نشد: '.$e->getMessage()], JSON_UNESCAPED_UNICODE); exit;
  }
}


function bm_admin_comment_source(): string {
  $src = strtolower(trim((string)($_REQUEST['comment_source'] ?? 'database')));
  return in_array($src, ['archive1','external','app'], true) ? 'archive1' : 'database';
}
function bm_admin_comment_tables(string $source): array {
  return $source === 'archive1'
    ? ['archive1_comments', 'archive1_comment_likes']
    : ['comments', 'comment_likes'];
}

if(isset($_GET['approve_comment']) && is_numeric($_GET['approve_comment'])){
  $commentId = intval($_GET['approve_comment']);
  $commentSource = bm_admin_comment_source();
  [$commentTable, $likeTable] = bm_admin_comment_tables($commentSource);
  try {
    if(!admin_table_exists_safe($pdo, $commentTable)) throw new RuntimeException('جدول دیدگاه پیدا نشد.');
    $stmt = $pdo->prepare("SELECT movie_id, user_id FROM `{$commentTable}` WHERE id = ?");
    $stmt->execute([$commentId]);
    $commentRow = $stmt->fetch(PDO::FETCH_ASSOC);
    if(!$commentRow) throw new RuntimeException('کامنت پیدا نشد.');

    $pdo->beginTransaction();
    $pdo->prepare("UPDATE `{$commentTable}` SET status = 'approved' WHERE id = ?")->execute([$commentId]);

    $userId = (int)($commentRow['user_id'] ?? 0);
    if($userId > 0 && admin_table_exists_safe($pdo, 'users') && admin_column_exists_safe($pdo, 'users', 'first_comment_approved')){
      $pdo->prepare('UPDATE users SET first_comment_approved = 1 WHERE id = ?')->execute([$userId]);
    }
    if($commentSource === 'database') admin_recalculate_movie_rating($pdo, (int)($commentRow['movie_id'] ?? 0));
    $pdo->commit();

    admin_record_activity($pdo, 'approve_comment', $commentSource === 'archive1' ? 'archive1_comment' : 'comment', $commentId, 'Comment approved');
    $message = $commentSource === 'archive1' ? 'کامنت آرشیو ۱ تأیید شد' : 'کامنت تأیید شد';
  } catch(Throwable $e){
    if($pdo->inTransaction()) $pdo->rollBack();
    $message = 'خطا در تأیید کامنت: ' . $e->getMessage();
  }
  header('Location: admin.php?msg=' . urlencode($message) . '&tab=pending#commentsSection'); exit;
}

if(isset($_GET['reject_comment']) && is_numeric($_GET['reject_comment'])){
  $commentId = intval($_GET['reject_comment']);
  $commentSource = bm_admin_comment_source();
  [$commentTable, $likeTable] = bm_admin_comment_tables($commentSource);
  try {
    if(!admin_table_exists_safe($pdo, $commentTable)) throw new RuntimeException('جدول دیدگاه پیدا نشد.');
    $stmt = $pdo->prepare("SELECT movie_id FROM `{$commentTable}` WHERE id = ?");
    $stmt->execute([$commentId]);
    $movieId = $stmt->fetchColumn();
    if($movieId === false) throw new RuntimeException('کامنت پیدا نشد.');

    $pdo->beginTransaction();
    $pdo->prepare("UPDATE `{$commentTable}` SET status = 'rejected' WHERE id = ?")->execute([$commentId]);
    if($commentSource === 'database') admin_recalculate_movie_rating($pdo, (int)$movieId);
    $pdo->commit();

    admin_record_activity($pdo, 'reject_comment', $commentSource === 'archive1' ? 'archive1_comment' : 'comment', $commentId, 'Comment rejected');
    $message = $commentSource === 'archive1' ? 'کامنت آرشیو ۱ رد شد' : 'کامنت رد شد';
  } catch(Throwable $e){
    if($pdo->inTransaction()) $pdo->rollBack();
    $message = 'خطا در رد کامنت: ' . $e->getMessage();
  }
  header('Location: admin.php?msg=' . urlencode($message) . '&tab=pending#commentsSection'); exit;
}

if(isset($_GET['delete_comment']) && is_numeric($_GET['delete_comment'])){
  $commentId = intval($_GET['delete_comment']);
  $commentSource = bm_admin_comment_source();
  [$commentTable, $likeTable] = bm_admin_comment_tables($commentSource);
  try {
    if(!admin_table_exists_safe($pdo, $commentTable)) throw new RuntimeException('جدول دیدگاه پیدا نشد.');

    $stmt = $pdo->prepare("SELECT movie_id FROM `{$commentTable}` WHERE id = ?");
    $stmt->execute([$commentId]);
    $movieId = (int)($stmt->fetchColumn() ?: 0);

    $stmt = $pdo->prepare("SELECT id FROM `{$commentTable}` WHERE id = ? OR parent_id = ?");
    $stmt->execute([$commentId, $commentId]);
    $commentIds = array_values(array_unique(array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN) ?: [])));

    $pdo->beginTransaction();
    if($commentIds && admin_table_exists_safe($pdo, $likeTable)){
      $ph = implode(',', array_fill(0, count($commentIds), '?'));
      $pdo->prepare("DELETE FROM `{$likeTable}` WHERE comment_id IN ($ph)")->execute($commentIds);
    }
    $pdo->prepare("DELETE FROM `{$commentTable}` WHERE parent_id = ?")->execute([$commentId]);
    $pdo->prepare("DELETE FROM `{$commentTable}` WHERE id = ?")->execute([$commentId]);

    if($commentSource === 'database') admin_recalculate_movie_rating($pdo, $movieId);
    $pdo->commit();

    admin_record_activity($pdo, 'delete_comment', $commentSource === 'archive1' ? 'archive1_comment' : 'comment', $commentId, 'Comment and replies deleted');
    $message = $commentSource === 'archive1' ? 'کامنت آرشیو ۱ و پاسخ‌های آن حذف شد' : 'کامنت و پاسخ‌های آن حذف شد';
  } catch(Throwable $e){
    if($pdo->inTransaction()) $pdo->rollBack();
    $message = 'خطا در حذف کامنت: ' . $e->getMessage();
  }
  header('Location: admin.php?msg=' . urlencode($message) . '#commentsSection'); exit;
}

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_comment'])){
  $commentId = intval($_POST['comment_id']);
  $newText = trim($_POST['comment_text'] ?? '');
  $commentSource = bm_admin_comment_source();
  [$commentTable, $likeTable] = bm_admin_comment_tables($commentSource);
  try {
    if($commentId <= 0 || $newText === '') throw new RuntimeException('متن یا شناسه نامعتبر است.');
    if(!admin_table_exists_safe($pdo, $commentTable)) throw new RuntimeException('جدول دیدگاه پیدا نشد.');
    $pdo->prepare("UPDATE `{$commentTable}` SET comment = ? WHERE id = ?")->execute([$newText, $commentId]);
    $message = 'متن کامنت ویرایش شد';
  } catch(Throwable $e) {
    $message = 'خطا در ویرایش کامنت: ' . $e->getMessage();
  }
  header('Location: admin.php?msg=' . urlencode($message) . '#commentsSection'); exit;
}

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_request'])){
  $requestId = intval($_POST['request_id'] ?? 0);
  $requestedStatus = admin_request_status_key($_POST['status'] ?? 'pending');
  $adminResponse = trim((string)($_POST['admin_response'] ?? ''));
  try {
    if($requestId <= 0) throw new RuntimeException('شناسه درخواست نامعتبر است.');
    if(mb_strlen($adminResponse, 'UTF-8') > 5000) throw new RuntimeException('متن پاسخ بیش از حد طولانی است.');

    // Some older installations used ENUM(answered/approved). Detect the actual
    // column and store a compatible value, then verify what was really saved.
    $dbStatus = admin_request_status_db_value($pdo, $requestedStatus);
    $stmt = $pdo->prepare('UPDATE movie_requests SET status = ?, admin_response = ?, updated_at = NOW() WHERE id = ?');
    $stmt->execute([$dbStatus, $adminResponse, $requestId]);
    if($stmt->rowCount() < 1 && admin_safe_count($pdo, 'SELECT COUNT(*) FROM movie_requests WHERE id = ?', [$requestId]) < 1) throw new RuntimeException('درخواست پیدا نشد.');

    $verifyStmt = $pdo->prepare('SELECT user_id, title, status, admin_response FROM movie_requests WHERE id = ? LIMIT 1');
    $verifyStmt->execute([$requestId]);
    $saved = $verifyStmt->fetch(PDO::FETCH_ASSOC);
    if(!$saved) throw new RuntimeException('درخواست بعد از ذخیره قابل خواندن نیست.');
    if(admin_request_status_key($saved['status'] ?? '') !== $requestedStatus) {
      throw new RuntimeException('وضعیت در دیتابیس ذخیره نشد؛ ساختار ستون status قدیمی است.');
    }

    $requestOwner = (int)($saved['user_id'] ?? 0);
    if($requestOwner > 0){
      $requestTitle = trim((string)($saved['title'] ?? 'درخواست شما')) ?: 'درخواست شما';
      if($requestedStatus === 'approved'){
        $notifTitle = 'درخواستت پذیرفته شد 🎬';
        $notifMessage = 'درخواست «' . $requestTitle . '» پذیرفته شد.';
      } elseif($requestedStatus === 'rejected'){
        $notifTitle = 'وضعیت درخواستت به‌روزرسانی شد';
        $notifMessage = 'درخواست «' . $requestTitle . '» در حال حاضر قابل انجام نیست.';
      } else {
        $notifTitle = 'درخواستت در حال بررسی است';
        $notifMessage = 'وضعیت درخواست «' . $requestTitle . '» روی «در حال بررسی» قرار گرفت.';
      }
      if($adminResponse !== '') $notifMessage .= ' پاسخ مدیریت: ' . mb_substr($adminResponse, 0, 800, 'UTF-8');
      bm_notification_center_insert($pdo, $requestOwner, 'request_update', $notifTitle, $notifMessage, ['url'=>'/profile#requests-section','request_id'=>$requestId], 'request:' . $requestId . ':' . $requestedStatus . ':' . sha1($adminResponse));
    }

    admin_record_activity($pdo, 'update_request', 'request', $requestId, $requestedStatus . ($adminResponse !== '' ? ' | response' : ''));
    $message = $requestedStatus === 'approved' ? 'درخواست پذیرفته شد و وضعیت کاربر به‌روزرسانی شد' : ($requestedStatus === 'rejected' ? 'درخواست رد شد و وضعیت کاربر به‌روزرسانی شد' : 'درخواست در وضعیت بررسی قرار گرفت');
  } catch(Throwable $e){
    $message = 'خطا در به‌روزرسانی درخواست: ' . $e->getMessage();
  }
  header('Location: admin.php?msg=' . urlencode($message) . '#requestsSection'); exit;
}
if(isset($_GET['delete_request']) && is_numeric($_GET['delete_request'])){
  $requestId = intval($_GET['delete_request']);
  try {
    $stmt = $pdo->prepare('DELETE FROM movie_requests WHERE id = ?');
    $stmt->execute([$requestId]);
    if($stmt->rowCount() < 1) throw new RuntimeException('درخواست پیدا نشد.');
    admin_record_activity($pdo, 'delete_request', 'request', $requestId, 'Request deleted');
    $message = 'درخواست حذف شد';
  } catch(Throwable $e){
    $message = 'خطا در حذف درخواست: ' . $e->getMessage();
  }
  header('Location: admin.php?msg=' . urlencode($message) . '#requestsSection'); exit;
}

$requestsPerPage = 20;
$reqPage = isset($_GET['req_page']) ? max(1, intval($_GET['req_page'])) : 1;
$reqOffset = ($reqPage - 1) * $requestsPerPage;
$totalRequests = (int)$pdo->query("SELECT COUNT(*) FROM movie_requests")->fetchColumn();
$totalReqPages = ceil($totalRequests / $requestsPerPage);
$requestsList = $pdo->prepare("SELECT r.*, u.username, u.avatar FROM movie_requests r LEFT JOIN users u ON r.user_id = u.id ORDER BY CASE WHEN LOWER(TRIM(CAST(r.status AS CHAR))) IN ('pending','new','reviewing','review','0') THEN 1 ELSE 2 END, r.created_at DESC LIMIT ? OFFSET ?");
$requestsList->execute([$requestsPerPage, $reqOffset]);
$requestsList = $requestsList->fetchAll();

$commentsPerPage = 20;
$commentTab = ($_GET['tab'] ?? 'approved') === 'pending' ? 'pending' : 'approved';
$commentPage = isset($_GET['comment_page']) ? max(1, intval($_GET['comment_page'])) : 1;
$commentOffset = ($commentPage - 1) * $commentsPerPage;
$commentsListAll = [];

if(admin_table_exists_safe($pdo, 'comments')){
  $dbRows = admin_safe_fetch_all($pdo, "
    SELECT c.*,
           m.id AS local_movie_id,
           m.title AS movie_title_en,
           COALESCE(NULLIF(m.title_fa,''), NULLIF(m.title,''), NULLIF(ai.item_title_fa,''), NULLIF(ai.item_title,'')) AS movie_title,
           m.imdb_code,
           ai.archive_no AS external_archive_no,
           ai.slug AS external_slug,
           ai.item_type AS external_type,
           COALESCE(u.username, c.username, 'کاربر') AS user_name,
           u.avatar AS user_avatar,
           (SELECT COUNT(*) FROM comments r WHERE r.parent_id = c.id AND r.status != 'rejected') AS reply_count
    FROM comments c
    LEFT JOIN movies m ON c.movie_id = m.id
    LEFT JOIN archive1_items ai ON c.movie_id = ai.virtual_movie_id
    LEFT JOIN users u ON c.user_id = u.id
    WHERE c.status = ?
    ORDER BY c.created_at DESC
    LIMIT 1000
  ", [$commentTab]);
  foreach($dbRows as &$row){
    $row['comment_source'] = 'database';
    $archiveNo = (int)($row['external_archive_no'] ?? 0);
    $slug = trim((string)($row['external_slug'] ?? ''));
    $type = trim((string)($row['external_type'] ?? ''));
    $localId = (int)($row['local_movie_id'] ?? 0);
    if($localId > 0){
      $row['source_label'] = 'دیتابیس سایت';
      $row['movie_url'] = function_exists('bm_movie_url')
        ? bm_movie_url(['id'=>$localId,'title'=>$row['movie_title_en'] ?? ($row['movie_title'] ?? 'movie')]) . '#bmMovieComments'
        : ('movie.php?imdb=' . rawurlencode((string)($row['imdb_code'] ?? '')) . '#bmMovieComments');
    } elseif($archiveNo > 0 && $slug !== '') {
      $row['source_label'] = 'آرشیو ' . $archiveNo . ' / ثبت قدیمی';
      $row['movie_url'] = 'movie.php?arc=' . $archiveNo . '&slug=' . rawurlencode($slug)
        . ($type !== '' ? '&type=' . rawurlencode($type) : '') . '#bmMovieComments';
    } else {
      $row['source_label'] = 'دیتابیس سایت';
      $row['movie_url'] = '';
    }
    if(empty($row['movie_title'])) $row['movie_title'] = 'محتوای مرتبط با این دیدگاه';
  }
  unset($row);
  $commentsListAll = array_merge($commentsListAll, $dbRows);
}

if(admin_table_exists_safe($pdo, 'archive1_comments')){
  $arcRows = admin_safe_fetch_all($pdo, "
    SELECT c.*,
           ai.archive_no AS external_archive_no,
           ai.slug AS external_slug,
           ai.item_type AS external_type,
           COALESCE(NULLIF(ai.item_title_fa,''), NULLIF(ai.item_title,'')) AS movie_title,
           COALESCE(u.username, c.username, 'کاربر') AS user_name,
           u.avatar AS user_avatar,
           (SELECT COUNT(*) FROM archive1_comments r WHERE r.parent_id = c.id AND r.status != 'rejected') AS reply_count
    FROM archive1_comments c
    LEFT JOIN archive1_items ai ON ai.virtual_movie_id = c.movie_id
    LEFT JOIN users u ON c.user_id = u.id
    WHERE c.status = ?
    ORDER BY c.created_at DESC
    LIMIT 1000
  ", [$commentTab]);

  foreach($arcRows as &$row){
    $archiveNo = max(1, (int)($row['external_archive_no'] ?? 1));
    $slug = trim((string)($row['external_slug'] ?? ''));
    $type = trim((string)($row['external_type'] ?? ''));
    $row['comment_source'] = 'archive1';
    $row['source_label'] = 'آرشیو ' . $archiveNo . ' / اپ';
    $row['imdb_code'] = '';
    $row['movie_url'] = $slug !== ''
      ? ('movie.php?arc=' . $archiveNo . '&slug=' . rawurlencode($slug)
          . ($type !== '' ? '&type=' . rawurlencode($type) : '') . '#bmMovieComments')
      : '';
    if(empty($row['movie_title'])) $row['movie_title'] = 'محتوای آرشیو ' . $archiveNo;
  }
  unset($row);
  $commentsListAll = array_merge($commentsListAll, $arcRows);
}

$commentFocusId = max(0, (int)($_GET['comment_focus'] ?? 0));
$commentFocusSource = (string)($_GET['comment_source'] ?? 'database');
if (!in_array($commentFocusSource, ['database','archive1'], true)) $commentFocusSource = 'database';

usort($commentsListAll, static function(array $a, array $b): int {
  $ta = strtotime((string)($a['created_at'] ?? '')) ?: 0;
  $tb = strtotime((string)($b['created_at'] ?? '')) ?: 0;
  if($ta === $tb) return ((int)($b['id'] ?? 0)) <=> ((int)($a['id'] ?? 0));
  return $tb <=> $ta;
});
if ($commentFocusId > 0) {
  foreach ($commentsListAll as $focusIndex => $focusRow) {
    if ((int)($focusRow['id'] ?? 0) === $commentFocusId && (string)($focusRow['comment_source'] ?? 'database') === $commentFocusSource) {
      $focusItem = $focusRow;
      array_splice($commentsListAll, $focusIndex, 1);
      array_unshift($commentsListAll, $focusItem);
      $commentPage = 1;
      $commentOffset = 0;
      break;
    }
  }
}
$totalCommentsCount = count($commentsListAll);
$commentsList = array_slice($commentsListAll, $commentOffset, $commentsPerPage);
$totalCommentPages = max(1, (int)ceil(max(1, $totalCommentsCount) / $commentsPerPage));

$page = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;
$perPage = 20;
$offset = ($page - 1) * $perPage;
$totalPages = ceil($totalMovies / $perPage);
$paginatedMovies = $pdo->prepare("SELECT * FROM movies ORDER BY id DESC LIMIT ? OFFSET ?");
$paginatedMovies->execute([$perPage, $offset]);
$paginatedMovies = $paginatedMovies->fetchAll();

// Admin picks with posters
$adminPickPage = isset($_GET['pick_page']) ? max(1, intval($_GET['pick_page'])) : 1;
$adminPickPerPage = 10;
$adminPickOffset = ($adminPickPage - 1) * $adminPickPerPage;
$totalAdminPickPages = max(1, (int)ceil(max(1, $totalAdminPicks) / $adminPickPerPage));
if($adminPickPage > $totalAdminPickPages){ $adminPickPage = $totalAdminPickPages; $adminPickOffset = ($adminPickPage - 1) * $adminPickPerPage; }
$adminPicksStmt = $pdo->prepare("SELECT ap.id as pick_id, ap.pick_order, m.* FROM admin_picks ap JOIN movies m ON ap.movie_id = m.id ORDER BY ap.pick_order ASC LIMIT ? OFFSET ?");
$adminPicksStmt->execute([$adminPickPerPage, $adminPickOffset]);
$adminPicksList = $adminPicksStmt->fetchAll();
// Add poster path to each admin pick
foreach($adminPicksList as &$pick){
  $posterKey = trim((string)($pick['imdb_code'] ?? '')) !== '' ? $pick['imdb_code'] : $pick['id'];
  $pick['poster_path'] = 'posters/' . $posterKey . '.webp';
  $pick['has_poster'] = is_file(__DIR__ . '/' . $pick['poster_path']);
}
unset($pick);

$allMoviesForSearch = []; // Admin Fast: pick search is now AJAX-based.

if(isset($_GET['msg'])){ $message = urldecode($_GET['msg']); $messageType = "success"; }
$bmSecurityReport = function_exists('bm_security_global_rate_report') ? bm_security_global_rate_report(40) : ['settings'=>[],'stats'=>[],'active'=>[],'events'=>[],'top_targets'=>[]];
$bmSecurityCfg = (array)($bmSecurityReport['settings'] ?? []);
$bmSecurityStats = (array)($bmSecurityReport['stats'] ?? []);
$bmSecurityEnabled = !empty($bmSecurityCfg['enabled']);
$bmSecurityWhitelist = implode("\n", (array)($bmSecurityCfg['whitelist'] ?? []));
$bmSecurityBlacklist = implode("\n", (array)($bmSecurityCfg['blacklist'] ?? []));
$bmSecurityEvents = array_slice((array)($bmSecurityReport['events'] ?? []), 0, 7);
$bmSecurityTargets = array_slice((array)($bmSecurityReport['top_targets'] ?? []), 0, 6, true);
$bmSecurityTargetMax = $bmSecurityTargets ? max(array_map('intval', array_values($bmSecurityTargets))) : 0;
$bmSecurityEventLabels = [
  'blocked' => 'مسدودی خودکار',
  'manual_block' => 'مسدودی دستی',
  'manual_unblock' => 'رفع مسدودی',
  'captcha_success' => 'CAPTCHA موفق',
  'captcha_failed' => 'CAPTCHA ناموفق',
  'captcha_escalated' => 'تشدید CAPTCHA',
  'identity_blocked' => 'هویت محدود شد',
  'endpoint_escalated' => 'تشدید Endpoint',
];
$passwordResetFlash = null;
if(!empty($_SESSION['admin_password_reset_flash']) && is_array($_SESSION['admin_password_reset_flash'])){
  $candidateFlash = $_SESSION['admin_password_reset_flash'];
  unset($_SESSION['admin_password_reset_flash']);
  $flashCreated = (int)($candidateFlash['created_at'] ?? 0);
  if($flashCreated > 0 && (time() - $flashCreated) <= 600 && !empty($candidateFlash['password'])){
    $passwordResetFlash = $candidateFlash;
  }
}
if(isset($_GET['logout'])){ header('Location: /logout'); exit; }



// ============================================
// داده‌های مرکز فرماندهی، سلامت محتوا و ابزارهای حرفه‌ای
// ============================================
$linkCountSubSql = "SELECT movie_id, COUNT(*) AS link_count FROM (SELECT movie_id FROM softsub_links UNION ALL SELECT movie_id FROM dubbed_links) x GROUP BY movie_id";
$totalNoLinks = admin_safe_count($pdo, "SELECT COUNT(*) FROM movies m LEFT JOIN ($linkCountSubSql) lc ON lc.movie_id = m.id WHERE COALESCE(lc.link_count,0)=0");
$totalNoDescriptions = admin_safe_count($pdo, "SELECT COUNT(*) FROM movies WHERE description IS NULL OR TRIM(description) = ''");
$totalNoGenres = admin_safe_count($pdo, "SELECT COUNT(*) FROM movies WHERE genres IS NULL OR TRIM(genres) = ''");
$totalNoImdb = admin_safe_count($pdo, "SELECT COUNT(*) FROM movies WHERE imdb_code IS NULL OR TRIM(imdb_code) = ''");
$totalLowRated = admin_safe_count($pdo, "SELECT COUNT(*) FROM movies WHERE imdb_rate IS NOT NULL AND imdb_rate > 0 AND imdb_rate < 5");
$totalIncompleteMovies = admin_safe_count($pdo, "SELECT COUNT(*) FROM movies m LEFT JOIN ($linkCountSubSql) lc ON lc.movie_id = m.id WHERE COALESCE(lc.link_count,0)=0 OR m.description IS NULL OR TRIM(m.description)='' OR m.genres IS NULL OR TRIM(m.genres)='' OR m.imdb_code IS NULL OR TRIM(m.imdb_code)='' ");
$healthScore = $totalMovies > 0 ? max(0, min(100, (int)round(100 - (($totalIncompleteMovies / max(1, $totalMovies)) * 100)))) : 100;
$incompleteMovies = admin_safe_fetch_all($pdo, "SELECT m.id, m.title, m.title_fa, m.imdb_code, m.year, m.type, m.imdb_rate, COALESCE(lc.link_count,0) AS link_count FROM movies m LEFT JOIN ($linkCountSubSql) lc ON lc.movie_id = m.id WHERE COALESCE(lc.link_count,0)=0 OR m.description IS NULL OR TRIM(m.description)='' OR m.genres IS NULL OR TRIM(m.genres)='' OR m.imdb_code IS NULL OR TRIM(m.imdb_code)='' ORDER BY m.id DESC LIMIT 12");

$todayMovies = admin_safe_count($pdo, "SELECT COUNT(*) FROM movies WHERE DATE(created_at)=CURDATE()");
$todayComments = admin_safe_count($pdo, "SELECT COUNT(*) FROM comments WHERE DATE(created_at)=CURDATE()");
$todayRequests = admin_safe_count($pdo, "SELECT COUNT(*) FROM movie_requests WHERE DATE(created_at)=CURDATE()");
$todayUsers = admin_column_exists_safe($pdo, 'users', 'created_at') ? admin_safe_count($pdo, "SELECT COUNT(*) FROM users WHERE DATE(created_at)=CURDATE()") : 0;
$pendingRequests = admin_safe_count($pdo, "SELECT COUNT(*) FROM movie_requests WHERE LOWER(TRIM(CAST(status AS CHAR))) IN ('pending','new','reviewing','review','0')");

$recentLinks = admin_safe_fetch_all($pdo, "SELECT * FROM (SELECT 'softsub' AS link_type, l.id, l.movie_id, l.quality, l.url, l.size, m.title, m.title_fa FROM softsub_links l JOIN movies m ON m.id = l.movie_id UNION ALL SELECT 'dubbed' AS link_type, l.id, l.movie_id, l.quality, l.url, l.size, m.title, m.title_fa FROM dubbed_links l JOIN movies m ON m.id = l.movie_id) z ORDER BY id DESC LIMIT 12");
$smartPickSuggestions = admin_safe_fetch_all($pdo, "SELECT m.id, m.title, m.title_fa, m.imdb_code, m.type, m.year, m.imdb_rate FROM movies m LEFT JOIN admin_picks ap ON ap.movie_id = m.id WHERE ap.id IS NULL ORDER BY m.imdb_rate DESC, m.year DESC, m.id DESC LIMIT 8");
$genreStats = admin_safe_fetch_all($pdo, "SELECT genre, COUNT(*) AS total FROM (SELECT TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(genres, ',', n), ',', -1)) AS genre FROM movies CROSS JOIN (SELECT 1 n UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5) numbers WHERE genres IS NOT NULL AND genres != '') g WHERE genre IS NOT NULL AND genre != '' GROUP BY genre ORDER BY total DESC LIMIT 8");
$monthlyStats = admin_safe_fetch_all($pdo, "SELECT DATE_FORMAT(created_at, '%Y-%m') AS label, COUNT(*) AS total FROM movies WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH) GROUP BY label ORDER BY label ASC");

$recentActivity = [];
if(admin_table_exists_safe($pdo, 'admin_activity_logs')){
  $recentActivity = admin_safe_fetch_all($pdo, "SELECT admin_name, action, target_type, target_id, details, created_at FROM admin_activity_logs ORDER BY created_at DESC LIMIT 12");
}
if(!$recentActivity){
  $recentActivity = array_merge(
    array_map(fn($r)=>['admin_name'=>'system','action'=>'new_movie','target_type'=>'movie','target_id'=>$r['id'] ?? null,'details'=>($r['title_fa'] ?: $r['title'] ?? ''),'created_at'=>$r['created_at'] ?? null], admin_safe_fetch_all($pdo, "SELECT id, title, title_fa, created_at FROM movies ORDER BY id DESC LIMIT 4")),
    array_map(fn($r)=>['admin_name'=>'user','action'=>'new_request','target_type'=>'request','target_id'=>$r['id'] ?? null,'details'=>$r['title'] ?? '', 'created_at'=>$r['created_at'] ?? null], admin_safe_fetch_all($pdo, "SELECT id, title, created_at FROM movie_requests ORDER BY id DESC LIMIT 4")),
    array_map(fn($r)=>['admin_name'=>'user','action'=>'new_comment','target_type'=>'comment','target_id'=>$r['id'] ?? null,'details'=>admin_text_cut((string)($r['comment'] ?? ''),80), 'created_at'=>$r['created_at'] ?? null], admin_safe_fetch_all($pdo, "SELECT id, comment, created_at FROM comments ORDER BY id DESC LIMIT 4"))
  );
  usort($recentActivity, fn($a,$b)=>strcmp((string)($b['created_at'] ?? ''), (string)($a['created_at'] ?? '')));
  $recentActivity = array_slice($recentActivity, 0, 12);
}

$userIdColumn = admin_column_exists_safe($pdo, 'users', 'id') ? 'id' : (admin_column_exists_safe($pdo, 'users', 'user_id') ? 'user_id' : 'id');
$userColumns = [$userIdColumn];
$userHasPasswordColumn = admin_column_exists_safe($pdo, 'users', 'password');
foreach(['username','name','display_name','email','avatar','created_at','last_login','last_login_at','status','is_banned','role','vip_expires_at','admin_badge_color'] as $col){ if(admin_column_exists_safe($pdo, 'users', $col)) $userColumns[] = $col; }
$userColumns = array_values(array_unique($userColumns));
$userStatusColumn = in_array('status', $userColumns, true) ? 'status' : (in_array('is_banned', $userColumns, true) ? 'is_banned' : '');
$userSearch = trim((string)($_GET['user_q'] ?? ''));
$userPage = max(1, (int)($_GET['user_page'] ?? 1));
$usersPerPage = 20;
$userOffset = ($userPage - 1) * $usersPerPage;
$userWhere = '1=1'; $userParams = [];
$userSearchCols = array_values(array_intersect(['username','name','display_name','email'], $userColumns));
if($userSearch !== '' && $userSearchCols){
  $parts = [];
  foreach($userSearchCols as $sc){ $parts[] = '`' . $sc . '` LIKE ?'; $userParams[] = '%' . $userSearch . '%'; }
  $userWhere = '(' . implode(' OR ', $parts) . ')';
}
$totalUsersFiltered = admin_table_exists_safe($pdo, 'users') ? admin_safe_count($pdo, 'SELECT COUNT(*) FROM users WHERE ' . $userWhere, $userParams) : 0;
$totalUserPages = max(1, (int)ceil(max(1, $totalUsersFiltered) / $usersPerPage));
if($userPage > $totalUserPages){ $userPage = $totalUserPages; $userOffset = ($userPage - 1) * $usersPerPage; }
$usersList = [];
if(admin_table_exists_safe($pdo, 'users')){
  try {
    $sql = 'SELECT ' . implode(',', array_map(fn($c)=>'`'.$c.'`', $userColumns)) . ' FROM users WHERE ' . $userWhere . ' ORDER BY `' . $userIdColumn . '` DESC LIMIT ? OFFSET ?';
    $stmt = $pdo->prepare($sql);
    $i=1;
    foreach($userParams as $param){ $stmt->bindValue($i++, $param, PDO::PARAM_STR); }
    $stmt->bindValue($i++, $usersPerPage, PDO::PARAM_INT);
    $stmt->bindValue($i++, $userOffset, PDO::PARAM_INT);
    $stmt->execute();
    $usersList = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
  } catch(Throwable $e){ $usersList = []; }
}
$activeBanners = admin_table_exists_safe($pdo, 'admin_banners') ? admin_safe_fetch_all($pdo, "SELECT * FROM admin_banners ORDER BY is_active DESC, id DESC LIMIT 30") : [];
$quickReplies = admin_table_exists_safe($pdo, 'admin_quick_replies') ? admin_safe_fetch_all($pdo, "SELECT * FROM admin_quick_replies ORDER BY is_active DESC, id DESC LIMIT 30") : [];
$activeQuickReplies = array_values(array_filter($quickReplies, fn($r)=> (int)($r['is_active'] ?? 0) === 1));
$trashItems = admin_table_exists_safe($pdo, 'admin_recycle_bin') ? admin_safe_fetch_all($pdo, "SELECT * FROM admin_recycle_bin ORDER BY restored_at IS NULL DESC, created_at DESC LIMIT 30") : [];

$attentionMoviesRaw = admin_safe_fetch_all($pdo, "SELECT m.id, m.title, m.title_fa, m.imdb_code, m.year, m.type, m.imdb_rate, m.description, m.genres, COALESCE(lc.link_count,0) AS link_count FROM movies m LEFT JOIN ($linkCountSubSql) lc ON lc.movie_id = m.id ORDER BY m.id DESC LIMIT 250");
$attentionMovies = [];
foreach($attentionMoviesRaw as $am){
  $reasons = [];
  $posterKey = trim((string)($am['imdb_code'] ?? '')) !== '' ? $am['imdb_code'] : $am['id'];
  if(!is_file(__DIR__ . '/posters/' . $posterKey . '.webp')) $reasons[] = 'بدون کاور';
  if((int)($am['link_count'] ?? 0) === 0) $reasons[] = 'بدون لینک';
  if(trim((string)($am['description'] ?? '')) === '') $reasons[] = 'بدون توضیح';
  if(trim((string)($am['genres'] ?? '')) === '') $reasons[] = 'بدون ژانر';
  if(trim((string)($am['imdb_code'] ?? '')) === '') $reasons[] = 'بدون IMDb';
  if(trim((string)($am['title_fa'] ?? '')) === '') $reasons[] = 'عنوان فارسی ندارد';
  if((float)($am['imdb_rate'] ?? 0) > 0 && (float)($am['imdb_rate'] ?? 0) < 5) $reasons[] = 'امتیاز پایین';
  if($reasons){ $am['attention_reasons'] = $reasons; $attentionMovies[] = $am; }
  if(count($attentionMovies) >= 20) break;
}
$weekMovies = admin_safe_count($pdo, "SELECT COUNT(*) FROM movies WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
$weekApprovedComments = admin_safe_count($pdo, "SELECT COUNT(*) FROM comments WHERE status='approved' AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
$weekRequestsAnswered = admin_safe_count($pdo, "SELECT COUNT(*) FROM movie_requests WHERE LOWER(TRIM(CAST(status AS CHAR))) IN ('approved','answered','accepted','done','completed','1') AND updated_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
$weekRequestsNew = admin_safe_count($pdo, "SELECT COUNT(*) FROM movie_requests WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
$weekUsers = admin_column_exists_safe($pdo, 'users', 'created_at') ? admin_safe_count($pdo, "SELECT COUNT(*) FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)") : 0;
$weekActivity = admin_table_exists_safe($pdo, 'admin_activity_logs') ? admin_safe_count($pdo, "SELECT COUNT(*) FROM admin_activity_logs WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)") : 0;
$omdbReady = $adminOmdbKey !== '';
admin_prune_site_error_logs(86400); // keep diagnostic rows for at most 24 hours
$siteErrorSnapshot = admin_build_site_error_snapshot();

$adminPanelUser = admin_current_user() ?: [];
$adminPanelIsOwner = bm_admin_role_is_owner($adminPanelUser);
$adminPanelName = trim((string)($adminPanelUser['display_name'] ?? $adminPanelUser['name'] ?? $adminPanelUser['username'] ?? 'مدیر BankMovie'));
if($adminPanelName === '') $adminPanelName = 'مدیر BankMovie';
$adminPanelRoleLabel = $adminPanelIsOwner ? 'مدیر اصلی' : 'تیم مدیریت';
$adminPanelAvatar = trim(str_replace('\\','/',(string)($adminPanelUser['avatar'] ?? '')));
if($adminPanelAvatar !== '' && !preg_match('~^https?://~i',$adminPanelAvatar)){
  $candidate = ltrim($adminPanelAvatar,'/');
  if(strpos($candidate,'..') !== false) $adminPanelAvatar='';
  elseif(is_file(__DIR__.'/'.$candidate)) $adminPanelAvatar='/'.$candidate;
  elseif(is_file(__DIR__.'/uploads/avatars/'.basename($candidate))) $adminPanelAvatar='/uploads/avatars/'.basename($candidate);
  else $adminPanelAvatar='';
}

// Prepare data for charts
$chartData = [
  'films' => $totalFilms,
  'series' => $totalSeries,
  'comments' => $totalComments,
  'pending' => $totalPendingComments,
  'users' => $totalUsers,
  'picks' => $totalAdminPicks
];
?>
<?php
$vipCapabilityCatalog = bm_vip_feature_catalog();
$vipCapabilitySettings = bm_vip_feature_settings();
$vipSalesSettings = bm_vip_sales_settings();
$vipEnabledBenefits = 0;
$vipPreparedGates = 0;
foreach ($vipCapabilityCatalog as $vipKey => $vipMeta) {
  $vipOn = !empty($vipCapabilitySettings['features'][$vipKey]);
  if (($vipMeta['group'] ?? '') === 'benefit' && $vipOn) $vipEnabledBenefits++;
  if (($vipMeta['group'] ?? '') === 'gate') $vipPreparedGates++;
}
$vipActiveUsers = 0;
try {
  if (bm_watch_party_column_exists($pdo, 'users', 'vip_expires_at')) {
    $vipActiveUsers = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE LOWER(role) IN ('vip','premium','special') AND (vip_expires_at IS NULL OR vip_expires_at>NOW())")->fetchColumn();
  } else {
    $vipActiveUsers = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE LOWER(role) IN ('vip','premium','special')")->fetchColumn();
  }
} catch(Throwable $e) { $vipActiveUsers = 0; }
$vipWatchPartyStats = ['rooms'=>0,'members'=>0,'messages'=>0];
$vipWatchPartySchema = bm_watch_party_schema_report($pdo);
if (!empty($vipWatchPartySchema['ready'])) {
  $vipWatchPartyStats['rooms'] = admin_safe_count($pdo, "SELECT COUNT(*) FROM watch_party_rooms WHERE (expires_at_epoch>UNIX_TIMESTAMP()) OR (expires_at_epoch=0 AND expires_at>NOW())");
  $vipWatchPartyStats['members'] = admin_safe_count($pdo, "SELECT COUNT(*) FROM watch_party_members");
  $vipWatchPartyStats['messages'] = admin_safe_count($pdo, "SELECT COUNT(*) FROM watch_party_messages");
}
$vipGiftEvents = bm_vip_gift_recent_events($pdo, 8);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>پنل مدیریت حرفه‌ای | BankMovie</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<!-- Chart.js از روت سایت برای سرعت بیشتر (در صورت وجود فایل محلی) -->
<script src="/assets/vendor/chart.js" onerror="window.__bmLocalChartFailed=true"></script>
<script>
(function(){
  function loadChartFallback(){
    if(typeof Chart !== 'undefined' || document.getElementById('bmChartFallback')) return;
    var script = document.createElement('script');
    script.id = 'bmChartFallback';
    script.src = 'https://cdn.jsdelivr.net/npm/assets/vendor/chart.js@4.4.0/dist/chart.umd.min.js';
    script.onload = function(){ if(typeof initCharts === 'function') initCharts(); };
    document.head.appendChild(script);
  }
  if(typeof Chart === 'undefined') setTimeout(loadChartFallback, 120);
  window.addEventListener('load', function(){ if(typeof Chart === 'undefined') loadChartFallback(); });
})();
</script>
<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

:root {
  --bg-primary: #0a0c12;
  --bg-secondary: #0f111a;
  --surface: rgba(18, 22, 35, 0.75);
  --surface-hover: rgba(25, 30, 45, 0.85);
  --border: rgba(66, 78, 110, 0.25);
  --border-glow: rgba(0, 255, 163, 0.5);
  --text-primary: #f0f3fa;
  --text-secondary: #9aa2bf;
  --accent: #00ffa3;
  --accent-dark: #00cc82;
  --accent-glow: 0 0 20px rgba(0, 255, 163, 0.4);
  --danger: #ff4d6d;
  --warning: #ffb347;
  --info: #4d9eff;
  --radius-sm: 12px;
  --radius-md: 18px;
  --radius-lg: 24px;
  --transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

body {
  background: var(--bg-primary);
  color: var(--text-primary);
  font-family: 'Vazirmatn', sans-serif;
  overflow-x: hidden;
  min-height: 100vh;
  position: relative;
}

/* Animated gradient background */
body::before {
  content: '';
  position: fixed;
  top: -30%;
  right: -20%;
  width: 80%;
  height: 80%;
  background: radial-gradient(circle, rgba(0, 255, 163, 0.08) 0%, transparent 70%);
  pointer-events: none;
  z-index: 0;
  animation: float 20s infinite alternate;
}

body::after {
  content: '';
  position: fixed;
  bottom: -20%;
  left: -10%;
  width: 70%;
  height: 70%;
  background: radial-gradient(circle, rgba(77, 158, 255, 0.06) 0%, transparent 70%);
  pointer-events: none;
  z-index: 0;
  animation: float 25s infinite alternate-reverse;
}

@keyframes float {
  0% { transform: translate(0, 0) scale(1); opacity: 0.5; }
  100% { transform: translate(30px, -30px) scale(1.2); opacity: 0.8; }
}

/* ========== SIDEBAR (Premium) ========== */
.sidebar {
  position: fixed;
  right: 0;
  top: 0;
  width: 280px;
  height: 100vh;
  background: rgba(8, 10, 18, 0.96);
  backdrop-filter: blur(20px);
  border-left: 1px solid var(--border-glow);
  z-index: 100;
  padding: 32px 20px;
  overflow-y: auto;
  transition: var(--transition);
  box-shadow: -10px 0 40px rgba(0, 0, 0, 0.5);
}

.sidebar::-webkit-scrollbar {
  width: 4px;
}

.sidebar::-webkit-scrollbar-track {
  background: transparent;
}

.sidebar::-webkit-scrollbar-thumb {
  background: var(--accent);
  border-radius: 10px;
}

.sidebar-logo {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 40px;
  padding-bottom: 24px;
  border-bottom: 1px solid var(--border);
}

.sidebar-logo i {
  font-size: 32px;
  color: var(--accent);
  filter: drop-shadow(0 0 8px var(--accent));
  animation: pulse 2s infinite;
}

@keyframes pulse {
  0% { filter: drop-shadow(0 0 0px var(--accent)); }
  50% { filter: drop-shadow(0 0 12px var(--accent)); }
  100% { filter: drop-shadow(0 0 0px var(--accent)); }
}

.sidebar-logo h2 {
  font-size: 22px;
  font-weight: 800;
  background: linear-gradient(135deg, var(--accent), var(--info));
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
}

.sidebar-nav {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 40px;
}

.sidebar-nav a {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 12px 18px;
  border-radius: var(--radius-sm);
  color: var(--text-secondary);
  text-decoration: none;
  font-weight: 500;
  font-size: 14px;
  transition: var(--transition);
  border: 1px solid transparent;
  position: relative;
  overflow: hidden;
}

.sidebar-nav a::before {
  content: '';
  position: absolute;
  top: 0;
  right: 0;
  width: 0;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(0, 255, 163, 0.1));
  transition: width 0.3s;
  z-index: -1;
}

.sidebar-nav a:hover::before {
  width: 100%;
}

.sidebar-nav a:hover {
  background: rgba(0, 255, 163, 0.08);
  color: var(--accent);
  border-color: var(--border-glow);
  transform: translateX(-4px);
}

.sidebar-nav a.active {
  background: linear-gradient(90deg, rgba(0, 255, 163, 0.15), transparent);
  color: var(--accent);
  border-right: 2px solid var(--accent);
  box-shadow: -4px 0 10px rgba(0, 255, 163, 0.1);
}

.sidebar-footer {
  position: absolute;
  bottom: 30px;
  right: 20px;
  left: 20px;
  padding-top: 20px;
  border-top: 1px solid var(--border);
}

.logout-btn {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 18px;
  border-radius: var(--radius-sm);
  background: rgba(255, 77, 109, 0.1);
  color: var(--danger);
  text-decoration: none;
  font-weight: 600;
  transition: var(--transition);
}

.logout-btn:hover {
  background: rgba(255, 77, 109, 0.2);
  transform: translateX(-4px);
  box-shadow: 0 0 12px rgba(255, 77, 109, 0.3);
}

/* ========== MAIN CONTENT ========== */
.main-content {
  margin-right: 280px;
  padding: 28px 32px;
  position: relative;
  z-index: 1;
  min-height: 100vh;
  animation: fadeInUp 0.6s ease-out;
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* ========== STATS & CHARTS ========== */
.stats-charts-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 24px;
  margin-bottom: 32px;
}

.chart-card {
  background: var(--surface);
  backdrop-filter: blur(12px);
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  padding: 20px;
  transition: var(--transition);
  position: relative;
  overflow: hidden;
}

.chart-card::after {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 2px;
  background: linear-gradient(90deg, transparent, var(--accent), transparent);
  opacity: 0;
  transition: opacity 0.3s;
}

.chart-card:hover::after {
  opacity: 1;
}

.chart-card:hover {
  border-color: var(--border-glow);
  box-shadow: 0 20px 40px -15px rgba(0, 0, 0, 0.6);
  transform: translateY(-3px);
}

.chart-card h4 {
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 16px;
  color: var(--accent);
  display: flex;
  align-items: center;
  gap: 8px;
}

.chart-container {
  position: relative;
  height: 260px;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: 20px;
  margin-bottom: 32px;
}

.stat-card {
  background: var(--surface);
  backdrop-filter: blur(12px);
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  padding: 20px 16px;
  transition: var(--transition);
  position: relative;
  overflow: hidden;
  text-align: center;
  cursor: pointer;
}

.stat-card::before {
  content: '';
  position: absolute;
  top: 0;
  right: 0;
  width: 4px;
  height: 100%;
  background: linear-gradient(180deg, var(--accent), var(--accent-dark));
  opacity: 0;
  transition: var(--transition);
}

.stat-card:hover {
  transform: translateY(-6px);
  border-color: var(--border-glow);
  box-shadow: 0 20px 35px -15px rgba(0, 255, 163, 0.2);
}

.stat-card:hover::before {
  opacity: 1;
}

.stat-icon {
  font-size: 32px;
  color: var(--accent);
  margin-bottom: 12px;
  transition: transform 0.2s;
}

.stat-card:hover .stat-icon {
  transform: scale(1.1);
  filter: drop-shadow(0 0 6px var(--accent));
}

.stat-number {
  font-size: 32px;
  font-weight: 800;
  background: linear-gradient(135deg, var(--text-primary), var(--accent));
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  line-height: 1.2;
  margin-bottom: 6px;
}

.stat-label {
  font-size: 13px;
  color: var(--text-secondary);
  font-weight: 500;
}

/* ========== CARDS (Glass Premium) ========== */
.glass-card {
  background: var(--surface);
  backdrop-filter: blur(16px);
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  margin-bottom: 28px;
  overflow: hidden;
  transition: var(--transition);
  position: relative;
}

.glass-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 1px;
  background: linear-gradient(90deg, transparent, var(--accent), transparent);
  opacity: 0;
  transition: opacity 0.3s;
}

.glass-card:hover::before {
  opacity: 1;
}

.glass-card:hover {
  border-color: var(--border-glow);
  box-shadow: 0 15px 35px -12px rgba(0, 0, 0, 0.5);
  transform: translateY(-2px);
}

.card-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px 28px;
  border-bottom: 1px solid var(--border);
  flex-wrap: wrap;
  gap: 12px;
}

.card-header h3 {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: 18px;
  font-weight: 700;
}

.card-header h3 i {
  color: var(--accent);
  font-size: 22px;
  text-shadow: 0 0 4px var(--accent);
}

.card-body {
  padding: 24px 28px;
}

/* ========== BUTTONS (Premium) ========== */
.btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 10px 22px;
  border-radius: 50px;
  font-size: 13px;
  font-weight: 700;
  font-family: 'Vazirmatn', sans-serif;
  border: none;
  cursor: pointer;
  transition: var(--transition);
  text-decoration: none;
  position: relative;
  overflow: hidden;
}

.btn::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  width: 0;
  height: 0;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 50%;
  transform: translate(-50%, -50%);
  transition: width 0.5s, height 0.5s;
}

.btn:active::after {
  width: 200px;
  height: 200px;
  opacity: 0;
}

.btn-primary {
  background: linear-gradient(135deg, var(--accent), var(--accent-dark));
  color: #061a10;
  box-shadow: 0 4px 12px rgba(0, 255, 163, 0.3);
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(0, 255, 163, 0.4);
}

.btn-outline {
  background: transparent;
  border: 1px solid var(--border);
  color: var(--text-primary);
}

.btn-outline:hover {
  background: rgba(0, 255, 163, 0.1);
  border-color: var(--accent);
  color: var(--accent);
  box-shadow: 0 0 12px rgba(0, 255, 163, 0.2);
}

.btn-danger {
  background: rgba(255, 77, 109, 0.15);
  border: 1px solid rgba(255, 77, 109, 0.3);
  color: var(--danger);
}

.btn-danger:hover {
  background: rgba(255, 77, 109, 0.3);
  transform: translateY(-2px);
  box-shadow: 0 0 12px rgba(255, 77, 109, 0.3);
}

.btn-sm {
  padding: 6px 14px;
  font-size: 12px;
}

/* ========== FORM ELEMENTS ========== */
.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  font-size: 12px;
  font-weight: 600;
  color: var(--text-secondary);
  margin-bottom: 8px;
}

input, select, textarea {
  width: 100%;
  padding: 12px 16px;
  background: rgba(5, 8, 18, 0.7);
  border: 1px solid var(--border);
  border-radius: var(--radius-sm);
  color: var(--text-primary);
  font-size: 14px;
  font-family: 'Vazirmatn', sans-serif;
  transition: var(--transition);
}

input:focus, select:focus, textarea:focus {
  outline: none;
  border-color: var(--accent);
  box-shadow: 0 0 0 3px rgba(0, 255, 163, 0.15);
}

.form-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 20px;
}

/* ========== CHECKLIST ========== */
.filter-input {
  width: 100%;
  padding: 10px 14px;
  background: rgba(5, 8, 18, 0.7);
  border: 1px solid var(--border);
  border-radius: 10px;
  color: var(--text-primary);
  margin-bottom: 12px;
}

.checklist {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
  gap: 8px;
  max-height: 220px;
  overflow-y: auto;
  padding: 12px;
  background: rgba(0, 0, 0, 0.2);
  border-radius: var(--radius-sm);
}

.checklist::-webkit-scrollbar {
  width: 4px;
}

.checklist::-webkit-scrollbar-thumb {
  background: var(--accent);
  border-radius: 10px;
}

.check-item {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  padding: 6px 10px;
  border-radius: 8px;
  cursor: pointer;
  transition: var(--transition);
}

.check-item:hover {
  background: rgba(0, 255, 163, 0.08);
}

.check-item input[type="checkbox"] {
  width: 16px;
  height: 16px;
  accent-color: var(--accent);
}

/* ========== MOVIE LIST ========== */
.movie-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
  max-height: 620px;
  overflow-y: auto;
  padding: 4px;
}

.movie-row {
  display: flex;
  align-items: center;
  gap: 16px;
  background: rgba(5, 8, 14, 0.6);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  padding: 14px 20px;
  transition: var(--transition);
}

.movie-row:hover {
  border-color: var(--border-glow);
  background: rgba(0, 255, 163, 0.03);
  transform: translateX(-4px);
}

.movie-poster {
  width: 48px;
  height: 68px;
  border-radius: 10px;
  object-fit: cover;
  background: rgba(255, 255, 255, 0.05);
  flex-shrink: 0;
}

.movie-info {
  flex: 1;
}

.movie-name {
  font-size: 15px;
  font-weight: 700;
  margin-bottom: 6px;
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

.movie-meta {
  font-size: 12px;
  color: var(--text-secondary);
  display: flex;
  gap: 16px;
}

/* ========== BADGES ========== */
.badge {
  display: inline-flex;
  align-items: center;
  padding: 4px 12px;
  border-radius: 50px;
  font-size: 11px;
  font-weight: 700;
  backdrop-filter: blur(4px);
}

.badge-success {
  background: rgba(0, 255, 163, 0.2);
  color: var(--accent);
  border: 1px solid rgba(0, 255, 163, 0.3);
}

.badge-warning {
  background: rgba(255, 179, 71, 0.2);
  color: var(--warning);
  border: 1px solid rgba(255, 179, 71, 0.3);
}

.badge-danger {
  background: rgba(255, 77, 109, 0.2);
  color: var(--danger);
  border: 1px solid rgba(255, 77, 109, 0.3);
}

.badge-info {
  background: rgba(77, 158, 255, 0.2);
  color: var(--info);
  border: 1px solid rgba(77, 158, 255, 0.3);
}

.badge-gray {
  background: rgba(255, 255, 255, 0.08);
  color: var(--text-secondary);
  border: 1px solid var(--border);
}

/* ========== TABLES ========== */
.table-wrapper {
  overflow-x: auto;
  border-radius: var(--radius-md);
}

.data-table {
  width: 100%;
  border-collapse: collapse;
}

.data-table th {
  text-align: right;
  padding: 14px 16px;
  font-size: 12px;
  font-weight: 600;
  color: var(--text-secondary);
  border-bottom: 1px solid var(--border);
  background: rgba(0, 0, 0, 0.2);
}

.data-table td {
  padding: 14px 16px;
  font-size: 13px;
  border-bottom: 1px solid var(--border);
  vertical-align: middle;
}

.data-table tr:hover td {
  background: rgba(0, 255, 163, 0.03);
}

/* Avatar in comments */
.user-avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  object-fit: cover;
  background: rgba(255,255,255,0.1);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: 1px solid var(--border-glow);
}

/* ========== PAGINATION ========== */
.pagination {
  display: flex;
  justify-content: center;
  gap: 8px;
  margin-top: 24px;
  flex-wrap: wrap;
}

.pagination a {
  padding: 8px 16px;
  border-radius: 50px;
  font-size: 13px;
  text-decoration: none;
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid var(--border);
  color: var(--text-primary);
  transition: var(--transition);
  min-width: 40px;
  text-align: center;
}

.pagination a:hover, .pagination a.active {
  background: var(--accent);
  color: #061a10;
  border-color: transparent;
  box-shadow: 0 0 12px var(--accent);
}

/* ========== TABS ========== */
.tabs {
  display: flex;
  gap: 10px;
  margin-bottom: 24px;
  flex-wrap: wrap;
}

.tab {
  padding: 8px 24px;
  border-radius: 50px;
  font-size: 13px;
  font-weight: 600;
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid var(--border);
  color: var(--text-secondary);
  text-decoration: none;
  transition: var(--transition);
}

.tab.active, .tab:hover {
  background: var(--accent);
  color: #061a10;
  border-color: transparent;
  box-shadow: 0 0 10px var(--accent);
}

/* ========== SEARCH ========== */
.search-wrapper {
  position: relative;
  margin-bottom: 20px;
}

.search-wrapper i {
  position: absolute;
  right: 16px;
  top: 50%;
  transform: translateY(-50%);
  color: var(--text-secondary);
  font-size: 16px;
}

.search-wrapper input {
  padding-right: 45px;
  background: rgba(5, 8, 18, 0.8);
  border-radius: 50px;
}

.live-results {
  position: absolute;
  top: calc(100% + 8px);
  left: 0;
  right: 0;
  background: rgba(8, 12, 20, 0.98);
  backdrop-filter: blur(16px);
  border: 1px solid var(--border-glow);
  border-radius: var(--radius-md);
  z-index: 100;
  display: none;
  overflow: hidden;
  box-shadow: 0 20px 40px rgba(0,0,0,0.4);
}

.live-item {
  padding: 12px 16px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  cursor: pointer;
  transition: var(--transition);
  border-bottom: 1px solid var(--border);
}

.live-item:hover {
  background: rgba(0, 255, 163, 0.08);
}

/* ========== TOAST ========== */
.toast {
  position: fixed;
  top: 24px;
  left: 50%;
  transform: translateX(-50%);
  background: rgba(10, 15, 25, 0.95);
  backdrop-filter: blur(12px);
  border: 1px solid var(--accent);
  border-radius: 50px;
  padding: 12px 28px;
  display: flex;
  align-items: center;
  gap: 12px;
  font-weight: 600;
  color: var(--accent);
  z-index: 1000;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
  animation: slideDown 0.3s ease;
}

@keyframes slideDown {
  from {
    opacity: 0;
    transform: translateX(-50%) translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateX(-50%) translateY(0);
  }
}

/* ========== MODAL ========== */
.modal {
  display: none;
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.8);
  backdrop-filter: blur(12px);
  z-index: 1000;
  align-items: center;
  justify-content: center;
  padding: 20px;
}

.modal.open {
  display: flex;
}

.modal-content {
  background: linear-gradient(145deg, rgba(18, 22, 35, 0.98), rgba(8, 12, 20, 0.98));
  border: 1px solid var(--border-glow);
  border-radius: var(--radius-lg);
  padding: 28px;
  max-width: 550px;
  width: 100%;
  max-height: 90vh;
  overflow-y: auto;
  animation: fadeInScale 0.3s ease;
}

@keyframes fadeInScale {
  from {
    opacity: 0;
    transform: scale(0.95);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

/* ========== DRAG & DROP ========== */
.pick-item, .story-item {
  display: flex;
  align-items: center;
  gap: 16px;
  background: rgba(5, 8, 14, 0.6);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  padding: 12px 18px;
  margin-bottom: 10px;
  transition: var(--transition);
}
.story-item {
  padding: 10px 16px;
}
.drag-handle {
  cursor: grab;
  color: var(--text-secondary);
  font-size: 20px;
  padding: 0 8px;
  transition: color 0.2s;
}
.drag-handle:hover {
  color: var(--accent);
}
.story-thumb {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  object-fit: cover;
  background: rgba(0,0,0,0.3);
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  border: 1px solid var(--border);
}
.story-thumb video, .story-thumb img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.story-info {
  flex: 1;
}


/* ========== Added Professional Modules ========== */
.attention-grid,.user-grid-pro,.weekly-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:14px}.attention-card,.user-card-pro,.weekly-card,.pro-form-box,.banner-item,.quick-reply-item,.trash-item{background:rgba(5,8,18,.48);border:1px solid var(--border);border-radius:20px;padding:16px;transition:var(--transition)}.attention-card:hover,.user-card-pro:hover,.banner-item:hover,.quick-reply-item:hover,.trash-item:hover{border-color:var(--border-glow);transform:translateY(-2px)}.attention-title strong{display:block;font-size:14px}.attention-title small,.banner-info small,.trash-item small,.user-card-head small{display:block;color:var(--text-secondary);font-size:12px;margin-top:5px}.attention-reasons{display:flex;gap:6px;flex-wrap:wrap;margin:12px 0}.attention-actions,.user-card-actions,.banner-actions{display:flex;gap:8px;flex-wrap:wrap}.banner-list,.quick-reply-list,.trash-list{display:flex;flex-direction:column;gap:12px}.banner-item{display:grid;grid-template-columns:170px 1fr auto;gap:16px;align-items:center}.banner-preview{height:88px;border-radius:16px;background:rgba(255,255,255,.06);display:flex;align-items:center;justify-content:center;overflow:hidden;border:1px solid var(--border)}.banner-preview img{width:100%;height:100%;object-fit:cover}.banner-info strong{display:block}.switch-line{display:inline-flex;align-items:center;gap:8px;margin:0 0 16px;color:var(--text-secondary)}.bm-ad-admin-intro{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:18px;padding:14px 16px;border:1px solid rgba(var(--accent-rgb),.22);border-radius:18px;background:linear-gradient(135deg,rgba(var(--accent-rgb),.10),rgba(255,255,255,.025))}.bm-ad-admin-intro strong{display:block;font-size:14px}.bm-ad-admin-intro span{display:block;color:var(--text-secondary);font-size:12px;margin-top:5px;line-height:1.7}.bm-banner-pro-grid{grid-template-columns:repeat(3,minmax(0,1fr))}.bm-banner-css-field{grid-column:1/-1}.bm-banner-css-field textarea{min-height:150px;font-family:ui-monospace,SFMono-Regular,Consolas,monospace;direction:ltr;text-align:left;line-height:1.65}.bm-banner-switches{display:flex;gap:14px;align-items:center;flex-wrap:wrap;margin-top:16px;padding:12px 14px;border:1px solid var(--border);border-radius:16px;background:rgba(0,0,0,.12)}.bm-banner-switches .switch-line{margin:0}.form-group small{display:block;color:var(--text-secondary);font-size:11px;line-height:1.7;margin-top:6px}.banner-preview img{animation-play-state:running}@media(max-width:980px){.bm-banner-pro-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:700px){.bm-ad-admin-intro{align-items:stretch;flex-direction:column}.bm-banner-pro-grid{grid-template-columns:1fr}.bm-banner-css-field{grid-column:auto}.bm-banner-switches{align-items:flex-start;flex-direction:column}}.quick-reply-item{display:flex;justify-content:space-between;gap:14px;align-items:flex-start}.quick-reply-item p{color:var(--text-secondary);line-height:1.9;margin-top:6px}.user-search-bar{display:flex;gap:10px;align-items:center;margin-bottom:18px}.user-card-head{display:flex;gap:12px;align-items:center}.user-avatar.big{width:54px;height:54px;flex:0 0 54px}.user-avatar.big img{width:100%;height:100%;object-fit:cover;border-radius:50%}.user-card-meta{display:flex;gap:6px;flex-wrap:wrap;margin:14px 0}.weekly-card{text-align:center}.weekly-card i{font-size:26px;color:var(--accent);display:block;margin-bottom:10px}.weekly-card strong{font-size:30px;display:block}.weekly-card span{font-size:12px;color:var(--text-secondary)}.trash-item{display:flex;justify-content:space-between;gap:14px;align-items:center}.trash-item.is-restored{opacity:.62}.section-help{color:var(--text-secondary);line-height:1.9;margin-bottom:16px}.quick-edit-form{border:1px solid var(--border);background:rgba(0,0,0,.18);border-radius:20px;padding:16px}.kbd-help{position:fixed;left:18px;top:18px;z-index:120;background:rgba(8,10,18,.9);border:1px solid var(--border);border-radius:16px;padding:10px 14px;color:var(--text-secondary);font-size:12px;backdrop-filter:blur(10px)}.kbd-help kbd{background:rgba(255,255,255,.08);border:1px solid var(--border);border-radius:8px;padding:2px 6px;color:var(--accent)}@media(max-width:800px){.banner-item{grid-template-columns:1fr}.quick-reply-item,.trash-item,.user-search-bar{flex-direction:column;align-items:stretch}}

/* ========== RESPONSIVE ========== */
@media (max-width: 1024px) {
  .sidebar {
    transform: translateX(100%);
    width: 260px;
  }
  .sidebar.open {
    transform: translateX(0);
  }
  .main-content {
    margin-right: 0;
    padding: 20px;
  }
  .menu-toggle {
    display: block;
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 101;
    background: var(--surface);
    border: 1px solid var(--accent);
    border-radius: 12px;
    padding: 10px;
    cursor: pointer;
    backdrop-filter: blur(8px);
  }
  .stats-charts-row {
    grid-template-columns: 1fr;
    gap: 16px;
  }
}

@media (max-width: 768px) {
  .stats-grid {
    grid-template-columns: repeat(2, 1fr);
    gap: 12px;
  }
  .card-body {
    padding: 18px;
  }
  .movie-row {
    flex-wrap: wrap;
  }
}

@media (max-width: 480px) {
  .stats-grid {
    grid-template-columns: repeat(2, 1fr);
  }
  .stat-number {
    font-size: 24px;
  }
}


/* ========== Command Center Extensions ========== */
.command-grid{display:grid;grid-template-columns:1.15fr .9fr 1.15fr;gap:24px;margin-bottom:32px;align-items:stretch;}
.command-card{height:100%;margin-bottom:0;}
.compact-body{padding:18px 22px;}
.alert-row{display:grid;grid-template-columns:30px 1fr auto;align-items:center;gap:12px;padding:12px 14px;border:1px solid var(--border);border-radius:16px;text-decoration:none;color:var(--text-primary);background:rgba(5,8,18,.48);margin-bottom:10px;transition:var(--transition);}
.alert-row:hover{border-color:var(--accent);transform:translateX(-4px);background:rgba(0,255,163,.07);}
.alert-row i{color:var(--accent);font-size:16px}.alert-row strong{font-size:18px;color:var(--accent)}
.pulse-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:16px;}
.pulse-item{border:1px solid var(--border);border-radius:18px;padding:16px;text-align:center;background:linear-gradient(145deg,rgba(255,255,255,.05),rgba(255,255,255,.015));}
.pulse-item span{display:block;font-size:28px;font-weight:900;background:linear-gradient(135deg,var(--text-primary),var(--accent));-webkit-background-clip:text;background-clip:text;color:transparent}.pulse-item small{color:var(--text-secondary)}
.quick-actions-row{display:flex;gap:10px;flex-wrap:wrap}.mini-timeline{display:flex;flex-direction:column;gap:12px}.timeline-item-mini{display:flex;gap:12px;align-items:flex-start}.timeline-dot{width:12px;height:12px;border-radius:50%;background:var(--accent);box-shadow:0 0 14px var(--accent);margin-top:7px;flex:0 0 auto}.timeline-item-mini strong{display:block;font-size:13px}.timeline-item-mini small{display:block;color:var(--text-secondary);font-size:11px;margin-top:4px;line-height:1.7}
.health-overview{display:grid;grid-template-columns:220px 1fr;gap:24px;align-items:center;margin-bottom:24px}.health-score{width:190px;height:190px;border-radius:50%;margin:auto;display:flex;flex-direction:column;align-items:center;justify-content:center;background:conic-gradient(var(--accent) calc(var(--score)*1%),rgba(255,255,255,.08) 0);position:relative;box-shadow:0 0 40px rgba(0,255,163,.15)}.health-score:before{content:"";position:absolute;inset:16px;border-radius:50%;background:linear-gradient(145deg,rgba(18,22,35,.98),rgba(8,12,20,.98));border:1px solid var(--border)}.health-score span,.health-score small{position:relative;z-index:1}.health-score span{font-size:42px;font-weight:900;color:var(--accent)}.health-score small{font-size:12px;color:var(--text-secondary)}

.archive-api-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.archive-api-card{border:1px solid var(--border);background:rgba(5,8,18,.55);border-radius:22px;padding:16px}.archive-api-card h3{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:0 0 12px;color:var(--accent)}.archive-api-fields{display:grid;grid-template-columns:1fr 170px;gap:12px}.archive-api-fields textarea{min-height:92px;font-family:ui-monospace,monospace;direction:ltr;text-align:left}.switch-line{display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin:10px 0}.cookie-status{font-size:12px;color:var(--text-secondary);line-height:1.8;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:14px;padding:10px;margin-top:10px}.archive-api-note{border-radius:18px;border:1px solid rgba(0,255,163,.22);background:rgba(0,255,163,.07);padding:13px 15px;color:var(--text-secondary);line-height:1.9;margin-bottom:16px}.archive-api-note strong{color:var(--accent)}@media(max-width:900px){.archive-api-grid{grid-template-columns:1fr}.archive-api-fields{grid-template-columns:1fr}}

.health-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}.health-card{padding:16px;border-radius:18px;border:1px solid var(--border);background:rgba(5,8,18,.55);display:flex;align-items:center;gap:12px;transition:var(--transition)}.health-card:hover{border-color:var(--accent);transform:translateY(-3px)}.health-card i{width:38px;height:38px;border-radius:14px;display:flex;align-items:center;justify-content:center;background:rgba(0,255,163,.1);color:var(--accent)}.health-card strong{font-size:24px}.health-card span{color:var(--text-secondary);font-size:12px}.section-subtitle{display:flex;align-items:center;gap:8px;color:var(--accent);font-weight:800;margin:12px 0 16px}.pro-table tbody tr{transition:var(--transition)}.pro-table tbody tr:hover{transform:translateX(-2px)}
.bulk-toolbar{display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:14px;border:1px solid var(--border);border-radius:18px;background:rgba(5,8,18,.55);margin-bottom:18px}.bulk-info{display:flex;align-items:center;gap:8px;color:var(--accent);font-weight:800;margin-left:auto}.bulk-toolbar select{width:auto;min-width:190px;padding:8px 14px}.select-dot{display:flex;align-items:center;justify-content:center;cursor:pointer;flex:0 0 auto}.select-dot input{display:none}.select-dot span{width:22px;height:22px;border-radius:8px;border:1px solid var(--border);background:rgba(255,255,255,.04);position:relative;transition:var(--transition)}.select-dot input:checked+span{background:var(--accent);border-color:var(--accent);box-shadow:0 0 14px rgba(0,255,163,.35)}.select-dot input:checked+span:after{content:"✓";position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#061a10;font-weight:900;font-size:14px}.movie-actions{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}.link-url{direction:ltr;display:inline-block;max-width:320px;color:var(--text-secondary)}
.import-box,.security-card{border:1px solid var(--border);border-radius:20px;background:rgba(5,8,18,.52);padding:18px}.smart-status{margin-top:12px;padding:12px 14px;border-radius:14px;background:rgba(77,158,255,.08);border:1px solid rgba(77,158,255,.22);color:var(--text-secondary)}.suggestion-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px}.suggestion-card{display:flex;gap:14px;border:1px solid var(--border);border-radius:20px;background:rgba(5,8,18,.55);padding:14px;transition:var(--transition)}.suggestion-card:hover{border-color:var(--accent);transform:translateY(-3px)}.suggestion-poster{width:62px;height:88px;border-radius:14px;overflow:hidden;background:rgba(255,255,255,.06);display:flex;align-items:center;justify-content:center;flex:0 0 auto}.suggestion-poster img{width:100%;height:100%;object-fit:cover}.suggestion-info{display:flex;flex-direction:column;gap:8px;align-items:flex-start}.suggestion-info small{color:var(--text-secondary)}
.activity-timeline{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px}.activity-item{display:flex;gap:14px;border:1px solid var(--border);border-radius:18px;background:rgba(5,8,18,.5);padding:14px}.activity-icon{width:40px;height:40px;border-radius:16px;display:flex;align-items:center;justify-content:center;background:rgba(0,255,163,.1);color:var(--accent);flex:0 0 auto}.activity-body p{color:var(--text-secondary);font-size:12px;margin:4px 0}.activity-body small{color:var(--text-secondary)}.security-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:16px}.security-card i{font-size:28px;color:var(--accent);margin-bottom:12px}.security-card h4{margin-bottom:8px}.security-card p{color:var(--text-secondary);font-size:13px;line-height:1.9;margin-bottom:14px}
.theme-dock{position:fixed;left:18px;bottom:18px;z-index:120;display:flex;gap:8px;padding:10px;border-radius:999px;border:1px solid var(--border);background:rgba(8,10,18,.82);backdrop-filter:blur(14px);box-shadow:0 20px 40px rgba(0,0,0,.35)}.theme-chip{width:22px;height:22px;border-radius:50%;border:2px solid rgba(255,255,255,.28);cursor:pointer;background:#00ffa3;padding:0}.theme-chip.active{outline:2px solid var(--text-primary);outline-offset:2px}.theme-purple-chip{background:#a855f7}.theme-red-chip{background:#ff304f}.theme-gold-chip{background:#f7c948}body.theme-purple{--accent:#a855f7;--accent-dark:#7c3aed;--border-glow:rgba(168,85,247,.55);--accent-glow:0 0 20px rgba(168,85,247,.4)}body.theme-red{--accent:#ff304f;--accent-dark:#c81e3a;--border-glow:rgba(255,48,79,.55);--accent-glow:0 0 20px rgba(255,48,79,.4)}body.theme-gold{--accent:#f7c948;--accent-dark:#d69e2e;--border-glow:rgba(247,201,72,.55);--accent-glow:0 0 20px rgba(247,201,72,.35)}
.modal-wide{max-width:780px}.quick-movie-head{display:flex;gap:18px;align-items:flex-start}.quick-poster{width:110px;height:156px;border-radius:18px;overflow:hidden;background:rgba(255,255,255,.06);display:flex;align-items:center;justify-content:center;flex:0 0 auto;border:1px solid var(--border)}.quick-poster img{width:100%;height:100%;object-fit:cover}.quick-info h3{color:var(--accent);margin-bottom:8px}.quick-info p{color:var(--text-secondary);line-height:1.9}.quick-badges{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}.quick-description{margin-top:18px;line-height:2;color:var(--text-secondary);border:1px solid var(--border);border-radius:18px;padding:16px;background:rgba(5,8,18,.45)}.quick-actions{display:flex;gap:10px;justify-content:flex-end;margin-top:18px;flex-wrap:wrap}
.sidebar-footer{position:sticky;bottom:0;right:auto;left:auto;background:linear-gradient(180deg,transparent,rgba(8,10,18,.96) 25%);padding-top:18px;margin-top:18px}.sidebar{padding-bottom:20px}.stats-charts-row{grid-template-columns:repeat(2,minmax(0,1fr));}
@media(max-width:1200px){.command-grid{grid-template-columns:1fr}.health-overview{grid-template-columns:1fr}.health-grid{grid-template-columns:repeat(2,1fr)}}@media(max-width:700px){.health-grid,.pulse-grid{grid-template-columns:1fr}.bulk-toolbar{align-items:stretch}.bulk-toolbar>*{width:100%}.bulk-info{margin-left:0}.quick-movie-head{flex-direction:column}.theme-dock{left:12px;bottom:12px}.stats-charts-row{grid-template-columns:1fr!important}}

</style>

<style id="ultra-pro-admin-skin">
/* ==========================================================
   Ultra Professional Admin Skin - UI only
   منطق PHP/SQL دست نخورده؛ این لایه فقط ظاهر و تجربه کاربری را ارتقا می‌دهد.
   ========================================================== */
:root {
  --bg-primary: #05070d;
  --bg-secondary: #090d17;
  --surface: rgba(15, 21, 35, 0.72);
  --surface-hover: rgba(24, 33, 53, 0.86);
  --surface-strong: rgba(11, 16, 28, 0.92);
  --border: rgba(148, 163, 184, 0.14);
  --border-glow: rgba(45, 212, 191, 0.45);
  --text-primary: #f8fafc;
  --text-secondary: #a8b3cf;
  --muted: #64748b;
  --accent: #2dd4bf;
  --accent-dark: #0f766e;
  --accent-2: #8b5cf6;
  --accent-3: #38bdf8;
  --gold: #fbbf24;
  --danger: #fb7185;
  --warning: #f59e0b;
  --info: #60a5fa;
  --success: #34d399;
  --radius-sm: 14px;
  --radius-md: 20px;
  --radius-lg: 28px;
  --shadow-soft: 0 20px 60px rgba(0, 0, 0, 0.28);
  --shadow-hard: 0 30px 90px rgba(0, 0, 0, 0.55);
  --ring: 0 0 0 1px rgba(45, 212, 191, 0.2), 0 0 28px rgba(45, 212, 191, 0.16);
  --transition: 220ms cubic-bezier(.2,.8,.2,1);
}

html {
  scroll-behavior: smooth;
  scrollbar-color: rgba(45,212,191,.55) rgba(255,255,255,.04);
}

body {
  background:
    radial-gradient(circle at 82% 6%, rgba(45, 212, 191, .16), transparent 28rem),
    radial-gradient(circle at 14% 16%, rgba(139, 92, 246, .15), transparent 26rem),
    radial-gradient(circle at 34% 92%, rgba(56, 189, 248, .10), transparent 24rem),
    linear-gradient(135deg, #05070d 0%, #070a12 45%, #0a0f1d 100%);
  color: var(--text-primary);
  letter-spacing: -0.015em;
}

body::before {
  inset: 0;
  width: auto;
  height: auto;
  top: 0;
  right: 0;
  background:
    linear-gradient(rgba(255,255,255,.025) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255,255,255,.025) 1px, transparent 1px);
  background-size: 42px 42px;
  mask-image: radial-gradient(circle at center, black 0%, transparent 72%);
  opacity: .5;
  animation: gridDrift 28s linear infinite;
}

body::after {
  inset: auto -18% -30% auto;
  width: 58vw;
  height: 58vw;
  background: conic-gradient(from 120deg, rgba(45,212,191,.16), rgba(139,92,246,.13), rgba(56,189,248,.12), rgba(45,212,191,.16));
  filter: blur(72px);
  opacity: .55;
  animation: auroraSpin 24s linear infinite;
}

@keyframes gridDrift {
  from { transform: translate3d(0, 0, 0); }
  to { transform: translate3d(42px, 42px, 0); }
}

@keyframes auroraSpin {
  to { transform: rotate(360deg) scale(1.04); }
}

::selection {
  background: rgba(45, 212, 191, .35);
  color: #fff;
}

.sidebar {
  width: 292px;
  padding: 26px 18px;
  background:
    linear-gradient(180deg, rgba(9,13,24,.95), rgba(5,7,13,.92)),
    radial-gradient(circle at 40% 0%, rgba(45, 212, 191, .18), transparent 22rem);
  border-left: 1px solid rgba(45, 212, 191, .25);
  box-shadow: -24px 0 80px rgba(0,0,0,.5);
}

.sidebar::before {
  content: "";
  position: absolute;
  inset: 14px;
  border-radius: 28px;
  border: 1px solid rgba(255,255,255,.055);
  pointer-events: none;
}

.sidebar-logo {
  padding: 18px 16px 24px;
  margin-bottom: 22px;
  border-bottom: 1px solid rgba(255,255,255,.08);
  border-radius: 24px;
  background: linear-gradient(135deg, rgba(255,255,255,.06), rgba(255,255,255,.015));
}

.sidebar-logo i {
  width: 48px;
  height: 48px;
  display: inline-grid;
  place-items: center;
  border-radius: 18px;
  font-size: 24px;
  color: #03120f;
  background: linear-gradient(135deg, var(--accent), var(--accent-3));
  box-shadow: 0 16px 40px rgba(45,212,191,.25);
}

.sidebar-logo h2 {
  font-size: 25px;
  line-height: 1;
  letter-spacing: -.04em;
}

.sidebar-logo h2::after {
  content: "Admin Control";
  display: block;
  margin-top: 8px;
  font-size: 11px;
  font-weight: 600;
  letter-spacing: .08em;
  text-transform: uppercase;
  color: var(--text-secondary);
}

.sidebar-nav {
  gap: 7px;
  padding: 0 4px 92px;
}

.sidebar-nav a {
  min-height: 48px;
  padding: 13px 15px;
  border-radius: 17px;
  font-size: 13.5px;
  color: #c8d1e6;
  background: transparent;
}

.sidebar-nav a i {
  width: 22px;
  text-align: center;
  font-size: 15px;
  color: rgba(45,212,191,.85);
}

.sidebar-nav a:hover,
.sidebar-nav a.active {
  background: linear-gradient(90deg, rgba(45,212,191,.16), rgba(139,92,246,.08));
  color: #fff;
  border-color: rgba(45,212,191,.28);
  box-shadow: inset 0 0 0 1px rgba(255,255,255,.04), 0 18px 40px rgba(0,0,0,.16);
  transform: translateX(-5px);
}

.sidebar-nav a.active {
  border-right: 3px solid var(--accent);
}

.sidebar-footer {
  right: 18px;
  left: 18px;
  bottom: 18px;
  padding: 14px;
  border-radius: 22px;
  background: rgba(255,255,255,.035);
  border: 1px solid rgba(255,255,255,.08);
}

.logout-btn {
  justify-content: center;
  border-radius: 16px;
  background: linear-gradient(135deg, rgba(251,113,133,.16), rgba(251,113,133,.08));
}

.main-content {
  margin-right: 292px;
  padding: 28px clamp(18px, 2.4vw, 38px) 46px;
}

.dashboard-hero {
  position: relative;
  display: grid;
  grid-template-columns: minmax(0, 1.5fr) minmax(280px, .9fr);
  gap: 22px;
  margin-bottom: 26px;
  padding: clamp(22px, 3vw, 34px);
  border-radius: 34px;
  overflow: hidden;
  background:
    linear-gradient(135deg, rgba(15, 23, 42, .86), rgba(15, 23, 42, .52)),
    radial-gradient(circle at 12% 18%, rgba(139, 92, 246, .22), transparent 28rem),
    radial-gradient(circle at 88% 20%, rgba(45, 212, 191, .18), transparent 26rem);
  border: 1px solid rgba(255,255,255,.10);
  box-shadow: var(--shadow-soft);
  isolation: isolate;
}

.dashboard-hero::before {
  content: "";
  position: absolute;
  inset: -1px;
  background:
    linear-gradient(90deg, transparent, rgba(45,212,191,.48), transparent),
    linear-gradient(180deg, rgba(255,255,255,.10), transparent 44%);
  opacity: .26;
  pointer-events: none;
  z-index: -1;
}

.dashboard-hero::after {
  content: "";
  position: absolute;
  left: 4%;
  top: 14%;
  width: 190px;
  height: 190px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(45,212,191,.20), transparent 68%);
  filter: blur(8px);
  opacity: .75;
  pointer-events: none;
}

.hero-eyebrow {
  display: inline-flex;
  align-items: center;
  gap: 9px;
  margin-bottom: 14px;
  padding: 8px 13px;
  border-radius: 999px;
  color: #c9fff8;
  font-size: 12px;
  font-weight: 800;
  background: rgba(45,212,191,.11);
  border: 1px solid rgba(45,212,191,.22);
}

.hero-title {
  margin: 0;
  font-size: clamp(28px, 4vw, 48px);
  line-height: 1.12;
  font-weight: 950;
  letter-spacing: -.055em;
}

.hero-title span {
  background: linear-gradient(135deg, #fff, #99f6e4 45%, #bfdbfe 86%);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
}

.hero-subtitle {
  margin: 14px 0 22px;
  max-width: 760px;
  color: #bdc8df;
  font-size: 14.5px;
  line-height: 1.9;
}

.hero-actions {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
}

.hero-panel {
  align-self: stretch;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
  padding: 14px;
  border-radius: 26px;
  background: rgba(2, 6, 23, .36);
  border: 1px solid rgba(255,255,255,.08);
  backdrop-filter: blur(16px);
}

.hero-mini-card {
  min-height: 112px;
  padding: 17px;
  border-radius: 22px;
  background: linear-gradient(145deg, rgba(255,255,255,.08), rgba(255,255,255,.025));
  border: 1px solid rgba(255,255,255,.08);
  box-shadow: inset 0 1px 0 rgba(255,255,255,.06);
}

.hero-mini-card i {
  display: inline-grid;
  place-items: center;
  width: 36px;
  height: 36px;
  margin-bottom: 12px;
  border-radius: 14px;
  color: #04100e;
  background: linear-gradient(135deg, var(--accent), var(--accent-3));
}

.hero-mini-value {
  display: block;
  font-size: 24px;
  line-height: 1;
  font-weight: 950;
}

.hero-mini-label {
  display: block;
  margin-top: 7px;
  color: var(--text-secondary);
  font-size: 12px;
}

.stats-charts-row {
  grid-template-columns: minmax(0, 1.08fr) minmax(320px, .92fr);
  gap: 22px;
}

.chart-card,
.glass-card,
.stat-card {
  background:
    linear-gradient(180deg, rgba(255,255,255,.055), rgba(255,255,255,.025)),
    rgba(9, 14, 26, .66);
  border: 1px solid rgba(255,255,255,.09);
  box-shadow: 0 20px 60px rgba(0, 0, 0, .26);
  backdrop-filter: blur(18px) saturate(140%);
}

.chart-card,
.glass-card {
  border-radius: 30px;
}

.chart-card {
  padding: 22px;
}

.chart-card h4,
.card-header h3 {
  letter-spacing: -.025em;
}

.chart-card h4 {
  color: #dffefa;
}

.chart-card h4 i,
.card-header h3 i {
  display: inline-grid;
  place-items: center;
  width: 34px;
  height: 34px;
  border-radius: 14px;
  color: #04120f;
  background: linear-gradient(135deg, var(--accent), var(--accent-3));
  box-shadow: 0 14px 32px rgba(45,212,191,.18);
  text-shadow: none;
}

.chart-card:hover,
.glass-card:hover,
.stat-card:hover {
  border-color: rgba(45,212,191,.32);
  box-shadow: var(--shadow-hard), var(--ring);
  transform: translateY(-4px);
}

.stats-grid {
  grid-template-columns: repeat(auto-fit, minmax(170px, 1fr));
  gap: 16px;
}

.stat-card {
  min-height: 160px;
  display: grid;
  align-content: center;
  padding: 20px 16px;
  border-radius: 26px;
}

.stat-card::after {
  content: "";
  position: absolute;
  inset: auto -20% -48% -20%;
  height: 82px;
  background: radial-gradient(ellipse at center, rgba(45,212,191,.14), transparent 68%);
  opacity: 0;
  transition: opacity var(--transition), transform var(--transition);
}

.stat-card:hover::after {
  opacity: 1;
  transform: translateY(-12px);
}

.stat-icon {
  margin-inline: auto;
  width: 54px;
  height: 54px;
  display: grid;
  place-items: center;
  border-radius: 20px;
  background: rgba(45, 212, 191, .10);
  border: 1px solid rgba(45,212,191,.18);
  color: var(--accent);
}

.stat-number {
  margin-top: 14px;
  font-size: 34px;
  letter-spacing: -.04em;
}

.stat-label {
  margin-top: 4px;
  color: #b5bfd4;
}

.glass-card {
  margin-bottom: 24px;
}

.glass-card::before,
.chart-card::after {
  height: 1px;
  opacity: 1;
  background: linear-gradient(90deg, transparent, rgba(45,212,191,.45), rgba(139,92,246,.28), transparent);
}

.card-header {
  padding: 19px 24px;
  background: linear-gradient(90deg, rgba(255,255,255,.055), transparent);
}

.card-body {
  padding: 24px;
}

.btn {
  min-height: 42px;
  border-radius: 15px;
  font-weight: 850;
  letter-spacing: -.01em;
  box-shadow: none;
}

.btn-primary {
  background: linear-gradient(135deg, var(--accent), #5eead4 42%, var(--accent-3));
  color: #04110f;
  box-shadow: 0 16px 38px rgba(45, 212, 191, .20);
}

.btn-primary:hover {
  box-shadow: 0 20px 48px rgba(45, 212, 191, .32);
}

.btn-outline {
  background: rgba(255,255,255,.055);
  border: 1px solid rgba(255,255,255,.11);
}

.btn-outline:hover {
  background: rgba(45, 212, 191, .12);
  border-color: rgba(45,212,191,.36);
}

.btn-danger {
  background: rgba(251, 113, 133, .12);
  border-color: rgba(251, 113, 133, .25);
  color: #fecdd3;
}

.btn-danger:hover {
  color: #fff;
  background: rgba(251, 113, 133, .24);
}

.btn-sm {
  min-height: 34px;
  border-radius: 12px;
}

input,
select,
textarea,
.filter-input {
  min-height: 46px;
  background: rgba(2, 6, 23, .42);
  border: 1px solid rgba(148, 163, 184, .16);
  border-radius: 16px;
  color: #eef6ff;
  box-shadow: inset 0 1px 0 rgba(255,255,255,.035);
}

textarea {
  line-height: 1.8;
}

select option {
  background: #0b1220;
  color: #f8fafc;
}

input:hover,
select:hover,
textarea:hover {
  border-color: rgba(148, 163, 184, .28);
}

input:focus,
select:focus,
textarea:focus {
  border-color: rgba(45, 212, 191, .72);
  box-shadow: 0 0 0 4px rgba(45, 212, 191, .10), inset 0 1px 0 rgba(255,255,255,.05);
}

.form-group label {
  margin-bottom: 9px;
  color: #cdd7ec;
  font-size: 12.5px;
}

.form-grid {
  gap: 16px;
}

.search-wrapper input {
  min-height: 52px;
  border-radius: 18px;
  padding-right: 48px;
  background:
    linear-gradient(135deg, rgba(255,255,255,.055), rgba(255,255,255,.018)),
    rgba(2,6,23,.42);
}

.search-wrapper i {
  color: var(--accent);
}

.checklist {
  gap: 9px;
  max-height: 238px;
  padding: 13px;
  background: rgba(2, 6, 23, .34);
  border: 1px solid rgba(255,255,255,.06);
}

.check-item {
  min-height: 34px;
  border: 1px solid rgba(255,255,255,.055);
  background: rgba(255,255,255,.025);
}

.check-item:hover {
  background: rgba(45,212,191,.10);
  border-color: rgba(45,212,191,.18);
}

.movie-list {
  gap: 11px;
  padding-left: 6px;
  padding-right: 2px;
}

.movie-list::-webkit-scrollbar,
.table-wrapper::-webkit-scrollbar,
.modal-content::-webkit-scrollbar,
.checklist::-webkit-scrollbar {
  width: 7px;
  height: 7px;
}

.movie-list::-webkit-scrollbar-thumb,
.table-wrapper::-webkit-scrollbar-thumb,
.modal-content::-webkit-scrollbar-thumb,
.checklist::-webkit-scrollbar-thumb {
  background: linear-gradient(var(--accent), var(--accent-2));
  border-radius: 99px;
}

.movie-row,
.pick-item,
.story-item {
  background:
    linear-gradient(135deg, rgba(255,255,255,.052), rgba(255,255,255,.018)),
    rgba(2, 6, 23, .30);
  border: 1px solid rgba(255,255,255,.08);
  border-radius: 22px;
  box-shadow: inset 0 1px 0 rgba(255,255,255,.035);
}

.movie-row {
  padding: 13px 16px;
}

.movie-row:hover,
.pick-item:hover,
.story-item:hover {
  border-color: rgba(45,212,191,.30);
  background: linear-gradient(135deg, rgba(45,212,191,.10), rgba(139,92,246,.045));
  transform: translateX(-5px);
}

.movie-poster {
  width: 54px;
  height: 78px;
  border-radius: 15px;
  box-shadow: 0 16px 26px rgba(0,0,0,.24);
  border: 1px solid rgba(255,255,255,.10);
}

.movie-name {
  color: #fff;
}

.movie-meta {
  color: #9eabc4;
}

.badge {
  min-height: 24px;
  padding: 4px 10px;
  border-radius: 999px;
  font-size: 11px;
  box-shadow: inset 0 1px 0 rgba(255,255,255,.045);
}

.badge-success {
  background: rgba(52, 211, 153, .13);
  color: #a7f3d0;
  border-color: rgba(52, 211, 153, .25);
}

.badge-warning {
  background: rgba(245, 158, 11, .13);
  color: #fde68a;
  border-color: rgba(245, 158, 11, .28);
}

.badge-danger {
  background: rgba(251, 113, 133, .13);
  color: #fecdd3;
  border-color: rgba(251, 113, 133, .28);
}

.badge-info {
  background: rgba(96, 165, 250, .13);
  color: #bfdbfe;
  border-color: rgba(96, 165, 250, .28);
}

.badge-gray {
  background: rgba(148, 163, 184, .10);
  color: #cbd5e1;
  border-color: rgba(148, 163, 184, .18);
}

.table-wrapper {
  border: 1px solid rgba(255,255,255,.075);
  background: rgba(2, 6, 23, .28);
  box-shadow: inset 0 1px 0 rgba(255,255,255,.035);
}

.data-table {
  min-width: 900px;
}

.data-table th {
  padding: 16px;
  background: rgba(15, 23, 42, .78);
  color: #d3dbee;
  font-weight: 850;
  white-space: nowrap;
}

.data-table td {
  padding: 15px 16px;
  color: #e7edf8;
}

.data-table tr {
  transition: background var(--transition);
}

.data-table tr:hover td {
  background: rgba(45, 212, 191, .06);
}

.user-avatar {
  border: 1px solid rgba(45, 212, 191, .38);
  box-shadow: 0 0 0 4px rgba(45,212,191,.06);
}

.pagination {
  gap: 9px;
}

.pagination a,
.tab {
  border-radius: 14px;
  border: 1px solid rgba(255,255,255,.09);
  background: rgba(255,255,255,.055);
}

.pagination a:hover,
.pagination a.active,
.tab.active,
.tab:hover {
  background: linear-gradient(135deg, var(--accent), var(--accent-3));
  color: #04110f;
  box-shadow: 0 14px 32px rgba(45, 212, 191, .20);
}

.tabs {
  padding: 8px;
  border-radius: 18px;
  width: fit-content;
  background: rgba(2, 6, 23, .28);
  border: 1px solid rgba(255,255,255,.07);
}

.live-results {
  border-color: rgba(45,212,191,.36);
  background: rgba(7, 12, 23, .96);
  border-radius: 22px;
  box-shadow: 0 28px 70px rgba(0,0,0,.48);
}

.live-item {
  padding: 14px 16px;
}

.live-item:hover {
  background: rgba(45,212,191,.11);
}

.toast {
  top: 22px;
  border: 1px solid rgba(45,212,191,.45);
  background: rgba(6, 12, 23, .86);
  color: #ccfbf1;
  border-radius: 18px;
  box-shadow: 0 24px 70px rgba(0,0,0,.48), 0 0 0 1px rgba(255,255,255,.05);
}

.modal {
  background:
    radial-gradient(circle at 30% 20%, rgba(45,212,191,.16), transparent 28rem),
    rgba(0, 0, 0, .72);
}

.modal-content {
  border-radius: 30px;
  border: 1px solid rgba(45,212,191,.32);
  background:
    linear-gradient(180deg, rgba(255,255,255,.07), rgba(255,255,255,.025)),
    rgba(7, 12, 23, .94);
  box-shadow: var(--shadow-hard);
}

.drag-handle {
  width: 34px;
  height: 42px;
  display: grid;
  place-items: center;
  border-radius: 14px;
  background: rgba(255,255,255,.045);
}

.story-thumb {
  border-radius: 16px;
  border-color: rgba(255,255,255,.10);
}

.empty {
  border: 1px dashed rgba(148,163,184,.22);
  border-radius: 22px;
  color: var(--text-secondary);
  background: rgba(255,255,255,.025);
}

.menu-toggle {
  box-shadow: 0 18px 46px rgba(0,0,0,.35);
}

.admin-stagger {
  animation: adminFadeRise .55s var(--transition) both;
}

@keyframes adminFadeRise {
  from { opacity: 0; transform: translateY(16px); }
  to { opacity: 1; transform: translateY(0); }
}

@media (max-width: 1180px) {
  .dashboard-hero {
    grid-template-columns: 1fr;
  }
  .hero-panel {
    grid-template-columns: repeat(4, minmax(120px, 1fr));
  }
  .stats-charts-row {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 1024px) {
  .sidebar {
    width: min(310px, 86vw);
    transform: translateX(110%);
  }
  .sidebar.open {
    transform: translateX(0);
  }
  .main-content {
    margin-right: 0;
    padding-top: 82px;
  }
  .menu-toggle {
    border-radius: 16px;
    background: rgba(8, 13, 24, .78);
    backdrop-filter: blur(16px);
  }
}

@media (max-width: 720px) {
  .dashboard-hero {
    padding: 20px;
    border-radius: 26px;
  }
  .hero-panel {
    grid-template-columns: 1fr 1fr;
  }
  .hero-actions .btn {
    width: 100%;
    justify-content: center;
  }
  .card-header,
  .card-body {
    padding: 18px;
  }
  .stats-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .stat-card {
    min-height: 138px;
  }
  .movie-actions {
    width: 100%;
    display: flex;
    gap: 8px;
  }
  .movie-actions .btn {
    flex: 1;
    justify-content: center;
  }
}

@media (max-width: 460px) {
  .main-content {
    padding-inline: 13px;
  }
  .stats-grid,
  .hero-panel {
    grid-template-columns: 1fr;
  }
  .hero-title {
    font-size: 30px;
  }
}

@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: .001ms !important;
    animation-iteration-count: 1 !important;
    scroll-behavior: auto !important;
    transition-duration: .001ms !important;
  }
}


/* ===== OMDb Queue + Duplicate Guard + Pro Quick Edit Update ===== */
.pro-attention-card{overflow:visible}.omdb-queue-panel{margin-bottom:22px;padding:18px;border-radius:24px;background:linear-gradient(135deg,rgba(45,212,191,.12),rgba(139,92,246,.08)),rgba(5,8,18,.58);border:1px solid rgba(45,212,191,.22);box-shadow:0 22px 55px rgba(0,0,0,.22)}.queue-headline{display:flex;justify-content:space-between;gap:14px;align-items:flex-start;margin-bottom:14px}.queue-headline strong{display:flex;align-items:center;gap:10px;font-size:16px;color:#eafffb}.queue-headline strong i{color:var(--accent)}.queue-headline small{display:block;color:var(--text-secondary);line-height:1.9;margin-top:6px}.queue-controls{display:flex;gap:10px;flex-wrap:wrap;align-items:center}.queue-controls select{width:auto;min-width:230px;height:42px}.queue-progress-wrap{height:9px;margin:16px 0 10px;border-radius:999px;overflow:hidden;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.08)}.queue-progress-bar{height:100%;width:0;background:linear-gradient(90deg,var(--accent),var(--accent-3));border-radius:inherit;transition:width .35s ease}.queue-stats{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:12px}.queue-stats span{padding:7px 11px;border-radius:999px;background:rgba(255,255,255,.055);border:1px solid rgba(255,255,255,.08);font-size:12px;color:var(--text-secondary)}.queue-stats b{color:var(--accent);font-size:13px}.queue-log{max-height:190px;overflow:auto;display:flex;flex-direction:column;gap:7px;padding-left:4px}.queue-log-row{display:flex;justify-content:space-between;gap:12px;align-items:center;padding:9px 11px;border-radius:14px;background:rgba(0,0,0,.22);border:1px solid rgba(255,255,255,.06);font-size:12px;color:var(--text-secondary)}.queue-log-row small{opacity:.7;white-space:nowrap}.queue-log-ok{border-color:rgba(45,212,191,.25);color:#d9fff7}.queue-log-warn{border-color:rgba(245,158,11,.28);color:#ffe1a8}.attention-card.is-completed{opacity:.72;border-color:rgba(45,212,191,.35);background:linear-gradient(145deg,rgba(45,212,191,.08),rgba(255,255,255,.025))}.duplicate-alert{margin-bottom:18px;padding:16px;border-radius:22px;background:linear-gradient(135deg,rgba(251,191,36,.12),rgba(251,113,133,.07)),rgba(5,8,18,.62);border:1px solid rgba(251,191,36,.28);box-shadow:0 18px 45px rgba(0,0,0,.18)}.duplicate-danger{border-color:rgba(251,113,133,.36);background:linear-gradient(135deg,rgba(251,113,133,.14),rgba(251,191,36,.08)),rgba(5,8,18,.68)}.duplicate-title{display:flex;gap:10px;align-items:center;color:#fff;font-weight:900;margin-bottom:8px}.duplicate-title i{color:var(--warning)}.duplicate-alert p{color:var(--text-secondary);line-height:1.9;margin-bottom:12px}.duplicate-row{display:grid;grid-template-columns:1fr auto;gap:8px;align-items:center;margin-top:8px;padding:10px 12px;border-radius:16px;background:rgba(0,0,0,.22);border:1px solid rgba(255,255,255,.07)}.duplicate-row strong{display:block}.duplicate-row small{display:block;color:var(--text-secondary);margin-top:4px}.duplicate-actions{display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap;margin-top:12px}.quick-edit-form{background:linear-gradient(145deg,rgba(45,212,191,.075),rgba(139,92,246,.055)),rgba(5,8,18,.55);border-color:rgba(45,212,191,.22);box-shadow:inset 0 1px 0 rgba(255,255,255,.06)}.quick-edit-form .form-grid{grid-template-columns:repeat(auto-fit,minmax(190px,1fr))}.modal-wide{max-width:920px}.quick-actions .btn{white-space:nowrap}@media(max-width:760px){.queue-headline,.duplicate-row{grid-template-columns:1fr;display:block}.queue-controls select{width:100%}.queue-controls .btn{width:100%;justify-content:center}.duplicate-row .btn{margin-top:10px;width:100%;justify-content:center}}

/* Admin Fast Sections */
.admin-fast-toolbar{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:14px;
  margin:0 0 20px;
  padding:14px 16px;
  border:1px solid rgba(255,255,255,.08);
  border-radius:22px;
  background:rgba(255,255,255,.035);
  box-shadow:inset 0 1px 0 rgba(255,255,255,.05);
}
.admin-fast-title{
  display:flex;
  align-items:center;
  gap:10px;
  color:var(--text-primary);
  font-weight:900;
  font-size:14px;
}
.admin-fast-title i{color:var(--accent)}
.admin-fast-hint{
  color:var(--text-secondary);
  font-size:12px;
  line-height:1.7;
}
.admin-page-section.admin-section-hidden,
.admin-dashboard-block.admin-section-hidden{
  display:none !important;
}
.admin-page-section{
  animation:adminFastIn .22s ease both;
}
@keyframes adminFastIn{
  from{opacity:0;transform:translateY(8px)}
  to{opacity:1;transform:translateY(0)}
}
.sidebar-nav a.admin-active{
  background:linear-gradient(90deg,rgba(0,255,163,.18),rgba(0,255,163,.04));
  color:var(--accent);
  border-color:var(--border-glow);
}
.movie-list-loading{
  padding:24px;
  text-align:center;
  color:var(--text-secondary);
  border:1px dashed var(--border);
  border-radius:18px;
  background:rgba(255,255,255,.03);
}
@media(max-width:720px){
  .admin-fast-toolbar{align-items:flex-start;flex-direction:column;padding:12px;border-radius:18px}
  .admin-fast-hint{font-size:11px}
}

</style>

<!-- BankMovie performance hints: CSS only + tiny low-power detector; no PHP/site logic changed. -->
<script>(function(){try{var d=document.documentElement,m=function(q){return window.matchMedia&&matchMedia(q).matches},c=navigator.connection||navigator.mozConnection||navigator.webkitConnection;if(m('(prefers-reduced-motion: reduce)')||(c&&c.saveData)||(m('(max-width: 768px)')&&((navigator.deviceMemory&&navigator.deviceMemory<=4)||(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=4))))d.classList.add('bm-low-power')}catch(e){}})();</script>
<script id="bm-device-tier">(function(d,n){try{var r=d.documentElement,m=function(q){return !!(window.matchMedia&&matchMedia(q).matches)},c=n.connection||n.mozConnection||n.webkitConnection||{},w=m('(max-width:900px)'),e=String(c.effectiveType||''),mem=Number(n.deviceMemory||0),cpu=Number(n.hardwareConcurrency||0),re=m('(prefers-reduced-motion:reduce)'),save=!!c.saveData,slow=/slow-2g|2g/.test(e),ultra=w&&(save||slow||(mem&&mem<=2)||(cpu&&cpu<=2)),low=re||save||slow||(w&&((mem&&mem<=3)||(cpu&&cpu<=4))),lite=w&&(low||(mem&&mem<=4)||(cpu&&cpu<=4));if(w)r.classList.add('bm-scroll-lite');if(low)r.classList.add('bm-low-power');if(lite)r.classList.add('bm-mobile-lite');if(ultra)r.classList.add('bm-ultra-lite');window.__BM_DEVICE_TIER__={mobile:w,low:low,lite:lite,ultra:ultra,saveData:save,effectiveType:e,memory:mem,cores:cpu}}catch(x){}})(document,navigator);</script>
<link rel="preload" href="/assets/css/bm-performance.css?v=mobile-lite66" as="style">
<link rel="stylesheet" href="/assets/css/bm-performance.css?v=mobile-lite66">
<link rel="stylesheet" href="/assets/css/admin-site-errors-v127.css?v=127">
<style id="bm-admin-main-v148-overrides">

.vip-admin-shell{position:relative;overflow:hidden;border-color:rgba(139,92,246,.28)!important;background:radial-gradient(circle at 88% 4%,rgba(139,92,246,.18),transparent 34%),linear-gradient(145deg,rgba(10,14,28,.96),rgba(7,10,20,.92))!important}.vip-admin-shell:before{content:"";position:absolute;inset:0;pointer-events:none;background:linear-gradient(115deg,transparent,rgba(255,255,255,.035),transparent);transform:translateX(-45%)}.vip-admin-hero{position:relative;z-index:1;display:flex;justify-content:space-between;gap:18px;align-items:center;padding:24px}.vip-admin-hero h3{margin:0 0 7px;font-size:24px}.vip-admin-hero p{margin:0;color:var(--text-secondary);line-height:1.9}.vip-admin-actions{display:flex;gap:9px;flex-wrap:wrap}.vip-admin-stats{position:relative;z-index:1;display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;padding:0 24px 20px}.vip-admin-stat{padding:16px;border:1px solid rgba(255,255,255,.08);border-radius:18px;background:rgba(255,255,255,.035)}.vip-admin-stat strong{display:block;font-size:25px;color:#fff}.vip-admin-stat span{font-size:11px;color:var(--text-secondary)}.vip-feature-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.vip-feature-card{display:flex;align-items:flex-start;gap:12px;padding:14px;border:1px solid rgba(255,255,255,.08);border-radius:17px;background:rgba(255,255,255,.025)}.vip-feature-card i{width:38px;height:38px;border-radius:12px;display:grid;place-items:center;background:rgba(139,92,246,.12);color:#c4b5fd}.vip-feature-card .copy{min-width:0;flex:1}.vip-feature-card b{display:block;margin-bottom:4px}.vip-feature-card small{display:block;color:var(--text-secondary);line-height:1.7}.vip-switch{position:relative;width:44px;height:24px;flex:0 0 auto}.vip-switch input{position:absolute;inset:0;width:100%;height:100%;margin:0;opacity:0;z-index:3;cursor:pointer}.vip-switch span{position:absolute;inset:0;border-radius:999px;background:#252b3a;border:1px solid rgba(255,255,255,.1);transition:.2s}.vip-switch span:after{content:"";position:absolute;width:18px;height:18px;top:2px;right:3px;border-radius:50%;background:#7c8498;transition:.2s}.vip-switch input:checked+span{background:linear-gradient(135deg,#8b5cf6,#2563eb)}.vip-switch input:checked+span:after{right:21px;background:#fff}.vip-group-title{margin:22px 0 10px;display:flex;align-items:center;gap:9px}.vip-group-title span{font-size:10px;padding:5px 9px;border-radius:999px;background:rgba(255,255,255,.06);color:var(--text-secondary)}.vip-admin-note{margin-top:14px;padding:12px 14px;border-radius:14px;background:rgba(245,158,11,.07);border:1px solid rgba(245,158,11,.18);color:#fcd34d;font-size:11px;line-height:1.8}@media(max-width:900px){.vip-admin-hero{align-items:flex-start;flex-direction:column}.vip-admin-stats{grid-template-columns:repeat(2,1fr)}.vip-feature-grid{grid-template-columns:1fr}}@media(max-width:520px){.vip-admin-stats{grid-template-columns:1fr 1fr;padding-inline:14px}.vip-admin-hero{padding:18px 14px}.vip-admin-actions .btn{width:100%}}
.sidebar{display:flex!important;flex-direction:column!important;overflow:hidden!important;padding-bottom:18px!important}.sidebar-logo{flex:0 0 auto}.sidebar-nav{flex:1 1 auto!important;min-height:0!important;overflow-y:auto!important;padding-bottom:12px!important;margin-bottom:0!important;scrollbar-width:thin}.sidebar-footer{position:static!important;right:auto!important;left:auto!important;bottom:auto!important;flex:0 0 auto;margin-top:12px!important;padding:12px!important}
/* V148.60.12 — request center */
.bm-req-replied-mark{display:flex;align-items:center;gap:5px;margin-top:5px;color:var(--text-secondary);font-size:9px;white-space:nowrap}.bm-req-status-picker{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:9px}.bm-req-status-choice{position:relative;cursor:pointer}.bm-req-status-choice input{position:absolute;opacity:0;pointer-events:none}.bm-req-status-choice>span{display:flex;min-height:76px;flex-direction:column;align-items:center;justify-content:center;gap:3px;text-align:center;border:1px solid var(--border);border-radius:16px;background:rgba(255,255,255,.025);transition:.18s ease}.bm-req-status-choice i{font-size:17px}.bm-req-status-choice b{font-size:11px;color:var(--text-primary)}.bm-req-status-choice small{font-size:9px;color:var(--text-secondary)}.bm-req-status-choice.pending i{color:#fbbf24}.bm-req-status-choice.approved i{color:#34d399}.bm-req-status-choice.rejected i{color:#fb7185}.bm-req-status-choice input:checked+span{transform:translateY(-1px);box-shadow:0 8px 24px rgba(0,0,0,.18)}.bm-req-status-choice.pending input:checked+span{border-color:rgba(251,191,36,.5);background:rgba(251,191,36,.09)}.bm-req-status-choice.approved input:checked+span{border-color:rgba(52,211,153,.5);background:rgba(52,211,153,.09)}.bm-req-status-choice.rejected input:checked+span{border-color:rgba(251,113,133,.5);background:rgba(251,113,133,.09)}.bm-req-quick-title,.bm-req-response-head{display:flex;align-items:center;justify-content:space-between;gap:10px}.bm-req-quick-title small,.bm-req-response-head small{font-size:9px;color:var(--text-secondary)}.bm-req-quick-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:8px;max-height:235px;overflow:auto;padding:2px}.bm-req-quick-card{font:inherit;text-align:right;border:1px solid var(--border);border-radius:15px;background:rgba(255,255,255,.025);color:var(--text-primary);padding:11px 12px;cursor:pointer;transition:.18s ease}.bm-req-quick-card:hover,.bm-req-quick-card.active{border-color:var(--border-glow);background:rgba(0,255,163,.055)}.bm-req-quick-card strong{display:block;font-size:10.5px;margin-bottom:5px;color:#fff}.bm-req-quick-card span{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow:hidden;font-size:9px;line-height:1.8;color:var(--text-secondary)}.bm-req-quick-card.active:after{content:'انتخاب شد';display:inline-flex;margin-top:7px;padding:3px 7px;border-radius:999px;background:rgba(52,211,153,.1);color:#6ee7b7;font-size:8px;font-weight:900}.bm-req-quick-empty{padding:13px;border:1px dashed var(--border);border-radius:14px;color:var(--text-secondary);font-size:10px;line-height:1.8}.bm-req-response-head{margin-bottom:7px}.bm-req-response-head label{margin:0!important}.bm-req-response-head small{direction:ltr;font-variant-numeric:tabular-nums}.req-modal-note{font-size:9px;color:var(--text-secondary)}@media(max-width:650px){.bm-req-status-picker{grid-template-columns:1fr}.bm-req-status-choice>span{min-height:58px}.bm-req-quick-grid{grid-template-columns:1fr;max-height:210px}}
</style>
<style id="bm-admin-password-reset-v14861966">
.bm-reset-pass-card{position:relative;overflow:hidden;display:grid;grid-template-columns:auto minmax(0,1fr) auto;gap:14px;align-items:center;margin:0 0 16px;padding:16px 18px;border:1px solid rgba(34,211,238,.28);border-radius:20px;background:radial-gradient(circle at 90% 10%,rgba(34,211,238,.14),transparent 34%),linear-gradient(135deg,rgba(8,18,31,.96),rgba(8,12,22,.94));box-shadow:0 18px 45px rgba(0,0,0,.24)}
.bm-reset-pass-icon{width:46px;height:46px;border-radius:15px;display:grid;place-items:center;background:rgba(34,211,238,.1);border:1px solid rgba(34,211,238,.18);color:#67e8f9;font-size:18px}.bm-reset-pass-copy{min-width:0}.bm-reset-pass-copy small{display:block;color:var(--text-secondary);font-size:10px;margin-bottom:5px}.bm-reset-pass-copy strong{display:block;color:#fff;font-size:13px;margin-bottom:7px}.bm-reset-pass-value{display:flex;align-items:center;gap:9px;direction:ltr}.bm-reset-pass-value code{display:block;max-width:100%;overflow:auto;padding:9px 11px;border-radius:12px;background:rgba(0,0,0,.28);border:1px solid rgba(255,255,255,.08);color:#a5f3fc;font:800 14px/1.2 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;letter-spacing:.6px;white-space:nowrap}.bm-reset-pass-note{grid-column:2/-1;color:#fcd34d;font-size:9px;line-height:1.8}.bm-password-reset-btn{border-color:rgba(34,211,238,.24)!important;color:#a5f3fc!important}.bm-password-reset-btn:hover{background:rgba(34,211,238,.09)!important;border-color:rgba(34,211,238,.42)!important}.bm-password-reset-btn i{margin-left:5px}@media(max-width:640px){.bm-reset-pass-card{grid-template-columns:auto minmax(0,1fr);padding:14px}.bm-reset-pass-card>.btn{grid-column:1/-1;width:100%}.bm-reset-pass-note{grid-column:1/-1}.bm-reset-pass-value code{font-size:12px}.bm-reset-pass-icon{width:42px;height:42px}}
</style>

<?php if (!function_exists('bm_site_bool') || bm_site_bool('ui_neon_checkbox_enabled', true)): ?>
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-uiverse-v14843.css?v=14843">
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-adapter-v14843.css?v=14843">
<style id="bm-neon-checkbox-settings">.neon-checkbox{--primary:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_color','#00ffaa'),ENT_QUOTES,'UTF-8') : '#00ffaa' ?>;--primary-dark:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_dark_color','#00cc88'),ENT_QUOTES,'UTF-8') : '#00cc88' ?>;--primary-light:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_light_color','#88ffdd'),ENT_QUOTES,'UTF-8') : '#88ffdd' ?>;--size:<?= function_exists('bm_site_get') ? max(24,min(38,(int)bm_site_get('ui_neon_checkbox_size',30))) : 30 ?>px}</style>
<script src="/assets/js/bm-neon-checkbox-v14843.js?v=14843" defer></script>
<?php endif; ?>
<style id="bm-v172-movie-editor">
.bm-release-editor{margin:18px 0;padding:18px;border:1px solid rgba(54,255,159,.18);border-radius:22px;background:linear-gradient(145deg,rgba(54,255,159,.055),rgba(56,189,248,.035))}.bm-release-head{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;margin-bottom:15px}.bm-release-head strong{display:block;font-size:14px}.bm-release-head small{display:block;margin-top:5px;color:var(--text-secondary);font-size:10px;line-height:1.8}.bm-release-head>span{max-width:420px;padding:7px 10px;border-radius:12px;background:rgba(54,255,159,.08);color:#8fffc8;font-size:10px;line-height:1.7}.bm-update-checks{display:flex;gap:10px;flex-wrap:wrap;margin-top:12px}.bm-update-checks label{display:flex;align-items:center;gap:7px;padding:9px 11px;border:1px solid var(--border);border-radius:13px;background:rgba(255,255,255,.03);font-size:10px}.bm-summary-head{display:flex;justify-content:space-between;gap:10px}.bm-summary-head small{color:var(--text-secondary)}.bm-summary-tools{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-top:8px;color:var(--text-secondary);font-size:10px}.bm-summary-preview{margin-top:10px;padding:14px;border:1px solid var(--border);border-radius:16px;background:rgba(0,0,0,.18);line-height:2;color:#d9e1ee;white-space:pre-wrap}.bm-cover-editor{display:flex;gap:14px;align-items:center}.bm-cover-preview{width:88px;height:126px;border-radius:16px;border:1px solid var(--border);background:rgba(255,255,255,.04);display:grid;place-items:center;overflow:hidden;flex:0 0 auto}.bm-cover-preview img{width:100%;height:100%;object-fit:cover}.bm-link-grid{grid-template-columns:repeat(3,minmax(0,1fr))!important}.bm-link-grid input{min-width:0}@media(max-width:760px){.bm-release-head{flex-direction:column}.bm-link-grid{grid-template-columns:1fr!important}.bm-cover-editor{align-items:flex-start}.bm-update-checks{display:grid;grid-template-columns:1fr 1fr}}@media(max-width:420px){.bm-update-checks{grid-template-columns:1fr}}

<style id="bm-v173-sidebar-groups">
.bm-sidebar-groups{padding-bottom:14px}.bm-sidebar-group-label{display:flex;align-items:center;gap:8px;margin:14px 12px 5px;color:rgba(255,255,255,.38);font-size:9px;font-weight:900;letter-spacing:.35px}.bm-sidebar-group-label:after{content:"";height:1px;flex:1;background:rgba(255,255,255,.07)}.bm-sidebar-group-label span{white-space:nowrap}.bm-sidebar-groups>a{margin-bottom:2px}.bm-sidebar-groups>a[href="admin_hub.php"]{border:1px solid rgba(74,222,128,.18);background:linear-gradient(135deg,rgba(34,197,94,.12),rgba(59,130,246,.08));color:#dfffea}
</style>
</style>
<style id="bm-admin-avatar-badge-v179">
.sidebar .bm-admin-brand-profile{display:grid!important;grid-template-columns:52px minmax(0,1fr)!important;gap:11px!important;align-items:center!important;text-align:right!important;padding:14px 12px!important;margin:6px 10px 14px!important;border:1px solid rgba(255,255,255,.09)!important;border-radius:18px!important;background:linear-gradient(135deg,rgba(47,124,255,.12),rgba(255,255,255,.035))!important;box-shadow:0 16px 36px rgba(0,0,0,.18)!important}
.sidebar .bm-admin-avatar-shell{width:52px;height:52px;border-radius:16px;overflow:hidden;display:grid;place-items:center;background:linear-gradient(135deg,#18243a,#0a101a);border:1px solid rgba(125,182,255,.28);box-shadow:0 0 0 3px rgba(47,124,255,.07);flex:none}.sidebar .bm-admin-avatar-shell img{width:100%;height:100%;display:block;object-fit:cover}.sidebar .bm-admin-avatar-shell i{font-size:21px!important;color:#78b8ff!important;margin:0!important}.sidebar .bm-admin-brand-copy{min-width:0;display:flex;flex-direction:column;align-items:flex-start;gap:2px}.sidebar .bm-admin-brand-copy h2{margin:0!important;font-size:15px!important;line-height:1.2!important}.sidebar .bm-admin-brand-copy strong{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px;color:#f8fbff}.sidebar .bm-admin-brand-copy small{font-size:9px;color:#7fa2ca}.bm-admin-badge-color-form{display:flex;align-items:center;gap:7px;flex-wrap:wrap;padding:7px 8px;border:1px solid rgba(29,155,240,.18);border-radius:12px;background:rgba(29,155,240,.055)}.bm-admin-badge-color-form label{display:flex;align-items:center;gap:5px;font-size:10px;color:#b9c9df;font-weight:800}.bm-admin-badge-color-form input[type=color]{width:34px;height:30px;border:0;padding:2px;border-radius:9px;background:#111827;cursor:pointer}.bm-admin-color-preview{width:18px;height:18px;display:grid;place-items:center;border-radius:50%;background:var(--c);color:#fff;font-size:11px;font-weight:950;box-shadow:0 0 10px color-mix(in srgb,var(--c) 40%,transparent)}
</style>
<style id="bm-admin-search-focus-v181">
.data-table tr:target,.user-card-pro:target{outline:2px solid rgba(96,165,250,.58)!important;outline-offset:-2px;background:rgba(59,130,246,.10)!important;box-shadow:0 0 28px rgba(59,130,246,.13)!important}
</style>
<link rel="stylesheet" href="/assets/css/bm-admin-settings-search-v182.css?v=182.0">
<script src="/assets/js/bm-admin-settings-search-v182.js?v=182.0" defer></script>
<link rel="stylesheet" href="/assets/css/bm-admin-mobile-v185.css?v=185.0">
<script src="/assets/js/bm-admin-mobile-v185.js?v=185.0" defer></script>

<style id="bm-security-center-v24">
#securityCenterSection{margin:0 0 26px;overflow:hidden}
.bm-security-nav{border-color:rgba(45,212,191,.24)!important;background:linear-gradient(135deg,rgba(45,212,191,.12),rgba(96,165,250,.055))!important}
.bm-sec2{position:relative;background:linear-gradient(180deg,rgba(255,255,255,.05),rgba(255,255,255,.022)),rgba(7,12,22,.76)!important;border-color:rgba(148,163,184,.13)!important}
.bm-sec2:before{content:"";position:absolute;inset:0 0 auto;height:220px;pointer-events:none;background:radial-gradient(650px 210px at 92% -20%,rgba(45,212,191,.15),transparent 68%),radial-gradient(500px 180px at 8% 0,rgba(96,165,250,.08),transparent 70%)}
.bm-sec2-head{position:relative;z-index:1;display:flex;justify-content:space-between;align-items:center;gap:20px;padding:25px 26px 18px;border-bottom:1px solid rgba(255,255,255,.065)}
.bm-sec2-heading{display:flex;align-items:center;gap:15px;min-width:0}.bm-sec2-logo{width:54px;height:54px;flex:0 0 54px;border-radius:19px;display:grid;place-items:center;color:#04120f;background:linear-gradient(135deg,var(--accent),var(--accent-3));box-shadow:0 15px 36px rgba(45,212,191,.19)}.bm-sec2-logo i{font-size:22px}.bm-sec2-eyebrow{display:flex;align-items:center;gap:7px;margin-bottom:5px;color:var(--accent);font-size:9px;font-weight:900;letter-spacing:.12em;text-transform:uppercase}.bm-sec2-heading h2{margin:0;font-size:22px;letter-spacing:-.035em}.bm-sec2-heading p{margin:6px 0 0;color:var(--text-secondary);font-size:11px;line-height:1.8;max-width:720px}.bm-sec2-controls{display:flex;align-items:center;gap:9px;flex-wrap:wrap;justify-content:flex-end}.bm-sec2-live{display:inline-flex;align-items:center;gap:8px;padding:9px 12px;border-radius:999px;font-size:10px;font-weight:900;border:1px solid rgba(255,255,255,.09);background:rgba(255,255,255,.035)}.bm-sec2-live.on{color:#86efac;border-color:rgba(52,211,153,.23);background:rgba(52,211,153,.07)}.bm-sec2-live.off{color:#fda4af;border-color:rgba(251,113,133,.22);background:rgba(251,113,133,.07)}.bm-sec2-dot{width:7px;height:7px;border-radius:50%;background:currentColor;box-shadow:0 0 12px currentColor}
.bm-sec2-protection{position:relative;z-index:1;display:grid;grid-template-columns:minmax(290px,.95fr) minmax(0,1.45fr);gap:14px;padding:18px 26px 4px}.bm-sec2-status-card{position:relative;overflow:hidden;min-height:166px;padding:21px;border:1px solid rgba(45,212,191,.16);border-radius:24px;background:linear-gradient(135deg,rgba(45,212,191,.085),rgba(96,165,250,.035)),rgba(255,255,255,.025)}.bm-sec2-status-card:after{content:"";position:absolute;width:170px;height:170px;border-radius:50%;left:-55px;bottom:-95px;background:rgba(45,212,191,.08);filter:blur(2px)}.bm-sec2-status-top{display:flex;align-items:center;justify-content:space-between;gap:12px}.bm-sec2-status-title{display:flex;align-items:center;gap:9px;font-weight:900}.bm-sec2-status-title i{color:var(--accent)}.bm-sec2-status-card>strong{position:relative;z-index:1;display:block;margin-top:18px;font-size:31px;letter-spacing:-.045em}.bm-sec2-status-card>p{position:relative;z-index:1;margin:8px 0 0;color:var(--text-secondary);font-size:11px;line-height:1.9}.bm-sec2-chips{position:relative;z-index:1;display:flex;gap:7px;flex-wrap:wrap;margin-top:16px}.bm-sec2-chip{display:inline-flex;align-items:center;gap:6px;padding:7px 9px;border-radius:10px;border:1px solid rgba(255,255,255,.075);background:rgba(0,0,0,.16);color:#c8d2e5;font-size:9px}.bm-sec2-chip i{color:var(--accent)}
.bm-sec2-kpis{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.bm-sec2-kpi{position:relative;overflow:hidden;min-height:78px;padding:14px 14px 12px;border:1px solid rgba(255,255,255,.075);border-radius:19px;background:rgba(255,255,255,.027);transition:var(--transition)}.bm-sec2-kpi:hover{transform:translateY(-2px);border-color:rgba(45,212,191,.22);background:rgba(255,255,255,.04)}.bm-sec2-kpi-head{display:flex;align-items:center;justify-content:space-between;gap:8px}.bm-sec2-kpi-icon{width:31px;height:31px;border-radius:11px;display:grid;place-items:center;background:rgba(45,212,191,.09);color:var(--accent);font-size:12px;border:1px solid rgba(45,212,191,.11)}.bm-sec2-kpi.hot .bm-sec2-kpi-icon{color:#fb7185;background:rgba(251,113,133,.08);border-color:rgba(251,113,133,.13)}.bm-sec2-kpi.good .bm-sec2-kpi-icon{color:#34d399}.bm-sec2-kpi b{font-size:23px;letter-spacing:-.035em}.bm-sec2-kpi small{display:block;margin-top:7px;color:var(--text-secondary);font-size:9px;line-height:1.55}
.bm-sec2-alert{position:relative;z-index:1;display:flex;align-items:center;gap:11px;margin:12px 26px 18px;padding:11px 13px;border:1px solid rgba(45,212,191,.13);border-radius:15px;background:rgba(45,212,191,.045);color:#b9eadf;font-size:9.5px;line-height:1.8}.bm-sec2-alert>i{width:30px;height:30px;flex:0 0 30px;border-radius:11px;display:grid;place-items:center;background:rgba(45,212,191,.09);color:var(--accent)}
.bm-sec2-dashboard{position:relative;z-index:1;display:grid;grid-template-columns:minmax(0,1.2fr) minmax(320px,.8fr);gap:14px;padding:0 26px 18px}.bm-sec2-box{border:1px solid rgba(255,255,255,.075);border-radius:22px;background:rgba(0,0,0,.12);overflow:hidden}.bm-sec2-box-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:15px 17px;border-bottom:1px solid rgba(255,255,255,.06)}.bm-sec2-box-title{display:flex;align-items:center;gap:9px;font-size:12px;font-weight:900}.bm-sec2-box-title i{width:30px;height:30px;border-radius:11px;display:grid;place-items:center;background:rgba(45,212,191,.08);color:var(--accent)}.bm-sec2-box-head small{color:var(--text-secondary);font-size:8.5px}.bm-sec2-activity{display:grid;grid-template-columns:minmax(0,1fr) minmax(210px,.65fr);min-height:245px}.bm-sec2-events{padding:8px 14px}.bm-sec2-event{display:grid;grid-template-columns:31px minmax(0,1fr) auto;gap:10px;align-items:center;padding:10px 3px;border-bottom:1px solid rgba(255,255,255,.055)}.bm-sec2-event:last-child{border-bottom:0}.bm-sec2-event-icon{width:31px;height:31px;border-radius:11px;display:grid;place-items:center;background:rgba(96,165,250,.08);color:var(--info);font-size:10px}.bm-sec2-event b{display:block;font-size:10px}.bm-sec2-event span{display:block;margin-top:3px;color:var(--text-secondary);font-size:8.5px;direction:ltr;text-align:right;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.bm-sec2-event time{color:#718096;font-size:8px;white-space:nowrap}.bm-sec2-targets{border-right:1px solid rgba(255,255,255,.055);padding:13px}.bm-sec2-targets h4{margin:0 0 11px;color:var(--text-secondary);font-size:9px}.bm-sec2-target{margin-bottom:11px}.bm-sec2-target-row{display:flex;justify-content:space-between;gap:9px;margin-bottom:5px;font-size:8.5px}.bm-sec2-target-row code{max-width:155px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#d8e0ee;background:none;padding:0;direction:ltr}.bm-sec2-target-row b{color:#fff}.bm-sec2-target-track{height:5px;border-radius:999px;background:rgba(255,255,255,.055);overflow:hidden}.bm-sec2-target-track span{display:block;height:100%;border-radius:999px;background:linear-gradient(90deg,var(--accent),var(--accent-3));box-shadow:0 0 10px rgba(45,212,191,.2)}
.bm-sec2-blocks{padding:9px 12px 12px;max-height:245px;overflow:auto}.bm-sec2-block{display:grid;grid-template-columns:35px minmax(0,1fr) auto;gap:9px;align-items:center;padding:9px 2px;border-bottom:1px solid rgba(255,255,255,.055)}.bm-sec2-block:last-child{border-bottom:0}.bm-sec2-block-icon{width:35px;height:35px;border-radius:12px;display:grid;place-items:center;color:#fb7185;background:rgba(251,113,133,.075);border:1px solid rgba(251,113,133,.11)}.bm-sec2-block strong{display:block;font-size:9.5px;direction:ltr;text-align:right}.bm-sec2-block small{display:block;margin-top:3px;color:var(--text-secondary);font-size:8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.bm-sec2-empty{padding:35px 15px;text-align:center;color:var(--text-secondary);font-size:10px}.bm-sec2-empty i{display:block;margin:0 auto 9px;color:var(--accent);font-size:24px}
.bm-sec2-quick{display:grid;grid-template-columns:minmax(0,1fr) 75px auto;gap:7px;padding:11px 12px;border-top:1px solid rgba(255,255,255,.055)}.bm-sec2-quick input{min-width:0;border:1px solid var(--border);border-radius:11px;background:rgba(0,0,0,.2);color:var(--text-primary);padding:8px 9px;font:inherit;font-size:10px;outline:0}.bm-sec2-block-actions{display:flex;gap:7px;padding:0 12px 12px;flex-wrap:wrap}
.bm-sec2-settings{position:relative;z-index:1;padding:0 26px 26px}.bm-sec2-settings-head{display:flex;align-items:flex-end;justify-content:space-between;gap:14px;margin:5px 0 12px}.bm-sec2-settings-head h3{display:flex;align-items:center;gap:9px;margin:0;font-size:15px}.bm-sec2-settings-head h3 i{color:var(--accent)}.bm-sec2-settings-head p{margin:4px 0 0;color:var(--text-secondary);font-size:9.5px}.bm-sec2-groups{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;align-items:start}.bm-sec2-group{border:1px solid rgba(255,255,255,.075);border-radius:19px;background:rgba(255,255,255,.022);overflow:hidden}.bm-sec2-group summary{list-style:none;cursor:pointer;display:flex;align-items:center;gap:10px;padding:14px 15px;font-size:11px;font-weight:900;user-select:none}.bm-sec2-group summary::-webkit-details-marker{display:none}.bm-sec2-group summary i:first-child{width:31px;height:31px;border-radius:11px;display:grid;place-items:center;background:rgba(45,212,191,.08);color:var(--accent)}.bm-sec2-group summary .fa-chevron-down{margin-right:auto;color:#6f7e97;font-size:8px;transition:transform .2s}.bm-sec2-group[open] summary .fa-chevron-down{transform:rotate(180deg)}.bm-sec2-group-body{padding:0 14px 14px}.bm-sec2-fields{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.bm-sec2-field{display:flex;flex-direction:column;gap:5px}.bm-sec2-field.full{grid-column:1/-1}.bm-sec2-field label{color:var(--text-secondary);font-size:8.5px;font-weight:800}.bm-sec2-field input[type=number],.bm-sec2-field input[type=text],.bm-sec2-field textarea{width:100%;min-width:0;border:1px solid var(--border);border-radius:11px;background:rgba(0,0,0,.2);color:var(--text-primary);padding:9px 10px;font:inherit;font-size:10px;outline:0}.bm-sec2-field textarea{min-height:92px;resize:vertical;direction:ltr;text-align:left}.bm-sec2-toggle{position:relative;display:flex;align-items:center;gap:10px;padding:9px 10px;margin-bottom:7px;border-radius:12px;border:1px solid rgba(255,255,255,.065);background:rgba(0,0,0,.1);font-size:9px;line-height:1.65;color:var(--text-secondary);cursor:pointer;min-height:50px}.bm-sec2-toggle>input[type=checkbox]{position:absolute!important;width:1px!important;height:1px!important;min-width:0!important;min-height:0!important;margin:0!important;padding:0!important;opacity:0!important;pointer-events:none!important;appearance:none!important;-webkit-appearance:none!important}.bm-sec2-toggle-copy{display:block;min-width:0;flex:1}.bm-sec2-toggle strong{display:block;color:#e9eef8;margin-bottom:2px}.bm-sec2-switch{position:relative;display:inline-block;flex:0 0 38px;width:38px;height:20px;border-radius:999px;background:#242c36;border:1px solid rgba(255,255,255,.11);box-shadow:inset 0 0 0 1px rgba(0,0,0,.12);transition:background .18s ease,border-color .18s ease,box-shadow .18s ease}.bm-sec2-switch:after{content:"";position:absolute;top:2px;right:2px;width:14px;height:14px;border-radius:50%;background:#7f8a99;box-shadow:0 1px 5px rgba(0,0,0,.38);transition:transform .18s ease,background .18s ease}.bm-sec2-toggle>input[type=checkbox]:checked+.bm-sec2-switch{background:rgba(45,212,191,.18);border-color:rgba(45,212,191,.55);box-shadow:0 0 0 2px rgba(45,212,191,.04),inset 0 0 12px rgba(45,212,191,.08)}.bm-sec2-toggle>input[type=checkbox]:checked+.bm-sec2-switch:after{transform:translateX(-18px);background:var(--accent);box-shadow:0 0 10px rgba(45,212,191,.35)}.bm-sec2-toggle>input[type=checkbox]:focus-visible+.bm-sec2-switch{outline:2px solid rgba(45,212,191,.48);outline-offset:2px}.bm-sec2-toggle:hover .bm-sec2-switch{border-color:rgba(45,212,191,.38)}.bm-sec2-save{position:sticky;bottom:10px;z-index:3;display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:12px;padding:10px 11px;border:1px solid rgba(45,212,191,.14);border-radius:16px;background:rgba(6,11,20,.92);backdrop-filter:blur(14px)}.bm-sec2-save span{color:var(--text-secondary);font-size:9px}.bm-sec2-save b{color:var(--accent)}
@media(max-width:1150px){.bm-sec2-protection{grid-template-columns:1fr}.bm-sec2-status-card{min-height:auto}.bm-sec2-dashboard{grid-template-columns:1fr}.bm-sec2-groups{grid-template-columns:1fr 1fr}.bm-sec2-group:last-child{grid-column:1/-1}}
@media(max-width:760px){.bm-sec2-head{padding:18px 15px 14px;align-items:flex-start;flex-direction:column}.bm-sec2-controls{width:100%;justify-content:space-between}.bm-sec2-protection{padding:14px 15px 3px}.bm-sec2-kpis{grid-template-columns:repeat(2,1fr)}.bm-sec2-alert{margin:10px 15px 14px}.bm-sec2-dashboard{padding:0 15px 14px}.bm-sec2-activity{grid-template-columns:1fr}.bm-sec2-targets{border-right:0;border-top:1px solid rgba(255,255,255,.055)}.bm-sec2-settings{padding:0 15px 18px}.bm-sec2-groups{grid-template-columns:1fr}.bm-sec2-group:last-child{grid-column:auto}.bm-sec2-save{position:static;align-items:stretch;flex-direction:column}.bm-sec2-save .btn{width:100%}.bm-sec2-quick{grid-template-columns:1fr 70px}.bm-sec2-quick .btn{grid-column:1/-1}}
@media(max-width:440px){.bm-sec2-heading{align-items:flex-start}.bm-sec2-logo{width:46px;height:46px;flex-basis:46px;border-radius:16px}.bm-sec2-heading h2{font-size:18px}.bm-sec2-heading p{font-size:9px}.bm-sec2-kpis{grid-template-columns:1fr 1fr}.bm-sec2-kpi{padding:11px;min-height:73px}.bm-sec2-kpi b{font-size:20px}.bm-sec2-status-card>strong{font-size:26px}.bm-sec2-fields{grid-template-columns:1fr}.bm-sec2-field.full{grid-column:auto}.bm-sec2-event{grid-template-columns:28px minmax(0,1fr)}.bm-sec2-event time{display:none}}
</style>
</head>
<body class="bm-admin-page bm-admin-page-main">

<!-- Mobile Menu Toggle -->
<div class="menu-toggle" id="menuToggle" style="display: none;">
  <i class="fas fa-bars" style="color: var(--accent); font-size: 22px;"></i>
</div>

<!-- Sidebar -->
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo bm-admin-brand-profile">
    <div class="bm-admin-avatar-shell"><?php if($adminPanelAvatar !== ''): ?><img src="<?= htmlspecialchars($adminPanelAvatar, ENT_QUOTES, 'UTF-8') ?>" alt="آواتار مدیر"><?php else: ?><i class="fas fa-user-shield"></i><?php endif; ?></div>
    <div class="bm-admin-brand-copy"><h2>BankMovie</h2><strong><?= htmlspecialchars($adminPanelName, ENT_QUOTES, 'UTF-8') ?></strong><small><?= htmlspecialchars($adminPanelRoleLabel, ENT_QUOTES, 'UTF-8') ?></small></div>
  </div>
  
  <div class="sidebar-nav bm-sidebar-groups">
    <a href="admin_hub.php" class="active"><i class="fas fa-table-cells-large"></i> مرکز مدیریت</a>

    <div class="bm-sidebar-group-label"><span>داشبورد</span></div>
    <a href="#" class="bm-security-nav" onclick="scrollToSection('securityCenterSection'); return false;"><i class="fas fa-shield-halved"></i> امنیت و Anti-Spam</a>
    <a href="#" onclick="scrollToSection('commandCenterSection'); return false;"><i class="fas fa-gauge-high"></i> مرکز فرماندهی</a>
    <a href="#" onclick="scrollToSection('attentionSection'); return false;"><i class="fas fa-triangle-exclamation"></i> نیازمند توجه</a>
    <a href="#" onclick="scrollToSection('healthSection'); return false;"><i class="fas fa-heart-pulse"></i> سلامت محتوا</a>

    <div class="bm-sidebar-group-label"><span>محتوا و Import</span></div>
    <a href="#" onclick="scrollToSection('moviesSection'); return false;"><i class="fas fa-video"></i> فیلم‌ها و سریال‌ها</a>
    <a href="#" onclick="scrollToSection('addMovieSection'); return false;"><i class="fas fa-plus-circle"></i> افزودن محتوا</a>
    <a href="admin_content_updates.php"><i class="fas fa-arrows-rotate"></i> مرکز بروزرسانی</a>
    <a href="admin_import_pro.php"><i class="fas fa-wand-magic-sparkles"></i> Import Pro</a>
    <a href="admin_import_history.php"><i class="fas fa-clock-rotate-left"></i> صف و تاریخچه Import</a>
    <a href="#" onclick="scrollToSection('omdbSection'); return false;"><i class="fas fa-magic-wand-sparkles"></i> ایمپورت OMDb</a>
    <a href="#" onclick="scrollToSection('linkHealthSection'); return false;"><i class="fas fa-link"></i> چک لینک‌ها</a>
    <a href="#" onclick="scrollToSection('missingSection'); return false;"><i class="fas fa-image"></i> بدون کاور</a>
    <a href="admin_collections.php"><i class="fas fa-layer-group"></i> کالکشن‌ها</a>
    <a href="admin_slider.php"><i class="fas fa-sliders-h"></i> اسلایدر</a>
    <a href="admin_weekly_schedule.php"><i class="fas fa-calendar-days"></i> جدول پخش</a>

    <div class="bm-sidebar-group-label"><span>رسانه و ظاهر</span></div>
    <a href="admin_media_manager.php"><i class="fas fa-photo-film"></i> Media Manager</a>
    <a href="admin_site_manager.php"><i class="fas fa-palette"></i> ظاهر و متن‌ها</a>
    <a href="#" onclick="scrollToSection('bannersSection'); return false;"><i class="fas fa-rectangle-ad"></i> بنرها</a>
    <a href="admin_stickers.php"><i class="fas fa-note-sticky"></i> استیکر و گیف</a>
    <a href="#" onclick="scrollToSection('storiesSection'); return false;"><i class="fas fa-scroll"></i> استوری‌ها</a>

    <div class="bm-sidebar-group-label"><span>کاربران و ارتباط</span></div>
    <a href="#" onclick="scrollToSection('usersSection'); return false;"><i class="fas fa-users-gear"></i> کاربران</a>
    <a href="#" onclick="scrollToSection('commentsSection'); return false;"><i class="fas fa-comments"></i> نظرات</a>
    <a href="#" onclick="scrollToSection('requestsSection'); return false;"><i class="fas fa-envelope"></i> درخواست‌ها</a>
    <a href="#" onclick="scrollToSection('notifSection'); return false;"><i class="fas fa-bell"></i> نوتیفیکیشن</a>
    <a href="#" onclick="scrollToSection('quickRepliesSection'); return false;"><i class="fas fa-message"></i> پیام آماده</a>

    <div class="bm-sidebar-group-label"><span>VIP و دسترسی</span></div>
    <a href="admin_vip_manager.php"><i class="fas fa-crown"></i> VIP Studio</a>
    <a href="admin_feature_flags.php"><i class="fas fa-toggle-on"></i> Feature Flags</a>
    <a href="#" onclick="scrollToSection('vipSection'); return false;"><i class="fas fa-user-shield"></i> کاربران VIP</a>
    <a href="admin_control_center.php?tab=archives"><i class="fas fa-box-archive"></i> آرشیوها</a>

    <div class="bm-sidebar-group-label"><span>زیرساخت</span></div>
    <a href="admin_paths.php"><i class="fas fa-route"></i> مسیرها و دانلود</a>
    <a href="admin_control_center.php"><i class="fas fa-sliders"></i> مرکز کنترل کامل</a>
    <a href="api_manager.php"><i class="fas fa-plug-circle-bolt"></i> مدیریت API</a>
    <a href="bm_admin.php"><i class="fas fa-mobile-screen-button"></i> کنترل اپ</a>
    <a href="admin_desktop.php"><i class="fas fa-desktop"></i> کنترل دسکتاپ</a>
    <a href="admin_boxoffice.php"><i class="fas fa-chart-bar"></i> باکس آفیس</a>

    <div class="bm-sidebar-group-label"><span>امنیت و نگهداری</span></div>
    <a href="admin_health.php"><i class="fas fa-stethoscope"></i> عیب‌یابی سرور</a>
    <a href="#" onclick="scrollToSection('backupSection'); return false;"><i class="fas fa-database"></i> بکاپ</a>
    <a href="#" onclick="scrollToSection('activitySection'); return false;"><i class="fas fa-clock-rotate-left"></i> لاگ فعالیت</a>
    <a href="#" onclick="scrollToSection('weeklyReportSection'); return false;"><i class="fas fa-chart-line"></i> گزارش هفتگی</a>
    <a href="#" onclick="scrollToSection('trashSection'); return false;"><i class="fas fa-recycle"></i> سطل بازیافت</a>
  </div>
  
  <div class="sidebar-footer">
    <a href="/logout" class="logout-btn" onclick="return confirm('خروج از پنل؟')">
      <i class="fas fa-sign-out-alt"></i>
      خروج
    </a>
  </div>
</aside>

<!-- Theme Switcher -->
<div class="theme-dock" aria-label="انتخاب تم پنل">
  <button type="button" data-theme="neon" class="theme-chip active" title="Neon Green"></button>
  <button type="button" data-theme="purple" class="theme-chip theme-purple-chip" title="Purple Cinema"></button>
  <button type="button" data-theme="red" class="theme-chip theme-red-chip" title="Red Netflix"></button>
  <button type="button" data-theme="gold" class="theme-chip theme-gold-chip" title="Gold Premium"></button>
</div>

<!-- Main Content -->
<main class="main-content" id="mainContent">
<section class="admin-command-search" id="adminCommandSearch" data-search-endpoint="/admin_settings_search.php">
  <div class="admin-command-box">
    <i class="fas fa-magnifying-glass"></i>
    <input type="search" id="adminGlobalSearch" autocomplete="off" spellcheck="false" placeholder="جستجو فقط در تنظیمات پنل؛ فیلم و سریال سرچ خودشان را دارند..." aria-label="جستجو در تنظیمات پنل مدیریت" aria-controls="adminSearchResults" aria-expanded="false">
    <kbd>Ctrl K</kbd>
  </div>
  <div class="admin-search-results" id="adminSearchResults" role="listbox" aria-label="نتایج جستجوی تنظیمات مدیریت"></div>
</section>

<div class="admin-fast-toolbar" id="adminFastToolbar">
  <div>
    <div class="admin-fast-title"><i class="fas fa-bolt"></i><span id="adminFastTitle">داشبورد سریع</span></div>
    <div class="admin-fast-hint">برای سبک شدن پنل فقط بخش انتخاب‌شده نمایش داده می‌شود؛ داشبورد و ابزارهای اصلی جداگانه باز می‌شوند.</div>
  </div>
  <button type="button" class="btn btn-outline btn-sm" onclick="openAdminSection('commandCenterSection', true)">
    <i class="fas fa-gauge-high"></i> داشبورد
  </button>
</div>

<section class="glass-card bm-sec2" id="securityCenterSection">
  <div class="bm-sec2-head">
    <div class="bm-sec2-heading">
      <div class="bm-sec2-logo"><i class="fas fa-shield-halved"></i></div>
      <div>
        <div class="bm-sec2-eyebrow"><i class="fas fa-wave-square"></i> BankMovie Security Center</div>
        <h2>امنیت و Anti-Spam</h2>
        <p>نمای زنده محافظ سایت، مسدودی‌ها و تنظیمات Rate Limit؛ بدون دخالت APIهای اپ در Global Block.</p>
      </div>
    </div>
    <div class="bm-sec2-controls">
      <span class="bm-sec2-live <?= $bmSecurityEnabled ? 'on' : 'off' ?>"><span class="bm-sec2-dot"></span><?= $bmSecurityEnabled ? 'محافظ فعال' : 'محافظ خاموش' ?></span>
      <form method="POST" action="admin.php?admin_section=securityCenterSection#securityCenterSection">
        <?= admin_csrf_input() ?><input type="hidden" name="admin_security_action" value="toggle">
        <button type="submit" class="btn <?= $bmSecurityEnabled ? 'btn-danger' : 'btn-primary' ?> btn-sm"><i class="fas fa-power-off"></i> <?= $bmSecurityEnabled ? 'خاموش کردن' : 'روشن کردن' ?></button>
      </form>
    </div>
  </div>

  <div class="bm-sec2-protection">
    <div class="bm-sec2-status-card">
      <div class="bm-sec2-status-top">
        <span class="bm-sec2-status-title"><i class="fas fa-shield-heart"></i> وضعیت محافظت</span>
        <span class="badge <?= $bmSecurityEnabled ? 'badge-success' : 'badge-danger' ?>"><?= $bmSecurityEnabled ? 'ONLINE' : 'OFFLINE' ?></span>
      </div>
      <strong><?= (int)($bmSecurityCfg['limit'] ?? 20) ?> درخواست / <?= (int)($bmSecurityCfg['window'] ?? 60) ?> ثانیه</strong>
      <p>در صورت عبور از سقف، کاربر عادی برای <?= max(1, (int)ceil(((int)($bmSecurityCfg['penalty'] ?? 300))/60)) ?> دقیقه محدود می‌شود و می‌تواند با CAPTCHA محدودیت را رفع کند.</p>
      <div class="bm-sec2-chips">
        <span class="bm-sec2-chip"><i class="fas fa-crown"></i> Admin/VIP Bypass</span>
        <span class="bm-sec2-chip"><i class="fas fa-mobile-screen"></i> App/API خارج از Global Block</span>
        <span class="bm-sec2-chip"><i class="fas fa-database"></i> Pre-DB Guard</span>
      </div>
    </div>
    <div class="bm-sec2-kpis">
      <div class="bm-sec2-kpi hot"><div class="bm-sec2-kpi-head"><span class="bm-sec2-kpi-icon"><i class="fas fa-triangle-exclamation"></i></span><b><?= number_format((int)($bmSecurityStats['today_violations'] ?? 0)) ?></b></div><small>عبور از سقف امروز</small></div>
      <div class="bm-sec2-kpi"><div class="bm-sec2-kpi-head"><span class="bm-sec2-kpi-icon"><i class="fas fa-user-secret"></i></span><b><?= number_format((int)($bmSecurityStats['today_attack_ips'] ?? 0)) ?></b></div><small>IP مشکوک امروز</small></div>
      <div class="bm-sec2-kpi"><div class="bm-sec2-kpi-head"><span class="bm-sec2-kpi-icon"><i class="fas fa-hand"></i></span><b><?= number_format((int)($bmSecurityStats['today_blocked_hits'] ?? 0)) ?></b></div><small>درخواست دفع‌شده</small></div>
      <div class="bm-sec2-kpi hot"><div class="bm-sec2-kpi-head"><span class="bm-sec2-kpi-icon"><i class="fas fa-ban"></i></span><b><?= number_format((int)($bmSecurityStats['active'] ?? 0)) ?></b></div><small>مسدودی فعال</small></div>
      <div class="bm-sec2-kpi good"><div class="bm-sec2-kpi-head"><span class="bm-sec2-kpi-icon"><i class="fas fa-circle-check"></i></span><b><?= number_format((int)($bmSecurityStats['captcha_success'] ?? 0)) ?></b></div><small>CAPTCHA موفق</small></div>
      <div class="bm-sec2-kpi"><div class="bm-sec2-kpi-head"><span class="bm-sec2-kpi-icon"><i class="fas fa-satellite-dish"></i></span><b><?= number_format((int)($bmSecurityStats['recent_ips'] ?? 0)) ?></b></div><small>IP دیده‌شده ۲۴ ساعت</small></div>
    </div>
  </div>

  <div class="bm-sec2-alert"><i class="fas fa-circle-info"></i><div><strong>حالت سازگار با اپ فعال است.</strong> API/AJAX سهمیه Page View را مصرف نمی‌کنند و Global Block سایت روی APIهای اپ اعمال نمی‌شود. Blacklist دستی همچنان مستقل است.</div></div>

  <div class="bm-sec2-dashboard">
    <div class="bm-sec2-box">
      <div class="bm-sec2-box-head"><div class="bm-sec2-box-title"><i class="fas fa-chart-line"></i> فعالیت امنیتی اخیر</div><small>آخرین رخدادها و مقصدهای پرتکرار</small></div>
      <div class="bm-sec2-activity">
        <div class="bm-sec2-events">
          <?php if($bmSecurityEvents): foreach($bmSecurityEvents as $secEvent):
            $secEventType = (string)($secEvent['event'] ?? 'security_event');
            $secEventLabel = $bmSecurityEventLabels[$secEventType] ?? $secEventType;
            $secEventIp = (string)($secEvent['ip'] ?? '—');
            $secEventUri = (string)($secEvent['uri'] ?? $secEvent['target'] ?? '/');
            $secEventTimeRaw = (string)($secEvent['time'] ?? '');
            $secEventTs = $secEventTimeRaw !== '' ? (int)strtotime($secEventTimeRaw) : 0;
          ?>
          <div class="bm-sec2-event">
            <span class="bm-sec2-event-icon"><i class="fas <?= str_contains($secEventType,'captcha') ? 'fa-key' : (str_contains($secEventType,'unblock') ? 'fa-unlock' : 'fa-shield') ?>"></i></span>
            <div><b><?= htmlspecialchars($secEventLabel, ENT_QUOTES, 'UTF-8') ?> · <?= htmlspecialchars($secEventIp, ENT_QUOTES, 'UTF-8') ?></b><span><?= htmlspecialchars($secEventUri, ENT_QUOTES, 'UTF-8') ?></span></div>
            <time><?= $secEventTs > 0 ? date('H:i', $secEventTs) : '—' ?></time>
          </div>
          <?php endforeach; else: ?>
          <div class="bm-sec2-empty"><i class="fas fa-shield-check"></i>هنوز رویداد امنیتی جدیدی ثبت نشده.</div>
          <?php endif; ?>
        </div>
        <div class="bm-sec2-targets">
          <h4>هدف‌های پرتکرار امروز</h4>
          <?php if($bmSecurityTargets): foreach($bmSecurityTargets as $secTarget => $secTargetCount): $secPct = $bmSecurityTargetMax > 0 ? max(6, min(100, (int)round(((int)$secTargetCount/$bmSecurityTargetMax)*100))) : 0; ?>
          <div class="bm-sec2-target"><div class="bm-sec2-target-row"><code><?= htmlspecialchars((string)$secTarget, ENT_QUOTES, 'UTF-8') ?></code><b><?= number_format((int)$secTargetCount) ?></b></div><div class="bm-sec2-target-track"><span style="width:<?= $secPct ?>%"></span></div></div>
          <?php endforeach; else: ?><div class="bm-sec2-empty"><i class="fas fa-chart-simple"></i>داده‌ای برای امروز نیست.</div><?php endif; ?>
        </div>
      </div>
    </div>

    <div class="bm-sec2-box">
      <div class="bm-sec2-box-head"><div class="bm-sec2-box-title"><i class="fas fa-ban"></i> مسدودی‌های فعال</div><span class="badge <?= !empty($bmSecurityReport['active']) ? 'badge-danger' : 'badge-success' ?>"><?= number_format(count((array)($bmSecurityReport['active'] ?? []))) ?></span></div>
      <div class="bm-sec2-blocks">
        <?php if(!empty($bmSecurityReport['active'])): foreach(array_slice((array)$bmSecurityReport['active'],0,8) as $secBlock): ?>
          <div class="bm-sec2-block">
            <span class="bm-sec2-block-icon"><i class="fas fa-user-lock"></i></span>
            <div><strong><?= htmlspecialchars((string)($secBlock['ip'] ?? ''), ENT_QUOTES, 'UTF-8') ?></strong><small>تا <?= !empty($secBlock['blocked_until']) ? date('H:i:s', (int)$secBlock['blocked_until']) : '—' ?> · <?= htmlspecialchars((string)($secBlock['last_uri'] ?? '/'), ENT_QUOTES, 'UTF-8') ?></small></div>
            <form method="POST" action="admin.php?admin_section=securityCenterSection#securityCenterSection"><?= admin_csrf_input() ?><input type="hidden" name="admin_security_action" value="unblock"><input type="hidden" name="rate_ip" value="<?= htmlspecialchars((string)($secBlock['ip'] ?? ''), ENT_QUOTES, 'UTF-8') ?>"><button class="btn btn-outline btn-sm" type="submit">رفع</button></form>
          </div>
        <?php endforeach; else: ?><div class="bm-sec2-empty"><i class="fas fa-circle-check"></i>هیچ مسدودی فعالی وجود ندارد.</div><?php endif; ?>
      </div>
      <form class="bm-sec2-quick" method="POST" action="admin.php?admin_section=securityCenterSection#securityCenterSection">
        <?= admin_csrf_input() ?><input type="hidden" name="admin_security_action" value="manual_block">
        <input type="text" name="rate_ip" placeholder="IP برای بلاک" required><input type="number" name="rate_minutes" min="1" max="1440" value="5" title="دقیقه"><button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-ban"></i> بلاک</button>
      </form>
      <div class="bm-sec2-block-actions">
        <form method="POST" action="admin.php?admin_section=securityCenterSection#securityCenterSection" onsubmit="return confirm('همه شمارنده‌ها و بلاک‌های موقت ریست شوند؟')"><?= admin_csrf_input() ?><input type="hidden" name="admin_security_action" value="reset"><button type="submit" class="btn btn-outline btn-sm"><i class="fas fa-rotate"></i> ریست موقت‌ها</button></form>
      </div>
    </div>
  </div>

  <div class="bm-sec2-settings">
    <div class="bm-sec2-settings-head"><div><h3><i class="fas fa-sliders"></i> تنظیمات محافظ</h3><p>تنظیمات بر اساس کاربرد دسته‌بندی شده‌اند تا صفحه شلوغ نشود.</p></div><span class="badge badge-gray">Advanced Controls</span></div>
    <form method="POST" action="admin.php?admin_section=securityCenterSection#securityCenterSection">
      <?= admin_csrf_input() ?><input type="hidden" name="admin_security_action" value="save">
      <div class="bm-sec2-groups">
        <details class="bm-sec2-group" open>
          <summary><i class="fas fa-gauge-high"></i><span>Rate Limit اصلی</span><i class="fas fa-chevron-down"></i></summary>
          <div class="bm-sec2-group-body">
            <label class="bm-sec2-toggle"><input class="bm-no-neon" type="checkbox" name="rate_enabled" <?= $bmSecurityEnabled ? 'checked' : '' ?>><span class="bm-sec2-switch" aria-hidden="true"></span><span class="bm-sec2-toggle-copy"><strong>Anti-Spam فعال</strong>Enforcement عمومی سایت.</span></label>
            <label class="bm-sec2-toggle"><input class="bm-no-neon" type="checkbox" name="rate_privileged_bypass" <?= !array_key_exists('privileged_bypass',$bmSecurityCfg) || !empty($bmSecurityCfg['privileged_bypass']) ? 'checked' : '' ?>><span class="bm-sec2-switch" aria-hidden="true"></span><span class="bm-sec2-toggle-copy"><strong>Admin/VIP Bypass</strong>کاربران ویژه از محدودیت خودکار عبور کنند.</span></label>
            <div class="bm-sec2-fields">
              <div class="bm-sec2-field"><label>Page Limit</label><input type="number" name="rate_limit" min="1" max="5000" value="<?= (int)($bmSecurityCfg['limit'] ?? 20) ?>"></div>
              <div class="bm-sec2-field"><label>Search Limit / min</label><input type="number" name="rate_search_limit" min="1" max="5000" value="<?= (int)($bmSecurityCfg['search_limit'] ?? 40) ?>"></div>
              <div class="bm-sec2-field"><label>Window (sec)</label><input type="number" name="rate_window" min="10" max="3600" value="<?= (int)($bmSecurityCfg['window'] ?? 60) ?>"></div>
              <div class="bm-sec2-field"><label>Block Duration</label><input type="number" name="rate_penalty" min="60" max="86400" value="<?= (int)($bmSecurityCfg['penalty'] ?? 300) ?>"></div>
              <div class="bm-sec2-field full"><label>Multi-layer Limit</label><div style="padding:11px 13px;border:1px solid rgba(65,211,168,.22);background:rgba(65,211,168,.06);border-radius:12px;color:var(--muted);font-size:12px;line-height:1.9">IP، Visitor، Session و User همگی دقیقاً از <b style="color:var(--text)">Page Limit</b> پیروی می‌کنند. <b style="color:var(--text)">Search Limit</b> مستقل است: پیش‌فرض ۴۰ جستجو در ۶۰ ثانیه و عبور از آن فقط خود Search را محدود می‌کند.</div></div>
            </div>
          </div>
        </details>

        <details class="bm-sec2-group">
          <summary><i class="fas fa-key"></i><span>CAPTCHA و Escalation</span><i class="fas fa-chevron-down"></i></summary>
          <div class="bm-sec2-group-body">
            <label class="bm-sec2-toggle"><input class="bm-no-neon" type="checkbox" name="rate_challenge_enabled" <?= !empty($bmSecurityCfg['challenge_enabled']) ? 'checked' : '' ?>><span class="bm-sec2-switch" aria-hidden="true"></span><span class="bm-sec2-toggle-copy"><strong>CAPTCHA فعال</strong>رفع خودکار محدودیت برای انسان واقعی.</span></label>
            <label class="bm-sec2-toggle"><input class="bm-no-neon" type="checkbox" name="rate_escalation_enabled" <?= !empty($bmSecurityCfg['escalation_enabled']) ? 'checked' : '' ?>><span class="bm-sec2-switch" aria-hidden="true"></span><span class="bm-sec2-toggle-copy"><strong>Escalation فعال</strong>تخلف تکراری مجازات بیشتری بگیرد.</span></label>
            <div class="bm-sec2-fields">
              <div class="bm-sec2-field"><label>CAPTCHA TTL</label><input type="number" name="rate_challenge_ttl" min="60" max="900" value="<?= (int)($bmSecurityCfg['challenge_ttl'] ?? 300) ?>"></div>
              <div class="bm-sec2-field"><label>Min solve ms</label><input type="number" name="rate_challenge_min_age_ms" min="700" max="10000" value="<?= (int)($bmSecurityCfg['challenge_min_age_ms'] ?? 1200) ?>"></div>
              <div class="bm-sec2-field"><label>Wrong Attempts</label><input type="number" name="rate_captcha_attempts" min="1" max="10" value="<?= (int)($bmSecurityCfg['captcha_attempts'] ?? 3) ?>"></div>
              <div class="bm-sec2-field"><label>Human Pass TTL</label><input type="number" name="rate_captcha_pass_ttl" min="60" max="3600" value="<?= (int)($bmSecurityCfg['captcha_pass_ttl'] ?? 600) ?>"></div>
              <div class="bm-sec2-field"><label>Escalation Window</label><input type="number" name="rate_escalation_duration" min="300" max="86400" value="<?= (int)($bmSecurityCfg['escalation_duration'] ?? 3600) ?>"></div>
              <div class="bm-sec2-field"><label>Escalation ×</label><input type="number" name="rate_escalation_multiplier" min="2" max="10" value="<?= (int)($bmSecurityCfg['escalation_multiplier'] ?? 3) ?>"></div>
              <div class="bm-sec2-field full"><label>Max Penalty</label><input type="number" name="rate_escalation_max_penalty" min="60" max="86400" value="<?= (int)($bmSecurityCfg['escalation_max_penalty'] ?? 3600) ?>"></div>
            </div>
          </div>
        </details>

        <details class="bm-sec2-group">
          <summary><i class="fas fa-folder-shield"></i><span>محافظت فایل و 404</span><i class="fas fa-chevron-down"></i></summary>
          <div class="bm-sec2-group-body">
            <label class="bm-sec2-toggle"><input class="bm-no-neon" type="checkbox" name="file_protection_enabled" <?= !array_key_exists('file_protection_enabled',$bmSecurityCfg) || !empty($bmSecurityCfg['file_protection_enabled']) ? 'checked' : '' ?>><span class="bm-sec2-switch" aria-hidden="true"></span><span class="bm-sec2-toggle-copy"><strong>File Protection اصلی</strong>قوانین فایل و پوشه قبل از PHP در .htaccess اجرا شوند.</span></label>
            <label class="bm-sec2-toggle"><input class="bm-no-neon" type="checkbox" name="file_block_archives" <?= !array_key_exists('file_block_archives',$bmSecurityCfg) || !empty($bmSecurityCfg['file_block_archives']) ? 'checked' : '' ?>><span class="bm-sec2-switch" aria-hidden="true"></span><span class="bm-sec2-toggle-copy"><strong>ZIP / Archive فقط داخل /app/</strong>ZIP/RAR/TAR/GZ خارج از پوشه app با 403 بسته شوند.</span></label>
            <label class="bm-sec2-toggle"><input class="bm-no-neon" type="checkbox" name="file_block_backups" <?= !array_key_exists('file_block_backups',$bmSecurityCfg) || !empty($bmSecurityCfg['file_block_backups']) ? 'checked' : '' ?>><span class="bm-sec2-switch" aria-hidden="true"></span><span class="bm-sec2-toggle-copy"><strong>Backup / Database Files</strong>SQL، BAK، DUMP و نسخه‌های قدیمی مستقیم دانلود نشوند.</span></label>
            <label class="bm-sec2-toggle"><input class="bm-no-neon" type="checkbox" name="file_block_secrets" <?= !array_key_exists('file_block_secrets',$bmSecurityCfg) || !empty($bmSecurityCfg['file_block_secrets']) ? 'checked' : '' ?>><span class="bm-sec2-switch" aria-hidden="true"></span><span class="bm-sec2-toggle-copy"><strong>Secret / Config Files</strong>.env، KEY، PEM، INI، config و فایل‌های credential از وب بسته باشند.</span></label>
            <label class="bm-sec2-toggle"><input class="bm-no-neon" type="checkbox" name="file_block_upload_exec" <?= !array_key_exists('file_block_upload_exec',$bmSecurityCfg) || !empty($bmSecurityCfg['file_block_upload_exec']) ? 'checked' : '' ?>><span class="bm-sec2-switch" aria-hidden="true"></span><span class="bm-sec2-toggle-copy"><strong>جلوگیری از اجرای Script در Upload</strong>PHP/PHTML/PHAR و double-extension داخل uploads/posters/avatars اجرا نشوند.</span></label>
            <label class="bm-sec2-toggle"><input class="bm-no-neon" type="checkbox" name="file_block_directory_listing" <?= !array_key_exists('file_block_directory_listing',$bmSecurityCfg) || !empty($bmSecurityCfg['file_block_directory_listing']) ? 'checked' : '' ?>><span class="bm-sec2-switch" aria-hidden="true"></span><span class="bm-sec2-toggle-copy"><strong>Directory Listing</strong>پوشه بدون index لیست فایل‌ها را نمایش ندهد.</span></label>
            <label class="bm-sec2-toggle"><input class="bm-no-neon" type="checkbox" name="rate_error_abuse_enabled" <?= !array_key_exists('error_abuse_enabled',$bmSecurityCfg) || !empty($bmSecurityCfg['error_abuse_enabled']) ? 'checked' : '' ?>><span class="bm-sec2-switch" aria-hidden="true"></span><span class="bm-sec2-toggle-copy"><strong>404 / 4xx Abuse Guard</strong>درخواست‌های خطای پشت‌سرهم از یک IP وارد Anti-Spam شوند.</span></label>
            <div class="bm-sec2-fields">
              <div class="bm-sec2-field"><label>4xx معمولی / min</label><input type="number" name="rate_error_limit" min="1" max="5000" value="<?= (int)($bmSecurityCfg['error_limit'] ?? 40) ?>"></div>
              <div class="bm-sec2-field"><label>Static Asset Miss / min</label><input type="number" name="rate_asset_error_limit" min="10" max="5000" value="<?= (int)($bmSecurityCfg['asset_error_limit'] ?? 120) ?>"></div>
              <div class="bm-sec2-field"><label>Probe خطرناک / min</label><input type="number" name="rate_probe_error_limit" min="1" max="100" value="<?= (int)($bmSecurityCfg['probe_error_limit'] ?? 8) ?>"></div>
              <div class="bm-sec2-field full"><label>رفتار Guard هوشمند v3.6</label><div style="padding:11px 13px;border:1px solid rgba(65,211,168,.22);background:rgba(65,211,168,.06);border-radius:12px;color:var(--muted);font-size:12px;line-height:1.9">خطای معمولی پیش‌فرض <b style="color:var(--text)">40/min</b> است. Probeهای واضح مثل <b style="color:var(--text)">.env / config.js / wp-login.php / simple.php</b> با سقف سخت‌تر <b style="color:var(--text)">8/min</b> کنترل می‌شوند. Asset گمشده‌ای که مستقیم کوبیده شود سقف مستقل <b style="color:var(--text)">120/min</b> دارد؛ اما Asset خراب که واقعاً از داخل صفحه خود BankMovie به‌عنوان image/css/js درخواست شده باشد، کاربر واقعی را Global Block نمی‌کند. خطاهای 5xx شمرده نمی‌شوند و /app/ و APIهای واقعی اپ همچنان خارج‌اند.</div></div>
            </div>
          </div>
        </details>

        <details class="bm-sec2-group">
          <summary><i class="fas fa-list-check"></i><span>دسترسی و لاگ‌ها</span><i class="fas fa-chevron-down"></i></summary>
          <div class="bm-sec2-group-body">
            <label class="bm-sec2-toggle"><input class="bm-no-neon" type="checkbox" name="rate_endpoint_global_block" <?= !empty($bmSecurityCfg['endpoint_global_block']) ? 'checked' : '' ?>><span class="bm-sec2-switch" aria-hidden="true"></span><span class="bm-sec2-toggle-copy"><strong>Endpoint Global Block</strong>فقط برای Endpointهای غیر API طبق v2.3.</span></label>
            <label class="bm-sec2-toggle"><input class="bm-no-neon" type="checkbox" name="rate_app_bypass" <?= !empty($bmSecurityCfg['app_bypass']) ? 'checked' : '' ?>><span class="bm-sec2-switch" aria-hidden="true"></span><span class="bm-sec2-toggle-copy"><strong>App HMAC Bypass</strong>رفتار سازگاری موجود حفظ شود.</span></label>
            <label class="bm-sec2-toggle"><input class="bm-no-neon" type="checkbox" name="rate_log_enabled" <?= !empty($bmSecurityCfg['log_enabled']) ? 'checked' : '' ?>><span class="bm-sec2-switch" aria-hidden="true"></span><span class="bm-sec2-toggle-copy"><strong>Security Logging</strong>رخدادهای امنیتی ثبت شوند.</span></label>
            <div class="bm-sec2-fields">
              <div class="bm-sec2-field full"><label>Whitelist · هر IP/CIDR یک خط</label><textarea name="rate_whitelist"><?= htmlspecialchars($bmSecurityWhitelist, ENT_QUOTES, 'UTF-8') ?></textarea></div>
              <div class="bm-sec2-field full"><label>Blacklist · هر IP/CIDR یک خط</label><textarea name="rate_blacklist"><?= htmlspecialchars($bmSecurityBlacklist, ENT_QUOTES, 'UTF-8') ?></textarea></div>
            </div>
          </div>
        </details>
      </div>
      <div class="bm-sec2-save"><span><b><i class="fas fa-circle-info"></i> نکته:</b> Page Limit برای صفحات عادی است؛ Search Limit مستقل و همیشه بر مبنای ۶۰ ثانیه است. تغییر هر عدد فوراً روی Policy جدید اعمال می‌شود.</span><button type="submit" class="btn btn-primary"><i class="fas fa-floppy-disk"></i> ذخیره تنظیمات امنیتی</button></div>
    </form>
  </div>
</section>

<!-- Ultra Professional Hero -->
<section class="dashboard-hero admin-stagger">
  <div class="hero-copy">
    <div class="hero-eyebrow"><i class="fas fa-shield-alt"></i> کنترل‌سنتر حرفه‌ای BankMovie</div>
    <h1 class="hero-title">پنل مدیریت <span>سینمایی و پریمیوم</span></h1>
    <p class="hero-subtitle">
      مدیریت فیلم‌ها، سریال‌ها، درخواست‌ها، کامنت‌ها، استوری‌ها و انتخاب‌های ادمین در یک داشبورد شیشه‌ای، سریع و مرتب.
    </p>
    <div class="hero-actions">
      <a href="#" onclick="scrollToSection('addMovieSection'); return false;" class="btn btn-primary">
        <i class="fas fa-plus-circle"></i> افزودن محتوای جدید
      </a>
      <a href="#" onclick="scrollToSection('commentsSection'); return false;" class="btn btn-outline">
        <i class="fas fa-comments"></i> بررسی نظرات
      </a>
      <a href="#" onclick="scrollToSection('requestsSection'); return false;" class="btn btn-outline">
        <i class="fas fa-inbox"></i> درخواست‌های کاربران
      </a>
    </div>
  </div>
  <div class="hero-panel">
    <div class="hero-mini-card">
      <i class="fas fa-film"></i>
      <span class="hero-mini-value"><?= number_format($totalMovies) ?></span>
      <span class="hero-mini-label">کل محتوا</span>
    </div>
    <div class="hero-mini-card">
      <i class="fas fa-users"></i>
      <span class="hero-mini-value"><?= number_format($totalUsers) ?></span>
      <span class="hero-mini-label">کاربر ثبت‌شده</span>
    </div>
    <div class="hero-mini-card">
      <i class="fas fa-clock"></i>
      <span class="hero-mini-value"><?= number_format($totalPendingComments) ?></span>
      <span class="hero-mini-label">نظر در انتظار</span>
    </div>
    <div class="hero-mini-card">
      <i class="fas fa-trophy"></i>
      <span class="hero-mini-value"><?= number_format($totalAdminPicks) ?></span>
      <span class="hero-mini-label">انتخاب ادمین</span>
    </div>
  </div>
</section>


<?php if($message): ?>
<div class="toast" id="gToast">
  <i class="fas fa-check-circle"></i>
  <?= htmlspecialchars($message) ?>
</div>
<script>setTimeout(()=>document.getElementById('gToast')?.remove(), 3500);</script>
<?php endif; ?>
<?php if(!empty($adminPanelHealth['errors'])): ?>
<div class="glass-card" style="border-color:rgba(251,113,133,.48);margin-bottom:20px">
  <div class="card-body"><strong style="color:#fb7185">بررسی هاست چند مشکل پیدا کرد:</strong>
    <ul style="margin:12px 20px 0;line-height:2;color:var(--text-secondary)"><?php foreach($adminPanelHealth['errors'] as $healthError): ?><li><?= admin_escape($healthError) ?></li><?php endforeach; ?></ul>
    <a class="btn btn-outline btn-sm" href="admin_health.php" style="margin-top:12px">باز کردن عیب‌یابی کامل</a>
  </div>
</div>
<?php endif; ?>

<!-- Command Center -->
<section class="command-grid" id="commandCenterSection">
  <div class="glass-card command-card command-alerts">
    <div class="card-header"><h3><i class="fas fa-triangle-exclamation"></i> هشدارهای فوری</h3><span class="badge badge-warning"><?= number_format($totalIncompleteMovies) ?> نیازمند بررسی</span></div>
    <div class="card-body compact-body">
      <a class="alert-row" href="#" onclick="scrollToSection('commentsSection'); return false;"><i class="fas fa-comments"></i><span>کامنت در انتظار</span><strong><?= number_format($totalPendingComments) ?></strong></a>
      <a class="alert-row" href="#" onclick="scrollToSection('requestsSection'); return false;"><i class="fas fa-inbox"></i><span>درخواست pending</span><strong><?= number_format($pendingRequests) ?></strong></a>
      <a class="alert-row" href="#" onclick="scrollToSection('missingSection'); return false;"><i class="fas fa-image"></i><span>بدون کاور</span><strong><?= number_format($totalMissingPosters) ?></strong></a>
      <a class="alert-row" href="#" onclick="scrollToSection('healthSection'); return false;"><i class="fas fa-link-slash"></i><span>بدون لینک دانلود</span><strong><?= number_format($totalNoLinks) ?></strong></a>
      <a class="alert-row" href="#" onclick="scrollToSection('healthSection'); return false;"><i class="fas fa-barcode"></i><span>بدون IMDb Code</span><strong><?= number_format($totalNoImdb) ?></strong></a>
    </div>
  </div>

  <div class="glass-card command-card">
    <div class="card-header"><h3><i class="fas fa-bolt"></i> نبض امروز سایت</h3><span class="badge badge-success"><?= date('Y/m/d') ?></span></div>
    <div class="card-body compact-body">
      <div class="pulse-grid">
        <div class="pulse-item"><span><?= number_format($todayMovies) ?></span><small>محتوای جدید</small></div>
        <div class="pulse-item"><span><?= number_format($todayUsers) ?></span><small>کاربر جدید</small></div>
        <div class="pulse-item"><span><?= number_format($todayComments) ?></span><small>کامنت امروز</small></div>
        <div class="pulse-item"><span><?= number_format($todayRequests) ?></span><small>درخواست امروز</small></div>
        <div class="pulse-item"><span><?= number_format($bmLiveVisitors) ?></span><small>کاربر آنلاین</small></div>
        <div class="pulse-item"><span><?= number_format($bmTodayVisits) ?></span><small>بازدید امروز</small></div>
      </div>
      <div class="quick-actions-row">
        <a href="#" onclick="scrollToSection('omdbSection'); return false;" class="btn btn-primary btn-sm"><i class="fas fa-wand-magic-sparkles"></i> ایمپورت سریع</a>
        <a href="#" onclick="scrollToSection('healthSection'); return false;" class="btn btn-outline btn-sm"><i class="fas fa-stethoscope"></i> عیب‌یابی محتوا</a>
      </div>
    </div>
  </div>

  <div class="glass-card command-card">
    <div class="card-header"><h3><i class="fas fa-clock-rotate-left"></i> فعالیت‌های اخیر</h3><a href="#" onclick="scrollToSection('activitySection'); return false;" class="btn btn-outline btn-sm">مشاهده کامل</a></div>
    <div class="card-body compact-body">
      <div class="mini-timeline">
        <?php foreach(array_slice($recentActivity,0,6) as $act): ?>
        <div class="timeline-item-mini">
          <span class="timeline-dot"></span>
          <div><strong><?= htmlspecialchars($act['action'] ?? 'activity') ?></strong><small><?= htmlspecialchars($act['details'] ?? '') ?> · <?= !empty($act['created_at']) ? date('Y/m/d H:i', strtotime($act['created_at'])) : '—' ?></small></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>


<div class="glass-card" id="popularVisitsSection">
  <div class="card-header"><h3><i class="fas fa-fire-flame-curved"></i> فیلم‌های پربازدید سایت</h3><span class="badge badge-info">۳۰ روز اخیر</span></div>
  <div class="card-body compact-body">
    <?php if(!empty($bmPopularVisitedMovies)): ?>
    <div class="table-wrapper"><table class="data-table pro-table"><thead><tr><th>عنوان</th><th>نوع</th><th>IMDb</th><th>بازدید</th><th>عملیات</th></tr></thead><tbody>
      <?php foreach($bmPopularVisitedMovies as $pm): ?>
      <tr>
        <td><strong><?= htmlspecialchars($pm['title_fa'] ?: $pm['title']) ?></strong><br><small><?= htmlspecialchars($pm['title'] ?? '') ?></small></td>
        <td><span class="badge badge-info"><?= (($pm['type'] ?? '') === 'movie') ? 'فیلم' : 'سریال' ?></span></td>
        <td><?= htmlspecialchars($pm['imdb_code'] ?? '—') ?></td>
        <td><strong><?= number_format((int)($pm['view_count'] ?? 0)) ?></strong></td>
        <td><a class="btn btn-outline btn-sm" href="/movie/<?= rawurlencode(preg_replace('~[^a-z0-9]+~i','-', strtolower($pm['title'] ?: 'movie'))) ?>-<?= (int)$pm['id'] ?>" target="_blank">مشاهده</a></td>
      </tr>
      <?php endforeach; ?>
    </tbody></table></div>
    <?php else: ?>
    <div class="empty-state">هنوز بازدیدی برای فیلم‌ها ثبت نشده است.</div>
    <?php endif; ?>
  </div>
</div>

<!-- Content Health -->
<div class="glass-card" id="healthSection">
  <div class="card-header">
    <h3><i class="fas fa-heart-pulse"></i> سیستم سلامت محتوا</h3>
    <span class="badge <?= $healthScore >= 80 ? 'badge-success' : ($healthScore >= 55 ? 'badge-warning' : 'badge-danger') ?>">امتیاز سلامت <?= $healthScore ?>٪</span>
  </div>
  <div class="card-body">
    <div class="health-overview">
      <div class="health-score" style="--score: <?= (int)$healthScore ?>"><span><?= (int)$healthScore ?>%</span><small>Content Health</small></div>
      <div class="health-grid">
        <div class="health-card"><i class="fas fa-image"></i><strong><?= number_format($totalMissingPosters) ?></strong><span>بدون کاور</span></div>
        <div class="health-card"><i class="fas fa-link-slash"></i><strong><?= number_format($totalNoLinks) ?></strong><span>بدون لینک</span></div>
        <div class="health-card"><i class="fas fa-align-left"></i><strong><?= number_format($totalNoDescriptions) ?></strong><span>بدون توضیح</span></div>
        <div class="health-card"><i class="fas fa-tags"></i><strong><?= number_format($totalNoGenres) ?></strong><span>بدون ژانر</span></div>
        <div class="health-card"><i class="fab fa-imdb"></i><strong><?= number_format($totalNoImdb) ?></strong><span>بدون IMDb</span></div>
        <div class="health-card"><i class="fas fa-star-half-stroke"></i><strong><?= number_format($totalLowRated) ?></strong><span>امتیاز پایین</span></div>
      </div>
    </div>
    <div class="section-subtitle"><i class="fas fa-list-check"></i> محتوای نیازمند تکمیل</div>
    <div class="table-wrapper">
      <table class="data-table pro-table">
        <thead><tr><th>عنوان</th><th>نوع</th><th>سال</th><th>لینک</th><th>IMDb</th><th>عملیات</th></tr></thead>
        <tbody>
          <?php if($incompleteMovies): foreach($incompleteMovies as $m): ?>
          <tr>
            <td><strong><?= htmlspecialchars($m['title_fa'] ?: $m['title']) ?></strong></td>
            <td><span class="badge badge-info"><?= ($m['type'] ?? '') === 'movie' ? 'فیلم' : 'سریال' ?></span></td>
            <td><?= htmlspecialchars((string)($m['year'] ?? '—')) ?></td>
            <td><span class="badge <?= ((int)($m['link_count'] ?? 0) > 0) ? 'badge-success' : 'badge-danger' ?>"><?= number_format((int)($m['link_count'] ?? 0)) ?></span></td>
            <td><?= htmlspecialchars($m['imdb_code'] ?: 'ندارد') ?></td>
            <td><a href="admin_edit_movie.php?id=<?= (int)$m['id'] ?>" class="btn btn-outline btn-sm">تکمیل</a></td>
          </tr>
          <?php endforeach; else: ?>
          <tr><td colspan="6" style="text-align:center; padding:30px;">همه‌چیز مرتب است 🎬</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Professional Charts Row -->
<div class="stats-charts-row">
  <div class="chart-card">
    <h4><i class="fas fa-chart-bar"></i> توزیع محتوا</h4>
    <div class="chart-container">
      <canvas id="statsBarChart"></canvas>
    </div>
  </div>
  <div class="chart-card">
    <h4><i class="fas fa-chart-pie"></i> وضعیت نظرات</h4>
    <div class="chart-container">
      <canvas id="commentsDoughnutChart"></canvas>
    </div>
  </div>
  <div class="chart-card">
    <h4><i class="fas fa-fire"></i> محبوب‌ترین ژانرها</h4>
    <div class="chart-container">
      <canvas id="genresChart"></canvas>
    </div>
  </div>
  <div class="chart-card">
    <h4><i class="fas fa-calendar-days"></i> رشد آرشیو در ماه‌های اخیر</h4>
    <div class="chart-container">
      <canvas id="monthlyChart"></canvas>
    </div>
  </div>
</div>

<!-- Stats Grid (enhanced) -->
<div class="stats-grid">
  <div class="stat-card"><div class="stat-icon"><i class="fas fa-film"></i></div><div class="stat-number"><?= number_format($totalMovies) ?></div><div class="stat-label">فیلم و سریال</div></div>
  <div class="stat-card"><div class="stat-icon"><i class="fas fa-tv"></i></div><div class="stat-number"><?= number_format($totalFilms) ?></div><div class="stat-label">فیلم</div></div>
  <div class="stat-card"><div class="stat-icon"><i class="fas fa-layer-group"></i></div><div class="stat-number"><?= number_format($totalSeries) ?></div><div class="stat-label">سریال</div></div>
  <div class="stat-card"><div class="stat-icon"><i class="fas fa-link"></i></div><div class="stat-number"><?= number_format($totalLinks) ?></div><div class="stat-label">لینک‌ها</div></div>
  <div class="stat-card"><div class="stat-icon"><i class="fas fa-comment"></i></div><div class="stat-number"><?= number_format($totalComments) ?></div><div class="stat-label">کامنت تأیید شده</div></div>
  <div class="stat-card"><div class="stat-icon"><i class="fas fa-signal"></i></div><div class="stat-number"><?= number_format($bmLiveVisitors) ?></div><div class="stat-label">آنلاین لحظه‌ای</div></div>
  <div class="stat-card"><div class="stat-icon"><i class="fas fa-eye"></i></div><div class="stat-number"><?= number_format($bmTodayVisits) ?></div><div class="stat-label">بازدید امروز</div></div>
  <div class="stat-card"><div class="stat-icon"><i class="fas fa-clock"></i></div><div class="stat-number"><?= number_format($totalPendingComments) ?></div><div class="stat-label">در انتظار تأیید</div></div>
  <div class="stat-card"><div class="stat-icon"><i class="fas fa-users"></i></div><div class="stat-number"><?= number_format($totalUsers) ?></div><div class="stat-label">کاربران</div></div>
  <div class="stat-card"><div class="stat-icon"><i class="fas fa-image"></i></div><div class="stat-number"><?= number_format($totalMissingPosters) ?></div><div class="stat-label">بدون کاور</div></div>
  <div class="stat-card"><div class="stat-icon"><i class="fas fa-scroll"></i></div><div class="stat-number"><?= number_format($totalStories) ?></div><div class="stat-label">استوری</div></div>
  <div class="stat-card"><div class="stat-icon"><i class="fas fa-trophy"></i></div><div class="stat-number"><?= number_format($totalAdminPicks) ?></div><div class="stat-label">انتخاب ادمین</div></div>
  <div class="stat-card"><div class="stat-icon"><i class="fas fa-inbox"></i></div><div class="stat-number"><?= number_format($totalRequests) ?></div><div class="stat-label">درخواست‌ها</div></div>
</div>

<!-- BankMovie V127: site errors and slow requests on the main dashboard -->
<div class="glass-card bm-site-errors-card" id="siteErrorsDashboard">
  <div class="card-header">
    <div>
      <h3><i class="fas fa-heart-pulse"></i> خطاها و سلامت سایت</h3>
      <p class="bm-site-errors-sub">خطاهای PHP، کندی صفحه فیلم، مشکل دیتابیس و تأخیر آرشیوهای خارجی</p>
    </div>
    <div class="bm-site-errors-actions">
      <a class="btn btn-outline btn-sm" href="admin_health.php#movie-performance"><i class="fas fa-chart-line"></i> گزارش کامل</a>
      <form method="post" onsubmit="return confirm('همه گزارش‌های خطا و کندی پاک شوند؟ این کار قابل بازگشت نیست.');">
        <?= admin_csrf_input() ?>
        <button class="btn btn-danger btn-sm" type="submit" name="reset_site_error_logs" value="1"><i class="fas fa-rotate-right"></i> ریست گزارش‌ها</button>
      </form>
    </div>
  </div>
  <div class="card-body">
    <?php if(isset($_GET['site_logs_reset'])): ?><div class="bm-site-errors-reset-ok"><i class="fas fa-check-circle"></i> گزارش‌های خطا و کندی با موفقیت ریست شدند.</div><?php endif; ?>
    <div class="bm-site-errors-stats">
      <div><span class="bm-error-stat-icon warn"><i class="fas fa-gauge-high"></i></span><b><?= number_format($siteErrorSnapshot['slow_count']) ?></b><small>درخواست کند</small></div>
      <div><span class="bm-error-stat-icon bad"><i class="fas fa-bug"></i></span><b><?= number_format($siteErrorSnapshot['php_count']) ?></b><small>خطای PHP</small></div>
      <div><span class="bm-error-stat-icon bad"><i class="fas fa-database"></i></span><b><?= number_format($siteErrorSnapshot['db_count']) ?></b><small>مشکل دیتابیس</small></div>
      <div><span class="bm-error-stat-icon info"><i class="fas fa-cloud-arrow-down"></i></span><b><?= number_format($siteErrorSnapshot['external_count']) ?></b><small>تأخیر API</small></div>
      <div><span class="bm-error-stat-icon ok"><i class="fas fa-file-waveform"></i></span><b><?= number_format($siteErrorSnapshot['total_bytes']/1024, 1) ?> KB</b><small>حجم گزارش‌ها</small></div>
    </div>
    <?php if(!empty($siteErrorSnapshot['recent'])): ?>
    <div class="bm-site-errors-list">
      <?php foreach($siteErrorSnapshot['recent'] as $errorRow): ?>
      <div class="bm-site-error-row">
        <span class="bm-site-error-level <?= htmlspecialchars($errorRow['level']) ?>"></span>
        <div><b><?= htmlspecialchars($errorRow['kind']) ?></b><small><?= htmlspecialchars($errorRow['summary']) ?></small></div>
        <code title="<?= htmlspecialchars($errorRow['uri']) ?>"><?= htmlspecialchars($errorRow['uri'] ?: 'system log') ?></code>
        <time><?= htmlspecialchars($errorRow['time'] ? date('m/d H:i', strtotime($errorRow['time'])) : '—') ?></time>
      </div>
      <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="bm-site-errors-empty"><i class="fas fa-shield-check"></i><b>فعلاً خطای ثبت‌شده‌ای وجود ندارد</b><span>اگر صفحه‌ای بیش از ۲٫۵ ثانیه طول بکشد یا PHP خطای جدی بدهد، اینجا ظاهر می‌شود.</span></div>
    <?php endif; ?>
  </div>
</div>

<!-- Needs Attention Section -->
<div class="glass-card pro-attention-card" id="attentionSection">
  <div class="card-header">
    <h3><i class="fas fa-triangle-exclamation"></i> سیستم نیازمند توجه</h3>
    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
      <span class="badge badge-warning"><?= number_format(count($attentionMovies)) ?> مورد فوری</span>
      <?php if($attentionMovies): ?><span class="badge badge-info">صف هوشمند ۵ ثانیه‌ای</span><?php endif; ?>
    </div>
  </div>
  <div class="card-body">
    <?php if($attentionMovies): ?>
    <div class="omdb-queue-panel">
      <div class="queue-headline">
        <div>
          <strong><i class="fas fa-robot"></i> صف هوشمند تکمیل OMDb</strong>
          <small>هر آیتم بعد از پایان آیتم قبلی و با فاصله امن ۵ ثانیه اجرا می‌شود؛ هر زمان خواستی می‌توانی توقف یا ادامه بزنی.</small>
        </div>
        <span class="badge badge-gray" id="attentionOmdbStatus">آماده</span>
      </div>
      <div class="queue-controls">
        <select id="attentionQueueFilter" aria-label="فیلتر صف تکمیل OMDb">
          <option value="all">همه موارد نیازمند توجه</option>
          <option value="بدون IMDb">فقط بدون IMDb</option>
          <option value="بدون ژانر">فقط بدون ژانر</option>
          <option value="بدون توضیح">فقط بدون توضیح</option>
          <option value="بدون کاور">فقط بدون کاور</option>
          <option value="عنوان فارسی ندارد">فقط بدون عنوان فارسی</option>
        </select>
        <button class="btn btn-primary btn-sm" type="button" id="attentionAutoOmdbBtn"><i class="fas fa-play"></i> شروع صف</button>
        <button class="btn btn-outline btn-sm" type="button" id="attentionPauseOmdbBtn" disabled><i class="fas fa-pause"></i> توقف</button>
        <button class="btn btn-outline btn-sm" type="button" id="attentionResumeOmdbBtn" disabled><i class="fas fa-forward"></i> ادامه</button>
        <button class="btn btn-outline btn-sm" type="button" id="attentionResetOmdbBtn"><i class="fas fa-rotate-right"></i> ریست</button>
      </div>
      <div class="queue-progress-wrap"><div id="attentionQueueBar" class="queue-progress-bar"></div></div>
      <div class="queue-stats">
        <span>کل صف: <b id="queueTotal">0</b></span>
        <span>موفق: <b id="queueSuccess">0</b></span>
        <span>ناموفق: <b id="queueFail">0</b></span>
        <span>باقی‌مانده: <b id="queueLeft">0</b></span>
      </div>
      <div id="attentionQueueLog" class="queue-log"></div>
    </div>
    <?php endif; ?>
    <div class="attention-grid">
      <?php if($attentionMovies): foreach($attentionMovies as $am): ?>
      <div class="attention-card" data-reasons="<?= htmlspecialchars(implode('|', $am['attention_reasons'])) ?>" data-movie-id="<?= (int)$am['id'] ?>">
        <div class="attention-title">
          <strong><?= htmlspecialchars($am['title_fa'] ?: $am['title']) ?></strong>
          <small><?= htmlspecialchars((string)($am['year'] ?? '—')) ?> · <?= htmlspecialchars((string)($am['imdb_code'] ?: 'بدون IMDb')) ?></small>
        </div>
        <div class="attention-reasons">
          <?php foreach($am['attention_reasons'] as $r): ?><span class="badge badge-warning"><?= htmlspecialchars($r) ?></span><?php endforeach; ?>
        </div>
        <div class="attention-actions">
          <button class="btn btn-outline btn-sm" type="button" onclick="openMovieQuick(<?= (int)$am['id'] ?>)"><i class="fas fa-eye"></i> جزئیات</button>
          <button class="btn btn-primary btn-sm" type="button" onclick="openQuickEdit(<?= (int)$am['id'] ?>)"><i class="fas fa-pen"></i> ویرایش سریع</button>
          <button class="btn btn-outline btn-sm attention-omdb-btn" type="button" data-movie-id="<?= (int)$am['id'] ?>"><i class="fas fa-download"></i> تکمیل OMDb</button>
        </div>
      </div>
      <?php endforeach; else: ?>
      <div class="empty">فعلاً مورد فوری برای بررسی وجود ندارد.</div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Movies Section -->
<div class="glass-card" id="moviesSection">
  <div class="card-header">
    <h3><i class="fas fa-video"></i> مدیریت فیلم‌ها و سریال‌ها (جدیدترین در بالا)</h3>
  </div>
  <div class="card-body">
    <div class="bulk-toolbar">
      <div class="bulk-info"><i class="fas fa-layer-group"></i><span id="bulkCount">۰ انتخاب</span></div>
      <button type="button" class="btn btn-outline btn-sm" id="selectVisibleBtn"><i class="fas fa-check-double"></i> انتخاب صفحه</button>
      <button type="button" class="btn btn-outline btn-sm" id="clearSelectionBtn"><i class="fas fa-eraser"></i> پاک کردن انتخاب</button>
      <select id="bulkActionSelect" aria-label="اکشن گروهی">
        <option value="">اکشن گروهی...</option>
        <option value="add_picks">افزودن به انتخاب ادمین</option>
        <option value="remove_picks">حذف از انتخاب ادمین</option>
        <option value="move_to_trash">انتقال امن به سطل بازیافت</option>
        <option value="delete_movies">حذف دائمی فیلم‌های انتخاب‌شده</option>
      </select>
      <button type="button" class="btn btn-primary btn-sm" id="bulkApplyBtn"><i class="fas fa-bolt"></i> اجرا</button>
    </div>
    <form method="POST" id="bulkForm" style="display:none;">
      <?= admin_csrf_input() ?>
      <input type="hidden" name="bulk_action" id="bulkActionInput">
      <div id="bulkIdsBox"></div>
    </form>
    <div class="search-wrapper">
      <i class="fas fa-search"></i>
      <input type="text" id="movSearch" placeholder="جستجوی فیلم، سریال یا کد IMDb ..." autocomplete="off">
    </div>
    <div id="movContainer"></div>
  </div>
</div>

<!-- Missing Posters Section -->
<?php if(count($missingPosters) > 0): ?>
<div class="glass-card" id="missingSection">
  <div class="card-header">
    <h3><i class="fas fa-image"></i> فیلم‌های بدون کاور <span class="badge badge-warning"><?= count($missingPosters) ?> مورد</span></h3>
    <div style="display:flex; gap:12px;">
      <button type="button" id="uploadBtn" class="btn btn-primary" disabled>
        <i class="fas fa-upload"></i> آپلود انتخاب‌شده‌ها
      </button>
      <button type="button" id="clearBtn" class="btn btn-outline btn-sm" style="display:none;">پاک کردن</button>
    </div>
  </div>
  <div class="card-body">
    <div id="upProgress" style="display:none; margin-bottom:20px;">
      <div style="background:rgba(255,255,255,0.08); border-radius:50px; overflow:hidden;"><div id="upBar" style="width:0%; height:6px; background:var(--accent); transition:width .3s;"></div></div>
      <div id="upText" class="badge badge-gray" style="margin-top:8px;"></div>
    </div>
    <div class="movie-list" id="missingList">
      <?php $cnt=0; foreach($missingPosters as $m): $cnt++; ?>
      <div class="movie-row missing-row" data-idx="<?= $cnt ?>" data-key="<?= htmlspecialchars($m['imdb_code'] ?: $m['id']) ?>">
        <div class="movie-info">
          <div class="movie-name"><?= htmlspecialchars($m['title_fa'] ?: $m['title']) ?></div>
          <div class="movie-meta">IMDb: <?= htmlspecialchars($m['imdb_code'] ?: 'ندارد') ?></div>
        </div>
        <div style="display:flex; align-items:center; gap:12px;">
          <input type="file" class="pFile" accept="image/jpeg,image/png,image/webp,image/gif,.gif,.webp" style="width:200px; font-size:12px;">
          <span class="pStatus badge badge-gray">انتخاب نشده</span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- Smart Import Section -->
<div class="glass-card" id="omdbSection">
  <div class="card-header">
    <h3><i class="fas fa-magic-wand-sparkles"></i> ایمپورت هوشمند اطلاعات فیلم</h3>
    <span class="badge <?= $omdbReady ? 'badge-success' : 'badge-warning' ?>"><?= $omdbReady ? 'API آماده است' : 'نیاز به OMDB_API_KEY' ?></span>
  </div>
  <div class="card-body">
    <div class="import-box">
      <div class="form-grid">
        <div class="form-group"><label>عنوان انگلیسی یا کد IMDb</label><input type="text" id="omdbQuery" placeholder="مثلاً tt0111161 یا Inception"></div>
        <div class="form-group"><label>عملیات</label><button type="button" class="btn btn-primary" id="omdbFetchBtn"><i class="fas fa-download"></i> دریافت اطلاعات + دانلود کاور WebP</button></div>
      </div>
      <div id="omdbStatus" class="smart-status">اگر کلید OMDB_API_KEY روی سرور تعریف باشد، اطلاعات داخل فرم افزودن فیلم پر می‌شود و پوستر OMDb با کد IMDb به WebP داخل پوشه posters ذخیره می‌شود.</div>
    </div>
  </div>
</div>

<!-- Add Movie Section -->
<div class="glass-card" id="addMovieSection">
  <div class="card-header">
    <h3><i class="fas fa-plus-circle"></i> افزودن فیلم یا سریال جدید</h3>
  </div>
  <div class="card-body">
    <form method="POST" enctype="multipart/form-data" id="addForm">
      <?= admin_csrf_input() ?>
      <input type="hidden" name="add_movie" value="1">
      <input type="hidden" name="allow_duplicate" id="allowDuplicate" value="0">
      <div id="duplicateMovieAlert" class="duplicate-alert" style="display:none;"></div>
      
      <div class="form-grid">
        <div class="form-group"><label>عنوان انگلیسی *</label><input type="text" name="title" required></div>
        <div class="form-group"><label>عنوان فارسی</label><input type="text" name="title_fa"></div>
        <div class="form-group"><label>نوع</label><select name="type"><option value="movie">فیلم</option><option value="tvSeries">سریال</option></select></div>
        <div class="form-group"><label>سال انتشار</label><input type="number" name="year" placeholder="مثال: 2024"></div>
        <div class="form-group"><label>امتیاز IMDb</label><input type="number" step="0.1" name="imdb_rate" placeholder="مثال: 8.5"></div>
        <div class="form-group"><label>تعداد رای</label><input type="number" name="imdb_votes"></div>
        <div class="form-group"><label>کد IMDb</label><input type="text" name="imdb_code" placeholder="tt1234567"></div>
      </div>
      
      <div class="form-group bm-summary-editor"><div class="bm-summary-head"><label>خلاصه داستان حرفه‌ای</label><small id="addSummaryCount">۰ / ۲۶۰۰</small></div><textarea name="description" id="addDescription" rows="6" maxlength="2600" placeholder="خلاصه داستان تمیز و بدون متن تبلیغاتی؛ فقط خود داستان را بنویس..."></textarea><div class="bm-summary-tools"><button type="button" class="btn btn-outline btn-sm" id="addSummaryPreviewBtn">پیش‌نمایش خلاصه</button><span>متن در صفحه فیلم با فاصله‌گذاری خواناتر نمایش داده می‌شود.</span></div><div id="addSummaryPreview" class="bm-summary-preview" hidden></div></div>
      <div class="form-group"><label>کاور فیلم / سریال</label><div class="bm-cover-editor"><div class="bm-cover-preview" id="addPosterPreview"><i class="fas fa-image"></i></div><div><input type="file" name="poster" id="addPosterInput" accept="image/jpeg,image/png,image/webp,image/gif,.gif,.webp"><small>JPG / PNG / WebP — بعد از ذخیره بهینه می‌شود.</small></div></div></div>
      
      <div class="form-grid">
        <div class="form-group">
          <label>کشور(ها)</label>
          <input type="search" class="filter-input" data-target="cList" placeholder="جستجوی کشور...">
          <div class="checklist" id="cList">
            <?php foreach($allCountries as $c): ?>
            <label class="check-item"><input type="checkbox" name="countries[]" value="<?= htmlspecialchars($c) ?>"><span><?= htmlspecialchars($c) ?></span></label>
            <?php endforeach; ?>
          </div>
          <input type="text" name="countries_manual" id="countriesManual" placeholder="کشور دستی؛ با کاما جدا کن" style="margin-top:10px;">
        </div>
        <div class="form-group">
          <label>زبان(ها)</label>
          <input type="search" class="filter-input" data-target="lList" placeholder="جستجوی زبان...">
          <div class="checklist" id="lList">
            <?php foreach($allLanguages as $l): ?>
            <label class="check-item"><input type="checkbox" name="languages[]" value="<?= htmlspecialchars($l) ?>"><span><?= htmlspecialchars($l) ?></span></label>
            <?php endforeach; ?>
          </div>
          <input type="text" name="languages_manual" id="languagesManual" placeholder="زبان دستی؛ با کاما جدا کن" style="margin-top:10px;">
        </div>
        <div class="form-group"><label>کارگردان</label><input type="text" name="director"></div>
        <div class="form-group"><label>بازیگران</label><input type="text" name="actors"></div>
        <div class="form-group"><label>شرکت‌های تولید</label><input type="text" name="production_companies"></div>
        <div class="form-group"><label>وضعیت (سریال)</label><select name="status"><option value="">انتخاب کنید</option><?php foreach($statusList as $s): ?><option value="<?= htmlspecialchars($s) ?>"><?= htmlspecialchars($s) ?></option><?php endforeach; ?></select></div>
        <div class="form-group"><label>رده سنی</label><select name="rated"><option value="">انتخاب کنید</option><?php foreach($ratedList as $r): ?><option value="<?= htmlspecialchars($r) ?>"><?= htmlspecialchars($r) ?></option><?php endforeach; ?></select></div>
        <div class="form-group"><label>فصل‌ها</label><input type="number" name="seasons"></div>
        <div class="form-group"><label>قسمت‌ها</label><input type="number" name="episodes"></div>
      </div>
      
      <div class="bm-release-editor">
        <div class="bm-release-head"><div><strong>آپدیت و وضعیت انتشار</strong><small>برای سریال‌های جدید فقط «وضعیت» کافی نیست؛ آخرین فصل/قسمت، کیفیت و نسخه تازه را مشخص کن.</small></div><span id="addReleasePreview">بدون آپدیت ثبت‌شده</span></div>
        <div class="form-grid">
          <div class="form-group"><label>آخرین فصل</label><input type="number" min="0" name="last_season" placeholder="مثلاً 2"></div>
          <div class="form-group"><label>آخرین قسمت</label><input type="number" min="0" name="last_episode" placeholder="مثلاً 8"></div>
          <div class="form-group"><label>آخرین کیفیت اضافه‌شده</label><input type="text" name="latest_quality" placeholder="1080p WEB-DL"></div>
          <div class="form-group"><label>توضیح آپدیت</label><input type="text" name="update_note" maxlength="700" placeholder="مثلاً نسخه x265 هم اضافه شد"></div>
        </div>
        <div class="bm-update-checks">
          <label><input type="checkbox" name="dubbed_added" value="1"> دوبله فارسی اضافه شد</label>
          <label><input type="checkbox" name="subtitle_added" value="1"> زیرنویس فارسی اضافه شد</label>
          <label><input type="checkbox" name="season_completed" value="1"> فصل جاری تمام شد</label>
          <label><input type="checkbox" name="series_completed" value="1"> سریال تمام شد</label>
        </div>
      </div>

      <div class="form-group">
        <label>ژانرها</label>
        <input type="search" class="filter-input" data-target="gList" placeholder="جستجوی ژانر...">
        <div class="checklist" id="gList">
          <?php foreach($genresList as $genre): ?>
          <label class="check-item"><input type="checkbox" value="<?= htmlspecialchars($genre) ?>"><span><?= htmlspecialchars($genre) ?></span></label>
          <?php endforeach; ?>
        </div>
        <input type="text" name="genres_manual" id="genresManual" placeholder="ژانر دستی؛ با کاما جدا کن" style="margin-top:10px;">
        <input type="hidden" name="genres_list" id="genresHidden">
      </div>
      
      <div class="form-group"><label>لینک‌های زیرنویس دار</label></div>
      <div id="softLinks">
        <div class="link-row" style="background:rgba(5,8,14,0.5); border:1px solid var(--border); border-radius:16px; padding:16px; margin-bottom:12px;">
          <div class="form-grid bm-link-grid">
            <input type="text" name="soft_quality[]" placeholder="کیفیت (مثلاً 1080p)">
            <input type="text" name="soft_url[]" placeholder="لینک ویدیو">
            <input type="text" name="soft_subtitle_url[]" placeholder="لینک فایل زیرنویس SRT/VTT">
            <input type="text" name="soft_size[]" placeholder="حجم">
            <input type="number" min="0" name="soft_season[]" placeholder="فصل">
            <input type="number" min="0" name="soft_episode[]" placeholder="قسمت">
          </div>
        </div>
      </div>
      <button type="button" id="addSoft" class="btn btn-outline btn-sm" style="margin-bottom:20px;">+ افزودن لینک زیرنویس</button>
      
      <div class="form-group"><label>لینک‌های دوبله فارسی</label></div>
      <div id="dubLinks">
        <div class="link-row" style="background:rgba(5,8,14,0.5); border:1px solid var(--border); border-radius:16px; padding:16px; margin-bottom:12px;">
          <div class="form-grid bm-link-grid">
            <input type="text" name="dub_quality[]" placeholder="کیفیت (مثلاً 1080p)">
            <input type="text" name="dub_url[]" placeholder="لینک ویدیو">
            <input type="text" name="dub_size[]" placeholder="حجم">
            <input type="number" min="0" name="dub_season[]" placeholder="فصل">
            <input type="number" min="0" name="dub_episode[]" placeholder="قسمت">
          </div>
        </div>
      </div>
      <button type="button" id="addDub" class="btn btn-outline btn-sm" style="margin-bottom:24px;">+ افزودن لینک دوبله</button>
      
      <button type="submit" class="btn btn-primary" style="width:100%;">
        <i class="fas fa-save"></i> ذخیره فیلم
      </button>
    </form>
  </div>
</div>

<!-- Smart Picks Suggestions -->
<div class="glass-card" id="smartPicksSection">
  <div class="card-header">
    <h3><i class="fas fa-wand-magic-sparkles"></i> پیشنهاد هوشمند برای انتخاب ادمین</h3>
    <span class="badge badge-info">بر اساس IMDb و سال انتشار</span>
  </div>
  <div class="card-body">
    <div class="suggestion-grid">
      <?php if($smartPickSuggestions): foreach($smartPickSuggestions as $sp): $spKey = trim((string)($sp['imdb_code'] ?? '')) !== '' ? $sp['imdb_code'] : $sp['id']; $spPoster = 'posters/' . $spKey . '.webp'; ?>
      <div class="suggestion-card">
        <div class="suggestion-poster">
          <?php if(is_file(__DIR__ . '/' . $spPoster)): ?><img src="<?= htmlspecialchars($spPoster) ?>" alt="poster"><?php else: ?><i class="fas fa-film"></i><?php endif; ?>
        </div>
        <div class="suggestion-info">
          <strong><?= htmlspecialchars($sp['title_fa'] ?: $sp['title']) ?></strong>
          <small><?= htmlspecialchars((string)($sp['year'] ?? '—')) ?> · IMDb <?= htmlspecialchars((string)($sp['imdb_rate'] ?? '—')) ?></small>
          <a href="?add_to_admin_pick=<?= (int)$sp['id'] ?>&csrf_token=<?= urlencode($csrf_token) ?>#smartPicksSection" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> افزودن</a>
        </div>
      </div>
      <?php endforeach; else: ?>
      <div class="empty">پیشنهادی برای اضافه شدن وجود ندارد.</div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Admin Picks Section with real posters -->
<div class="glass-card" id="picksSection">
  <div class="card-header">
    <h3><i class="fas fa-star"></i> انتخاب‌های ادمین (جدیدترین در بالا، قابل جابجایی)</h3>
  </div>
  <div class="card-body">
    <div class="search-wrapper" style="margin-bottom:20px;">
      <i class="fas fa-search"></i>
      <input type="text" id="pickSearch" placeholder="جستجو و افزودن فیلم به انتخاب‌های ادمین ...">
      <div class="live-results" id="pickResults"></div>
    </div>
    <div class="picks-list" id="picksList" data-offset="<?= (int)$adminPickOffset ?>">
      <?php if(count($adminPicksList) > 0): foreach($adminPicksList as $p): ?>
      <div class="pick-item" data-id="<?= isset($p['pick_id']) ? (int)$p['pick_id'] : 0 ?>">
        <div class="drag-handle"><i class="fas fa-grip-vertical"></i></div>
        <div style="width:40px; height:56px; border-radius:8px; overflow:hidden; background:rgba(0,0,0,0.3); flex-shrink:0;">
          <?php if($p['has_poster'] && file_exists($p['poster_path'])): ?>
          <img src="<?= htmlspecialchars($p['poster_path']) ?>" style="width:100%; height:100%; object-fit:cover;">
          <?php else: ?>
          <div style="width:100%; height:100%; display:flex; align-items:center; justify-content:center; background:rgba(255,255,255,0.05);"><i class="fas fa-film"></i></div>
          <?php endif; ?>
        </div>
        <div class="pick-info" style="flex:1;">
          <strong style="font-size:14px;"><?= htmlspecialchars($p['title_fa'] ?: $p['title']) ?></strong>
          <span class="badge badge-gray"><?= $p['type'] === 'movie' ? 'فیلم' : 'سریال' ?></span>
          <span class="badge badge-warning"><?= htmlspecialchars((string)$p['year']) ?></span>
        </div>
        <a href="?remove_from_admin_pick=<?= isset($p['movie_id']) ? (int)$p['movie_id'] : 0 ?>&pick_page=<?= (int)$adminPickPage ?>&csrf_token=<?= urlencode($csrf_token) ?>#picksSection" class="btn btn-danger btn-sm" onclick="return confirm('حذف از انتخاب‌های ادمین؟')">حذف</a>
      </div>
      <?php endforeach; else: ?>
      <div class="empty" style="text-align:center; padding:40px;">هیچ فیلمی در انتخاب‌های ادمین وجود ندارد</div>
      <?php endif; ?>
    </div>
    <?php if($totalAdminPicks > $adminPickPerPage): ?>
    <div class="pagination">
      <?php if($adminPickPage > 1): ?><a href="?pick_page=<?= $adminPickPage - 1 ?>#picksSection">قبلی</a><?php endif; ?>
      <?php for($i=max(1,$adminPickPage-2); $i<=min($totalAdminPickPages,$adminPickPage+2); $i++): ?>
      <a href="?pick_page=<?= $i ?>#picksSection" class="<?= $i==$adminPickPage?'active':'' ?>"><?= $i ?></a>
      <?php endfor; ?>
      <?php if($adminPickPage < $totalAdminPickPages): ?><a href="?pick_page=<?= $adminPickPage + 1 ?>#picksSection">بعدی</a><?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- Link Health Section -->
<div class="glass-card" id="linkHealthSection">
  <div class="card-header">
    <h3><i class="fas fa-link"></i> بررسی سلامت لینک‌های دانلود</h3>
    <span class="badge badge-gray">تست دستی و سریع هر لینک</span>
  </div>
  <div class="card-body">
    <div class="table-wrapper">
      <table class="data-table pro-table">
        <thead><tr><th>فیلم</th><th>نوع</th><th>کیفیت</th><th>لینک</th><th>وضعیت</th><th>عملیات</th></tr></thead>
        <tbody>
          <?php if($recentLinks): foreach($recentLinks as $ln): ?>
          <tr>
            <td><strong><?= htmlspecialchars($ln['title_fa'] ?: $ln['title']) ?></strong></td>
            <td><span class="badge <?= $ln['link_type'] === 'dubbed' ? 'badge-success' : 'badge-info' ?>"><?= $ln['link_type'] === 'dubbed' ? 'دوبله' : 'زیرنویس' ?></span></td>
            <td><?= htmlspecialchars($ln['quality'] ?: '—') ?></td>
            <td><span class="link-url" title="<?= htmlspecialchars($ln['url']) ?>"><?= htmlspecialchars(admin_text_cut($ln['url'], 48)) ?><?= admin_text_len($ln['url']) > 48 ? '...' : '' ?></span></td>
            <td><span class="link-status badge badge-gray">بررسی نشده</span></td>
            <td><button type="button" class="btn btn-outline btn-sm" onclick="checkDownloadLink(this, <?= htmlspecialchars(json_encode($ln['url']), ENT_QUOTES, 'UTF-8') ?>)"><i class="fas fa-stethoscope"></i> چک کن</button></td>
          </tr>
          <?php endforeach; else: ?>
          <tr><td colspan="6" style="text-align:center; padding:30px;">لینکی برای بررسی پیدا نشد.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Requests Section -->
<div class="glass-card" id="requestsSection">
  <div class="card-header">
    <h3><i class="fas fa-envelope"></i> درخواست‌های کاربران</h3>
  </div>
  <div class="card-body">
    <?php if(count($requestsList) > 0): ?>
    <div class="table-wrapper">
      <table class="data-table">
        <thead><tr><th>کاربر</th><th>عنوان</th><th>نوع</th><th>سال</th><th>وضعیت</th><th>تاریخ</th><th>عملیات</th></tr></thead>
        <tbody>
          <?php foreach($requestsList as $req): ?>
          <tr>
            <td><?= htmlspecialchars($req['username'] ?? 'نامشخص') ?></td>
            <td><strong><?= htmlspecialchars($req['title']) ?></strong></td>
            <td><span class="badge badge-info"><?= $req['type'] === 'movie' ? 'فیلم' : 'سریال' ?></span></td>
            <td><?= $req['year'] ?? '—' ?></td>
            <td><?php $reqStatusKey = admin_request_status_key($req['status'] ?? 'pending'); ?><span class="badge <?= $reqStatusKey === 'approved' ? 'badge-success' : ($reqStatusKey === 'rejected' ? 'badge-danger' : 'badge-warning') ?>"><?= htmlspecialchars(admin_request_status_label($req['status'] ?? 'pending')) ?></span><?php if(trim((string)($req['admin_response'] ?? '')) !== ''): ?><small class="bm-req-replied-mark"><i class="fas fa-message"></i> پاسخ دارد</small><?php endif; ?></td>
            <td><?= date('Y/m/d', strtotime($req['created_at'])) ?></td>
            <td><div style="display:flex; gap:8px;"><button class="btn btn-outline btn-sm" onclick="openReqModal(<?= htmlspecialchars(json_encode($req)) ?>)">پاسخ</button><a href="?delete_request=<?= (int)$req['id'] ?>&csrf_token=<?= urlencode($csrf_token) ?>" class="btn btn-danger btn-sm" onclick="return confirm('حذف درخواست؟')">حذف</a></div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php if($totalReqPages > 1): ?><div class="pagination"><?php for($i=1;$i<=$totalReqPages;$i++): ?><a href="?req_page=<?= $i ?>#requestsSection" class="<?= $i==$reqPage?'active':'' ?>"><?= $i ?></a><?php endfor; ?></div><?php endif; ?>
    <?php else: ?><div class="empty" style="text-align:center; padding:40px;">هیچ درخواستی ثبت نشده است</div><?php endif; ?>
  </div>
</div>


<!-- Professional Manual Ads Manager v174 -->
<div class="glass-card" id="bannersSection">
  <div class="card-header">
    <div>
      <h3><i class="fas fa-rectangle-ad"></i> تبلیغات دستی حرفه‌ای</h3>
      <small style="color:var(--text-muted)">تصویر جدا برای دسکتاپ/موبایل، زمان‌بندی، اولویت، CTA، نمایش دستگاهی و CSS اختصاصی هر بنر.</small>
    </div>
    <?php
    try { $bannersList = $pdo->query("SELECT * FROM admin_banners ORDER BY is_active DESC, COALESCE(priority,0) DESC, id DESC LIMIT 80")->fetchAll(PDO::FETCH_ASSOC); }
    catch(Throwable $e) { $bannersList = []; }
    ?>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap"><span class="badge badge-info"><?= number_format(count($bannersList)) ?> بنر</span><a class="btn btn-outline btn-sm" href="admin_site_manager.php?group=advertising"><i class="fas fa-rectangle-ad"></i> تنظیمات تبلیغات</a><a class="btn btn-outline btn-sm" href="admin_custom_css.php"><i class="fas fa-code"></i> CSS سفارشی کل سایت</a></div>
  </div>
  <div class="card-body">
    <form method="POST" enctype="multipart/form-data" class="pro-form-box" style="margin-bottom:28px;border:1px solid var(--border);border-radius:24px;padding:20px;">
      <?= admin_csrf_input() ?>
      <input type="hidden" name="admin_banner_action" id="banner_action" value="create">
      <input type="hidden" name="banner_id" id="banner_id" value="0">
      <input type="hidden" name="banner_existing_image" id="banner_existing_image" value="">
      <input type="hidden" name="banner_existing_mobile_image" id="banner_existing_mobile_image" value="">

      <div class="form-grid">
        <div class="form-group"><label>عنوان داخلی بنر</label><input type="text" name="banner_title" id="banner_title" placeholder="مثلاً کمپین شهریور" required></div>
        <div class="form-group"><label>جایگاه نمایش</label><select name="banner_position" id="banner_position">
          <option value="home_top">بالای صفحه اصلی</option><option value="home_middle">وسط صفحه اصلی</option><option value="home_bottom">پایین صفحه اصلی</option><option value="movie_page">صفحه فیلم/سریال</option><option value="mobile">شناور موبایل</option><option value="custom">جایگاه سفارشی</option>
        </select></div>
        <div class="form-group"><label>لینک مقصد</label><input type="text" name="banner_link" id="banner_link" placeholder="/movie/slug یا https://example.com"></div>
        <div class="form-group"><label>اولویت</label><input type="number" name="banner_priority" id="banner_priority" value="0" min="-1000" max="1000"><small>عدد بیشتر زودتر نمایش داده می‌شود.</small></div>
        <div class="form-group"><label>تصویر دسکتاپ</label><input type="file" name="banner_image" id="banner_image" accept="image/jpeg,image/png,image/webp,image/gif,.gif,.webp"><small>JPEG / PNG / GIF / WebP تا ۱۲MB؛ GIF و Animated WebP بدون تبدیل ذخیره می‌شوند تا انیمیشن حفظ شود.</small></div>
        <div class="form-group"><label>تصویر مخصوص موبایل</label><input type="file" name="banner_mobile_image" id="banner_mobile_image" accept="image/jpeg,image/png,image/webp,image/gif,.gif,.webp"><small>می‌توانی یک GIF یا Animated WebP جدا برای موبایل بدهی.</small><label style="display:flex;gap:7px;align-items:center;margin-top:7px"><input type="checkbox" name="banner_remove_mobile_image" id="banner_remove_mobile_image"> حذف تصویر موبایل فعلی</label></div>
        <div class="form-group"><label>نحوه نمایش تصویر</label><select name="banner_object_fit" id="banner_object_fit"><option value="contain">Contain — کامل دیده شود</option><option value="cover">Cover — کادر را پر کند</option><option value="fill">Fill — کشیده شود</option></select></div>
        <div class="form-group"><label>Alt تصویر</label><input type="text" name="banner_alt_text" id="banner_alt_text" maxlength="255" placeholder="توضیح کوتاه تصویر"></div>
        <div class="form-group"><label>متن Badge</label><input type="text" name="banner_badge_text" id="banner_badge_text" maxlength="80" placeholder="تبلیغات / اسپانسر"></div>
        <div class="form-group"><label>متن دکمه CTA</label><input type="text" name="banner_cta_text" id="banner_cta_text" maxlength="80" placeholder="مشاهده / خرید"></div>
        <div class="form-group"><label>شروع نمایش</label><input type="datetime-local" name="banner_starts_at" id="banner_starts_at"></div>
        <div class="form-group"><label>پایان نمایش</label><input type="datetime-local" name="banner_ends_at" id="banner_ends_at"></div>
        <div class="form-group"><label>کلاس CSS اختصاصی</label><input type="text" name="banner_custom_class" id="banner_custom_class" placeholder="مثلاً summer-campaign"><small>برای استایل‌دادن از CSS سفارشی کل سایت.</small></div>
      </div>

      <div class="form-group" style="margin-top:12px"><label>CSS اختصاصی همین بنر</label><textarea name="banner_custom_css" id="banner_custom_css" rows="5" spellcheck="false" placeholder="مثلاً: box-shadow:0 0 30px rgba(0,255,170,.25); border:1px solid #00ffaa;"></textarea><small>فقط declarationهای CSS وارد کن؛ این کد فقط روی همان کارت بنر اعمال می‌شود. برای CSS کامل مثل وردپرس از «CSS سفارشی کل سایت» استفاده کن.</small></div>

      <div style="display:flex;gap:15px;flex-wrap:wrap;margin-top:14px">
        <label class="switch-line"><input type="checkbox" name="banner_active" id="banner_active" checked> فعال</label>
        <label class="switch-line"><input type="checkbox" name="banner_show_desktop" id="banner_show_desktop" checked> دسکتاپ</label>
        <label class="switch-line"><input type="checkbox" name="banner_show_mobile" id="banner_show_mobile" checked> موبایل</label>
        <label class="switch-line"><input type="checkbox" name="banner_open_new_tab" id="banner_open_new_tab" checked> لینک در تب جدید</label>
        <label class="switch-line"><input type="checkbox" name="banner_show_badge" id="banner_show_badge" checked> نمایش Badge</label>
        <label class="switch-line"><input type="checkbox" name="banner_show_cta" id="banner_show_cta" checked> نمایش CTA</label>
      </div>
      <div style="display:flex;gap:12px;margin-top:20px;flex-wrap:wrap"><button type="submit" class="btn btn-primary" id="bannerSubmitBtn"><i class="fas fa-save"></i> ذخیره بنر</button><button type="button" class="btn btn-outline" id="cancelBannerEdit" style="display:none">لغو ویرایش</button></div>
    </form>

    <div class="banner-list">
    <?php if($bannersList): foreach($bannersList as $bn): ?>
      <div class="banner-item"
        data-id="<?= (int)$bn['id'] ?>"
        data-title="<?= htmlspecialchars((string)$bn['title'],ENT_QUOTES,'UTF-8') ?>"
        data-position="<?= htmlspecialchars((string)$bn['position'],ENT_QUOTES,'UTF-8') ?>"
        data-link="<?= htmlspecialchars((string)($bn['link_url']??''),ENT_QUOTES,'UTF-8') ?>"
        data-starts="<?= htmlspecialchars((string)($bn['starts_at']??''),ENT_QUOTES,'UTF-8') ?>"
        data-ends="<?= htmlspecialchars((string)($bn['ends_at']??''),ENT_QUOTES,'UTF-8') ?>"
        data-active="<?= (int)$bn['is_active'] ?>"
        data-image="<?= htmlspecialchars((string)($bn['image_path']??''),ENT_QUOTES,'UTF-8') ?>"
        data-mobile-image="<?= htmlspecialchars((string)($bn['mobile_image_path']??''),ENT_QUOTES,'UTF-8') ?>"
        data-alt="<?= htmlspecialchars((string)($bn['alt_text']??''),ENT_QUOTES,'UTF-8') ?>"
        data-badge="<?= htmlspecialchars((string)($bn['badge_text']??''),ENT_QUOTES,'UTF-8') ?>"
        data-cta="<?= htmlspecialchars((string)($bn['cta_text']??''),ENT_QUOTES,'UTF-8') ?>"
        data-class="<?= htmlspecialchars((string)($bn['custom_class']??''),ENT_QUOTES,'UTF-8') ?>"
        data-css="<?= htmlspecialchars(base64_encode((string)($bn['custom_css']??'')),ENT_QUOTES,'UTF-8') ?>"
        data-fit="<?= htmlspecialchars((string)($bn['object_fit']??'contain'),ENT_QUOTES,'UTF-8') ?>"
        data-desktop="<?= (int)($bn['show_desktop']??1) ?>" data-mobile="<?= (int)($bn['show_mobile']??1) ?>" data-newtab="<?= (int)($bn['open_new_tab']??1) ?>" data-showbadge="<?= (int)($bn['show_badge']??1) ?>" data-showcta="<?= (int)($bn['show_cta']??1) ?>" data-priority="<?= (int)($bn['priority']??0) ?>">
        <div class="banner-preview" style="display:grid;grid-template-columns:1fr 74px;gap:7px;min-width:230px">
          <div><?php $img=(string)($bn['image_path']??''); if($img!=='' && (preg_match('/^https?:\/\//i',$img)||file_exists(__DIR__.'/'.ltrim($img,'/')))): ?><img src="<?= htmlspecialchars($img) ?>" alt="banner" style="width:100%;height:82px;object-fit:contain;border-radius:10px"><?php else: ?><div style="height:82px;display:grid;place-items:center"><i class="fas fa-image" style="font-size:30px;opacity:.45"></i></div><?php endif; ?></div>
          <div><?php $mimg=(string)($bn['mobile_image_path']??''); if($mimg!=='' && (preg_match('/^https?:\/\//i',$mimg)||file_exists(__DIR__.'/'.ltrim($mimg,'/')))): ?><img src="<?= htmlspecialchars($mimg) ?>" alt="mobile banner" style="width:74px;height:82px;object-fit:contain;border-radius:10px"><?php else: ?><div style="height:82px;display:grid;place-items:center;opacity:.4"><i class="fas fa-mobile-screen"></i></div><?php endif; ?></div>
        </div>
        <div class="banner-info"><strong><?= htmlspecialchars((string)$bn['title']) ?></strong><small>جایگاه: <?= htmlspecialchars((string)$bn['position']) ?> • اولویت <?= (int)($bn['priority']??0) ?> • <?= !empty($bn['show_desktop'])?'Desktop ':'' ?><?= !empty($bn['show_mobile'])?'Mobile':'' ?></small><small>زمان: <?= !empty($bn['starts_at'])?date('Y/m/d H:i',strtotime((string)$bn['starts_at'])):'همیشه' ?> تا <?= !empty($bn['ends_at'])?date('Y/m/d H:i',strtotime((string)$bn['ends_at'])):'همیشه' ?></small><?php if(!empty($bn['link_url'])): ?><small>لینک: <a href="<?= htmlspecialchars((string)$bn['link_url']) ?>" target="_blank" rel="noopener" style="color:var(--accent)"><?= htmlspecialchars(admin_text_cut((string)$bn['link_url'],55)) ?></a></small><?php endif; ?></div>
        <div class="banner-actions"><span class="badge <?= (int)$bn['is_active']?'badge-success':'badge-gray' ?>"><?= (int)$bn['is_active']?'فعال':'غیرفعال' ?></span><button type="button" class="btn btn-outline btn-sm edit-banner-btn"><i class="fas fa-edit"></i> ویرایش</button><form method="POST" style="display:inline" onsubmit="return confirm('وضعیت بنر تغییر کند؟')"><?= admin_csrf_input() ?><input type="hidden" name="admin_banner_action" value="toggle"><input type="hidden" name="banner_id" value="<?= (int)$bn['id'] ?>"><button type="submit" class="btn btn-outline btn-sm"><i class="fas fa-power-off"></i></button></form><form method="POST" style="display:inline" onsubmit="return confirm('بنر حذف شود؟')"><?= admin_csrf_input() ?><input type="hidden" name="admin_banner_action" value="delete"><input type="hidden" name="banner_id" value="<?= (int)$bn['id'] ?>"><button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button></form></div>
      </div>
    <?php endforeach; else: ?><div class="empty" style="text-align:center;padding:40px">هنوز تبلیغ دستی ثبت نشده است.</div><?php endif; ?>
    </div>
  </div>
</div>

<!-- Quick Replies Manager -->
<div class="glass-card" id="quickRepliesSection">
  <div class="card-header">
    <h3><i class="fas fa-message"></i> سیستم پیام آماده برای درخواست‌ها</h3>
    <span class="badge badge-info"><?= number_format(count($quickReplies)) ?> قالب</span>
  </div>
  <div class="card-body">
    <form method="POST" class="pro-form-box" style="margin-bottom:22px;">
      <?= admin_csrf_input() ?>
      <input type="hidden" name="quick_reply_action" value="create">
      <div class="form-grid">
        <div class="form-group"><label>عنوان کوتاه</label><input type="text" name="qr_title" placeholder="مثلاً به‌زودی اضافه می‌شود" required></div>
        <div class="form-group"><label>متن پیام آماده</label><textarea name="qr_message" rows="3" required></textarea></div>
      </div>
      <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> ذخیره پیام آماده</button>
    </form>
    <div class="quick-reply-list">
      <?php if($quickReplies): foreach($quickReplies as $qr): ?>
      <div class="quick-reply-item">
        <div><strong><?= htmlspecialchars($qr['title']) ?></strong><p><?= htmlspecialchars($qr['message']) ?></p></div>
        <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
          <span class="badge <?= (int)$qr['is_active'] ? 'badge-success' : 'badge-gray' ?>"><?= (int)$qr['is_active'] ? 'فعال' : 'غیرفعال' ?></span>
          <form method="POST"><?= admin_csrf_input() ?><input type="hidden" name="quick_reply_action" value="toggle"><input type="hidden" name="qr_id" value="<?= (int)$qr['id'] ?>"><button class="btn btn-outline btn-sm" type="submit">تغییر وضعیت</button></form>
          <form method="POST" onsubmit="return confirm('حذف شود؟')"><?= admin_csrf_input() ?><input type="hidden" name="quick_reply_action" value="delete"><input type="hidden" name="qr_id" value="<?= (int)$qr['id'] ?>"><button class="btn btn-danger btn-sm" type="submit">حذف</button></form>
        </div>
      </div>
      <?php endforeach; else: ?>
      <div class="empty">پیام آماده‌ای ثبت نشده است.</div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Comments Section with real avatars -->
<div class="glass-card" id="commentsSection">
  <div class="card-header">
    <h3><i class="fas fa-comments"></i> نظرات کاربران</h3>
  </div>
  <div class="card-body">
    <?php
      $bmArc1CommentTableExists = admin_table_exists_safe($pdo, 'archive1_comments');
      $bmArc1AllCount = $bmArc1CommentTableExists ? admin_safe_count($pdo, "SELECT COUNT(*) FROM archive1_comments") : 0;
      $bmArc1PendingCount = $bmArc1CommentTableExists ? admin_safe_count($pdo, "SELECT COUNT(*) FROM archive1_comments WHERE status='pending'") : 0;
    ?>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px;">
      <span class="badge <?= $bmArc1CommentTableExists ? 'badge-success' : 'badge-danger' ?>">جدول آرشیو ۱: <?= $bmArc1CommentTableExists ? 'فعال' : 'پیدا نشد' ?></span>
      <span class="badge badge-info">کل کامنت آرشیو ۱: <?= number_format($bmArc1AllCount) ?></span>
      <span class="badge badge-warning">در انتظار آرشیو ۱: <?= number_format($bmArc1PendingCount) ?></span>
    </div>
    <div class="tabs">
      <a href="?tab=approved#commentsSection" class="tab <?= $commentTab=='approved'?'active':'' ?>">تأیید شده‌ها (<?= number_format($totalComments) ?>)</a>
      <a href="?tab=pending#commentsSection" class="tab <?= $commentTab=='pending'?'active':'' ?>">در انتظار (<?= number_format($totalPendingComments) ?>)</a>
    </div>
    <?php if(count($commentsList) > 0): ?>
    <div class="table-wrapper">
      <table class="data-table">
        <thead><tr><th>فیلم</th><th>کاربر</th><th>نظر</th><th>امتیاز</th><th>تاریخ</th><th>پاسخ</th><th>عملیات</th></tr></thead>
        <tbody>
          <?php foreach($commentsList as $c): ?>
          <tr id="comment-<?= htmlspecialchars((string)($c['comment_source'] ?? 'database'), ENT_QUOTES, 'UTF-8') ?>-<?= (int)$c['id'] ?>">
            <td>
              <div style="display:flex;flex-direction:column;gap:6px;">
                <?php if(!empty($c['movie_url'])): ?>
                  <a href="<?= htmlspecialchars($c['movie_url']) ?>" target="_blank" rel="noopener" style="color:var(--accent);font-weight:800;text-decoration:none;">
                    <?= htmlspecialchars($c['movie_title'] ?: 'مشاهده فیلم') ?>
                  </a>
                <?php else: ?>
                  <span style="color:var(--accent);font-weight:800;"><?= htmlspecialchars($c['movie_title'] ?: 'نامشخص') ?></span>
                <?php endif; ?>
                <span class="badge <?= ($c['comment_source'] ?? 'database') === 'archive1' ? 'badge-info' : 'badge-gray' ?>"><?= htmlspecialchars($c['source_label'] ?? 'دیتابیس سایت') ?></span>
                <?php if(!empty($c['movie_url'])): ?><a href="<?= htmlspecialchars($c['movie_url']) ?>" target="_blank" rel="noopener" class="btn btn-outline btn-sm">مشاهده و پاسخ</a><?php endif; ?>
              </div>
            </td>
            <td>
              <div style="display:flex; align-items:center; gap:8px;">
                <?php 
                  $avatarPath = '';
                  if(!empty($c['user_avatar']) && file_exists(__DIR__ . '/uploads/avatars/' . $c['user_avatar'])){
                    $avatarPath = 'uploads/avatars/' . $c['user_avatar'];
                  } elseif(!empty($c['user_avatar']) && file_exists(__DIR__ . '/' . $c['user_avatar'])){
                    $avatarPath = $c['user_avatar'];
                  }
                ?>
                <?php if($avatarPath): ?>
                  <img src="<?= htmlspecialchars($avatarPath) ?>" class="user-avatar" alt="avatar">
                <?php else: ?>
                  <div class="user-avatar" style="background:rgba(0,255,163,0.2);"><i class="fas fa-user" style="font-size:18px;"></i></div>
                <?php endif; ?>
                <span><?= htmlspecialchars($c['user_name'] ?? 'کاربر') ?></span>
              </div>
            </td>
            <td style="max-width:250px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;"><?= htmlspecialchars(bm_comment_media_admin_label((string)($c['comment'] ?? ''))) ?></td>
            <td><?= ($c['rating'] ?? 0) > 0 ? ($c['rating']).'/5' : '—' ?></td>
            <td style="white-space:nowrap;"><?= date('Y/m/d H:i', strtotime($c['created_at'] ?? 'now')) ?></td>
            <td><span class="badge badge-gray"><?= $c['reply_count'] ?? 0 ?></span></td>
            <td><div style="display:flex; gap:8px; flex-wrap:wrap;">
              <?php $commentSource = ($c['comment_source'] ?? 'database'); $bmIsMediaComment = bm_sticker_parse_marker((string)($c['comment'] ?? '')) !== null; ?>
              <?php if($commentTab=='pending'): ?>
                <a href="?approve_comment=<?= (int)$c['id'] ?>&comment_source=<?= urlencode($commentSource) ?>&tab=pending&csrf_token=<?= urlencode($csrf_token) ?>#commentsSection" class="btn btn-outline btn-sm" onclick="return confirm('تأیید؟')">تأیید</a>
                <a href="?reject_comment=<?= (int)$c['id'] ?>&comment_source=<?= urlencode($commentSource) ?>&tab=pending&csrf_token=<?= urlencode($csrf_token) ?>#commentsSection" class="btn btn-danger btn-sm" onclick="return confirm('رد؟')">رد</a>
              <?php endif; ?>
              <?php if(!$bmIsMediaComment): ?><button class="btn btn-outline btn-sm" onclick="openEditComm(<?= htmlspecialchars(json_encode($c, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES), ENT_QUOTES, 'UTF-8') ?>)">ویرایش</button><?php else: ?><span class="badge badge-info">رسانه VIP</span><?php endif; ?>
              <a href="?delete_comment=<?= (int)$c['id'] ?>&comment_source=<?= urlencode($commentSource) ?>&csrf_token=<?= urlencode($csrf_token) ?>#commentsSection" class="btn btn-danger btn-sm" onclick="return confirm('حذف؟')">حذف</a>
            </div></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php if($totalCommentPages > 1): ?><div class="pagination"><?php for($i=1;$i<=$totalCommentPages;$i++): ?><a href="?tab=<?= $commentTab ?>&comment_page=<?= $i ?>#commentsSection" class="<?= $i==$commentPage?'active':'' ?>"><?= $i ?></a><?php endfor; ?></div><?php endif; ?>
    <?php else: ?><div class="empty" style="text-align:center; padding:40px;">هیچ نظری در این دسته وجود ندارد</div><?php endif; ?>
  </div>
</div>

<!-- VIP & Watch Party Section -->
<div class="glass-card vip-admin-shell" id="vipSection">
  <div class="vip-admin-hero">
    <div><h3><i class="fas fa-crown"></i> مرکز BankMovie VIP</h3><p>مدیریت قابلیت‌های اشتراک، صفحه فروش و اتاق‌های Watch Party از همین بخش پنل اصلی.</p></div>
    <div class="vip-admin-actions"><a class="btn btn-primary" href="/vip" target="_blank"><i class="fas fa-arrow-up-right-from-square"></i> صفحه VIP</a><a class="btn btn-outline" href="admin_vip_users.php"><i class="fas fa-users"></i> کاربران VIP</a><a class="btn btn-outline" href="admin_vip_manager.php"><i class="fas fa-pen-ruler"></i> محتوا و قیمت‌ها</a><a class="btn btn-outline" href="admin_watch_party.php"><i class="fas fa-people-group"></i> مدیریت Watch Party</a><a class="btn btn-outline" href="admin_stickers.php"><i class="fas fa-note-sticky"></i> مدیریت استیکر و گیف</a><a class="btn btn-outline" href="/watch-party" target="_blank"><i class="fas fa-circle-play"></i> ورود به اتاق‌ها</a></div>
  </div>
  <div class="vip-admin-stats"><div class="vip-admin-stat"><strong><?= number_format($vipActiveUsers) ?></strong><span>عضو VIP فعال</span></div><div class="vip-admin-stat"><strong><?= number_format($vipEnabledBenefits) ?></strong><span>مزیت فعال</span></div><div class="vip-admin-stat"><strong><?= number_format($vipWatchPartyStats['rooms']) ?></strong><span>اتاق فعال</span></div><div class="vip-admin-stat"><strong><?= number_format($vipWatchPartyStats['messages']) ?></strong><span>پیام Watch Party</span></div></div>
  <div class="card-body" style="position:relative;z-index:1;border-top:1px solid rgba(255,255,255,.08);border-bottom:1px solid rgba(255,255,255,.08);">
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;align-items:start;">
      <div>
        <h4 style="margin:0 0 7px;display:flex;align-items:center;gap:8px;"><i class="fas fa-gift" style="color:#fbbf24"></i> هدیه اشتراک به همه کاربران</h4>
        <p style="margin:0 0 14px;color:var(--text-muted,#94a3b8);font-size:12px;line-height:1.9;">به همه حساب‌های غیرمدیر VIP هدیه بده. کاربران عادی از همین لحظه VIP می‌شوند؛ برای VIPهای تاریخ‌دار، روز هدیه روی تاریخ پایان فعلی جمع می‌شود؛ VIP دائمی بدون تغییر می‌ماند.</p>
        <form method="POST" action="admin.php#vipSection" onsubmit="return confirm('هدیه VIP برای همه کاربران اعمال شود؟ این عملیات روی تاریخ اشتراک کاربران اثر می‌گذارد.');" style="display:flex;gap:9px;flex-wrap:wrap;align-items:end;">
          <?= admin_csrf_input() ?>
          <input type="hidden" name="vip_bulk_gift" value="1">
          <div class="form-group" style="margin:0;min-width:160px;"><label>تعداد روز هدیه</label><input class="form-control" type="number" name="vip_gift_days" min="1" max="365" value="1" required></div>
          <div class="form-group" style="margin:0;flex:1;min-width:220px;"><label>یادداشت / دلیل (اختیاری)</label><input class="form-control" type="text" name="vip_gift_note" maxlength="255" placeholder="مثلاً هدیه سالگرد BankMovie"></div>
          <button class="btn btn-primary" type="submit"><i class="fas fa-gift"></i> اعمال هدیه برای همه</button>
        </form>
      </div>
      <div style="padding:13px;border:1px solid rgba(255,255,255,.08);border-radius:14px;background:rgba(255,255,255,.025);">
        <strong style="display:block;margin-bottom:9px;font-size:12px;">آخرین هدیه‌ها</strong>
        <?php if(!$vipGiftEvents): ?><span style="font-size:11px;color:#94a3b8;">هنوز هدیه‌ای ثبت نشده.</span><?php else: ?>
          <div style="display:flex;flex-direction:column;gap:7px;max-height:180px;overflow:auto;">
          <?php foreach($vipGiftEvents as $giftEvent): ?>
            <div style="display:flex;justify-content:space-between;gap:10px;font-size:10px;padding-bottom:7px;border-bottom:1px solid rgba(255,255,255,.06);">
              <span><b><?= (int)$giftEvent['days'] ?> روز</b> · <?= ($giftEvent['scope'] ?? '') === 'all' ? 'همگانی' : ('کاربر #' . (int)($giftEvent['target_user_id'] ?? 0)) ?><?php if(($giftEvent['scope'] ?? '') === 'all'): ?> · <?= number_format((int)($giftEvent['affected_count'] ?? 0)) ?> نفر<?php endif; ?></span>
              <span style="direction:ltr;color:#94a3b8;white-space:nowrap;"><?= htmlspecialchars((string)($giftEvent['created_at'] ?? '')) ?></span>
            </div>
          <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <div class="card-body" style="position:relative;z-index:1">
    <form method="POST" action="admin.php#vipSection"><?= admin_csrf_input() ?><input type="hidden" name="vip_features_save" value="1">
      <?php foreach(['benefit'=>'مزایای فعال اشتراک','gate'=>'قابلیت‌های آماده برای VIP شدن در آینده'] as $vipGroup=>$vipGroupLabel): ?>
      <div class="vip-group-title"><h4 style="margin:0"><?= htmlspecialchars($vipGroupLabel) ?></h4><span><?= $vipGroup==='benefit'?'فعال برای اعضای VIP':'پیش‌فرض غیرفعال؛ دسترسی رایگان حفظ می‌شود' ?></span></div>
      <div class="vip-feature-grid">
      <?php foreach($vipCapabilityCatalog as $vipKey=>$vipMeta): if(($vipMeta['group']??'')!==$vipGroup) continue; $vipOn=!empty($vipCapabilitySettings['features'][$vipKey]); ?>
        <label class="vip-feature-card"><i class="fas <?= htmlspecialchars($vipMeta['icon']??'fa-star') ?>"></i><span class="copy"><b><?= htmlspecialchars($vipMeta['label']) ?></b><small><?= htmlspecialchars($vipMeta['description']) ?></small></span><span class="vip-switch"><input type="checkbox" name="vip_features[<?= htmlspecialchars($vipKey) ?>]" value="1" <?= $vipOn?'checked':'' ?>><span></span></span></label>
      <?php endforeach; ?>
      </div>
      <?php endforeach; ?>
      <div class="vip-admin-note">کنترل پخش حالا لایه‌ای است: می‌توانی فقط پلیرهای خارجی را VIP کنی و پلیر داخلی رایگان بماند، یا با «قفل مادر» کل مسیر پخش را VIP کنی. هر کلید فقط همان قابلیت مشخص را محدود می‌کند.</div>
      <div style="display:flex;justify-content:flex-end;margin-top:16px"><button class="btn btn-primary" type="submit"><i class="fas fa-floppy-disk"></i> ذخیره تنظیمات VIP</button></div>
    </form>
  </div>
</div>

<!-- Users Section -->
<div class="glass-card" id="usersSection">
  <div class="card-header">
    <h3><i class="fas fa-users-gear"></i> مدیریت کاربران</h3>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
      <a class="btn btn-primary btn-sm" href="#" onclick="scrollToSection('vipSection');return false;"><i class="fas fa-crown"></i> مرکز VIP</a>
      <span class="badge badge-info"><?= number_format($totalUsers) ?> کاربر</span>
    </div>
  </div>
  <div class="card-body">
    <?php if($passwordResetFlash): ?>
    <div class="bm-reset-pass-card" id="bmResetPasswordFlash">
      <div class="bm-reset-pass-icon"><i class="fas fa-key"></i></div>
      <div class="bm-reset-pass-copy">
        <small>رمز عبور جدید برای</small>
        <strong><?= htmlspecialchars((string)($passwordResetFlash['username'] ?? ('User #'.(int)($passwordResetFlash['user_id'] ?? 0))), ENT_QUOTES, 'UTF-8') ?></strong>
        <div class="bm-reset-pass-value"><code id="bmResetPasswordValue"><?= htmlspecialchars((string)$passwordResetFlash['password'], ENT_QUOTES, 'UTF-8') ?></code></div>
      </div>
      <button class="btn btn-primary btn-sm" type="button" onclick="bmCopyResetPassword(this)"><i class="fas fa-copy"></i> کپی رمز</button>
      <div class="bm-reset-pass-note"><i class="fas fa-triangle-exclamation"></i> این رمز فقط همین بار در پنل نمایش داده می‌شود؛ بعد از تحویل به کاربر، صفحه را رفرش نکنی تا زمانی که کپی‌اش کرده‌ای.</div>
    </div>
    <script>
    function bmCopyResetPassword(btn){
      const value=document.getElementById('bmResetPasswordValue')?.textContent?.trim()||'';
      if(!value)return;
      const done=()=>{const old=btn.innerHTML;btn.innerHTML='<i class="fas fa-check"></i> کپی شد';setTimeout(()=>btn.innerHTML=old,1800)};
      if(navigator.clipboard&&window.isSecureContext){navigator.clipboard.writeText(value).then(done).catch(()=>bmCopyResetPasswordFallback(value,done));}
      else bmCopyResetPasswordFallback(value,done);
    }
    function bmCopyResetPasswordFallback(value,done){const t=document.createElement('textarea');t.value=value;t.setAttribute('readonly','');t.style.position='fixed';t.style.opacity='0';document.body.appendChild(t);t.select();try{document.execCommand('copy');done();}catch(e){}t.remove();}
    </script>
    <?php endif; ?>
    <form method="GET" action="admin.php#usersSection" class="user-search-bar">
      <div class="search-wrapper" style="margin-bottom:0; flex:1;">
        <i class="fas fa-search"></i>
        <input type="text" name="user_q" value="<?= htmlspecialchars($userSearch) ?>" placeholder="جستجوی نام کاربری، نام یا ایمیل...">
      </div>
      <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i> جستجو</button>
      <?php if($userSearch !== ''): ?><a class="btn btn-outline" href="admin.php#usersSection">پاک کردن</a><?php endif; ?>
    </form>
    <div class="user-grid-pro">
      <?php if($usersList): foreach($usersList as $u):
        $uid = (int)($u[$userIdColumn] ?? $u['id'] ?? 0);
        $uname = $u['username'] ?? $u['display_name'] ?? $u['name'] ?? ('User #' . $uid);
        $isBanned = false; if(isset($u['is_banned'])) $isBanned = (int)$u['is_banned'] === 1; if(isset($u['status'])) $isBanned = strtolower((string)$u['status']) === 'banned';
        $userRole = strtolower(trim((string)($u['role'] ?? 'user')));
        $isProtectedAdmin = in_array($userRole, ['admin','administrator'], true);
        $isVipRole = in_array($userRole, ['vip','premium','special'], true);
        $vipExpiryRaw = trim((string)($u['vip_expires_at'] ?? ''));
        $vipExpiryTs = $vipExpiryRaw !== '' ? strtotime($vipExpiryRaw) : false;
        $vipExpired = $isVipRole && $vipExpiryTs !== false && $vipExpiryTs <= time();
        $vipActive = $isVipRole && !$vipExpired;
        $vipDaysLeft = ($vipActive && $vipExpiryRaw !== '') ? bm_vip_gift_days_left($vipExpiryRaw) : null;
        $vipPermanent = $vipActive && $vipExpiryRaw === '';
        $avatarPath = '';
        if(!empty($u['avatar']) && is_file(__DIR__ . '/uploads/avatars/' . basename((string)$u['avatar']))) $avatarPath = 'uploads/avatars/' . basename((string)$u['avatar']);
        elseif(!empty($u['avatar']) && is_file(__DIR__ . '/' . (string)$u['avatar'])) $avatarPath = (string)$u['avatar'];
      ?>
      <div class="user-card-pro" id="user-<?= $uid ?>">
        <div class="user-card-head">
          <div class="user-avatar big"><?php if($avatarPath): ?><img src="<?= htmlspecialchars($avatarPath) ?>" alt="avatar"><?php else: ?><i class="fas fa-user"></i><?php endif; ?></div>
          <div>
            <strong><?= htmlspecialchars($uname) ?></strong>
            <small><?= htmlspecialchars($u['email'] ?? 'بدون ایمیل') ?></small>
          </div>
        </div>
        <div class="user-card-meta">
          <span class="badge <?= $isBanned ? 'badge-danger' : 'badge-success' ?>"><?= $isBanned ? 'مسدود' : 'فعال' ?></span>
          <?php if(!empty($u['role'])): ?><span class="badge badge-info"><?= htmlspecialchars($u['role']) ?></span><?php endif; ?>
          <?php if($vipActive): ?>
            <span class="badge badge-success"><i class="fas fa-crown"></i> VIP <?= $vipExpiryRaw !== '' ? 'تا '.date('Y/m/d', (int)$vipExpiryTs) : 'دائمی' ?></span>
            <?php if($vipExpiryRaw !== '' && $vipDaysLeft !== null): ?><span class="badge badge-info"><i class="fas fa-hourglass-half"></i> <?= number_format((int)$vipDaysLeft) ?> روز مانده</span><?php endif; ?>
          <?php elseif($vipExpired): ?><span class="badge badge-danger">VIP منقضی‌شده <?= $vipExpiryRaw !== '' ? '· پایان '.date('Y/m/d',(int)$vipExpiryTs) : '' ?></span><?php endif; ?>
          <?php if(!empty($u['created_at'])): ?><span class="badge badge-gray">عضویت <?= date('Y/m/d', strtotime($u['created_at'])) ?></span><?php endif; ?>
          <?php if(!empty($u['last_login'])): ?><span class="badge badge-gray">ورود <?= date('Y/m/d', strtotime($u['last_login'])) ?></span><?php endif; ?>
          <?php if(!empty($u['last_login_at'])): ?><span class="badge badge-gray">ورود <?= date('Y/m/d', strtotime($u['last_login_at'])) ?></span><?php endif; ?>
        </div>
        <div class="user-card-actions">
          <?php if($userStatusColumn): ?>
          <form method="POST"><?= admin_csrf_input() ?><input type="hidden" name="user_id" value="<?= $uid ?>"><input type="hidden" name="user_action" value="<?= $isBanned ? 'unban' : 'ban' ?>"><button class="btn <?= $isBanned ? 'btn-outline' : 'btn-danger' ?> btn-sm" type="submit"><?= $isBanned ? 'رفع مسدودی' : 'مسدود' ?></button></form>
          <?php else: ?><span class="badge badge-gray">برای بن/رفع بن ستون status یا is_banned لازم است</span><?php endif; ?>
          <?php if(!$isProtectedAdmin): ?>
          <form method="POST" class="vip-user-form" style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;">
            <?= admin_csrf_input() ?>
            <input type="hidden" name="user_id" value="<?= $uid ?>">
            <input type="hidden" name="user_action" value="make_vip">
            <select name="vip_plan" class="form-control" style="width:auto;min-width:118px;padding:8px 10px;" onchange="const d=this.form.querySelector('[name=vip_until]');d.style.display=this.value==='custom'?'block':'none';">
              <?php for($vipMonth=1;$vipMonth<=12;$vipMonth++): ?>
              <option value="m<?= $vipMonth ?>" <?= $vipMonth===1?'selected':'' ?>>VIP <?= $vipMonth ?> ماهه</option>
              <?php endfor; ?>
              <option value="permanent">VIP دائمی</option>
              <option value="custom">تاریخ پایان دلخواه</option>
            </select>
            <input type="date" name="vip_until" min="<?= date('Y-m-d', strtotime('+1 day')) ?>" style="display:none;width:auto;padding:8px 10px;">
            <button class="btn btn-primary btn-sm" type="submit"><i class="fas fa-crown"></i> <?= $vipActive ? 'تمدید VIP' : 'VIP کردن' ?></button>
          </form>
          <form method="POST" class="vip-user-form" style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;" onsubmit="return confirm('روز هدیه به این کاربر اضافه شود؟ اگر VIP نباشد، VIP می‌شود.');">
            <?= admin_csrf_input() ?>
            <input type="hidden" name="user_id" value="<?= $uid ?>">
            <input type="hidden" name="user_action" value="add_vip_days">
            <input type="hidden" name="return_user_q" value="<?= htmlspecialchars($userSearch,ENT_QUOTES,'UTF-8') ?>">
            <input class="form-control" type="number" name="vip_gift_days" min="1" max="3650" value="1" required style="width:92px;padding:8px 10px;" <?= $vipPermanent ? 'disabled' : '' ?>>
            <button class="btn btn-outline btn-sm" type="submit" <?= $vipPermanent ? 'disabled title="VIP دائمی است"' : '' ?>><i class="fas fa-gift"></i> هدیه روز</button>
          </form>
          <?php if($isVipRole): ?>
          <form method="POST" onsubmit="return confirm('دسترسی VIP این کاربر حذف شود؟')"><?= admin_csrf_input() ?><input type="hidden" name="user_id" value="<?= $uid ?>"><input type="hidden" name="user_action" value="remove_vip"><button class="btn btn-danger btn-sm" type="submit">حذف VIP</button></form>
          <?php endif; ?>
          <?php else: ?><span class="badge badge-gray">نقش مدیر محافظت شده است</span><?php endif; ?>
          <?php if($isProtectedAdmin && $adminPanelIsOwner && in_array('admin_badge_color', $userColumns, true)): $adminBadgeColor = trim((string)($u['admin_badge_color'] ?? '')); if(!preg_match('/^#[0-9a-fA-F]{6}$/',$adminBadgeColor)) $adminBadgeColor = '#1d9bf0'; ?>
          <form method="POST" class="bm-admin-badge-color-form" title="رنگ تیک این مدیر">
            <?= admin_csrf_input() ?><input type="hidden" name="user_id" value="<?= $uid ?>"><input type="hidden" name="user_action" value="set_admin_badge_color">
            <label><span class="bm-admin-color-preview" style="--c:<?= htmlspecialchars($adminBadgeColor,ENT_QUOTES,'UTF-8') ?>">✓</span> رنگ تیک</label>
            <input type="color" name="admin_badge_color" value="<?= htmlspecialchars($adminBadgeColor,ENT_QUOTES,'UTF-8') ?>">
            <button class="btn btn-outline btn-sm" type="submit">ذخیره</button>
          </form>
          <?php endif; ?>
          <?php if(!$isProtectedAdmin && $userHasPasswordColumn): ?>
          <form method="POST" onsubmit="return confirm('برای این کاربر یک رمز تصادفی جدید ساخته شود؟ رمز فعلی بلافاصله از اعتبار خارج می‌شود.')">
            <?= admin_csrf_input() ?>
            <input type="hidden" name="user_id" value="<?= $uid ?>">
            <input type="hidden" name="user_action" value="reset_password">
            <input type="hidden" name="return_user_q" value="<?= htmlspecialchars($userSearch, ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="return_user_page" value="<?= (int)$userPage ?>">
            <button class="btn btn-outline btn-sm bm-password-reset-btn" type="submit"><i class="fas fa-key"></i> بازیابی رمز</button>
          </form>
          <?php endif; ?>
          <?php if(in_array('avatar', $userColumns, true)): ?>
          <form method="POST" onsubmit="return confirm('آواتار حذف شود؟')"><?= admin_csrf_input() ?><input type="hidden" name="user_id" value="<?= $uid ?>"><input type="hidden" name="user_action" value="delete_avatar"><button class="btn btn-outline btn-sm" type="submit">حذف آواتار</button></form>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; else: ?>
      <div class="empty">کاربری برای نمایش پیدا نشد. اگر فقط تعداد کاربران را می‌دیدی، این نسخه نمایش کارت‌های کاربر را با ستون‌های موجود جدول users سازگار کرده است.</div>
      <?php endif; ?>
    </div>
    <?php if($totalUserPages > 1): ?>
    <div class="pagination">
      <?php for($i=max(1,$userPage-2); $i<=min($totalUserPages,$userPage+2); $i++): ?>
      <a href="?user_q=<?= urlencode($userSearch) ?>&user_page=<?= $i ?>#usersSection" class="<?= $i==$userPage?'active':'' ?>"><?= $i ?></a>
      <?php endfor; ?>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- Activity Log Section -->
<div class="glass-card" id="activitySection">
  <div class="card-header">
    <h3><i class="fas fa-clock-rotate-left"></i> لاگ فعالیت ادمین‌ها</h3>
    <span class="badge <?= $activityLogAvailable ? 'badge-success' : 'badge-warning' ?>"><?= $activityLogAvailable ? 'فعال' : 'محدود' ?></span>
  </div>
  <div class="card-body">
    <div class="activity-timeline">
      <?php if($recentActivity): foreach($recentActivity as $act): ?>
      <div class="activity-item">
        <span class="activity-icon"><i class="fas fa-bolt"></i></span>
        <div class="activity-body">
          <strong><?= htmlspecialchars($act['action'] ?? 'activity') ?></strong>
          <p><?= htmlspecialchars($act['details'] ?? '') ?></p>
          <small><?= htmlspecialchars($act['admin_name'] ?? 'system') ?> · <?= !empty($act['created_at']) ? date('Y/m/d H:i', strtotime($act['created_at'])) : '—' ?></small>
        </div>
      </div>
      <?php endforeach; else: ?>
      <div class="empty">هنوز فعالیتی ثبت نشده است.</div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Weekly Report Section -->
<div class="glass-card" id="weeklyReportSection">
  <div class="card-header">
    <h3><i class="fas fa-chart-line"></i> گزارش هفتگی ادمین</h3>
    <span class="badge badge-success">۷ روز اخیر</span>
  </div>
  <div class="card-body">
    <div class="weekly-grid">
      <div class="weekly-card"><i class="fas fa-film"></i><strong><?= number_format($weekMovies) ?></strong><span>فیلم/سریال اضافه‌شده</span></div>
      <div class="weekly-card"><i class="fas fa-comments"></i><strong><?= number_format($weekApprovedComments) ?></strong><span>کامنت تأییدشده</span></div>
      <div class="weekly-card"><i class="fas fa-inbox"></i><strong><?= number_format($weekRequestsNew) ?></strong><span>درخواست جدید</span></div>
      <div class="weekly-card"><i class="fas fa-check"></i><strong><?= number_format($weekRequestsAnswered) ?></strong><span>درخواست پاسخ‌داده‌شده</span></div>
      <div class="weekly-card"><i class="fas fa-users"></i><strong><?= number_format($weekUsers) ?></strong><span>کاربر جدید</span></div>
      <div class="weekly-card"><i class="fas fa-bolt"></i><strong><?= number_format($weekActivity) ?></strong><span>اکشن ادمین</span></div>
    </div>
  </div>
</div>

<!-- Recycle Bin Section -->
<div class="glass-card" id="trashSection">
  <div class="card-header">
    <h3><i class="fas fa-recycle"></i> سطل بازیافت امن</h3>
    <span class="badge badge-warning"><?= number_format(count(array_filter($trashItems, fn($t)=>empty($t['restored_at'])))) ?> قابل بازیابی</span>
  </div>
  <div class="card-body">
    <p class="section-help">این سطل، مسیر امن جداگانه است و حذف اصلی سایت را دست‌کاری نمی‌کند. برای حذف برگشت‌پذیر، از اکشن «انتقال امن به سطل بازیافت» یا دکمه‌های این بخش استفاده کن.</p>
    <div class="trash-list">
      <?php if($trashItems): foreach($trashItems as $tr): $restored = !empty($tr['restored_at']); ?>
      <div class="trash-item <?= $restored ? 'is-restored' : '' ?>">
        <div><strong><?= htmlspecialchars($tr['title'] ?: ($tr['item_type'] . ' #' . $tr['item_id'])) ?></strong><small><?= htmlspecialchars($tr['item_type']) ?> · حذف: <?= date('Y/m/d H:i', strtotime($tr['created_at'])) ?><?= $restored ? ' · بازیابی: ' . date('Y/m/d H:i', strtotime($tr['restored_at'])) : '' ?></small></div>
        <div style="display:flex; gap:8px; flex-wrap:wrap;">
          <?php if(!$restored && $tr['item_type']==='movie'): ?>
          <form method="POST"><?= admin_csrf_input() ?><input type="hidden" name="trash_action" value="restore_movie"><input type="hidden" name="trash_id" value="<?= (int)$tr['id'] ?>"><button class="btn btn-primary btn-sm" type="submit">بازیابی</button></form>
          <?php endif; ?>
          <form method="POST" onsubmit="return confirm('از سطل حذف دائمی شود؟')"><?= admin_csrf_input() ?><input type="hidden" name="trash_action" value="purge"><input type="hidden" name="trash_id" value="<?= (int)$tr['id'] ?>"><button class="btn btn-danger btn-sm" type="submit">حذف از سطل</button></form>
        </div>
      </div>
      <?php endforeach; else: ?>
      <div class="empty">سطل بازیافت خالی است.</div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Backup and Security Section -->
<div class="glass-card" id="backupSection">
  <div class="card-header">
    <h3><i class="fas fa-shield-halved"></i> امنیت و بکاپ</h3>
    <span class="badge badge-success">حالت امن</span>
  </div>
  <div class="card-body">
    <div class="security-grid">
      <div class="security-card">
        <i class="fas fa-database"></i>
        <h4>بکاپ JSON دیتابیس</h4>
        <p>خروجی جداول اصلی با مخفی‌سازی فیلدهای حساس مثل password و token.</p>
        <form method="POST"><?= admin_csrf_input() ?><input type="hidden" name="download_backup" value="1"><button type="submit" class="btn btn-primary"><i class="fas fa-download"></i> دانلود بکاپ</button></form>
      </div>
      <div class="security-card">
        <i class="fas fa-user-shield"></i>
        <h4>وضعیت امنیت — Safe Mode</h4>
        <p>نمایش فقط‌خواندنی نشست‌های فعال، وضعیت لاگ‌ها و محافظت فایل‌های حساس؛ بدون تغییر Login، CSRF یا API.</p>
        <a href="/admin_security_safe.php" class="btn btn-primary"><i class="fas fa-eye"></i> مشاهده وضعیت امنیت</a>
      </div>
      <div class="security-card">
        <i class="fas fa-clipboard-check"></i>
        <h4>لاگ تغییرات</h4>
        <p>اکشن‌های جدید مثل بکاپ، اکشن گروهی و مدیریت کاربر در جدول admin_activity_logs ثبت می‌شوند.</p>
        <span class="badge badge-success">فعال</span>
      </div>
    </div>
  </div>
</div>

<!-- Stories Section with draggable reorder & thumbnails -->
<div class="glass-card" id="storiesSection">
  <div class="card-header">
    <h3><i class="fas fa-scroll"></i> مدیریت استوری‌ها (جدیدترین در بالا، قابل جابجایی)</h3>
  </div>
  <div class="card-body">
    <form method="POST" enctype="multipart/form-data" style="margin-bottom:28px;">
      <?= admin_csrf_input() ?>
      <input type="hidden" name="add_story" value="1">
      <div class="form-grid">
        <div class="form-group"><label>فایل (تصویر یا ویدیو)</label><input type="file" name="story_file" accept="image/*,video/*" required></div>
        <div class="form-group"><label>متن استوری</label><input type="text" name="caption" placeholder="توضیحات"></div>
        <div class="form-group"><label>لینک (اختیاری)</label><input type="text" name="link" placeholder="https://..."></div>
      </div>
      <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> افزودن استوری جدید (در ابتدا)</button>
    </form>
    
    <div id="storiesListContainer">
      <?php if(count($stories) > 0): ?>
        <?php foreach($stories as $s): ?>
        <div class="story-item" data-id="<?= $s['id'] ?>">
          <div class="drag-handle"><i class="fas fa-grip-vertical"></i></div>
          <div class="story-thumb">
            <?php if($s['type'] === 'video'): ?>
              <video src="<?= htmlspecialchars(function_exists('bm_public_asset_url') ? bm_public_asset_url($s['file_path'] ?? '') : ('/' . ltrim((string)($s['file_path'] ?? ''), '/'))) ?>" style="width:100%; height:100%; object-fit:cover;"></video>
            <?php else: ?>
              <img src="<?= htmlspecialchars(function_exists('bm_public_asset_url') ? bm_public_asset_url($s['file_path'] ?? '') : ('/' . ltrim((string)($s['file_path'] ?? ''), '/'))) ?>" alt="thumbnail">
            <?php endif; ?>
          </div>
          <div class="story-info">
            <div><span class="badge <?= $s['type']==='video' ? 'badge-info' : 'badge-success' ?>"><?= $s['type']==='video' ? 'ویدیو' : 'تصویر' ?></span>
            <span style="font-size:13px; margin-right:8px;"><?= htmlspecialchars($s['caption'] ?: 'بدون متن') ?></span></div>
          </div>
          <form method="POST" style="display:inline" onsubmit="return confirm('استوری حذف شود؟')">
            <?= admin_csrf_input() ?>
            <input type="hidden" name="story_action" value="delete">
            <input type="hidden" name="story_id" value="<?= (int)$s['id'] ?>">
            <button type="submit" class="btn btn-danger btn-sm">حذف</button>
          </form>
        </div>
        <?php endforeach; ?>
      <?php else: ?>
      <div class="empty" style="text-align:center; padding:40px;">هیچ استوری وجود ندارد</div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php
$bmRecentSiteNotifications=[];
$bmRecentTargetedNotificationBatches=[];
try {
  if(admin_table_exists_safe($pdo,'notifications')){
    $bmRecentSiteNotifications=$pdo->query("SELECT id,COALESCE(NULLIF(title,''),'پیام BankMovie') title,message,COALESCE(link,'') link,is_active,expires_at,created_at FROM notifications ORDER BY id DESC LIMIT 30")->fetchAll(PDO::FETCH_ASSOC) ?: [];
  }
  if(admin_table_exists_safe($pdo,'app_notifications')){
    $bmRecentTargetedNotificationBatches=$pdo->query("SELECT dedupe_key,MAX(title) title,MAX(message) message,COUNT(*) recipients,MAX(created_at) created_at FROM app_notifications WHERE type='admin' AND dedupe_key LIKE 'admin:%' GROUP BY dedupe_key ORDER BY MAX(created_at) DESC LIMIT 20")->fetchAll(PDO::FETCH_ASSOC) ?: [];
  }
} catch(Throwable $ignored) {}
?>
<!-- Notification Section -->
<div class="glass-card" id="notifSection">
  <div class="card-header">
    <div><h3><i class="fas fa-bell"></i> مرکز نوتیفیکیشن کاربران</h3><p style="margin-top:6px;color:var(--text-tertiary);font-size:12px;">اعلان داخل خود سایت با Badge خوانده‌نشده، لینک مقصد و هدف‌گیری کاربران. پاسخ درخواست‌ها و فعال/غیرفعال‌شدن VIP هم خودکار اعلان می‌سازند.</p></div>
  </div>
  <div class="card-body">
    <form method="POST">
      <?= admin_csrf_input() ?>
      <input type="hidden" name="send_notification" value="1">
      <div style="display:grid;grid-template-columns:minmax(0,1fr) minmax(220px,.45fr);gap:14px;align-items:end;">
        <div class="form-group"><label>عنوان اعلان</label><input type="text" name="notification_title" maxlength="220" value="پیام BankMovie" placeholder="مثلاً: قسمت جدید اضافه شد"></div>
        <div class="form-group"><label>ارسال برای</label><select name="notification_audience" id="notificationAudience"><option value="all">همه کاربران</option><option value="vip">فقط اعضای VIP</option><option value="regular">فقط کاربران عادی</option><option value="user">یک کاربر مشخص</option></select></div>
      </div>
      <div class="form-group" id="notificationIdentityWrap" style="display:none;"><label>کاربر مشخص</label><input type="text" name="notification_identity" placeholder="ID یا نام کاربری یا ایمیل"></div>
      <div class="form-group"><label>متن پیام</label><textarea name="notification_message" rows="4" maxlength="5000" required placeholder="متن اعلان را بنویسید..."></textarea></div>
      <div class="form-group"><label>لینک مقصد داخل سایت <small style="opacity:.55">(اختیاری)</small></label><input type="text" name="notification_url" placeholder="مثلاً /vip یا /boxoffice"></div>
      <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;"><button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> ارسال نوتیفیکیشن</button><span style="font-size:11px;color:var(--text-tertiary);">اعلان‌ها برای هر کاربر جدا ذخیره می‌شوند و امکان خواندن/حذف دارند.</span></div>
    </form>

    <div style="margin-top:22px;border-top:1px solid rgba(255,255,255,.09);padding-top:18px;">
      <div style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap;margin-bottom:12px;">
        <div><b style="font-size:15px;">مدیریت اعلان‌های ارسال‌شده</b><div style="font-size:11px;color:var(--text-tertiary);margin-top:4px;">حذف از اینجا سراسری است؛ اعلان Broadcast از سایت و فید اعلان داخل اپ حذف می‌شود.</div></div>
        <form method="POST" onsubmit="return confirm('همه اعلان‌های دستی سایت حذف شوند؟ اعلان‌های سیستمی مثل پاسخ دیدگاه دست‌نخورده می‌مانند.')">
          <?= admin_csrf_input() ?><input type="hidden" name="clear_site_notifications" value="1">
          <button class="btn btn-danger" type="submit"><i class="fas fa-trash"></i> حذف همه اعلان‌های دستی</button>
        </form>
      </div>

      <?php if(!$bmRecentSiteNotifications && !$bmRecentTargetedNotificationBatches): ?>
        <div class="empty" style="padding:24px;text-align:center;">اعلان دستی ذخیره‌شده‌ای وجود ندارد.</div>
      <?php endif; ?>

      <?php foreach($bmRecentSiteNotifications as $notif): ?>
        <div style="display:flex;gap:12px;align-items:flex-start;justify-content:space-between;padding:13px 0;border-bottom:1px solid rgba(255,255,255,.06);">
          <div style="min-width:0;flex:1;">
            <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;"><b><?= htmlspecialchars((string)($notif['title'] ?? 'پیام BankMovie'), ENT_QUOTES, 'UTF-8') ?></b><span style="font-size:10px;padding:3px 8px;border-radius:999px;background:rgba(47,124,255,.12);color:#7dd3fc;">Broadcast</span></div>
            <div style="margin-top:5px;white-space:pre-wrap;overflow-wrap:anywhere;"><?= htmlspecialchars((string)($notif['message'] ?? ''), ENT_QUOTES, 'UTF-8') ?></div>
            <small style="display:block;color:var(--text-tertiary);margin-top:6px;" dir="ltr">#<?= (int)$notif['id'] ?> · <?= htmlspecialchars((string)($notif['created_at'] ?? ''), ENT_QUOTES, 'UTF-8') ?></small>
          </div>
          <form method="POST" onsubmit="return confirm('این اعلان از سایت و فید اپ برای همه حذف شود؟')">
            <?= admin_csrf_input() ?><input type="hidden" name="delete_site_notification" value="1"><input type="hidden" name="notification_id" value="<?= (int)$notif['id'] ?>">
            <button class="btn btn-danger" type="submit"><i class="fas fa-trash"></i> حذف</button>
          </form>
        </div>
      <?php endforeach; ?>

      <?php foreach($bmRecentTargetedNotificationBatches as $batch): ?>
        <div style="display:flex;gap:12px;align-items:flex-start;justify-content:space-between;padding:13px 0;border-bottom:1px solid rgba(255,255,255,.06);">
          <div style="min-width:0;flex:1;">
            <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;"><b><?= htmlspecialchars((string)($batch['title'] ?? 'پیام BankMovie'), ENT_QUOTES, 'UTF-8') ?></b><span style="font-size:10px;padding:3px 8px;border-radius:999px;background:rgba(34,197,94,.12);color:#86efac;">هدف‌دار · <?= number_format((int)($batch['recipients'] ?? 0)) ?> گیرنده</span></div>
            <div style="margin-top:5px;white-space:pre-wrap;overflow-wrap:anywhere;"><?= htmlspecialchars((string)($batch['message'] ?? ''), ENT_QUOTES, 'UTF-8') ?></div>
            <small style="display:block;color:var(--text-tertiary);margin-top:6px;" dir="ltr"><?= htmlspecialchars((string)($batch['created_at'] ?? ''), ENT_QUOTES, 'UTF-8') ?></small>
          </div>
          <form method="POST" onsubmit="return confirm('این اعلان برای همه گیرنده‌های هدف‌دار حذف شود؟')">
            <?= admin_csrf_input() ?><input type="hidden" name="delete_site_notification_batch" value="1"><input type="hidden" name="notification_batch" value="<?= htmlspecialchars((string)($batch['dedupe_key'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
            <button class="btn btn-danger" type="submit"><i class="fas fa-trash"></i> حذف</button>
          </form>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<script>
(function(){
  const select=document.getElementById('notificationAudience');
  const wrap=document.getElementById('notificationIdentityWrap');
  if(!select||!wrap)return;
  const sync=()=>{wrap.style.display=select.value==='user'?'block':'none';};
  select.addEventListener('change',sync);sync();
})();
</script>

</main>

<!-- Modals -->
<div id="editCommModal" class="modal">
  <div class="modal-content">
    <h3 style="margin-bottom:20px; color:var(--accent);"><i class="fas fa-edit"></i> ویرایش نظر</h3>
    <form method="POST">
      <?= admin_csrf_input() ?>
      <input type="hidden" name="edit_comment" value="1">
      <input type="hidden" name="comment_id" id="eCommId">
      <input type="hidden" name="comment_source" id="eCommSource" value="database">
      <div class="form-group"><label>متن جدید</label><textarea name="comment_text" id="eCommText" rows="5" required></textarea></div>
      <div class="modal-footer" style="display:flex; gap:12px; justify-content:flex-end; margin-top:24px;">
        <button type="button" class="btn btn-outline" onclick="closeEditComm()">انصراف</button>
        <button type="submit" class="btn btn-primary">ذخیره</button>
      </div>
    </form>
  </div>
</div>

<div id="reqModal" class="modal">
  <div class="modal-content">
    <h3 style="margin-bottom:20px; color:var(--accent);"><i class="fas fa-reply-all"></i> پاسخ به درخواست</h3>
    <form method="POST">
      <?= admin_csrf_input() ?>
      <input type="hidden" name="update_request" value="1">
      <input type="hidden" name="request_id" id="mReqId">
      <div class="form-group"><label>عنوان</label><input type="text" id="mReqTitle" readonly disabled style="background:rgba(255,255,255,0.04);"></div>
      <div class="form-group"><label>توضیح کاربر</label><textarea id="mReqDesc" rows="3" readonly disabled style="background:rgba(255,255,255,0.04);"></textarea></div>
      <div class="form-group">
        <label>وضعیت نهایی درخواست</label>
        <div class="bm-req-status-picker" id="mReqStatusPicker">
          <label class="bm-req-status-choice pending"><input type="radio" name="status" value="pending"><span><i class="fas fa-clock"></i><b>در حال بررسی</b><small>درخواست هنوز باز است</small></span></label>
          <label class="bm-req-status-choice approved"><input type="radio" name="status" value="approved"><span><i class="fas fa-circle-check"></i><b>پذیرفته شد</b><small>درخواست تأیید شده</small></span></label>
          <label class="bm-req-status-choice rejected"><input type="radio" name="status" value="rejected"><span><i class="fas fa-circle-xmark"></i><b>رد شد</b><small>امکان انجام درخواست نیست</small></span></label>
        </div>
      </div>
      <div class="form-group bm-req-quick-wrap">
        <div class="bm-req-quick-title"><label>پیام‌های آماده</label><small>با یک کلیک متن پاسخ وارد می‌شود؛ بعدش می‌توانی ویرایشش کنی.</small></div>
        <?php if($activeQuickReplies): ?><div class="bm-req-quick-grid" id="quickReplyGrid">
          <?php foreach($activeQuickReplies as $qr): ?>
          <button type="button" class="bm-req-quick-card" data-quick-id="<?= (int)$qr['id'] ?>" data-message="<?= htmlspecialchars((string)$qr['message'], ENT_QUOTES, 'UTF-8') ?>">
            <strong><?= htmlspecialchars((string)$qr['title']) ?></strong>
            <span><?= htmlspecialchars((string)$qr['message']) ?></span>
          </button>
          <?php endforeach; ?>
        </div><?php else: ?><div class="bm-req-quick-empty">پیام آماده فعالی وجود ندارد. از بخش «پیام آماده» پنل می‌توانی پیام جدید بسازی.</div><?php endif; ?>
      </div>
      <div class="form-group"><div class="bm-req-response-head"><label>پاسخ ادمین</label><small id="mReqRespCount">۰ / ۵۰۰۰</small></div><textarea name="admin_response" id="mReqResp" rows="5" maxlength="5000" placeholder="پاسخ دقیق برای کاربر؛ مثلاً لینک، علت رد یا زمان تقریبی بررسی..."></textarea></div>
      <div class="modal-footer" style="display:flex; gap:12px; justify-content:flex-end; margin-top:24px;">
        <button type="button" class="btn btn-outline" onclick="closeReqModal()">انصراف</button>
        <button type="submit" class="btn btn-primary">ثبت پاسخ</button>
      </div>
    </form>
  </div>
</div>

<div id="movieQuickModal" class="modal">
  <div class="modal-content modal-wide">
    <div class="quick-movie-head">
      <div class="quick-poster" id="quickPoster"><i class="fas fa-film"></i></div>
      <div class="quick-info">
        <h3 id="quickTitle">جزئیات فیلم</h3>
        <p id="quickMeta"></p>
        <div id="quickBadges" class="quick-badges"></div>
      </div>
    </div>
    <div class="quick-description" id="quickDescription"></div>
    <form id="quickEditForm" class="quick-edit-form" style="display:none; margin-top:18px;">
      <input type="hidden" id="qeId" name="movie_id">
      <div class="form-grid">
        <div class="form-group"><label>عنوان انگلیسی</label><input type="text" id="qeTitle" name="title"></div>
        <div class="form-group"><label>عنوان فارسی</label><input type="text" id="qeTitleFa" name="title_fa"></div>
        <div class="form-group"><label>نوع</label><select id="qeType" name="type"><option value="movie">فیلم</option><option value="tvSeries">سریال</option></select></div>
        <div class="form-group"><label>سال</label><input type="number" id="qeYear" name="year"></div>
        <div class="form-group"><label>IMDb</label><input type="number" step="0.1" id="qeRate" name="imdb_rate"></div>
        <div class="form-group"><label>تعداد رأی IMDb</label><input type="number" id="qeVotes" name="imdb_votes"></div>
        <div class="form-group"><label>کد IMDb</label><input type="text" id="qeImdb" name="imdb_code"></div>
        <div class="form-group"><label>ژانر</label><input type="text" id="qeGenres" name="genres" placeholder="Action, Drama"></div>
        <div class="form-group"><label>کشور</label><input type="text" id="qeCountry" name="country" placeholder="United States of America"></div>
        <div class="form-group"><label>زبان</label><input type="text" id="qeLanguage" name="language" placeholder="English, Persian (Farsi)"></div>
        <div class="form-group"><label>کارگردان</label><input type="text" id="qeDirector" name="director"></div>
        <div class="form-group"><label>بازیگران</label><input type="text" id="qeActors" name="actors"></div>
        <div class="form-group"><label>رده سنی</label><input type="text" id="qeRated" name="rated" placeholder="PG-13 / TV-MA"></div>
        <div class="form-group"><label>وضعیت سریال</label><input type="text" id="qeStatus" name="status" placeholder="Ended / Returning Series"></div>
        <div class="form-group"><label>شرکت تولید</label><input type="text" id="qeProduction" name="production_companies"></div>
        <div class="form-group"><label>فصل‌ها</label><input type="number" id="qeSeasons" name="seasons"></div>
        <div class="form-group"><label>قسمت‌ها</label><input type="number" id="qeEpisodes" name="episodes"></div>
      </div>
      <div class="form-group"><label>توضیحات</label><textarea id="qeDescription" name="description" rows="5"></textarea></div>
      <div class="quick-actions"><button type="button" class="btn btn-outline" id="quickOmdbBtn"><i class="fas fa-wand-magic-sparkles"></i> پر کردن از OMDb</button><button type="button" class="btn btn-primary" id="quickSaveBtn"><i class="fas fa-save"></i> ذخیره سریع</button><button type="button" class="btn btn-outline" onclick="document.getElementById('quickEditForm').style.display='none'">بستن فرم</button></div>
    </form>
    <div class="quick-actions">
      <button type="button" id="quickEditInline" class="btn btn-primary"><i class="fas fa-pen"></i> Quick Edit</button>
      <a id="quickEdit" href="#" class="btn btn-outline"><i class="fas fa-edit"></i> ویرایش کامل</a>
      <button type="button" class="btn btn-outline" onclick="document.getElementById('movieQuickModal').classList.remove('open')">بستن</button>
    </div>
  </div>
</div>

<script>
window.ADMIN_CSRF = <?= json_encode($csrf_token ?? admin_csrf_token(), JSON_UNESCAPED_UNICODE) ?>;
const allMovies = []; // Admin Fast: movies are loaded page-by-page via AJAX
const allForPick = []; // Admin Fast: pick search is AJAX-based

// Charts initialization (wait for Chart.js)
function initCharts() {
  if(window.__bmChartsInited) return;
  if(typeof Chart === 'undefined') {
    setTimeout(initCharts, 200);
    return;
  }
  window.__bmChartsInited = true;
  // Bar chart
  const barCtx = document.getElementById('statsBarChart')?.getContext('2d');
  if(barCtx) {
    new Chart(barCtx, {
      type: 'bar',
      data: {
        labels: ['فیلم', 'سریال', 'کامنت', 'کاربران', 'انتخاب ادمین'],
        datasets: [{
          label: 'تعداد',
          data: [<?= $totalFilms ?>, <?= $totalSeries ?>, <?= $totalComments ?>, <?= $totalUsers ?>, <?= $totalAdminPicks ?>],
          backgroundColor: 'rgba(0, 255, 163, 0.6)',
          borderColor: '#00ffa3',
          borderWidth: 1,
          borderRadius: 8,
          barPercentage: 0.7
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { labels: { color: '#f0f3fa', font: { family: 'Vazirmatn', size: 12 } } },
          tooltip: { backgroundColor: 'rgba(0,0,0,0.8)', titleColor: '#00ffa3', bodyColor: '#fff' }
        },
        scales: {
          y: { beginAtZero: true, grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#9aa2bf' } },
          x: { ticks: { color: '#9aa2bf', font: { family: 'Vazirmatn' } } }
        }
      }
    });
  }
  // Doughnut chart for comments
  const doughnutCtx = document.getElementById('commentsDoughnutChart')?.getContext('2d');
  if(doughnutCtx) {
    new Chart(doughnutCtx, {
      type: 'doughnut',
      data: {
        labels: ['تأیید شده', 'در انتظار'],
        datasets: [{
          data: [<?= $totalComments ?>, <?= $totalPendingComments ?>],
          backgroundColor: ['#00ffa3', '#ffb347'],
          borderWidth: 0,
          hoverOffset: 8,
          cutout: '65%'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'bottom', labels: { color: '#f0f3fa', font: { family: 'Vazirmatn', size: 12 } } },
          tooltip: { backgroundColor: 'rgba(0,0,0,0.8)', titleColor: '#00ffa3' }
        }
      }
    });
  }
  const genreCtx = document.getElementById('genresChart')?.getContext('2d');
  if(genreCtx) {
    new Chart(genreCtx, {
      type: 'bar',
      data: {
        labels: <?= json_encode(array_column($genreStats, 'genre'), JSON_UNESCAPED_UNICODE) ?>,
        datasets: [{ label: 'تعداد', data: <?= json_encode(array_map('intval', array_column($genreStats, 'total')), JSON_UNESCAPED_UNICODE) ?>, backgroundColor: 'rgba(77, 158, 255, 0.55)', borderColor: '#4d9eff', borderWidth: 1, borderRadius: 8 }]
      },
      options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display:false }, tooltip: { backgroundColor:'rgba(0,0,0,.85)', titleColor:'#00ffa3' } }, scales: { x:{ beginAtZero:true, grid:{color:'rgba(255,255,255,.05)'}, ticks:{color:'#9aa2bf'} }, y:{ grid:{display:false}, ticks:{color:'#9aa2bf', font:{family:'Vazirmatn'}} } } }
    });
  }
  const monthlyCtx = document.getElementById('monthlyChart')?.getContext('2d');
  if(monthlyCtx) {
    new Chart(monthlyCtx, {
      type: 'line',
      data: { labels: <?= json_encode(array_column($monthlyStats, 'label'), JSON_UNESCAPED_UNICODE) ?>, datasets: [{ label:'محتوای اضافه‌شده', data: <?= json_encode(array_map('intval', array_column($monthlyStats, 'total')), JSON_UNESCAPED_UNICODE) ?>, tension:.35, fill:true, backgroundColor:'rgba(0,255,163,.12)', borderColor:'#00ffa3', pointRadius:4 }] },
      options: { responsive:true, maintainAspectRatio:false, plugins:{ legend:{ labels:{ color:'#f0f3fa', font:{family:'Vazirmatn'} } } }, scales:{ y:{ beginAtZero:true, grid:{color:'rgba(255,255,255,.05)'}, ticks:{color:'#9aa2bf'} }, x:{ grid:{display:false}, ticks:{color:'#9aa2bf'} } } }
    });
  }
}
document.addEventListener('DOMContentLoaded', initCharts);

function esc(s){ return s ? String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])) : ''; }


// Duplicate movie guard before adding new content
const duplicateGuardState = { lastKey: '', duplicates: [] };
function duplicateGuardKey(form){
  const v = name => (form?.querySelector(`[name="${name}"]`)?.value || '').trim().toLowerCase();
  return [v('title'), v('title_fa'), v('year'), v('imdb_code')].join('|');
}
function renderDuplicateAlert(duplicates, mode='warning'){
  const box = document.getElementById('duplicateMovieAlert');
  if(!box) return;
  if(!duplicates || !duplicates.length){ box.style.display='none'; box.innerHTML=''; return; }
  const rows = duplicates.map(d=>`<div class="duplicate-row"><strong>${esc(d.title_fa || d.title || 'بدون عنوان')}</strong><small>${esc(d.reason || 'مشابه')} · سال ${esc(d.year || '—')} · IMDb ${esc(d.imdb_code || '—')} · #${esc(d.id)}</small><a class="btn btn-outline btn-sm" href="admin_edit_movie.php?id=${encodeURIComponent(d.id)}" target="_blank">ویرایش موجود</a></div>`).join('');
  box.className = 'duplicate-alert ' + (mode === 'danger' ? 'duplicate-danger' : 'duplicate-warning');
  box.innerHTML = `<div class="duplicate-title"><i class="fas fa-copy"></i><span>احتمال ثبت تکراری پیدا شد</span></div><p>قبل از ذخیره بررسی کن؛ اگر مطمئنی این نسخه باید جدا ثبت شود، ادامه با ثبت تکراری را بزن.</p>${rows}<div class="duplicate-actions"><button type="button" class="btn btn-primary btn-sm" id="allowDuplicateBtn"><i class="fas fa-check"></i> ادامه با ثبت تکراری</button><button type="button" class="btn btn-outline btn-sm" id="hideDuplicateBtn">فعلاً نه</button></div>`;
  box.style.display='block';
  document.getElementById('allowDuplicateBtn')?.addEventListener('click',()=>{
    const allow = document.getElementById('allowDuplicate');
    if(allow) allow.value = '1';
    box.innerHTML = '<div class="duplicate-title"><i class="fas fa-check"></i><span>ثبت تکراری برای همین ارسال مجاز شد.</span></div>';
    box.style.display='block';
  });
  document.getElementById('hideDuplicateBtn')?.addEventListener('click',()=>{ box.style.display='none'; });
}
async function checkDuplicateMovie(form){
  if(!form) return [];
  const title = (form.querySelector('[name="title"]')?.value || '').trim();
  const imdb = (form.querySelector('[name="imdb_code"]')?.value || '').trim();
  const year = (form.querySelector('[name="year"]')?.value || '').trim();
  const titleFa = (form.querySelector('[name="title_fa"]')?.value || '').trim();
  if(!title && !imdb) { renderDuplicateAlert([]); return []; }
  const key = duplicateGuardKey(form);
  if(duplicateGuardState.lastKey === key) return duplicateGuardState.duplicates;
  const fd = new URLSearchParams();
  fd.set('ajax_action','check_duplicate_movie'); fd.set('csrf_token',window.ADMIN_CSRF);
  fd.set('title',title); fd.set('title_fa',titleFa); fd.set('year',year); fd.set('imdb_code',imdb);
  try{
    const res = await fetch(location.href,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:fd.toString()});
    const data = await res.json();
    duplicateGuardState.lastKey = key;
    duplicateGuardState.duplicates = data.success ? (data.duplicates || []) : [];
    renderDuplicateAlert(duplicateGuardState.duplicates);
    return duplicateGuardState.duplicates;
  }catch(e){ return []; }
}
(function initDuplicateGuard(){
  const form = document.getElementById('addForm');
  if(!form) return;
  let t = null;
  ['title','title_fa','year','imdb_code'].forEach(name=>{
    form.querySelector(`[name="${name}"]`)?.addEventListener('input',()=>{
      const allow = document.getElementById('allowDuplicate'); if(allow) allow.value = '0';
      duplicateGuardState.lastKey = '';
      clearTimeout(t); t = setTimeout(()=>checkDuplicateMovie(form), 650);
    });
  });
  form.addEventListener('submit', async function(e){
    if(form.dataset.nativeSubmit === '1') return;
    syncGenresHidden();
    if(document.getElementById('allowDuplicate')?.value === '1') return;
    e.preventDefault();
    const dups = await checkDuplicateMovie(form);
    if(dups.length){
      renderDuplicateAlert(dups, 'danger');
      document.getElementById('duplicateMovieAlert')?.scrollIntoView({behavior:'smooth', block:'center'});
      return;
    }
    form.dataset.nativeSubmit = '1';
    HTMLFormElement.prototype.submit.call(form);
  });
})();

// Mobile sidebar toggle
const menuToggle = document.getElementById('menuToggle');
const sidebar = document.getElementById('sidebar');
if(menuToggle) {
  menuToggle.style.display = window.innerWidth <= 1024 ? 'block' : 'none';
  menuToggle.addEventListener('click', () => sidebar.classList.toggle('open'));
  window.addEventListener('resize', () => {
    if(window.innerWidth <= 1024) menuToggle.style.display = 'block';
    else menuToggle.style.display = 'none';
  });
}

const ADMIN_FAST_SECTIONS = [
  'securityCenterSection','commandCenterSection','healthSection','attentionSection','moviesSection','linkHealthSection','omdbSection',
  'missingSection','addMovieSection','smartPicksSection','picksSection','requestsSection','bannersSection',
  'quickRepliesSection','commentsSection','vipSection','usersSection','activitySection','storiesSection','notifSection',
  'weeklyReportSection','trashSection','backupSection'
];

const ADMIN_SECTION_TITLES = {
  securityCenterSection:'امنیت و Anti-Spam',
  commandCenterSection:'داشبورد سریع',
  healthSection:'سلامت محتوا',
  attentionSection:'نیازمند توجه',
  moviesSection:'مدیریت فیلم‌ها',
  linkHealthSection:'چک لینک‌ها',
  omdbSection:'ایمپورت هوشمند',
  missingSection:'بدون کاور',
  addMovieSection:'افزودن فیلم',
  smartPicksSection:'پیشنهاد ادمین',
  picksSection:'انتخاب ادمین',
  requestsSection:'درخواست‌ها',  bannersSection:'بنر تبلیغاتی',
  quickRepliesSection:'پیام آماده',
  commentsSection:'نظرات',
  vipSection:'VIP و Watch Party',
  usersSection:'کاربران',
  activitySection:'لاگ فعالیت',
  storiesSection:'استوری‌ها',
  notifSection:'نوتیفیکیشن',
  weeklyReportSection:'گزارش هفتگی',
  trashSection:'سطل بازیافت',
  backupSection:'امنیت و بکاپ'
};

function adminPrepareSections(){
  ADMIN_FAST_SECTIONS.forEach(id=>{
    const el=document.getElementById(id);
    if(el) el.classList.add('admin-page-section');
  });
  document.querySelector('.dashboard-hero')?.classList.add('admin-dashboard-block');
  document.querySelector('.stats-grid')?.classList.add('admin-dashboard-block');
  document.querySelector('.stats-charts-row')?.classList.add('admin-dashboard-block');
  document.getElementById('popularVisitsSection')?.classList.add('admin-dashboard-block');
  document.getElementById('siteErrorsDashboard')?.classList.add('admin-dashboard-block');
}

function openAdminSection(id, pushState = true){
  adminPrepareSections();
  if(!ADMIN_FAST_SECTIONS.includes(id)) id='commandCenterSection';

  const isDashboard = id === 'commandCenterSection';
  document.querySelectorAll('.admin-dashboard-block').forEach(el=>el.classList.toggle('admin-section-hidden', !isDashboard));
  ADMIN_FAST_SECTIONS.forEach(secId=>{
    const el=document.getElementById(secId);
    if(!el) return;
    const show = isDashboard ? (secId === 'commandCenterSection' || secId === 'securityCenterSection') : (secId === id);
    el.classList.toggle('admin-section-hidden', !show);
  });

  document.querySelectorAll('.sidebar-nav a').forEach(a=>{
    const onclick = a.getAttribute('onclick') || '';
    const active = onclick.includes("'" + id + "'") || onclick.includes('"' + id + '"');
    a.classList.toggle('admin-active', active);
    a.classList.toggle('active', active);
  });

  const title = document.getElementById('adminFastTitle');
  if(title) title.textContent = ADMIN_SECTION_TITLES[id] || 'پنل مدیریت';

  if(id === 'moviesSection' && typeof filtered !== 'undefined' && filtered.length === 0 && !movLoading && typeof fetchAdminMovies === 'function') fetchAdminMovies(1, movQuery);

  if(pushState){
    const url = new URL(location.href);
    url.searchParams.set('admin_section', id);
    history.replaceState(null, '', url.pathname + url.search + '#' + id);
  }

  document.getElementById('mainContent')?.scrollIntoView({behavior:'smooth', block:'start'});
  if(window.innerWidth <= 1024 && sidebar) sidebar.classList.remove('open');
}

function scrollToSection(id) {
  openAdminSection(id, true);
}

document.addEventListener('DOMContentLoaded', ()=>{
  adminPrepareSections();
  const params = new URLSearchParams(location.search);
  const initial = (location.hash || '').replace('#','') || params.get('admin_section') || 'commandCenterSection';
  openAdminSection(initial, false);
});

// Movies render — Admin Fast AJAX
let filtered = [], movPage = 1, movPer = 20, movTotalPages = 1, movTotal = 0, movQuery = '', movLoading = false;

async function fetchAdminMovies(page = 1, query = movQuery){
  const cont = document.getElementById('movContainer');
  if(!cont) return;
  movLoading = true;
  cont.innerHTML = '<div class="movie-list-loading"><i class="fas fa-spinner fa-spin"></i> در حال دریافت لیست فیلم‌ها...</div>';

  const fd = new URLSearchParams();
  fd.set('ajax_action', 'admin_movies_list');
  fd.set('csrf_token', window.ADMIN_CSRF);
  fd.set('page', page);
  fd.set('per_page', movPer);
  fd.set('q', query || '');

  try{
    const res = await fetch(location.href, {
      method:'POST',
      headers:{'Content-Type':'application/x-www-form-urlencoded'},
      body:fd.toString()
    });
    const data = await res.json();
    if(!data.success) throw new Error(data.message || 'خطا در دریافت لیست');
    filtered = Array.isArray(data.movies) ? data.movies : [];
    allMovies.splice(0, allMovies.length, ...filtered);
    movPage = Number(data.page || page);
    movTotalPages = Number(data.pages || 1);
    movTotal = Number(data.total || filtered.length);
    renderMov();
  }catch(e){
    cont.innerHTML = `<div class="empty">خطا در دریافت لیست: ${esc(e.message || e)}</div>`;
  }finally{
    movLoading = false;
  }
}

function faNum(value){
  return String(value).replace(/[0-9]/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
}

function renderMov() {
  const slice = filtered;
  const cont = document.getElementById('movContainer');
  if(!cont) return;
  if(!slice.length){ cont.innerHTML='<div class="empty">فیلمی یافت نشد</div>'; return; }

  let h = `<div class="bulk-info" style="margin-bottom:12px"><i class="fas fa-database"></i> ${faNum(movTotal.toLocaleString('en-US'))} مورد · صفحه ${faNum(movPage)} از ${faNum(movTotalPages)}</div>`;
  h += '<div class="movie-list">';
  for(const m of slice){
    h += `<div class="movie-row" data-movie-id="${m.id}">
      <label class="select-dot"><input type="checkbox" class="movie-select" value="${m.id}" onchange="syncBulkSelection()"><span></span></label>
      <img src="${esc(m.poster)}" class="movie-poster" onerror="this.style.display='none'">
      <div class="movie-info">
        <div class="movie-name">${esc(m.title_fa||m.title)}
          <span class="badge ${m.type==='movie'?'badge-info':'badge-success'}">${m.type==='movie'?'فیلم':'سریال'}</span>
          ${!m.has_poster?'<span class="badge badge-warning">بدون کاور</span>':''}
        </div>
        <div class="movie-meta">سال ${m.year||'—'} | امتیاز ${m.imdb_rate||'—'} | ${esc(m.imdb_code||'—')}</div>
      </div>
      <div class="movie-actions enhanced-actions">
        <button type="button" class="btn btn-outline btn-sm" onclick="openMovieQuick(${m.id})"><i class="fas fa-eye"></i> جزئیات</button>
        <button type="button" class="btn btn-primary btn-sm" onclick="openQuickEdit(${m.id})"><i class="fas fa-pen"></i> Quick</button>
        <form method="POST" style="display:inline" onsubmit="return confirm('به سطل بازیافت منتقل شود؟')"><input type="hidden" name="csrf_token" value="${esc(window.ADMIN_CSRF)}"><input type="hidden" name="trash_action" value="move_movie"><input type="hidden" name="movie_id" value="${m.id}"><button class="btn btn-outline btn-sm" type="submit"><i class="fas fa-recycle"></i> سطل</button></form>
        <a href="admin_edit_movie.php?id=${m.id}" class="btn btn-outline btn-sm">ویرایش کامل</a>
        <a href="?delete_movie=${m.id}&csrf_token=${encodeURIComponent(window.ADMIN_CSRF)}#moviesSection" class="btn btn-danger btn-sm" onclick="return confirm('حذف دائمی؟')">حذف</a>
      </div>
    </div>`;
  }
  h += '</div>';
  if(movTotalPages>1){
    h += '<div class="pagination">';
    if(movPage>1) h += `<a href="#" onclick="chgMov(${movPage-1});return false;">قبلی</a>`;
    for(let i=Math.max(1,movPage-2); i<=Math.min(movTotalPages,movPage+2); i++)
      h += `<a href="#" onclick="chgMov(${i});return false;" class="${i===movPage?'active':''}">${faNum(i)}</a>`;
    if(movPage<movTotalPages) h += `<a href="#" onclick="chgMov(${movPage+1});return false;">بعدی</a>`;
    h += '</div>';
  }
  cont.innerHTML = h;
  if(typeof syncBulkSelection === 'function') syncBulkSelection();
}
function chgMov(p){ fetchAdminMovies(p, movQuery); }

let movSearchTimer = null;
document.getElementById('movSearch')?.addEventListener('input',function(){
  movQuery = this.value.trim();
  clearTimeout(movSearchTimer);
  movSearchTimer = setTimeout(()=>fetchAdminMovies(1, movQuery), 350);
});
renderMov();

// Filter checklists
document.querySelectorAll('.filter-input[data-target]').forEach(inp=>{
  inp.addEventListener('input',function(){
    const list=document.getElementById(this.dataset.target);
    if(!list) return;
    const t=this.value.trim().toLowerCase();
    list.querySelectorAll('label').forEach(lb=>{ lb.style.display=lb.textContent.toLowerCase().includes(t)?'':'none'; });
  });
});

// Genres hidden
document.getElementById('addForm')?.addEventListener('submit',function(){
  const sel=[...document.querySelectorAll('#gList input:checked')].map(cb=>cb.value);
  document.getElementById('genresHidden').value=sel.join(', ');
});

// Link rows
function mkLinkRow(kind){
  const d=document.createElement('div'); d.className='link-row'; d.style.cssText='background:rgba(5,8,14,0.5); border:1px solid var(--border); border-radius:16px; padding:16px; margin-bottom:12px;';
  const subtitle=kind==='soft'?'<input type="text" name="soft_subtitle_url[]" placeholder="لینک فایل زیرنویس SRT/VTT">':'';
  d.innerHTML=`<div style="display:flex; justify-content:flex-end; margin-bottom:12px;"><button type="button" class="btn btn-danger btn-sm" onclick="this.closest('.link-row').remove()">حذف</button></div>
  <div class="form-grid bm-link-grid"><input type="text" name="${kind}_quality[]" placeholder="کیفیت"><input type="text" name="${kind}_url[]" placeholder="لینک ویدیو">${subtitle}<input type="text" name="${kind}_size[]" placeholder="حجم"><input type="number" min="0" name="${kind}_season[]" placeholder="فصل"><input type="number" min="0" name="${kind}_episode[]" placeholder="قسمت"></div>`;
  return d;
}
document.getElementById('addSoft')?.addEventListener('click',()=>document.getElementById('softLinks').appendChild(mkLinkRow('soft')));
document.getElementById('addDub')?.addEventListener('click',()=>document.getElementById('dubLinks').appendChild(mkLinkRow('dub')));

// Missing posters upload
let selMovies=[], uploading=false;
document.querySelectorAll('.missing-row').forEach(row=>{
  const fi=row.querySelector('.pFile'), st=row.querySelector('.pStatus');
  const md={row,fi,st,key:row.dataset.key,file:null};
  fi.addEventListener('change',function(){
    if(this.files?.[0]){ md.file=this.files[0]; st.textContent='آماده'; st.className='pStatus badge badge-success';
      if(!selMovies.find(m=>m===md)) selMovies.push(md);
    } else { md.file=null; st.textContent='انتخاب نشده'; st.className='pStatus badge badge-gray';
      selMovies=selMovies.filter(m=>m!==md);
    }
    updBtn();
  });
});
function updBtn(){
  const n=selMovies.length, btn=document.getElementById('uploadBtn'), cb=document.getElementById('clearBtn');
  if(n>0&&!uploading){ btn.disabled=false; if(cb) cb.style.display=''; }
  else { btn.disabled=true; if(cb&&!n) cb.style.display='none'; }
}
document.getElementById('clearBtn')?.addEventListener('click',()=>{
  selMovies.forEach(m=>{ m.fi.value=''; m.file=null; m.st.textContent='انتخاب نشده'; m.st.className='pStatus badge badge-gray'; });
  selMovies=[]; updBtn();
});
document.getElementById('uploadBtn')?.addEventListener('click',async function(){
  if(!selMovies.length||uploading) return;
  uploading=true; this.disabled=true;
  const pd=document.getElementById('upProgress'), bar=document.getElementById('upBar'), txt=document.getElementById('upText');
  if(pd) pd.style.display='block';
  let ok=0,fail=0;
  for(let i=0;i<selMovies.length;i++){
    const m=selMovies[i];
    if(bar) bar.style.width=Math.round((i/selMovies.length)*100)+'%';
    if(txt) txt.textContent=`آپلود ${i+1} از ${selMovies.length}...`;
    m.st.textContent='در حال آپلود...'; m.st.className='pStatus badge badge-warning';
    try{
      const fd=new FormData();
      fd.append('upload_poster_ajax','1');
      fd.append('imdb_code',m.key);
      fd.append('poster_file_ajax',m.file);
      fd.append('csrf_token',window.ADMIN_CSRF);
      const res=await fetch(location.href,{method:'POST',body:fd});
      const data=await res.json();
      if(data.success){ ok++; m.st.textContent='آپلود شد'; m.st.className='pStatus badge badge-success'; m.fi.disabled=true; }
      else throw new Error(data.message||'');
    } catch(e){ fail++; m.st.textContent='خطا'; m.st.className='pStatus badge badge-danger'; }
  }
  if(bar) bar.style.width='100%';
  if(txt) txt.textContent=`تمام! ${ok} موفق${fail?'، '+fail+' ناموفق':''}`;
  uploading=false;
  setTimeout(()=>{ if(pd) pd.style.display='none'; this.disabled=false; }, 3000);
});

// Admin pick search — Admin Fast AJAX
const pSrch=document.getElementById('pickSearch'), pRes=document.getElementById('pickResults');
let pickSearchTimer = null;
async function adminPickSearch(q){
  if(!pRes) return;
  if(q.length<2){ pRes.style.display='none'; return; }
  pRes.innerHTML = '<div class="live-item">در حال جستجو...</div>';
  pRes.style.display='block';

  const fd = new URLSearchParams();
  fd.set('ajax_action','admin_pick_search');
  fd.set('csrf_token', window.ADMIN_CSRF);
  fd.set('q', q);

  try{
    const res = await fetch(location.href,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:fd.toString()});
    const data = await res.json();
    const found = data.success ? (data.items || []) : [];
    if(!found.length){ pRes.innerHTML='<div class="live-item">نتیجه‌ای یافت نشد</div>'; return; }
    pRes.innerHTML=found.map(m=>`<div class="live-item" data-id="${m.id}"><span>${esc(m.title_fa||m.title)} (${m.year||'—'})</span><span class="badge badge-gray">${m.type==='movie'?'فیلم':'سریال'}</span></div>`).join('');
    pRes.querySelectorAll('.live-item[data-id]').forEach(el=>el.addEventListener('click',function(){
      location.href=`?add_to_admin_pick=${this.dataset.id}&csrf_token=${encodeURIComponent(window.ADMIN_CSRF)}#picksSection`;
    }));
  }catch(e){
    pRes.innerHTML='<div class="live-item">خطا در جستجو</div>';
  }
}
if(pSrch) pSrch.addEventListener('input',function(){
  const t=this.value.trim();
  clearTimeout(pickSearchTimer);
  pickSearchTimer = setTimeout(()=>adminPickSearch(t), 300);
});
document.addEventListener('click',e=>{ if(pSrch&&!pSrch.contains(e.target)&&pRes&&!pRes.contains(e.target)) pRes.style.display='none'; });

// Drag & drop picks
let dragSrcPick=null;
function initPickDD(){
  document.querySelectorAll('#picksList .pick-item').forEach(item=>{
    item.setAttribute('draggable','true');
    item.addEventListener('dragstart',function(e){ dragSrcPick=this; e.dataTransfer.effectAllowed='move'; });
    item.addEventListener('dragover',e=>{ e.preventDefault(); e.dataTransfer.dropEffect='move'; return false; });
    item.addEventListener('dragenter',function(){ this.style.borderColor='var(--accent)'; });
    item.addEventListener('dragleave',function(){ this.style.borderColor=''; });
    item.addEventListener('drop',function(e){
      e.stopPropagation();
      this.style.borderColor='';
      if(dragSrcPick&&dragSrcPick!==this&&this.parentNode===dragSrcPick.parentNode){
        const parent=this.parentNode, kids=[...parent.children], di=kids.indexOf(dragSrcPick), ti=kids.indexOf(this);
        di<ti ? parent.insertBefore(dragSrcPick,this.nextSibling) : parent.insertBefore(dragSrcPick,this);
        const ids=[...parent.querySelectorAll('.pick-item')].map(el=>el.dataset.id);
        const offset=Math.max(0, Number(parent.dataset.offset || 0));
        fetch(location.href,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
          body:'ajax_action=reorder_admin_picks&ids='+encodeURIComponent(JSON.stringify(ids))+'&offset='+encodeURIComponent(offset)+'&csrf_token='+encodeURIComponent(window.ADMIN_CSRF)
        }).then(r=>r.json()).then(d=>{ if(!d.success) throw new Error(d.message || 'ذخیره ترتیب انجام نشد'); }).catch(e=>alert(e.message));
      }
      return false;
    });
    item.addEventListener('dragend',function(){ this.style.borderColor=''; });
  });
}
initPickDD();

// Drag & drop stories
let dragSrcStory=null;
function initStoriesDD(){
  document.querySelectorAll('#storiesListContainer .story-item').forEach(item=>{
    item.setAttribute('draggable','true');
    item.addEventListener('dragstart',function(e){ dragSrcStory=this; e.dataTransfer.effectAllowed='move'; });
    item.addEventListener('dragover',e=>{ e.preventDefault(); e.dataTransfer.dropEffect='move'; return false; });
    item.addEventListener('dragenter',function(){ this.style.borderColor='var(--accent)'; });
    item.addEventListener('dragleave',function(){ this.style.borderColor=''; });
    item.addEventListener('drop',function(e){
      e.stopPropagation();
      this.style.borderColor='';
      if(dragSrcStory&&dragSrcStory!==this&&this.parentNode===dragSrcStory.parentNode){
        const parent=this.parentNode, kids=[...parent.children], di=kids.indexOf(dragSrcStory), ti=kids.indexOf(this);
        di<ti ? parent.insertBefore(dragSrcStory,this.nextSibling) : parent.insertBefore(dragSrcStory,this);
        const ids=[...parent.querySelectorAll('.story-item')].map(el=>el.dataset.id);
        fetch(location.href,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
          body:'ajax_action=reorder_stories&ids='+encodeURIComponent(JSON.stringify(ids))+'&csrf_token='+encodeURIComponent(window.ADMIN_CSRF)
        }).then(r=>r.json()).then(d=>{ if(d.success) console.log('ترتیب استوری‌ها ذخیره شد'); });
      }
      return false;
    });
    item.addEventListener('dragend',function(){ this.style.borderColor=''; });
  });
}
initStoriesDD();

// Modals
function normalizeReqStatus(value){
  const v=String(value||'').trim().toLowerCase();
  if(['approved','answered','accepted','accept','done','completed','complete','success','1'].includes(v)) return 'approved';
  if(['rejected','declined','denied','reject','failed','2'].includes(v)) return 'rejected';
  return 'pending';
}
function setReqStatus(value){
  const key=normalizeReqStatus(value);
  const radio=document.querySelector(`#mReqStatusPicker input[name="status"][value="${key}"]`);
  if(radio) radio.checked=true;
}
function updateReqRespCount(){
  const box=document.getElementById('mReqResp'), count=document.getElementById('mReqRespCount');
  if(count) count.textContent=`${(box?.value||'').length.toLocaleString('fa-IR')} / ۵۰۰۰`;
}
function openReqModal(req){
  document.getElementById('mReqId').value=req.id;
  document.getElementById('mReqTitle').value=req.title||'';
  document.getElementById('mReqDesc').value=req.description||'';
  setReqStatus(req.status||'pending');
  document.getElementById('mReqResp').value=req.admin_response||'';
  document.querySelectorAll('.bm-req-quick-card').forEach(el=>el.classList.remove('active'));
  updateReqRespCount();
  document.getElementById('reqModal').classList.add('open');
}
function closeReqModal(){ document.getElementById('reqModal').classList.remove('open'); }
function openEditComm(c){
  document.getElementById('eCommId').value=c.id;
  document.getElementById('eCommSource').value=c.comment_source||'database';
  document.getElementById('eCommText').value=c.comment||'';
  document.getElementById('editCommModal').classList.add('open');
}
function closeEditComm(){ document.getElementById('editCommModal').classList.remove('open'); }
document.querySelectorAll('.modal').forEach(m=>m.addEventListener('click',function(e){ if(e.target===this) this.classList.remove('open'); }));


// Bulk actions
window.syncBulkSelection = function(){
  const selected = [...document.querySelectorAll('.movie-select:checked')].map(i=>i.value);
  const countEl = document.getElementById('bulkCount');
  if(countEl) countEl.textContent = selected.length ? selected.length + ' انتخاب' : '۰ انتخاب';
};
document.getElementById('selectVisibleBtn')?.addEventListener('click',()=>{ document.querySelectorAll('.movie-select').forEach(cb=>cb.checked=true); syncBulkSelection(); });
document.getElementById('clearSelectionBtn')?.addEventListener('click',()=>{ document.querySelectorAll('.movie-select').forEach(cb=>cb.checked=false); syncBulkSelection(); });
document.getElementById('bulkApplyBtn')?.addEventListener('click',()=>{
  const action = document.getElementById('bulkActionSelect')?.value || '';
  const ids = [...document.querySelectorAll('.movie-select:checked')].map(i=>i.value);
  if(!action) return alert('یک اکشن گروهی انتخاب کن.');
  if(!ids.length) return alert('اول چند فیلم را انتخاب کن.');
  if(action === 'move_to_trash' && !confirm('فیلم‌های انتخاب‌شده به سطل بازیافت منتقل شوند؟')) return;
  if(action === 'delete_movies' && !confirm('حذف گروهی دائمی و برگشت‌ناپذیر است. مطمئنی؟')) return;
  const box = document.getElementById('bulkIdsBox');
  box.innerHTML = ids.map(id=>`<input type="hidden" name="movie_ids[]" value="${id}">`).join('');
  document.getElementById('bulkActionInput').value = action;
  document.getElementById('bulkForm').submit();
});

// Quick movie view
window.openMovieQuick = function(id){
  const m = allMovies.find(x=>String(x.id)===String(id));
  if(!m) return;
  const modal = document.getElementById('movieQuickModal');
  document.getElementById('quickTitle').textContent = m.title_fa || m.title || 'بدون عنوان';
  document.getElementById('quickMeta').textContent = `${m.type === 'movie' ? 'فیلم' : 'سریال'} · سال ${m.year || '—'} · IMDb ${m.imdb_rate || '—'} · ${m.imdb_code || 'بدون کد'}`;
  document.getElementById('quickDescription').textContent = m.description || 'توضیحی ثبت نشده است.';
  document.getElementById('quickBadges').innerHTML = [m.genres, m.country, m.director].filter(Boolean).map(v=>`<span class="badge badge-gray">${esc(v)}</span>`).join('');
  document.getElementById('quickEdit').href = `admin_edit_movie.php?id=${m.id}`;
  if(document.getElementById('qeId')) { fillQuickEditForm(m); document.getElementById('quickEditForm').style.display='none'; }
  const poster = document.getElementById('quickPoster');
  poster.innerHTML = `<img src="${esc(m.poster)}" onerror="this.parentNode.innerHTML='<i class=&quot;fas fa-film&quot;></i>'">`;
  modal.classList.add('open');
};


// Request quick replies — visual cards with full preview.
document.querySelectorAll('.bm-req-quick-card').forEach(card=>{
  card.addEventListener('click', function(){
    document.querySelectorAll('.bm-req-quick-card').forEach(el=>el.classList.remove('active'));
    this.classList.add('active');
    const box=document.getElementById('mReqResp');
    if(box){ box.value=this.dataset.message||''; box.focus(); box.setSelectionRange(box.value.length,box.value.length); }
    updateReqRespCount();
  });
});
document.getElementById('mReqResp')?.addEventListener('input', updateReqRespCount);

// Quick edit inline
function fillQuickEditForm(m){
  document.getElementById('qeId').value = m.id || '';
  document.getElementById('qeTitle').value = m.title || '';
  document.getElementById('qeTitleFa').value = m.title_fa || '';
  document.getElementById('qeType').value = m.type || 'movie';
  document.getElementById('qeYear').value = m.year || '';
  document.getElementById('qeRate').value = m.imdb_rate || '';
  const votesEl = document.getElementById('qeVotes'); if(votesEl) votesEl.value = m.imdb_votes || '';
  document.getElementById('qeImdb').value = m.imdb_code || '';
  document.getElementById('qeGenres').value = m.genres || '';
  document.getElementById('qeCountry').value = m.country || '';
  const langEl = document.getElementById('qeLanguage'); if(langEl) langEl.value = m.language || '';
  const dirEl = document.getElementById('qeDirector'); if(dirEl) dirEl.value = m.director || '';
  const actEl = document.getElementById('qeActors'); if(actEl) actEl.value = m.actors || '';
  const ratedEl = document.getElementById('qeRated'); if(ratedEl) ratedEl.value = m.rated || '';
  const statusEl = document.getElementById('qeStatus'); if(statusEl) statusEl.value = m.status || '';
  const prodEl = document.getElementById('qeProduction'); if(prodEl) prodEl.value = m.production_companies || '';
  const seasonsEl = document.getElementById('qeSeasons'); if(seasonsEl) seasonsEl.value = m.seasons || '';
  const episodesEl = document.getElementById('qeEpisodes'); if(episodesEl) episodesEl.value = m.episodes || '';
  document.getElementById('qeDescription').value = m.description || '';
}
window.openQuickEdit = function(id){
  const m = allMovies.find(x=>String(x.id)===String(id));
  if(!m) return;
  openMovieQuick(id);
  fillQuickEditForm(m);
  document.getElementById('quickEditForm').style.display='block';
};
document.getElementById('quickEditInline')?.addEventListener('click', function(){
  const id = document.getElementById('qeId')?.value;
  if(id){ document.getElementById('quickEditForm').style.display='block'; return; }
  const title = document.getElementById('quickTitle')?.textContent || '';
  const m = allMovies.find(x=>(x.title_fa||x.title||'')===title);
  if(m){ fillQuickEditForm(m); document.getElementById('quickEditForm').style.display='block'; }
});
document.getElementById('quickOmdbBtn')?.addEventListener('click', async function(){
  const query = (document.getElementById('qeImdb')?.value || document.getElementById('qeTitle')?.value || '').trim();
  if(!query) return alert('برای دریافت OMDb اول عنوان انگلیسی یا کد IMDb را وارد کن.');
  const old = this.innerHTML; this.disabled = true; this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> دریافت OMDb...';
  try{
    const fd = new URLSearchParams(); fd.set('ajax_action','fetch_omdb'); fd.set('query',query); fd.set('csrf_token',window.ADMIN_CSRF);
    const res = await fetch(location.href,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:fd.toString()});
    const data = await res.json();
    if(!data.success) throw new Error(data.message || 'OMDb نتیجه‌ای برنگرداند');
    const m = data.movie || {};
    const assign = (id, value, overwrite=true) => { const el=document.getElementById(id); if(el && value !== undefined && value !== null && value !== '' && (overwrite || !el.value)) el.value = value; };
    assign('qeTitle', m.title, false);
    assign('qeType', m.type, true);
    assign('qeYear', m.year, false);
    assign('qeRate', m.imdb_rate, true);
    assign('qeVotes', m.imdb_votes, true);
    assign('qeImdb', m.imdb_code, false);
    assign('qeGenres', m.genres, false);
    assign('qeCountry', m.country, false);
    assign('qeLanguage', m.language, false);
    assign('qeDirector', m.director, false);
    assign('qeActors', m.actors, false);
    assign('qeRated', m.rated, false);
    assign('qeProduction', m.production_companies, false);
    assign('qeDescription', m.description, false);
    alert('اطلاعات OMDb داخل فرم ویرایش سریع پر شد. برای ثبت، ذخیره سریع را بزن.');
  }catch(e){ alert(e.message || 'خطا در دریافت OMDb'); }
  this.disabled = false; this.innerHTML = old;
});

document.getElementById('quickSaveBtn')?.addEventListener('click', async function(){
  const form = document.getElementById('quickEditForm');
  const fd = new URLSearchParams(new FormData(form));
  fd.set('ajax_action','quick_update_movie'); fd.set('csrf_token',window.ADMIN_CSRF);
  const old=this.innerHTML; this.disabled=true; this.innerHTML='<i class="fas fa-spinner fa-spin"></i> ذخیره...';
  try{
    const res = await fetch(location.href,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:fd.toString()});
    const data = await res.json();
    if(!data.success) throw new Error(data.message || 'خطا');
    alert(data.message || 'ذخیره شد');
    location.reload();
  }catch(e){ alert(e.message || 'خطا در ذخیره'); }
  this.disabled=false; this.innerHTML=old;
});

// Keyboard shortcuts
(function(){
  const help = document.createElement('div');
  help.className = 'kbd-help';
  help.innerHTML = '<kbd>Ctrl</kbd> + <kbd>K</kbd> جستجو · <kbd>N</kbd> افزودن · <kbd>C</kbd> کامنت · <kbd>R</kbd> درخواست · <kbd>Esc</kbd> بستن';
  document.body.appendChild(help);
  setTimeout(()=>{ help.style.opacity='0'; help.style.pointerEvents='none'; }, 6500);
  document.addEventListener('keydown', function(e){
    const tag = (document.activeElement?.tagName || '').toLowerCase();
    const typing = ['input','textarea','select'].includes(tag);
    if((e.ctrlKey || e.metaKey) && e.key.toLowerCase()==='k') { e.preventDefault(); scrollToSection('moviesSection'); setTimeout(()=>document.getElementById('movSearch')?.focus(),250); return; }
    if(typing) return;
    const key = e.key.toLowerCase();
    if(key==='n') scrollToSection('addMovieSection');
    if(key==='c') scrollToSection('commentsSection');
    if(key==='r') scrollToSection('requestsSection');
    if(key==='u') scrollToSection('usersSection');
    if(key==='b') scrollToSection('bannersSection');
  });
})();

// Link checker
window.checkDownloadLink = async function(btn, url){
  const row = btn.closest('tr');
  const badge = row?.querySelector('.link-status');
  const old = btn.innerHTML;
  btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> در حال تست...';
  if(badge){ badge.className='link-status badge badge-warning'; badge.textContent='در حال بررسی'; }
  try{
    const fd = new URLSearchParams();
    fd.set('ajax_action','check_link'); fd.set('url',url); fd.set('csrf_token',window.ADMIN_CSRF);
    const res = await fetch(location.href,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:fd.toString()});
    const data = await res.json();
    if(!data.success) throw new Error(data.message || 'خطا');
    if(badge){ badge.className = 'link-status badge ' + (data.ok ? 'badge-success' : 'badge-danger'); badge.textContent = `${data.status || '—'} · ${data.time_ms || 0}ms`; }
  }catch(e){ if(badge){ badge.className='link-status badge badge-danger'; badge.textContent='خطا'; } }
  btn.disabled = false; btn.innerHTML = old;
};

// OMDb smart import
function setField(name, value){ const el = document.querySelector(`[name="${name}"]`); if(el && value !== undefined && value !== null && value !== '') el.value = value; }
function splitList(v){ return String(v || '').split(/[,،|/]+/).map(x=>x.trim()).filter(x=>x && x.toUpperCase() !== 'N/A'); }
function normListKey(v){ return String(v || '').toLowerCase().replace(/\(.*?\)/g,'').replace(/[^a-z0-9]+/g,' ').trim(); }
const omdbAliases = {
  country: {
    'usa':'United States of America', 'us':'United States of America', 'u s a':'United States of America', 'united states':'United States of America', 'united states of america':'United States of America',
    'uk':'United Kingdom', 'u k':'United Kingdom', 'england':'United Kingdom', 'great britain':'United Kingdom',
    'south korea':'South Korea', 'korea south':'South Korea', 'republic of korea':'South Korea', 'korea':'South Korea',
    'north korea':'North Korea', 'soviet union':'Soviet Union', 'hong kong':'Hong Kong', 'uae':'United Arab Emirates'
  },
  language: {
    'farsi':'Persian (Farsi)', 'persian':'Persian (Farsi)', 'persian farsi':'Persian (Farsi)',
    'mandarin':'Chinese (Mandarin)', 'chinese':'Chinese (Mandarin)', 'cantonese':'Chinese (Mandarin)',
    'korean':'Korean', 'japanese':'Japanese', 'arabic':'Arabic', 'urdu':'Urdu', 'hindi':'Hindi', 'english':'English'
  },
  genre: {
    'sci fi':'Sci-Fi', 'science fiction':'Sci-Fi', 'film noir':'Film-Noir', 'tv movie':'TV Movie'
  }
};
function existingOptionMap(listId){
  const map = new Map();
  document.querySelectorAll(`#${listId} input[type="checkbox"]`).forEach(cb=>map.set(normListKey(cb.value), cb));
  return map;
}
function ensureChecklistValue(listId, value, nameAttr){
  if(!value) return null;
  const list = document.getElementById(listId); if(!list) return null;
  const map = existingOptionMap(listId);
  const key = normListKey(value);
  if(map.has(key)){ const cb = map.get(key); cb.checked = true; return cb.value; }
  const label = document.createElement('label');
  label.className = 'check-item omdb-added-option';
  const safeValue = value.trim();
  label.innerHTML = `<input type="checkbox" ${nameAttr ? `name="${nameAttr}"` : ''} value="${esc(safeValue)}" checked><span>${esc(safeValue)} <small style="color:var(--accent)">OMDb</small></span>`;
  list.prepend(label);
  return safeValue;
}
function checkOmdbList(listId, rawValue, group, nameAttr, manualSelector){
  const values = splitList(rawValue);
  const selected = [];
  values.forEach(v=>{
    const canonical = omdbAliases[group]?.[normListKey(v)] || v;
    const picked = ensureChecklistValue(listId, canonical, nameAttr);
    if(picked) selected.push(picked);
    else if(manualSelector){
      const el = document.querySelector(manualSelector);
      if(el){
        const old = splitList(el.value);
        if(!old.some(x=>normListKey(x)===normListKey(canonical))) old.push(canonical);
        el.value = old.join(', ');
      }
    }
  });
  return selected;
}
function syncGenresHidden(){
  const checked = [...document.querySelectorAll('#gList input[type="checkbox"]:checked')].map(cb=>cb.value);
  const manual = splitList(document.getElementById('genresManual')?.value || '');
  const unique = [];
  [...checked, ...manual].forEach(v=>{ if(!unique.some(x=>normListKey(x)===normListKey(v))) unique.push(v); });
  const hidden = document.getElementById('genresHidden');
  if(hidden) hidden.value = unique.join(', ');
  return unique;
}
document.addEventListener('change', function(e){ if(e.target?.closest?.('#gList') || e.target?.id === 'genresManual') syncGenresHidden(); });
document.getElementById('addForm')?.addEventListener('submit', syncGenresHidden);

document.getElementById('omdbFetchBtn')?.addEventListener('click', async function(){
  const q = document.getElementById('omdbQuery')?.value.trim();
  const status = document.getElementById('omdbStatus');
  if(!q) return alert('عنوان یا کد IMDb را وارد کن.');
  const old = this.innerHTML; this.disabled=true; this.innerHTML='<i class="fas fa-spinner fa-spin"></i> دریافت...';
  if(status) status.textContent='در حال دریافت اطلاعات...';
  try{
    const fd = new URLSearchParams(); fd.set('ajax_action','fetch_omdb'); fd.set('query',q); fd.set('csrf_token',window.ADMIN_CSRF);
    const res = await fetch(location.href,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:fd.toString()});
    const data = await res.json();
    if(!data.success) throw new Error(data.message || 'خطا در دریافت');
    const m = data.movie;
    setField('title', m.title); setField('type', m.type); setField('year', m.year); setField('imdb_rate', m.imdb_rate); setField('imdb_votes', m.imdb_votes); setField('imdb_code', m.imdb_code); setField('description', m.description); setField('director', m.director); setField('actors', m.actors); setField('rated', m.rated); setField('production_companies', m.production_companies);
    checkOmdbList('gList', m.genres, 'genre', '', '#genresManual');
    checkOmdbList('cList', m.country, 'country', 'countries[]', '#countriesManual');
    checkOmdbList('lList', m.language, 'language', 'languages[]', '#languagesManual');
    syncGenresHidden();
    if(status) status.innerHTML = `اطلاعات <strong>${esc(m.title)}</strong> دریافت شد و ژانر/کشور/زبان هم انتخاب یا به صورت دستی اضافه شد. در حال تلاش برای دانلود کاور WebP...`;
    if(m.poster && m.poster !== 'N/A' && m.imdb_code){
      try{
        const pfd = new URLSearchParams(); pfd.set('ajax_action','download_omdb_poster'); pfd.set('poster_url',m.poster); pfd.set('imdb_code',m.imdb_code); pfd.set('csrf_token',window.ADMIN_CSRF);
        const pres = await fetch(location.href,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:pfd.toString()});
        const pdata = await pres.json();
        if(status) status.innerHTML = `اطلاعات <strong>${esc(m.title)}</strong> دریافت شد. ${pdata.success ? 'کاور هم با فرمت WebP ذخیره شد: ' + esc(pdata.path || '') : 'اما دانلود کاور انجام نشد: ' + esc(pdata.message || '')}`;
      }catch(pe){ if(status) status.innerHTML = `اطلاعات دریافت شد؛ اما دانلود کاور خطا داد.`; }
    } else if(status) status.innerHTML = `اطلاعات <strong>${esc(m.title)}</strong> دریافت شد؛ پوستر معتبر در OMDb نبود.`;
    scrollToSection('addMovieSection');
  }catch(e){ if(status) status.textContent = e.message || 'خطا در دریافت اطلاعات'; }
  this.disabled=false; this.innerHTML=old;
});

async function completeAttentionMovie(btn, options = {}){
  const id = btn?.dataset?.movieId;
  if(!id) return {success:false, message:'شناسه نامعتبر'};
  const old = btn.innerHTML;
  btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> تکمیل...';
  try{
    const fd = new URLSearchParams();
    fd.set('ajax_action','omdb_complete_movie'); fd.set('movie_id',id); fd.set('csrf_token',window.ADMIN_CSRF);
    if(options.overwrite) fd.set('overwrite','1');
    const res = await fetch(location.href,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:fd.toString()});
    const data = await res.json();
    if(!data.success) throw new Error(data.message || 'خطا در OMDb');
    btn.classList.remove('btn-outline'); btn.classList.add('btn-primary');
    btn.innerHTML = '<i class="fas fa-check"></i> تکمیل شد';
    const card = btn.closest('.attention-card');
    card?.classList.add('is-completed');
    card?.querySelectorAll('.badge-warning')?.forEach(b=>{ b.classList.remove('badge-warning'); b.classList.add('badge-gray'); });
    return data;
  }catch(e){
    btn.disabled = false; btn.innerHTML = old;
    if(!options.silent) alert(e.message || 'خطا در تکمیل OMDb');
    return {success:false, message:e.message || 'خطا'};
  }
}
document.querySelectorAll('.attention-omdb-btn').forEach(btn=>btn.addEventListener('click', ()=>completeAttentionMovie(btn)));

const attentionQueue = {
  interval: 5000,
  list: [],
  index: 0,
  running: false,
  paused: false,
  success: 0,
  fail: 0,
  timer: null
};
function attentionQueueLog(text, type='info'){
  const log = document.getElementById('attentionQueueLog');
  if(!log) return;
  const row = document.createElement('div');
  row.className = 'queue-log-row queue-log-' + type;
  row.innerHTML = `<span>${esc(text)}</span><small>${new Date().toLocaleTimeString('fa-IR')}</small>`;
  log.prepend(row);
  while(log.children.length > 12) log.lastElementChild.remove();
}
function buildAttentionQueue(){
  const filter = document.getElementById('attentionQueueFilter')?.value || 'all';
  const buttons = [...document.querySelectorAll('.attention-omdb-btn')].filter(btn=>{
    if(btn.disabled || btn.closest('.attention-card')?.classList.contains('is-completed')) return false;
    if(filter === 'all') return true;
    return (btn.closest('.attention-card')?.dataset?.reasons || '').includes(filter);
  });
  attentionQueue.list = buttons;
  attentionQueue.index = 0;
  attentionQueue.success = 0;
  attentionQueue.fail = 0;
  updateAttentionQueueUi();
  return buttons;
}
function updateAttentionQueueUi(){
  const total = attentionQueue.list.length;
  const done = attentionQueue.success + attentionQueue.fail;
  const left = Math.max(0, total - done);
  const pct = total ? Math.min(100, Math.round((done / total) * 100)) : 0;
  const setText = (id, value) => { const el=document.getElementById(id); if(el) el.textContent=value; };
  setText('queueTotal', total);
  setText('queueSuccess', attentionQueue.success);
  setText('queueFail', attentionQueue.fail);
  setText('queueLeft', left);
  const bar = document.getElementById('attentionQueueBar'); if(bar) bar.style.width = pct + '%';
  const status = document.getElementById('attentionOmdbStatus');
  if(status){
    if(attentionQueue.running && !attentionQueue.paused) status.textContent = `در حال اجرا: ${done}/${total}`;
    else if(attentionQueue.paused) status.textContent = `متوقف شد: ${done}/${total}`;
    else status.textContent = total ? `آماده: ${total} مورد` : 'موردی در صف نیست';
  }
  const start = document.getElementById('attentionAutoOmdbBtn');
  const pause = document.getElementById('attentionPauseOmdbBtn');
  const resume = document.getElementById('attentionResumeOmdbBtn');
  if(start) start.disabled = attentionQueue.running;
  if(pause) pause.disabled = !attentionQueue.running || attentionQueue.paused;
  if(resume) resume.disabled = !attentionQueue.paused;
}
async function runAttentionQueueNext(){
  clearTimeout(attentionQueue.timer);
  if(!attentionQueue.running || attentionQueue.paused){ updateAttentionQueueUi(); return; }
  if(attentionQueue.index >= attentionQueue.list.length){
    attentionQueue.running = false;
    attentionQueue.paused = false;
    attentionQueueLog(`صف تمام شد؛ ${attentionQueue.success} موفق و ${attentionQueue.fail} ناموفق.`, attentionQueue.fail ? 'warn' : 'ok');
    updateAttentionQueueUi();
    return;
  }
  const btn = attentionQueue.list[attentionQueue.index];
  const title = btn.closest('.attention-card')?.querySelector('.attention-title strong')?.textContent?.trim() || `فیلم #${btn.dataset.movieId}`;
  attentionQueueLog(`شروع تکمیل: ${title}`);
  const result = await completeAttentionMovie(btn, {silent:true});
  if(result.success){ attentionQueue.success++; attentionQueueLog(`موفق: ${title}`, 'ok'); }
  else { attentionQueue.fail++; attentionQueueLog(`ناموفق: ${title} — ${result.message || 'خطا'}`, 'warn'); }
  attentionQueue.index++;
  updateAttentionQueueUi();
  attentionQueue.timer = setTimeout(runAttentionQueueNext, attentionQueue.interval);
}
document.getElementById('attentionAutoOmdbBtn')?.addEventListener('click', function(){
  if(!buildAttentionQueue().length) return alert('با این فیلتر موردی برای تکمیل وجود ندارد.');
  attentionQueue.running = true;
  attentionQueue.paused = false;
  attentionQueueLog('صف تکمیل OMDb شروع شد؛ فاصله هر آیتم ۵ ثانیه است.', 'ok');
  updateAttentionQueueUi();
  runAttentionQueueNext();
});
document.getElementById('attentionPauseOmdbBtn')?.addEventListener('click', function(){
  attentionQueue.paused = true;
  clearTimeout(attentionQueue.timer);
  attentionQueueLog('صف متوقف شد.', 'warn');
  updateAttentionQueueUi();
});
document.getElementById('attentionResumeOmdbBtn')?.addEventListener('click', function(){
  if(!attentionQueue.list.length) return;
  attentionQueue.running = true;
  attentionQueue.paused = false;
  attentionQueueLog('صف ادامه پیدا کرد.', 'ok');
  updateAttentionQueueUi();
  runAttentionQueueNext();
});
document.getElementById('attentionResetOmdbBtn')?.addEventListener('click', function(){
  clearTimeout(attentionQueue.timer);
  attentionQueue.running = false;
  attentionQueue.paused = false;
  buildAttentionQueue();
  attentionQueueLog('صف ریست شد.');
});
document.getElementById('attentionQueueFilter')?.addEventListener('change', buildAttentionQueue);
buildAttentionQueue();
// v174: professional manual-ad editor
function bmDecodeBannerCss(v){
  try{var bytes=Uint8Array.from(atob(v||''),c=>c.charCodeAt(0));return new TextDecoder('utf-8').decode(bytes)}catch(e){try{return atob(v||'')}catch(_){return ''}}
}
document.querySelectorAll('.edit-banner-btn').forEach(btn => {
  btn.addEventListener('click', function() {
    const item=this.closest('.banner-item'); if(!item)return;
    const set=(id,val)=>{const el=document.getElementById(id);if(el)el.value=val??''};
    set('banner_action','update'); set('banner_id',item.dataset.id); set('banner_title',item.dataset.title); set('banner_position',item.dataset.position); set('banner_link',item.dataset.link);
    set('banner_starts_at',item.dataset.starts?item.dataset.starts.replace(' ','T').slice(0,16):''); set('banner_ends_at',item.dataset.ends?item.dataset.ends.replace(' ','T').slice(0,16):'');
    set('banner_existing_image',item.dataset.image); set('banner_existing_mobile_image',item.dataset.mobileImage); set('banner_alt_text',item.dataset.alt); set('banner_badge_text',item.dataset.badge); set('banner_cta_text',item.dataset.cta); set('banner_custom_class',item.dataset.class); set('banner_custom_css',bmDecodeBannerCss(item.dataset.css)); set('banner_object_fit',item.dataset.fit||'contain'); set('banner_priority',item.dataset.priority||'0');
    const check=(id,v)=>{const el=document.getElementById(id);if(el)el.checked=v==='1'};
    check('banner_active',item.dataset.active); check('banner_show_desktop',item.dataset.desktop); check('banner_show_mobile',item.dataset.mobile); check('banner_open_new_tab',item.dataset.newtab); check('banner_show_badge',item.dataset.showbadge); check('banner_show_cta',item.dataset.showcta);
    const rm=document.getElementById('banner_remove_mobile_image'); if(rm)rm.checked=false;
    const submit=document.getElementById('bannerSubmitBtn'); if(submit)submit.innerHTML='<i class="fas fa-pen"></i> بروزرسانی بنر';
    const cancel=document.getElementById('cancelBannerEdit'); if(cancel)cancel.style.display='inline-flex';
    document.getElementById('bannersSection')?.scrollIntoView({behavior:'smooth',block:'start'});
  });
});
document.getElementById('cancelBannerEdit')?.addEventListener('click',function(){
  const form=this.closest('form'); if(form)form.reset();
  const set=(id,val)=>{const el=document.getElementById(id);if(el)el.value=val};
  set('banner_action','create'); set('banner_id','0'); set('banner_existing_image',''); set('banner_existing_mobile_image',''); set('banner_priority','0'); set('banner_object_fit','contain');
  ['banner_active','banner_show_desktop','banner_show_mobile','banner_open_new_tab','banner_show_badge','banner_show_cta'].forEach(id=>{const el=document.getElementById(id);if(el)el.checked=true});
  const submit=document.getElementById('bannerSubmitBtn'); if(submit)submit.innerHTML='<i class="fas fa-save"></i> ذخیره بنر';
  this.style.display='none';
});
// Theme switcher
(function(){
  const saved = localStorage.getItem('adminTheme') || 'neon';
  function applyTheme(t){
    document.body.classList.remove('theme-purple','theme-red','theme-gold');
    if(t !== 'neon') document.body.classList.add('theme-' + t);
    document.querySelectorAll('.theme-chip').forEach(b=>b.classList.toggle('active', b.dataset.theme===t));
    localStorage.setItem('adminTheme', t);
  }
  applyTheme(saved);
  document.querySelectorAll('.theme-chip').forEach(btn=>btn.addEventListener('click',()=>applyTheme(btn.dataset.theme)));
})();

// CSRF auto-inject
(function(){
  function inject(){
    document.querySelectorAll('form[method="POST"], form[method="post"]').forEach(f=>{
      if(!f.querySelector('input[name="csrf_token"]')){
        const i=document.createElement('input'); i.type='hidden'; i.name='csrf_token'; i.value=window.ADMIN_CSRF; f.appendChild(i);
      }
    });
  }
  inject();
  document.addEventListener('DOMContentLoaded',inject);
  document.addEventListener('click',e=>{
    const a=e.target.closest('a[href]');
    if(!a) return;
    const h=a.getAttribute('href')||'';
    const k=['delete_movie','delete_story','add_to_admin_pick','remove_from_admin_pick','approve_comment','reject_comment','delete_comment','delete_request'];
    if(k.some(key=>h.includes(key+'='))&&!h.includes('csrf_token=')){
      const hashPos = h.indexOf('#');
      const base = hashPos >= 0 ? h.slice(0, hashPos) : h;
      const hash = hashPos >= 0 ? h.slice(hashPos) : '';
      a.setAttribute('href', base + (base.includes('?') ? '&' : '?') + 'csrf_token=' + encodeURIComponent(window.ADMIN_CSRF) + hash);
    }
  },true);
})();
</script>

<script id="ultra-pro-admin-js">
(function(){
  const cards = document.querySelectorAll('.glass-card, .chart-card, .stat-card');
  cards.forEach((el, i) => {
    el.classList.add('admin-stagger');
    el.style.animationDelay = Math.min(i * 35, 420) + 'ms';
  });

  const navLinks = [...document.querySelectorAll('.sidebar-nav a[onclick*="scrollToSection"]')];
  const sections = navLinks.map(a => {
    const match = (a.getAttribute('onclick') || '').match(/scrollToSection\('([^']+)'\)/);
    return match ? { link: a, el: document.getElementById(match[1]) } : null;
  }).filter(Boolean);

  if('IntersectionObserver' in window && sections.length) {
    const io = new IntersectionObserver((entries) => {
      const visible = entries
        .filter(e => e.isIntersecting)
        .sort((a,b) => b.intersectionRatio - a.intersectionRatio)[0];
      if(!visible) return;
      const found = sections.find(s => s.el === visible.target);
      if(!found) return;
      navLinks.forEach(a => a.classList.remove('active'));
      found.link.classList.add('active');
    }, { rootMargin: '-28% 0px -58% 0px', threshold: [0.08, 0.18, 0.32] });
    sections.forEach(s => io.observe(s.el));
  }

  document.addEventListener('keydown', function(e){
    if(e.key !== 'Escape') return;
    document.querySelectorAll('.modal.open').forEach(m => m.classList.remove('open'));
    document.getElementById('sidebar')?.classList.remove('open');
  });
})();
</script>
<script src="/assets/js/bm-performance.js?v=mobile-lite66" defer></script>
<script id="bm-v172-editor-js">
(function(){
 const desc=document.getElementById('addDescription'), count=document.getElementById('addSummaryCount'), preview=document.getElementById('addSummaryPreview');
 function syncSummary(){if(count&&desc)count.textContent=(desc.value.length).toLocaleString('fa-IR')+' / ۲۶۰۰';}
 desc?.addEventListener('input',syncSummary);syncSummary();
 document.getElementById('addSummaryPreviewBtn')?.addEventListener('click',()=>{if(!preview||!desc)return;preview.hidden=!preview.hidden;preview.textContent=desc.value.trim()||'هنوز خلاصه‌ای نوشته نشده.';});
 const pi=document.getElementById('addPosterInput'), pp=document.getElementById('addPosterPreview');pi?.addEventListener('change',()=>{const f=pi.files?.[0];if(!f||!pp)return;const u=URL.createObjectURL(f);pp.innerHTML='<img alt="preview">';pp.querySelector('img').src=u;});
 const box=document.querySelector('.bm-release-editor'), out=document.getElementById('addReleasePreview');
 function syncUpdate(){if(!box||!out)return;const v=n=>box.querySelector('[name="'+n+'"]')?.value.trim()||'', c=n=>!!box.querySelector('[name="'+n+'"]')?.checked;const e=v('last_episode');out.textContent=e?('قسمت '+e+' اضافه شد'):'بدون آپدیت ثبت‌شده';}
 box?.querySelectorAll('input').forEach(x=>x.addEventListener('input',syncUpdate));box?.querySelectorAll('input[type="checkbox"]').forEach(x=>x.addEventListener('change',syncUpdate));syncUpdate();
})();
</script>
</body>
</html>