# نصب BankMovie Desktop Server v1.9.0

## فایل‌های اصلی
این فایل‌ها را در ریشه سایت و مسیرهای متناظر آپلود کنید:

- desktop_api.php
- desktop_user_api.php
- desktop_config.php
- admin_desktop.php
- includes/desktop_proxy_auth.php
- includes/desktop_config_lib.php
- includes/desktop_archive4_bridge.php

## اضافه کردن گزینه کنترل دسکتاپ به admin.php
روش امن‌تر این است که به‌جای جایگزینی کامل admin.php، اسکریپت زیر را روی سرور اجرا کنید:

```bash
php tools/patch_admin_desktop_menu.php /path/to/public_html
```

اسکریپت قبل از تغییر از admin.php بکاپ timestamp دار می‌سازد.

فایل `admin.php` کامل نیز فقط برای نصب روی همان snapshot سورسی که هنگام ساخت این بسته استفاده شده، داخل بسته قرار دارد.

## Archive 4
در نسخه Desktop، Archive 4 مستقیماً از runtime سینماتیک `includes/api4_lib.php` سرو می‌شود و دیگر وارد مسیر SerialBlog/api5 نمی‌شود. مسیر Android تغییر نکرده است.

## VIP / Archive 5
Desktop Config v2 می‌تواند سیاست هر آرشیو را از سایت/Android به ارث ببرد یا مستقل override شود. هنگام مهاجرت از Desktop Config قدیمی v1، archive policyها دوباره روی حالت «همگام با سایت» قرار می‌گیرند تا Public قدیمی روی VIP زنده سایت override نکند.

در `admin_desktop.php` برای هر آرشیو می‌توانید جداگانه مشخص کنید:
- فعال / مخفی
- ورود عمومی/member/VIP/admin
- پخش عمومی/member/VIP/admin/disabled
- دانلود عمومی/member/VIP/admin/disabled
- همگام با سایت یا تنظیم مستقل Desktop

## امنیت
کلاینت Windows هیچ App Secret ثابتی ندارد. `desktop_api.php` و `desktop_user_api.php` درخواست داخلی به APIهای موجود سایت را سمت سرور امضا می‌کنند.
