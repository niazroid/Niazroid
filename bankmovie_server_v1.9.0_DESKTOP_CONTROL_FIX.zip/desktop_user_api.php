<?php
declare(strict_types=1);
@ini_set('display_errors','0');
@ini_set('log_errors','1');

require_once __DIR__ . '/includes/desktop_proxy_auth.php';
$target = __DIR__ . '/app_user_api.php';
if (!is_file($target)) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status'=>'error','message'=>'Desktop account gateway unavailable.']);
    exit;
}

bm_desktop_proxy_apply_signature($target, 'BM_USER_APP_KEY', 'BM_USER_APP_SECRET');
$_SERVER['HTTP_X_BM_NOTIFICATION_PROTOCOL'] = $_SERVER['HTTP_X_BM_NOTIFICATION_PROTOCOL'] ?? '2';
require $target;
