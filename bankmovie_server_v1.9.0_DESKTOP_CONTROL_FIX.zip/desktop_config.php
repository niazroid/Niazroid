<?php
declare(strict_types=1);
@ini_set('display_errors','0');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: no-store, max-age=0');
header('X-Content-Type-Options: nosniff');
require_once __DIR__.'/includes/security_bootstrap.php';
require_once __DIR__.'/includes/desktop_config_lib.php';
$desktop=bm_desktop_config_load();
$site=bm_desktop_site_remote_config();
$domain=rtrim((string)$desktop['active_domain'],'/');
$archives=bm_desktop_effective_archive_policies($desktop,$site);
$features=array_replace((array)($site['features']??[]),(array)($desktop['features']??[]));
$out=$site;
$out['status']='ok';$out['platform']='windows';$out['schema_version_desktop']=3;
$out['active_domain']=$domain;
$out['desktop_api_url']=$domain.(string)$desktop['desktop_api_path'];
$out['api_url']=$out['desktop_api_url'];
$out['account_api_url']=$domain.(string)$desktop['account_api_path'];
$out['features']=$features;
$out['app_archive_policy']=$archives;$out['archive_policy']=$archives;
$out['desktop']=[
  'enabled'=>(bool)$desktop['enabled'],'latest_version'=>$desktop['latest_version'],'minimum_version'=>$desktop['minimum_version'],
  'force_update'=>(bool)$desktop['force_update'],'download_url'=>$desktop['download_url'],'notice'=>$desktop['notice'],
  'features'=>$desktop['features'],'archives'=>$archives,'updated_at'=>$desktop['updated_at']??null
];
echo json_encode($out,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
