<?php
declare(strict_types=1);
@ini_set('display_errors','0');
@ini_set('log_errors','1');

require_once __DIR__.'/includes/desktop_archive4_bridge.php';
if (bm_desktop_archive4_try_handle()) exit;

require_once __DIR__ . '/includes/desktop_proxy_auth.php';
$target = __DIR__ . '/app_api.php';
if (!is_file($target)) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status'=>'error','message'=>'Desktop gateway unavailable.']);
    exit;
}

// Sign internally on the server. No static app secret is required in the EXE.
bm_desktop_proxy_apply_signature($target, 'BM_APP_AUTH_KEY', 'BM_APP_AUTH_SECRET');
$_SERVER['HTTP_X_BM_DOWNLOAD_SYSTEM'] = '2';
require $target;
