'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const base=path.join(__dirname,'..');
const app=fs.readFileSync(path.join(base,'src/app.js'),'utf8');
const html=fs.readFileSync(path.join(base,'src/index.html'),'utf8');
const pkg=require('../package.json');
assert.equal(pkg.version,'1.0.0');
assert.match(html,/آخرین نسخه: 1\.0\.0/);
assert.match(app,/state\.archive=enabledArchives\(\)\.includes\(1\)\?1:\(enabledArchives\(\)\[0\]\|\|1\)/);
assert.doesNotMatch(app,/state\.archive=Number\(state\.settings\.preferredArchive\|\|enabledArchives\(\)\[0\]\|\|1\)/);
assert.match(app,/آخرین نسخه: \$\{esc\(state\.appVersion\|\|'1\.0\.0'\)\}/);
assert.match(app,/Automatic fallback lasts for this session only/);
assert.match(app,/آرشیو ۱ در حال حاضر قابل استفاده نیست/);
assert.deepEqual(pkg.build.win.target[0].arch,['x64']);

// Execute the real fallback function with a stubbed bridge and UI.
const start=app.indexOf('async function bm1124ShowHome(force=false){');
const end=app.indexOf('\n/* This final override',start);
assert.ok(start>0&&end>start);
const fn=app.slice(start,end);
async function testScenario(firstWorks){
  const calls={archiveRequests:[],persist:[],notices:[],toast:[]};
  const state={archive:1,language:'fa'};
  const view={innerHTML:'',prepend:n=>calls.notices.push(n.textContent)};
  const selector={value:''};
  const context={
    state,ARCHIVE_NAMES:{1:'آرشیو ۱',2:'آرشیو ۲'},
    enabledArchives:()=>[1,2],archiveActionNeedsVip:()=>false,isVip:()=>false,
    bm1124ArchiveCandidates:p=>[p,...[1,2].filter(n=>n!==p)],
    bm1124LoadHomeArchive:async n=>{calls.archiveRequests.push(n); return n===1&&!firstWorks?{ok:false,error:new Error('offline')}:{ok:true,data:{archive:n}}},
    setActiveNav:()=>{},setLoading:()=>{},
    $:s=>s==='#view'?view:s==='#archiveSelect'?selector:null,
    bridge:{setSettings:async p=>calls.persist.push(p)},
    updateSearchPlaceholder:()=>{},renderTopCategories:()=>{},renderHome:r=>calls.rendered=r.archive,
    bm1124ApplySectionControls:()=>{},bm1123EnsureHomeFooter:()=>{},bm1123RefreshHeaderFilter:()=>{},
    document:{createElement:()=>({className:'',setAttribute(){},textContent:''})},
    toast:(msg)=>calls.toast.push(msg),
    bm1124ArchiveUnavailableHtml:()=>'<div>error</div>',$$:()=>[],publicUiError:e=>String(e),
    console,
  };
  vm.createContext(context);
  vm.runInContext(fn,context);
  await context.bm1124ShowHome(false);
  return {calls,state,selector};
}
(async()=>{
  const ok=await testScenario(true);
  assert.deepEqual(ok.calls.archiveRequests,[1]);
  assert.equal(ok.state.archive,1);
  assert.equal(ok.calls.notices.length,0);
  const fail=await testScenario(false);
  assert.deepEqual(fail.calls.archiveRequests,[1,2]);
  assert.equal(fail.state.archive,2);
  assert.equal(fail.calls.rendered,2);
  assert.equal(fail.calls.persist.length,0,'automatic fallback must not save selection');
  assert.match(fail.calls.notices[0],/آرشیو ۱/);
  assert.match(fail.calls.notices[0],/آرشیو ۲/);
  console.log('PASS version 1.0.0, startup Archive 1, safe archive failover, visible notice and x64-only build');
})().catch(e=>{console.error(e);process.exit(1)});
