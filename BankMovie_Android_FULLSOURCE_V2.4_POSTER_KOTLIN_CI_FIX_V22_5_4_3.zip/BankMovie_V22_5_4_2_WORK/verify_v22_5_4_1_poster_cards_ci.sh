#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
php -l server-required/api5_lib.php >/dev/null
php -l server-required/includes/api4_lib.php >/dev/null
python3 - <<'PYTEST'
from pathlib import Path
main = Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
workflow = Path('.github/workflows/build-bankmovie.yml').read_text()
# Prevent Kotlin compiler errors caused by duplicated imports in any Kotlin source.
from collections import Counter
for kotlin_file in Path('app/src/main/java').rglob('*.kt'):
    import_lines = [line.strip() for line in kotlin_file.read_text(encoding='utf-8').splitlines() if line.strip().startswith('import ')]
    duplicates = [key for key, count in Counter(import_lines).items() if count > 1]
    assert not duplicates, f'Duplicate Kotlin imports in {kotlin_file}: {duplicates}'
assert main.count('import java.nio.ByteBuffer') == 1
assert 'POSTER_KOTLIN_CI_FIX_V22_5_4_3.zip' in workflow
assert 'verify_v22_5_4_1_poster_cards_ci.sh' in workflow
loader = main[main.index('private fun loadImage('):main.index('private fun animateExpandable(',main.index('private fun loadImage('))]
for required in ('instanceFollowRedirects = true', 'image/webp,image/jpeg,image/png',
    'conn.responseCode', 'status !in 200..299', 'Poster HTTPS redirect downgrade',
    'ImageDecoder.decodeBitmap', 'Unsupported poster format', 'BankMoviePoster',
    'pendingPosterTargets.remove(finalUrl)', 'PosterDiskCache.write'):
    assert required in loader, 'Missing image loader guard: ' + required
assert 'image/avif' not in loader
normalizer = main[main.index('private fun normalizeArchiveItem('):main.index('private fun normalizeArchiveResponse(')]
assert 'posterString(item.opt(key))' in normalizer
assert '"poster_url", "image", "image_url", "thumbnail", "thumb"' in normalizer
assert 'archive == 5' in normalizer and 'archive == 3 || archive == 4' in normalizer
# Make sure the old security + real API quota layers are still in source.
for token in ('BmV22Client.attach', 'BmApiRateLimit.requireContentOpenAllowed', 'quotaRequest(', 'archive5ApiUrl('):
    assert token in main
print('VERIFY_V22_5_4_1_POSTER_CARDS_CI_OK')
PYTEST
