package ir.bankmoviee.app

// BANKMOVIE_PASS4_6_2_SOURCE_FINGERPRINT: player-lifecycle-guest-glass-viewgroup-compile-fix
// BANKMOVIE_V7_23_PLAYER_LAST_FRAME_HOLD: PixelCopy SurfaceView freeze-frame lifecycle bridge
// BANKMOVIE_V7_25_PLAYER_FRAME_BRIDGE: hold last frame until a real non-black VLC surface frame is verified
// BANKMOVIE_V7_26_PLAYER_UTILITY_ICON_TUNING: slightly smaller utility glyphs; play/seek controls unchanged

import android.app.Activity
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.GridLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.util.UUID
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.PixelCopy
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class PlayerActivity : Activity() {

    companion object {
        const val EXTRA_VIDEO_URL = "video_url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_PLAYLIST_JSON = "playlist_json"
        const val EXTRA_PLAYLIST_FILE = "playlist_file"
        const val EXTRA_PROGRESS_KEY = "progress_key"
        const val EXTRA_RESUME_POSITION = "resume_position"
        const val EXTRA_WATCH_PARTY_ROOM_CODE = "watch_party_room_code"
        const val EXTRA_WATCH_PARTY_ROLE = "watch_party_role"
        const val EXTRA_WATCH_PARTY_INVITE_URL = "watch_party_invite_url"
        private const val REQ_WATCH_PARTY_AUDIO = 7401

        // V7.22: keep the native player session alive briefly while the app is in
        // the background. Longer retention wastes decoder/native memory; after this
        // window we fall back to the existing saved-position rebuild path.
        private const val PLAYER_BACKGROUND_RETAIN_MS = 180_000L
        // V7.25: never expose the freshly re-attached black SurfaceView. Probe the
        // underlying VLC surface with tiny PixelCopy samples and remove the held
        // frame only after two consecutive rendered-frame samples are confirmed.
        private const val PLAYER_FRAME_PROBE_INTERVAL_MS = 140L
        private const val PLAYER_FRAME_PROBE_TIMEOUT_MS = 12_000L
        private const val PLAYER_UTILITY_ICON_DP = 24
        private const val VOLUME_BOOST_MAX_PERCENT = 200f
        private const val STATE_PLAYER_INDEX = "bm_player_index"
        private const val STATE_PLAYER_POSITION = "bm_player_position"
        private const val STATE_PLAYER_WAS_PLAYING = "bm_player_was_playing"
        private const val STATE_PLAYER_SPEED = "bm_player_speed"
        private const val STATE_PLAYER_MODE = "bm_player_mode"
        private const val STATE_PARTY_READY_CONFIRMED = "bm_party_ready_confirmed"
        private const val STATE_PARTY_PLAYBACK_STARTED = "bm_party_playback_started"
    }

    data class Track(
        val url: String,
        val title: String,
        val quality: String,
        val type: String,
        val label: String,
        val typeFa: String,
        val displayLabel: String,
        val isAudio: Boolean,
        val season: Int,
        val episode: Int,
        val progressKey: String
    )

    private val blue: Int get() = UiPreferences.accentColor(this)
    private val blue2: Int get() = UiPreferences.blend(blue, Color.WHITE, 0.28f)
    private val blue3: Int get() = Color.argb(170, Color.red(blue), Color.green(blue), Color.blue(blue))
    private val panel = Color.argb(230, 12, 12, 14)
    private val stroke = Color.argb(115, 255, 255, 255)
    private val white = Color.WHITE
    private val muted = Color.rgb(190, 192, 202)

    private lateinit var root: FrameLayout
    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var lifecycleFrameOverlay: ImageView
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var centerControls: LinearLayout
    private lateinit var playerTopActions: LinearLayout
    private lateinit var playerBottomActions: LinearLayout
    private lateinit var titleText: TextView
    private lateinit var subText: TextView
    private lateinit var playerMetaRow: LinearLayout
    private lateinit var seek: SeekBar
    private lateinit var currentTimeText: TextView
    private lateinit var totalTimeText: TextView
    private lateinit var hudBox: TextView
    private lateinit var volumeGestureHud: FrameLayout
    private lateinit var volumeGestureTrack: FrameLayout
    private lateinit var volumeGestureLevel: View
    private lateinit var volumeGesturePercent: TextView
    private lateinit var volumeGestureIcon: ImageView
    private var volumeGestureTrackHeightPx = 0
    private lateinit var brightnessGestureHud: FrameLayout
    private lateinit var brightnessGestureTrack: FrameLayout
    private lateinit var brightnessGestureLevel: View
    private lateinit var brightnessGesturePercent: TextView
    private lateinit var brightnessGestureIcon: ImageView
    private var brightnessGestureTrackHeightPx = 0
    private lateinit var playIcon: ImageView
    private lateinit var playButtonBox: FrameLayout
    private lateinit var fitIcon: ImageView
    private lateinit var lockIcon: ImageView
    private lateinit var unlockOverlay: FrameLayout

    private var vlc: LibVLC? = null
    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tracks = mutableListOf<Track>()
    private var currentIndex = 0
    private var title = "Bankmovie"
    private var videoUrl = ""
    private var progressKey = ""
    private var requestedResumePosition = 0L
    private var resumeTarget = 0L
    private var resumeGuardUntil = 0L
    private var seekJumpMs = 10000L
    private val modes = arrayOf("FIT", "CROP", "STRETCH")
    private val modeTitles = arrayOf("متناسب", "برش سینمایی", "کشیده")
    private var modeIndex = 0
    private var controlsLocked = false
    private var lastTap = 0L
    private var touchStartX = 0f
    private var touchStartRawY = 0f
    private var lastGestureRawY = 0f
    private var gestureVolumePercent = 0f
    private var currentVlcVolumePercent = 100
    private var lastAppliedBrightness = -1f
    private var gestureMode = 0 // 0 none, 1 brightness, 2 volume
    private var controlsVisible = true
    private var sleepMinutes = 0
    private var currentSpeed = 1.0f
    private var hardwareDecoder = true
    private var autoPlayNext = true
    private var nextPromptShownKey = ""
    private var skipNextOnce = false
    private var nextPromptDialog: AlertDialog? = null
    private var lastProgressSaveAt = 0L
    private var resumeApplied = false
    private var playbackRetryCount = 0
    private val maxPlaybackRetries = 5
    private var playbackRetryScheduled = false
    private var bufferingStartedAt = 0L
    private var recentLongBufferCount = 0
    private var decoderAutoFallbackUsed = false
    private var lifecycleRestorePending = false
    private var lifecycleWasPlaying = false
    private var lifecyclePosition = 0L
    private var lifecyclePausedAt = 0L
    private var pauseAfterLifecycleRestore = false
    private var lifecycleViewsDetached = false
    private var lifecycleRestoreGeneration = 0
    private var restoredFromInstanceState = false
    private var restoredInstanceWasPlaying = true
    // V7.23: keep a lightweight copy of the last rendered video frame above the
    // VLC surface while Android recreates/re-attaches that surface after HOME/app-switch.
    // This prevents the user-visible black flash without retaining a whole View tree.
    private var lifecycleFrameBitmap: Bitmap? = null
    private var lifecycleFrameCapturePending = false
    private var lifecycleFrameAwaitingVideo = false
    private var lifecycleFrameVoutSeen = false
    private var lifecycleFrameCaptureGeneration = 0
    private var lifecycleFrameLastCaptureAt = 0L
    private var lifecycleFrameProbeGeneration = 0
    private var lifecycleFrameProbeStartedAt = 0L
    private var lifecycleFrameProbeReadySamples = 0
    private var lifecycleFrameProbePending = false
    private val releaseRetainedPlayerRunnable = Runnable {
        if (!lifecycleRestorePending || isFinishing || isDestroyed) return@Runnable
        val keep = max(lifecyclePosition, runCatching { player?.time ?: 0L }.getOrDefault(0L)).coerceAtLeast(0L)
        if (keep > 0L) requestedResumePosition = max(requestedResumePosition, keep)
        savePlaybackProgress(true)
        // Free the heavy native decoder after the short retained-session window.
        // onResume will transparently rebuild at requestedResumePosition if needed.
        releasePlayerAsyncForRebuild()
    }
    private var lastGuestControlNoticeAt = 0L
    private var subtitleDelayMs = 0
    private var subtitleScale = 112
    private var subtitlePositionIndex = 0
    private val subtitlePositions = arrayOf("پایین", "وسط", "بالا")
    private val subtitleMargins = arrayOf("70", "205", "350")
    private var subtitleEnabled = true
    private var subtitleTextColor = Color.YELLOW
    private var subtitleBackgroundMode = "black"
    private var subtitleFontMode = "system"
    private var subtitleBold = true
    private var lastEnabledSpuTrack = 0
    private var preferredAudioTrackId = Int.MIN_VALUE
    private var preferredSubtitleTrackId = Int.MIN_VALUE
    private var longPress2x = false
    private val longPressRunnable = Runnable {
        longPress2x = true
        setTemporarySpeed(true)
    }
    private val volumeGestureHideRunnable = Runnable {
        if (!::volumeGestureHud.isInitialized) return@Runnable
        volumeGestureHud.animate().cancel()
        volumeGestureHud.animate()
            .alpha(0f)
            .translationX((-dp(6)).toFloat())
            .setDuration(145L)
            .withEndAction { volumeGestureHud.visibility = View.GONE }
            .start()
    }
    private val brightnessGestureHideRunnable = Runnable {
        if (!::brightnessGestureHud.isInitialized) return@Runnable
        brightnessGestureHud.animate().cancel()
        brightnessGestureHud.animate()
            .alpha(0f)
            .translationX(dp(6).toFloat())
            .setDuration(145L)
            .withEndAction { brightnessGestureHud.visibility = View.GONE }
            .start()
    }
    private val audioManager by lazy { getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager }


    // PASS 4 — Native Watch Party state. The app talks to the exact same tables
    // used by the website through app_user_api.php, so web and Android can share a room.
    private var partyRoomCode = ""
    private var partyRole = ""
    private var partyInviteUrl = ""
    private var partyIsHost = false
    private var partyActive = false
    private var partyApplyingRemote = false
    private var partyLastEventId = 0L
    private var partyLastMessageId = 0L
    private var partyLastSequence = -1L
    private var partyServerOffsetMs = 0L
    private var partyLastPollAt = 0L
    private var partyLastHeartbeatAt = 0L
    private var partyLastHostActionAt = 0L
    private var partyMembers = JSONArray()
    private var partyThemeKey = "simple"
    private var partyRoomTitle = ""
    private var partyRoomPoster = ""
    private var partyChatEnabled = true
    private var partyPollInFlight = false
    private var partyDock: LinearLayout? = null
    private var partyStatusChip: TextView? = null
    private var partyChatScroll: ScrollView? = null
    private var partyChatList: LinearLayout? = null
    private var partyChatDialog: AlertDialog? = null
    private var partyLobbyDialog: AlertDialog? = null
    private val partyMessageIdsShown = linkedSetOf<Long>()
    private var partyUnreadChat = 0
    private var partyChatButton: View? = null
    private var partyPlaybackStarted = false
    // A joined guest must explicitly confirm inside the player lobby before any
    // host state is allowed to create/start the local decoder.
    private var partyReadyConfirmed = false
    // V7.44.8 — keep one canonical room source and serialize the transition out
    // of the lobby. This prevents a second LibVLC instance from being created
    // while the first one is still attaching its Surface on Xiaomi/MIUI devices.
    private var partySharedSourceUrl = ""
    private var partyReadyLaunchInFlight = false
    private var partyGuestAutoStarting = false
    private var partyLastExplicitPlaySentAt = 0L
    private val partyChromeHideRunnable = Runnable {
        if (partyActive && partyChatDialog?.isShowing != true) setPartyChromeVisible(false)
    }

    private val partyPollRunnable = object : Runnable {
        override fun run() {
            if (partyActive && !isFinishing && !isDestroyed) {
                pollWatchParty()
                if (partyIsHost) sendWatchPartyHeartbeatIfNeeded()
                handler.postDelayed(this, if (partyIsHost) 420L else 360L)
            }
        }
    }

    // PASS 4.3 — Voice Call/WebRTC intentionally removed. Watch Party is chat + synchronized playback only.

    private val hideRunnable = Runnable { if (!controlsLocked) hideControls() }
    private val hudHideRunnable = Runnable { hudBox.visibility = View.GONE }
    private val sleepRunnable = Runnable {
        Toast.makeText(this, "زمان خواب رسید", Toast.LENGTH_SHORT).show()
        finish()
    }
    private val progressRunnable = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enterImmersive()
        try {
            parseIncoming()
            loadUiPreferences()
            restoreInstancePlaybackState(savedInstanceState)
            if (tracks.isEmpty() && videoUrl.isNotBlank()) tracks.add(Track(videoUrl, title, "", "", "", "", "", false, 0, 0, progressKey.ifBlank { "progress_$videoUrl" }))
            if (currentIndex !in tracks.indices) currentIndex = 0
            videoUrl = tracks.getOrNull(currentIndex)?.url ?: videoUrl
            title = tracks.getOrNull(currentIndex)?.title ?: title
            progressKey = tracks.getOrNull(currentIndex)?.progressKey?.ifBlank { progressKey } ?: progressKey
            if (videoUrl.isBlank()) throw IllegalArgumentException("Empty playback URL")
            currentBrightness = if (window.attributes.screenBrightness > 0f) window.attributes.screenBrightness else 0.55f
            buildUi()
            if (partyRoomCode.isNotBlank()) {
                partyActive = true
                partyIsHost = partyRole.equals("host", true)
                buildWatchPartyOverlay()
                updateGuestPlaybackLockUi()
                if (partyReadyConfirmed) {
                    // V7.44.8 — only restore a decoder if playback had actually begun.
                    // A ready guest can legitimately be waiting for the host with no
                    // local VLC instance yet; recreating one here caused double-starts.
                    if (partyPlaybackStarted) {
                        switchTo(currentIndex, preserveRequestedResume = restoredFromInstanceState)
                    } else {
                        showControls()
                        showPartyChrome()
                    }
                } else {
                    showWatchPartyLobby()
                }
                handler.removeCallbacks(partyPollRunnable)
                handler.postDelayed(partyPollRunnable, 350L)
            } else {
                if (restoredFromInstanceState && !restoredInstanceWasPlaying) {
                    pauseAfterLifecycleRestore = true
                }
                switchTo(currentIndex, preserveRequestedResume = restoredFromInstanceState)
            }
        } catch (_: Throwable) {
            Toast.makeText(this, "این نسخه پخش معتبر نیست؛ نسخه دیگری را انتخاب کنید", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun restoreInstancePlaybackState(state: Bundle?) {
        if (state == null) return
        restoredFromInstanceState = true
        currentIndex = state.getInt(STATE_PLAYER_INDEX, currentIndex)
        requestedResumePosition = max(
            requestedResumePosition,
            state.getLong(STATE_PLAYER_POSITION, 0L).coerceAtLeast(0L)
        )
        restoredInstanceWasPlaying = state.getBoolean(STATE_PLAYER_WAS_PLAYING, true)
        currentSpeed = state.getFloat(STATE_PLAYER_SPEED, currentSpeed).coerceIn(0.5f, 2.0f)
        modeIndex = state.getInt(STATE_PLAYER_MODE, modeIndex).coerceIn(0, modes.lastIndex)
        partyReadyConfirmed = state.getBoolean(STATE_PARTY_READY_CONFIRMED, partyReadyConfirmed)
        partyPlaybackStarted = state.getBoolean(STATE_PARTY_PLAYBACK_STARTED, partyPlaybackStarted)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        val current = player
        val pos = max(
            requestedResumePosition,
            runCatching { current?.time ?: lifecyclePosition }.getOrDefault(lifecyclePosition)
        ).coerceAtLeast(0L)
        outState.putInt(STATE_PLAYER_INDEX, currentIndex)
        outState.putLong(STATE_PLAYER_POSITION, pos)
        outState.putBoolean(STATE_PLAYER_WAS_PLAYING, runCatching { current?.isPlaying ?: lifecycleWasPlaying }.getOrDefault(lifecycleWasPlaying))
        outState.putFloat(STATE_PLAYER_SPEED, currentSpeed)
        outState.putInt(STATE_PLAYER_MODE, modeIndex)
        outState.putBoolean(STATE_PARTY_READY_CONFIRMED, partyReadyConfirmed)
        outState.putBoolean(STATE_PARTY_PLAYBACK_STARTED, partyPlaybackStarted)
        super.onSaveInstanceState(outState)
    }

    private var currentBrightness = 0.55f

    private fun loadUiPreferences() {
        subtitleEnabled = UiPreferences.subtitleEnabled(this)
        subtitleTextColor = UiPreferences.subtitleTextColor(this)
        subtitleBackgroundMode = UiPreferences.subtitleBackgroundMode(this)
        subtitleScale = UiPreferences.subtitleScale(this)
        subtitleDelayMs = UiPreferences.subtitleDelayMs(this)
        subtitleFontMode = UiPreferences.subtitleFontMode(this)
        subtitleBold = UiPreferences.subtitleBold(this)
        subtitlePositionIndex = UiPreferences.subtitlePosition(this)
        seekJumpMs = UiPreferences.seekSeconds(this).toLong() * 1000L
        autoPlayNext = UiPreferences.autoNext(this)
    }

    private fun parseIncoming() {
        videoUrl = intent.getStringExtra(EXTRA_VIDEO_URL) ?: ""
        title = intent.getStringExtra(EXTRA_TITLE) ?: "Bankmovie"
        progressKey = intent.getStringExtra(EXTRA_PROGRESS_KEY) ?: ""
        requestedResumePosition = intent.getLongExtra(EXTRA_RESUME_POSITION, 0L).coerceAtLeast(0L)
        partyRoomCode = intent.getStringExtra(EXTRA_WATCH_PARTY_ROOM_CODE).orEmpty().trim()
        partyRole = intent.getStringExtra(EXTRA_WATCH_PARTY_ROLE).orEmpty().trim()
        partyInviteUrl = intent.getStringExtra(EXTRA_WATCH_PARTY_INVITE_URL).orEmpty().trim()
        val payloadFile = intent.getStringExtra(EXTRA_PLAYLIST_FILE).orEmpty()
        val json = if (payloadFile.isNotBlank()) {
            runCatching {
                File(payloadFile).takeIf { it.isFile && it.length() in 1..2_500_000L }?.readText(Charsets.UTF_8).orEmpty()
            }.getOrDefault("").ifBlank { intent.getStringExtra(EXTRA_PLAYLIST_JSON).orEmpty() }
        } else {
            intent.getStringExtra(EXTRA_PLAYLIST_JSON).orEmpty()
        }
        if (json.isNotBlank()) {
            try {
                val obj = JSONObject(json)
                currentIndex = obj.optInt("selectedIndex", 0)
                val arr = obj.optJSONArray("tracks") ?: JSONArray()
                for (i in 0 until min(arr.length(), 160)) {
                    val it = arr.optJSONObject(i) ?: continue
                    if (it.optString("url").isBlank()) continue
                    tracks.add(
                        Track(
                            it.optString("url"),
                            it.optString("title", title),
                            it.optString("quality"),
                            it.optString("type"),
                            it.optString("label"),
                            it.optString("type_fa"),
                            it.optString("display_label"),
                            it.optBoolean("is_audio", false),
                            it.optInt("season", 0),
                            it.optInt("episode", 0),
                            it.optString("progress_key").ifBlank { "progress_${it.optString("url")}" }
                        )
                    )
                }
            } catch (_: Throwable) {}
        }
    }

    private fun isTvLike(): Boolean {
        val mode = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK
        return mode == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION || resources.configuration.smallestScreenWidthDp >= 600
    }

    private fun playerFocusDrawable(radiusDp: Int): android.graphics.drawable.Drawable {
        val glow = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(Color.argb(50, Color.red(blue), Color.green(blue), Color.blue(blue)))
            setStroke(dp(2), Color.argb(205, Color.red(blue), Color.green(blue), Color.blue(blue)))
        }
        val ring = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dp(3), blue2)
        }
        return android.graphics.drawable.LayerDrawable(arrayOf(glow, ring)).apply {
            setLayerInset(1, dp(4), dp(4), dp(4), dp(4))
        }
    }

    private fun applyPlayerFocus(view: View, radiusDp: Int = 22, scale: Float = 1.06f, normalElevation: Float = 0f) {
        if (!isTvLike()) return
        if (view.getTag(R.id.bm_tv_focus_bound) == true) return
        view.setTag(R.id.bm_tv_focus_bound, true)
        val originalForeground = view.foreground
        view.isFocusable = true
        view.isClickable = true
        view.isFocusableInTouchMode = false
        if (android.os.Build.VERSION.SDK_INT >= 26) view.defaultFocusHighlightEnabled = false
        var parent = view.parent
        while (parent is android.view.ViewGroup) {
            parent.clipChildren = false
            parent.clipToPadding = false
            parent = parent.parent
        }
        view.setOnFocusChangeListener { v, has ->
            v.animate().cancel()
            v.foreground = if (has) playerFocusDrawable(radiusDp) else originalForeground
            v.elevation = if (has) dp(24).toFloat() else normalElevation
            v.translationZ = if (has) dp(8).toFloat() else 0f
            v.animate()
                .scaleX(if (has) scale else 1f)
                .scaleY(if (has) scale else 1f)
                .setDuration(if (has) 145L else 105L)
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        }
    }

    private fun focusPlayButton() {
        if (partyGuestPlaybackLocked()) {
            partyChatButton?.takeIf { it.isShown && it.isFocusable }?.requestFocus() ?: root.requestFocus()
            return
        }
        if (::playButtonBox.isInitialized) {
            playButtonBox.requestFocus()
        } else {
            root.requestFocus()
        }
    }

    private fun applyPlayerFocusTree(view: View) {
        view.postDelayed({
            fun walk(v: View) {
                if (v is android.view.ViewGroup) {
                    v.clipChildren = false
                    v.clipToPadding = false
                }
                val skip = v is ScrollView || v is SeekBar
                if (!skip && v.hasOnClickListeners()) {
                    applyPlayerFocus(v, 20, 1.055f, v.elevation)
                }
                if (v is android.view.ViewGroup) {
                    for (i in 0 until v.childCount) walk(v.getChildAt(i))
                }
            }
            walk(view)
        }, 55)
    }

    private fun ccAudioSubtitleButton(click: () -> Unit): View {
        return FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            isClickable = true
            isFocusable = true
            contentDescription = "صدا و زیرنویس"
            applyPlayerFocus(this, 20, 1.08f, 0f)
            setOnClickListener { click() }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(R.drawable.ic_player_cc)
                setColorFilter(Color.WHITE)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, FrameLayout.LayoutParams(dp(PLAYER_UTILITY_ICON_DP), dp(PLAYER_UTILITY_ICON_DP), Gravity.CENTER))
        }
    }

    private fun buildUi() {
        root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            isFocusable = true
            isFocusableInTouchMode = true
        }
        videoLayout = VLCVideoLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            isFocusable = true
            isFocusableInTouchMode = true
        }
        root.addView(videoLayout, FrameLayout.LayoutParams(-1, -1))

        // V7.23 LAST-FRAME HOLD: sits above VLC only, below all player chrome.
        // It is shown solely during lifecycle restoration and disappears only after
        // VLC reports a fresh video output/time update.
        lifecycleFrameOverlay = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_XY
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
            isFocusable = false
            isClickable = false
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        root.addView(lifecycleFrameOverlay, FrameLayout.LayoutParams(-1, -1))

        hudBox = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = rounded(Color.argb(210, 0, 0, 0), dp(20), Color.argb(120, 255, 255, 255))
            visibility = View.GONE
        }
        root.addView(hudBox, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER).apply { bottomMargin = dp(28) })

        // V7.44.5: VLC-style gesture HUDs with corrected spacing and direction.
        // The SVG icon now has a real visual gap below the slider, the label is
        // separated from the pill, and the fill is explicitly anchored at the
        // bottom so a larger value always grows upward on-screen.
        volumeGestureHud = FrameLayout(this).apply {
            visibility = View.GONE
            alpha = 0f
            translationX = (-dp(6)).toFloat()
            isClickable = false
            isFocusable = false
            clipChildren = false
            clipToPadding = false
        }
        val volumeRail = FrameLayout(this).apply {
            background = playerGestureRailSurface()
            elevation = dp(8).toFloat()
            setPadding(dp(7), dp(8), dp(7), dp(8))
        }
        volumeGestureHud.addView(volumeRail, FrameLayout.LayoutParams(dp(60), -1, Gravity.START))

        volumeGesturePercent = TextView(this).apply {
            text = "0%"
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            includeFontPadding = false
        }
        volumeRail.addView(volumeGesturePercent, FrameLayout.LayoutParams(-1, dp(24), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(4)
        })

        volumeGestureTrackHeightPx = dp(88)
        volumeGestureTrack = FrameLayout(this).apply {
            background = rounded(Color.argb(118, 255, 255, 255), dp(999), Color.TRANSPARENT)
            clipToOutline = true
        }
        volumeGestureLevel = View(this).apply {
            background = rounded(Color.WHITE, dp(999), Color.TRANSPARENT)
            scaleY = 0f
            // Fixed pixel pivot avoids device/layout timing differences that made
            // the white fill look inverted on some landscape devices.
            pivotY = volumeGestureTrackHeightPx.toFloat()
        }
        volumeGestureTrack.addView(volumeGestureLevel, FrameLayout.LayoutParams(-1, volumeGestureTrackHeightPx, Gravity.BOTTOM))
        volumeRail.addView(volumeGestureTrack, FrameLayout.LayoutParams(dp(9), volumeGestureTrackHeightPx, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(42)
        })

        volumeGestureIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_player_volume_gesture)
            setColorFilter(Color.WHITE)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        volumeRail.addView(volumeGestureIcon, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(12)
        })
        volumeGestureHud.addView(TextView(this).apply {
            text = "Volume"
            setTextColor(Color.WHITE)
            textSize = 13.2f
            typeface = Typeface.DEFAULT
            gravity = Gravity.CENTER_VERTICAL or Gravity.LEFT
            includeFontPadding = false
            alpha = 0.98f
        }, FrameLayout.LayoutParams(dp(72), dp(36), Gravity.CENTER_VERTICAL or Gravity.END))
        root.addView(volumeGestureHud, FrameLayout.LayoutParams(dp(150), dp(198), Gravity.START or Gravity.CENTER_VERTICAL).apply {
            leftMargin = dp(10)
        })

        brightnessGestureHud = FrameLayout(this).apply {
            visibility = View.GONE
            alpha = 0f
            translationX = dp(6).toFloat()
            isClickable = false
            isFocusable = false
            clipChildren = false
            clipToPadding = false
        }
        val brightnessRail = FrameLayout(this).apply {
            background = playerGestureRailSurface()
            elevation = dp(8).toFloat()
            setPadding(dp(7), dp(8), dp(7), dp(8))
        }
        brightnessGestureHud.addView(brightnessRail, FrameLayout.LayoutParams(dp(60), -1, Gravity.END))

        brightnessGesturePercent = TextView(this).apply {
            text = "0%"
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            includeFontPadding = false
        }
        brightnessRail.addView(brightnessGesturePercent, FrameLayout.LayoutParams(-1, dp(24), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(4)
        })

        brightnessGestureTrackHeightPx = dp(88)
        brightnessGestureTrack = FrameLayout(this).apply {
            background = rounded(Color.argb(118, 255, 255, 255), dp(999), Color.TRANSPARENT)
            clipToOutline = true
        }
        brightnessGestureLevel = View(this).apply {
            background = rounded(Color.WHITE, dp(999), Color.TRANSPARENT)
            scaleY = 0f
            pivotY = brightnessGestureTrackHeightPx.toFloat()
        }
        brightnessGestureTrack.addView(brightnessGestureLevel, FrameLayout.LayoutParams(-1, brightnessGestureTrackHeightPx, Gravity.BOTTOM))
        brightnessRail.addView(brightnessGestureTrack, FrameLayout.LayoutParams(dp(9), brightnessGestureTrackHeightPx, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(42)
        })

        brightnessGestureIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_player_brightness_gesture)
            setColorFilter(Color.WHITE)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        brightnessRail.addView(brightnessGestureIcon, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(12)
        })
        brightnessGestureHud.addView(TextView(this).apply {
            text = "Brightness"
            setTextColor(Color.WHITE)
            textSize = 13.2f
            typeface = Typeface.DEFAULT
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            includeFontPadding = false
            alpha = 0.98f
        }, FrameLayout.LayoutParams(dp(92), dp(36), Gravity.CENTER_VERTICAL or Gravity.START))
        root.addView(brightnessGestureHud, FrameLayout.LayoutParams(dp(174), dp(198), Gravity.END or Gravity.CENTER_VERTICAL).apply {
            rightMargin = dp(10)
        })

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(6))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(175, 0, 0, 0), Color.argb(58, 0, 0, 0), Color.TRANSPARENT)
            )
        }

        val back = glassIconButton(R.drawable.ic_player_back) { if (partyActive) showPartyRoomSheet() else finish() }
        topBar.addView(back, LinearLayout.LayoutParams(dp(50), dp(50)))

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
            clipChildren = false
            clipToPadding = false
        }
        titleText = TextView(this).apply {
            text = title
            setTextColor(white)
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
        }
        subText = TextView(this).apply {
            text = currentLabel()
            visibility = View.GONE
        }
        playerMetaRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            clipChildren = false
            clipToPadding = false
        }
        info.addView(titleText)
        info.addView(playerMetaRow, LinearLayout.LayoutParams(-1, dp(30)).apply { topMargin = dp(2) })
        info.addView(subText, LinearLayout.LayoutParams(1,1))
        topBar.addView(info, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10); marginEnd = dp(10) })
        rebuildPlayerMetaChips()

        playerTopActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(0, 0, 0, 0)
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
        }
        playerTopActions.addView(simplePlayerIconWithText(R.drawable.ic_speedometer, speedLabel()) { showSpeedSheet() }, LinearLayout.LayoutParams(dp(58), dp(48)).apply { marginStart = dp(3) })
        playerTopActions.addView(ccAudioSubtitleButton { showAudioSubtitleSettingsSheet() }, LinearLayout.LayoutParams(dp(50), dp(48)).apply { marginStart = dp(3) })
        playerTopActions.addView(simplePlayerIcon(R.drawable.ic_player_pip) { enterPipMode() }, LinearLayout.LayoutParams(dp(50), dp(48)))
        topBar.addView(playerTopActions)
        root.addView(topBar, FrameLayout.LayoutParams(-1, dp(74), Gravity.TOP))

        centerControls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER
        }
        val jumpLabel = (seekJumpMs / 1000L).toString()
        val rewind = circleAction(R.drawable.ic_player_replay, jumpLabel) { seekBy(-seekJumpMs) }.apply { id = View.generateViewId() }
        val play = FrameLayout(this).apply {
            id = View.generateViewId()
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
            applyPlayerFocus(this, 999, 1.10f, 0f)
            setOnClickListener { toggle() }
        }
        playButtonBox = play
        playIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_player_pause)
            setColorFilter(Color.WHITE)
        }
        play.addView(playIcon, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER))
        val forward = circleAction(R.drawable.ic_player_forward, jumpLabel) { seekBy(seekJumpMs) }.apply { id = View.generateViewId() }
        rewind.nextFocusRightId = play.id
        play.nextFocusLeftId = rewind.id
        play.nextFocusRightId = forward.id
        forward.nextFocusLeftId = play.id
        centerControls.addView(rewind, LinearLayout.LayoutParams(dp(70), dp(70)).apply { marginEnd = dp(22) })
        centerControls.addView(play, LinearLayout.LayoutParams(dp(82), dp(82)))
        centerControls.addView(forward, LinearLayout.LayoutParams(dp(70), dp(70)).apply { marginStart = dp(22) })
        root.addView(centerControls, FrameLayout.LayoutParams(-1, dp(104), Gravity.CENTER))

        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(18), dp(4), dp(18), dp(10))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.TRANSPARENT, Color.argb(120, 0, 0, 0), Color.argb(225, 0, 0, 0))
            )
        }

        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        currentTimeText = TextView(this).apply { text = "00:00"; setTextColor(white); textSize = 10.5f }
        totalTimeText = TextView(this).apply { text = "--:--"; setTextColor(muted); textSize = 10.5f; gravity = Gravity.END }
        timeRow.addView(currentTimeText, LinearLayout.LayoutParams(0, -2, 1f))
        timeRow.addView(totalTimeText, LinearLayout.LayoutParams(0, -2, 1f))
        bottomBar.addView(timeRow)

        seek = SeekBar(this).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        bottomBar.addView(seek, LinearLayout.LayoutParams(-1, dp(34)).apply { topMargin = dp(2) })

        playerBottomActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            // Utility controls live on the opposite/right edge, away from the
            // timeline start and closer to the top-right playback tools.
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, 0)
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
        }
        val fitButton = glassIconButton(R.drawable.ic_player_fit) { nextMode() }
        fitIcon = fitButton.getChildAt(0) as ImageView
        val lockButton = glassIconButton(R.drawable.ic_player_lock) { toggleLock() }
        lockIcon = lockButton.getChildAt(0) as ImageView
        val standardBadge = TextView(this).apply {
            text = streamBadgeText()
            visibility = if (text.isBlank()) View.GONE else View.VISIBLE
            setTextColor(Color.rgb(210, 225, 255))
            textSize = 10.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.argb(82, 139, 92, 246), dp(12), Color.argb(90, 255, 255, 255))
        }
        val settingsButton = glassIconButton(R.drawable.ic_player_settings) { showSettingsSheet() }
        playerBottomActions.addView(standardBadge, LinearLayout.LayoutParams(dp(58), dp(32)).apply { marginEnd = dp(8) })
        playerBottomActions.addView(settingsButton, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(6) })
        playerBottomActions.addView(fitButton, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(6) })
        playerBottomActions.addView(lockButton, LinearLayout.LayoutParams(dp(48), dp(48)))
        bottomBar.addView(playerBottomActions, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4); gravity = Gravity.RIGHT })
        root.addView(bottomBar, FrameLayout.LayoutParams(-1, dp(116), Gravity.BOTTOM))

        // Use the same state transition as the normal lock button. The previous
        // direct boolean assignment left this unlock icon visible after unlocking.
        unlockOverlay = glassIconButton(R.drawable.ic_player_unlock) { toggleLock() }.apply { visibility = View.GONE }
        root.addView(unlockOverlay, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(18) })

        setContentView(root)
        BankmovieFonts.applyToTree(this, root)
        applyPlayerFocusTree(root)
        root.postDelayed({ focusPlayButton() }, 300)

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(s: SeekBar?) { handler.removeCallbacks(hideRunnable) }
            override fun onStopTrackingTouch(s: SeekBar?) {
                if (partyGuestPlaybackLocked()) {
                    showGuestPlaybackLockedNotice()
                    updateProgress()
                    hideBarsLater()
                    return
                }
                val progress = s?.progress ?: 0
                val p = player ?: return
                if (p.length > 0) p.time = (progress.toLong() * p.length) / 1000L
                if (partyActive && partyIsHost) sendWatchPartyControl("seek")
                hideBarsLater()
            }
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {}
        })

        videoLayout.setOnTouchListener { _, e -> handleVideoTouch(e) }
        hideBarsLater()
    }

    // ---------------------------------------------------------------------
    // PASS 4.3 — Native Watch Party room UI + sync + site-style chat + sticker packs
    // ---------------------------------------------------------------------
    private fun partyGlass(radius: Int = 22, alpha: Int = 232, strokeAlpha: Int = 92): GradientDrawable {
        // V7.44.6 — Watch Party gets its own midnight/cyan glass language,
        // matching the approved mockup instead of the old charcoal/green cards.
        val top = Color.argb(alpha.coerceIn(0,255), 8, 31, 56)
        val bottom = Color.argb((alpha - 14).coerceIn(0,255), 4, 17, 34)
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(strokeAlpha.coerceIn(0,255), 42, 169, 255))
        }
    }

    private fun partyAccent(radius: Int = 20): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(27, 225, 235), Color.rgb(17, 126, 255))).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(210, 99, 229, 255))
        }

    private fun partySoftAccent(radius: Int = 18): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.argb(178, 5, 71, 91), Color.argb(190, 7, 38, 78))).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(150, 22, 207, 235))
        }

    private fun partyRoundIcon(iconRes: Int, sizeDp: Int = 42, click: (() -> Unit)? = null): FrameLayout = FrameLayout(this).apply {
        background = partyGlass(999, 218, 92)
        isClickable = click != null
        isFocusable = click != null
        if (click != null) {
            applyPlayerFocus(this, 999, 1.07f, 0f)
            setOnClickListener { click() }
        }
        addView(ImageView(this@PlayerActivity).apply {
            setImageResource(iconRes)
            setColorFilter(Color.WHITE)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }, FrameLayout.LayoutParams(dp((sizeDp * .46f).roundToInt()), dp((sizeDp * .46f).roundToInt()), Gravity.CENTER))
    }

    // PASS 4.6 — player chrome uses the same charcoal glass language as the app.
    private fun playerGlassSurface(radius: Int = 24, alpha: Int = 238, strokeAlpha: Int = 72): GradientDrawable {
        val top = Color.argb(alpha.coerceIn(0, 255), 38, 39, 44)
        val bottom = Color.argb((alpha - 18).coerceIn(0, 255), 21, 22, 26)
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(strokeAlpha.coerceIn(0, 255), 255, 255, 255))
        }
    }

    private fun playerGlassAccent(radius: Int = 20): GradientDrawable {
        val p = UiPreferences.palette(this)
        return GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(
            UiPreferences.blend(p.primary, Color.WHITE, 0.12f),
            p.primary
        )).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(120, 255, 255, 255))
        }
    }

    private fun partyGuestPlaybackLocked(): Boolean = partyActive && !partyIsHost

    private fun showGuestPlaybackLockedNotice() {
        val now = System.currentTimeMillis()
        if (now - lastGuestControlNoticeAt < 900L) return
        lastGuestControlNoticeAt = now
        showHud("کنترل پخش دست میزبان است · فقط صدا برای شما آزاد است")
    }

    private fun setPlaybackControlTreeEnabled(view: View, enabled: Boolean) {
        view.isEnabled = enabled
        view.isFocusable = enabled
        view.alpha = if (enabled) 1f else 0.38f
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) setPlaybackControlTreeEnabled(view.getChildAt(i), enabled)
        }
    }

    private fun updateGuestPlaybackLockUi() {
        if (!::seek.isInitialized || !::centerControls.isInitialized) return
        val enabled = !partyGuestPlaybackLocked()
        seek.isEnabled = enabled
        seek.isFocusable = enabled
        seek.alpha = if (enabled) 1f else 0.42f
        setPlaybackControlTreeEnabled(centerControls, enabled)
        if (::playerTopActions.isInitialized) setPlaybackControlTreeEnabled(playerTopActions, enabled)
        if (::playerBottomActions.isInitialized) setPlaybackControlTreeEnabled(playerBottomActions, enabled)
        // Room/chat controls are intentionally separate and stay available to guests.
    }

    private fun partyIcon(icon: Int, description: String, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            contentDescription = description
            background = partyGlass(18, 232, 76)
            isClickable = true; isFocusable = true
            applyPlayerFocus(this, 18, 1.08f, 0f)
            setOnClickListener { click() }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(icon); setColorFilter(Color.WHITE)
            }, FrameLayout.LayoutParams(dp(23), dp(23), Gravity.CENTER))
        }
    }

    private fun buildWatchPartyOverlay() {
        // V7.44.6 — Approved Watch Party layout: a compact cyan room chip above
        // the timeline plus a floating chat/settings dock on the right.
        partyStatusChip = TextView(this).apply {
            text = if (partyIsHost) "👥  هم‌زمان تماشا  ♛   |   Watch Party" else "👥  هم‌زمان تماشا   |   Watch Party"
            setTextColor(Color.WHITE)
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = partySoftAccent(999)
            setPadding(dp(16), dp(7), dp(16), dp(7))
            isClickable = true
            isFocusable = true
            elevation = dp(8).toFloat()
            applyPlayerFocus(this, 999, 1.035f, 0f)
            setOnClickListener { showPartyChrome(); showPartyRoomSheet() }
        }
        root.addView(partyStatusChip, FrameLayout.LayoutParams(-2, dp(42), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(122)
        })

        partyDock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(7), dp(6), dp(7))
            background = partyGlass(24, 220, 120)
            elevation = dp(10).toFloat()
        }
        val chat = partyIcon(R.drawable.ic_party_chat, "گفت‌وگوی خصوصی") { showPartyChrome(); showWatchPartyChat() }
        partyChatButton = chat
        val settings = partyIcon(R.drawable.ic_player_settings, "مدیریت اتاق") { showPartyChrome(); showPartyRoomSheet() }
        partyDock?.addView(chat, LinearLayout.LayoutParams(dp(48), dp(48)).apply { bottomMargin = dp(8) })
        partyDock?.addView(settings, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(partyDock, FrameLayout.LayoutParams(dp(62), -2, Gravity.RIGHT or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(14) })
        applyPartyTheme("simple")
        showPartyChrome()
    }

    private fun setPartyChromeVisible(visible: Boolean) {
        val value = if (visible) View.VISIBLE else View.GONE
        partyDock?.visibility = value
        partyStatusChip?.visibility = value
        if (visible) {
            partyDock?.alpha = 1f
            partyStatusChip?.alpha = 1f
        }
    }

    private fun showPartyChrome() {
        if (!partyActive) return
        setPartyChromeVisible(true)
        handler.removeCallbacks(partyChromeHideRunnable)
        handler.postDelayed(partyChromeHideRunnable, 5000L)
    }

    private fun updatePartyStatusChip() {
        val count = partyMembers.length()
        val countText = if (count > 0) "$count نفر" else "همگام"
        partyStatusChip?.text = if (partyIsHost) "👥  $countText  ♛   |   Watch Party" else "👥  $countText   |   Watch Party"
        partyStatusChip?.setTextColor(if (partyPollInFlight) Color.rgb(205, 238, 248) else Color.WHITE)
        updateChatBadge()
    }

    private fun showWatchPartyLobby() {
        if (!partyActive || partyRoomCode.isBlank() || partyReadyConfirmed) return
        if (partyLobbyDialog?.isShowing == true) return
        lateinit var dialog: AlertDialog
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(15), dp(16), dp(14))
            background = partyGlass(26, 246, 132)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            addView(TextView(this@PlayerActivity).apply {
                text = "سینمای خصوصی BankMovie"
                setTextColor(Color.WHITE)
                textSize = 19f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            })
            addView(TextView(this@PlayerActivity).apply {
                text = "BankMovie Watch Party"
                setTextColor(Color.rgb(174, 201, 239))
                textSize = 10.5f
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
        }
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        // V7.44.7 — lobby is a hard gate until the user explicitly confirms readiness.
        // Keep the close glyph for visual parity, but never let it dismiss the room.
        header.addView(partyRoundIcon(R.drawable.ic_close_clean, 42) {
            Toast.makeText(this, "برای ادامه ابتدا روی «شروع تماشا / آماده‌ام» بزنید", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginStart = dp(8) })
        header.addView(FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(21, 221, 235), Color.rgb(13, 120, 255))).apply {
                cornerRadius = dp(999).toFloat()
                setStroke(dp(1), Color.argb(220, 125, 236, 255))
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(R.drawable.ic_party_members)
                setColorFilter(Color.WHITE)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            }, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER))
        }, LinearLayout.LayoutParams(dp(54), dp(54)).apply { marginStart = dp(10) })
        shell.addView(header)

        val infoLine = TextView(this).apply {
            text = if (partyIsHost)
                "◷  این اتاق تا ۴ ساعت فعال است     ⚡  فیلم با کیفیت بالا برای همه اعضا همگام می‌شود."
            else
                "◷  اتاق فعال است     ⚡  بعد از آماده‌شدن، پخش با میزبان همگام می‌شود."
            setTextColor(Color.rgb(181, 207, 232))
            textSize = 10f
            gravity = Gravity.RIGHT
            setLineSpacing(dp(2).toFloat(), 1.05f)
        }
        shell.addView(infoLine, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10); bottomMargin = dp(10) })

        val roomCodeShell = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(7), dp(10), dp(7))
            background = partyGlass(18, 220, 96)
        }
        val roomText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            addView(TextView(this@PlayerActivity).apply {
                text = "کد اتاق"
                setTextColor(Color.rgb(153, 187, 224))
                textSize = 9.5f
                gravity = Gravity.RIGHT
            })
            addView(TextView(this@PlayerActivity).apply {
                text = partyRoomCode
                setTextColor(Color.rgb(225, 239, 255))
                textSize = 13.5f
                typeface = Typeface.MONOSPACE
                gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.MIDDLE
            }, LinearLayout.LayoutParams(-1, dp(26)).apply { topMargin = dp(2) })
        }
        roomCodeShell.addView(roomText, LinearLayout.LayoutParams(0, -2, 1f))
        roomCodeShell.addView(partyRoundIcon(R.drawable.ic_copy_link, 40) {
            copyPartyInvite()
            Toast.makeText(this, "لینک دعوت کپی شد", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginStart = dp(10) })
        shell.addView(roomCodeShell, LinearLayout.LayoutParams(-1, -2))

        fun actionButton(label: String, icon: Int, click: () -> Unit): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            background = partyGlass(17, 214, 96)
            isClickable = true
            isFocusable = true
            applyPlayerFocus(this, 17, 1.04f, 0f)
            setOnClickListener { click() }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(icon)
                setColorFilter(Color.WHITE)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            }, LinearLayout.LayoutParams(dp(20), dp(20)).apply { marginStart = dp(7) })
            addView(TextView(this@PlayerActivity).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 11.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
        }
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        actions.addView(actionButton("دعوت اعضای اتاق", R.drawable.ic_party_members) {
            // Open members on top of the lobby. Closing the child sheet reveals the
            // still-open lobby instead of losing the readiness gate.
            showPartyMembers()
        }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(6) })
        actions.addView(actionButton("دعوت", R.drawable.ic_copy_link) {
            sharePartyInvite()
        }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) })
        shell.addView(actions, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        val startButton = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            background = partyAccent(20)
            elevation = dp(8).toFloat()
            isClickable = true
            isFocusable = true
            applyPlayerFocus(this, 20, 1.035f, 0f)
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(R.drawable.ic_play_fill)
                setColorFilter(Color.WHITE)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginStart = dp(9) })
            addView(LinearLayout(this@PlayerActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                addView(TextView(this@PlayerActivity).apply {
                    text = if (partyIsHost) "همه آماده‌اند؟" else "آماده‌ای؟"
                    setTextColor(Color.argb(220, 255, 255, 255))
                    textSize = 9.4f
                    gravity = Gravity.CENTER
                })
                addView(TextView(this@PlayerActivity).apply {
                    text = "شروع تماشا"
                    setTextColor(Color.WHITE)
                    textSize = 18f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                })
            })
            setOnClickListener {
                // V7.44.8 — hard single-flight ready transition. Rapid taps, an
                // onResume from the Android share sheet, or a poll callback must not
                // create/rebuild LibVLC twice while its Surface is still attaching.
                if (partyReadyConfirmed || partyReadyLaunchInFlight) return@setOnClickListener
                partyReadyLaunchInFlight = true
                partyReadyConfirmed = true

                // A pre-ready trip to Share/chooser used to mark lifecycle restore as
                // pending even though no player existed. Clear that stale state before
                // the first real playback launch.
                lifecycleRestorePending = false
                lifecycleWasPlaying = false
                lifecyclePosition = 0L
                lifecyclePausedAt = 0L
                pauseAfterLifecycleRestore = false
                handler.removeCallbacks(releaseRetainedPlayerRunnable)

                isEnabled = false
                alpha = 0.86f
                dialog.dismiss()

                if (!partyIsHost) {
                    // Guests become ready, then wait for the host's authoritative room
                    // state/source. Do not start the local link first and immediately
                    // rebuild it from shared_source_url — that native double-start was
                    // the crash path on several Xiaomi/MIUI devices.
                    partyPlaybackStarted = false
                    partyReadyLaunchInFlight = false
                    showControls()
                    showPartyChrome()
                    enterImmersive()
                    handler.postDelayed({ pollWatchParty() }, 100L)
                    return@setOnClickListener
                }

                // Let the dialog window detach before attaching VLC's SurfaceView.
                // This small boundary avoids MIUI window/surface races without adding
                // visible latency to the ready action.
                handler.postDelayed({
                    if (!partyActive || isFinishing || isDestroyed) {
                        partyReadyLaunchInFlight = false
                        return@postDelayed
                    }
                    if (!partyPlaybackStarted && player == null) {
                        partyPlaybackStarted = true
                        requestedResumePosition = 0L
                        launchPlayerSafely(videoUrl)
                    }
                    showControls()
                    showPartyChrome()
                    enterImmersive()
                    handler.postDelayed({
                        partyReadyLaunchInFlight = false
                        pollWatchParty()
                    }, 700L)
                }, 140L)
            }
        }
        shell.addView(startButton, LinearLayout.LayoutParams(-1, dp(66)).apply { topMargin = dp(11) })

        val syncChip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            background = partySoftAccent(999)
            setPadding(dp(12), dp(5), dp(12), dp(5))
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(R.drawable.ic_detail_update_sync)
                setColorFilter(Color.rgb(46, 223, 242))
            }, LinearLayout.LayoutParams(dp(17), dp(17)).apply { marginStart = dp(6) })
            addView(TextView(this@PlayerActivity).apply {
                text = if (partyIsHost) "همگام با میزبان" else "همگام‌سازی با میزبان"
                setTextColor(Color.rgb(66, 226, 242))
                textSize = 10f
                typeface = Typeface.DEFAULT_BOLD
            })
        }
        shell.addView(syncChip, LinearLayout.LayoutParams(-2, dp(32)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(10) })

        dialog = AlertDialog.Builder(this).setView(shell).setCancelable(false).create()
        partyLobbyDialog = dialog
        dialog.setCanceledOnTouchOutside(false)
        dialog.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP && !partyReadyConfirmed) {
                Toast.makeText(this, "برای ادامه ابتدا روی «شروع تماشا / آماده‌ام» بزنید", Toast.LENGTH_SHORT).show()
                true
            } else false
        }
        dialog.setOnDismissListener {
            if (partyLobbyDialog === dialog) partyLobbyDialog = null
            // Defensive restore: external share/activity switches or an OEM dialog
            // quirk must not permanently remove the lobby before readiness is confirmed.
            if (partyActive && !partyReadyConfirmed && !isFinishing && !isDestroyed) {
                handler.postDelayed({
                    if (partyActive && !partyReadyConfirmed && partyLobbyDialog?.isShowing != true && !isFinishing && !isDestroyed) {
                        showWatchPartyLobby()
                    }
                }, 120L)
            }
        }
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout(if (isTvLike()) dp(650) else (resources.displayMetrics.widthPixels * 0.92f).toInt(), -2)
    }

    private fun updateChatBadge() {
        val button = partyChatButton as? FrameLayout ?: return
        val old = button.findViewWithTag<View>("party_unread")
        if (partyUnreadChat <= 0) { old?.let { button.removeView(it) }; return }
        val badge = (old as? TextView) ?: TextView(this).apply {
            tag = "party_unread"; setTextColor(Color.WHITE); textSize = 8f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; background = rounded(Color.rgb(239,68,68), 999, Color.WHITE)
            button.addView(this, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.TOP or Gravity.RIGHT).apply { topMargin = -dp(3); rightMargin = -dp(3) })
        }
        badge.text = partyUnreadChat.coerceAtMost(99).toString()
    }

    private fun pollWatchParty() {
        if (!partyActive || partyRoomCode.isBlank() || partyPollInFlight) return
        partyPollInFlight = true
        val requestStart = System.currentTimeMillis()
        AccountApi.watchPartyPoll(this, partyRoomCode, partyLastEventId, partyLastMessageId, 0L) { result ->
            val requestEnd = System.currentTimeMillis()
            partyPollInFlight = false
            partyLastPollAt = requestEnd
            if (!result.success || result.json == null) {
                if (result.statusCode == 404 || result.json?.optString("error") == "room_expired") {
                    partyActive = false
                    handler.removeCallbacks(partyPollRunnable)
                    Toast.makeText(this, result.message.ifBlank { "اتاق Watch Party پایان یافت" }, Toast.LENGTH_LONG).show()
                }
                updatePartyStatusChip()
                return@watchPartyPoll
            }
            val json = result.json
            json.optLong("server_time_ms", 0L).takeIf { it > 0L }?.let { server ->
                val midpoint = requestStart + (requestEnd - requestStart) / 2L
                val candidate = server - midpoint
                partyServerOffsetMs = if (partyServerOffsetMs == 0L) candidate else ((partyServerOffsetMs * 3L + candidate) / 4L)
            }
            partyRole = json.optString("member_role", partyRole)
            partyIsHost = partyRole.equals("host", true)
            updateGuestPlaybackLockUi()
            partyChatEnabled = json.optBoolean("chat_enabled", true)

            var sharedSource = ""
            json.optJSONObject("room")?.let { room ->
                partyThemeKey = room.optString("background_key", partyThemeKey)
                partyRoomTitle = room.optString("content_title", partyRoomTitle)
                partyRoomPoster = room.optString("poster_url", partyRoomPoster)
                applyPartyTheme(partyThemeKey)
                sharedSource = room.optString("shared_source_url").trim()
                if (sharedSource.isNotBlank()) partySharedSourceUrl = sharedSource
                if (partyReadyConfirmed && !partyIsHost && !partyReadyLaunchInFlight && player != null && sharedSource.isNotBlank() && sharedSource != videoUrl && partyPlaybackStarted) {
                    partyApplyingRemote = true
                    partyReadyLaunchInFlight = true
                    videoUrl = sharedSource
                    requestedResumePosition = 0L
                    handler.postDelayed({
                        launchPlayerSafely(sharedSource)
                        handler.postDelayed({
                            partyApplyingRemote = false
                            partyReadyLaunchInFlight = false
                        }, 420L)
                    }, 120L)
                }
            }

            val events = json.optJSONArray("events") ?: JSONArray()
            for (i in 0 until events.length()) partyLastEventId = max(partyLastEventId, events.optJSONObject(i)?.optLong("id", 0L) ?: 0L)
            val messages = json.optJSONArray("messages") ?: JSONArray()
            handlePartyMessages(messages)
            partyMembers = json.optJSONArray("members") ?: partyMembers
            if (!partyIsHost) {
                val state = json.optJSONObject("state")
                val serverNow = json.optLong("server_time_ms", requestEnd + partyServerOffsetMs)
                if (partyReadyConfirmed && !partyReadyLaunchInFlight && state != null && !state.optBoolean("paused", true) && sharedSource.isNotBlank() && (!partyPlaybackStarted || player == null)) {
                    // Android-to-Android: after the guest confirms readiness, create
                    // exactly one local decoder from the host's canonical shared source.
                    partyReadyLaunchInFlight = true
                    partyPlaybackStarted = true
                    partyGuestAutoStarting = true
                    partyApplyingRemote = true
                    partyLobbyDialog?.dismiss()
                    videoUrl = sharedSource
                    val targetMs = (state.optDouble("current_time", 0.0).coerceAtLeast(0.0) * 1000.0).toLong()
                    requestedResumePosition = targetMs
                    pauseAfterLifecycleRestore = false
                    launchPlayerSafely(sharedSource)
                    handler.postDelayed({
                        partyApplyingRemote = false
                        partyGuestAutoStarting = false
                        partyReadyLaunchInFlight = false
                        applyWatchPartyState(state, serverNow)
                        showPartyChrome()
                    }, 520L)
                } else {
                    state?.let { applyWatchPartyState(it, serverNow) }
                }
            }
            updatePartyStatusChip()
        }
    }

    private fun applyWatchPartyState(state: JSONObject, serverTimeMs: Long) {
        val seq = state.optLong("sequence_no", -1L)
        if (seq < partyLastSequence) return
        partyLastSequence = seq
        val paused = state.optBoolean("paused", true)
        val rate = state.optDouble("playback_rate", 1.0).toFloat().coerceIn(0.5f, 2f)
        var target = state.optDouble("current_time", 0.0).coerceAtLeast(0.0)
        val updatedAt = state.optLong("updated_at_ms", 0L)
        if (!paused && updatedAt > 0L) {
            val effectiveServerNow = if (serverTimeMs > 0L) serverTimeMs else System.currentTimeMillis() + partyServerOffsetMs
            target += ((effectiveServerNow - updatedAt).coerceAtLeast(0L) / 1000.0) * rate
        }
        val p = player ?: return
        val local = p.time.coerceAtLeast(0L) / 1000.0
        val drift = target - local
        partyApplyingRemote = true
        try {
            if (paused && p.isPlaying) p.pause()
            if (!paused && !p.isPlaying) p.play()
            when {
                kotlin.math.abs(drift) > 0.55 -> {
                    p.time = (target * 1000.0).toLong().coerceAtLeast(0L)
                    p.setRate(rate)
                }
                !paused && kotlin.math.abs(drift) > 0.12 -> {
                    val correction = if (drift > 0) 0.055f else -0.055f
                    p.setRate((rate + correction).coerceIn(0.90f, 1.10f))
                }
                else -> p.setRate(rate)
            }
            currentSpeed = rate
            playIcon.setImageResource(if (paused) R.drawable.ic_player_play else R.drawable.ic_player_pause)
        } catch (_: Throwable) {
        } finally {
            handler.postDelayed({ partyApplyingRemote = false }, 90L)
        }
    }

    private fun currentPartyPositionSeconds(): Double {
        return (player?.time ?: 0L).coerceAtLeast(0L) / 1000.0
    }

    private fun currentPartyPaused(): Boolean {
        return player?.isPlaying != true
    }

    private fun sendWatchPartyControl(event: String, retryAttempt: Int = 0) {
        if (!partyActive || !partyIsHost || partyApplyingRemote || partyRoomCode.isBlank()) return
        partyLastHostActionAt = System.currentTimeMillis()
        AccountApi.watchPartyControl(
            this, partyRoomCode, event, currentPartyPositionSeconds(), currentPartyPaused(), currentSpeed,
            buffering = false, sourceUrl = if (event == "source_change") videoUrl else ""
        ) { result ->
            if (result.success) {
                result.json?.optJSONObject("state")?.optLong("sequence_no", -1L)?.let { if (it >= 0) partyLastSequence = max(partyLastSequence, it) }
            } else if (event != "state" && retryAttempt < 1 && partyActive && partyIsHost) {
                // User actions are important for Android-to-Android rooms. One short
                // retry prevents a dropped PLAY/PAUSE/SEEK request from leaving the
                // other phone with only a moving timestamp and no playback.
                handler.postDelayed({ sendWatchPartyControl(event, retryAttempt + 1) }, 260L)
            }
        }
    }

    private fun sendWatchPartyHeartbeatIfNeeded() {
        val now = System.currentTimeMillis()
        if (!partyActive || !partyIsHost || partyApplyingRemote || now - partyLastHeartbeatAt < 900L || now - partyLastHostActionAt < 650L) return
        partyLastHeartbeatAt = now
        AccountApi.watchPartyControl(this, partyRoomCode, "state", currentPartyPositionSeconds(), currentPartyPaused(), currentSpeed) {}
    }

    private fun handlePartyMessages(messages: JSONArray) {
        for (i in 0 until messages.length()) {
            val message = messages.optJSONObject(i) ?: continue
            val id = message.optLong("id", 0L)
            if (id <= 0L) continue
            partyLastMessageId = max(partyLastMessageId, id)
            if (!partyMessageIdsShown.add(id)) continue
            appendPartyMessage(message)
            showPartyMessageOverlay(message)
            val media = message.optJSONObject("media")
            if (media != null && media.optString("url").isNotBlank()) showPartyReaction(media)
            if (partyChatDialog?.isShowing != true) partyUnreadChat++
        }
        while (partyMessageIdsShown.size > 220) partyMessageIdsShown.remove(partyMessageIdsShown.first())
        updateChatBadge()
    }

    private fun showPartyMessageOverlay(message: JSONObject) {
        if (!partyActive || message.optBoolean("is_mine", false)) return
        val username = message.optString("username").ifBlank { "همراه" }
        val textValue = message.optString("text").ifBlank { message.optString("message") }
        val media = message.optJSONObject("media")
        if (textValue.isBlank() && (media == null || media.optString("url").isBlank())) return

        val bubble = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(9), dp(10), dp(9))
            background = playerGlassSurface(20, 236, 82)
            elevation = dp(8).toFloat()
            alpha = 0f
            translationY = -dp(10).toFloat()
        }
        bubble.addView(partyAvatarView(message, 36), LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginStart = dp(9) })

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = username
            setTextColor(if (message.optBoolean("is_vip", false) || message.optBoolean("is_admin", false)) Color.rgb(255, 203, 76) else Color.WHITE)
            textSize = 10.7f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, -2, 1f))
        if (message.optBoolean("is_vip", false) || message.optBoolean("is_admin", false)) {
            header.addView(TextView(this).apply {
                text = if (message.optBoolean("is_admin", false)) "ADMIN" else "VIP"
                setTextColor(Color.rgb(255, 206, 78))
                textSize = 8.4f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = rounded(Color.argb(40, 255, 193, 52), dp(999), Color.argb(105, 255, 207, 90))
                setPadding(dp(6), dp(2), dp(6), dp(2))
            }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(6) })
        }
        content.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(3) })

        if (textValue.isNotBlank() && !textValue.startsWith("[bm-sticker:")) {
            content.addView(TextView(this).apply {
                text = textValue
                setTextColor(Color.rgb(242, 244, 248))
                textSize = 12.2f
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.RIGHT
                setLineSpacing(dp(1).toFloat(), 1f)
            })
        } else if (media != null) {
            content.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                media.optString("url").takeIf { it.isNotBlank() }?.let { loadPartyImage(it, this) }
            }, LinearLayout.LayoutParams(dp(92), dp(58)))
        }
        bubble.addView(content, LinearLayout.LayoutParams(0, -2, 1f))

        val width = if (isTvLike()) dp(460) else min(dp(340), resources.displayMetrics.widthPixels - dp(28))
        root.addView(bubble, FrameLayout.LayoutParams(width, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(if (isTvLike()) 90 else 58)
        })
        bubble.animate().alpha(1f).translationY(0f).setDuration(170L).withEndAction {
            bubble.postDelayed({
                bubble.animate().alpha(0f).translationY(-dp(8).toFloat()).setDuration(220L).withEndAction {
                    runCatching { root.removeView(bubble) }
                }.start()
            }, 3300L)
        }.start()
    }

    private fun partyAvatarView(payload: JSONObject, sizeDp: Int = 38): FrameLayout {
        val username = payload.optString("username").ifBlank { "همراه" }
        val vip = payload.optBoolean("is_vip", false)
        val admin = payload.optBoolean("is_admin", false)
        val avatarUrl = payload.optString("avatar_url").trim()
        val border = if (vip || admin) Color.rgb(255, 196, 60) else Color.argb(95,255,255,255)
        return FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(27, 43, 53))
                setStroke(dp(1), border)
            }
            clipToOutline = true
            addView(TextView(this@PlayerActivity).apply {
                text = username.take(1).uppercase()
                setTextColor(Color.WHITE)
                textSize = if (sizeDp >= 42) 12f else 10.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(34,122,118), Color.rgb(46,75,143))).apply {
                    shape = GradientDrawable.OVAL
                }
            }, FrameLayout.LayoutParams(-1,-1))
            if (avatarUrl.isNotBlank()) {
                addView(ImageView(this@PlayerActivity).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT) }
                    clipToOutline = true
                    loadPartyImage(avatarUrl, this)
                }, FrameLayout.LayoutParams(-1,-1).apply { setMargins(dp(2),dp(2),dp(2),dp(2)) })
            }
            addView(View(this@PlayerActivity).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.rgb(42, 214, 132))
                    setStroke(dp(1), Color.rgb(5,42,35))
                }
            }, FrameLayout.LayoutParams(dp(9),dp(9),Gravity.BOTTOM or Gravity.RIGHT).apply {
                rightMargin = dp(1); bottomMargin = dp(1)
            })
        }
    }

    private fun partyMessageTime(raw: String): String {
        val clean = raw.trim()
        val match = Regex("(?:T|\\s)(\\d{2}):(\\d{2})").find(clean)
        return if (match != null) "${match.groupValues[1]}:${match.groupValues[2]}" else ""
    }

    private fun showWatchPartyChat() {
        if (!partyChatEnabled) {
            Toast.makeText(this, "گفت‌وگوی اتاق غیرفعال است", Toast.LENGTH_SHORT).show()
            return
        }
        partyUnreadChat = 0
        updateChatBadge()
        handler.removeCallbacks(partyChromeHideRunnable)
        lateinit var dialog: AlertDialog

        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, 0, 0, 0)
            background = partyGlass(25, 248, 128)
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(10), dp(12), dp(10))
            background = GradientDrawable(GradientDrawable.Orientation.RIGHT_LEFT, intArrayOf(Color.rgb(8, 38, 70), Color.rgb(5, 22, 43))).apply {
                setCornerRadii(floatArrayOf(dp(25).toFloat(), dp(25).toFloat(), dp(25).toFloat(), dp(25).toFloat(), 0f, 0f, 0f, 0f))
                setStroke(dp(1), Color.argb(95, 43, 176, 255))
            }
        }
        head.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            addView(TextView(this@PlayerActivity).apply {
                text = "گفت‌وگوی خصوصی"
                setTextColor(Color.WHITE)
                textSize = 17.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            })
            addView(TextView(this@PlayerActivity).apply {
                text = "پیام‌ها فقط برای اعضای همین اتاق قابل مشاهده است"
                setTextColor(Color.rgb(158, 190, 224))
                textSize = 9.4f
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(partyRoundIcon(R.drawable.ic_close_clean, 42) { dialog.dismiss() }, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginStart = dp(8) })
        shell.addView(head, LinearLayout.LayoutParams(-1, -2))

        partyChatList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            minimumHeight = dp(if (isTvLike()) 330 else 260)
            background = GradientDrawable(GradientDrawable.Orientation.BL_TR, intArrayOf(Color.rgb(4, 18, 34), Color.rgb(5, 25, 46), Color.rgb(4, 16, 31)))
        }
        partyChatScroll = ScrollView(this).apply {
            addView(partyChatList)
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        shell.addView(partyChatScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(10), dp(9), dp(10), dp(10))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.rgb(5, 25, 47), Color.rgb(4, 17, 33)))
        }
        val send = FrameLayout(this).apply {
            background = partyAccent(999)
            isClickable = true
            isFocusable = true
            elevation = dp(6).toFloat()
            applyPlayerFocus(this, 999, 1.06f, 0f)
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(R.drawable.ic_send_round)
                setColorFilter(Color.WHITE)
            }, FrameLayout.LayoutParams(dp(23), dp(23), Gravity.CENTER))
        }

        val inputShell = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(6, 25, 46), Color.rgb(8, 32, 56))).apply {
                cornerRadius = dp(999).toFloat()
                setStroke(dp(1), Color.argb(115, 70, 156, 235))
            }
            setPadding(dp(7), dp(3), dp(7), dp(3))
        }
        val input = EditText(this).apply {
            hint = "پیام بنویسید..."
            setHintTextColor(Color.rgb(139, 161, 184))
            setTextColor(Color.WHITE)
            textSize = 12.5f
            maxLines = 3
            minLines = 1
            background = ColorDrawable(Color.TRANSPARENT)
            setPadding(dp(7), 0, dp(7), 0)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        }
        val sticker = FrameLayout(this).apply {
            background = rounded(Color.argb(110, 12, 52, 82), dp(999), Color.argb(120, 60, 160, 235))
            isClickable = true
            isFocusable = true
            contentDescription = "استیکر و ایموجی"
            applyPlayerFocus(this, 999, 1.08f, 0f)
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(R.drawable.ic_sticker_smile_square)
                setColorFilter(Color.rgb(226, 236, 247))
            }, FrameLayout.LayoutParams(dp(23), dp(23), Gravity.CENTER))
            setOnClickListener { showPartyStickerPicker() }
        }
        inputShell.addView(input, LinearLayout.LayoutParams(0, dp(48), 1f))
        inputShell.addView(sticker, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginStart = dp(5) })
        composer.addView(inputShell, LinearLayout.LayoutParams(0, dp(52), 1f))
        composer.addView(send, LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginStart = dp(9) })
        send.setOnClickListener {
            val value = input.text?.toString()?.trim().orEmpty()
            if (value.isNotBlank()) {
                sendPartyMessage(value)
                input.setText("")
            }
        }
        shell.addView(composer)

        dialog = AlertDialog.Builder(this).setView(shell).create()
        partyChatDialog = dialog
        dialog.setOnDismissListener {
            partyChatDialog = null
            partyChatList = null
            partyChatScroll = null
            showPartyChrome()
        }
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        val dialogWidth = if (isTvLike()) (w * .40f).toInt() else (w * .43f).toInt()
        val dialogHeight = if (isTvLike()) (h * .84f).toInt() else (h * .88f).toInt()
        dialog.window?.setLayout(dialogWidth, dialogHeight)
        dialog.window?.attributes = dialog.window?.attributes?.apply { gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL }
        partyMessageIdsShown.clear()
        partyLastMessageId = 0L
        pollWatchParty()
    }

    private fun appendPartyMessage(message: JSONObject) {
        val list = partyChatList ?: return
        val mine = message.optBoolean("is_mine", false)
        val username = message.optString("username").ifBlank { "همراه" }
        val vip = message.optBoolean("is_vip", false)
        val admin = message.optBoolean("is_admin", false)
        val maxBubbleWidth = (resources.displayMetrics.widthPixels * if (isTvLike()) 0.28f else 0.34f).toInt().coerceAtLeast(dp(190))

        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (mine) Gravity.RIGHT or Gravity.BOTTOM else Gravity.LEFT or Gravity.BOTTOM
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val avatar = partyAvatarView(message, 38)
        val bubble = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(11),dp(8),dp(11),dp(7))
            background = if (mine) {
                GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(20,95,151),Color.rgb(10,68,115))).apply {
                    setCornerRadii(floatArrayOf(dp(17).toFloat(),dp(17).toFloat(),dp(17).toFloat(),dp(17).toFloat(),dp(5).toFloat(),dp(5).toFloat(),dp(17).toFloat(),dp(17).toFloat()))
                    setStroke(dp(1),Color.argb(95,92,176,255))
                }
            } else {
                GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(12,38,68),Color.rgb(7,25,48))).apply {
                    setCornerRadii(floatArrayOf(dp(17).toFloat(),dp(17).toFloat(),dp(17).toFloat(),dp(17).toFloat(),dp(17).toFloat(),dp(17).toFloat(),dp(5).toFloat(),dp(5).toFloat()))
                    setStroke(dp(1),Color.argb(90,75,145,220))
                }
            }
        }
        bubble.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            addView(TextView(this@PlayerActivity).apply {
                text = if (mine) "شما" else username
                setTextColor(if (vip || admin) Color.rgb(255,199,64) else Color.rgb(131,205,255))
                textSize = 10f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
                maxWidth = maxBubbleWidth - dp(70)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            if (admin || vip) {
                addView(TextView(this@PlayerActivity).apply {
                    text = if (admin) "ADMIN" else "VIP"
                    setTextColor(if (admin) Color.rgb(255,204,72) else Color.rgb(65,42,8))
                    textSize = 7.2f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    background = if (admin) rounded(Color.argb(55,255,190,30),999,Color.argb(120,255,196,60)) else GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,intArrayOf(Color.rgb(255,232,126),Color.rgb(255,177,31))).apply { cornerRadius=dp(999).toFloat() }
                    setPadding(dp(5),dp(1),dp(5),dp(1))
                }, LinearLayout.LayoutParams(-2,dp(16)).apply { marginEnd = dp(6) })
            }
        })

        val textValue = message.optString("text").ifBlank { message.optString("message") }
        if (textValue.isNotBlank() && !textValue.startsWith("[bm-sticker:")) {
            bubble.addView(TextView(this).apply {
                text = textValue
                setTextColor(Color.WHITE)
                textSize = 12.8f
                gravity = Gravity.RIGHT
                setLineSpacing(dp(2).toFloat(),1f)
                maxWidth = maxBubbleWidth
                setTextIsSelectable(false)
            }, LinearLayout.LayoutParams(-2,-2).apply { topMargin=dp(4) })
        }
        message.optJSONObject("media")?.optString("url")?.takeIf { it.isNotBlank() }?.let { url ->
            val mediaSize = dp(if (isTvLike()) 210 else 170)
            bubble.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                adjustViewBounds = true
                setBackgroundColor(Color.TRANSPARENT)
                loadPartyImage(url,this)
            }, LinearLayout.LayoutParams(mediaSize,mediaSize).apply { gravity=Gravity.RIGHT;topMargin=dp(7) })
        }
        val time = partyMessageTime(message.optString("created_at"))
        if (time.isNotBlank()) {
            bubble.addView(TextView(this).apply {
                text = if (mine && message.optString("delivered_at").isNotBlank()) "$time  ✓✓" else time
                setTextColor(Color.argb(165,226,236,238))
                textSize = 8.2f
                gravity = Gravity.LEFT
            }, LinearLayout.LayoutParams(-1,-2).apply { topMargin = dp(4) })
        }

        if (mine) {
            wrap.addView(bubble,LinearLayout.LayoutParams(-2,-2).apply { marginEnd=dp(7) })
            wrap.addView(avatar,LinearLayout.LayoutParams(dp(38),dp(38)))
        } else {
            wrap.addView(avatar,LinearLayout.LayoutParams(dp(38),dp(38)))
            wrap.addView(bubble,LinearLayout.LayoutParams(-2,-2).apply { marginStart=dp(7) })
        }
        list.addView(wrap,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(10) })
        partyChatScroll?.post { partyChatScroll?.fullScroll(View.FOCUS_DOWN) }
    }

    private fun sendPartyMessage(message: String) {
        if (!partyActive || partyRoomCode.isBlank()) return
        val clientId = "android_${UUID.randomUUID().toString().replace("-","").take(40)}"
        AccountApi.watchPartyMessage(this, partyRoomCode, message, clientId) { result ->
            if (!result.success) Toast.makeText(this, result.message.ifBlank { "پیام ارسال نشد" }, Toast.LENGTH_SHORT).show()
            else handler.postDelayed({ pollWatchParty() }, 120L)
        }
    }

    private fun showPartyStickerPicker() {
        AccountApi.commentMediaCatalog(this) { result ->
            val packs=result.json?.optJSONArray("packs") ?: JSONArray()
            if (!result.success || packs.length()==0) {
                Toast.makeText(this,result.message.ifBlank { "استیکرها دریافت نشد" },Toast.LENGTH_SHORT).show()
                return@commentMediaCatalog
            }
            lateinit var dialog: AlertDialog
            val landscape = resources.displayMetrics.widthPixels > resources.displayMetrics.heightPixels
            val shell=LinearLayout(this).apply {
                orientation=LinearLayout.VERTICAL; layoutDirection=View.LAYOUT_DIRECTION_RTL
                setPadding(dp(10),dp(10),dp(10),dp(10)); background=partyGlass(26,246,86)
            }
            val header=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;gravity=Gravity.CENTER_VERTICAL }
            header.addView(LinearLayout(this).apply {
                orientation=LinearLayout.VERTICAL;gravity=Gravity.RIGHT
                addView(TextView(this@PlayerActivity).apply { text="استیکر و GIF";setTextColor(Color.WHITE);textSize=17f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.RIGHT })
                addView(TextView(this@PlayerActivity).apply { text="همان بسته‌های گفت‌وگو و کامنت بانک‌مووی";setTextColor(muted);textSize=9.8f;gravity=Gravity.RIGHT })
            },LinearLayout.LayoutParams(0,-2,1f))
            header.addView(TextView(this).apply { text="×";setTextColor(Color.WHITE);textSize=22f;gravity=Gravity.CENTER;background=partyGlass(999,214,60);setOnClickListener{dialog.dismiss()} },LinearLayout.LayoutParams(dp(42),dp(42)).apply{marginStart=dp(6)})
            shell.addView(header,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(7)})

            val tabScroll=HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled=false;overScrollMode=View.OVER_SCROLL_NEVER;layoutDirection=View.LAYOUT_DIRECTION_RTL }
            val tabs=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(dp(2),dp(3),dp(2),dp(6)) }
            tabScroll.addView(tabs)
            shell.addView(tabScroll,LinearLayout.LayoutParams(-1,dp(48)))

            val contentScroll=ScrollView(this).apply { isFillViewport=true }
            val grid=GridLayout(this).apply { columnCount=if(isTvLike())5 else if(landscape)4 else 3;alignmentMode=GridLayout.ALIGN_BOUNDS;useDefaultMargins=false }
            contentScroll.addView(grid)
            shell.addView(contentScroll,LinearLayout.LayoutParams(-1,0,1f))

            fun renderPack(pack:JSONObject) {
                grid.removeAllViews()
                val slug=pack.optString("slug").ifBlank { pack.optString("key") }
                val items=pack.optJSONArray("items") ?: JSONArray()
                for(j in 0 until items.length()) {
                    val it=items.optJSONObject(j)?:continue
                    val id=it.optString("id");val url=it.optString("url")
                    if(slug.isBlank()||id.isBlank()||url.isBlank())continue
                    val card=FrameLayout(this).apply {
                        background=partyGlass(16,208,54);isClickable=true;isFocusable=true;applyPlayerFocus(this,16,1.06f,0f)
                        addView(ImageView(this@PlayerActivity).apply { scaleType=ImageView.ScaleType.FIT_CENTER;adjustViewBounds=true;loadPartyImage(url,this) },FrameLayout.LayoutParams(-1,-1).apply{setMargins(dp(5),dp(5),dp(5),dp(5))})
                        setOnClickListener{sendPartyMessage("[bm-sticker:$slug:$id]");dialog.dismiss()}
                    }
                    val spec=GridLayout.spec(GridLayout.UNDEFINED,1f)
                    grid.addView(card,GridLayout.LayoutParams(spec,spec).apply { width=dp(if(isTvLike())112 else if(landscape)96 else 102);height=dp(if(isTvLike())94 else if(landscape)78 else 90);setMargins(dp(4),dp(4),dp(4),dp(4)) })
                }
                contentScroll.post{contentScroll.scrollTo(0,0)}
            }

            val tabViews=mutableListOf<TextView>()
            for(i in 0 until packs.length()) {
                val pack=packs.optJSONObject(i)?:continue
                val label=pack.optString("label").ifBlank{pack.optString("name").ifBlank{"بسته ${i+1}"}}
                val tab=TextView(this).apply {
                    text=label;setTextColor(Color.WHITE);textSize=10.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER
                    setPadding(dp(12),0,dp(12),0);isClickable=true;isFocusable=true
                    background=if(i==0)partyAccent(999)else partyGlass(999,210,52)
                    setOnClickListener{
                        tabViews.forEach{v->v.background=partyGlass(999,210,52)};background=partyAccent(999);renderPack(pack)
                    }
                }
                tabViews.add(tab);tabs.addView(tab,LinearLayout.LayoutParams(-2,dp(38)).apply{marginStart=dp(4);marginEnd=dp(4)})
            }
            if(packs.length()>0)packs.optJSONObject(0)?.let(::renderPack)
            dialog=AlertDialog.Builder(this).setView(shell).create();dialog.show();dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            val w=if(isTvLike())dp(690) else (resources.displayMetrics.widthPixels*(if(landscape)0.78f else 0.95f)).toInt()
            val h=(resources.displayMetrics.heightPixels*(if(landscape)0.82f else 0.68f)).toInt()
            dialog.window?.setLayout(w,h)
        }
    }

    private fun partyAbsoluteUrl(raw: String): String {
        val clean = raw.trim()
        if (clean.isBlank()) return ""
        if (clean.startsWith("http://", true) || clean.startsWith("https://", true)) return clean
        return AppConfig.BASE_DOMAIN.trimEnd('/') + "/" + clean.trimStart('/')
    }

    private fun loadPartyImage(url: String, target: ImageView) {
        val resolved = partyAbsoluteUrl(url)
        if (resolved.isBlank()) return
        Thread {
            try {
                val conn=(URL(resolved).openConnection() as HttpURLConnection).apply { connectTimeout=8000; readTimeout=10000; useCaches=true; setRequestProperty("User-Agent","BankmovieAndroidNative/2.3-WatchParty") }
                val bytes=conn.inputStream.use { input -> input.readBytes().let { if(it.size>5_000_000) ByteArray(0) else it } }
                conn.disconnect(); if(bytes.isEmpty()) return@Thread
                if(Build.VERSION.SDK_INT>=28) {
                    val drawable=ImageDecoder.decodeDrawable(ImageDecoder.createSource(ByteBuffer.wrap(bytes)))
                    runOnUiThread { if(!isFinishing){ target.setImageDrawable(drawable); if(drawable is AnimatedImageDrawable) drawable.start() } }
                } else {
                    val bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.size)
                    runOnUiThread { if(!isFinishing) target.setImageBitmap(bitmap) }
                }
            } catch (_:Throwable) {}
        }.start()
    }

    private fun showPartyReaction(media: JSONObject) {
        val url=media.optString("url"); if(url.isBlank()||!partyActive) return
        val image=ImageView(this).apply { scaleType=ImageView.ScaleType.CENTER_CROP; alpha=0f; scaleX=0.75f; scaleY=0.75f; background=partyGlass(24,170,42); loadPartyImage(url,this) }
        root.addView(image,FrameLayout.LayoutParams(dp(150),dp(150),Gravity.CENTER).apply { leftMargin=dp(220) })
        image.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180L).withEndAction {
            image.postDelayed({ image.animate().alpha(0f).scaleX(0.88f).scaleY(0.88f).setDuration(240L).withEndAction { runCatching { root.removeView(image) } }.start() },2200L)
        }.start()
    }

    private fun showPartyMembers() {
        lateinit var dialog: AlertDialog
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = partyGlass(24, 246, 126)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "اعضای اتاق (${partyMembers.length()})"
            setTextColor(Color.WHITE)
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(partyRoundIcon(R.drawable.ic_close_clean, 40) { dialog.dismiss() }, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginStart = dp(8) })
        shell.addView(header)

        fun sectionLabel(label: String) = TextView(this).apply {
            text = label
            setTextColor(Color.rgb(156, 188, 222))
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setPadding(0, dp(9), 0, dp(4))
        }
        fun memberCard(m: JSONObject, isHost: Boolean): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = if (isHost) partySoftAccent(17) else partyGlass(17, 214, 88)
            addView(partyAvatarView(m, 44), LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(10) })
            addView(LinearLayout(this@PlayerActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT
                addView(TextView(this@PlayerActivity).apply {
                    text = if (isHost) "${m.optString("username").ifBlank { "میزبان" }}  ♛" else m.optString("username").ifBlank { "همراه" }
                    setTextColor(if (isHost) Color.rgb(255, 203, 84) else Color.rgb(100, 232, 241))
                    textSize = 13f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.RIGHT
                })
                addView(TextView(this@PlayerActivity).apply {
                    text = if (isHost) "میزبان · کنترل پخش" else "آنلاین"
                    setTextColor(Color.rgb(182, 205, 229))
                    textSize = 9.5f
                    gravity = Gravity.RIGHT
                }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
            }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(TextView(this@PlayerActivity).apply {
                text = "●"
                setTextColor(Color.rgb(67, 229, 126))
                textSize = 12f
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(24), -2))
        }

        val hosts = mutableListOf<JSONObject>()
        val members = mutableListOf<JSONObject>()
        for (i in 0 until partyMembers.length()) {
            val m = partyMembers.optJSONObject(i) ?: continue
            if (m.optString("member_role").equals("host", true)) hosts += m else members += m
        }
        shell.addView(sectionLabel("میزبان (${hosts.size})"))
        if (hosts.isEmpty()) {
            shell.addView(TextView(this).apply {
                text = "در حال دریافت اطلاعات میزبان..."
                setTextColor(muted)
                textSize = 10f
                gravity = Gravity.RIGHT
                background = partyGlass(16, 205, 62)
                setPadding(dp(10), dp(12), dp(10), dp(12))
            })
        } else hosts.forEach { shell.addView(memberCard(it, true), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) }) }

        shell.addView(sectionLabel("اعضا (${members.size})"))
        if (members.isEmpty()) {
            shell.addView(TextView(this).apply {
                text = "هنوز کسی به اتاق اضافه نشده"
                setTextColor(muted)
                textSize = 10f
                gravity = Gravity.RIGHT
                background = partyGlass(16, 205, 62)
                setPadding(dp(10), dp(12), dp(10), dp(12))
            })
        } else members.forEach { shell.addView(memberCard(it, false), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) }) }

        shell.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            background = partyGlass(18, 220, 100)
            isClickable = true
            isFocusable = true
            applyPlayerFocus(this, 18, 1.04f, 0f)
            setOnClickListener { dialog.dismiss(); showPartyRoomSheet() }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(R.drawable.ic_player_settings)
                setColorFilter(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(20), dp(20)).apply { marginStart = dp(7) })
            addView(TextView(this@PlayerActivity).apply {
                text = "مدیریت اتاق"
                setTextColor(Color.WHITE)
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
        }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })

        val inviteRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun inviteButton(label: String, click: () -> Unit) = TextView(this).apply {
            text = label
            setTextColor(Color.rgb(92, 225, 240))
            textSize = 10.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = partySoftAccent(999)
            isClickable = true
            isFocusable = true
            setOnClickListener { click() }
        }
        inviteRow.addView(inviteButton("دعوت") { sharePartyInvite() }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginStart = dp(5) })
        inviteRow.addView(inviteButton("کپی لینک") { copyPartyInvite(); Toast.makeText(this, "لینک دعوت کپی شد", Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(5) })
        shell.addView(inviteRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        dialog = AlertDialog.Builder(this).setView(shell).create()
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout(if (isTvLike()) dp(520) else (resources.displayMetrics.widthPixels * 0.82f).toInt(), -2)
    }

    private fun copyPartyInvite() {
        val url=partyInviteUrl.ifBlank { AppConfig.BASE_DOMAIN.trimEnd('/') + "/watch-party?room=" + Uri.encode(partyRoomCode) }
        val cb=getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cb.setPrimaryClip(ClipData.newPlainText("BankMovie Watch Party",url))
    }

    private fun sharePartyInvite() {
        val url = partyInviteUrl.ifBlank { AppConfig.BASE_DOMAIN.trimEnd('/') + "/watch-party?room=" + Uri.encode(partyRoomCode) }
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "BankMovie Watch Party")
            putExtra(Intent.EXTRA_TEXT, "به اتاق خصوصی BankMovie من بیا:\n$url")
        }
        runCatching { startActivity(Intent.createChooser(share, "دعوت به Watch Party")) }
            .onFailure {
                copyPartyInvite()
                Toast.makeText(this, "لینک دعوت کپی شد", Toast.LENGTH_SHORT).show()
            }
    }

    private fun showPartyRoomSheet() {
        lateinit var dialog: AlertDialog
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14),dp(14),dp(14),dp(14))
            background = partyGlass(26,246,82)
        }
        shell.addView(TextView(this).apply {
            text = "تنظیمات اتاق"
            setTextColor(Color.WHITE)
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        })
        shell.addView(TextView(this).apply {
            text = "سینمای خصوصی BankMovie  •  $partyRoomCode"
            setTextColor(muted)
            textSize = 10.5f
            gravity = Gravity.RIGHT
            setPadding(0,dp(5),0,dp(10))
        })

        val scroll = ScrollView(this).apply {
            isFillViewport = false
            isVerticalScrollBarEnabled = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0,0,dp(2),dp(3))
        }
        fun row(label:String, sub:String, click:()->Unit) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            setPadding(dp(13),dp(10),dp(13),dp(10))
            background = partyGlass(17,212,52)
            isClickable = true
            isFocusable = true
            applyPlayerFocus(this,17,1.035f,0f)
            setOnClickListener { click() }
            addView(TextView(this@PlayerActivity).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            })
            addView(TextView(this@PlayerActivity).apply {
                text = sub
                setTextColor(muted)
                textSize = 9.6f
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(2) })
        }
        body.addView(row("اعضای اتاق","${partyMembers.length()}/2 نفر در اتاق") { dialog.dismiss(); showPartyMembers() }, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) })
        body.addView(row("تم و پس‌زمینه", if (partyIsHost) "انتخاب تم اتاق" else "فقط میزبان می‌تواند تغییر دهد") { dialog.dismiss(); showPartyThemes() }, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) })
        body.addView(row("کپی لینک دعوت","ارسال لینک واقعی همین اتاق") { copyPartyInvite(); Toast.makeText(this,"لینک دعوت کپی شد",Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) })
        body.addView(row("گفت‌وگوی خصوصی","باز کردن چت اتاق") { dialog.dismiss(); showWatchPartyChat() }, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) })
        body.addView(row("وضعیت همگام‌سازی", if (partyIsHost) "میزبان · کنترل پخش و تغییر منبع" else "همراه · دریافت زمان و منبع از میزبان") { showPartyChrome() }, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) })
        body.addView(TextView(this).apply {
            text = if (partyIsHost) "بستن اتاق و خروج" else "خروج از اتاق"
            setTextColor(Color.rgb(255,138,154))
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = partyGlass(17,214,58)
            setOnClickListener { dialog.dismiss(); leaveWatchPartyAndFinish() }
        }, LinearLayout.LayoutParams(-1,dp(46)).apply { topMargin=dp(3) })
        scroll.addView(body)
        shell.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))

        dialog = AlertDialog.Builder(this).setView(shell).create()
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val width = if (isTvLike()) dp(560) else (resources.displayMetrics.widthPixels*.86f).toInt()
        val maxHeight = (resources.displayMetrics.heightPixels * if (isTvLike()) .82f else .78f).toInt()
        dialog.window?.setLayout(width, maxHeight)
    }

    private fun showPartyThemes() {
        val themes=listOf(
            "simple" to "ساده", "purple_dream" to "رویای بنفش", "teal_mist" to "مه آبی", "golden" to "طلایی",
            "forest" to "جنگل", "pink_cloud" to "رویای پونی", "interstellar" to "میان ستاره‌ای", "pony" to "پونی", "pizza" to "پیتزا",
            "darkness" to "تاریکی", "romantic_hearts" to "عاشقانه", "galaxy_nova" to "کهکشانی", "starlight" to "ستاره‌ای", "aurora" to "شفق قطبی"
        )
        lateinit var dialog:AlertDialog
        val shell=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(12),dp(12),dp(12),dp(12)); background=partyGlass(24,246,82) }
        shell.addView(TextView(this).apply { text="تم و پس‌زمینه اتاق"; setTextColor(Color.WHITE); textSize=17f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.RIGHT; setPadding(0,0,0,dp(8)) })
        val scroll=ScrollView(this); val grid=GridLayout(this).apply { columnCount=3; alignmentMode=GridLayout.ALIGN_BOUNDS; useDefaultMargins=false }
        themes.forEach { (key,label) ->
            val color=partyThemeColor(key)
            val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(dp(5),dp(5),dp(5),dp(5)); background=if(key==partyThemeKey) rounded(Color.argb(72,Color.red(blue),Color.green(blue),Color.blue(blue)),16,blue2) else partyGlass(16,205,45); isClickable=partyIsHost; isFocusable=partyIsHost; applyPlayerFocus(this,16,1.05f,0f)
                addView(View(this@PlayerActivity).apply { background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(color,Color.rgb(20,21,26))).apply { cornerRadius=dp(12).toFloat() } },LinearLayout.LayoutParams(-1,dp(55)))
                addView(TextView(this@PlayerActivity).apply { text=label; setTextColor(Color.WHITE); textSize=10f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER },LinearLayout.LayoutParams(-1,dp(28)))
                setOnClickListener { if(partyIsHost) AccountApi.watchPartyRoomSettings(this@PlayerActivity,partyRoomCode,key){r->if(r.success){partyThemeKey=key;applyPartyTheme(key);dialog.dismiss()}else Toast.makeText(this@PlayerActivity,r.message,Toast.LENGTH_SHORT).show()} }
            }
            grid.addView(card,GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED,1f),GridLayout.spec(GridLayout.UNDEFINED,1f)).apply { width=dp(if(isTvLike())160 else 105); height=dp(96); setMargins(dp(4),dp(4),dp(4),dp(4)) })
        }
        scroll.addView(grid); shell.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        if(!partyIsHost) shell.addView(TextView(this).apply { text="انتخاب تم فقط در اختیار میزبان VIP است"; setTextColor(muted); textSize=10f; gravity=Gravity.CENTER },LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(6) })
        dialog=AlertDialog.Builder(this).setView(shell).create(); dialog.show(); dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); dialog.window?.setLayout(if(isTvLike())dp(590) else (resources.displayMetrics.widthPixels*0.9f).toInt(),(resources.displayMetrics.heightPixels*0.82f).toInt())
    }

    private fun partyThemeColor(key:String):Int=when(key){
        "purple_dream"->Color.rgb(126,53,210); "teal_mist"->Color.rgb(20,150,153); "golden"->Color.rgb(204,146,24); "forest"->Color.rgb(22,116,67);
        "pink_cloud"->Color.rgb(182,72,130); "interstellar"->Color.rgb(60,43,127); "pony"->Color.rgb(178,92,136); "pizza"->Color.rgb(142,74,35); "darkness"->Color.rgb(24,27,34);
        "romantic_hearts"->Color.rgb(171,46,93); "galaxy_nova"->Color.rgb(91,34,130); "starlight"->Color.rgb(38,68,137); "aurora"->Color.rgb(19,135,111);
        else->Color.rgb(45,49,58)
    }

    private fun applyPartyTheme(key:String) {
        val c = if (key == "simple") Color.rgb(20, 190, 232) else partyThemeColor(key)
        val dark = UiPreferences.blend(Color.rgb(4, 18, 35), c, if (key == "simple") 0.10f else 0.18f)
        partyDock?.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.argb(224, Color.red(dark), Color.green(dark), Color.blue(dark)), Color.argb(238, 3, 15, 29))).apply {
            cornerRadius = dp(24).toFloat()
            setStroke(dp(1), Color.argb(130, 48, 185, 255))
        }
        partyStatusChip?.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.argb(218, 5, 52, 72), Color.argb(210, Color.red(c), Color.green(c), Color.blue(c)))).apply {
            cornerRadius = dp(999).toFloat()
            setStroke(dp(1), Color.argb(150, 83, 224, 255))
        }
        partyChatDialog?.window?.decorView?.background = ColorDrawable(Color.TRANSPARENT)
        val chatBase = if (key == "simple") Color.rgb(5, 24, 45) else UiPreferences.blend(Color.rgb(5, 24, 45), c, 0.22f)
        partyChatList?.background = GradientDrawable(GradientDrawable.Orientation.BL_TR, intArrayOf(chatBase, UiPreferences.blend(chatBase, Color.BLACK, 0.24f)))
    }

    private fun leaveWatchPartyAndFinish() {
        if (!partyActive) { finish(); return }
        partyActive=false; handler.removeCallbacks(partyPollRunnable)
        AccountApi.watchPartyLeave(this,partyRoomCode,partyIsHost) { finish() }
        handler.postDelayed({ if(!isFinishing) finish() },700L)
    }

    // PASS 4.3 — WebRTC/voice call removed to keep APK compact and stable.

    private fun simplePlayerIcon(iconRes: Int, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            applyPlayerFocus(this, 20, 1.10f, 0f)
            setOnClickListener {
                if (!controlsLocked || iconRes == R.drawable.ic_player_lock) {
                    click()
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, FrameLayout.LayoutParams(dp(PLAYER_UTILITY_ICON_DP), dp(PLAYER_UTILITY_ICON_DP), Gravity.CENTER))
        }
    }

    private fun simplePlayerIconWithText(iconRes: Int, label: String, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            applyPlayerFocus(this, 22, 1.10f, 0f)
            setOnClickListener {
                if (!controlsLocked) {
                    click()
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }, FrameLayout.LayoutParams(dp(23), dp(23), Gravity.CENTER).apply { rightMargin = dp(8) })
            addView(TextView(this@PlayerActivity).apply {
                text = label.replace("نرمال", "1x").replace(".0x", "x")
                setTextColor(Color.WHITE)
                textSize = 11.5f
                typeface = Typeface.DEFAULT_BOLD
            }, FrameLayout.LayoutParams(-2, -2, Gravity.RIGHT or Gravity.TOP).apply { rightMargin = dp(2); topMargin = dp(0) })
        }
    }

    private fun topActionButton(iconRes: Int, label: String, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(7), 0, dp(7), 0)
            background = rounded(Color.argb(150, 6, 14, 28), dp(18), Color.argb(155, 55, 99, 170))
            setOnClickListener {
                if (!controlsLocked) {
                    click()
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(17), dp(17)).apply { marginEnd = dp(4) })
            addView(TextView(this@PlayerActivity).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 10.2f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
            })
        }
    }

    private fun typeSwitchButton(iconRes: Int, label: String, subtitle: Boolean): LinearLayout {
        val active = tracks.getOrNull(currentIndex)?.let { isSubtitle(it) == subtitle } ?: false
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), 0, dp(8), 0)
            background = if (active) {
                android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.argb(230, 25, 115, 255), Color.argb(210, 92, 60, 255))).apply {
                    cornerRadius = dp(20).toFloat()
                    setStroke(dp(1), Color.argb(210, 190, 225, 255))
                }
            } else rounded(Color.argb(150, 6, 14, 28), dp(20), Color.argb(155, 55, 99, 170))
            setOnClickListener {
                if (!controlsLocked) {
                    quickTypeSwitch(subtitle)
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginEnd = dp(5) })
            addView(TextView(this@PlayerActivity).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 11f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
            })
        }
    }

    private fun glassIconButton(iconRes: Int, click: () -> Unit): FrameLayout {
        val box = FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
            applyPlayerFocus(this, 999, 1.045f, 0f)
            setOnClickListener {
                if (!controlsLocked || iconRes == R.drawable.ic_player_unlock) {
                    click()
                    hideBarsLater()
                }
            }
        }
        box.addView(ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(Color.WHITE)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, FrameLayout.LayoutParams(dp(PLAYER_UTILITY_ICON_DP), dp(PLAYER_UTILITY_ICON_DP), Gravity.CENTER))
        return box
    }

    private fun circleAction(iconRes: Int, smallLabel: String, click: () -> Unit): FrameLayout {
        val box = FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
            applyPlayerFocus(this, 999, 1.10f, 0f)
            setOnClickListener { click(); hideBarsLater() }
        }
        val stack = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        stack.addView(ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(Color.WHITE)
        }, LinearLayout.LayoutParams(dp(32), dp(32)))
        stack.addView(TextView(this).apply {
            text = smallLabel
            setTextColor(Color.WHITE)
            textSize = 11.2f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        })
        box.addView(stack, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        return box
    }

    private fun schedulePlaybackRetry(url: String, reason: String = "خطا در پخش") {
        if (playbackRetryScheduled || isFinishing || isDestroyed) return
        val clean = url.trim()
        if (clean.isBlank()) return
        if (playbackRetryCount >= maxPlaybackRetries) {
            playbackRetryScheduled = false
            Toast.makeText(this, "این لینک بعد از $maxPlaybackRetries تلاش پخش نشد؛ کیفیت یا نسخه دیگری را انتخاب کنید", Toast.LENGTH_LONG).show()
            releasePlayerAsyncForRebuild()
            return
        }
        playbackRetryCount += 1
        if (playbackRetryCount == 1) hardwareDecoder = false
        val keep = runCatching { player?.time?.coerceAtLeast(0L) ?: 0L }.getOrDefault(0L)
        if (keep > 0L) requestedResumePosition = max(requestedResumePosition, keep)
        playbackRetryScheduled = true
        Toast.makeText(this, "$reason؛ تلاش مجدد ${playbackRetryCount}/$maxPlaybackRetries", Toast.LENGTH_SHORT).show()
        val delayMs = (650L + playbackRetryCount * 250L).coerceAtMost(1700L)
        handler.postDelayed({
            playbackRetryScheduled = false
            if (!isFinishing && !isDestroyed) launchPlayerSafely(clean)
        }, delayMs)
    }

    private fun launchPlayerSafely(url: String) {
        val clean = url.trim()
        if (clean.isBlank()) {
            Toast.makeText(this, "لینک پخش خالی است", Toast.LENGTH_LONG).show()
            return
        }
        try {
            startPlayer(clean)
        } catch (_: Throwable) {
            releasePlayerAsyncForRebuild()
            schedulePlaybackRetry(clean, "پلیر نتوانست منبع را باز کند")
        }
    }

    private fun irancellSubtitleFontPath(): String? {
        val assetName = BankmovieFonts.assetFileName(subtitleFontMode) ?: return null
        val dir = File(filesDir, "subtitle_fonts")
        val out = File(dir, assetName)
        if (out.isFile && out.length() > 4096L) return out.absolutePath
        return runCatching {
            dir.mkdirs()
            assets.open("fonts/$assetName").use { input ->
                out.outputStream().use { output -> input.copyTo(output) }
            }
            out.takeIf { it.isFile && it.length() > 4096L }?.absolutePath
        }.getOrNull()
    }

    private fun isMeteredOrMobileNetwork(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return runCatching {
            val network = cm.activeNetwork ?: return@runCatching true
            val caps = cm.getNetworkCapabilities(network) ?: return@runCatching true
            cm.isActiveNetworkMetered || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
        }.getOrDefault(true)
    }

    private fun stableCacheMs(isAdaptive: Boolean): Int {
        if (!isAdaptive) return if (DeviceProfile.isLowEnd(this)) 2200 else 1700
        return when {
            isMeteredOrMobileNetwork() -> 6500
            DeviceProfile.isLowEnd(this) -> 5200
            else -> 4200
        }
    }

    private fun startPlayer(url: String) {
        releasePlayerAsyncForRebuild()
        resumeApplied = false
        val isDash = url.lowercase(Locale.US).contains(".mpd") || url.lowercase(Locale.US).contains("format=mpd") || url.lowercase(Locale.US).contains("dash")
        val isHls = url.lowercase(Locale.US).contains(".m3u8") || url.lowercase(Locale.US).contains("hls")
        // Restore the previously stable player buffering. The aggressive TV
        // adaptive/caching patch caused decoder artifacts on some televisions.
        val cacheMs = stableCacheMs(isDash || isHls)
        val subtitleBgColor = UiPreferences.subtitleBackgroundColor(this) and 0xFFFFFF
        val subtitleBgOpacity = UiPreferences.subtitleBackgroundOpacity(this)
        val libOptions = arrayListOf(
            "--network-caching=$cacheMs",
            "--file-caching=$cacheMs",
            "--live-caching=$cacheMs",
            "--http-reconnect",
            "--audio-time-stretch",
            "--drop-late-frames",
            "--subsdec-encoding=UTF-8",
            "--sub-text-scale=$subtitleScale",
            "--freetype-rel-fontsize=22",
            "--sub-margin=${subtitleMargins[subtitlePositionIndex]}",
            "--freetype-color=${subtitleTextColor and 0xFFFFFF}",
            "--freetype-outline-color=0",
            "--freetype-outline-thickness=3",
            "--freetype-background-color=$subtitleBgColor",
            "--freetype-background-opacity=$subtitleBgOpacity"
        )
        if (subtitleBold) libOptions.add("--freetype-bold")
        irancellSubtitleFontPath()?.let { fontPath ->
            libOptions.add("--freetype-font=$fontPath")
        }
        if (isDash || isHls) {
            libOptions.add("--adaptive-logic=rate")
            libOptions.add("--adaptive-use-access")
        }
        val lib = LibVLC(this, libOptions)
        vlc = lib
        val mp = MediaPlayer(lib)
        player = mp
        // Preserve VLC-style boost when switching quality/episode inside the same player activity.
        runCatching { mp.javaClass.getMethod("setVolume", Integer.TYPE).invoke(mp, currentVlcVolumePercent.coerceIn(0, VOLUME_BOOST_MAX_PERCENT.roundToInt())) }
        mp.attachViews(videoLayout, null, false, false)
        mp.setEventListener { event ->
            runOnUiThread {
                when (event.type) {
                    MediaPlayer.Event.Buffering -> {
                        val percent = event.buffering
                        if (percent < 1f && bufferingStartedAt == 0L) bufferingStartedAt = System.currentTimeMillis()
                        if (percent >= 99f && bufferingStartedAt > 0L) {
                            val stalledFor = System.currentTimeMillis() - bufferingStartedAt
                            bufferingStartedAt = 0L
                            if (stalledFor >= 4500L) recentLongBufferCount += 1
                            if (recentLongBufferCount >= 3 && hardwareDecoder && !decoderAutoFallbackUsed) {
                                decoderAutoFallbackUsed = true
                                val keep = player?.time?.coerceAtLeast(0L) ?: 0L
                                hardwareDecoder = false
                                requestedResumePosition = keep
                                showHud("حالت پایدار تصویر فعال شد")
                                handler.postDelayed({ launchPlayerSafely(videoUrl) }, 180L)
                            }
                        }
                    }
                    MediaPlayer.Event.Playing -> {
                        if (partyActive) partyReadyLaunchInFlight = false
                        playbackRetryCount = 0
                        playbackRetryScheduled = false
                        bufferingStartedAt = 0L
                        playIcon.setImageResource(R.drawable.ic_player_pause)
                        if (partyActive && partyIsHost && !partyApplyingRemote) {
                            val now = System.currentTimeMillis()
                            if (now - partyLastExplicitPlaySentAt > 450L) {
                                partyLastExplicitPlaySentAt = now
                                sendWatchPartyControl("play")
                            }
                        }
                        if (pauseAfterLifecycleRestore && !lifecycleFrameAwaitingVideo) {
                            pauseAfterLifecycleRestore = false
                            handler.postDelayed({ runCatching { player?.pause() } }, 180L)
                        }
                        applyMode()
                        applySubtitleDelay()
                        handler.postDelayed({ applySubtitleVisibility() }, 350L)
                        handler.postDelayed({ applyPreferredNativeTracks() }, 500L)
                        handler.postDelayed({ applyPreferredNativeTracks() }, 1300L)
                        if (!resumeApplied) {
                            resumeApplied = true
                            val prefs = getSharedPreferences("bm_smart_cinema", MODE_PRIVATE)
                            val stableKey = progressKey.ifBlank { "progress_$videoUrl" }
                            val stored = prefs.getLong(stableKey, prefs.getLong("progress_$videoUrl", 0L))
                            val saved = max(stored, requestedResumePosition)
                            if (saved > 15000L) {
                                fun applyResumeSeek() {
                                    try {
                                        val current = player?.time ?: 0L
                                        if (current < saved - 5000L) player?.time = saved
                                    } catch (_: Throwable) {}
                                }
                                applyResumeSeek()
                                listOf(300L, 800L, 1600L, 3000L, 5000L, 8000L, 11000L).forEach { delayMs ->
                                    handler.postDelayed({ applyResumeSeek() }, delayMs)
                                }
                                showHud("ادامه از ${fmt(saved)}")
                            }
                        }
                        updateLabels()
                    }
                    MediaPlayer.Event.Vout -> {
                        // V7.25: Vout only means a video output object exists; on many
                        // devices that Surface is still black for several seconds.
                        // Never reveal it yet. Probe the actual Surface pixels instead.
                        lifecycleFrameVoutSeen = true
                        if (lifecycleFrameAwaitingVideo) startLifecycleFrameReadyProbe()
                    }
                    MediaPlayer.Event.TimeChanged -> {
                        // Audio/time can advance before the first video frame. Keep the
                        // frozen frame visible until the surface probe confirms pixels.
                        if (lifecycleFrameAwaitingVideo) startLifecycleFrameReadyProbe()
                    }
                    MediaPlayer.Event.Paused -> playIcon.setImageResource(R.drawable.ic_player_play)
                    MediaPlayer.Event.Stopped -> playIcon.setImageResource(R.drawable.ic_player_play)
                    MediaPlayer.Event.EndReached -> playNext()
                    MediaPlayer.Event.EncounteredError -> {
                        if (partyActive) partyReadyLaunchInFlight = false
                        schedulePlaybackRetry(videoUrl, "خطا در پخش")
                    }
                }
            }
        }
        val media = Media(lib, Uri.parse(url))
        media.setHWDecoderEnabled(hardwareDecoder, false)
        media.addOption(":input-repeat=0")
        media.addOption(":http-reconnect=true")
        media.addOption(":network-caching=$cacheMs")
        media.addOption(":subsdec-encoding=UTF-8")
        if (subtitleBold) media.addOption(":freetype-bold")
        irancellSubtitleFontPath()?.let { media.addOption(":freetype-font=$it") }
        media.addOption(":freetype-color=${subtitleTextColor and 0xFFFFFF}")
        media.addOption(":freetype-outline-color=0")
        media.addOption(":freetype-outline-thickness=3")
        media.addOption(":freetype-background-color=$subtitleBgColor")
        media.addOption(":freetype-background-opacity=$subtitleBgOpacity")
        val resumePrefs = getSharedPreferences("bm_smart_cinema", MODE_PRIVATE)
        val resumeStableKey = progressKey.ifBlank { "progress_$videoUrl" }
        val resumeBeforePlay = max(
            resumePrefs.getLong(
                resumeStableKey,
                resumePrefs.getLong("progress_$videoUrl", 0L)
            ),
            requestedResumePosition
        )
        resumeTarget = resumeBeforePlay
        resumeGuardUntil = System.currentTimeMillis() + 12000L
        if (resumeBeforePlay > 15000L) {
            media.addOption(":start-time=${resumeBeforePlay / 1000L}")
        }
        if (isDash || isHls) {
            media.addOption(":demux=adaptive")
            media.addOption(":adaptive-logic=rate")
            media.addOption(":adaptive-use-access=true")
        }
        mp.media = media
        media.release()
        mp.play()
        if (currentSpeed != 1.0f) {
            try { mp.setRate(currentSpeed) } catch (_: Throwable) {}
        }
        applySubtitleDelay()
        handler.removeCallbacks(progressRunnable)
        handler.post(progressRunnable)
    }

    private fun switchTo(index: Int, preserveRequestedResume: Boolean = false) {
        if (partyGuestPlaybackLocked()) {
            showGuestPlaybackLockedNotice()
            return
        }
        if (index !in tracks.indices) return
        if (player != null && videoUrl.isNotBlank()) savePlaybackProgress(true)
        currentIndex = index
        nextPromptShownKey = ""
        skipNextOnce = false
        nextPromptDialog?.dismiss()
        title = tracks[index].title
        videoUrl = tracks[index].url
        progressKey = tracks[index].progressKey.ifBlank { "progress_$videoUrl" }
        val storedResume = UiPreferences.prefs(this).getLong(
            progressKey,
            UiPreferences.prefs(this).getLong("progress_$videoUrl", 0L)
        )
        requestedResumePosition = if (preserveRequestedResume) {
            max(requestedResumePosition, storedResume)
        } else {
            storedResume
        }
        updateLabels()
        refreshTopActions()
        launchPlayerSafely(videoUrl)
        showHud(currentLabel().ifBlank { "در حال پخش" })
    }

    private fun refreshTopActions() {
        // Simple VLC/MX-style top controls stay fixed.
    }


    private fun updateLabels() {
        titleText.text = title
        subText.text = currentLabel()
        rebuildPlayerMetaChips()
    }

    private fun playerMetaChip(label: String, iconRes: Int? = null, onClick: (() -> Unit)? = null): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(8), 0, dp(8), 0)
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.argb(190, 19, 36, 62), Color.argb(182, 9, 22, 43))).apply {
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), Color.argb(104, 94, 160, 235))
            }
            if (onClick != null) {
                isClickable = true
                isFocusable = true
                applyPlayerFocus(this, 8, 1.035f, 0f)
                setOnClickListener { onClick() }
            }
            if (iconRes != null) {
                addView(ImageView(this@PlayerActivity).apply {
                    setImageResource(iconRes)
                    setColorFilter(Color.WHITE)
                    scaleType = ImageView.ScaleType.CENTER_INSIDE
                }, LinearLayout.LayoutParams(dp(14), dp(14)).apply { marginEnd = dp(5) })
            }
            if (label.isNotBlank()) {
                addView(TextView(this@PlayerActivity).apply {
                    text = label
                    setTextColor(Color.rgb(229, 238, 252))
                    textSize = 9.5f
                    typeface = Typeface.DEFAULT_BOLD
                    includeFontPadding = false
                    gravity = Gravity.CENTER
                    maxLines = 1
                })
            }
        }
    }

    private fun rebuildPlayerMetaChips() {
        if (!::playerMetaRow.isInitialized) return
        playerMetaRow.removeAllViews()
        val current = tracks.getOrNull(currentIndex)
        val quality = current?.quality?.trim()?.takeIf { it.isNotBlank() }
            ?: Regex("(?i)(2160|1440|1080|720|480|360|240)p").find(currentLabel())?.value
            ?: ""
        fun add(view: View) {
            playerMetaRow.addView(view, LinearLayout.LayoutParams(-2, dp(25)).apply { marginEnd = dp(5) })
        }
        if (quality.isNotBlank()) add(playerMetaChip(quality.uppercase(Locale.US)) { showQualitySheet() })
        val hasDub = tracks.any { !isSubtitle(it) && !isAudioOnly(it) }
        val hasSub = tracks.any { isSubtitle(it) }
        if (hasDub) add(playerMetaChip("دوبله", R.drawable.ic_dubbed_mic_green) { showTypeSheet(false) })
        if (hasSub) add(playerMetaChip("زیرنویس", R.drawable.ic_setup_subtitle) { showTypeSheet(true) })
        add(playerMetaChip("", R.drawable.ic_player_cc) { showAudioSubtitleSettingsSheet() })
    }

    private fun currentLabel(): String = tracks.getOrNull(currentIndex)?.let { trackLabel(it) } ?: ""

    private fun streamStandard(url: String): String {
        val u = url.lowercase(Locale.US)
        return when {
            u.contains(".mpd") || u.contains("format=mpd") || u.contains("dash") -> "DASH"
            u.contains(".m3u8") || u.contains("hls") -> "HLS"
            else -> ""
        }
    }

    private fun streamBadgeText(): String {
        val s = streamStandard(videoUrl)
        return if (s.isBlank()) "" else s
    }

    private fun trackLabel(t: Track): String {
        val typeFa = when {
            t.typeFa.isNotBlank() -> t.typeFa
            isSubtitle(t) -> "زیرنویس"
            isAudioOnly(t) -> "صوت دوبله"
            else -> "دوبله"
        }
        val base = t.displayLabel.ifBlank { (t.quality.ifBlank { "کیفیت نامشخص" }) + " • " + typeFa }.trim()
        val normalized = base.lowercase(Locale.US).replace("‌", " ")
        val alreadyHasEpisode = normalized.contains("قسمت ${t.episode}") || normalized.contains("episode ${t.episode}") || normalized.contains("e${t.episode}")
        val alreadyHasSeason = normalized.contains("فصل ${t.season}") || normalized.contains("season ${t.season}") || normalized.contains("s${t.season}")
        val episodeHead = when {
            t.season > 0 && t.episode > 0 && !(alreadyHasSeason || alreadyHasEpisode) -> "فصل ${t.season} • قسمت ${t.episode}"
            t.episode > 0 && !alreadyHasEpisode -> "قسمت ${t.episode}"
            t.season > 0 && !alreadyHasSeason -> "فصل ${t.season}"
            else -> ""
        }
        val standard = streamStandard(t.url)
        return listOf(episodeHead, base, standard).filter { it.isNotBlank() }.distinct().joinToString(" • ")
    }

    private fun isSubtitle(t: Track): Boolean {
        val s = (t.type + " " + t.typeFa + " " + t.displayLabel + " " + t.label + " " + t.url).lowercase(Locale.US)
        return s.contains("sub") || s.contains("subtitle") || s.contains("زیر")
    }

    private fun isAudioOnly(t: Track): Boolean = t.isAudio || t.url.lowercase(Locale.US).endsWith(".mka") || t.url.lowercase(Locale.US).endsWith(".mp3")

    private fun showSourceSheet() {
        if (tracks.isEmpty()) return
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = playerGlassSurface(26, 244, 76)
        }
        scroll.addView(box)
        var dialog: AlertDialog? = null
        val isSeries = tracks.any { it.season > 0 || it.episode > 0 }
        if (isSeries) {
            tracks.groupBy { it.season }.toSortedMap().forEach { entry ->
                box.addView(sectionTitle(if (entry.key > 0) "فصل ${entry.key}" else "قسمت‌ها"))
                entry.value.groupBy { it.episode }.toSortedMap().forEach { ep ->
                    box.addView(TextView(this).apply {
                        text = if (ep.key > 0) "قسمت ${ep.key}" else "لینک‌ها"
                        setTextColor(muted)
                        textSize = 13f
                        setPadding(0, dp(8), 0, dp(4))
                    })
                    val first = ep.value.firstOrNull() ?: return@forEach
                    val idx = tracks.indexOf(first)
                    box.addView(sheetButton("${trackLabel(first)}${if (idx == currentIndex) "  ●" else ""}") {
                        dialog?.dismiss(); switchTo(idx)
                    }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4); bottomMargin = dp(4) })
                }
            }
        } else {
            tracks.forEachIndexed { idx, t ->
                box.addView(sheetButton("${trackLabel(t)}${if (idx == currentIndex) "  ●" else ""}") {
                    dialog?.dismiss(); switchTo(idx)
                }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4); bottomMargin = dp(4) })
            }
        }
        dialog = dialogOf(scroll)
        dialog.show()
    }

    private fun scopedTracks(): List<Track> {
        val current = tracks.getOrNull(currentIndex)
        return if (current != null && (current.season > 0 || current.episode > 0)) {
            tracks.filter { it.season == current.season && it.episode == current.episode }
        } else tracks.toList()
    }

    private fun showQualitySheet() {
        val scoped = scopedTracks().filter { !isAudioOnly(it) }
        if (scoped.isEmpty()) return
        val unique = linkedMapOf<String, Track>()
        scoped.forEach { if (it.quality.isNotBlank() && !unique.containsKey(it.quality)) unique[it.quality] = it }
        if (unique.isEmpty()) return Toast.makeText(this, "کیفیتی پیدا نشد", Toast.LENGTH_SHORT).show()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = playerGlassSurface(26, 244, 76)
        }
        box.addView(sectionTitle("انتخاب کیفیت"))
        var dialog: AlertDialog? = null
        unique.forEach { q, sample ->
            box.addView(sheetButton(q + if (sample.quality == tracks.getOrNull(currentIndex)?.quality) "  ●" else "") {
                dialog?.dismiss()
                val current = tracks.getOrNull(currentIndex)
                val target = scoped.firstOrNull { it.quality == q }
                val idx = tracks.indexOf(target)
                if (idx >= 0) switchTo(idx)
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(5); bottomMargin = dp(5) })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
    }

    private fun quickTypeSwitch(subtitleOnly: Boolean) {
        val current = tracks.getOrNull(currentIndex)
        val scoped = scopedTracks().filter { if (subtitleOnly) isSubtitle(it) else (!isSubtitle(it) && !isAudioOnly(it)) }
        if (scoped.isEmpty()) {
            Toast.makeText(this, if (subtitleOnly) "نسخه زیرنویس پیدا نشد" else "نسخه دوبله پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }
        val preferred = scoped.firstOrNull { it.quality == current?.quality } ?: scoped.firstOrNull()
        val idx = tracks.indexOf(preferred)
        if (idx >= 0 && idx != currentIndex) {
            switchTo(idx)
        } else {
            showTypeSheet(subtitleOnly)
        }
    }

    private fun showTypeSheet(subtitleOnly: Boolean) {
        val scoped = scopedTracks().filter { if (subtitleOnly) isSubtitle(it) else (!isSubtitle(it) && !isAudioOnly(it)) }
        if (scoped.isEmpty()) return Toast.makeText(this, if (subtitleOnly) "نسخه زیرنویس پیدا نشد" else "نسخه دوبله پیدا نشد", Toast.LENGTH_SHORT).show()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = playerGlassSurface(26, 244, 76)
        }
        box.addView(sectionTitle(if (subtitleOnly) "زیرنویس" else "صدا / دوبله"))
        var dialog: AlertDialog? = null
        scoped.forEach { t ->
            val idx = tracks.indexOf(t)
            box.addView(sheetButton("${t.quality.ifBlank { "نامشخص" }}${if (idx == currentIndex) "  ●" else ""}") {
                dialog?.dismiss(); if (idx >= 0) switchTo(idx)
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(5); bottomMargin = dp(5) })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
    }

    private data class NativeTrackOption(val id: Int, val name: String)

    private fun nativeTrackOptions(methodName: String): List<NativeTrackOption> {
        val mp = player ?: return emptyList()
        return try {
            val raw = mp.javaClass.getMethod(methodName).invoke(mp)
            val values: List<Any?> = when (raw) {
                is Array<*> -> raw.toList()
                is Iterable<*> -> raw.toList()
                else -> emptyList()
            }
            values.mapNotNull { item ->
                if (item == null) return@mapNotNull null
                val id = try {
                    item.javaClass.getMethod("getId").invoke(item) as? Int
                } catch (_: Throwable) {
                    try { item.javaClass.getField("id").getInt(item) } catch (_: Throwable) { null }
                } ?: return@mapNotNull null
                val name = try {
                    item.javaClass.getMethod("getName").invoke(item)?.toString()
                } catch (_: Throwable) {
                    try { item.javaClass.getField("name").get(item)?.toString() } catch (_: Throwable) { null }
                }.orEmpty().ifBlank { "Track $id" }
                NativeTrackOption(id, name)
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun currentNativeTrack(methodName: String): Int {
        val mp = player ?: return -1
        return try { (mp.javaClass.getMethod(methodName).invoke(mp) as? Int) ?: -1 } catch (_: Throwable) { -1 }
    }

    private fun setNativeTrack(methodName: String, id: Int): Boolean {
        val mp = player ?: return false
        return try {
            val result = mp.javaClass.getMethod(methodName, Integer.TYPE).invoke(mp, id)
            result !is Boolean || result
        } catch (_: Throwable) {
            false
        }
    }

    private fun applySubtitleVisibility() {
        if (!subtitleEnabled) {
            val current = currentNativeTrack("getSpuTrack")
            if (current >= 0) lastEnabledSpuTrack = current
            setNativeTrack("setSpuTrack", -1)
            return
        }
        val current = currentNativeTrack("getSpuTrack")
        if (current >= 0) return
        val available = nativeTrackOptions("getSpuTracks").filter { it.id >= 0 }
        val target = available.firstOrNull { it.id == lastEnabledSpuTrack } ?: available.firstOrNull()
        if (target != null) setNativeTrack("setSpuTrack", target.id)
    }

    private fun applyPreferredNativeTracks() {
        if (preferredAudioTrackId != Int.MIN_VALUE && preferredAudioTrackId >= 0) {
            setNativeTrack("setAudioTrack", preferredAudioTrackId)
        }
        if (!subtitleEnabled || preferredSubtitleTrackId == -1) {
            setNativeTrack("setSpuTrack", -1)
            return
        }
        if (preferredSubtitleTrackId != Int.MIN_VALUE && preferredSubtitleTrackId >= 0) {
            lastEnabledSpuTrack = preferredSubtitleTrackId
            setNativeTrack("setSpuTrack", preferredSubtitleTrackId)
        }
    }

    private fun showNativeTrackDialog(titleValue: String, audio: Boolean) {
        val options = nativeTrackOptions(if (audio) "getAudioTracks" else "getSpuTracks")
        val current = currentNativeTrack(if (audio) "getAudioTrack" else "getSpuTrack")
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(Color.argb(248, 18, 18, 21), dp(28), Color.argb(150, Color.red(blue), Color.green(blue), Color.blue(blue)))
        }
        box.addView(sectionTitle(titleValue))
        var dialog: AlertDialog? = null
        if (!audio) {
            box.addView(sheetButton("خاموش${if (current < 0) "  ✓" else ""}") {
                subtitleEnabled = false
                UiPreferences.prefs(this).edit().putBoolean(UiPreferences.KEY_SUB_ENABLED, false).apply()
                applySubtitleVisibility()
                dialog?.dismiss()
                showHud("زیرنویس غیرفعال شد")
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(7) })
        }
        options.filter { audio || it.id >= 0 }.forEach { option ->
            box.addView(sheetButton("${option.name}${if (option.id == current) "  ✓" else ""}") {
                if (audio) setNativeTrack("setAudioTrack", option.id)
                else {
                    subtitleEnabled = true
                    lastEnabledSpuTrack = option.id
                    UiPreferences.prefs(this).edit().putBoolean(UiPreferences.KEY_SUB_ENABLED, true).apply()
                    setNativeTrack("setSpuTrack", option.id)
                }
                dialog?.dismiss()
                showHud(if (audio) "ترک صدا تغییر کرد" else "زیرنویس فعال شد")
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(7) })
        }
        if (options.isEmpty()) {
            box.addView(TextView(this).apply {
                text = "ترکی برای انتخاب پیدا نشد"
                setTextColor(muted)
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(18), dp(12), dp(18))
            })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun showSettingsSheet() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = playerGlassSurface(30, 248, 88)
            elevation = dp(10).toFloat()
        }
        scroll.addView(box)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        header.addView(TextView(this).apply {
            text = "تنظیمات پخش"
            setTextColor(Color.WHITE)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_player_settings)
            setColorFilter(Color.WHITE)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = playerGlassAccent(15)
        }, LinearLayout.LayoutParams(dp(42), dp(42)))
        box.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        box.addView(settingsMiniLabel("صدا و زیرنویس"))
        box.addView(settingButton("صدا، زیرنویس و ظاهر", subtitleStyleLabel(), "انتخاب ترک صدا و زیرنویس، خاموش‌کردن، رنگ، پس‌زمینه، اندازه و فونت") { showAudioSubtitleSettingsSheet() })

        box.addView(settingsMiniLabel("پخش"))
        box.addView(settingButton("سرعت پخش", speedLabel(), "تنظیم از 0.5x تا 2x") { showSpeedSheet() })
        box.addView(settingButton("زمان پرش", "${seekJumpMs / 1000L} ثانیه", "مقدار عقب و جلو رفتن") {
            val values = listOf(5L, 10L, 30L, 60L)
            val currentIndex = values.indexOf(seekJumpMs / 1000L).let { if (it < 0) 1 else it }
            val next = values[(currentIndex + 1) % values.size]
            seekJumpMs = next * 1000L
            UiPreferences.prefs(this).edit().putInt(UiPreferences.KEY_SEEK_SECONDS, next.toInt()).apply()
            showHud("زمان پرش: $next ثانیه")
        })
        box.addView(settingButton("پخش خودکار قسمت بعد", if (autoPlayNext) "روشن" else "خاموش", "پس از پایان قسمت، قسمت بعدی پخش شود") {
            autoPlayNext = !autoPlayNext
            showHud("پخش خودکار: ${if (autoPlayNext) "روشن" else "خاموش"}")
        })

        box.addView(settingsMiniLabel("سیستم"))
        box.addView(settingButton("دیکودر", if (hardwareDecoder) "سخت‌افزاری" else "نرم‌افزاری", "برای دستگاه‌های ضعیف حالت سخت‌افزاری بهتر است") {
            hardwareDecoder = !hardwareDecoder
            restartKeepingTime("دیکودر: ${if (hardwareDecoder) "سخت‌افزاری" else "نرم‌افزاری"}")
        })
        box.addView(settingButton("تصویر در تصویر", "فعال‌سازی", "برای اندروید 8 به بالا") { enterPipMode() })
        box.addView(settingButton("تایمر خواب", if (sleepMinutes > 0) "${sleepMinutes} دقیقه" else "خاموش", "خاموشی خودکار پلیر") { showSleepSheet() })
        box.addView(settingButton("قفل کنترل‌ها", if (controlsLocked) "قفل" else "باز", "قفل‌کردن دکمه‌ها و ژست‌ها") { toggleLock() })

        val dialog = dialogOf(scroll)
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun settingsMiniLabel(label: String): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(UiPreferences.palette(this@PlayerActivity).primary2)
            textSize = 11.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setPadding(0, dp(12), 0, dp(6))
        }
    }

    private fun settingButton(title: String, value: String, sub: String, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = playerGlassSurface(18, 232, 58)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            applyPlayerFocus(this, 17, 1.025f, 0f)
            setOnClickListener { click() }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }

            val row = LinearLayout(this@PlayerActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            row.addView(TextView(this@PlayerActivity).apply {
                text = title
                setTextColor(Color.WHITE)
                textSize = 14.2f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this@PlayerActivity).apply {
                text = value
                setTextColor(UiPreferences.palette(this@PlayerActivity).primary2)
                textSize = 12.2f
                gravity = Gravity.LEFT
                maxLines = 1
            }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(10) })
            addView(row)
            addView(TextView(this@PlayerActivity).apply {
                text = sub
                setTextColor(muted)
                textSize = 11.3f
                gravity = Gravity.RIGHT
                setPadding(0, dp(5), 0, 0)
            })
        }
    }

    private fun showSpeedSheet() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = playerGlassSurface(28, 246, 82)
            elevation = dp(9).toFloat()
        }
        box.addView(sectionTitle("سرعت پخش"))
        val value = TextView(this).apply {
            text = speedLabel()
            setTextColor(Color.WHITE)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
        }
        box.addView(value)

        val speedSeek = SeekBar(this).apply {
            max = 150
            progress = ((currentSpeed - 0.5f) * 100f).roundToInt().coerceIn(0, 150)
            progressTintList = android.content.res.ColorStateList.valueOf(UiPreferences.palette(this@PlayerActivity).primary)
            thumbTintList = android.content.res.ColorStateList.valueOf(UiPreferences.palette(this@PlayerActivity).primary2)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(95, 255, 255, 255))
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        box.addView(speedSeek, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8); bottomMargin = dp(8) })

        box.addView(TextView(this).apply {
            text = "از 0.5x تا 2.0x"
            setTextColor(Color.rgb(215, 225, 240))
            textSize = 12f
            gravity = Gravity.CENTER
        })

        speedSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(s: SeekBar?) { handler.removeCallbacks(hideRunnable) }
            override fun onStopTrackingTouch(s: SeekBar?) { hideBarsLater() }
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val sp = ((50 + progress) / 100f).coerceIn(0.5f, 2.0f)
                currentSpeed = (sp * 100f).roundToInt() / 100f
                try { player?.setRate(currentSpeed) } catch (_: Throwable) {}
                value.text = speedLabel()
            }
        })

        val dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun showAudioSubtitleSettingsSheet() {
        var localEnabled = subtitleEnabled
        var localTextColor = subtitleTextColor
        var localBgMode = subtitleBackgroundMode
        var localFontMode = subtitleFontMode
        var localScale = subtitleScale
        var localPosition = subtitlePositionIndex
        var localDelay = subtitleDelayMs
        var localAudioTrack = currentNativeTrack("getAudioTrack")
        var localSubtitleTrack = currentNativeTrack("getSpuTrack")

        val audioOptions = nativeTrackOptions("getAudioTracks").filter { it.id >= 0 }
        val subtitleOptions = nativeTrackOptions("getSpuTracks").filter { it.id >= 0 }
        if (localAudioTrack < 0) localAudioTrack = audioOptions.firstOrNull()?.id ?: -1
        if (localEnabled && localSubtitleTrack < 0) localSubtitleTrack = subtitleOptions.firstOrNull()?.id ?: -1

        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = playerGlassSurface(30, 248, 88)
            elevation = dp(10).toFloat()
        }
        scroll.addView(box)

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        head.addView(TextView(this).apply {
            text = "صدا و زیرنویس"
            setTextColor(Color.WHITE)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_player_audio)
            setColorFilter(Color.WHITE)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = playerGlassAccent(15)
        }, LinearLayout.LayoutParams(dp(42), dp(42)))
        box.addView(head, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        fun optionButton(label: String, selected: () -> Boolean, click: () -> Unit): TextView {
            lateinit var view: TextView
            view = TextView(this).apply {
                textSize = 12.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                setPadding(dp(13), 0, dp(13), 0)
                maxLines = 2
                setOnClickListener { click() }
                applyPlayerFocus(this, 17, 1.03f, 0f)
            }
            fun refresh() {
                val active = selected()
                view.text = label + if (active) "   ✓" else ""
                view.background = if (active) playerGlassAccent(16) else playerGlassSurface(16, 226, 54)
                view.setTextColor(Color.WHITE)
            }
            view.tag = Runnable { refresh() }
            refresh()
            return view
        }

        fun refreshOptions(container: LinearLayout) {
            for (i in 0 until container.childCount) {
                (container.getChildAt(i).tag as? Runnable)?.run()
            }
        }

        box.addView(settingsMiniLabel("ترک صدا"))
        val audioBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (audioOptions.isEmpty()) {
            audioBox.addView(TextView(this).apply {
                text = "ترک صدای جداگانه‌ای در این فایل پیدا نشد"
                setTextColor(muted)
                textSize = 12.5f
                gravity = Gravity.RIGHT
                setPadding(dp(12), dp(13), dp(12), dp(13))
                background = playerGlassSurface(15, 224, 52)
            })
        } else {
            audioOptions.forEach { option ->
                val button = optionButton(option.name, { localAudioTrack == option.id }) {
                    localAudioTrack = option.id
                    refreshOptions(audioBox)
                }
                audioBox.addView(button, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(7) })
            }
        }
        box.addView(audioBox)

        box.addView(settingsMiniLabel("زیرنویس"))
        val subtitleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        subtitleBox.addView(optionButton("خاموش", { !localEnabled || localSubtitleTrack < 0 }) {
            localEnabled = false
            localSubtitleTrack = -1
            refreshOptions(subtitleBox)
        }, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(7) })
        subtitleOptions.forEach { option ->
            val button = optionButton(option.name, { localEnabled && localSubtitleTrack == option.id }) {
                localEnabled = true
                localSubtitleTrack = option.id
                refreshOptions(subtitleBox)
            }
            subtitleBox.addView(button, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(7) })
        }
        if (subtitleOptions.isEmpty()) {
            subtitleBox.addView(TextView(this).apply {
                text = "زیرنویس داخلی در این فایل پیدا نشد"
                setTextColor(muted)
                textSize = 12.5f
                gravity = Gravity.RIGHT
                setPadding(dp(12), dp(13), dp(12), dp(13))
            })
        }
        box.addView(subtitleBox)

        box.addView(settingsMiniLabel("رنگ متن"))
        val colors = listOf(Color.WHITE, Color.YELLOW, Color.BLACK, Color.RED, Color.BLUE, Color.GREEN, Color.rgb(255, 193, 7))
        val colorViews = mutableListOf<TextView>()
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(0, dp(6), 0, dp(6)) }
        fun refreshColorViews() {
            colorViews.forEachIndexed { i, view ->
                view.text = if (colors[i] == localTextColor) "✓" else ""
                view.background = rounded(colors[i], dp(999), if (colors[i] == localTextColor) blue2 else Color.argb(90, 255, 255, 255))
                view.setTextColor(if (colors[i] == Color.BLACK) Color.WHITE else Color.BLACK)
            }
        }
        colors.forEachIndexed { index, color ->
            val v = TextView(this).apply {
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setOnClickListener { localTextColor = color; refreshColorViews() }
                applyPlayerFocus(this, 999, 1.08f, 0f)
            }
            colorViews.add(v)
            colorRow.addView(v, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginStart = dp(7) })
        }
        refreshColorViews()
        box.addView(android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(colorRow) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        box.addView(settingsMiniLabel("پس‌زمینه زیرنویس"))
        val bgOptions = listOf("transparent" to "شفاف", "black" to "مشکی", "white" to "سفید", "yellow" to "زرد", "red" to "قرمز", "blue" to "آبی", "pink" to "صورتی")
        val bgButtons = mutableListOf<Pair<String, TextView>>()
        val bgRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, dp(4), 0, dp(4))
        }
        fun refreshBgButtons() {
            bgButtons.forEach { (key, view) ->
                val selected = key == localBgMode
                view.background = if (selected) rounded(blue, dp(15), blue2) else rounded(Color.rgb(30, 30, 34), dp(15), Color.argb(80, 255, 255, 255))
                view.setTextColor(if (selected) UiPreferences.palette(this).onPrimary else Color.WHITE)
            }
        }
        bgOptions.forEachIndexed { index, pair ->
            val v = TextView(this).apply {
                text = pair.second
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setOnClickListener { localBgMode = pair.first; refreshBgButtons() }
                applyPlayerFocus(this, 17, 1.035f, 0f)
            }
            bgButtons.add(pair.first to v)
            bgRow.addView(v, LinearLayout.LayoutParams(dp(82), dp(43)).apply { if (index > 0) marginStart = dp(5) })
        }
        refreshBgButtons()
        box.addView(android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(bgRow)
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        box.addView(settingsMiniLabel("فونت زیرنویس"))
        val fontButtons = mutableListOf<Pair<String, TextView>>()
        val fontRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, dp(10))
        }
        fun refreshFontButtons() {
            fontButtons.forEach { (key, view) ->
                val selected = key == localFontMode
                view.background = if (selected) rounded(blue, dp(16), blue2) else rounded(Color.rgb(30, 30, 34), dp(16), Color.argb(80, 255, 255, 255))
                view.setTextColor(if (selected) UiPreferences.palette(this).onPrimary else Color.WHITE)
            }
        }
        BankmovieFonts.options.forEachIndexed { index, option ->
            val v = TextView(this).apply {
                text = option.faLabel
                textSize = 13f
                typeface = BankmovieFonts.forMode(this@PlayerActivity, option.key, true)
                gravity = Gravity.CENTER
                setOnClickListener { localFontMode = option.key; refreshFontButtons() }
                applyPlayerFocus(this, 17, 1.035f, 0f)
            }
            fontButtons += option.key to v
            fontRow.addView(v, LinearLayout.LayoutParams(dp(112), dp(46)).apply { if (index > 0) marginStart = dp(7) })
        }
        refreshFontButtons()
        box.addView(android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(fontRow)
        }, LinearLayout.LayoutParams(-1, -2))

        box.addView(settingsMiniLabel("جای زیرنویس"))
        val positionButtons = mutableListOf<Pair<Int, TextView>>()
        val positionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, dp(10))
        }
        fun refreshPositionButtons() {
            positionButtons.forEach { (index, view) ->
                val selected = index == localPosition
                view.background = if (selected) rounded(blue, dp(16), blue2) else rounded(Color.rgb(30, 30, 34), dp(16), Color.argb(80, 255, 255, 255))
                view.setTextColor(if (selected) UiPreferences.palette(this).onPrimary else Color.WHITE)
            }
        }
        subtitlePositions.forEachIndexed { index, label ->
            val v = TextView(this).apply {
                text = label
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setOnClickListener { localPosition = index; refreshPositionButtons() }
                applyPlayerFocus(this, 17, 1.035f, 0f)
            }
            positionButtons += index to v
            positionRow.addView(v, LinearLayout.LayoutParams(0, dp(46), 1f).apply { if (index > 0) marginStart = dp(7) })
        }
        refreshPositionButtons()
        box.addView(positionRow, LinearLayout.LayoutParams(-1, -2))

        box.addView(settingsMiniLabel("اندازه و هماهنگی"))
        val sizeValue = TextView(this).apply { text = "اندازه متن: $localScale%"; setTextColor(Color.WHITE); textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT }
        box.addView(sizeValue)
        val sizeSeek = SeekBar(this).apply {
            max = 90
            progress = (localScale - 80).coerceIn(0, 90)
            progressTintList = android.content.res.ColorStateList.valueOf(blue)
            thumbTintList = android.content.res.ColorStateList.valueOf(blue2)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(90, 255, 255, 255))
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        sizeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) { localScale = 80 + progress; sizeValue.text = "اندازه متن: $localScale%" }
            }
        })
        box.addView(sizeSeek, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(6) })

        val delayValue = TextView(this).apply { text = "هماهنگی زیرنویس: ${"%.1f".format(Locale.US, localDelay / 1000f)}s"; setTextColor(Color.WHITE); textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT }
        box.addView(delayValue)
        val delaySeek = SeekBar(this).apply {
            max = 200
            progress = ((localDelay + 10000) / 100).coerceIn(0, 200)
            progressTintList = android.content.res.ColorStateList.valueOf(blue)
            thumbTintList = android.content.res.ColorStateList.valueOf(blue2)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(90, 255, 255, 255))
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        delaySeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) { localDelay = progress * 100 - 10000; delayValue.text = "هماهنگی زیرنویس: ${"%.1f".format(Locale.US, localDelay / 1000f)}s" }
            }
        })
        box.addView(delaySeek, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })

        val applyButton = TextView(this).apply {
            text = "اعمال صدا و زیرنویس"
            setTextColor(UiPreferences.palette(this@PlayerActivity).onPrimary)
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = playerGlassAccent(22)
            applyPlayerFocus(this, 23, 1.035f, 0f)
        }
        box.addView(applyButton, LinearLayout.LayoutParams(-1, dp(52)))

        val dialog = dialogOf(scroll)
        applyButton.setOnClickListener {
            val styleChanged = localTextColor != subtitleTextColor || localBgMode != subtitleBackgroundMode || localFontMode != subtitleFontMode || localScale != subtitleScale || localPosition != subtitlePositionIndex || localDelay != subtitleDelayMs
            subtitleEnabled = localEnabled
            subtitleTextColor = localTextColor
            subtitleBackgroundMode = localBgMode
            subtitleFontMode = localFontMode
            subtitleScale = localScale
            subtitlePositionIndex = localPosition
            subtitleDelayMs = localDelay
            preferredAudioTrackId = localAudioTrack
            preferredSubtitleTrackId = if (localEnabled) localSubtitleTrack else -1
            UiPreferences.prefs(this).edit()
                .putBoolean(UiPreferences.KEY_SUB_ENABLED, subtitleEnabled)
                .putInt(UiPreferences.KEY_SUB_TEXT_COLOR, subtitleTextColor)
                .putString(UiPreferences.KEY_SUB_BG_MODE, subtitleBackgroundMode)
                .putString(UiPreferences.KEY_SUB_FONT, subtitleFontMode)
                .putInt(UiPreferences.KEY_SUB_SCALE, subtitleScale)
                .putInt(UiPreferences.KEY_SUB_DELAY, subtitleDelayMs)
                .putInt(UiPreferences.KEY_SUB_POSITION, subtitlePositionIndex)
                .apply()
            dialog.dismiss()
            if (styleChanged) {
                restartKeepingTime("تنظیمات صدا و زیرنویس اعمال شد")
            } else {
                applyPreferredNativeTracks()
                applySubtitleDelay()
                showHud("صدا و زیرنویس اعمال شد")
            }
        }
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun showSubtitleStyleSheet() {
        showAudioSubtitleSettingsSheet()
    }

    private fun showSleepSheet() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = playerGlassSurface(26, 244, 76)
        }
        box.addView(sectionTitle("Sleep Timer"))
        var dialog: AlertDialog? = null
        listOf(0 to "خاموش", 15 to "15 دقیقه", 30 to "30 دقیقه", 45 to "45 دقیقه", 60 to "60 دقیقه").forEach { item ->
            box.addView(sheetButton(item.second + if (sleepMinutes == item.first) "  ●" else "") {
                setSleepTimer(item.first)
                dialog?.dismiss()
            }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(4); bottomMargin = dp(4) })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
    }

    private fun speedLabel(): String = if (currentSpeed == 1.0f) "نرمال" else "${currentSpeed}x"

    private fun subtitleStyleLabel(): String {
        val colorLabel = when (subtitleTextColor) {
            Color.YELLOW -> "زرد"
            Color.BLACK -> "مشکی"
            Color.RED -> "قرمز"
            Color.BLUE -> "آبی"
            Color.GREEN -> "سبز"
            else -> "سفید"
        }
        val bgLabel = when (subtitleBackgroundMode) {
            "black" -> "پس‌زمینه مشکی"
            "white" -> "پس‌زمینه سفید"
            "yellow" -> "پس‌زمینه زرد"
            "red" -> "پس‌زمینه قرمز"
            "blue" -> "پس‌زمینه آبی"
            "pink" -> "پس‌زمینه صورتی"
            else -> "شفاف"
        }
        val fontLabel = BankmovieFonts.label(subtitleFontMode)
        return "$colorLabel • $bgLabel • $fontLabel • $subtitleScale%"
    }

    private fun applySubtitleDelay() {
        try { player?.javaClass?.getMethod("setSpuDelay", java.lang.Long.TYPE)?.invoke(player, subtitleDelayMs * 1000L) } catch (_: Throwable) {}
    }

    private fun restartKeepingTime(message: String) {
        val pos = player?.time ?: 0L
        requestedResumePosition = pos
        startPlayer(videoUrl)
        handler.postDelayed({
            try { player?.time = pos } catch (_: Throwable) {}
            showHud(message)
        }, 650)
    }

    private fun setTemporarySpeed(active: Boolean) {
        try { player?.setRate(if (active) 2.0f else currentSpeed) } catch (_: Throwable) {}
        showHud(if (active) "2X" else "سرعت پخش: ${speedLabel()}")
    }

    private fun enterPipMode(showError: Boolean = true) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val width = videoLayout.width.takeIf { it > 0 } ?: root.width.takeIf { it > 0 } ?: 16
                val height = videoLayout.height.takeIf { it > 0 } ?: root.height.takeIf { it > 0 } ?: 9
                val ratio = android.util.Rational(width.coerceAtLeast(1), height.coerceAtLeast(1))
                val builder = PictureInPictureParams.Builder()
                    .setAspectRatio(ratio)
                enterPictureInPictureMode(builder.build())
            } catch (_: Throwable) {
                if (showError) Toast.makeText(this, "Picture in Picture روی این دستگاه فعال نشد", Toast.LENGTH_SHORT).show()
            }
        } else if (showError) {
            Toast.makeText(this, "Picture in Picture برای اندروید 8 به بالا است", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setSleepTimer(minutes: Int) {
        sleepMinutes = minutes
        handler.removeCallbacks(sleepRunnable)
        if (minutes > 0) handler.postDelayed(sleepRunnable, minutes * 60_000L)
        showHud(if (minutes > 0) "خواب: ${minutes} دقیقه" else "حالت خواب خاموش شد")
    }

    private fun sectionTitle(label: String): TextView = TextView(this).apply {
        text = label
        setTextColor(white)
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 0, 0, dp(6))
    }

    private fun ensurePlayerModalDragHandle(view: View): View? {
        if (isTvLike()) return null
        val root = when (view) {
            is LinearLayout -> view
            is ScrollView -> (if (view.childCount > 0) view.getChildAt(0) else null) as? LinearLayout
            else -> null
        } ?: return null
        val first = if (root.childCount > 0) root.getChildAt(0) else null
        if (first?.tag == "bm_player_modal_drag_target") return first
        val target = FrameLayout(this).apply {
            tag = "bm_player_modal_drag_target"
            isClickable = true
            isFocusable = true
            contentDescription = "برای باز و بسته کردن پنجره بکشید"
            addView(View(this@PlayerActivity).apply {
                background = rounded(Color.argb(135, 164, 177, 198), dp(999), Color.TRANSPARENT)
            }, FrameLayout.LayoutParams(dp(62), dp(5), Gravity.CENTER))
        }
        root.addView(target, 0, LinearLayout.LayoutParams(-1, dp(34)).apply { bottomMargin = dp(2) })
        return target
    }

    private fun wirePlayerModalDrag(dialog: AlertDialog, handle: View) {
        if (isTvLike()) return
        val target = dialog.window?.decorView ?: return
        var downY = 0f
        var startY = 0f
        var moved = false
        val slop = dp(7).toFloat()
        fun snapTo(value: Float) {
            target.animate().cancel()
            target.animate().translationY(value).alpha(1f).setDuration(260L)
                .setInterpolator(android.view.animation.DecelerateInterpolator(1.7f)).start()
        }
        handle.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = event.rawY
                    startY = target.translationY
                    moved = false
                    target.animate().cancel()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val delta = event.rawY - downY
                    if (kotlin.math.abs(delta) > slop) moved = true
                    val maxY = (target.height * 0.72f).coerceAtLeast(dp(120).toFloat())
                    target.translationY = (startY + delta).coerceIn(0f, maxY)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val height = target.height.coerceAtLeast(dp(260)).toFloat()
                    val current = target.translationY
                    val collapsed = height * 0.42f
                    if (!moved && event.actionMasked == MotionEvent.ACTION_UP) {
                        snapTo(if (current > height * 0.18f) 0f else collapsed)
                    } else if (current > height * 0.64f) {
                        target.animate().cancel()
                        target.animate().translationY(height).alpha(0.82f).setDuration(190L).withEndAction {
                            if (dialog.isShowing) dialog.dismiss()
                        }.start()
                    } else if (current > height * 0.20f) {
                        snapTo(collapsed)
                    } else snapTo(0f)
                    true
                }
                else -> false
            }
        }
    }

    private fun dialogOf(view: View): AlertDialog {
        val mobileDragHandle = ensurePlayerModalDragHandle(view)
        return AlertDialog.Builder(this).setView(view).create().also { dialog ->
            dialog.setOnShowListener {
                val win = dialog.window
                win?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                win?.setDimAmount(0.62f)
                win?.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                val screenWidth = resources.displayMetrics.widthPixels
                val preferredWidth = if (isTvLike()) min(screenWidth - dp(80), dp(760)) else min(screenWidth - dp(24), dp(620))
                win?.setLayout(preferredWidth, android.view.WindowManager.LayoutParams.WRAP_CONTENT)
                if (!isTvLike()) {
                    win?.let { window ->
                        window.setGravity(Gravity.BOTTOM)
                        val attrs = window.attributes
                        attrs.y = dp(10)
                        window.attributes = attrs
                    }
                }
                val decor = win?.decorView
                decor?.animate()?.cancel()
                if (decor != null) {
                    decor.alpha = 0f
                    decor.scaleX = 0.97f
                    decor.scaleY = 0.97f
                    decor.translationY = dp(10).toFloat()
                    decor.animate()
                        .alpha(1f)
                        .scaleX(1f)
                        .scaleY(1f)
                        .translationY(0f)
                        .setDuration(180L)
                        .setInterpolator(android.view.animation.DecelerateInterpolator())
                        .start()
                }
                if (!isTvLike() && mobileDragHandle != null) {
                    view.post { wirePlayerModalDrag(dialog, mobileDragHandle) }
                }
                applyPlayerFocusTree(view)
                view.postDelayed({
                    fun first(v: View): Boolean {
                        if (v.isFocusable && v.isEnabled && v.visibility == View.VISIBLE && v.hasOnClickListeners()) {
                            v.requestFocus()
                            return true
                        }
                        if (v is android.view.ViewGroup) {
                            for (i in 0 until v.childCount) if (first(v.getChildAt(i))) return true
                        }
                        return false
                    }
                    first(view)
                }, 95L)
            }
        }
    }

    private fun sheetButton(label: String, click: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(white)
            textSize = 14f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = playerGlassSurface(16, 228, 62)
            applyPlayerFocus(this, 18, 1.035f, 0f)
            setOnClickListener { click() }
        }
    }

    private fun toggle() {
        if (partyGuestPlaybackLocked()) {
            showGuestPlaybackLockedNotice()
            return
        }
        val p = player ?: return
        if (p.isPlaying) p.pause() else p.play()
        playIcon.setImageResource(if (p.isPlaying) R.drawable.ic_player_pause else R.drawable.ic_player_play)
        if (partyActive && partyIsHost) sendWatchPartyControl(if (p.isPlaying) "play" else "pause")
        hideBarsLater()
    }

    private fun seekBy(delta: Long) {
        if (partyGuestPlaybackLocked()) {
            showGuestPlaybackLockedNotice()
            return
        }
        val p = player ?: return
        val len = p.length
        p.time = if (len > 0) min(max(p.time + delta, 0L), len) else max(p.time + delta, 0L)
        if (partyActive && partyIsHost) sendWatchPartyControl("seek")
        updateProgress()
        hideBarsLater()
    }

    private fun nextEpisodeIndex(): Int {
        val current = tracks.getOrNull(currentIndex) ?: return -1
        if (current.episode <= 0 && current.season <= 0) return -1
        val candidates = tracks.withIndex().filter { (_, track) ->
            track.episode > 0 && (
                track.season > current.season ||
                    (track.season == current.season && track.episode > current.episode)
                )
        }
        if (candidates.isEmpty()) return -1
        val targetPair = candidates.minWithOrNull(
            compareBy<IndexedValue<Track>> { it.value.season }
                .thenBy { it.value.episode }
        ) ?: return -1
        val sameEpisode = candidates.filter {
            it.value.season == targetPair.value.season && it.value.episode == targetPair.value.episode
        }
        return (sameEpisode.firstOrNull {
            it.value.quality.equals(current.quality, true) && isSubtitle(it.value) == isSubtitle(current)
        } ?: sameEpisode.firstOrNull {
            isSubtitle(it.value) == isSubtitle(current) && isAudioOnly(it.value) == isAudioOnly(current)
        } ?: sameEpisode.first()).index
    }

    private fun nextEpisodeTitle(index: Int): String {
        val target = tracks.getOrNull(index) ?: return "قسمت بعدی"
        return if (target.season > 0) "فصل ${target.season} • قسمت ${target.episode}" else "قسمت ${target.episode}"
    }

    private fun maybePromptNextEpisode(time: Long, length: Long) {
        if (!autoPlayNext || length <= 0L || time <= 0L) return
        val nextIndex = nextEpisodeIndex()
        if (nextIndex < 0) return
        val current = tracks.getOrNull(currentIndex) ?: return
        val key = "${current.season}:${current.episode}:${current.url}"
        if (nextPromptShownKey == key || time.toDouble() / length.toDouble() < 0.95) return
        nextPromptShownKey = key
        skipNextOnce = false
        nextPromptDialog?.dismiss()
        val accent = blue
        val accentSoft = UiPreferences.blend(accent, Color.WHITE, 0.18f)
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(22), dp(20), dp(22), dp(20))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                UiPreferences.blend(Color.rgb(18, 20, 25), accent, 0.10f),
                Color.rgb(20, 21, 25),
                Color.rgb(13, 15, 20)
            )).apply {
                cornerRadius = dp(26).toFloat()
                setStroke(dp(1), Color.argb(145, Color.red(accent), Color.green(accent), Color.blue(accent)))
            }
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(accent)
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(R.drawable.ic_play_fill)
                setColorFilter(Color.WHITE)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                setPadding(dp(12), dp(12), dp(12), dp(12))
            }, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(14) })
        head.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            addView(TextView(this@PlayerActivity).apply {
                text = "قسمت بعدی آماده است"
                setTextColor(Color.WHITE)
                textSize = if (isTvLike()) 19f else 17f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            })
            addView(TextView(this@PlayerActivity).apply {
                text = "${nextEpisodeTitle(nextIndex)} پخش شود؟"
                setTextColor(Color.rgb(176, 188, 207))
                textSize = if (isTvLike()) 13.5f else 12.5f
                gravity = Gravity.RIGHT
                setPadding(0, dp(7), 0, 0)
            })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        shell.addView(head, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(20) })

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        lateinit var dialog: AlertDialog
        val playNextButton = TextView(this).apply {
            text = "▶  بله، پخش کن"
            setTextColor(UiPreferences.palette(this@PlayerActivity).onPrimary)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(accentSoft, accent)).apply {
                cornerRadius = dp(17).toFloat()
            }
            isClickable = true
            isFocusable = true
            setOnClickListener {
                skipNextOnce = false
                dialog.dismiss()
                switchTo(nextIndex)
            }
        }
        val cancelButton = TextView(this).apply {
            text = "لغو"
            setTextColor(Color.rgb(220, 226, 236))
            textSize = 13.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.argb(235, 28, 38, 53), dp(17), Color.argb(78, 255, 255, 255))
            isClickable = true
            isFocusable = true
            setOnClickListener {
                skipNextOnce = true
                dialog.dismiss()
                showHud("در همین قسمت می‌مانیم")
            }
        }
        actions.addView(playNextButton, LinearLayout.LayoutParams(0, dp(56), 1.22f).apply { marginEnd = dp(6) })
        actions.addView(cancelButton, LinearLayout.LayoutParams(0, dp(56), 0.88f).apply { marginStart = dp(6) })
        shell.addView(actions, LinearLayout.LayoutParams(-1, -2))

        dialog = AlertDialog.Builder(this).setView(shell).setCancelable(true).create()
        nextPromptDialog = dialog
        dialog.setOnDismissListener { if (nextPromptDialog === dialog) nextPromptDialog = null }
        dialog.setOnShowListener {
            dialog.window?.let { win ->
                win.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                win.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                win.setDimAmount(0.54f)
                val width = if (isTvLike()) dp(540) else min(resources.displayMetrics.widthPixels - dp(28), dp(520))
                win.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT)
                win.setGravity(Gravity.CENTER)
            }
            playNextButton.requestFocus()
        }
        dialog.show()
    }

    private fun playNext() {
        if (!autoPlayNext || skipNextOnce) {
            playIcon.setImageResource(R.drawable.ic_player_play)
            return
        }
        val next = nextEpisodeIndex()
        if (next >= 0 && nextPromptDialog == null) maybePromptNextEpisode(player?.time ?: 0L, player?.length ?: 0L)
    }

    private fun nextMode() {
        modeIndex = (modeIndex + 1) % modes.size
        applyMode()
        showHud("حالت تصویر: ${modeTitles[modeIndex]}")
        hideBarsLater()
    }

    private fun applyMode() {
        val mp = player ?: return
        when (modes[modeIndex]) {
            "FIT" -> { setAspect(mp, null); setScale(mp, 0f) }
            "CROP" -> { setAspect(mp, null); setScale(mp, 1.2f) }
            "STRETCH" -> {
                videoLayout.post {
                    val w = max(root.width, resources.displayMetrics.widthPixels)
                    val h = max(root.height, resources.displayMetrics.heightPixels)
                    setAspect(mp, "$w:$h")
                    setScale(mp, 0f)
                }
            }
        }
    }

    private fun toggleLock() {
        controlsLocked = !controlsLocked
        updateLockUi()
        if (controlsLocked) {
            topBar.visibility = View.GONE
            bottomBar.visibility = View.GONE
            centerControls.visibility = View.GONE
            unlockOverlay.visibility = View.VISIBLE
            controlsVisible = false
            showHud("قفل شد")
        } else {
            unlockOverlay.visibility = View.GONE
            showControls()
            showHud("قفل باز شد")
            focusPlayButton()
        }
    }

    private fun updateLockUi() {
        lockIcon.setImageResource(if (controlsLocked) R.drawable.ic_player_unlock else R.drawable.ic_player_lock)
        if (::unlockOverlay.isInitialized) {
            unlockOverlay.visibility = if (controlsLocked) View.VISIBLE else View.GONE
        }
    }

    private fun showControls() {
        if (controlsLocked) return
        controlsVisible = true
        topBar.visibility = View.VISIBLE
        bottomBar.visibility = View.VISIBLE
        centerControls.visibility = View.VISIBLE
        if (partyActive) showPartyChrome()
        hideBarsLater()
    }

    private fun hideControls() {
        if (controlsLocked) return
        controlsVisible = false
        topBar.visibility = View.GONE
        bottomBar.visibility = View.GONE
        centerControls.visibility = View.GONE
    }

    private fun hideBarsLater() {
        handler.removeCallbacks(hideRunnable)
        if (!controlsLocked) handler.postDelayed(hideRunnable, 3500)
    }

    private fun showHud(msg: String) {
        hudBox.text = msg
        hudBox.visibility = View.VISIBLE
        handler.removeCallbacks(hudHideRunnable)
        handler.postDelayed(hudHideRunnable, 1100)
    }

    private fun playerGestureRailSurface(): GradientDrawable {
        return GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                Color.argb(188, 43, 45, 43),
                Color.argb(208, 24, 26, 25)
            )
        ).apply {
            cornerRadius = dp(24).toFloat()
            setStroke(dp(1), Color.argb(82, 255, 255, 255))
        }
    }

    private fun currentGestureVolumePercent(): Float {
        val maxVol = audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val systemVol = audioManager.getStreamVolume(android.media.AudioManager.STREAM_MUSIC).coerceIn(0, maxVol)
        return if (systemVol >= maxVol && currentVlcVolumePercent > 100) {
            currentVlcVolumePercent.toFloat().coerceAtMost(VOLUME_BOOST_MAX_PERCENT)
        } else {
            (systemVol.toFloat() / maxVol.toFloat() * 100f).coerceIn(0f, 100f)
        }
    }

    private fun applyVlcAmplification(percent: Int) {
        val safe = percent.coerceIn(0, VOLUME_BOOST_MAX_PERCENT.roundToInt())
        if (currentVlcVolumePercent == safe) return
        currentVlcVolumePercent = safe
        runCatching {
            val target = player ?: return@runCatching
            target.javaClass.getMethod("setVolume", Integer.TYPE).invoke(target, safe)
        }
    }

    private fun applyGestureVolumePercent(value: Float) {
        val percent = value.coerceIn(0f, VOLUME_BOOST_MAX_PERCENT)
        gestureVolumePercent = percent
        val maxVol = audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        if (percent <= 100f) {
            val targetVol = (percent / 100f * maxVol.toFloat()).roundToInt().coerceIn(0, maxVol)
            if (targetVol != audioManager.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)) {
                audioManager.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, targetVol, 0)
            }
            applyVlcAmplification(100)
        } else {
            if (audioManager.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) != maxVol) {
                audioManager.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, maxVol, 0)
            }
            applyVlcAmplification(percent.roundToInt())
        }
    }

    private fun showVolumeGestureHud(percentValue: Float) {
        if (!::volumeGestureHud.isInitialized) return
        if (::brightnessGestureHud.isInitialized && brightnessGestureHud.visibility == View.VISIBLE) {
            handler.removeCallbacks(brightnessGestureHideRunnable)
            brightnessGestureHud.animate().cancel()
            brightnessGestureHud.visibility = View.GONE
            brightnessGestureHud.alpha = 0f
            brightnessGestureHud.translationX = dp(6).toFloat()
        }
        val percent = percentValue.coerceIn(0f, VOLUME_BOOST_MAX_PERCENT)
        // Boost-aware scale: 100% is the middle of the bar, 200% is full.
        val trackRatio = (percent / VOLUME_BOOST_MAX_PERCENT).coerceIn(0f, 1f)
        volumeGesturePercent.text = "${percent.roundToInt()}%"
        volumeGestureIcon.alpha = if (percent <= 0.5f) 0.48f else 1f
        volumeGestureLevel.scaleY = trackRatio
        if (volumeGestureHud.visibility != View.VISIBLE) {
            volumeGestureHud.animate().cancel()
            volumeGestureHud.visibility = View.VISIBLE
            volumeGestureHud.alpha = 0f
            volumeGestureHud.translationX = (-dp(6)).toFloat()
            volumeGestureHud.animate()
                .alpha(1f)
                .translationX(0f)
                .setDuration(95L)
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        }
        handler.removeCallbacks(volumeGestureHideRunnable)
        handler.postDelayed(volumeGestureHideRunnable, 900L)
    }

    private fun showBrightnessGestureHud(brightness: Float) {
        if (!::brightnessGestureHud.isInitialized) return
        if (::volumeGestureHud.isInitialized && volumeGestureHud.visibility == View.VISIBLE) {
            handler.removeCallbacks(volumeGestureHideRunnable)
            volumeGestureHud.animate().cancel()
            volumeGestureHud.visibility = View.GONE
            volumeGestureHud.alpha = 0f
            volumeGestureHud.translationX = (-dp(6)).toFloat()
        }
        val ratio = brightness.coerceIn(0.05f, 1f)
        brightnessGesturePercent.text = "${(ratio * 100f).roundToInt()}%"
        brightnessGestureLevel.scaleY = ratio
        if (brightnessGestureHud.visibility != View.VISIBLE) {
            brightnessGestureHud.animate().cancel()
            brightnessGestureHud.visibility = View.VISIBLE
            brightnessGestureHud.alpha = 0f
            brightnessGestureHud.translationX = dp(6).toFloat()
            brightnessGestureHud.animate()
                .alpha(1f)
                .translationX(0f)
                .setDuration(95L)
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        }
        handler.removeCallbacks(brightnessGestureHideRunnable)
        handler.postDelayed(brightnessGestureHideRunnable, 900L)
    }

    private fun handleVideoTouch(e: MotionEvent): Boolean {
        if (controlsLocked && e.action != MotionEvent.ACTION_UP) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touchStartX = e.x
                touchStartRawY = e.rawY
                lastGestureRawY = e.rawY
                gestureVolumePercent = currentGestureVolumePercent()
                gestureMode = 0
                longPress2x = false
                handler.removeCallbacks(longPressRunnable)
                if (!partyGuestPlaybackLocked()) handler.postDelayed(longPressRunnable, 480)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - touchStartX
                val totalRawDy = e.rawY - touchStartRawY
                if (gestureMode == 0 && abs(totalRawDy) > abs(dx) && abs(totalRawDy) > dp(14)) {
                    handler.removeCallbacks(longPressRunnable)
                    // Left lane = volume, right lane = brightness. Use raw screen Y
                    // because some landscape device/view combinations report local
                    // coordinates in a transformed direction.
                    gestureMode = if (partyGuestPlaybackLocked()) 2 else if (touchStartX < root.width / 2f) 2 else 1
                    lastGestureRawY = e.rawY
                    return true
                }

                // This is intentionally incremental and explicit:
                // finger moves UP => rawY gets smaller => stepUpPx is POSITIVE.
                // finger moves DOWN => rawY gets larger => stepUpPx is NEGATIVE.
                val stepUpPx = lastGestureRawY - e.rawY
                lastGestureRawY = e.rawY

                if (gestureMode == 1) {
                    val stepRatio = (stepUpPx / root.height) * 1.42f
                    val nextBrightness = (currentBrightness + stepRatio).coerceIn(0.05f, 1f)
                    currentBrightness = nextBrightness
                    if (lastAppliedBrightness < 0f || abs(nextBrightness - lastAppliedBrightness) >= 0.003f) {
                        val lp = window.attributes
                        lp.screenBrightness = nextBrightness
                        window.attributes = lp
                        lastAppliedBrightness = nextBrightness
                    }
                    showBrightnessGestureHud(nextBrightness)
                    return true
                } else if (gestureMode == 2) {
                    // Logical 0–200% VLC-style range. Up always adds, down always subtracts.
                    val stepPercent = (stepUpPx / root.height) * 205f
                    val nextPercent = (gestureVolumePercent + stepPercent).coerceIn(0f, VOLUME_BOOST_MAX_PERCENT)
                    applyGestureVolumePercent(nextPercent)
                    showVolumeGestureHud(nextPercent)
                    return true
                }
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longPressRunnable)
                if (longPress2x) {
                    longPress2x = false
                    setTemporarySpeed(false)
                    hideBarsLater()
                    return true
                }
                if (controlsLocked) {
                    unlockOverlay.visibility = View.VISIBLE
                    return true
                }
                if (gestureMode != 0) {
                    hideBarsLater()
                    return true
                }
                val now = System.currentTimeMillis()
                if (now - lastTap < 280) {
                    if (partyGuestPlaybackLocked()) {
                        showGuestPlaybackLockedNotice()
                    } else {
                        if (e.x < root.width / 2f) seekBy(-10000) else seekBy(10000)
                    }
                    lastTap = 0L
                } else {
                    lastTap = now
                    handler.postDelayed({
                        if (System.currentTimeMillis() - lastTap >= 260) {
                            val partyHidden = partyActive && (partyDock?.visibility != View.VISIBLE || partyStatusChip?.visibility != View.VISIBLE)
                            if (partyHidden) {
                                showControls()
                                showPartyChrome()
                            } else if (controlsVisible) {
                                hideControls()
                                if (partyActive) showPartyChrome()
                            } else {
                                showControls()
                                if (partyActive) showPartyChrome()
                            }
                        }
                    }, 270)
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longPressRunnable)
                if (longPress2x) {
                    longPress2x = false
                    setTemporarySpeed(false)
                }
            }
        }
        return true
    }

    private fun savePlaybackProgress(force: Boolean = false) {
        if (videoUrl.isBlank()) return
        val now = System.currentTimeMillis()
        if (!force && now - lastProgressSaveAt < 8000L) return
        lastProgressSaveAt = now
        try {
            val p = player
            val stableKey = progressKey.ifBlank { "progress_$videoUrl" }
            val prefs = getSharedPreferences("bm_smart_cinema", MODE_PRIVATE)
            // If the retained native player has already been released while the app
            // is backgrounded, never overwrite the last valid position with zero.
            val savedTime = (p?.time ?: max(lifecyclePosition, requestedResumePosition)).coerceAtLeast(0L)
            val duration = (p?.length ?: prefs.getLong("${stableKey}_duration", 0L)).coerceAtLeast(0L)
            prefs.edit()
                .putLong(stableKey, savedTime)
                .putLong("progress_$videoUrl", savedTime)
                .putLong("${stableKey}_duration", duration)
                .putLong("progress_${videoUrl}_duration", duration)
                .apply()
        } catch (_: Throwable) {}
    }

    private fun updateProgress() {
        val p = player ?: return
        val len = p.length
        var time = p.time
        if (resumeTarget > 15000L && System.currentTimeMillis() < resumeGuardUntil) {
            if (time < resumeTarget - 5000L) {
                try { p.time = resumeTarget } catch (_: Throwable) {}
                time = p.time
            } else {
                resumeTarget = 0L
            }
        }
        if (len > 0) seek.progress = ((time * 1000L) / len).toInt().coerceIn(0, 1000)
        if (len > 0L) maybePromptNextEpisode(time, len)
        currentTimeText.text = fmt(time)
        totalTimeText.text = if (len > 0) fmt(len) else "--:--"
        savePlaybackProgress(false)
    }

    private fun fmt(ms: Long): String {
        if (ms <= 0) return "00:00"
        val total = ms / 1000L
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%02d:%02d", m, s)
    }

    private fun setAspect(mp: MediaPlayer, ratio: String?) {
        try { mp.javaClass.getMethod("setAspectRatio", String::class.java).invoke(mp, ratio) } catch (_: Throwable) {}
    }

    private fun setScale(mp: MediaPlayer, scale: Float) {
        try { mp.javaClass.getMethod("setScale", java.lang.Float.TYPE).invoke(mp, scale) } catch (_: Throwable) {}
    }

    private fun rounded(color: Int, radius: Int, strokeColor: Int): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            if (strokeColor != Color.TRANSPARENT) setStroke(dp(1), strokeColor)
        }
    }

    private fun enterImmersive() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
    }

    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (event.action != android.view.KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        val key = event.keyCode

        if (partyGuestPlaybackLocked()) {
            val playbackKey = key == android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE ||
                key == android.view.KeyEvent.KEYCODE_MEDIA_PLAY ||
                key == android.view.KeyEvent.KEYCODE_MEDIA_PAUSE ||
                key == android.view.KeyEvent.KEYCODE_MEDIA_REWIND ||
                key == android.view.KeyEvent.KEYCODE_MEDIA_FAST_FORWARD ||
                key == android.view.KeyEvent.KEYCODE_MEDIA_NEXT ||
                key == android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS ||
                key == android.view.KeyEvent.KEYCODE_MENU ||
                key == android.view.KeyEvent.KEYCODE_SETTINGS ||
                key == android.view.KeyEvent.KEYCODE_CAPTIONS ||
                key == android.view.KeyEvent.KEYCODE_C
            if (playbackKey) {
                showGuestPlaybackLockedNotice()
                return true
            }
            val focus = currentFocus
            if ((key == android.view.KeyEvent.KEYCODE_DPAD_LEFT || key == android.view.KeyEvent.KEYCODE_DPAD_RIGHT) &&
                (focus == null || focus == root || focus == videoLayout || focus == seek)) {
                showControls()
                showGuestPlaybackLockedNotice()
                return true
            }
            if ((key == android.view.KeyEvent.KEYCODE_DPAD_CENTER || key == android.view.KeyEvent.KEYCODE_ENTER ||
                    key == android.view.KeyEvent.KEYCODE_NUMPAD_ENTER || key == android.view.KeyEvent.KEYCODE_SPACE) &&
                (focus == null || focus == root || focus == videoLayout || focus == seek || focus == playButtonBox)) {
                showControls()
                showGuestPlaybackLockedNotice()
                return true
            }
        }

        fun focusLooksLikePlayerChrome(): Boolean {
            val f = currentFocus ?: return false
            return f != root && f != videoLayout
        }

        when (key) {
            android.view.KeyEvent.KEYCODE_BACK -> {
                if (controlsLocked) {
                    controlsLocked = false
                    unlockOverlay.visibility = View.GONE
                    showControls()
                    updateLockUi()
                    showHud("قفل باز شد")
                    focusPlayButton()
                    return true
                }
                if (controlsVisible) {
                    hideControls()
                    return true
                }
                finish()
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_CENTER,
            android.view.KeyEvent.KEYCODE_ENTER,
            android.view.KeyEvent.KEYCODE_NUMPAD_ENTER,
            android.view.KeyEvent.KEYCODE_SPACE,
            android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
            android.view.KeyEvent.KEYCODE_MEDIA_PLAY,
            android.view.KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                if (controlsLocked) {
                    controlsLocked = false
                    unlockOverlay.visibility = View.GONE
                    showControls()
                    updateLockUi()
                    showHud("قفل باز شد")
                    focusPlayButton()
                    return true
                }

                if (!controlsVisible) {
                    showControls()
                    focusPlayButton()
                    return true
                }

                val f = currentFocus
                if (f != null && f != root && f != videoLayout && f != seek) {
                    return super.dispatchKeyEvent(event)
                }

                toggle()
                showControls()
                focusPlayButton()
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (controlsLocked) return true
                showControls()
                if (currentFocus == seek) {
                    seekBy(-300000)
                    showHud("۵ دقیقه عقب")
                    seek.requestFocus()
                    return true
                }
                if (!controlsVisible || !focusLooksLikePlayerChrome()) {
                    seekBy(-seekJumpMs)
                    showHud("${seekJumpMs / 1000L} ثانیه عقب")
                    focusPlayButton()
                    return true
                }
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (controlsLocked) return true
                showControls()
                if (currentFocus == seek) {
                    seekBy(300000)
                    showHud("۵ دقیقه جلو")
                    seek.requestFocus()
                    return true
                }
                if (!controlsVisible || !focusLooksLikePlayerChrome()) {
                    seekBy(seekJumpMs)
                    showHud("${seekJumpMs / 1000L} ثانیه جلو")
                    focusPlayButton()
                    return true
                }
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_MEDIA_REWIND -> {
                if (!controlsLocked) {
                    showControls()
                    seekBy(-30000)
                    showHud("۳۰ ثانیه عقب")
                    if (currentFocus == seek) seek.requestFocus()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                if (!controlsLocked) {
                    showControls()
                    seekBy(30000)
                    showHud("۳۰ ثانیه جلو")
                    if (currentFocus == seek) seek.requestFocus()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_UP -> {
                if (controlsLocked) return true
                showControls()
                if (!focusLooksLikePlayerChrome()) focusPlayButton()
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (controlsLocked) return true
                showControls()
                if (!focusLooksLikePlayerChrome()) {
                    seek.requestFocus()
                    hideBarsLater()
                    return true
                }
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_MENU,
            android.view.KeyEvent.KEYCODE_SETTINGS -> {
                if (!controlsLocked) {
                    showControls()
                    showSettingsSheet()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_CAPTIONS,
            android.view.KeyEvent.KEYCODE_C -> {
                if (!controlsLocked) {
                    showControls()
                    showSubtitleStyleSheet()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_MEDIA_NEXT -> {
                if (currentIndex + 1 < tracks.size) switchTo(currentIndex + 1)
                return true
            }

            android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                if (currentIndex - 1 >= 0) switchTo(currentIndex - 1)
                return true
            }
        }

        return super.dispatchKeyEvent(event)
    }

    private fun findLargestVideoSurface(view: View): SurfaceView? {
        var best: SurfaceView? = if (view is SurfaceView) view else null
        var bestArea = if (best != null) best.width.toLong() * best.height.toLong() else -1L
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                val candidate = findLargestVideoSurface(view.getChildAt(i)) ?: continue
                val area = candidate.width.toLong() * candidate.height.toLong()
                if (area > bestArea) {
                    best = candidate
                    bestArea = area
                }
            }
        }
        return best
    }

    private fun captureLifecycleVideoFrame(force: Boolean = false) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N || !::videoLayout.isInitialized) return
        val now = System.currentTimeMillis()
        if (lifecycleFrameCapturePending) return
        if (!force && lifecycleFrameBitmap != null && now - lifecycleFrameLastCaptureAt < 450L) return
        val surface = findLargestVideoSurface(videoLayout) ?: return
        val sourceW = surface.width
        val sourceH = surface.height
        if (sourceW < 2 || sourceH < 2 || !surface.isShown) return

        // Cap the held frame to ~720p/1280px width. It is visible for only the short
        // surface restoration window and should not cost tens of MB on 4K devices.
        val scale = min(1f, 1280f / sourceW.toFloat())
        val targetW = max(2, (sourceW * scale).roundToInt())
        val targetH = max(2, (sourceH * scale).roundToInt())
        val bitmap = runCatching { Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888) }.getOrNull() ?: return
        val generation = ++lifecycleFrameCaptureGeneration
        lifecycleFrameCapturePending = true
        try {
            PixelCopy.request(surface, bitmap, { result ->
                if (generation == lifecycleFrameCaptureGeneration) lifecycleFrameCapturePending = false
                if (result == PixelCopy.SUCCESS && generation == lifecycleFrameCaptureGeneration) {
                    val previous = lifecycleFrameBitmap
                    lifecycleFrameBitmap = bitmap
                    lifecycleFrameLastCaptureAt = System.currentTimeMillis()
                    if (lifecycleRestorePending || lifecycleFrameAwaitingVideo) {
                        showLifecycleFrameOverlay()
                    }
                    if (previous !== bitmap) runCatching { previous?.recycle() }
                } else {
                    runCatching { bitmap.recycle() }
                }
            }, handler)
        } catch (_: Throwable) {
            lifecycleFrameCapturePending = false
            runCatching { bitmap.recycle() }
        }
    }

    private fun sampledFrameLooksRendered(bitmap: Bitmap): Boolean {
        if (bitmap.width < 2 || bitmap.height < 2) return false
        var samples = 0
        var visible = 0
        var minLuma = 255
        var maxLuma = 0
        val cols = 12
        val rows = 7
        for (gy in 0 until rows) {
            val y = ((gy + 0.5f) * bitmap.height / rows).toInt().coerceIn(0, bitmap.height - 1)
            for (gx in 0 until cols) {
                val x = ((gx + 0.5f) * bitmap.width / cols).toInt().coerceIn(0, bitmap.width - 1)
                val c = bitmap.getPixel(x, y)
                if (Color.alpha(c) < 16) continue
                val luma = (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10
                samples++
                minLuma = min(minLuma, luma)
                maxLuma = max(maxLuma, luma)
                if (luma >= 10) visible++
            }
        }
        if (samples == 0) return false
        // A newly attached SurfaceView is normally uniform #000000. Real dark movie
        // frames still contain either a few lit pixels or measurable luma variance.
        return visible >= max(3, samples / 14) || (maxLuma >= 14 && maxLuma - minLuma >= 8)
    }

    private fun startLifecycleFrameReadyProbe() {
        if (!lifecycleFrameAwaitingVideo || Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return
        if (lifecycleFrameProbeStartedAt == 0L) {
            lifecycleFrameProbeStartedAt = System.currentTimeMillis()
            lifecycleFrameProbeReadySamples = 0
            lifecycleFrameProbeGeneration += 1
        }
        scheduleLifecycleFrameProbe(lifecycleFrameProbeGeneration)
    }

    private fun scheduleLifecycleFrameProbe(generation: Int, delayMs: Long = PLAYER_FRAME_PROBE_INTERVAL_MS) {
        if (lifecycleFrameProbePending) return
        lifecycleFrameProbePending = true
        handler.postDelayed({
            lifecycleFrameProbePending = false
            if (generation == lifecycleFrameProbeGeneration && lifecycleFrameAwaitingVideo) {
                probeLifecycleVideoSurface(generation)
            }
        }, delayMs)
    }

    private fun probeLifecycleVideoSurface(generation: Int) {
        if (generation != lifecycleFrameProbeGeneration || !lifecycleFrameAwaitingVideo) return
        val elapsed = System.currentTimeMillis() - lifecycleFrameProbeStartedAt
        if (elapsed >= PLAYER_FRAME_PROBE_TIMEOUT_MS) {
            // Safety valve: never pin a stale frame forever if the stream is actually
            // audio-only/broken. Normal HOME restores are confirmed well before this.
            hideLifecycleFrameOverlay()
            return
        }
        val surface = if (::videoLayout.isInitialized) findLargestVideoSurface(videoLayout) else null
        if (surface == null || surface.width < 2 || surface.height < 2 || !surface.isShown) {
            scheduleLifecycleFrameProbe(generation)
            return
        }
        val probe = runCatching { Bitmap.createBitmap(96, 54, Bitmap.Config.ARGB_8888) }.getOrNull() ?: run {
            scheduleLifecycleFrameProbe(generation, 220L)
            return
        }
        try {
            lifecycleFrameProbePending = true
            PixelCopy.request(surface, probe, { result ->
                lifecycleFrameProbePending = false
                if (generation != lifecycleFrameProbeGeneration || !lifecycleFrameAwaitingVideo) {
                    runCatching { probe.recycle() }
                } else {
                    val rendered = result == PixelCopy.SUCCESS && sampledFrameLooksRendered(probe)
                    runCatching { probe.recycle() }
                    lifecycleFrameProbeReadySamples = if (rendered) lifecycleFrameProbeReadySamples + 1 else 0
                    if (lifecycleFrameProbeReadySamples >= 2) {
                        hideLifecycleFrameOverlay()
                    } else {
                        scheduleLifecycleFrameProbe(generation)
                    }
                }
            }, handler)
        } catch (_: Throwable) {
            lifecycleFrameProbePending = false
            runCatching { probe.recycle() }
            scheduleLifecycleFrameProbe(generation, 220L)
        }
    }

    private fun showLifecycleFrameOverlay() {
        val bitmap = lifecycleFrameBitmap ?: return
        if (!::lifecycleFrameOverlay.isInitialized || bitmap.isRecycled) return
        lifecycleFrameOverlay.setImageBitmap(bitmap)
        lifecycleFrameOverlay.alpha = 1f
        lifecycleFrameOverlay.visibility = View.VISIBLE
    }

    private fun hideLifecycleFrameOverlay() {
        if (!lifecycleFrameAwaitingVideo) return
        lifecycleFrameAwaitingVideo = false
        lifecycleFrameVoutSeen = false
        lifecycleFrameProbeGeneration += 1
        lifecycleFrameProbeStartedAt = 0L
        lifecycleFrameProbeReadySamples = 0
        lifecycleFrameProbePending = false
        if (::lifecycleFrameOverlay.isInitialized) lifecycleFrameOverlay.visibility = View.GONE
        if (pauseAfterLifecycleRestore) {
            pauseAfterLifecycleRestore = false
            handler.post { runCatching { player?.pause() } }
        }
    }

    private fun detachRetainedViewsForBackground() {
        if (!lifecycleRestorePending) return
        val current = player ?: return
        if (lifecycleViewsDetached) return
        runCatching {
            current.detachViews()
            lifecycleViewsDetached = true
        }
    }

    override fun onResume() {
        super.onResume()
        enterImmersive()
        handler.removeCallbacks(releaseRetainedPlayerRunnable)

        // V7.44.8 — while the hard lobby gate is active there is intentionally
        // no player to restore. A Share/chooser round-trip must never bootstrap a
        // hidden VLC instance behind the lobby.
        if (partyActive && !partyReadyConfirmed && partyRoomCode.isNotBlank()) {
            lifecycleRestorePending = false
            lifecycleWasPlaying = false
            lifecyclePosition = 0L
            lifecyclePausedAt = 0L
            if (partyLobbyDialog?.isShowing != true) {
                handler.post {
                    if (partyActive && !partyReadyConfirmed && partyLobbyDialog?.isShowing != true && !isFinishing && !isDestroyed) {
                        showWatchPartyLobby()
                    }
                }
            }
            return
        }

        if (!lifecycleRestorePending || videoUrl.isBlank()) return

        lifecycleFrameAwaitingVideo = lifecycleFrameBitmap != null
        lifecycleFrameVoutSeen = false
        lifecycleFrameProbeStartedAt = 0L
        lifecycleFrameProbeReadySamples = 0
        lifecycleFrameProbePending = false
        lifecycleFrameProbeGeneration += 1
        if (lifecycleFrameAwaitingVideo) {
            showLifecycleFrameOverlay()
            startLifecycleFrameReadyProbe()
        }

        val target = lifecyclePosition.coerceAtLeast(0L)
        val shouldPlay = lifecycleWasPlaying
        lifecycleRestorePending = false
        requestedResumePosition = max(requestedResumePosition, target)
        val generation = ++lifecycleRestoreGeneration

        // V7.22 PLAYER RETAINED SESSION:
        // Prefer re-attaching the same LibVLC MediaPlayer instead of recreating the
        // media/network request after every HOME/app-switch. This preserves decoder
        // state, selected tracks and the current playback position. If Android killed
        // the surface/player or re-attach fails, use the proven rebuild fallback.
        val retained = player
        if (retained != null) {
            val restored = runCatching {
                if (lifecycleViewsDetached) {
                    retained.attachViews(videoLayout, null, false, false)
                    lifecycleViewsDetached = false
                }
                val now = retained.time.coerceAtLeast(0L)
                if (target > 0L && abs(now - target) > 2500L) retained.time = target
                applyMode()
                applySubtitleDelay()
                handler.postDelayed({ applySubtitleVisibility() }, 180L)
                handler.postDelayed({ applyPreferredNativeTracks() }, 320L)
                if (shouldPlay) {
                    pauseAfterLifecycleRestore = false
                    retained.play()
                } else {
                    // A paused VLC surface may not redraw after re-attach. Let one
                    // frame render, then the Playing callback pauses it again.
                    pauseAfterLifecycleRestore = true
                    retained.play()
                }
                handler.removeCallbacks(progressRunnable)
                handler.post(progressRunnable)
                true
            }.getOrDefault(false)
            if (restored) return
        }

        // Fallback for process/surface loss or after PLAYER_BACKGROUND_RETAIN_MS.
        pauseAfterLifecycleRestore = !shouldPlay
        resumeApplied = false
        releasePlayerAsyncForRebuild()
        lifecycleViewsDetached = false
        val delay = if (DeviceProfile.isLowEnd(this)) 220L else 120L
        videoLayout.postDelayed({
            if (isFinishing || isDestroyed || generation != lifecycleRestoreGeneration) return@postDelayed
            launchPlayerSafely(videoUrl)
        }, delay)
    }

    private fun releasePlayer() {
        try {
            player?.stop()
            player?.detachViews()
            player?.release()
            vlc?.release()
        } catch (_: Throwable) {}
        player = null
        vlc = null
        lifecycleViewsDetached = false
    }

    private fun releasePlayerAsyncForRebuild() {
        val oldPlayer = player
        val oldVlc = vlc
        player = null
        vlc = null
        runCatching { oldPlayer?.setEventListener { _ -> } }
        runCatching { if (oldPlayer?.isPlaying == true) oldPlayer.pause() }
        runCatching { oldPlayer?.detachViews() }
        if (oldPlayer == null && oldVlc == null) return
        Thread({
            runCatching { oldPlayer?.stop() }
            runCatching { oldPlayer?.release() }
            runCatching { oldVlc?.release() }
        }, "BM-VLC-RebuildRelease").apply {
            priority = Thread.MIN_PRIORITY
            start()
        }
    }

    private fun releasePlayerAsyncForExit() {
        val oldPlayer = player
        val oldVlc = vlc
        player = null
        vlc = null
        runCatching { oldPlayer?.setEventListener { _ -> } }
        runCatching { oldPlayer?.detachViews() }
        if (oldPlayer == null && oldVlc == null) return
        Thread({
            runCatching { oldPlayer?.stop() }
            runCatching { oldPlayer?.release() }
            runCatching { oldVlc?.release() }
        }, "BM-VLC-Release").apply {
            priority = Thread.MIN_PRIORITY
            start()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus && !isFinishing && !isDestroyed && player != null && videoUrl.isNotBlank()) {
            val inPip = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && isInPictureInPictureMode
            if (!inPip) {
                // HOME/app-switch normally drops window focus slightly before onPause;
                // this gives PixelCopy a better chance to capture while SurfaceView
                // still contains the exact visible frame. Dialog focus changes are
                // harmless and simply refresh the same in-memory snapshot.
                captureLifecycleVideoFrame(force = true)
            }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            !isFinishing &&
            player?.isPlaying == true &&
            videoUrl.isNotBlank()
        ) {
            enterPipMode(showError = false)
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: android.content.res.Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            handler.removeCallbacks(hideRunnable)
            topBar.visibility = View.GONE
            bottomBar.visibility = View.GONE
            centerControls.visibility = View.GONE
            unlockOverlay.visibility = View.GONE
            hudBox.visibility = View.GONE
            setPartyChromeVisible(false)
            controlsVisible = false
        } else if (!controlsLocked) {
            showControls()
        }
    }

    override fun onPause() {
        val inPip = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && isInPictureInPictureMode
        if (!inPip && !isFinishing) {
            if (partyActive && !partyReadyConfirmed) {
                // Pre-ready lobby: there is no legitimate playback session yet.
                // Do not arm the generic lifecycle restore path just because Android
                // opened a Share/chooser activity on top of the player screen.
                lifecycleRestorePending = false
                lifecycleWasPlaying = false
                lifecyclePosition = 0L
                lifecyclePausedAt = 0L
            } else {
                // Capture while the VLC SurfaceView still owns a valid rendered buffer.
                // PixelCopy is asynchronous; onStop gives it a tiny grace period before detach.
                captureLifecycleVideoFrame(force = true)
                val current = player
                lifecyclePosition = (current?.time ?: requestedResumePosition).coerceAtLeast(0L)
                lifecycleWasPlaying = current?.isPlaying == true
                lifecyclePausedAt = System.currentTimeMillis()
                lifecycleRestorePending = videoUrl.isNotBlank() && current != null
                if (lifecyclePosition > 0L) requestedResumePosition = max(requestedResumePosition, lifecyclePosition)
                runCatching { current?.pause() }
                // Do NOT detach here. onPause is also used by transient overlays/dialogs.
                // Detach only once the Activity is really stopped/backgrounded.
                if (partyActive && partyIsHost && lifecycleWasPlaying) sendWatchPartyControl("pause")
            }
        }
        savePlaybackProgress(true)
        super.onPause()
    }

    override fun onStop() {
        val inPip = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && isInPictureInPictureMode
        if (!inPip && !isFinishing && lifecycleRestorePending) {
            if (lifecycleFrameCapturePending && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                handler.postDelayed({ detachRetainedViewsForBackground() }, 110L)
            } else {
                detachRetainedViewsForBackground()
            }
            handler.removeCallbacks(releaseRetainedPlayerRunnable)
            handler.postDelayed(releaseRetainedPlayerRunnable, PLAYER_BACKGROUND_RETAIN_MS)
        }
        super.onStop()
    }

    override fun onDestroy() {
        handler.removeCallbacks(releaseRetainedPlayerRunnable)
        savePlaybackProgress(true)
        nextPromptDialog?.dismiss()
        handler.removeCallbacksAndMessages(null)
        // V7.44.8 — never let the hard-gate dialog leak/re-open while the Activity
        // is being destroyed. Remove its dismiss hook before closing the window.
        runCatching {
            partyLobbyDialog?.setOnDismissListener(null)
            partyLobbyDialog?.dismiss()
            partyLobbyDialog = null
        }
        runCatching { partyChatDialog?.dismiss() }
        lifecycleFrameCaptureGeneration += 1
        lifecycleFrameCapturePending = false
        lifecycleFrameAwaitingVideo = false
        lifecycleFrameProbeGeneration += 1
        lifecycleFrameProbeStartedAt = 0L
        lifecycleFrameProbeReadySamples = 0
        lifecycleFrameProbePending = false
        runCatching { lifecycleFrameBitmap?.recycle() }
        lifecycleFrameBitmap = null
        // Native VLC shutdown can block for seconds on low-end devices. Never make the
        // main thread wait while the user is leaving the player.
        releasePlayerAsyncForExit()
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
}
