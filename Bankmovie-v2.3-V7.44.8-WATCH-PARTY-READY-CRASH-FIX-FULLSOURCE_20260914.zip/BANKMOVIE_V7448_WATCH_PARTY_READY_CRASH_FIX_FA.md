# BankMovie V7.44.8 — رفع کرش «شروع تماشا / آماده‌ام» در Watch Party

## باگ اصلی
در V7.44.7 اگر کاربر قبل از زدن «آماده‌ام» برای دعوت/Share از اپ خارج و برمی‌گشت، مسیر عمومی lifecycle می‌توانست `lifecycleRestorePending` را فعال کند، در حالی که هنوز هیچ VLC واقعی برای Watch Party نباید ساخته می‌شد. بعد از برگشت، پلیر می‌توانست پشت لابی به‌صورت مخفی ساخته شود و با زدن «شروع تماشا» یک بار دیگر LibVLC ساخته/تعویض شود. روی بعضی دستگاه‌های Xiaomi/MIUI این double-start / Surface attach race به Force Close یا برگشت به Splash منجر می‌شد.

## اصلاحات V7.44.8
- تا قبل از تأیید «آماده‌ام»، مسیر lifecycle دیگر اجازه ساخت/Restore پلیر مخفی را ندارد.
- `onPause` در لابی pre-ready دیگر `lifecycleRestorePending` را روشن نمی‌کند.
- `onResume` تا وقتی Ready تأیید نشده فقط لابی را بازسازی می‌کند و از مسیر Restore Player خارج می‌شود.
- کلیک Ready به حالت single-flight تبدیل شده؛ چند لمس سریع یا callback همزمان نمی‌تواند دو پلیر بسازد.
- قبل از اولین Start، state باقی‌مانده از Share/Chooser پاک می‌شود.
- برای Host، شروع VLC کمی بعد از detach شدن پنجره لابی انجام می‌شود تا race پنجره/Surface در MIUI حذف شود.
- Guest بعد از Ready مستقیماً لینک محلی را پخش نمی‌کند؛ منتظر `shared_source_url` و state میزبان می‌ماند و سپس فقط یک Decoder می‌سازد.
- تغییر source مهمان فقط وقتی پلیر پایدار است انجام می‌شود و با single-flight guard از rebuild همزمان جلوگیری می‌شود.
- در destroy شدن Activity، dismiss-listener لابی قبل از بستن پنجره حذف می‌شود تا Window leak یا reopen روی Activity مرده رخ ندهد.
- رفتار V7.44.7 حفظ شده: لابی قبل از Ready با لمس بیرون/Back/X بسته نمی‌شود.

## فایل‌های تغییرکرده
- `app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt`
- `BANKMOVIE_BUILD_SOURCE_2_3.txt`
- `verify_v7447_watch_party_ready_gate.sh` (سازگاری verifier با guard جدید)
- `verify_v7448_watch_party_ready_crash_fix.sh`

## سرور
هیچ فایل PHP یا سمت هاست تغییر نکرده است.
