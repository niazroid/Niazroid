#!/usr/bin/env bash
set -euo pipefail
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'

bash verify_v7447_watch_party_ready_gate.sh

grep -Fq 'sourceMainUpdateThirtySixthHotfixTag=BANKMOVIE-2.3-V7448-20260914' BANKMOVIE_BUILD_SOURCE_2_3.txt
grep -Fq 'private var partySharedSourceUrl = ""' "$player"
grep -Fq 'private var partyReadyLaunchInFlight = false' "$player"
grep -Fq 'if (partyReadyConfirmed || partyReadyLaunchInFlight) return@setOnClickListener' "$player"
grep -Fq 'if (partyActive && !partyReadyConfirmed && partyRoomCode.isNotBlank()) {' "$player"
grep -Fq 'lifecycleRestorePending = videoUrl.isNotBlank() && current != null' "$player"
grep -Fq 'if (partyActive && !partyReadyConfirmed) {' "$player"
grep -Fq 'partyLobbyDialog?.setOnDismissListener(null)' "$player"
grep -Fq 'if (!partyIsHost) {' "$player"
grep -Fq 'partyReadyLaunchInFlight = true' "$player"
grep -Fq 'handler.postDelayed({' "$player"
grep -Fq '}, 140L)' "$player"

python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt').read_text()
# Ready transition must clear stale lifecycle state before dismiss/launch.
i=s.index('if (partyReadyConfirmed || partyReadyLaunchInFlight) return@setOnClickListener')
chunk=s[i:i+3200]
assert chunk.index('lifecycleRestorePending = false') < chunk.index('dialog.dismiss()')
assert chunk.index('partyReadyConfirmed = true') < chunk.index('dialog.dismiss()')
assert 'if (!partyIsHost)' in chunk
assert 'launchPlayerSafely(videoUrl)' in chunk
# Guest start path must be driven by canonical shared source and single-flight guard.
i=s.index('if (partyReadyConfirmed && !partyReadyLaunchInFlight && state != null')
chunk=s[i:i+1800]
assert 'partyReadyLaunchInFlight = true' in chunk
assert 'videoUrl = sharedSource' in chunk
assert 'launchPlayerSafely(sharedSource)' in chunk
# Pre-ready onResume must return before generic lifecycle restore.
i=s.index('override fun onResume()')
chunk=s[i:i+2400]
a=chunk.index('if (partyActive && !partyReadyConfirmed && partyRoomCode.isNotBlank())')
b=chunk.index('if (!lifecycleRestorePending || videoUrl.isBlank()) return')
assert a < b
assert 'return\n        }' in chunk[a:b]
print('V7448_READY_CRASH_GUARDS_OK')
PY

# Source-shape sanity (balanced brackets outside strings/comments).
python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt').read_text()
stack=[]; i=0; state='code'; n=len(s)
while i<n:
    c=s[i]; nx=s[i+1] if i+1<n else ''
    if state=='code':
        if c=='/' and nx=='/': state='line'; i+=2; continue
        if c=='/' and nx=='*': state='block'; i+=2; continue
        if s[i:i+3]=='"""': state='triple'; i+=3; continue
        if c=='"': state='string'; i+=1; continue
        if c=="'": state='char'; i+=1; continue
        if c in '([{': stack.append(c)
        elif c in ')]}':
            pairs={')':'(',']':'[','}':'{'}
            assert stack and stack[-1]==pairs[c], (c,i,stack[-1:] if stack else [])
            stack.pop()
        i+=1; continue
    if state=='line':
        if c=='\n': state='code'
        i+=1; continue
    if state=='block':
        if c=='*' and nx=='/': state='code'; i+=2; continue
        i+=1; continue
    if state=='string':
        if c=='\\': i+=2; continue
        if c=='"': state='code'
        i+=1; continue
    if state=='char':
        if c=='\\': i+=2; continue
        if c=="'": state='code'
        i+=1; continue
    if state=='triple':
        if s[i:i+3]=='"""': state='code'; i+=3; continue
        i+=1
assert state=='code' and not stack, (state, stack[-10:])
print('V7448_KOTLIN_SHAPE_OK')
PY

echo V7448_WATCH_PARTY_READY_CRASH_FIX_VERIFY_OK
