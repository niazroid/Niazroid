<?php
/**
 * app_user_api.php — API حساب کاربری و واچ‌لیست اپ BankMovie
 *
 * POST actions:
 *   login, register, logout, watchlist_sync
 * GET/POST actions:
 *   config, me, watchlist_list
 */

declare(strict_types=1);

@ini_set('display_errors', '0');
@ini_set('log_errors', '1');

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-BM-App-Key, X-BM-Ts, X-BM-Sign, X-BM-User-Token');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

const BM_USER_APP_KEY = 'bm_android_v1_7c2f40';
const BM_USER_APP_SECRET = '9e1d4a7b3167f4c9b2d83f0a64e597f3d7f4b1a72638f90c6e2f2bd29d6aa8c1';

function bm_user_api_json(array $data, int $status = 200): never {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function bm_user_api_error(string $message, int $status = 400, array $extra = []): never {
    bm_user_api_json(array_merge([
        'status' => 'error',
        'success' => false,
        'message' => $message,
    ], $extra), $status);
}

function bm_user_api_header(string $name): string {
    $serverKey = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
    return trim((string)($_SERVER[$serverKey] ?? ''));
}

function bm_user_api_require_app_signature(): void {
    $key = bm_user_api_header('X-BM-App-Key');
    $ts = bm_user_api_header('X-BM-Ts');
    $signature = bm_user_api_header('X-BM-Sign');

    if (!hash_equals(BM_USER_APP_KEY, $key) || $ts === '' || $signature === '') {
        bm_user_api_error('Unauthorized', 401);
    }

    $timestamp = (int)$ts;
    if ($timestamp < time() - 900 || $timestamp > time() + 900) {
        bm_user_api_error('Expired request', 401);
    }

    $requestUri = (string)($_SERVER['REQUEST_URI'] ?? '');
    $path = (string)(parse_url($requestUri, PHP_URL_PATH) ?: '');
    $query = (string)(parse_url($requestUri, PHP_URL_QUERY) ?: '');
    $pathQuery = $path . ($query !== '' ? ('?' . $query) : '');
    $expected = hash_hmac('sha256', $ts . '|' . $pathQuery, BM_USER_APP_SECRET);

    if (!hash_equals($expected, $signature)) {
        bm_user_api_error('Bad signature', 401);
    }
}

bm_user_api_require_app_signature();
require_once __DIR__ . '/config.php';
bm_user_api_ensure_profile_schema($pdo);

function bm_user_api_body(): array {
    static $body = null;
    if (is_array($body)) return $body;

    $raw = file_get_contents('php://input');
    $decoded = is_string($raw) && trim($raw) !== '' ? json_decode($raw, true) : null;
    $body = is_array($decoded) ? $decoded : $_POST;
    return $body;
}

function bm_user_api_param(string $key, mixed $default = ''): mixed {
    $body = bm_user_api_body();
    if (array_key_exists($key, $body)) return $body[$key];
    if (array_key_exists($key, $_GET)) return $_GET[$key];
    return $default;
}

function bm_user_api_action(): string {
    return strtolower(trim((string)bm_user_api_param('action', $_GET['action'] ?? '')));
}

function bm_user_api_require_post(): void {
    if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
        bm_user_api_error('POST required', 405);
    }
}

function bm_user_api_bearer(): string {
    $direct = bm_user_api_header('X-BM-User-Token');
    if ($direct !== '') return $direct;
    $authorization = bm_user_api_header('Authorization');
    if (preg_match('/^Bearer\s+(.+)$/i', $authorization, $m)) {
        return trim((string)$m[1]);
    }
    return trim((string)bm_user_api_param('token', ''));
}

function bm_user_api_current_user(PDO $pdo, bool $required = true): array|false {
    $token = bm_user_api_bearer();
    $user = (new User($pdo))->checkSession($token);
    if (!$user && $required) bm_user_api_error('Please login', 401);
    return $user ?: false;
}

function bm_user_api_avatar_catalog(): array {
    $rows = [
        ['male_01','کای','male'], ['male_02','رن','male'], ['male_03','آکیرا','male'],
        ['male_04','هارو','male'], ['male_05','ریو','male'], ['male_06','کِن','male'],
        ['female_01','یونا','female'], ['female_02','میکا','female'], ['female_03','آی','female'],
        ['female_04','رین','female'], ['female_05','سورا','female'], ['female_06','هانا','female'],
        ['neon_01','نئون بنفش','special'], ['neon_02','نئون آبی','special'],
        ['neon_03','نئون قرمز','special'], ['neon_04','سایبر طلایی','special'],
    ];
    $items = [];
    foreach ($rows as $row) {
        $items[] = [
            'key' => $row[0],
            'label' => $row[1],
            'gender' => $row[2],
            'url' => rtrim((string)SITE_URL, '/') . '/assets/avatars/' . $row[0] . '.svg',
        ];
    }
    return $items;
}

function bm_user_api_remote_config(): array {
    static $config = null;
    if (is_array($config)) return $config;
    $file = __DIR__ . '/bankmovie_remote_config.json';
    $raw = is_file($file) ? @file_get_contents($file) : '';
    $decoded = is_string($raw) && $raw !== '' ? json_decode($raw, true) : null;
    return $config = is_array($decoded) ? $decoded : [];
}

function bm_user_api_features(): array {
    $config = bm_user_api_remote_config();
    $features = is_array($config['features'] ?? null) ? $config['features'] : [];
    $archives = is_array($features['archives'] ?? null) ? $features['archives'] : [];
    return [
        'registration_enabled' => array_key_exists('registration_enabled', $features) ? (bool)$features['registration_enabled'] : true,
        'comments_enabled' => array_key_exists('comments_enabled', $features) ? (bool)$features['comments_enabled'] : true,
        'login_poster_url' => trim((string)($features['login_poster_url'] ?? '')),
        'download_limit' => max(1, min(4, (int)($features['download_limit'] ?? 2))),
        'archive1_enabled' => array_key_exists('archive1_enabled', $archives) ? (bool)$archives['archive1_enabled'] : true,
        'archive2_enabled' => array_key_exists('archive2_enabled', $archives) ? (bool)$archives['archive2_enabled'] : true,
        'notification_center_enabled' => array_key_exists('notification_center_enabled', $features) ? (bool)$features['notification_center_enabled'] : true,
    ];
}

function bm_user_api_feature_enabled(string $key, bool $default = true): bool {
    $features = bm_user_api_features();
    return array_key_exists($key, $features) ? (bool)$features[$key] : $default;
}

function bm_user_api_ensure_notification_schema(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS app_notifications (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        type VARCHAR(32) NOT NULL DEFAULT 'system',
        title VARCHAR(220) NOT NULL DEFAULT '',
        message TEXT NOT NULL,
        target_json MEDIUMTEXT NULL,
        dedupe_key VARCHAR(190) NULL,
        read_at DATETIME NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_user_dedupe (user_id, dedupe_key),
        KEY idx_user_read_created (user_id, read_at, created_at),
        KEY idx_type_created (type, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS comment_reports (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        archive_no TINYINT UNSIGNED NOT NULL DEFAULT 1,
        movie_id BIGINT UNSIGNED NOT NULL,
        comment_id BIGINT UNSIGNED NOT NULL,
        reporter_user_id INT UNSIGNED NOT NULL,
        reason VARCHAR(60) NOT NULL,
        details VARCHAR(500) NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'open',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_comment_reporter (archive_no, comment_id, reporter_user_id),
        KEY idx_status_created (status, created_at),
        KEY idx_movie_comment (movie_id, comment_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function bm_user_api_notify(PDO $pdo, int $userId, string $type, string $title, string $message, array $target = [], string $dedupe = ''): void {
    if ($userId <= 0 || trim($message) === '') return;
    bm_user_api_ensure_notification_schema($pdo);
    $stmt = $pdo->prepare("INSERT INTO app_notifications(user_id,type,title,message,target_json,dedupe_key,created_at)
        VALUES(?,?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE title=VALUES(title),message=VALUES(message),target_json=VALUES(target_json)");
    $stmt->execute([$userId, substr($type,0,32), substr($title,0,220), $message, json_encode($target, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES), $dedupe !== '' ? substr($dedupe,0,190) : null]);
}

function bm_user_api_sync_remote_notifications(PDO $pdo, int $userId): void {
    $config = bm_user_api_remote_config();
    $notice = is_array($config['notice'] ?? null) ? $config['notice'] : [];
    if (!empty($notice['enabled']) && trim((string)($notice['message'] ?? '')) !== '') {
        $id = trim((string)($notice['id'] ?? ''));
        if ($id === '') $id = sha1((string)$notice['message']);
        bm_user_api_notify($pdo, $userId, (string)($notice['type'] ?? 'admin'), trim((string)($notice['title'] ?? 'پیام مدیریت')), trim((string)$notice['message']), is_array($notice['target'] ?? null) ? $notice['target'] : [], 'notice:' . $id);
    }
    $update = is_array($config['update'] ?? null) ? $config['update'] : [];
    if (!empty($update['enabled']) && trim((string)($update['version_name'] ?? '')) !== '') {
        $version = trim((string)$update['version_name']);
        bm_user_api_notify($pdo, $userId, 'update', trim((string)($update['title'] ?? 'آپدیت جدید')), trim((string)($update['message'] ?? 'نسخه جدید آماده است')), ['version_name'=>$version,'apk_url'=>(string)($update['apk_url'] ?? '')], 'update:' . $version);
    }
}

function bm_user_api_ensure_profile_schema(PDO $pdo): void {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        $rows = $pdo->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_ASSOC) ?: [];
        $cols = array_values(array_filter(array_map(static fn($row) => (string)($row['Field'] ?? ''), $rows)));
        if (!in_array('avatar', $cols, true)) {
            $pdo->exec("ALTER TABLE users ADD COLUMN avatar VARCHAR(500) NULL");
            $cols[] = 'avatar';
        }
        if (!in_array('avatar_key', $cols, true)) $pdo->exec("ALTER TABLE users ADD COLUMN avatar_key VARCHAR(40) NULL AFTER avatar");
    } catch (Throwable $e) {
        error_log('app_user_api profile schema: ' . $e->getMessage());
    }
}

function bm_user_api_avatar_url(string $key, string $fallback = ''): string {
    $allowed = array_column(bm_user_api_avatar_catalog(), 'key');
    if ($key !== '' && in_array($key, $allowed, true)) {
        return rtrim((string)SITE_URL, '/') . '/assets/avatars/' . $key . '.svg';
    }
    $fallback = trim($fallback);
    if ($fallback !== '' && !preg_match('~^https?://~i', $fallback)) $fallback = rtrim((string)SITE_URL, '/') . '/' . ltrim($fallback, '/');
    return $fallback;
}

function bm_user_api_public_user(array $user): array {
    $avatarKey = trim((string)($user['avatar_key'] ?? ''));
    $avatar = bm_user_api_avatar_url($avatarKey, (string)($user['avatar'] ?? ''));
    return [
        'id' => (int)($user['id'] ?? 0),
        'username' => (string)($user['username'] ?? ''),
        'email' => (string)($user['email'] ?? ''),
        'full_name' => (string)($user['full_name'] ?? ''),
        'avatar' => $avatar,
        'avatar_key' => $avatarKey,
        'role' => (string)($user['role'] ?? 'user'),
        'status' => (string)($user['status'] ?? 'active'),
        'theme' => (string)($user['theme'] ?? 'dark-green'),
        'language' => (string)($user['language'] ?? 'fa'),
        'created_at' => (string)($user['created_at'] ?? ''),
    ];
}

function bm_user_api_issue_token(PDO $pdo, int $userId): string {
    $token = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', time() + 30 * 86400);
    $stmt = $pdo->prepare('INSERT INTO user_sessions (user_id, session_token, expires_at) VALUES (?, ?, ?)');
    $stmt->execute([$userId, $token, $expires]);
    return $token;
}

function bm_user_api_ensure_watchlist(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS app_watchlist (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        storage_key VARCHAR(190) NOT NULL,
        archive_no TINYINT UNSIGNED NOT NULL DEFAULT 1,
        item_type VARCHAR(24) NOT NULL DEFAULT 'movie',
        item_id VARCHAR(190) NOT NULL DEFAULT '',
        db_movie_id INT UNSIGNED NULL,
        imdb_code VARCHAR(32) NULL,
        title VARCHAR(300) NOT NULL DEFAULT '',
        title_fa VARCHAR(300) NOT NULL DEFAULT '',
        poster VARCHAR(700) NULL,
        year_value VARCHAR(16) NULL,
        rating_value DECIMAL(4,1) NULL,
        source_url VARCHAR(700) NULL,
        payload_json MEDIUMTEXT NULL,
        added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uq_app_watchlist_user_key (user_id, storage_key),
        KEY idx_app_watchlist_user_added (user_id, added_at),
        KEY idx_app_watchlist_db_movie (db_movie_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_watchlist (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        item_link VARCHAR(500) NOT NULL,
        item_title VARCHAR(300) NOT NULL DEFAULT '',
        item_title_fa VARCHAR(300) NOT NULL DEFAULT '',
        item_year VARCHAR(10) DEFAULT NULL,
        item_poster VARCHAR(500) DEFAULT NULL,
        item_imdb_rate DECIMAL(3,1) DEFAULT NULL,
        item_type VARCHAR(20) DEFAULT 'movie',
        added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_user_link (user_id, item_link(200)),
        KEY idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function bm_user_api_normalize_type(string $type): string {
    $type = strtolower(trim($type));
    if (in_array($type, ['tv', 'tvseries'], true)) return 'series';
    if ($type === '') return 'movie';
    return substr($type, 0, 24);
}

function bm_user_api_abs_url(string $value): string {
    $value = trim($value);
    if ($value === '') return '';
    if (str_starts_with($value, '//')) return 'https:' . $value;
    if (preg_match('~^https?://~i', $value)) return $value;
    return rtrim((string)SITE_URL, '/') . '/' . ltrim($value, '/');
}

function bm_user_api_item_source(array $item): string {
    return strtolower(trim((string)($item['source'] ?? $item['source_type'] ?? '')));
}

function bm_user_api_is_database_item(array $item): bool {
    $source = bm_user_api_item_source($item);
    if (in_array($source, ['db_movies','database','local_db','collection','website_db'], true)) return true;
    if ((int)($item['db_id'] ?? 0) > 0) return true;
    $apiDetail = strtolower((string)($item['api_detail'] ?? ''));
    return str_contains($apiDetail, 'app_api.php') && str_contains($apiDetail, 'archive=2');
}

function bm_user_api_is_serialblog_item(array $item): bool {
    $source = bm_user_api_item_source($item);
    return in_array($source, ['serialblog','archive2','sb'], true) || ((int)($item['archive'] ?? 0) === 2 && !bm_user_api_is_database_item($item));
}

function bm_user_api_storage_key(array $item): string {
    $key = trim((string)($item['_key'] ?? $item['storage_key'] ?? ''));
    if ($key !== '') return substr($key, 0, 190);

    $archive = max(1, min(9, (int)($item['archive'] ?? 1)));
    $type = bm_user_api_normalize_type((string)($item['type'] ?? 'movie'));
    $id = trim((string)($item['id'] ?? $item['movie_id'] ?? $item['slug'] ?? $item['imdb_code'] ?? ''));
    if ($id === '') {
        $id = substr(hash('sha256', (string)($item['title_fa'] ?? '') . '|' . (string)($item['title'] ?? '') . '|' . (string)($item['poster'] ?? '')), 0, 40);
    }
    return substr($archive . '|' . $type . '|' . $id, 0, 190);
}

function bm_user_api_legacy_archive1_link(array $item): string {
    foreach (['web_url_abs', 'source_url', 'item_link', 'web_url'] as $field) {
        $value = trim((string)($item[$field] ?? ''));
        if ($value !== '') return bm_user_api_abs_url($value);
    }
    $id = trim((string)($item['id'] ?? $item['slug'] ?? ''));
    if ($id === '') return '';
    $type = bm_user_api_normalize_type((string)($item['type'] ?? 'movie'));
    return rtrim((string)SITE_URL, '/') . '/movie.php?arc=1&slug=' . rawurlencode($id) . '&type=' . rawurlencode($type);
}

function bm_user_api_upsert_app_item(PDO $pdo, int $userId, array $item): void {
    $storageKey = bm_user_api_storage_key($item);
    $archive = max(1, min(9, (int)($item['archive'] ?? 1)));
    $type = bm_user_api_normalize_type((string)($item['type'] ?? 'movie'));
    $itemId = trim((string)($item['id'] ?? $item['movie_id'] ?? $item['slug'] ?? ''));
    $isDatabaseItem = bm_user_api_is_database_item($item);
    $dbMovieId = $isDatabaseItem ? (int)($item['db_id'] ?? (ctype_digit($itemId) ? $itemId : 0)) : 0;
    $imdb = trim((string)($item['imdb_code'] ?? ''));
    $title = trim((string)($item['title'] ?? ''));
    $titleFa = trim((string)($item['title_fa'] ?? $title));
    if ($title === '') $title = $titleFa;
    if ($titleFa === '') $titleFa = $title;
    $poster = bm_user_api_abs_url((string)($item['poster'] ?? ''));
    $year = trim((string)($item['year'] ?? ''));
    $ratingRaw = $item['rating'] ?? null;
    $rating = is_numeric($ratingRaw) ? (float)$ratingRaw : null;
    $sourceUrl = bm_user_api_abs_url((string)($item['source_url'] ?? $item['web_url_abs'] ?? $item['web_url'] ?? ''));
    $payload = $item;
    $payload['_key'] = $storageKey;
    $payload['archive'] = $archive;
    $payload['type'] = $type;
    $payload['id'] = $itemId;
    $payload['poster'] = $poster;
    if ($sourceUrl !== '') $payload['source_url'] = $sourceUrl;

    $stmt = $pdo->prepare("INSERT INTO app_watchlist
        (user_id, storage_key, archive_no, item_type, item_id, db_movie_id, imdb_code, title, title_fa, poster, year_value, rating_value, source_url, payload_json, added_at, updated_at)
        VALUES (?, ?, ?, ?, ?, NULLIF(?,0), NULLIF(?,''), ?, ?, NULLIF(?,''), NULLIF(?,''), ?, NULLIF(?,''), ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
            archive_no=VALUES(archive_no), item_type=VALUES(item_type), item_id=VALUES(item_id),
            db_movie_id=VALUES(db_movie_id), imdb_code=VALUES(imdb_code), title=VALUES(title), title_fa=VALUES(title_fa),
            poster=VALUES(poster), year_value=VALUES(year_value), rating_value=VALUES(rating_value),
            source_url=VALUES(source_url), payload_json=VALUES(payload_json), updated_at=NOW()");
    $stmt->execute([
        $userId, $storageKey, $archive, $type, $itemId, $dbMovieId, $imdb, $title, $titleFa,
        $poster, $year, $rating, $sourceUrl,
        json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
    ]);

    // Mirror app changes to the website's existing watchlist tables.
    if ($isDatabaseItem && $dbMovieId > 0) {
        $check = $pdo->prepare('SELECT id FROM movies WHERE id = ? LIMIT 1');
        $check->execute([$dbMovieId]);
        if ($check->fetchColumn()) {
            $mirror = $pdo->prepare('INSERT IGNORE INTO watchlist (user_id, movie_id, added_at) VALUES (?, ?, NOW())');
            $mirror->execute([$userId, $dbMovieId]);
        }
    } elseif ($archive === 1) {
        $link = bm_user_api_legacy_archive1_link($item);
        if ($link !== '') {
            $mirror = $pdo->prepare("INSERT INTO archive1_watchlist
                (user_id, item_link, item_title, item_title_fa, item_year, item_poster, item_imdb_rate, item_type, added_at)
                VALUES (?, ?, ?, ?, NULLIF(?,''), NULLIF(?,''), ?, ?, NOW())
                ON DUPLICATE KEY UPDATE item_title=VALUES(item_title), item_title_fa=VALUES(item_title_fa),
                    item_year=VALUES(item_year), item_poster=VALUES(item_poster), item_imdb_rate=VALUES(item_imdb_rate), item_type=VALUES(item_type)");
            $mirror->execute([$userId, $link, $title, $titleFa, $year, $poster, $rating, $type]);
        }
    }
}

function bm_user_api_remove_app_item(PDO $pdo, int $userId, string $storageKey): void {
    $stmt = $pdo->prepare('SELECT * FROM app_watchlist WHERE user_id = ? AND storage_key = ? LIMIT 1');
    $stmt->execute([$userId, $storageKey]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

    $delete = $pdo->prepare('DELETE FROM app_watchlist WHERE user_id = ? AND storage_key = ?');
    $delete->execute([$userId, $storageKey]);

    if (!$row) return;
    $archive = (int)($row['archive_no'] ?? 0);
    if ($archive === 2 && (int)($row['db_movie_id'] ?? 0) > 0) {
        $mirror = $pdo->prepare('DELETE FROM watchlist WHERE user_id = ? AND movie_id = ?');
        $mirror->execute([$userId, (int)$row['db_movie_id']]);
    } elseif ($archive === 1) {
        $payload = json_decode((string)($row['payload_json'] ?? ''), true);
        $link = is_array($payload) ? bm_user_api_legacy_archive1_link($payload) : trim((string)($row['source_url'] ?? ''));
        if ($link !== '') {
            $mirror = $pdo->prepare('DELETE FROM archive1_watchlist WHERE user_id = ? AND item_link = ?');
            $mirror->execute([$userId, $link]);
        }
    }
}

function bm_user_api_import_legacy(PDO $pdo, int $userId): void {
    // Database/archive 2 watchlist.
    try {
        $stmt = $pdo->prepare('SELECT m.* FROM watchlist w JOIN movies m ON w.movie_id = m.id WHERE w.user_id = ? ORDER BY w.added_at ASC');
        $stmt->execute([$userId]);
        while ($movie = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $id = (string)(int)($movie['id'] ?? 0);
            if ($id === '0') continue;
            $imdb = trim((string)($movie['imdb_code'] ?? ''));
            $poster = trim((string)($movie['poster'] ?? ''));
            if ($poster === '' && $imdb !== '') $poster = 'posters/' . $imdb . '.webp';
            bm_user_api_upsert_app_item($pdo, $userId, [
                '_key' => '2|' . bm_user_api_normalize_type((string)($movie['type'] ?? 'movie')) . '|' . $id,
                'archive' => 2,
                'source' => 'db_movies',
                'id' => $id,
                'db_id' => (int)$id,
                'imdb_code' => $imdb,
                'type' => (string)($movie['type'] ?? 'movie'),
                'title' => (string)($movie['title'] ?? ''),
                'title_fa' => (string)($movie['title_fa'] ?? $movie['title'] ?? ''),
                'poster' => $poster,
                'year' => (string)($movie['year'] ?? ''),
                'rating' => $movie['imdb_rate'] ?? null,
                'source_url' => (string)($movie['source_url'] ?? ''),
            ]);
        }
    } catch (Throwable $e) {
        error_log('app_user_api legacy db watchlist import: ' . $e->getMessage());
    }

    // Archive 1 website watchlist.
    try {
        $stmt = $pdo->prepare('SELECT * FROM archive1_watchlist WHERE user_id = ? ORDER BY added_at ASC');
        $stmt->execute([$userId]);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $link = trim((string)($row['item_link'] ?? ''));
            if ($link === '') continue;
            $id = '';
            $parts = parse_url($link);
            if (!empty($parts['query'])) {
                parse_str((string)$parts['query'], $query);
                $id = trim((string)($query['slug'] ?? $query['id'] ?? ''));
            }
            if ($id === '' && preg_match('~/movie/arc1-([^/?#]+)~i', $link, $m)) $id = rawurldecode($m[1]);
            if ($id === '') {
                $path = trim((string)($parts['path'] ?? ''), '/');
                if ($path !== '') $id = rawurldecode((string)basename($path));
            }
            if ($id === '') $id = substr(hash('sha256', $link), 0, 32);
            $type = bm_user_api_normalize_type((string)($row['item_type'] ?? 'movie'));
            bm_user_api_upsert_app_item($pdo, $userId, [
                '_key' => '1|' . $type . '|' . $id,
                'archive' => 1,
                'id' => $id,
                'type' => $type,
                'title' => (string)($row['item_title'] ?? ''),
                'title_fa' => (string)($row['item_title_fa'] ?? $row['item_title'] ?? ''),
                'poster' => (string)($row['item_poster'] ?? ''),
                'year' => (string)($row['item_year'] ?? ''),
                'rating' => $row['item_imdb_rate'] ?? null,
                'source_url' => $link,
                'web_url_abs' => $link,
            ]);
        }
    } catch (Throwable $e) {
        error_log('app_user_api legacy archive1 watchlist import: ' . $e->getMessage());
    }
}

function bm_user_api_watchlist_items(PDO $pdo, int $userId): array {
    $stmt = $pdo->prepare('SELECT * FROM app_watchlist WHERE user_id = ? ORDER BY updated_at DESC, id DESC LIMIT 500');
    $stmt->execute([$userId]);
    $items = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $payload = json_decode((string)($row['payload_json'] ?? ''), true);
        if (!is_array($payload)) $payload = [];
        $payload['_key'] = (string)$row['storage_key'];
        $payload['archive'] = (int)$row['archive_no'];
        $payload['type'] = (string)$row['item_type'];
        $payload['id'] = (string)$row['item_id'];
        if (!empty($row['db_movie_id'])) {
            $payload['db_id'] = (int)$row['db_movie_id'];
            $payload['source'] = 'db_movies';
        }
        if (!empty($row['imdb_code'])) $payload['imdb_code'] = (string)$row['imdb_code'];
        $payload['title'] = (string)$row['title'];
        $payload['title_fa'] = (string)$row['title_fa'];
        $payload['poster'] = (string)($row['poster'] ?? '');
        $payload['year'] = (string)($row['year_value'] ?? '');
        if ($row['rating_value'] !== null) $payload['rating'] = (float)$row['rating_value'];
        if (!empty($row['source_url'])) $payload['source_url'] = (string)$row['source_url'];
        $payload['_saved_at'] = strtotime((string)$row['updated_at']) * 1000;
        $items[] = $payload;
    }
    return $items;
}

function bm_user_api_table_columns(PDO $pdo, string $table): array {
    static $cache = [];
    if (isset($cache[$table])) return $cache[$table];
    $safe = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    if ($safe === '') return [];
    try {
        $rows = $pdo->query("SHOW COLUMNS FROM `{$safe}`")->fetchAll(PDO::FETCH_ASSOC) ?: [];
        return $cache[$table] = array_values(array_filter(array_map(static fn($r) => (string)($r['Field'] ?? ''), $rows)));
    } catch (Throwable $e) {
        return $cache[$table] = [];
    }
}

function bm_user_api_first_column(array $columns, array $candidates): string {
    foreach ($candidates as $candidate) if (in_array($candidate, $columns, true)) return $candidate;
    return '';
}

function bm_user_api_ensure_comment_schema(PDO $pdo): void {
    bm_user_api_ensure_profile_schema($pdo);
    bm_user_api_ensure_notification_schema($pdo);
    $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_comments (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        movie_id INT UNSIGNED NOT NULL,
        user_id INT UNSIGNED NULL,
        username VARCHAR(100) NOT NULL DEFAULT '',
        comment TEXT NOT NULL,
        rating TINYINT UNSIGNED NOT NULL DEFAULT 0,
        spoiler TINYINT(1) NOT NULL DEFAULT 0,
        parent_id BIGINT UNSIGNED NULL DEFAULT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        KEY idx_movie_parent_status (movie_id, parent_id, status),
        KEY idx_user_status (user_id, status), KEY idx_parent (parent_id), KEY idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_comment_likes (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        comment_id BIGINT UNSIGNED NOT NULL,
        user_id INT UNSIGNED NOT NULL,
        type VARCHAR(10) NOT NULL DEFAULT 'like',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_comment_user (comment_id, user_id), KEY idx_comment_type (comment_id, type), KEY idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS comment_likes (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        comment_id BIGINT UNSIGNED NOT NULL,
        user_id INT UNSIGNED NOT NULL,
        type VARCHAR(10) NOT NULL DEFAULT 'like',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_comment_user (comment_id, user_id), KEY idx_comment_type (comment_id, type), KEY idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function bm_user_api_comment_item(): array {
    $item = bm_user_api_param('item', []);
    return is_array($item) ? $item : [];
}

function bm_user_api_resolve_db_movie_id(PDO $pdo, array $item): int {
    $cols = bm_user_api_table_columns($pdo, 'movies');
    if (!$cols) return 0;
    $idCol = bm_user_api_first_column($cols, ['id','movie_id']);
    if ($idCol === '') return 0;

    foreach (['db_id','movie_id','id'] as $key) {
        $value = trim((string)($item[$key] ?? ''));
        if ($value !== '' && ctype_digit($value)) {
            try {
                $stmt = $pdo->prepare("SELECT `{$idCol}` FROM movies WHERE `{$idCol}` = ? LIMIT 1");
                $stmt->execute([(int)$value]);
                $id = (int)($stmt->fetchColumn() ?: 0);
                if ($id > 0) return $id;
            } catch (Throwable $e) {}
        }
    }

    $where = []; $params = [];
    $imdb = trim((string)($item['imdb_code'] ?? $item['imdb'] ?? $item['imdb_id'] ?? ''));
    if ($imdb !== '') {
        foreach (['imdb_code','imdb','imdb_id'] as $col) if (in_array($col,$cols,true)) { $where[]="`{$col}` = ?"; $params[]=$imdb; }
    }
    $slug = trim((string)($item['slug'] ?? $item['source_slug'] ?? ''));
    if ($slug !== '') {
        foreach (['slug','source_slug','detail_id'] as $col) if (in_array($col,$cols,true)) { $where[]="`{$col}` = ?"; $params[]=$slug; }
    }
    $title = trim((string)($item['title'] ?? ''));
    if ($title !== '') {
        foreach (['title','title_en','original_title','name','english_title'] as $col) if (in_array($col,$cols,true)) { $where[]="`{$col}` = ?"; $params[]=$title; }
    }
    $titleFa = trim((string)($item['title_fa'] ?? ''));
    if ($titleFa !== '') {
        foreach (['title_fa','fa_title','persian_title'] as $col) if (in_array($col,$cols,true)) { $where[]="`{$col}` = ?"; $params[]=$titleFa; }
    }
    if (!$where) return 0;
    try {
        $stmt = $pdo->prepare("SELECT `{$idCol}` FROM movies WHERE " . implode(' OR ', $where) . " ORDER BY `{$idCol}` ASC LIMIT 1");
        $stmt->execute($params);
        return (int)($stmt->fetchColumn() ?: 0);
    } catch (Throwable $e) {
        error_log('app_user_api resolve movie: ' . $e->getMessage());
        return 0;
    }
}

function bm_user_api_comment_context(PDO $pdo, array $item): array {
    $archive = (int)($item['archive'] ?? 1);
    if (bm_user_api_is_database_item($item)) {
        $movieId = bm_user_api_resolve_db_movie_id($pdo, $item);
        if ($movieId <= 0) bm_user_api_error('شناسه فیلم در دیتابیس پیدا نشد', 404);
        return ['archive'=>2,'movie_id'=>$movieId,'comments'=>'comments','likes'=>'comment_likes'];
    }
    if (bm_user_api_is_serialblog_item($item)) $archive = 4;
    $prefix = $archive === 4 ? 'serialblog:' : ($archive === 3 ? 'arc3:' : 'arc1:');
    $identity = trim((string)($item['id'] ?? $item['slug'] ?? $item['source_url'] ?? $item['title_fa'] ?? $item['title'] ?? ''));
    if ($identity === '') bm_user_api_error('شناسه عنوان برای دیدگاه نامعتبر است', 422);
    $unsigned = sprintf('%u', crc32($prefix . $identity));
    $movieId = 1000000000 + ((int)$unsigned % 1000000000);
    return ['archive'=>$archive,'movie_id'=>$movieId,'comments'=>'archive1_comments','likes'=>'archive1_comment_likes'];
}

function bm_user_api_comment_date(string $date): string {
    $time = strtotime($date); if (!$time) return 'لحظاتی پیش';
    $d = max(0, time() - $time);
    if ($d < 60) return 'لحظاتی پیش';
    if ($d < 3600) return floor($d/60) . ' دقیقه پیش';
    if ($d < 86400) return floor($d/3600) . ' ساعت پیش';
    if ($d < 604800) return floor($d/86400) . ' روز پیش';
    if ($d < 2592000) return floor($d/604800) . ' هفته پیش';
    if ($d < 31536000) return floor($d/2592000) . ' ماه پیش';
    return floor($d/31536000) . ' سال پیش';
}

function bm_user_api_comment_row(array $row, int $currentUserId, bool $currentIsAdmin = false): array {
    $avatarKey = trim((string)($row['avatar_key'] ?? ''));
    return [
        'id'=>(int)$row['id'], 'user_id'=>(int)($row['user_id'] ?? 0),
        'username'=>(string)($row['username'] ?? 'کاربر'), 'comment'=>(string)($row['comment'] ?? ''),
        'rating'=>(int)($row['rating'] ?? 0), 'spoiler'=>(int)($row['spoiler'] ?? 0) === 1,
        'role'=>(string)($row['role'] ?? 'user'), 'avatar_key'=>$avatarKey,
        'avatar'=>bm_user_api_avatar_url($avatarKey, (string)($row['avatar'] ?? '')),
        'like_count'=>(int)($row['like_count'] ?? 0), 'dislike_count'=>(int)($row['dislike_count'] ?? 0),
        'user_vote'=>(string)($row['user_vote'] ?? ''), 'reply_count'=>(int)($row['reply_count'] ?? 0),
        'created_at'=>(string)($row['created_at'] ?? ''), 'date_text'=>bm_user_api_comment_date((string)($row['created_at'] ?? '')),
        'status'=>(string)($row['status'] ?? 'approved'), 'is_pending'=>(string)($row['status'] ?? 'approved') === 'pending',
        'badge'=>in_array((string)($row['role'] ?? ''), ['admin','administrator'], true) ? 'مدیر' : (in_array((string)($row['role'] ?? ''), ['vip','premium','special'], true) ? 'عضو ویژه' : ''),
        'can_delete'=>$currentUserId > 0 && ((int)($row['user_id'] ?? 0) === $currentUserId || $currentIsAdmin),
        'can_report'=>$currentUserId > 0 && (int)($row['user_id'] ?? 0) !== $currentUserId,
    ];
}

function bm_user_api_comment_list(PDO $pdo, array $ctx, int $currentUserId, int $page, int $limit, bool $currentIsAdmin = false): array {
    $c = $ctx['comments']; $l = $ctx['likes']; $movieId = (int)$ctx['movie_id'];
    $page=max(1,$page); $limit=max(1,min(30,$limit)); $offset=($page-1)*$limit;
    $visible = $currentUserId > 0 ? "(c.status='approved' OR (c.status='pending' AND c.user_id=?))" : "c.status='approved'";
    $sql = "SELECT c.*, u.role, u.avatar, u.avatar_key,
        COALESCE((SELECT COUNT(*) FROM `$l` x WHERE x.comment_id=c.id AND x.type='like'),0) like_count,
        COALESCE((SELECT COUNT(*) FROM `$l` x WHERE x.comment_id=c.id AND x.type='dislike'),0) dislike_count,
        COALESCE((SELECT type FROM `$l` x WHERE x.comment_id=c.id AND x.user_id=? LIMIT 1),'') user_vote,
        (SELECT COUNT(*) FROM `$c` r WHERE r.parent_id=c.id AND (r.status='approved' OR (r.status='pending' AND r.user_id=?))) reply_count
        FROM `$c` c LEFT JOIN users u ON u.id=c.user_id
        WHERE c.movie_id=? AND c.parent_id IS NULL AND $visible
        ORDER BY (c.status='pending') DESC, c.created_at DESC LIMIT $limit OFFSET $offset";
    $params=[$currentUserId,$currentUserId,$movieId]; if($currentUserId>0)$params[]=$currentUserId;
    $stmt=$pdo->prepare($sql); $stmt->execute($params);
    $items=[];
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $row) {
        $comment=bm_user_api_comment_row($row,$currentUserId,$currentIsAdmin);
        $replyVisible = $currentUserId > 0 ? "(r.status='approved' OR (r.status='pending' AND r.user_id=?))" : "r.status='approved'";
        $rs=$pdo->prepare("SELECT r.*,u.role,u.avatar,u.avatar_key,
            COALESCE((SELECT COUNT(*) FROM `$l` x WHERE x.comment_id=r.id AND x.type='like'),0) like_count,
            COALESCE((SELECT COUNT(*) FROM `$l` x WHERE x.comment_id=r.id AND x.type='dislike'),0) dislike_count,
            COALESCE((SELECT type FROM `$l` x WHERE x.comment_id=r.id AND x.user_id=? LIMIT 1),'') user_vote,
            0 reply_count FROM `$c` r LEFT JOIN users u ON u.id=r.user_id
            WHERE r.parent_id=? AND $replyVisible ORDER BY r.created_at ASC LIMIT 30");
        $rp=[$currentUserId,(int)$row['id']]; if($currentUserId>0)$rp[]=$currentUserId; $rs->execute($rp);
        $replies=[]; foreach ($rs->fetchAll(PDO::FETCH_ASSOC) ?: [] as $rr) $replies[]=bm_user_api_comment_row($rr,$currentUserId,$currentIsAdmin);
        $comment['replies']=$replies; $items[]=$comment;
    }
    $t=$pdo->prepare("SELECT COUNT(*) FROM `$c` WHERE movie_id=? AND parent_id IS NULL AND status='approved'"); $t->execute([$movieId]); $total=(int)$t->fetchColumn();
    $r=$pdo->prepare("SELECT AVG(rating),COUNT(*) FROM `$c` WHERE movie_id=? AND parent_id IS NULL AND status='approved' AND rating>0"); $r->execute([$movieId]); $rating=$r->fetch(PDO::FETCH_NUM) ?: [0,0];
    return ['items'=>$items,'page'=>$page,'limit'=>$limit,'total'=>$total,'has_more'=>$offset+count($items)<$total,'rating_avg'=>round((float)$rating[0],1),'rating_count'=>(int)$rating[1]];
}

function bm_user_api_update_movie_rating(PDO $pdo, int $movieId): void {
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS movie_ratings (movie_id INT UNSIGNED PRIMARY KEY, avg_rating DECIMAL(4,2) NOT NULL DEFAULT 0, total_votes INT UNSIGNED NOT NULL DEFAULT 0)");
        $s=$pdo->prepare("SELECT AVG(rating),COUNT(*) FROM comments WHERE movie_id=? AND parent_id IS NULL AND status='approved' AND rating>0"); $s->execute([$movieId]); $v=$s->fetch(PDO::FETCH_NUM) ?: [0,0];
        $u=$pdo->prepare("INSERT INTO movie_ratings(movie_id,avg_rating,total_votes) VALUES(?,?,?) ON DUPLICATE KEY UPDATE avg_rating=VALUES(avg_rating),total_votes=VALUES(total_votes)");
        $u->execute([$movieId,(float)$v[0],(int)$v[1]]);
    } catch (Throwable $e) { error_log('app user rating: '.$e->getMessage()); }
}

function bm_user_api_stats(PDO $pdo, int $userId): array {
    bm_user_api_ensure_watchlist($pdo);
    bm_user_api_ensure_notification_schema($pdo);
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM app_watchlist WHERE user_id = ?');
    $stmt->execute([$userId]);
    $watchlist = (int)$stmt->fetchColumn();
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM app_notifications WHERE user_id = ? AND read_at IS NULL');
    $stmt->execute([$userId]);
    return ['watchlist' => $watchlist, 'notifications_unread' => (int)$stmt->fetchColumn()];
}

$action = bm_user_api_action();

try {
    if ($action === 'config') {
        $features = bm_user_api_features();
        $configuredBg = trim((string)($features['login_poster_url'] ?? ''));
        $bgRelative = is_file(__DIR__ . '/uploads/poste.webp') ? 'uploads/poste.webp' : (is_file(__DIR__ . '/poste.webp') ? 'poste.webp' : '');
        $background = $configuredBg !== '' ? bm_user_api_abs_url($configuredBg) : ($bgRelative !== '' ? rtrim((string)SITE_URL, '/') . '/' . $bgRelative : '');
        bm_user_api_json([
            'status' => 'ok',
            'success' => true,
            'background_url' => $background,
            'features' => $features,
            'login_identifier' => 'username_or_email',
            'registration_email_required' => true,
            'forgot_password_enabled' => false,
            'avatars' => bm_user_api_avatar_catalog(),
        ]);
    }

    if ($action === 'login') {
        bm_user_api_require_post();
        $identity = trim((string)bm_user_api_param('identity', bm_user_api_param('username', '')));
        $password = (string)bm_user_api_param('password', '');
        if ($identity === '' || $password === '') bm_user_api_error('نام کاربری یا ایمیل و رمز عبور را وارد کنید');

        $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1');
        $stmt->execute([$identity, $identity]);
        $userRow = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$userRow || !password_verify($password, (string)$userRow['password'])) {
            bm_user_api_error('نام کاربری یا رمز عبور اشتباه است', 401);
        }
        if ((string)($userRow['status'] ?? 'active') !== 'active') {
            bm_user_api_error('حساب کاربری شما فعال نیست', 403);
        }

        $token = bm_user_api_issue_token($pdo, (int)$userRow['id']);
        bm_user_api_ensure_watchlist($pdo);
        bm_user_api_import_legacy($pdo, (int)$userRow['id']);
        bm_user_api_json([
            'status' => 'ok',
            'success' => true,
            'token' => $token,
            'user' => bm_user_api_public_user($userRow),
            'stats' => bm_user_api_stats($pdo, (int)$userRow['id']),
        ]);
    }

    if ($action === 'register') {
        bm_user_api_require_post();
        if (!bm_user_api_feature_enabled('registration_enabled', true)) bm_user_api_error('ثبت‌نام موقتاً از پنل مدیریت غیرفعال شده است', 403);
        $username = trim((string)bm_user_api_param('username', ''));
        $email = strtolower(trim((string)bm_user_api_param('email', '')));
        $password = (string)bm_user_api_param('password', '');
        $confirm = (string)bm_user_api_param('confirm_password', '');

        if (mb_strlen($username, 'UTF-8') < 3 || mb_strlen($username, 'UTF-8') > 40) {
            bm_user_api_error('نام کاربری باید بین ۳ تا ۴۰ کاراکتر باشد');
        }
        if (!preg_match('/^[\p{L}\p{N}_.-]+$/u', $username)) {
            bm_user_api_error('نام کاربری فقط می‌تواند شامل حروف، عدد، نقطه، خط تیره و زیرخط باشد');
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
            bm_user_api_error('ایمیل معتبر وارد کنید');
        }
        if (strlen($password) < 8) bm_user_api_error('رمز عبور باید حداقل ۸ کاراکتر باشد');
        if (!hash_equals($password, $confirm)) bm_user_api_error('رمز عبور و تکرار آن یکسان نیست');

        $stmt = $pdo->prepare('SELECT id, username, email FROM users WHERE username = ? OR email = ? LIMIT 1');
        $stmt->execute([$username, $email]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($existing) {
            if (strcasecmp((string)$existing['email'], $email) === 0) bm_user_api_error('این ایمیل قبلاً ثبت شده است', 409);
            bm_user_api_error('این نام کاربری قبلاً ثبت شده است', 409);
        }

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, status, created_at) VALUES (?, ?, ?, 'user', 'active', NOW())");
        $stmt->execute([$username, $email, $hash]);
        $userId = (int)$pdo->lastInsertId();
        $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([$userId]);
        $userRow = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['id' => $userId, 'username' => $username, 'email' => $email, 'status' => 'active', 'role' => 'user'];
        $token = bm_user_api_issue_token($pdo, $userId);
        bm_user_api_ensure_watchlist($pdo);

        bm_user_api_json([
            'status' => 'ok',
            'success' => true,
            'message' => 'ثبت‌نام با موفقیت انجام شد',
            'token' => $token,
            'user' => bm_user_api_public_user($userRow),
            'stats' => ['watchlist' => 0],
        ], 201);
    }

    if ($action === 'me') {
        $userRow = bm_user_api_current_user($pdo, true);
        $token = bm_user_api_bearer();
        $extend = $pdo->prepare('UPDATE user_sessions SET expires_at = ? WHERE session_token = ?');
        $extend->execute([date('Y-m-d H:i:s', time() + 30 * 86400), $token]);
        bm_user_api_ensure_watchlist($pdo);
        bm_user_api_import_legacy($pdo, (int)$userRow['id']);
        bm_user_api_json([
            'status' => 'ok',
            'success' => true,
            'user' => bm_user_api_public_user($userRow),
            'stats' => bm_user_api_stats($pdo, (int)$userRow['id']),
            'features' => bm_user_api_features(),
        ]);
    }

    if ($action === 'logout') {
        bm_user_api_require_post();
        $token = bm_user_api_bearer();
        if ($token !== '') {
            $stmt = $pdo->prepare('DELETE FROM user_sessions WHERE session_token = ?');
            $stmt->execute([$token]);
        }
        bm_user_api_json(['status' => 'ok', 'success' => true]);
    }

    if ($action === 'avatar_update') {
        bm_user_api_require_post();
        $userRow = bm_user_api_current_user($pdo, true);
        $key = trim((string)bm_user_api_param('avatar_key', ''));
        $allowed = array_column(bm_user_api_avatar_catalog(), 'key');
        if (!in_array($key, $allowed, true)) bm_user_api_error('آواتار انتخاب‌شده معتبر نیست');
        $relative = 'assets/avatars/' . $key . '.svg';
        $stmt = $pdo->prepare('UPDATE users SET avatar_key = ?, avatar = ? WHERE id = ?');
        $stmt->execute([$key, $relative, (int)$userRow['id']]);
        $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1'); $stmt->execute([(int)$userRow['id']]);
        bm_user_api_json(['status'=>'ok','success'=>true,'message'=>'آواتار ذخیره شد','user'=>bm_user_api_public_user($stmt->fetch(PDO::FETCH_ASSOC) ?: $userRow)]);
    }

    if ($action === 'comments_list') {
        bm_user_api_require_post();
        if (!bm_user_api_feature_enabled('comments_enabled', true)) bm_user_api_error('بخش دیدگاه‌ها موقتاً غیرفعال است', 403);
        bm_user_api_ensure_comment_schema($pdo);
        $userRow = bm_user_api_current_user($pdo, false);
        $ctx = bm_user_api_comment_context($pdo, bm_user_api_comment_item());
        $data = bm_user_api_comment_list($pdo, $ctx, $userRow ? (int)$userRow['id'] : 0, (int)bm_user_api_param('page',1), (int)bm_user_api_param('limit',10), $userRow && (string)($userRow['role'] ?? '') === 'admin');
        bm_user_api_json(array_merge(['status'=>'ok','success'=>true,'context'=>['archive'=>$ctx['archive'],'movie_id'=>$ctx['movie_id']]],$data));
    }

    if ($action === 'comment_add' || $action === 'comment_reply') {
        bm_user_api_require_post();
        if (!bm_user_api_feature_enabled('comments_enabled', true)) bm_user_api_error('ثبت دیدگاه موقتاً غیرفعال است', 403);
        bm_user_api_ensure_comment_schema($pdo);
        $userRow = bm_user_api_current_user($pdo, true); $ctx = bm_user_api_comment_context($pdo, bm_user_api_comment_item());
        $text = trim((string)bm_user_api_param('comment','')); $rating=(int)bm_user_api_param('rating',0); $spoiler=(int)bm_user_api_param('spoiler',0)===1?1:0;
        if (mb_strlen($text,'UTF-8') < 3) bm_user_api_error('متن دیدگاه باید حداقل ۳ کاراکتر باشد');
        if (mb_strlen($text,'UTF-8') > 500) bm_user_api_error('متن دیدگاه نباید بیشتر از ۵۰۰ کاراکتر باشد');
        if ($rating<0 || $rating>5) bm_user_api_error('امتیاز باید بین ۰ تا ۵ باشد');
        $parent = $action === 'comment_reply' ? (int)bm_user_api_param('parent_id',0) : 0;
        $parentRow = null;
        if ($parent>0) { $q=$pdo->prepare("SELECT id,user_id,username FROM `{$ctx['comments']}` WHERE id=? AND movie_id=? AND status!='deleted' LIMIT 1"); $q->execute([$parent,$ctx['movie_id']]); $parentRow=$q->fetch(PDO::FETCH_ASSOC); if(!$parentRow) bm_user_api_error('دیدگاه اصلی پیدا نشد',404); }
        $status = ((string)($userRow['role'] ?? '') === 'admin' || $parent>0) ? 'approved' : 'pending';
        if ($status==='pending') { $q=$pdo->prepare("SELECT id FROM `{$ctx['comments']}` WHERE user_id=? AND status='approved' LIMIT 1"); $q->execute([(int)$userRow['id']]); if($q->fetchColumn()) $status='approved'; }
        $stmt=$pdo->prepare("INSERT INTO `{$ctx['comments']}`(movie_id,user_id,username,comment,rating,spoiler,parent_id,status,created_at) VALUES(?,?,?,?,?,?,?,?,NOW())");
        $stmt->execute([$ctx['movie_id'],(int)$userRow['id'],(string)$userRow['username'],$text,$parent>0?0:$rating,$spoiler,$parent>0?$parent:null,$status]);
        $newCommentId = (int)$pdo->lastInsertId();
        if ($parentRow && (int)($parentRow['user_id'] ?? 0) > 0 && (int)$parentRow['user_id'] !== (int)$userRow['id']) {
            bm_user_api_notify($pdo, (int)$parentRow['user_id'], 'comment_reply', 'پاسخ جدید به دیدگاه شما', (string)$userRow['username'] . ' به دیدگاه شما پاسخ داد', ['item'=>bm_user_api_comment_item(),'comment_id'=>$newCommentId,'parent_id'=>$parent], 'reply:' . $newCommentId);
        }
        if ($ctx['archive']===2 && $status==='approved' && $parent===0) bm_user_api_update_movie_rating($pdo,(int)$ctx['movie_id']);
        bm_user_api_json(['status'=>'ok','success'=>true,'approved'=>$status==='approved','message'=>$status==='approved'?'دیدگاه با موفقیت ثبت شد':'دیدگاه پس از تأیید مدیر نمایش داده می‌شود']);
    }

    if ($action === 'comment_vote') {
        bm_user_api_require_post(); bm_user_api_ensure_comment_schema($pdo);
        $userRow=bm_user_api_current_user($pdo,true); $ctx=bm_user_api_comment_context($pdo,bm_user_api_comment_item());
        $commentId=(int)bm_user_api_param('comment_id',0); $type=strtolower(trim((string)bm_user_api_param('type','like')));
        if(!in_array($type,['like','dislike'],true)) bm_user_api_error('نوع رأی نامعتبر است');
        $q=$pdo->prepare("SELECT id FROM `{$ctx['comments']}` WHERE id=? AND movie_id=? AND status='approved' LIMIT 1"); $q->execute([$commentId,$ctx['movie_id']]); if(!$q->fetchColumn()) bm_user_api_error('دیدگاه پیدا نشد',404);
        $q=$pdo->prepare("SELECT type FROM `{$ctx['likes']}` WHERE comment_id=? AND user_id=? LIMIT 1"); $q->execute([$commentId,(int)$userRow['id']]); $old=(string)($q->fetchColumn()?:'');
        if($old===$type){$d=$pdo->prepare("DELETE FROM `{$ctx['likes']}` WHERE comment_id=? AND user_id=?");$d->execute([$commentId,(int)$userRow['id']]);$new='';}
        else{$u=$pdo->prepare("INSERT INTO `{$ctx['likes']}`(comment_id,user_id,type,created_at) VALUES(?,?,?,NOW()) ON DUPLICATE KEY UPDATE type=VALUES(type)");$u->execute([$commentId,(int)$userRow['id'],$type]);$new=$type;}
        $c=$pdo->prepare("SELECT SUM(type='like'),SUM(type='dislike') FROM `{$ctx['likes']}` WHERE comment_id=?");$c->execute([$commentId]);$v=$c->fetch(PDO::FETCH_NUM)?:[0,0];
        bm_user_api_json(['status'=>'ok','success'=>true,'user_vote'=>$new,'like_count'=>(int)$v[0],'dislike_count'=>(int)$v[1]]);
    }

    if ($action === 'comment_report') {
        bm_user_api_require_post(); bm_user_api_ensure_comment_schema($pdo);
        $userRow=bm_user_api_current_user($pdo,true); $ctx=bm_user_api_comment_context($pdo,bm_user_api_comment_item());
        $commentId=(int)bm_user_api_param('comment_id',0);
        $reason=trim((string)bm_user_api_param('reason','other'));
        $details=trim((string)bm_user_api_param('details',''));
        $allowed=['spoiler','insult','spam','illegal','other']; if(!in_array($reason,$allowed,true)) $reason='other';
        $q=$pdo->prepare("SELECT user_id FROM `{$ctx['comments']}` WHERE id=? AND movie_id=? AND status!='deleted' LIMIT 1"); $q->execute([$commentId,$ctx['movie_id']]); $owner=(int)($q->fetchColumn()?:0);
        if($owner<=0) bm_user_api_error('دیدگاه پیدا نشد',404);
        if($owner===(int)$userRow['id']) bm_user_api_error('امکان گزارش دیدگاه خودتان وجود ندارد',422);
        $stmt=$pdo->prepare("INSERT INTO comment_reports(archive_no,movie_id,comment_id,reporter_user_id,reason,details,status,created_at) VALUES(?,?,?,?,?,?,'open',NOW()) ON DUPLICATE KEY UPDATE reason=VALUES(reason),details=VALUES(details),status='open'");
        $stmt->execute([(int)$ctx['archive'],(int)$ctx['movie_id'],$commentId,(int)$userRow['id'],$reason,mb_substr($details,0,500,'UTF-8')]);
        bm_user_api_json(['status'=>'ok','success'=>true,'message'=>'گزارش شما ثبت شد و توسط مدیریت بررسی می‌شود']);
    }

    if ($action === 'notifications_list') {
        bm_user_api_require_post(); $userRow=bm_user_api_current_user($pdo,true); bm_user_api_ensure_notification_schema($pdo);
        $uid=(int)$userRow['id']; bm_user_api_sync_remote_notifications($pdo,$uid);
        $page=max(1,(int)bm_user_api_param('page',1)); $limit=max(1,min(50,(int)bm_user_api_param('limit',30))); $offset=($page-1)*$limit;
        $stmt=$pdo->prepare("SELECT * FROM app_notifications WHERE user_id=? ORDER BY created_at DESC,id DESC LIMIT $limit OFFSET $offset"); $stmt->execute([$uid]);
        $items=[]; foreach($stmt->fetchAll(PDO::FETCH_ASSOC)?:[] as $row){$target=json_decode((string)($row['target_json']??''),true);$items[]=['id'=>(int)$row['id'],'type'=>(string)$row['type'],'title'=>(string)$row['title'],'message'=>(string)$row['message'],'target'=>is_array($target)?$target:[],'is_read'=>!empty($row['read_at']),'date_text'=>bm_user_api_comment_date((string)$row['created_at']),'created_at'=>(string)$row['created_at']];}
        $count=$pdo->prepare('SELECT COUNT(*) FROM app_notifications WHERE user_id=?');$count->execute([$uid]);
        bm_user_api_json(['status'=>'ok','success'=>true,'items'=>$items,'total'=>(int)$count->fetchColumn(),'stats'=>bm_user_api_stats($pdo,$uid)]);
    }

    if ($action === 'notification_read' || $action === 'notifications_read_all') {
        bm_user_api_require_post(); $userRow=bm_user_api_current_user($pdo,true); bm_user_api_ensure_notification_schema($pdo); $uid=(int)$userRow['id'];
        if($action==='notification_read'){ $id=(int)bm_user_api_param('notification_id',0); $stmt=$pdo->prepare('UPDATE app_notifications SET read_at=COALESCE(read_at,NOW()) WHERE id=? AND user_id=?');$stmt->execute([$id,$uid]); }
        else { $stmt=$pdo->prepare('UPDATE app_notifications SET read_at=COALESCE(read_at,NOW()) WHERE user_id=?');$stmt->execute([$uid]); }
        bm_user_api_json(['status'=>'ok','success'=>true,'stats'=>bm_user_api_stats($pdo,$uid)]);
    }

    if ($action === 'comment_delete') {
        bm_user_api_require_post(); bm_user_api_ensure_comment_schema($pdo);
        $userRow=bm_user_api_current_user($pdo,true); $ctx=bm_user_api_comment_context($pdo,bm_user_api_comment_item()); $id=(int)bm_user_api_param('comment_id',0);
        $q=$pdo->prepare("SELECT user_id,parent_id FROM `{$ctx['comments']}` WHERE id=? AND movie_id=? LIMIT 1");$q->execute([$id,$ctx['movie_id']]);$row=$q->fetch(PDO::FETCH_ASSOC);
        if(!$row) bm_user_api_error('دیدگاه پیدا نشد',404);
        if((int)$row['user_id']!==(int)$userRow['id'] && (string)$userRow['role']!=='admin') bm_user_api_error('اجازه حذف این دیدگاه را ندارید',403);
        $u=$pdo->prepare("UPDATE `{$ctx['comments']}` SET status='deleted' WHERE id=? OR parent_id=?");$u->execute([$id,$id]);
        if($ctx['archive']===2 && empty($row['parent_id'])) bm_user_api_update_movie_rating($pdo,(int)$ctx['movie_id']);
        bm_user_api_json(['status'=>'ok','success'=>true,'message'=>'دیدگاه حذف شد']);
    }

    if ($action === 'watchlist_list') {
        $userRow = bm_user_api_current_user($pdo, true);
        bm_user_api_ensure_watchlist($pdo);
        bm_user_api_import_legacy($pdo, (int)$userRow['id']);
        $items = bm_user_api_watchlist_items($pdo, (int)$userRow['id']);
        bm_user_api_json([
            'status' => 'ok',
            'success' => true,
            'items' => $items,
            'count' => count($items),
        ]);
    }

    if ($action === 'watchlist_sync') {
        bm_user_api_require_post();
        $userRow = bm_user_api_current_user($pdo, true);
        $userId = (int)$userRow['id'];
        bm_user_api_ensure_watchlist($pdo);
        bm_user_api_import_legacy($pdo, $userId);

        $body = bm_user_api_body();
        $removed = is_array($body['removed_keys'] ?? null) ? $body['removed_keys'] : [];
        $items = is_array($body['items'] ?? null) ? $body['items'] : [];

        $pdo->beginTransaction();
        try {
            foreach (array_slice($removed, 0, 500) as $key) {
                $key = substr(trim((string)$key), 0, 190);
                if ($key !== '') bm_user_api_remove_app_item($pdo, $userId, $key);
            }
            foreach (array_slice($items, 0, 500) as $item) {
                if (is_array($item)) bm_user_api_upsert_app_item($pdo, $userId, $item);
            }
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }

        $merged = bm_user_api_watchlist_items($pdo, $userId);
        bm_user_api_json([
            'status' => 'ok',
            'success' => true,
            'items' => $merged,
            'count' => count($merged),
        ]);
    }

    bm_user_api_error('Unknown action', 404);
} catch (PDOException $e) {
    error_log('app_user_api database error: ' . $e->getMessage());
    bm_user_api_error('خطای موقت پایگاه داده', 500);
} catch (Throwable $e) {
    error_log('app_user_api error: ' . $e->getMessage());
    bm_user_api_error('خطای موقت سرور', 500);
}
