#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PY'
from pathlib import Path
import re, zipfile, xml.etree.ElementTree as ET
p=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt')
s=p.read_text(encoding='utf-8')
resources='app/src/main/res/drawable'
expected={
 'bm_v14_users_round':'users-round.svg',
 'bm_v14_play':'play.svg',
 'bm_v14_copy':'copy.svg',
 'bm_v14_clapperboard':'clapperboard.svg',
 'bm_v14_chevron_down':'chevron-down.svg',
 'bm_v14_circle_help':'circle-help.svg',
 'bm_v14_download':'download.svg',
 'bm_v14_share':'share-2.svg',
}
for name in expected:
    path=Path(resources,name+'.xml')
    assert path.is_file(),name
    root=ET.parse(path).getroot()
    assert root.tag.endswith('vector')
    assert len(list(root))>=1,name
    for part in root:
        assert part.attrib['{http://schemas.android.com/apk/res/android}pathData'],name
        assert part.attrib['{http://schemas.android.com/apk/res/android}strokeColor']=='#FFFFFFFF'
# Regression for Lucide play.svg polygon, whose coordinates are space-delimited.
play=ET.parse(Path(resources,'bm_v14_play.xml')).getroot()[0]
assert play.attrib['{http://schemas.android.com/apk/res/android}pathData']=='M6,3 L20,12 L6,21 Z'
# Both mobile + TV must gate recommendations for Archive 5 before any rail.
assert s.count('if (detailArchive != 5) {')==2
assert s.count('} // Archive 5 has no Recommendations section')==2
# Never remove recommendations for other archives.
assert 'addArchive2GenreRail(page' in s and 'addSearchRail(page' in s
assert 'isArchive5Promo(raw)' in s
assert 'if (archive != 5 || !isArchive5Promo(raw))' in s
assert 'if (json.has("results")) json.put("results", normalized)' in s
assert 'val pattern = Regex("""(?m)' in s
assert 'item.put("archive5_metadata", info)' in s
assert 'item.put("long_description", summary)' in s
assert 'item.optJSONArray("archive5_metadata")' in s
assert 'addInfoRow(fact.optString("label"), fact.optString("value"))' in s
assert 'titleKey.contains("فصل‌ها و قسمت‌ها") || titleKey.contains("seasons, episodes") -> R.drawable.bm_v14_play' in s
assert 'titleKey.contains("پیشنهاد فیلم") || titleKey.contains("recommended") -> R.drawable.bm_v14_clapperboard' in s
assert 'setImageResource(R.drawable.bm_v14_copy)' in s
assert 'setColorFilter(if (palette.light) palette.text else Color.WHITE)' in s
assert 'if (artRes == R.drawable.bm_v14_users_round ||' in s
assert 'R.drawable.bm_v14_circle_help' in s
# V13.1 compile fix remains intact.
assert not re.search(r'(?<!fun )\bdownloadNotice\s*\(',s)
print('BANKMOVIE_V14_ARCHIVE5_METADATA_PROMO_ICONS_OK')
PY
