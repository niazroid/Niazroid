#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
WF='.github/workflows/build-bankmovie.yml'
[[ -f "$MAIN" && -f "$WF" ]] || { echo VERIFY_V7471_9_FILES_MISSING; exit 1; }
# Box Office TV must now use the same mobile visual structure instead of the old purple summary/list UI.
grep -Fq 'val pink = Color.rgb(255, 63, 133)' "$MAIN"
grep -Fq 'Top-grossing movies worldwide' "$MAIN"
grep -Fq 'text = rank.toString().padStart(2, '\''0'\'')' "$MAIN"
grep -Fq 'Weeks in theaters:' "$MAIN"
grep -Fq 'Weekend gross:' "$MAIN"
grep -Fq 'Total gross:' "$MAIN"
grep -Fq 'tag = "bm_v68_boxoffice_item_$index"' "$MAIN"
# Profile compatibility: accept the original V7.47.1.9 person-hero or the later
# V7.47.1.10 mobile-matched auth-poster profile. Box Office requirements above stay strict.
if grep -Fq 'V7.47.1.9: Profile adopts the same person-hero language as Actor pages' "$MAIN"; then
  grep -Fq 'createBlurEffect(18f, 18f' "$MAIN"
else
  grep -Fq 'val backdropUrl = AccountSession.authBackground(this@MainActivity)' "$MAIN"
  grep -Fq 'if (isTvLike()) tag = "bm_tv_profile_header_card"' "$MAIN"
fi
grep -Fq 'private fun accountProfileCard()' "$MAIN"
grep -Fq 'shape = GradientDrawable.OVAL' "$MAIN"
# Previous TV drawer click/focus fixes must remain intact.
bash verify_v7471_7_tv_drawer_offline_focus.sh
bash verify_v7471_8_tv_drawer_click_bridge.sh
grep -Eq 'V7\.47\.1\.(9|10|11|12|12\.1|12\.2|12\.3|13|14|16).*FULLSOURCE\.zip' "$WF"
grep -Fq 'verify_v7471_9_boxoffice_profile_unified_ui.sh' "$WF"
echo VERIFY_V7471_9_BOXOFFICE_PROFILE_UNIFIED_UI_OK
