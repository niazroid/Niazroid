#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
need() { grep -Fq "$2" "$1" || { echo "Missing V6.5 marker: $2" >&2; exit 1; }; }

# Weekly first-entry root fix: initial detached children are rebuilt while attached,
# and a failed first DOWN refreshes the same current day before retries.
need "$MAIN" 'private var tvHomeWeeklyRefreshAction: (() -> Unit)? = null'
need "$MAIN" 'weeklyAttachedInitialRenderDone'
need "$MAIN" 'tvHomeWeeklyRefreshAction?.invoke()'
need "$MAIN" 'changing day mysteriously made DOWN start working.'

# Continue Watching: real custom cards are focusable immediately; profile rail and
# full-list page get deterministic focus routes after attachment.
need "$MAIN" 'tag = "bm_tv_continue_card"'
need "$MAIN" 'if (isTvLike()) applyTvFocusHalo(this, 15, 1.045f, dp(2).toFloat())'
need "$MAIN" 'tag = "bm_tv_profile_continue_row"'
need "$MAIN" 'tag = "bm_tv_continue_full_list"'
need "$MAIN" 'wireTvVerticalSequence(live.ifEmpty { tvTargets })'
need "$MAIN" 'handleHomeHorizontalMediaRowFallback'

# Box Office must stay strict rank order; the geometry router must not overwrite it.
need "$MAIN" 'val wireBoxOffice = {'
need "$MAIN" 'coordinate-based bindings overwrote #1→#2'
need "$MAIN" '"boxoffice" -> content.findViewWithTag<View>("bm_tv_boxoffice_row_0")'
# Scope check: there must be no deterministic-surface call in showBoxOffice body.
python3 - "$MAIN" <<'PY'
import sys
from pathlib import Path
s=Path(sys.argv[1]).read_text()
a=s.index('private fun showBoxOffice()')
b=s.index('private fun showCollections()', a)
chunk=s[a:b]
for line in chunk.splitlines():
    stripped=line.strip()
    if stripped.startswith('wireTvDeterministicSurface(page)'):
        raise SystemExit('V6.5 guard failed: Box Office still uses geometry deterministic surface')
PY

# Advanced filters: Series/category can always go down through an explicit form chain.
need "$MAIN" 'fun wireAdvancedFiltersTvExact()'
need "$MAIN" 'lastTypeChip = chip'
need "$MAIN" 'requestTvFocusVerified(firstSelector ?: yearFromInput)'
need "$MAIN" 'advancedSelectorRows.getOrNull(index + 1) ?: yearFromInput'
need "$MAIN" 'bindTvDirectionalTarget(dubbedChip, android.view.KeyEvent.KEYCODE_DPAD_DOWN) { applyButton }'
need "$MAIN" 'rootView.postDelayed({ wireAdvancedFiltersTvExact() }, 180L)'

# Non-Home controls must never become a hard dead end merely because an explicit
# binding is absent; platform fallback is allowed outside the strict Home contract.
need "$MAIN" 'Other screens must NOT swallow a direction when our explicit'
need "$MAIN" 'return if (currentScreen == "home") {'
need "$MAIN" '} else false'

echo 'TV_FOCUS_SURFACES_V65_ROOT_OK'
