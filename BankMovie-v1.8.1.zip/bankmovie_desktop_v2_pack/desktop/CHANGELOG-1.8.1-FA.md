# BankMovie Desktop 1.8.1

- حذف نیاز به App Key/Secret ثابت از EXE
- اتصال محتوا از طریق desktop_api.php با امضای داخلی سمت سرور
- اتصال حساب/VIP/آواتار از طریق desktop_user_api.php
- رفع خطای «پیکربندی امن نسخه ویندوز ناقص است»
- بدون تغییر در مسیر Android
