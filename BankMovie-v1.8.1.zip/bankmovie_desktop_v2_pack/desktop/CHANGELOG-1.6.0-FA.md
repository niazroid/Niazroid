# BankMovie Desktop 1.6.0

- کاهش لایه‌های مات و گرادیان Hero و خوانایی بهتر CTAها.
- Header روی Hero شفاف است و فقط بعد از عبور کامل از Hero به حالت مشکی/solid می‌رود.
- دکمه مشاهده و جستجوی مشابه روی Hero؛ CTA مشاهده روی کارت‌ها.
- صفحه‌بندی واقعی برای sectionها، Search، ژانرها، Collections و داخل Collection.
- Categories مطابق سایت: ژانرها، کالکشن‌ها، 250 فیلم برتر IMDb و 250 سریال برتر IMDb.
- Collection renderer اختصاصی با cover_image واقعی و صفحه جزئیات Collection.
- بازیگران گرد در Detail و صفحه بازیگر با Hero و Filmography.
- Trailer داخل پنجره وب داخلی Electron باز می‌شود.
- Box Office از endpoint عمومی واقعی bankmovie.top/api_boxoffice.php دریافت می‌شود.
- فونت UI از نسخه میزبانی‌شده BankMovie روی bankmovie.top بارگذاری می‌شود؛ فایل فونت در بسته Desktop کپی نشده است.
