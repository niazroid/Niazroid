# BankMovie Windows 1.4.0

- حذف وضعیت «متصل به ...» از Title Bar.
- برند Title Bar به `BankMovie` تغییر کرد.
- بازطراحی Title Bar با استایل Premium BM / Neon Cinematic و دکمه‌های اختصاصی Minimize / Maximize / Close.
- حذف Search و Archive Select از Toolbar بالایی.
- جایگزینی Toolbar با منوی دسته‌بندی واقعی آرشیو فعال، بر اساس Remote Config سایت.
- حذف Watch Party از Drawer تا زمان تکمیل پلیر داخلی.
- افزودن نشان IMDb واقعی در صفحه جزئیات.
- حذف نمایش تکراری برچسب‌های Softsub / زیرنویس / دوبله در ردیف‌های کیفیت.
- حفظ اسلایدر اصلی سایت و ساختار آرشیوها از نسخه 1.3.0.
