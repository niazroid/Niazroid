# تنظیم امن Build ویندوز

از نسخه 1.8.0 دامنه و کلیدهای Desktop داخل سورس پروژه هاردکد نمی‌شوند.

قبل از اجرای GitHub Actions سه Secret زیر را در Repository > Settings > Secrets and variables > Actions بسازید:

- `BM_DESKTOP_DOMAIN`
- `BM_DESKTOP_APP_KEY`
- `BM_DESKTOP_APP_SECRET`

مقادیر App Key و App Secret باید دقیقاً با credential فعلی Desktop روی سرور هماهنگ باشند. مقدار آن‌ها را از فایل خصوصی سرور که برای Desktop auth استفاده می‌شود بردارید؛ این مقادیر را داخل repository یا فایل ZIP commit نکنید.

Workflow هنگام Build فایل `electron/runtime.generated.js` را به‌صورت موقت می‌سازد و سپس installer را تولید می‌کند.

نکته امنیتی: هر credentialی که یک کلاینت دسکتاپ برای درخواست امضاشده استفاده کند در باینری نهایی قابل بازیابی مهندسی معکوس است؛ بنابراین این تغییر کلیدها را از سورس عمومی و رابط کاربری حذف می‌کند، اما جایگزین کنترل سمت سرور، rate limit و امکان rotate کردن credential نیست.
