# BankMovie Desktop v1.8.0

- Archive 4 Windows facade با runtime صحیح SerialBlog هماهنگ شد (server hotfix جداگانه).
- سیاست VIP ویندوز از سیاست واقعی سایت/Android تبعیت می‌کند؛ Desktop defaults دیگر سایت را public نمی‌کنند.
- خطاهای داخلی API/PHP در UI کاربر نمایش داده نمی‌شوند.
- Controller/API/domain از صفحه Settings حذف شدند.
- credentialهای Desktop از سورس ZIP حذف شدند و در GitHub Actions از Secrets تزریق می‌شوند.
- مشاهده Slider مقاوم‌تر شد: target_id/api_detail/link parse و fallback جستجوی عنوان.
- کالکشن‌های Home با renderer مخصوص Collection باز می‌شوند.
- Avatar picker بلافاصله با cache باز می‌شود و refresh شبکه در پس‌زمینه انجام می‌شود.
- Download Manager: پوستر، تفکیک فیلم/سریال، سرعت، ETA، pause/resume/cancel فوری، بازکردن مستقیم فایل و پوشه.
- اعلان Native ویندوز هنگام شروع/پایان/لغو دانلود.
