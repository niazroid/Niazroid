#!/usr/bin/env bash
set -euo pipefail
python3 - <<'PYTEST'
from pathlib import Path
import re, zipfile, os
main = Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
workflow = Path('.github/workflows/build-bankmovie.yml').read_text()
branch = main[main.index('    private fun pushCurrentScreenForBack() {'):main.index('    private fun runBackNavigationMotion(')]
restored = main[main.index('    private fun restoreRetainedNavigationScreen('):main.index('    private fun pushCurrentScreenForBack()')]
home = main[main.index('    private fun showHome() {'):main.index('    private fun showHome() {')+8000]
assert re.search(r'if \(isTvLike\(\) && currentScreen == "home"\) \{\s*navigationHistory.add \{ restorer\(\) \}\s*if \(navigationHistory.size > 24\) navigationHistory.removeAt\(0\)\s*return@let',branch), 'TV Home must rebuild without retained children'
assert branch.index('if (isTvLike() && currentScreen == "home")') < branch.index('val retainedChildren'), 'Do not capture stale TV Home views'
assert 'snapshot.contentPaddingRight' not in restored, 'V22.5.7.6 TV shell restore needs to be rolled back'
assert 'wireHomePosterRows()' not in restored, 'Do not rewire stale Home poster views'
assert 'buildBottomNav()' in home and 'clear()' in home and 'setBottomNavVisibility(View.VISIBLE)' in home, 'Stable Home builder must reset TV shell'
assert 'tvHomeRailRegistry.clear()' in home and 'tvFocusIndexByScreen.remove("home")' in home, 'Old focus state must be reset'
assert 'R.drawable.bm_site_neon_collections' in main, 'Keep mobile-matched TV neon visuals'
assert 'private fun handleDiscoverTvDirectionalFocus' in main, 'Discover TV fix must remain'
assert 'currentScreen == "home" && parent is HorizontalBankmovieSmoothScrollView' not in main, 'Do not reintroduce V22.5.7.4 clipping override'
assert 'restoreRetainedTvHomeViewport' not in main, 'Do not reintroduce forced scroll restoration'
assert 'verify_v22_5_7_7_tv_home_v23_stable_return.sh' in workflow
source = re.search(r'^\s*SOURCE_ZIP:\s*(\S+)\s*$',workflow,re.M)
assert source and source.group(1).endswith('.zip'), 'Workflow must point to a source ZIP'
assert not os.environ.get('SOURCE_ZIP') or source.group(1) == os.environ['SOURCE_ZIP'], 'Workflow and source ZIP must match'
print('VERIFY_V22_5_7_7_TV_HOME_V23_STABLE_RETURN_OK')
PYTEST
