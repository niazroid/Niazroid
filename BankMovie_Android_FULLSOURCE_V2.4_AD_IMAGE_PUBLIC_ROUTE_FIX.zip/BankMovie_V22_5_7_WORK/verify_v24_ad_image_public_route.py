#!/usr/bin/env python3
from pathlib import Path
import tempfile, json, base64, subprocess
r=Path(__file__).resolve().parent/'server-required'
png=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAMAAAADCAIAAADZSiLoAAAAF0lEQVR4nGP0nf2KgYGBgYGBiQEGECwAMtMB2DIloQUAAAAASUVORK5CYII=')
with tempfile.TemporaryDirectory() as t:
 d=Path(t)
 for f in ['app_config.php','app_ad_image.php']:(d/f).write_bytes((r/f).read_bytes())
 (d/'includes').mkdir()
 (d/'includes/security_bootstrap.php').write_text('''<?php function bm_security_cors(...$p){} function bm_security_enforce_rate_limit(...$p){} function bm_security_client_ip(){return '127.0.0.1';}''')
 for f in ['archive_control.php','vip_sales.php']:(d/'includes'/f).write_text('<?php')
 (d/'v2/api').mkdir(parents=True)
 (d/'v2/api/app_config.php').write_bytes((r/'v2/api/app_config.php').read_bytes())
 (d/'v2/api/bm_security.php').write_text('''<?php function bm22_limit(...$p){return false;} function bm22_client_ip(){return '127.0.0.1';} function bm22_fail(...$p){http_response_code(429); exit;}''')
 imgs=d/'uploads/bm-app-ads';imgs.mkdir(parents=True)
 name='1234567890abcdef1234567890ab.png'; (imgs/name).write_bytes(png); imgs.chmod(0o750)
 config=d/'bankmovie_remote_config.json';config.write_text(json.dumps({'home_ad':{'image_url':'/uploads/bm-app-ads/'+name}}))
 for p in ['app_config.php','v2/api/app_config.php']:
  cmd=['php','-r',"$_GET['bm_home_ad_image']='1'; $_SERVER['REQUEST_METHOD']='GET'; require '"+str(d/p)+"';"]
  result=subprocess.run(cmd,capture_output=True)
  if result.returncode or result.stdout!=png: print('ERROR',p,result.stderr[:500],result.stdout[:200]);raise SystemExit(1)
  print('PASS public image through',p)
 config.write_text(json.dumps({'home_ad':{'image_url':'/uploads/bm-app-ads/../../etc/passwd'}}))
 result=subprocess.run(['php','-r',"$_GET['bm_home_ad_image']='1'; $_SERVER['REQUEST_METHOD']='GET'; require '"+str(d/'v2/api/app_config.php')+"';"],capture_output=True)
 assert not result.stdout, result.stdout[:100]
 print('PASS rejects unsafe image route')
print('BANKMOVIE_AD_IMAGE_CONFIG_PUBLIC_ROUTE_OK')
