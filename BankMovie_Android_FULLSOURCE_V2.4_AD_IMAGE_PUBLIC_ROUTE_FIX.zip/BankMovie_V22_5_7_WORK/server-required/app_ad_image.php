<?php
/**
 * Public image delivery for the active BankMovie home advertisement.
 * Deliberately accepts NO file/path arguments; only the image in the current
 * admin-controlled configuration can be served.  Fixes nginx 403 on an older
 * 0750 uploads directory without relaxing access to unrelated upload paths.
 */
declare(strict_types=1);
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('X-Robots-Tag: noindex, nofollow');
if (!in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', ['GET', 'HEAD'], true)) {
    header('Allow: GET, HEAD'); http_response_code(405); exit;
}
$root = __DIR__;
$raw = @file_get_contents($root . '/bankmovie_remote_config.json');
$config = is_string($raw) ? json_decode($raw, true) : null;
$path = is_array($config) ? trim((string)($config['home_ad']['image_url'] ?? '')) : '';
if (!preg_match('~^/uploads/bm-app-ads/([a-f0-9]{28})\.(jpg|png|webp|gif)$~iD', $path, $parts)) {
    http_response_code(404); exit;
}
$dir = realpath($root . '/uploads/bm-app-ads');
if ($dir === false) { http_response_code(404); exit; }
$file = realpath($dir . DIRECTORY_SEPARATOR . $parts[1] . '.' . $parts[2]);
if ($file === false || dirname($file) !== $dir || !is_file($file) || !is_readable($file)) {
    http_response_code(404); exit;
}
$size = filesize($file);
if ($size === false || $size <= 0 || $size > 4 * 1024 * 1024) {
    http_response_code(404); exit;
}
$info = @getimagesize($file);
$mime = is_array($info) ? ($info['mime'] ?? '') : '';
if (!in_array($mime, ['image/jpeg','image/png','image/webp','image/gif'], true)) {
    http_response_code(404); exit;
}
header('Content-Type: ' . $mime);
header('Content-Length: ' . $size);
header('Cache-Control: public, max-age=300, must-revalidate');
$etag = '"' . hash('sha256', $parts[1] . ':' . $size . ':' . filemtime($file)) . '"';
header('ETag: ' . $etag);
if (trim($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $etag) {
    http_response_code(304); exit;
}
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'HEAD') exit;
readfile($file);
