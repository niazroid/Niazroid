/* Continue watching: native MPV timestamps, no stored stream links. */
function bmContinueIdentity(d,s={}){
  if(!d||!itemId(d))return undefined;
  return {id:String(itemId(d)),archive:Number(d.target_archive||d.archive||s.archive||state.archive),type:bm196Type(d),title:itemTitle(d),poster:bm196Poster(d),backdrop:cleanUrl(d.backdrop||d.background||d.backdrop_url||''),genres:d.genres_fa||d.genres||d.genre_fa||d.genre||d.genre_names||[]};
}
function bmContinueTime(seconds){const n=Math.max(0,Math.floor(Number(seconds)||0));return (n>=3600?String(Math.floor(n/3600))+':':'')+String(Math.floor(n/60)%60).padStart(2,'0')+':'+String(n%60).padStart(2,'0');}
function bmContinueEnglish(){return (state.language||bm191Language)==='en';}
function bmContinueLabel(r){return r.type==='series'?(bmContinueEnglish()?`S${r.season} · E${r.episode}`:`فصل ${r.season} • قسمت ${r.episode}`):bmContinueEnglish()?'Movie':'فیلم';}
let bmContinueBusy=false;
async function bmContinuePlay(r){
  if(bmContinueBusy)return;bmContinueBusy=true;
  try{
    if(!enabledArchives().includes(r.archive))throw Error('این آرشیو در حال حاضر در دسترس نیست.');
    if(!(await ensureVipAccess(r.archive,'browse'))||!(await ensureVipAccess(r.archive,'stream')))return;
    const response=await bmContent('detail',{archive:r.archive,id:r.id,type:r.type,no_cache:true});
    const d=response?.item||response;
    if(!d)throw Error('عنوان پیدا نشد.');
    const raw=d.play?.links||d.downloads||d.links||[];
    const all=r.type==='series'?seriesStructure(d,raw).flatMap(season=>season.episodes.flatMap(episode=>episode.links.map(link=>({...link,season:season.season,episode:episode.episode})))):Array.isArray(raw)?raw:[];
    const sources=dedupeSources(all).filter(s=>s.url&&!s.is_folder&&s.is_playable!==false);
    // Older builds sometimes saved missing season/episode fields as zero. The privileged matcher accepts only an unambiguous exact URL in that case.
    const idx=await bridge.continueMatch(r.key,sources.map(s=>({url:s.url,season:s.season,episode:s.episode,quality:s.quality,sourceType:s.type||s.type_fa||''})));
    const s=sources[idx];if(!s)throw Error('نسخه پخش قبلی دیگر موجود نیست؛ از صفحه فیلم یک کیفیت انتخاب کن.');
    if(!(await ensureVipAccess(Number(s.archive||r.archive),'stream')))return;
    const result=await bridge.playExternal({url:s.url,subtitleUrl:subtitleUrlOf(s),preferredPlayer:'bm-mpv',title:itemTitle(d),accent:bmPlayerAccent(),season:s.season||null,episode:s.episode||null,quality:s.quality||'',sourceType:s.type||s.type_fa||'',history:{...bmContinueIdentity(d),id:r.id,type:r.type,archive:r.archive,poster:bm196Poster(d)||r.poster},resumeKey:r.key});
    if(result?.ok)toast(`${bmContinueEnglish()?'Resumed at':'ادامه پخش از'} ${bmContinueTime(r.position)}${result.httpFallback?' • HTTP':''}`,'ok');
  }catch(e){toast(e.message||String(e),'error')}finally{bmContinueBusy=false;}
}
let bmContinueRefreshId=0;
async function bmContinueRefresh(){
  if(!bridge.continueList)return;
  const seq=++bmContinueRefreshId,home=$('#view .home-content'),detail=$('#view .detail .actions');
  if(!home&&!detail)return;
  if(!feature('external_player_fallback_enabled',true)){home?.querySelector('.bm-continue-section')?.remove();detail?.querySelector('.bm-continue-detail')?.remove();return;}
  let rows;try{rows=await bridge.continueList()}catch{return;}
  if(seq!==bmContinueRefreshId)return;
  const en=bmContinueEnglish(),label=en?'Continue watching':'ادامه تماشا';
  if(home?.isConnected){
    const visible=rows.filter(r=>enabledArchives().includes(r.archive));let section=home.querySelector('.bm-continue-section');
    if(!visible.length){section?.remove();return;}
    if(!section){section=document.createElement('section');section.className='bm-continue-section section';section.setAttribute('aria-label',label);const archive=home.querySelector('.archive-hub');if(archive)archive.after(section);else home.prepend(section);}
    const sig=JSON.stringify([en,visible.map(r=>[r.key,Math.floor(r.position),Math.floor(r.duration),r.started])]);
    if(section.dataset.signature===sig||section.querySelector('.bm-poster-dragging'))return;
    const oldScroll=section.querySelector('.rail')?.scrollLeft||0;section.dataset.signature=sig;
    section.innerHTML=`<div class="section-head"><h2 class="bm-continue-heading"><span>${icon('play')}</span>${label}</h2></div><div class="rail bm-continue-rail">${visible.map((r,i)=>{const progress=Math.max(0,Math.min(100,r.position/r.duration*100));return `<article class="bm-continue-card"><button class="bm-continue-play" type="button" data-continue-index="${i}" aria-label="${esc(label+' '+r.title)}"><div class="bm-continue-poster">${r.poster?img(r.poster,r.title):''}<span class="bm-continue-overlay">${icon('play')}</span><span class="bm-continue-time" dir="ltr">${bmContinueTime(r.position)} / ${bmContinueTime(r.duration)}</span><span class="bm-continue-progress" role="progressbar" aria-valuenow="${Math.floor(progress)}" aria-valuemin="0" aria-valuemax="100"><i style="width:${progress}%"></i></span></div><span class="bm-continue-title">${esc(r.title)}</span><small>${esc(bmContinueLabel(r))}${r.quality?' • '+esc(r.quality):''}</small></button><button type="button" class="bm-continue-remove" data-continue-remove="${i}" title="${en?'Remove from continue watching':'حذف از ادامه تماشا'}" aria-label="${en?'Remove':'حذف'}">×</button></article>`;}).join('')}</div>`;
    section.querySelector('.rail').scrollLeft=oldScroll;
    section.querySelectorAll('[data-continue-index]').forEach(b=>b.onclick=()=>bmContinuePlay(visible[Number(b.dataset.continueIndex)]));
    section.querySelectorAll('[data-continue-remove]').forEach(b=>b.onclick=async()=>{try{await bridge.continueRemove(visible[Number(b.dataset.continueRemove)].key);await bmContinueRefresh()}catch(e){toast(e.message,'error')}});
  }
  if(detail?.isConnected){
    const d=state.currentDetail,id=bmContinueIdentity(d),r=id&&rows.find(x=>x.id===id.id&&x.archive===id.archive&&x.type===id.type);
    let btn=detail.querySelector('.bm-continue-detail');if(!r){btn?.remove();return;}
    if(!btn){btn=document.createElement('button');btn.type='button';btn.className='btn primary bm-continue-detail';detail.querySelector('#playBest')?.after(btn);}
    btn.innerHTML=`${icon('play')}<span>${label} <bdi>${bmContinueTime(r.position)}</bdi>${r.type==='series'?' · '+esc(bmContinueLabel(r)):''}</span>`;btn.onclick=()=>bmContinuePlay(r);
  }
}
const bmContinueRenderHome=renderHome;renderHome=function(...args){const r=bmContinueRenderHome(...args);void bmContinueRefresh();return r;};
const bmContinueRenderDetail=renderDetail;renderDetail=function(...args){const r=bmContinueRenderDetail(...args);void bmContinueRefresh();return r;};
const bmContinueProfileUpdate=updateProfile;updateProfile=function(...args){const r=bmContinueProfileUpdate(...args);document.querySelector('.bm-continue-section')?.remove();document.querySelector('.bm-continue-detail')?.remove();void bmContinueRefresh();return r;};
window.addEventListener('focus',()=>void bmContinueRefresh());
document.addEventListener('visibilitychange',()=>{if(!document.hidden)void bmContinueRefresh()});
// MPV is a separate native process. Refresh visible history while it is playing,
// without network calls or repainting an unchanged rail.
setInterval(()=>{if(!document.hidden)void bmContinueRefresh()},5000);
