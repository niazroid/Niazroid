/* Website profile.php picker, ported to the authenticated desktop bridge. */
(()=>{
  const check='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 6L9 17l-5-5"/></svg>';
  const closeIcon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>';
  const userIcon='<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="2" y="3" width="20" height="18" rx="5" fill="currentColor" opacity=".23"/><circle cx="10" cy="9" r="3" fill="currentColor"/><path d="M4.5 17c0-3 2.4-5 5.5-5s5.5 2 5.5 5v1h-11z" fill="currentColor" opacity=".75"/><circle cx="18" cy="16" r="4" fill="currentColor"/><path d="M16.2 16l1.2 1.2 2.3-2.5" stroke="var(--accent,#327cf6)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/></svg>';
  let current=null;
  // users.avatar is authoritative: website may have left an older avatar_key in the row.
  function selectedKey(user){
    const value=String(user?.avatar||user?.avatar_url||'');
    if(value){const match=value.match(/\/assets\/avatars\/(?:avatar_)?([a-z]+_\d+)\.webp(?:[?#].*)?$/i)||value.match(/^assets\/avatars\/(?:avatar_)?([a-z]+_\d+)\.webp(?:[?#].*)?$/i);return match?match[1].toLowerCase():'';}
    return String(user?.avatar_key||'');
  }
  function close(restore=true){if(!current)return;const {root,previous}=current;current=null;root.remove();document.body.classList.remove('avatar-picker-open');if(restore&&previous?.isConnected)previous.focus();}
  function show(){
    if(!state.user){showAuthModal();return;}
    if(current){current.root.querySelector('#closeAvatarPickerBtn').focus();return;}
    const en=(state.language||document.documentElement.lang)==='en', t=(fa,eng)=>en?eng:fa;
    const selected=selectedKey(state.user), owner=state.user.id;
    const root=document.createElement('div');root.id='avatarPickerModal';root.className='avatar-picker-modal is-open';root.dir=en?'ltr':'rtl';root.setAttribute('role','dialog');root.setAttribute('aria-modal','true');root.setAttribute('aria-labelledby','avatarPickerTitle');
    root.innerHTML=`<button type="button" class="avatar-picker-backdrop" id="avatarPickerBackdrop" tabindex="-1" aria-label="${t('بستن','Close')}"></button><section class="avatar-picker-panel"><header class="avatar-picker-head"><div class="avatar-picker-title"><span class="avatar-picker-title-icon">${userIcon}</span><span><strong id="avatarPickerTitle">${t('انتخاب آواتار بانک مووی','Choose BankMovie Avatar')}</strong><span>${t('یک شخصیت آماده انتخاب کن؛ تغییر بلافاصله در پروفایل و Watch Party دیده می‌شود.','Choose a preset; it appears in your profile and Watch Party.')}</span></span></div><button type="button" class="avatar-picker-close" id="closeAvatarPickerBtn" aria-label="${t('بستن','Close')}">${closeIcon}</button></header><div class="bm-avatar-status" role="status" aria-live="polite" hidden></div><div class="avatar-picker-body"><div class="avatar-picker-grid">${BM_SITE_AVATARS.map(a=>`<div class="avatar-preset-form"><button type="button" data-avatar-key="${a.key}" class="avatar-preset-btn${a.key===selected?' is-selected':''}" aria-pressed="${a.key===selected}" aria-label="${esc(en?a.en:a.fa)}"><span class="avatar-preset-check">${check}</span><img class="avatar-preset-img" src="${a.path}" alt="" loading="lazy" decoding="async"><span class="avatar-preset-name">${esc(en?a.en:a.fa)}</span></button></div>`).join('')}</div></div><footer class="avatar-picker-foot"><p>${t('آواتارهای آماده برای همه اعضا فعال‌اند. بارگذاری تصویر شخصی از گالری مخصوص اعضای VIP است.','Presets are available to everyone. Custom image upload is reserved for VIP members.')}</p>${state.user.can_upload_avatar?`<label for="avatarSiteUpload" class="avatar-picker-vip-btn"><span class="vip-mini-badge">VIP</span>${t('آپلود تصویر خودم','Upload My Image')}</label><input type="file" id="avatarSiteUpload" accept="image/png,image/jpeg,image/webp,image/gif" hidden>`:`<button type="button" class="avatar-picker-vip-btn" id="avatarSiteVip"><span class="vip-mini-badge">VIP</span>${t('ویژه اعضای VIP','VIP Exclusive')}</button>`}</footer></section>`;
    current={root,previous:document.activeElement,busy:false};document.body.append(root);document.body.classList.add('avatar-picker-open');
    const session=current, status=root.querySelector('.bm-avatar-status');
    function error(msg){status.textContent=msg;status.hidden=false;}
    function setBusy(value){session.busy=value;root.querySelectorAll('.avatar-preset-btn,#avatarSiteUpload,#avatarSiteVip').forEach(b=>b.disabled=value);root.setAttribute('aria-busy',String(value));}
    async function save(action,body){
      if(session.busy||current!==session||state.user?.id!==owner)return;
      setBusy(true);status.hidden=true;
      try{const r=await bridge.user(action,body,'POST');if(!r?.success||!r.user)throw Error(r?.message||t('ذخیره آواتار ناموفق بود.','Avatar could not be saved.'));if(state.user?.id!==owner)return;state.user=r.user;updateProfile();if(current===session)close(false);if(state.lastView==='profile')renderProfile();toast(t('آواتار روی حساب ذخیره و همگام شد','Avatar saved and synced'),'ok');}
      catch(e){if(current===session){error(publicUiError(e));setBusy(false);}}
    }
    root.querySelector('#closeAvatarPickerBtn').onclick=()=>close();root.querySelector('#avatarPickerBackdrop').onclick=()=>close();
    root.querySelector('.avatar-picker-grid').addEventListener('click',e=>{const b=e.target.closest('[data-avatar-key]');if(b)void save('avatar_update',{avatar_key:b.dataset.avatarKey});});
    const vip=root.querySelector('#avatarSiteVip');if(vip)vip.onclick=()=>{close(false);showVipPlansModal();};
    const upload=root.querySelector('#avatarSiteUpload');if(upload)upload.onchange=()=>{const f=upload.files?.[0];if(!f||session.busy)return;if(f.size>4*1024*1024||!['image/png','image/jpeg','image/webp','image/gif'].includes(f.type)){error(t('فرمت تصویر یا حجم آن معتبر نیست (حداکثر ۴ مگابایت).','Invalid image or file exceeds 4 MB.'));upload.value='';return;}const rd=new FileReader();rd.onerror=()=>error(t('خواندن تصویر ناموفق بود.','Could not read image.'));rd.onload=()=>void save('avatar_upload',{image_base64:rd.result});rd.readAsDataURL(f);};
    root.querySelector('#closeAvatarPickerBtn').focus();if(selected){const b=root.querySelector('.is-selected');if(b){const sc=root.querySelector('.avatar-picker-body');sc.scrollTop=Math.max(0,b.offsetTop-sc.offsetTop-12);}}
  }
  showAvatarModal=async function(){show();};
  document.addEventListener('keydown',e=>{if(!current)return;if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();close();}else if(e.key==='Tab'){const items=[...current.root.querySelectorAll('button:not([disabled]):not([tabindex="-1"]),input:not([hidden]):not([disabled])')];if(!items.length)return;const first=items[0],last=items[items.length-1];if(e.shiftKey&&(document.activeElement===first||!current.root.contains(document.activeElement))){e.preventDefault();last.focus();}else if(!e.shiftKey&&(document.activeElement===last||!current.root.contains(document.activeElement))){e.preventDefault();first.focus();}}},true);
  const sync=bmSyncProfileMenu;bmSyncProfileMenu=function(){sync();const b=document.getElementById('bmAvatarMenu');if(b)b.hidden=!state.user;};
  const menuGlyph=document.querySelector('#bmAvatarMenu .bm-menu-icon');if(menuGlyph){menuGlyph.removeAttribute('data-svg-icon');menuGlyph.innerHTML=userIcon;}
  document.getElementById('bmAvatarMenu').addEventListener('click',()=>{bmCloseProfileMenu();show();});
})();
