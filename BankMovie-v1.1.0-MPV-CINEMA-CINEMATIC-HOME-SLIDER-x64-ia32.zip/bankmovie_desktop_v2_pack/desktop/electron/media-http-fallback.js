'use strict';
const {isIP}=require('node:net');
const tlsError=/^(?:CERT_[A-Z_]+|ERR_TLS_CERT_[A-Z_]+|DEPTH_ZERO_SELF_SIGNED_CERT|SELF_SIGNED_CERT_IN_CHAIN|UNABLE_TO_VERIFY_LEAF_SIGNATURE|UNABLE_TO_GET_ISSUER_CERT(?:_LOCALLY)?|ERR_SSL_WRONG_VERSION_NUMBER|ERR_SSL_UNSUPPORTED_PROTOCOL|ERR_SSL_TLSV1_ALERT_PROTOCOL_VERSION)$/;
function candidate(raw,protectedOrigins=[]){
  try{const u=new URL(raw),host=u.hostname.toLowerCase().replace(/\.$/,'');
    if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash||u.port||!host.includes('.')||isIP(host)||/\.(?:local|localhost|internal|lan|test|onion)$/.test(host)||!/^[-a-z0-9.]+$/.test(host)||!(/\.(?:mp4|mkv|webm|avi|mov|m4v|mp3|m4a|aac|flac|mka|ts)$/i.test(u.pathname)))return null;
    if(protectedOrigins.some(origin=>{try{const h=new URL(origin).hostname.toLowerCase();return host===h||host.endsWith('.'+h)}catch{return false}}))return null;
    if(/(?:^|\/)(?:api|auth|login|account|token|signed|private|secure|v1|v2)(?:\/|$)/i.test(u.pathname))return null;
    u.protocol='http:';return u.toString();
  }catch{return null}
}
// MPV receives only a pre-approved direct-media alternative from the trusted main process.
// HTTP links retain their original scheme; an upgrade may be tried after a real network failure.
function playbackAlternative(raw,{enabled=true,protectedOrigins=[]}={}){
  if(!enabled)return '';
  try{const u=new URL(raw);if(u.protocol==='https:')return candidate(raw,protectedOrigins)||'';
    if(u.protocol!=='http:')return '';
    u.protocol='https:';return candidate(u.toString(),protectedOrigins)?u.toString():'';
  }catch{return ''}
}
function downloadFailureAlternative(raw,error,options={}){
  const alt=playbackAlternative(raw,options);if(!alt)return '';
  const code=String(error||'').replace(/^net::/,'');
  if(/^https:/i.test(raw))return /^(?:ERR_CERT_[A-Z_]+|ERR_SSL_(?:PROTOCOL_ERROR|VERSION_OR_CIPHER_MISMATCH)|ERR_TLS_CERT_[A-Z_]+)$/.test(code)?alt:'';
  return /^(?:ERR_CONNECTION_(?:REFUSED|RESET|TIMED_OUT|CLOSED)|ERR_ADDRESS_UNREACHABLE|ERR_NETWORK_UNREACHABLE|ERR_TIMED_OUT)$/.test(code)?alt:'';
}
function certificateFailure(e){return tlsError.test(String(e?.cause?.code||e?.code||''));}
async function probe(url,fetcher=fetch){
  const c=new AbortController();const timer=setTimeout(()=>c.abort(),7000);
  try{const r=await fetcher(url,{method:'GET',headers:{Range:'bytes=0-0'},redirect:'manual',credentials:'omit',cache:'no-store',signal:c.signal});
    const type=String(r.headers?.get('content-type')||'').split(';')[0].toLowerCase();
    try{await r.body?.cancel()}catch{}
    return {status:r.status,media:/^(?:video\/|audio\/|application\/(?:octet-stream|x-matroska|mp4))/.test(type)};
  }finally{clearTimeout(timer)}
}
async function resolve(raw,{enabled=true,protectedOrigins=[],check=probe}={}){
  // Native HTTP sources (e.g. archive 5) and other ineligible URLs pass through unchanged.
  const alt=enabled&&candidate(raw,protectedOrigins);if(!alt)return {url:raw,fallback:false};
  try{await check(raw);return {url:raw,fallback:false};}catch(e){if(!certificateFailure(e))return {url:raw,fallback:false};}
  try{const r=await check(alt);if([200,206].includes(r.status)&&r.media)return {url:alt,fallback:true};}catch{}
  return {url:raw,fallback:false};
}
module.exports={candidate,playbackAlternative,downloadFailureAlternative,certificateFailure,probe,resolve};
