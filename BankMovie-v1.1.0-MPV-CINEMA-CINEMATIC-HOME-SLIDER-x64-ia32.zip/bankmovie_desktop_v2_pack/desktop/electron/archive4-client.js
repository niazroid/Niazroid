'use strict';
const actions=new Set(['section','search','live_search','detail','play']);
function paramsFor(action,p={}){
  const out={client:'app'};
  if(action==='section'){
    const aliases={updated_movies:'new_movies',movies:'new_movies',movie:'new_movies',updated_series:'new_series',series:'new_series',animation:'updated_animations',animations:'updated_animations',anime:'updated_anime'};
    const s=String(p.section||'new_movies');return {...out,section:aliases[s]||s,page:p.page||1};
  }
  if(action==='detail'||action==='play')return {...out,...(p.url?{url:p.url}:{id:p.id||p.slug})};
  for(const k of ['page','sort','type','genre','country','director','actor','year','yearse','fromYear','toYear','rates','rating','imdbScore','score','lang','dubbed','subtitle','playonline'])if(p[k]!==undefined&&p[k]!==null&&p[k]!==''&&p[k]!==false)out[k]=p[k];
  return {...out,s:p.q||p.s||''};
}
function card(m){const id=m.detail_id||m.slug||m.id||m.source_post_id||'';return {...m,archive:4,id:m.id||id,detail_id:m.detail_id||id,type:m.type||'movie',backdrop:m.backdrop||m.poster||''};}
function normalize(action,p,raw){
  if(!raw||raw.success===false||['error','disabled','denied','forbidden'].includes(String(raw.status||'').toLowerCase()))throw Error(raw?.message||'آرشیو ۴ در دسترس نیست یا دسترسی آن محدود است.');
  if(action==='detail'||action==='play'){
    const d=card(raw.item||raw);if(!d.id&&!d.detail_id)throw Error('اطلاعات عنوان در آرشیو ۴ موجود نیست.');
    const links=(Array.isArray(d.downloads)?d.downloads:Array.isArray(d.links)?d.links:[]).filter(x=>x&&typeof x==='object').map(x=>({...x,archive:4}));
    const play={...(d.play||{}),links,has_series_structure:d.type==='series'};
    return action==='detail'?{status:'success',action,archive:4,item:{...d,downloads:links,links,play}}:{status:'success',action,archive:4,id:d.id,title:d.title,title_fa:d.title_fa,type:d.type,poster:d.poster,trailer_url:d.trailer_url||d.trailer,play};
  }
  const rows=raw.movies||raw.items||raw.results||[];const limit=Math.max(1,Math.min(60,Number(p.limit)||24));const items=(Array.isArray(rows)?rows:[]).filter(x=>x&&typeof x==='object').slice(0,limit).map(card);
  return {...raw,action,archive:4,items,results:items};
}
module.exports={supports:(a,p)=>Number(p?.archive)===4&&actions.has(a),paramsFor,normalize};
