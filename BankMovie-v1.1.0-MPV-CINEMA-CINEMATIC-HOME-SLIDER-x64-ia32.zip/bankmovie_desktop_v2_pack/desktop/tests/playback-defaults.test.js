'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const main=fs.readFileSync('electron/main.js','utf8'),app=fs.readFileSync('src/app.js','utf8');
let disk={preferredPlayer:'vlc',authToken:'encrypted-example',downloadDir:'D:/Movies',preferredArchive:5};let writes=0;
let players=[{id:'vlc'},{id:'bm-mpv'}];
const ctx={readState:()=>({...disk}),writeState:patch=>{writes++;disk={...disk,...patch};return {...disk}},app:{getPath:()=>'/downloads'},downloaderSettings:()=>({}),detectPlayers:()=>players};vm.createContext(ctx);
vm.runInContext(main.slice(main.indexOf('function bmPlaybackDefaults()'),main.indexOf('function normalizeBase('))+'\n'+main.slice(main.indexOf('function selectedPlayer('),main.indexOf('async function materializeSubtitle(')),ctx);
assert.equal(ctx.settings().preferredPlayer,'bm-mpv');assert.equal(ctx.settings().mediaHttpFallback,true);assert.equal(disk.authToken,'encrypted-example');assert.equal(disk.downloadDir,'D:/Movies');assert.equal(disk.preferredArchive,5);assert.equal(writes,1);
assert.equal(ctx.selectedPlayer().id,'bm-mpv');
// Explicitly re-saved external preference and opt-out remain after restart.
disk.preferredPlayer='potplayer';disk.mediaHttpFallback=false;assert.equal(ctx.settings().preferredPlayer,'potplayer');assert.equal(ctx.settings().mediaHttpFallback,false);assert.equal(writes,1);
// Older explicit opt-out is not silently overridden.
disk={preferredPlayer:'kmplayer',mediaHttpFallback:false};assert.equal(ctx.settings().preferredPlayer,'bm-mpv');assert.equal(ctx.settings().mediaHttpFallback,false);
// Fresh install.
disk={};assert.equal(ctx.settings().preferredPlayer,'bm-mpv');assert.equal(ctx.settings().mediaHttpFallback,true);
players=[{id:'vlc'}];assert.equal(ctx.selectedPlayer(),null);assert.equal(ctx.selectedPlayer('vlc').id,'vlc');assert.equal(ctx.selectedPlayer('auto').id,'vlc');
assert.match(main,/bmHandle\('settings:set', \(_e, patch\) => \{\s*bmPlaybackDefaults\(\);\s*writeState/);
assert.match(main,/const pref = String\(settings\(\)\.preferredPlayer \|\| 'bm-mpv'\)/);
assert.match(app,/id="bmMediaHttpFallback" \$\{state\.settings\.mediaHttpFallback!==false\?/);
console.log('PASS: one-time native-player migration, saved choices retained, HTTP default on, explicit opt-out respected');
