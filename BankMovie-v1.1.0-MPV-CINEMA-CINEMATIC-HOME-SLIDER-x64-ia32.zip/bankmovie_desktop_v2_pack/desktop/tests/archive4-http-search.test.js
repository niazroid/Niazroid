'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),http=require('node:http');
const archive=require('../electron/archive4-client'),transport=require('../electron/media-http-fallback');
const main=fs.readFileSync('electron/main.js','utf8'),app=fs.readFileSync('src/app.js','utf8'),html=fs.readFileSync('src/index.html','utf8');
assert.match(html,/<button type="submit" class="header-search-icon bm1118-search-icon"/);assert.match(app,/form\.onsubmit=e=>\{e\.preventDefault\(\);.*showSearch/);
assert.match(app,/bm-party-create-dialog/);assert.match(app,/bmMediaHttpFallback/);
assert.deepEqual(archive.paramsFor('section',{archive:4,section:'updated_series',page:2}),{client:'app',section:'new_series',page:2});
assert.deepEqual(archive.paramsFor('detail',{archive:4,id:'film-1'}),{client:'app',id:'film-1'});
assert.deepEqual(archive.paramsFor('search',{archive:4,q:'Example',page:3,imdbScore:7,dubbed:1}),{client:'app',page:3,imdbScore:7,dubbed:1,s:'Example'});
const list=archive.normalize('section',{limit:1},{status:'success',movies:[{slug:'test',poster:'p'},{id:'2'}]});assert.equal(list.items.length,1);assert.equal(list.items[0].archive,4);assert.equal(list.items[0].detail_id,'test');
const locked={status:'success',id:3,type:'series',downloads:[{url:'',vip_locked:true}]};const detail=archive.normalize('detail',{},locked);assert.equal(detail.item.play.links[0].url,'');assert.equal(detail.item.play.links[0].vip_locked,true);
assert.throws(()=>archive.normalize('section',{}, {status:'disabled'}));assert.throws(()=>archive.normalize('section',{}, {success:false}));assert.equal(archive.supports('collections',{archive:4}),false);
const calls=[];let raw={status:'success',movies:[{id:1}]};const context={BMArchive4:archive,loadRemoteConfig:async()=>({desktop:{enabled:true},desktop_api_url:'https://bankmovie.top/v1/desktop_api.php'}),windowsV1ApiBase:()=> 'https://bankmovie.top/v1',loadToken:()=> 'mock-token',DEFAULT:{apiUrl:'https://bankmovie.top/v1/desktop_api.php'},fetchJson:async(url,opts)=>{calls.push({url,opts});return raw},URL};vm.createContext(context);vm.runInContext(main.slice(main.indexOf('function queryUrl('),main.indexOf('// The weekly schedule is served')),context);
const u='https://cdn.example.org/movie.mkv';const alt='http://cdn.example.org/movie.mkv';const cert=Object.assign(new Error('fetch failed'),{cause:{code:'CERT_HAS_EXPIRED'}});
(async()=>{
 const r=await context.contentRequest('section',{archive:4,section:'new_movies'});assert.equal(r.items[0].id,1);assert.equal(new URL(calls[0].url).pathname,'/v1/api4.php');assert.equal(new URL(calls[0].url).searchParams.has('archive'),false);assert.equal(calls[0].opts.headers.Authorization,'Bearer mock-token');
 raw={status:'disabled'};await assert.rejects(()=>context.contentRequest('section',{archive:4,section:'new_movies'}));assert.equal(calls.length,2,'no retry around access denial');
 assert.equal(transport.candidate(u),alt);for(const x of [u+'?token=123',u+'#hash','https://user:pass@cdn.example.org/movie.mkv','https://cdn.example.org/api/movie.mkv','https://127.0.0.1/movie.mkv','https://cdn.example.org:8443/movie.mkv','https://cdn.example.org/player.m3u8','https://bankmovie.top/movie.mkv','https://sub.bankmovie.top/movie.mkv'])assert.equal(transport.candidate(x,['https://bankmovie.top']),null,x);
 let seen=[];const check=async(url)=>{seen.push(url);if(url===u)throw cert;return {status:206,media:true}};
 assert.deepEqual(await transport.resolve(u,{enabled:false,check}),{url:u,fallback:false});assert.deepEqual(seen,[]);
 assert.deepEqual(await transport.resolve(u,{check}),{url:alt,fallback:true});assert.deepEqual(seen,[u,alt]);
 seen=[];for(const original of [alt,alt+'?token=original','http://cdn.example.org:8080/movie.mkv','http://cdn.example.org/media/no-extension'])assert.deepEqual(await transport.resolve(original,{check}),{url:original,fallback:false});assert.deepEqual(seen,[],'original HTTP source must not be rewritten or probed');
 assert.deepEqual(await transport.resolve(u,{check:async url=>{seen.push(url);return {status:206,media:true}}}),{url:u,fallback:false});assert.deepEqual(seen,[u]);
 seen=[];assert.deepEqual(await transport.resolve(u,{enabled:true,check:async url=>{seen.push(url);return {status:403,media:false}}}),{url:u,fallback:false});assert.deepEqual(seen,[u]);
 for(const error of [new Error('network'),Object.assign(new Error('timeout'),{code:'ETIMEDOUT'})]){seen=[];assert.equal((await transport.resolve(u,{enabled:true,check:async url=>{seen.push(url);throw error}})).fallback,false);assert.deepEqual(seen,[u]);}
 assert.equal((await transport.resolve(u,{enabled:true,check:async url=>{if(url===u)throw cert;return {status:302,media:true}}})).fallback,false);
 assert.equal((await transport.resolve(u,{enabled:true,check:async url=>{if(url===u)throw cert;return {status:200,media:false}}})).fallback,false);
 // Actual range probe, no full download, no cookies or authentication headers.
 const server=http.createServer((req,res)=>{assert.equal(req.headers.range,'bytes=0-0');assert.equal(req.headers.cookie,undefined);assert.equal(req.headers.authorization,undefined);res.writeHead(206,{'Content-Type':'video/mp4','Content-Range':'bytes 0-0/2'});res.end('a');});await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));try{assert.deepEqual(await transport.probe(`http://127.0.0.1:${server.address().port}/sample.mp4`),{status:206,media:true});}finally{await new Promise(resolve=>server.close(resolve));}
 assert.match(main,/BMNativePlayer\.launch\(player,url/);assert.match(main,/if\(approved\)bmGetHttpMediaSession\(\)\.downloadURL\(target\)/);assert.match(main,/windowsV1AuthHeaders\(url, options\)/);
 console.log('PASS: signed archive 4 route, restricted optional TLS fallback, real range probe, clickable search and creation dialog');
})().catch(e=>{console.error(e);process.exitCode=1});
