// Real MPV smoke on Windows CI. The localhost alternate is injected only in this
// isolated test; the production public-media policy rejects localhost/IP addresses.
'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),http=require('node:http'),https=require('node:https');
const {spawn,spawnSync}=require('node:child_process');const P=require('../electron/mpv-player');
assert.equal(process.platform,'win32');const player=P.bundledPlayer('',false,path.resolve(__dirname,'..'));assert.ok(player);
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'bm-media-tls-test-'));
const servers=[];let child;
const listen=server=>new Promise((resolve,reject)=>{servers.push(server);server.once('error',reject);server.listen(0,'127.0.0.1',()=>resolve(server.address().port));});
(async()=>{try{
 const key=path.join(temp,'test-key.pem'),cert=path.join(temp,'test-cert.pem');
 const candidates=['openssl',path.join(process.env.ProgramFiles||'C:\\Program Files','Git','usr','bin','openssl.exe')];
 let made=false;for(const exe of candidates){const r=spawnSync(exe,['req','-x509','-newkey','rsa:2048','-nodes','-keyout',key,'-out',cert,'-days','1','-subj','/CN=localhost'],{windowsHide:true,stdio:'ignore',timeout:15000});if(r.status===0){made=true;break;}}
 assert.ok(made,'OpenSSL must be available for temporary self-signed test certificate');
 const video=fs.readFileSync(path.join(__dirname,'mpv-smoke.mkv'));let clearRequests=0,secureRequests=0;
 function serve(req,res){let a=0,b=video.length-1;const range=/^bytes=(\d+)-(\d*)$/.exec(req.headers.range||'');if(range){a=Number(range[1]);if(range[2])b=Math.min(b,Number(range[2]));if(a>b){res.writeHead(416,{'Content-Range':`bytes */${video.length}`});return res.end();}}
  const h={'Content-Type':'video/x-matroska','Accept-Ranges':'bytes','Content-Length':b-a+1};if(range)h['Content-Range']=`bytes ${a}-${b}/${video.length}`;res.writeHead(range?206:200,h);res.end(req.method==='HEAD'?undefined:video.subarray(a,b+1));}
 const tlsPort=await listen(https.createServer({key:fs.readFileSync(key),cert:fs.readFileSync(cert)},(q,r)=>{secureRequests++;serve(q,r)}));
 const httpPort=await listen(http.createServer((q,r)=>{clearRequests++;serve(q,r)}));
 const original=`https://127.0.0.1:${tlsPort}/sample.mkv`,alternative=`http://127.0.0.1:${httpPort}/sample.mkv`;
 const startup=path.join(temp,'startup');fs.mkdirSync(startup);const log=path.join(temp,'mpv.log');
 const args=P.argsFor(player,original,{mediaAlternative:alternative});args.splice(args.length-2,0,'--vo=null','--ao=null','--hwdec=no','--force-window=no','--keep-open=no','--log-file='+log);
 child=spawn(player.path,args,{cwd:path.dirname(player.path),windowsHide:true,stdio:'ignore',env:{...process.env,LOCALAPPDATA:temp,BM_PLAYER_START_DIR:startup,BM_MEDIA_ORIGINAL:original,BM_MEDIA_ALTERNATIVE:alternative,BM_MEDIA_START:'',BM_PARTY_DIR:'',BM_CONTINUE_DIR:'',BM_PROFILE_DIR:''}});
 let exitCode,spawnError;child.once('exit',c=>{exitCode=c;});child.once('error',e=>{spawnError=e;});
 const deadline=Date.now()+25000;while(Date.now()<deadline&&!fs.existsSync(path.join(startup,'ready'))&&!fs.existsSync(path.join(startup,'error'))&&!fs.existsSync(path.join(startup,'tls-error'))&&!fs.existsSync(path.join(startup,'retry-error'))&&exitCode===undefined&&!spawnError)await new Promise(r=>setTimeout(r,100));
 assert.ifError(spawnError);assert.ok(fs.existsSync(path.join(startup,'retrying')),'MPV must recognize real certificate failure and try the alternate');assert.ok(fs.existsSync(path.join(startup,'ready')),'MPV must decode media through the alternate');assert.equal(secureRequests,0,'certificate validation was not bypassed');assert.ok(clearRequests>0,'alternate HTTP request reached the local test server');
 console.log('PASS: actual Windows MPV certificate failure -> HTTP retry -> playback ready');
}catch(e){try{console.error(fs.readFileSync(path.join(temp,'mpv.log'),'utf8').slice(-9000));}catch{}throw e;}finally{if(child&&child.exitCode===null){const exited=new Promise(r=>child.once('exit',r));child.kill();await Promise.race([exited,new Promise(r=>setTimeout(r,2000))]);}for(const s of servers){s.closeAllConnections?.();await new Promise(r=>s.close(r));}fs.rmSync(temp,{recursive:true,force:true});}})().catch(e=>{console.error(e);process.exitCode=1;});
