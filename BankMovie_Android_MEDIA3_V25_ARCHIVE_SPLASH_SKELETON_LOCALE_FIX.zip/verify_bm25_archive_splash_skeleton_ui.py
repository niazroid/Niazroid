#!/usr/bin/env python3
"""Static regression checks for user-requested mobile UI. Not an Android APK/device test."""
from pathlib import Path
root=Path(__file__).resolve().parent
main=(root/'app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
block=main.split('val instructions = listOf(',1)[1].split(')\n        instructions.forEachIndexed',1)[0]
lines=[l for l in block.splitlines() if l.strip().startswith('t(')]
assert len(lines)==6 and 'VPN' in lines[3] and 'Clear Data' in lines[4]
splash=main.split('private fun showSplashOnly()',1)[1].split('private fun discardStartupSplash()',1)[0]
assert 'تجربه تماشای حرفه‌ای' not in splash
assert 'typeface = BankmovieFonts.bold(this@MainActivity)' in splash
assert 'typeface = BankmovieFonts.medium(this@MainActivity)' in splash
archive=main.split('private fun archiveSegment(',1)[1].split('private fun archiveSwitchBar(',1)[0]
assert 'setSingleLine(true)' in archive
assert 'setAutoSizeTextTypeUniformWithConfiguration(8, 12, 1,' in archive
assert 'LinearLayout.LayoutParams(-1, -1)' in archive
skeleton=main.split('private fun movieDetailGlassLoading()',1)[1].split('private fun notificationGlassLoadingSkeleton()',1)[0]
assert 'val heroHeight = dp(472)' in skeleton
assert 'FrameLayout.LayoutParams(dp(62), dp(62), Gravity.TOP or Gravity.CENTER_HORIZONTAL)' in skeleton
assert 'FrameLayout.LayoutParams(dp(27), dp(27), Gravity.CENTER)' in skeleton
assert 'ic_comment_like' in skeleton and 'setImageResource(R.drawable.ic_imdb)' in skeleton
arrow=main.split('private fun applyLocalizedViewAllArrow(',1)[1].split('private fun sectionHeader(',1)[0]
assert 'bm_ic_view_all_left_user' in arrow and 'bm_ic_view_all_right_user' in arrow
assert 'UiPreferences.readableAccent(this)' in arrow
assert main.count('applyLocalizedViewAllArrow(this)') == 3
assert 'layoutDirection = if (!isFa() && !isTvLike()) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR' in main
assert 'versionName "2.5"' in (root/'app/build.gradle').read_text()
assert "applicationId 'ir.bankmoviee.app'" in (root/'app/build.gradle').read_text()
print('BM25_ARCHIVE_SPLASH_SKELETON_LOCALE_UI_STATIC_OK')
