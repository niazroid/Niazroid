-keep class org.videolan.** { *; }
-dontwarn org.videolan.**

-keep class ir.bankmoviee.app.InternalDownloadService { *; }
-keep class ir.bankmoviee.app.DownloadsActivity { *; }


# Preserve native/JNI entry points but allow app implementation names and the
# runtime vault to be optimized and renamed by R8.
-keepclasseswithmembers,allowoptimization,allowobfuscation class * {
    native <methods>;
}
-allowaccessmodification
-repackageclasses x
-adaptclassstrings
