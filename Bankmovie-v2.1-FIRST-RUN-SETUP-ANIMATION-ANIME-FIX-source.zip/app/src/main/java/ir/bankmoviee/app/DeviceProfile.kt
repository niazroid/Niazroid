package ir.bankmoviee.app

import android.app.ActivityManager
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import java.util.concurrent.atomic.AtomicReference

internal object DeviceProfile {
    private val lowEndCache = AtomicReference<Boolean?>()

    fun isTv(context: Context): Boolean {
        val mode = context.resources.configuration.uiMode and Configuration.UI_MODE_TYPE_MASK
        val pm = context.packageManager
        return mode == Configuration.UI_MODE_TYPE_TELEVISION ||
            pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LEANBACK) ||
            pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_TELEVISION)
    }

    fun isLowEnd(context: Context): Boolean {
        lowEndCache.get()?.let { return it }
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        val memoryClass = am.memoryClass
        val low = am.isLowRamDevice || memoryClass <= 192 || cores <= 4 ||
            (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P && memoryClass <= 256)
        lowEndCache.compareAndSet(null, low)
        return low
    }

    fun imageThreads(context: Context): Int = if (isLowEnd(context)) 2 else 3

    fun imageCacheKb(context: Context): Int {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val budgetMb = if (isLowEnd(context)) 18 else (am.memoryClass / 10).coerceIn(24, 48)
        return budgetMb * 1024
    }

    fun imageMaxSide(context: Context): Int = when {
        isTv(context) && isLowEnd(context) -> 1152
        isTv(context) -> 1440
        isLowEnd(context) -> 800
        else -> 1080
    }
}
