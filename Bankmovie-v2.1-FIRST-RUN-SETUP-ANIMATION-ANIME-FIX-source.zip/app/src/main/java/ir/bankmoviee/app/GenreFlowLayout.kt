package ir.bankmoviee.app

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import kotlin.math.max

/**
 * Lightweight RTL flow layout used for clickable movie genres.
 * It wraps long genre chips to the next line instead of clipping them.
 */
class GenreFlowLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : ViewGroup(context, attrs) {

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    var horizontalSpacing: Int = dp(6)
    var verticalSpacing: Int = dp(6)

    override fun generateDefaultLayoutParams(): LayoutParams =
        MarginLayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)

    override fun generateLayoutParams(attrs: AttributeSet?): LayoutParams =
        MarginLayoutParams(context, attrs)

    override fun generateLayoutParams(p: LayoutParams): LayoutParams =
        MarginLayoutParams(p)

    override fun checkLayoutParams(p: LayoutParams?): Boolean = p is MarginLayoutParams

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val widthMode = MeasureSpec.getMode(widthMeasureSpec)
        val widthSize = MeasureSpec.getSize(widthMeasureSpec)
        val availableWidth = if (widthMode == MeasureSpec.UNSPECIFIED) Int.MAX_VALUE
        else (widthSize - paddingLeft - paddingRight).coerceAtLeast(0)

        var rowWidth = 0
        var rowHeight = 0
        var usedWidth = 0
        var usedHeight = paddingTop + paddingBottom
        var hasVisibleChild = false

        for (i in 0 until childCount) {
            val child = getChildAt(i)
            if (child.visibility == View.GONE) continue
            hasVisibleChild = true
            measureChildWithMargins(child, widthMeasureSpec, 0, heightMeasureSpec, 0)
            val lp = child.layoutParams as MarginLayoutParams
            val childWidth = child.measuredWidth + lp.leftMargin + lp.rightMargin
            val childHeight = child.measuredHeight + lp.topMargin + lp.bottomMargin
            val extra = if (rowWidth == 0) 0 else horizontalSpacing

            if (rowWidth > 0 && rowWidth + extra + childWidth > availableWidth) {
                usedWidth = max(usedWidth, rowWidth)
                usedHeight += rowHeight + verticalSpacing
                rowWidth = childWidth
                rowHeight = childHeight
            } else {
                rowWidth += extra + childWidth
                rowHeight = max(rowHeight, childHeight)
            }
        }

        if (hasVisibleChild) {
            usedWidth = max(usedWidth, rowWidth)
            usedHeight += rowHeight
        }

        val desiredWidth = usedWidth + paddingLeft + paddingRight
        setMeasuredDimension(
            resolveSize(desiredWidth, widthMeasureSpec),
            resolveSize(usedHeight, heightMeasureSpec)
        )
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val rightEdge = width - paddingRight
        var x = rightEdge
        var y = paddingTop
        var rowHeight = 0

        for (i in 0 until childCount) {
            val child = getChildAt(i)
            if (child.visibility == View.GONE) continue
            val lp = child.layoutParams as MarginLayoutParams
            val childWidth = child.measuredWidth
            val childHeight = child.measuredHeight
            val needed = lp.leftMargin + childWidth + lp.rightMargin

            if (x != rightEdge && x - horizontalSpacing - needed < paddingLeft) {
                x = rightEdge
                y += rowHeight + verticalSpacing
                rowHeight = 0
            } else if (x != rightEdge) {
                x -= horizontalSpacing
            }

            val childRight = x - lp.rightMargin
            val childLeft = childRight - childWidth
            val childTop = y + lp.topMargin
            child.layout(childLeft, childTop, childRight, childTop + childHeight)
            x = childLeft - lp.leftMargin
            rowHeight = max(rowHeight, childHeight + lp.topMargin + lp.bottomMargin)
        }
    }
}
