package ir.bankmoviee.app

import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context
import android.os.Build

/**
 * Server-driven admin notification delivery without a third-party SDK.
 * Android's background scheduler checks the admin feed periodically, while
 * runNow() performs an immediate sync when the app opens or is upgraded.
 */
object AdminPushScheduler {
    private const val PERIODIC_JOB_ID = 21421
    private const val IMMEDIATE_JOB_ID = 21422
    private const val FIFTEEN_MINUTES = 15L * 60L * 1000L

    fun ensureScheduled(context: Context) {
        val scheduler = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        // Scheduling the same ID is idempotent and also works on Android 6,
        // where querying all pending jobs is not available.
        val builder = JobInfo.Builder(PERIODIC_JOB_ID, ComponentName(context, AdminPushJobService::class.java))
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            .setPersisted(true)
            .setPeriodic(FIFTEEN_MINUTES)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) builder.setRequiresBatteryNotLow(false)
        scheduler.schedule(builder.build())
    }

    fun runNow(context: Context) {
        val scheduler = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        scheduler.cancel(IMMEDIATE_JOB_ID)
        val job = JobInfo.Builder(IMMEDIATE_JOB_ID, ComponentName(context, AdminPushJobService::class.java))
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            .setMinimumLatency(1000L)
            .setOverrideDeadline(5000L)
            .build()
        scheduler.schedule(job)
    }
}
