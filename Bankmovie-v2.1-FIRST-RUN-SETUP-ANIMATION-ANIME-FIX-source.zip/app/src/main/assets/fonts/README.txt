The app font loader expects an optional private font at:
fonts/irancell_regular.ttf
If it is not present, Android's system typeface is used automatically and the build remains valid.
