#!/usr/bin/env bash
set -euo pipefail
FONT='app/src/main/assets/fonts/irancell_regular.ttf'
test -s "$FONT"
echo "Embedded Irancell font is ready: $FONT"
