# Bankmovie V2.1 — Performance, player stability and endpoint hardening

- Bounded memory LRU bitmap cache instead of retaining up to 120 large images.
- Sampled image decoding and fewer loader threads on low-RAM devices.
- Lighter TV focus animations on weak hardware.
- HLS/DASH adaptive selection changed from `highest` to bandwidth-aware `rate`.
- Larger cache on cellular/metered networks and automatic software-decoder fallback after repeated long stalls.
- Bootstrap URLs, trusted hosts, app key and current compatibility secret are removed from the plain APK string table and decoded at runtime.
- HTTPS website deep-link host declarations were removed from the manifest; the custom `bankmoviee://play` scheme remains.

Important: a client must connect to a server at runtime, so its destination cannot be made truly secret from device owners or network inspection. This hardening prevents casual static `strings` extraction; it is not antivirus evasion and must not be treated as server-side authentication security.
