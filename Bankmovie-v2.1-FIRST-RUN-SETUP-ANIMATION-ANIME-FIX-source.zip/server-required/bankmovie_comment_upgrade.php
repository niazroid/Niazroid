<?php
/**
 * Shared comment upgrade helpers for website/admin AJAX.
 * Does not contain database credentials and is safe to overwrite on deployment.
 */
if (!function_exists('bm_site_comment_table_exists')) {
    function bm_site_comment_table_exists(PDO $pdo, string $table): bool {
        $table = preg_replace('/[^A-Za-z0-9_]/', '', $table) ?: '';
        if ($table === '') return false;
        try {
            $stmt = $pdo->prepare('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? LIMIT 1');
            $stmt->execute([$table]);
            return (bool)$stmt->fetchColumn();
        } catch (Throwable $e) { return false; }
    }
}
if (!function_exists('bm_site_comment_column_exists')) {
    function bm_site_comment_column_exists(PDO $pdo, string $table, string $column): bool {
        try {
            $stmt = $pdo->prepare('SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=? LIMIT 1');
            $stmt->execute([$table,$column]);
            return (bool)$stmt->fetchColumn();
        } catch (Throwable $e) { return false; }
    }
}
if (!function_exists('bm_site_comment_upgrade_schema')) {
    function bm_site_comment_upgrade_schema(PDO $pdo): void {
        foreach (['comments','archive1_comments'] as $table) {
            if (!bm_site_comment_table_exists($pdo,$table)) continue;
            $changes = [
                'is_pinned' => "ALTER TABLE `{$table}` ADD COLUMN is_pinned TINYINT(1) NOT NULL DEFAULT 0 AFTER status",
                'pinned_at' => "ALTER TABLE `{$table}` ADD COLUMN pinned_at DATETIME NULL DEFAULT NULL AFTER is_pinned",
                'edited_at' => "ALTER TABLE `{$table}` ADD COLUMN edited_at DATETIME NULL DEFAULT NULL AFTER updated_at",
            ];
            foreach ($changes as $column=>$sql) {
                if (!bm_site_comment_column_exists($pdo,$table,$column)) {
                    try { $pdo->exec($sql); } catch (Throwable $e) { error_log("comment schema {$table}.{$column}: ".$e->getMessage()); }
                }
            }
        }
        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS comment_reports (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                archive_no TINYINT UNSIGNED NOT NULL DEFAULT 1,
                movie_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
                comment_id BIGINT UNSIGNED NOT NULL,
                reporter_user_id BIGINT UNSIGNED NOT NULL,
                reason VARCHAR(60) NOT NULL,
                details VARCHAR(500) NOT NULL DEFAULT '',
                status VARCHAR(20) NOT NULL DEFAULT 'open',
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                reviewed_at DATETIME NULL,
                reviewed_by BIGINT UNSIGNED NULL,
                UNIQUE KEY uq_comment_reporter (archive_no,comment_id,reporter_user_id),
                KEY idx_report_status (status,created_at),
                KEY idx_report_comment (archive_no,comment_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            $pdo->exec("CREATE TABLE IF NOT EXISTS comment_edit_history (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                archive_no TINYINT UNSIGNED NOT NULL DEFAULT 1,
                comment_id BIGINT UNSIGNED NOT NULL,
                editor_user_id BIGINT UNSIGNED NOT NULL,
                old_comment TEXT NOT NULL,
                old_spoiler TINYINT(1) NOT NULL DEFAULT 0,
                edited_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_comment (archive_no,comment_id,edited_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            $pdo->exec("CREATE TABLE IF NOT EXISTS app_notifications (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT UNSIGNED NOT NULL,
                type VARCHAR(40) NOT NULL DEFAULT 'admin',
                title VARCHAR(220) NOT NULL DEFAULT '',
                message TEXT NOT NULL,
                target_json LONGTEXT NULL,
                dedupe_key VARCHAR(190) NULL,
                read_at DATETIME NULL,
                is_read TINYINT(1) NOT NULL DEFAULT 0,
                dismissed_at DATETIME NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uq_user_dedupe (user_id,dedupe_key),
                KEY idx_user_read_created (user_id,read_at,created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            foreach ([
                'dedupe_key'=>"ALTER TABLE app_notifications ADD COLUMN dedupe_key VARCHAR(190) NULL AFTER target_json",
                'read_at'=>"ALTER TABLE app_notifications ADD COLUMN read_at DATETIME NULL AFTER dedupe_key",
                'is_read'=>"ALTER TABLE app_notifications ADD COLUMN is_read TINYINT(1) NOT NULL DEFAULT 0 AFTER read_at",
                'dismissed_at'=>"ALTER TABLE app_notifications ADD COLUMN dismissed_at DATETIME NULL AFTER is_read",
            ] as $column=>$sql) {
                if (!bm_site_comment_column_exists($pdo,'app_notifications',$column)) {
                    try { $pdo->exec($sql); } catch (Throwable $e) { error_log('app_notifications.'.$column.': '.$e->getMessage()); }
                }
            }
            try { $pdo->exec("CREATE UNIQUE INDEX uq_user_dedupe ON app_notifications (user_id,dedupe_key)"); } catch (Throwable $e) {}
            try { $pdo->exec("CREATE INDEX idx_user_read_created ON app_notifications (user_id,read_at,created_at)"); } catch (Throwable $e) {}
            try { $pdo->exec("CREATE INDEX idx_user_dismissed_created ON app_notifications (user_id,dismissed_at,created_at)"); } catch (Throwable $e) {}
            try { $pdo->exec("UPDATE app_notifications SET read_at=COALESCE(read_at,IF(is_read=1,created_at,NULL)) WHERE is_read=1"); } catch (Throwable $e) {}
            foreach ([
                'reviewed_at'=>"ALTER TABLE comment_reports ADD COLUMN reviewed_at DATETIME NULL AFTER created_at",
                'reviewed_by'=>"ALTER TABLE comment_reports ADD COLUMN reviewed_by BIGINT UNSIGNED NULL AFTER reviewed_at",
            ] as $column=>$sql) {
                if (!bm_site_comment_column_exists($pdo,'comment_reports',$column)) {
                    try { $pdo->exec($sql); } catch (Throwable $e) { error_log('comment_reports.'.$column.': '.$e->getMessage()); }
                }
            }
        } catch (Throwable $e) { error_log('comment shared schema: '.$e->getMessage()); }
    }
}
if (!function_exists('bm_site_comment_role_badge')) {
    function bm_site_comment_role_badge(string $role): string {
        $role = strtolower(trim($role));
        if (in_array($role,['admin','administrator'],true)) {
            return '<span class="bm-role-badge bm-role-admin" title="مدیر تأییدشده" aria-label="Verified admin">✓</span>';
        }
        if (in_array($role,['vip','premium','special'],true)) {
            return '<span class="bm-role-badge bm-role-vip" title="عضو ویژه">VIP</span>';
        }
        return '';
    }
}
if (!function_exists('bm_site_comment_is_admin')) {
    function bm_site_comment_is_admin($user): bool {
        return is_array($user) && in_array(strtolower((string)($user['role']??'')),['admin','administrator'],true);
    }
}
if (!function_exists('bm_site_comment_is_privileged')) {
    function bm_site_comment_is_privileged($user): bool {
        return is_array($user) && in_array(strtolower((string)($user['role']??'')),['admin','administrator','vip','premium','special'],true);
    }
}
if (!function_exists('bm_site_comment_config')) {
    function bm_site_comment_config(): array {
        $defaults=['enabled'=>true,'edit_minutes'=>10,'rate_count'=>3,'rate_minutes'=>10,'replies'=>true,'votes'=>true,'reports'=>true,'spoiler'=>true,'auto_approve_admin'=>true,'auto_approve_vip'=>true];
        $path=__DIR__.'/bankmovie_remote_config.json';
        if (!is_file($path)) return $defaults;
        $raw=@file_get_contents($path); $json=is_string($raw)?json_decode($raw,true):null;
        if (!is_array($json)) return $defaults;
        $comments=is_array($json['comments']??null)?$json['comments']:[];
        $features=is_array($json['features']??null)?$json['features']:[];
        return array_merge($defaults,[
            'enabled'=>(bool)($features['comments_enabled']??true),
            'edit_minutes'=>max(0,min(1440,(int)($comments['edit_minutes']??10))),
            'rate_count'=>max(1,min(30,(int)($comments['rate_count']??3))),
            'rate_minutes'=>max(1,min(1440,(int)($comments['rate_minutes']??10))),
            'replies'=>(bool)($features['comment_replies_enabled']??true),
            'votes'=>(bool)($features['comment_votes_enabled']??true),
            'reports'=>(bool)($features['comment_reports_enabled']??true),
            'spoiler'=>(bool)($features['comment_spoiler_enabled']??true),
            'auto_approve_admin'=>(bool)($comments['auto_approve_admin']??true),
            'auto_approve_vip'=>(bool)($comments['auto_approve_vip']??true),
        ]);
    }
}
if (!function_exists('bm_site_comment_submit_status')) {
    function bm_site_comment_submit_status($user): string {
        if (!is_array($user)) return 'pending';
        $role=strtolower(trim((string)($user['role']??'')));
        $cfg=bm_site_comment_config();
        if (in_array($role,['admin','administrator'],true) && !empty($cfg['auto_approve_admin'])) return 'approved';
        if (in_array($role,['vip','premium','special'],true) && !empty($cfg['auto_approve_vip'])) return 'approved';
        return 'pending';
    }
}
if (!function_exists('bm_site_comment_can_edit')) {
    function bm_site_comment_can_edit(array $comment, $user): bool {
        if (!is_array($user) || empty($user['id'])) return false;
        if (bm_site_comment_is_admin($user)) return true;
        if ((int)($comment['user_id']??0)!==(int)$user['id']) return false;
        $minutes=(int)(bm_site_comment_config()['edit_minutes']??10);
        if ($minutes<=0) return false;
        $created=strtotime((string)($comment['created_at']??''));
        return $created!==false && time()-$created <= $minutes*60;
    }
}
if (!function_exists('bm_site_comment_notify_reply')) {
    function bm_site_comment_notify_reply(PDO $pdo, int $archiveNo, int $movieId, int $parentId, int $replyId, int $actorUserId, string $actorName, string $table): void {
        try {
            $stmt=$pdo->prepare("SELECT user_id FROM `{$table}` WHERE id=? LIMIT 1");
            $stmt->execute([$parentId]);
            $owner=(int)$stmt->fetchColumn();
            if ($owner<=0 || $owner===$actorUserId) return;
            $target=json_encode(['archive'=>$archiveNo,'movie_id'=>$movieId,'comment_id'=>$replyId,'parent_id'=>$parentId],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
            $dedupe='comment_reply:'.$archiveNo.':'.$replyId;
            $stmt=$pdo->prepare("INSERT INTO app_notifications(user_id,type,title,message,target_json,dedupe_key,created_at) VALUES(?,'comment_reply',?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE title=VALUES(title),message=VALUES(message),target_json=VALUES(target_json)");
            $stmt->execute([$owner,'پاسخ جدید به دیدگاه شما',$actorName.' به دیدگاه شما پاسخ داد.',$target,$dedupe]);
        } catch (Throwable $e) { error_log('reply notification: '.$e->getMessage()); }
    }
}
if (!function_exists('bm_site_notification_insert')) {
    function bm_site_notification_insert(PDO $pdo, int $userId, string $type, string $title, string $message, array $target=[], string $dedupe=''): void {
        if ($userId<=0 || trim($message)==='') return;
        try {
            bm_site_comment_upgrade_schema($pdo);
            $stmt=$pdo->prepare("INSERT INTO app_notifications(user_id,type,title,message,target_json,dedupe_key,created_at) VALUES(?,?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE title=VALUES(title),message=VALUES(message),target_json=VALUES(target_json),read_at=NULL,is_read=0");
            $stmt->execute([$userId,substr($type,0,40),substr($title,0,220),$message,json_encode($target,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$dedupe!==''?substr($dedupe,0,190):null]);
        } catch (Throwable $e) { error_log('app notification insert: '.$e->getMessage()); }
    }
}
if (!function_exists('bm_site_comment_notify_status')) {
    function bm_site_comment_notify_status(PDO $pdo, int $userId, int $archiveNo, int $movieId, int $commentId, string $status): void {
        if ($userId<=0) return;
        $approved=$status==='approved';
        bm_site_notification_insert(
            $pdo,$userId,'comment_status',
            $approved?'دیدگاه شما تأیید شد':'دیدگاه شما رد شد',
            $approved?'دیدگاه شما توسط مدیریت تأیید و منتشر شد.':'دیدگاه شما توسط مدیریت تأیید نشد.',
            ['archive'=>$archiveNo,'movie_id'=>$movieId,'comment_id'=>$commentId],
            'comment_status:'.$archiveNo.':'.$commentId.':'.$status
        );
    }
}
if (!function_exists('bm_site_comment_order_sql')) {
    function bm_site_comment_order_sql(string $sort, string $alias='c', string $likeTable='comment_likes', string $commentTable='comments'): string {
        $a=preg_replace('/[^A-Za-z0-9_]/','',$alias)?:'c';
        $lt=preg_replace('/[^A-Za-z0-9_]/','',$likeTable)?:'comment_likes';
        $ct=preg_replace('/[^A-Za-z0-9_]/','',$commentTable)?:'comments';
        $pinned="{$a}.is_pinned DESC, COALESCE({$a}.pinned_at,{$a}.created_at) DESC";
        return match(strtolower(trim($sort))) {
            'oldest' => "{$a}.is_pinned DESC, {$a}.created_at ASC, {$a}.id ASC",
            'popular' => "{$pinned}, ((SELECT COUNT(*) FROM {$lt} lx WHERE lx.comment_id={$a}.id AND lx.type='like')-(SELECT COUNT(*) FROM {$lt} dx WHERE dx.comment_id={$a}.id AND dx.type='dislike')) DESC, {$a}.created_at DESC",
            'controversial' => "{$pinned}, LEAST((SELECT COUNT(*) FROM {$lt} lx WHERE lx.comment_id={$a}.id AND lx.type='like'),(SELECT COUNT(*) FROM {$lt} dx WHERE dx.comment_id={$a}.id AND dx.type='dislike')) DESC, {$a}.created_at DESC",
            'replies' => "{$pinned}, (SELECT COUNT(*) FROM {$ct} rr WHERE rr.parent_id={$a}.id AND LOWER(TRIM(CAST(rr.status AS CHAR))) IN ('approved','active','1')) DESC, {$a}.created_at DESC",
            default => "{$pinned}, {$a}.created_at DESC, {$a}.id DESC",
        };
    }
}
