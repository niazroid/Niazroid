# مستند کامل API6 برای اتصال آرشیو ۳ به اپلیکیشن BankMovie

> این سند برای تحویل مستقیم به ChatGPT یا توسعه‌دهنده اپ آماده شده است. بسته فقط شامل کدهای API6 و همین مستند است و سورس کامل بک‌اند یا فایل‌های غیرمرتبط داخل آن قرار نگرفته‌اند.

## 1) فایل‌های لازم

API6 از دو فایل تشکیل شده است:

```text
api6.php
api6_lib.php
```

فایل اصلی Endpoint برابر `api6.php` است، اما منطق استخراج، جستجو، جزئیات و لینک‌ها داخل `api6_lib.php` قرار دارد؛ بنابراین این دو فایل باید کنار هم باشند.

### وابستگی‌های موجود در بک‌اند BankMovie

فایل `api6.php` در همان پوشه به این فایل‌های موجود نیاز دارد:

```text
security_bootstrap.php
archive_control.php
```

همچنین روی سرور باید افزونه PHP DOM فعال باشد و cURL نیز برای اتصال پایدار توصیه می‌شود.

---

## 2) هدف API6

API6 آرشیو ۳ را به خروجی JSON استاندارد تبدیل می‌کند و قابلیت‌های زیر را در اختیار اپ قرار می‌دهد:

- جدیدترین فیلم‌ها
- جدیدترین سریال‌ها
- انیمیشن‌های به‌روزشده
- انیمه‌های به‌روزشده
- فهرست ژانرها همراه تعداد
- فهرست سال‌های انتشار همراه تعداد
- جستجوی ساده با عنوان
- جستجوی پیشرفته ترکیبی
- دریافت جزئیات کامل اثر
- استخراج لینک‌های پخش و دانلود
- تشخیص فیلم، سریال، انیمیشن و انیمه
- تفکیک دوبله، هاردساب، سافت‌ساب، زیرنویس و صوت دوبله
- صفحه‌بندی نتایج

---

## 3) آدرس پایه

در مثال‌های این سند فرض می‌شود API در مسیر زیر قرار دارد:

```text
https://YOUR-DOMAIN.com/api6.php
```

دامنه واقعی بک‌اند جایگزین `YOUR-DOMAIN.com` شود.

---

## 4) بررسی وضعیت API

### درخواست

```http
GET /api6.php?ping=1
```

Aliasهای قابل استفاده:

```text
status=1
auth_status=1
```

### پاسخ نمونه

```json
{
  "status": "success",
  "enabled": true,
  "archive": 3,
  "endpoint": "api6",
  "message": "آرشیو ۳ آماده است."
}
```

اگر آرشیو ۳ از پنل مدیریت غیرفعال باشد، API کد `503` و وضعیت `disabled` برمی‌گرداند.

---

## 5) دریافت بخش‌های قابل نمایش

### درخواست

```http
GET /api6.php?sections=1
```

بخش‌های مهم برای اپ:

| Section | کاربرد |
|---|---|
| `new_movies` | جدیدترین فیلم‌ها |
| `new_series` | جدیدترین سریال‌ها |
| `updated_animations` | انیمیشن‌های به‌روزشده |
| `updated_anime` | انیمه‌های به‌روزشده |
| `animations` | کل محتوای انیمیشن |
| `dubbed_movies` | فیلم‌های دوبله |
| `subtitled_movies` | فیلم‌های زیرنویس‌دار |
| `dubbed_series` | سریال‌های دوبله |
| `subtitled_series` | سریال‌های زیرنویس‌دار |
| `mini_series` | مینی‌سریال‌ها |
| `korean_series` | سریال‌های کره‌ای |
| `turkish_series` | سریال‌های ترکی |

### دریافت یک Section

```http
GET /api6.php?section=updated_anime&page=1
GET /api6.php?section=updated_animations&page=1
GET /api6.php?section=new_movies&page=1
GET /api6.php?section=new_series&page=1
```

### Alias به‌روزرسانی

```http
GET /api6.php?updates=anime&page=1
GET /api6.php?updates=animation&page=1
GET /api6.php?updates=series&page=1
GET /api6.php?updates=movie&page=1
```

---

## 6) دریافت گزینه‌های جستجوی پیشرفته

برای ساخت صفحه جستجوی پیشرفته، اپ نباید فهرست ژانرها و سال‌ها را به‌صورت پراکنده در کد تکرار کند. API6 یک Endpoint واحد ارائه می‌دهد:

```http
GET /api6.php?search_options=1
```

Aliasها:

```text
filters=1
options=1
```

### خروجی اصلی

```json
{
  "status": "success",
  "archive": 3,
  "types": [],
  "genres": [],
  "years": [],
  "imdb_scores": [],
  "languages": [],
  "sorts": [],
  "counts_source": "live_cached"
}
```

مقدار `counts_source` یکی از موارد زیر است:

- `live_cached`: تعدادها از صفحه منبع دریافت و در Cache نگه‌داری شده‌اند.
- `fallback_snapshot`: منبع موقتاً در دسترس نبوده و تعدادهای آخرین Snapshot استفاده شده‌اند.

تعدادها نباید در منطق اپ ثابت فرض شوند؛ فقط برای Badge و نمایش آماری هستند.

---

## 7) ژانرها

### Endpoint مستقل ژانرها

```http
GET /api6.php?genres=1
```

خروجی شامل دو فیلد است:

- `genres`: آرایه ساده نام ژانرها
- `genre_options`: آرایه کامل شامل `key`, `value`, `label`, `count`, `path`

### فهرست ژانرها و Snapshot تعدادها

| کلید پیشنهادی اپ | مقدار ارسالی به API | عنوان نمایشی | تعداد Snapshot |
|---|---|---|---:|
| `action` | `اکشن` | اکشن | 4560 |
| `biography` | `بیوگرافی` | بیوگرافی | 850 |
| `history` | `تاریخی` | تاریخی | 781 |
| `horror` | `ترسناک` | ترسناک | 1801 |
| `crime` | `جنایی` | جنایی | 2697 |
| `war` | `جنگی` | جنگی | 311 |
| `family` | `خانوادگی` | خانوادگی | 746 |
| `animation` | `انیمیشن` | انیمیشن | 1732 |
| `drama` | `درام` | درام | 8966 |
| `mystery` | `رازآلود` | رازآلود | 1440 |
| `romance` | `عاشقانه` | عاشقانه | 2178 |
| `sci-fi` | `علمی تخیلی` | علمی تخیلی | 905 |
| `fantasy` | `فانتزی` | فانتزی | 1178 |
| `comedy` | `کمدی` | کمدی | 4469 |
| `short` | `کوتاه` | کوتاه | 97 |
| `adventure` | `ماجراجویی` | ماجراجویی | 2754 |
| `documentary` | `مستند` | مستند | 268 |
| `music-video` | `موزیک ویدیو` | موزیک ویدیو | 1 |
| `musical` | `موزیکال` | موزیکال | 383 |
| `mini-series` | `مینی سریال` | مینی سریال | نامشخص |
| `noir` | `نوآر` | نوآر | 5 |
| `thriller` | `هیجان انگیز` | هیجان انگیز | 3074 |
| `sport` | `ورزشی` | ورزشی | 250 |
| `western` | `وسترن` | وسترن | 110 |

### نکات ژانر

- مقدار `انیمیشن` در API به مسیر دسته انیمیشن هدایت می‌شود.
- `تاریخی` در فهرست کناری منبع وجود دارد، هرچند در Select فرم جستجوی پیشرفته منبع نمایش داده نشده است؛ API6 آن را پشتیبانی می‌کند.
- `مینی سریال` در فرم جستجوی پیشرفته وجود دارد، اما در Screenshot تعداد مستقلی برای آن نمایش داده نشده است.
- API6 نام‌های انگلیسی مانند `action`, `crime`, `animation`, `thriller` را نیز به مقدار فارسی متناظر تبدیل می‌کند.

---

## 8) سال‌های انتشار

### Endpoint مستقل سال‌ها

```http
GET /api6.php?years=1
```

### Snapshot سال‌ها و تعداد آثار

| سال | تعداد | سال | تعداد |
|---:|---:|---:|---:|
| 2000 | 102 | 2001 | 130 |
| 2002 | 129 | 2003 | 143 |
| 2004 | 164 | 2005 | 185 |
| 2006 | 210 | 2007 | 201 |
| 2008 | 270 | 2009 | 319 |
| 2010 | 261 | 2011 | 307 |
| 2012 | 268 | 2013 | 322 |
| 2014 | 358 | 2015 | 363 |
| 2016 | 437 | 2017 | 560 |
| 2018 | 674 | 2019 | 735 |
| 2020 | 676 | 2021 | 731 |
| 2022 | 1187 | 2023 | 1791 |
| 2024 | 2222 | 2025 | 1819 |
| 2026 | 705 |  |  |

برای UI بهتر است سال‌ها از جدید به قدیم نمایش داده شوند، هرچند API ممکن است آن‌ها را به ترتیب صعودی برگرداند.

---

## 9) جستجوی ساده

```http
GET /api6.php?q=Batman&page=1
```

Alias نام جستجو:

```text
q
s
```

---

## 10) جستجوی پیشرفته

API6 پارامترهای فرم پیشرفته را به‌صورت ترکیبی پشتیبانی می‌کند.

### پارامترهای اصلی

| پارامتر API | نوع | مثال | توضیح |
|---|---|---|---|
| `q` یا `s` | string | `Batman` | نام اثر |
| `type` | string | `movie` | `all`, `movie`, `series`, `animation`, `anime` |
| `genre` | string | `اکشن` | مقدار فارسی یا Alias انگلیسی |
| `country` | string | `آمریکا` | کشور سازنده |
| `director` | string | `Christopher Nolan` | کارگردان |
| `actor` | string | `Christian Bale` | بازیگر |
| `year` یا `yearse` | integer | `2008` | سال دقیق انتشار |
| `fromYear` | integer | `2000` | شروع بازه سال؛ فیلتر تکمیلی API6 |
| `toYear` | integer | `2026` | پایان بازه سال؛ فیلتر تکمیلی API6 |
| `imdbScore` | number | `8` | حداقل امتیاز IMDb |
| `rates` یا `rating` | number | `8` | Alias امتیاز |
| `lang` | string | `دوبله` | `دوبله` یا `زیرنویس` |
| `dubbed` | bool/int | `1` | فقط دوبله‌ها |
| `subtitle` | bool/int | `1` | فقط زیرنویس‌دارها |
| `playonline` | bool/int | `1` | فقط موارد دارای پخش آنلاین |
| `sort` | string | `rating` | `newest`, `rating`, `year_desc`, `title` |
| `page` | integer | `1` | شماره صفحه |

### مقادیر اصلی فرم منبع

فرم جستجوی پیشرفته منبع از این نام‌ها استفاده می‌کند:

```text
type
genre
country
director
actor
yearse
imdbScore
lang
q
```

API6 همین نام‌ها را مستقیماً می‌پذیرد و Aliasهای مناسب اپ را نیز پشتیبانی می‌کند.

### مثال کامل

```http
GET /api6.php?q=Batman&type=movie&genre=اکشن&country=آمریکا&director=Christopher%20Nolan&actor=Christian%20Bale&year=2008&imdbScore=8&lang=دوبله&sort=rating&page=1
```

### مثال فقط ژانر و سال

```http
GET /api6.php?type=movie&genre=جنایی&year=2024&page=1
```

### مثال سریال زیرنویس‌دار

```http
GET /api6.php?type=series&genre=درام&lang=زیرنویس&imdbScore=7&page=1
```

### مثال انیمیشن

```http
GET /api6.php?type=animation&year=2025&page=1
```

### مثال انیمه به‌روزشده

برای ردیف اختصاصی انیمه بهتر است از Section استفاده شود:

```http
GET /api6.php?section=updated_anime&page=1
```

---

## 11) پاسخ فهرست و جستجو

```json
{
  "status": "success",
  "archive": 3,
  "page": 1,
  "count": 12,
  "has_more": true,
  "next_page": 2,
  "last_page_hint": 9,
  "filters": {},
  "movies": []
}
```

### مدل Card داخل `movies`

| فیلد | نوع | توضیح |
|---|---|---|
| `id` | string | شناسه اثر |
| `slug` | string | Slug منبع |
| `detail_id` | string | شناسه ترجیحی جزئیات |
| `source_post_id` | int/null | شناسه پست در صورت وجود |
| `title` | string | عنوان لاتین یا اصلی |
| `title_fa` | string | عنوان فارسی؛ اولویت نمایش |
| `full_title` | string | عنوان کامل |
| `year` | int/null | سال انتشار |
| `type` | string | `movie`, `series`, `anime` |
| `media_kind` | string/null | `animation` یا `anime` برای تفکیک ردیف‌ها |
| `poster` | string | آدرس پوستر |
| `rating` | number/null | امتیاز IMDb |
| `genres` | array | ژانرها |
| `country` | array | کشورها |
| `description` | string | خلاصه |
| `status` | string | وضعیت فصل/قسمت |
| `runtime` | int/null | مدت زمان |
| `actors` | array | بازیگران |
| `directors` | array | کارگردانان |
| `trailer` | string | تریلر |
| `has_dubbed` | bool | دارای دوبله |
| `has_subtitle` | bool | دارای زیرنویس |
| `has_online` | bool | دارای پخش آنلاین |

### قانون مهم برای فیلم و سریال

- فیلم نباید فصل یا قسمت جعلی داشته باشد.
- `season` و `episode` برای فیلم باید `null` باشند.
- سریال باید با فصل و قسمت واقعی گروه‌بندی شود.
- برای انیمیشن مستقل از `media_kind=animation` استفاده شود.
- برای انیمه یا انیمیشن سریالی از `media_kind=anime` استفاده شود.

---

## 12) دریافت جزئیات

### با شناسه

```http
GET /api6.php?id={ID}
```

### با URL کامل اثر

```http
GET /api6.php?url={URL_ENCODED}
```

برای امنیت فقط URLهای دامنه مجاز آرشیو پذیرفته می‌شوند.

### فیلدهای مهم Detail

```text
id
detail_id
source_post_id
title
title_fa
full_title
type
media_kind
poster
backdrop
year
rating
runtime
genres
country
actors
directors
writers
language
languages
description
long_description
trailer
has_dubbed
has_subtitle
has_online
downloads
links
play
```

---

## 13) لینک‌های پخش و دانلود

لینک‌ها باید براساس نوع واقعی نمایش داده شوند:

| مقدار `type` | عنوان فارسی |
|---|---|
| `dub` | دوبله |
| `hardsub` | هاردساب |
| `softsub` | سافت‌ساب |
| `subtitle` | زیرنویس |
| `audio` | صوت دوبله |

### قانون تفکیک زیرنویس

- `hardsub` یعنی زیرنویس روی تصویر چسبیده است.
- `softsub` یعنی زیرنویس جدا یا قابل انتخاب است.
- اپ نباید `softsub` را با زیرنویس معمولی یا هاردساب یکی کند.
- صوت دوبله باید با `is_audio=true` از فایل ویدئویی جدا شود.

### فیلدهای متداول Link

```text
url
quality
type
type_fa
display_label
season
episode
size
is_direct
is_download
is_playable
is_audio
```

---

## 14) طراحی پیشنهادی صفحه جستجوی پیشرفته اپ

ترتیب پیشنهادی اجزا:

1. فیلد نام اثر
2. انتخاب نوع: همه، فیلم، سریال، انیمیشن، انیمه
3. انتخاب ژانر همراه Badge تعداد
4. انتخاب سال انتشار
5. کشور
6. کارگردان
7. بازیگر
8. حداقل امتیاز IMDb
9. دوبله یا زیرنویس
10. مرتب‌سازی
11. دکمه جستجو
12. دکمه پاک‌کردن همه فیلترها

### رفتار UI

- گزینه‌ها ابتدا از `search_options=1` دریافت شوند.
- تعداد ژانر و سال فقط Badge نمایشی باشد.
- هنگام تغییر چند فیلتر، همه پارامترها در یک درخواست ارسال شوند.
- با اجرای جستجوی جدید، `page` به 1 برگردد.
- هنگام Scroll یا دکمه صفحه بعد، سایر فیلترها حفظ شوند.
- اگر `has_more=false` بود، درخواست صفحه بعد ارسال نشود.
- نتیجه خالی با پیام مناسب نمایش داده شود، نه صفحه خطا.
- درخواست قبلی هنگام تغییر سریع فیلترها Cancel شود.
- برای جستجوی متنی Debounce حدود 400 تا 600 میلی‌ثانیه مناسب است.

---

## 15) مدیریت خطا

اپ باید این وضعیت‌ها را مدیریت کند:

| HTTP/Status | رفتار اپ |
|---|---|
| `200 success` | نمایش محتوا |
| `503 disabled` | نمایش پیام غیرفعال‌بودن آرشیو |
| `500 error` | نمایش خطای دریافت اطلاعات و Retry |
| Timeout | Retry محدود با Backoff |
| JSON ناقص | ثبت Log و نمایش پیام عمومی |

تمام فیلدهای غیرحیاتی مانند `rating`, `year`, `runtime`, `poster`, `backdrop`, `season`, `episode`, `size` باید Nullable باشند.

---

## 16) UTF-8 و متن فارسی

- پاسخ API با `application/json; charset=utf-8` ارسال می‌شود.
- اپ نباید Encoding را به ISO-8859-1 یا Windows-1256 تغییر دهد.
- HTML Entity فقط یک بار Decode شود.
- برای نمایش فارسی از RTL و فونت مناسب اپ استفاده شود.
- مقادیر Query فارسی باید URL Encode شوند؛ کتابخانه HTTP معمولاً این کار را انجام می‌دهد.

---

## 17) Cache و Performance

- Cache فهرست‌ها در API6 حدود 240 ثانیه است.
- Cache جزئیات حدود 600 ثانیه است.
- اپ نیز می‌تواند گزینه‌های جستجو را برای چند ساعت Cache کند.
- در Refresh دستی، درخواست جدید ارسال شود.
- تصاویر با Lazy Loading و Placeholder نمایش داده شوند.
- برای TV و دستگاه‌های ضعیف، تعداد درخواست هم‌زمان محدود شود.

---

## 18) چک‌لیست تست

- [ ] `ping=1` پاسخ موفق می‌دهد.
- [ ] `search_options=1` ژانرها و سال‌ها را برمی‌گرداند.
- [ ] ژانر اکشن نتیجه می‌دهد.
- [ ] فیلتر سال 2025 نتیجه می‌دهد.
- [ ] جستجوی هم‌زمان نوع + ژانر + سال کار می‌کند.
- [ ] جستجو با نام کارگردان کار می‌کند.
- [ ] جستجو با نام بازیگر کار می‌کند.
- [ ] حداقل امتیاز IMDb اعمال می‌شود.
- [ ] دوبله و زیرنویس جدا فیلتر می‌شوند.
- [ ] `updated_animations` و `updated_anime` محتوای جدا دارند.
- [ ] فیلم فصل جعلی ندارد.
- [ ] سریال فصل و قسمت واقعی دارد.
- [ ] هاردساب و سافت‌ساب در UI جدا هستند.
- [ ] Pagination فیلترها را حفظ می‌کند.
- [ ] نتیجه خالی باعث Crash نمی‌شود.
- [ ] قطع اینترنت و Timeout مدیریت می‌شود.

---

## 19) دستور آماده برای ارسال به ChatGPT همراه سورس اپ

متن زیر را همراه این مستند، `api6.php`، `api6_lib.php` و ZIP سورس اپلیکیشن ارسال کنید:

```text
You are a senior Android/TV application engineer.

Integrate Archive 3 into my existing BankMovie application using the attached API6 files and the Persian API6 integration documentation as the source of truth.

Requirements:
1. Inspect the real application architecture before changing code.
2. Preserve the existing UI design, navigation, authentication, player, download manager, comments, watchlist, notifications, mobile layout, and TV focus behavior.
3. Add Archive 3 sections for new movies, new series, updated animations, and updated anime.
4. Add a complete advanced-search screen using API6 search_options, genres, years, type, country, director, actor, exact year, IMDb minimum score, dubbed/subtitle filter, sort, and pagination.
5. Keep all selected filters when loading the next page.
6. Use title_fa as the primary title and title as fallback.
7. Treat all optional API fields as nullable and prevent crashes.
8. Do not create fake seasons for movies.
9. Keep movie, series, animation, and anime behaviors separate.
10. Keep hardsub, softsub, subtitle, dub, and dub-audio link types separate.
11. Preserve UTF-8 Persian text and RTL layouts.
12. Add loading, empty, error, retry, offline, and pagination states.
13. Reuse the app's existing networking, repository, DTO, cache, player, and download architecture instead of creating duplicate systems.
14. Update both mobile and Android TV interfaces where the project contains separate implementations.
15. Run the available build, lint, and tests, fix introduced errors, and provide a concise changelog listing every modified file.

Do not return only sample code. Apply the changes directly to the supplied application source and return the complete modified project.
```

---

## 20) نکته نهایی تحویل

این بسته فقط برای انتقال قرارداد API6 و منطق جستجوی پیشرفته است. برای اعمال تغییرات واقعی روی اپ، باید ZIP سورس کامل اپلیکیشن نیز همراه آن برای ChatGPT ارسال شود.
