<?php
require_once __DIR__ . '/security_bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
require_once __DIR__ . '/api6_lib.php';
require_once __DIR__ . '/archive_control.php';

function api6_json($payload, $code = 200) {
    http_response_code((int)$code);
    echo json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

try {
    if (isset($_GET['ping']) || isset($_GET['status']) || isset($_GET['auth_status'])) {
        api6_json(array(
            'status' => 'success',
            'enabled' => bm_archive_is_enabled('archive3'),
            'archive' => 3,
            'endpoint' => 'archive3',
            'message' => bm_archive_is_enabled('archive3') ? 'آرشیو ۳ آماده است.' : bm_archive_disabled_message('archive3'),
        ));
    }

    if (!bm_archive_is_enabled('archive3')) {
        api6_json(array(
            'status' => 'disabled',
            'archive' => 3,
            'message' => bm_archive_disabled_message('archive3'),
            'movies' => array(),
            'downloads' => array(),
            'has_more' => false,
        ), 503);
    }

    if (isset($_GET['sections'])) {
        api6_json(array('status' => 'success', 'archive' => 3, 'sections' => array_keys(api6_section_catalog())));
    }
    if (isset($_GET['search_options']) || isset($_GET['filters']) || isset($_GET['options'])) {
        api6_json(array_merge(array('status' => 'success', 'archive' => 3), api6_search_options()));
    }
    if (isset($_GET['genres'])) {
        $options = api6_search_options();
        api6_json(array(
            'status' => 'success',
            'archive' => 3,
            'genres' => array_map(function($row) { return $row['value']; }, $options['genres']),
            'genre_options' => $options['genres'],
            'counts_source' => $options['counts_source'],
        ));
    }
    if (isset($_GET['years'])) {
        $options = api6_search_options();
        api6_json(array(
            'status' => 'success',
            'archive' => 3,
            'years' => $options['years'],
            'counts_source' => $options['counts_source'],
        ));
    }

    if (isset($_GET['section'])) {
        $section = trim((string)$_GET['section']);
        $page = max(1, (int)($_GET['page'] ?? 1));
        $result = api6_search(api6_section_params($section, $page));
        $result['section'] = $section;
        api6_json(array_merge(array('status' => 'success', 'archive' => 3), $result));
    }

    if (isset($_GET['updates']) || isset($_GET['archive'])) {
        $kind = trim((string)(isset($_GET['updates']) ? $_GET['updates'] : $_GET['archive']));
        $page = max(1, (int)($_GET['page'] ?? 1));
        if (in_array($kind, array('series','tv'), true)) $section = 'new_series';
        elseif (in_array($kind, array('updated_anime','anime'), true)) $section = 'updated_anime';
        elseif (in_array($kind, array('updated_animations','animation'), true)) $section = 'updated_animations';
        elseif ($kind === 'animations') $section = 'animations';
        else $section = 'new_movies';
        $result = api6_search(api6_section_params($section, $page));
        $result['section'] = $section;
        api6_json(array_merge(array('status' => 'success', 'archive' => 3), $result));
    }

    if (isset($_GET['id']) || isset($_GET['url'])) {
        $identifier = isset($_GET['url']) ? (string)$_GET['url'] : (string)$_GET['id'];
        api6_json(api6_get_details($identifier));
    }

    $params = array(
        's' => trim((string)($_GET['s'] ?? ($_GET['q'] ?? ''))),
        'type' => trim((string)($_GET['type'] ?? ($_GET['post-type'] ?? 'all'))),
        'genre' => trim((string)($_GET['genre'] ?? ($_GET['_genre'] ?? ''))),
        'sort' => trim((string)($_GET['sort'] ?? ($_GET['sortby'] ?? 'newest'))),
        'country' => trim((string)($_GET['country'] ?? ($_GET['_country'] ?? ''))),
        'director' => trim((string)($_GET['director'] ?? '')),
        'actor' => trim((string)($_GET['actor'] ?? '')),
        'yearse' => trim((string)($_GET['yearse'] ?? ($_GET['year'] ?? ''))),
        'year' => trim((string)($_GET['year'] ?? ($_GET['yearse'] ?? ''))),
        'fromYear' => trim((string)($_GET['fromYear'] ?? ($_GET['min_year'] ?? ''))),
        'toYear' => trim((string)($_GET['toYear'] ?? ($_GET['max_year'] ?? ''))),
        'rates' => trim((string)($_GET['rates'] ?? ($_GET['_rates'] ?? ($_GET['rating'] ?? ($_GET['imdbScore'] ?? ''))))),
        'rating' => trim((string)($_GET['rating'] ?? ($_GET['imdbScore'] ?? ''))),
        'imdbScore' => trim((string)($_GET['imdbScore'] ?? ($_GET['rates'] ?? ($_GET['rating'] ?? '')))),
        'score' => trim((string)($_GET['score'] ?? ($_GET['_score'] ?? ''))),
        'lang' => trim((string)($_GET['lang'] ?? '')),
        'dubbed' => !empty($_GET['dubbed']) || !empty($_GET['doble']),
        'subtitle' => !empty($_GET['subtitle']),
        'playonline' => !empty($_GET['playonline']),
        'page' => max(1, (int)($_GET['page'] ?? 1)),
    );

    api6_json(array_merge(array('status' => 'success', 'archive' => 3), api6_search($params)));
} catch (Throwable $e) {
    api6_json(array(
        'status' => 'error',
        'archive' => 3,
        'message' => 'دریافت اطلاعات آرشیو ۳ انجام نشد.',
        'error' => $e->getMessage(),
        'movies' => array(),
        'has_more' => false,
    ), 500);
}
