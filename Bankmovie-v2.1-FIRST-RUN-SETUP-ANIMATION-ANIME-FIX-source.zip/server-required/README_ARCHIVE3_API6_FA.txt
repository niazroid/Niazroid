نصب آرشیو ۳ / API6
====================

1) api6.php و api6_lib.php را در public_html و کنار هم آپلود کنید.
2) فایل‌های security_bootstrap.php و archive_control.php باید از قبل در همان مسیر موجود باشند.
3) افزونه PHP DOM باید فعال باشد؛ cURL نیز توصیه می‌شود.
4) ابتدا /api6.php?ping=1 و سپس /api6.php?search_options=1 را تست کنید.
5) برای فعال/غیرفعال‌سازی آرشیو ۳ از archive_control.php و تنظیم archive3 استفاده می‌شود.
6) در Remote Config می‌توانید archive3_api_url و home.archive3_sections را تغییر دهید.

فایل API6-APP-INTEGRATION-DOCUMENTATION-FA.md شامل قرارداد کامل API است.
