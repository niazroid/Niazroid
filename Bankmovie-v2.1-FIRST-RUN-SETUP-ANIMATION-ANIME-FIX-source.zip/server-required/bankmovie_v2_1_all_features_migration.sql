-- Bankmovie 2.1 unified comment/notification migration
-- Safe for the currently selected Bankmovie database. Take a backup first.
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS `comment_rate_limits` (
  `actor_key` varchar(190) NOT NULL,
  `window_started_at` datetime NOT NULL,
  `comment_count` int unsigned NOT NULL DEFAULT 0,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`actor_key`),
  KEY `idx_updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `comment_edit_history` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `archive_no` tinyint unsigned NOT NULL DEFAULT 1,
  `comment_id` bigint unsigned NOT NULL,
  `editor_user_id` bigint unsigned NOT NULL,
  `old_comment` text NOT NULL,
  `old_spoiler` tinyint(1) NOT NULL DEFAULT 0,
  `edited_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_comment` (`archive_no`,`comment_id`,`edited_at`),
  KEY `idx_editor` (`editor_user_id`,`edited_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `comment_reports` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `archive_no` tinyint unsigned NOT NULL DEFAULT 1,
  `movie_id` bigint unsigned NOT NULL DEFAULT 0,
  `comment_id` bigint unsigned NOT NULL,
  `reporter_user_id` bigint unsigned NOT NULL,
  `reason` varchar(60) NOT NULL,
  `details` varchar(500) NOT NULL DEFAULT '',
  `status` varchar(20) NOT NULL DEFAULT 'open',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reviewed_at` datetime DEFAULT NULL,
  `reviewed_by` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_comment_reporter` (`archive_no`,`comment_id`,`reporter_user_id`),
  KEY `idx_report_status` (`status`,`created_at`),
  KEY `idx_report_comment` (`archive_no`,`comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `app_notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `type` varchar(40) NOT NULL DEFAULT 'admin',
  `title` varchar(220) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `target_json` longtext,
  `dedupe_key` varchar(190) DEFAULT NULL,
  `read_at` datetime DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `dismissed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_dedupe` (`user_id`,`dedupe_key`),
  KEY `idx_user_read_created` (`user_id`,`read_at`,`created_at`),
  KEY `idx_user_dismissed_created` (`user_id`,`dismissed_at`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP PROCEDURE IF EXISTS `bm_add_column_if_missing`;
DELIMITER $$
CREATE PROCEDURE `bm_add_column_if_missing`(
  IN p_table varchar(64), IN p_column varchar(64), IN p_definition text
)
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=p_table)
     AND NOT EXISTS (SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=p_table AND COLUMN_NAME=p_column) THEN
    SET @bm_sql = CONCAT('ALTER TABLE `', REPLACE(p_table,'`',''), '` ADD COLUMN ', p_definition);
    PREPARE bm_stmt FROM @bm_sql;
    EXECUTE bm_stmt;
    DEALLOCATE PREPARE bm_stmt;
  END IF;
END$$
DELIMITER ;

CALL bm_add_column_if_missing('comments','is_pinned','`is_pinned` tinyint(1) NOT NULL DEFAULT 0 AFTER `status`');
CALL bm_add_column_if_missing('comments','pinned_at','`pinned_at` datetime NULL AFTER `is_pinned`');
CALL bm_add_column_if_missing('comments','edited_at','`edited_at` datetime NULL');
CALL bm_add_column_if_missing('archive1_comments','is_pinned','`is_pinned` tinyint(1) NOT NULL DEFAULT 0 AFTER `status`');
CALL bm_add_column_if_missing('archive1_comments','pinned_at','`pinned_at` datetime NULL AFTER `is_pinned`');
CALL bm_add_column_if_missing('archive1_comments','edited_at','`edited_at` datetime NULL');
CALL bm_add_column_if_missing('app_notifications','dedupe_key','`dedupe_key` varchar(190) NULL AFTER `target_json`');
CALL bm_add_column_if_missing('app_notifications','read_at','`read_at` datetime NULL AFTER `dedupe_key`');
CALL bm_add_column_if_missing('app_notifications','is_read','`is_read` tinyint(1) NOT NULL DEFAULT 0 AFTER `read_at`');
CALL bm_add_column_if_missing('comment_reports','reviewed_at','`reviewed_at` datetime NULL AFTER `created_at`');
CALL bm_add_column_if_missing('comment_reports','reviewed_by','`reviewed_by` bigint unsigned NULL AFTER `reviewed_at`');
DROP PROCEDURE IF EXISTS `bm_add_column_if_missing`;

UPDATE `app_notifications`
SET `read_at` = COALESCE(`read_at`, IF(`is_read`=1, `created_at`, NULL))
WHERE `is_read`=1;

SELECT TABLE_NAME, TABLE_ROWS
FROM information_schema.TABLES
WHERE TABLE_SCHEMA=DATABASE()
  AND TABLE_NAME IN ('comments','archive1_comments','comment_likes','archive1_comment_likes','comment_reports','comment_edit_history','comment_rate_limits','app_notifications')
ORDER BY TABLE_NAME;
