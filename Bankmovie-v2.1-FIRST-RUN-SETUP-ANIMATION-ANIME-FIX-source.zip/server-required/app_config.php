<?php
declare(strict_types=1);

@ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$configFile = __DIR__ . '/bankmovie_remote_config.json';
$default = [
    'schema_version' => 5,
    'ready' => true,
    'message' => 'اپ موقتاً در دسترس نیست.',
    'active_domain' => 'https://bankmovie.top',
    'api_url' => 'https://bankmovie.top/app_api.php',
    'account_api_url' => 'https://bankmovie.top/app_user_api.php',
    'account_api_urls' => ['https://bankmovie.top/app_user_api.php','https://bankmoviee.ir/app_user_api.php'],
    'servers' => [
        [
            'name' => 'سرور اصلی bankmovie.top',
            'enabled' => true,
            'priority' => 1,
            'domain' => 'https://bankmovie.top',
            'api_url' => 'https://bankmovie.top/app_api.php'
        ],
        [
            'name' => 'سرور دوم bankmoviee.ir',
            'enabled' => true,
            'priority' => 2,
            'domain' => 'https://bankmoviee.ir',
            'api_url' => 'https://bankmoviee.ir/app_api.php'
        ]
    ],
    'url_rewrites' => [],
    'features' => [
        'registration_enabled'=>true,'login_enabled'=>true,'comments_enabled'=>true,
        'comment_replies_enabled'=>true,'comment_votes_enabled'=>true,'comment_reports_enabled'=>true,'comment_spoiler_enabled'=>true,
        'notification_center_enabled'=>true,'internal_downloader_enabled'=>true,'multipart_download_enabled'=>true,
        'download_path_selection_enabled'=>true,'advanced_search_enabled'=>true,'categories_enabled'=>true,
        'watchlist_enabled'=>true,'continue_watching_enabled'=>true,'tv_quick_menu_enabled'=>true,
        'login_poster_url'=>'','download_limit'=>2,
        'archives'=>[
            'archive1_enabled'=>true,'archive1_hidden'=>false,
            'archive2_enabled'=>true,'archive2_hidden'=>false,
            'archive3_enabled'=>true,'archive3_hidden'=>false
        ]
    ],
    'comments' => ['edit_minutes'=>10,'rate_count'=>3,'rate_minutes'=>10,'auto_approve_admin'=>true,'auto_approve_vip'=>true],
    'downloads' => ['concurrent_limit'=>2,'retry_count'=>4,'retry_delay_seconds'=>8,'min_free_mb'=>256,'multipart_parts'=>4],
    'home' => [
        'archive1_sections'=>['updated_movies','updated_series','korean_series','dubbed','chinese_series','top_2026','anime','turkish','collections'],
        'archive2_sections'=>['updated_movies','updated_series','dubbed','animation','action','drama'],
        'archive3_sections'=>['new_movies','new_series','updated_animations','updated_anime','dubbed_movies','subtitled_movies']
    ],
    'notice'  => ['enabled'=>false,'id'=>'','type'=>'admin','title'=>'','message'=>'','dismissible'=>true,'target'=>['url'=>'']],
    'update' => [
        'enabled' => false,
        'version_code' => 1110000,
        'version_name' => '1.4',
        'apk_url' => '',
        'apk_urls' => ['universal'=>'','arm64_v8a'=>'','armeabi_v7a'=>''],
        'force' => false,
        'title' => 'آپدیت جدید آماده است',
        'message' => 'نسخه جدید Bankmovie آماده دانلود است.',
        'changes' => []
    ],
    'version_policy' => [
        'enabled' => true,
        'minimum_version_code' => 0,
        'minimum_version_name' => '',
        'blocked_version_names' => [],
        'blocked_version_codes' => [],
        'force_update_blocked' => true,
        'latest_version_only' => false,
        'block_message' => 'این نسخه از Bankmovie غیرفعال شده است. برای ادامه نسخه جدید را نصب کنید.'
    ],
    'updated_at' => gmdate('c')
];

if (is_file($configFile)) {
    $raw = file_get_contents($configFile);
    $saved = is_string($raw) ? json_decode($raw, true) : null;
    if (is_array($saved)) $default = array_replace_recursive($default, $saved);
}

echo json_encode($default, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
