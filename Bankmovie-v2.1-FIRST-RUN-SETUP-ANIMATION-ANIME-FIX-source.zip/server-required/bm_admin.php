<?php
declare(strict_types=1);

/**
 * Bankmovie App Admin v3
 * Security: site session + users.role=admin only. No standalone password.
 */

@ini_set('display_errors', '0');
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header("Permissions-Policy: camera=(), microphone=(), geolocation=()");

$usedSharedAdminGuard = false;
if (is_file(__DIR__ . '/admin_guard.php')) {
    require_once __DIR__ . '/admin_guard.php';
    if (function_exists('require_admin')) {
        require_admin();
        $usedSharedAdminGuard = true;
    }
}

if (!$usedSharedAdminGuard) {
    if (!is_file(__DIR__ . '/config.php')) {
        http_response_code(500);
        exit('config.php پیدا نشد. bm_admin.php باید در ریشه سایت نصب شود.');
    }
    require_once __DIR__ . '/config.php';
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();

    $bmRoleUser = (isset($currentUser) && is_array($currentUser)) ? $currentUser : null;

    // Compatible fallback for the site's session_token authentication.
    if (!$bmRoleUser && !empty($_COOKIE['session_token'])) {
        try {
            if (isset($userObj) && is_object($userObj) && method_exists($userObj, 'checkSession')) {
                $candidate = $userObj->checkSession((string)$_COOKIE['session_token']);
                if (is_array($candidate)) $bmRoleUser = $candidate;
            }
        } catch (Throwable $e) {
            $bmRoleUser = null;
        }
    }

    if (!$bmRoleUser || (($bmRoleUser['role'] ?? '') !== 'admin')) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'] ?? 'bm_admin.php';
        header('Location: login.php', true, 302);
        exit;
    }
    $currentUser = $bmRoleUser;
}

if (!isset($pdo) || !($pdo instanceof PDO)) {
    if (!is_file(__DIR__ . '/config.php')) {
        http_response_code(500);
        exit('config.php پیدا نشد.');
    }
    require_once __DIR__ . '/config.php';
}

require_once __DIR__ . '/bankmovie_comment_upgrade.php';
bm_site_comment_upgrade_schema($pdo);

function bm_admin_table_exists(PDO $pdo, string $table): bool {
    $safe = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    if ($safe === '') return false;
    try {
        $stmt = $pdo->prepare('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? LIMIT 1');
        $stmt->execute([$safe]);
        return (bool)$stmt->fetchColumn();
    } catch (Throwable $e) {
        return false;
    }
}

function bm_admin_user(): array {
    if (function_exists('admin_current_user')) {
        $u = admin_current_user();
        if (is_array($u)) return $u;
    }
    global $currentUser;
    return (isset($currentUser) && is_array($currentUser)) ? $currentUser : [];
}

function bm_h(mixed $value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function bm_csrf_token(): string {
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    if (empty($_SESSION['bm_admin_csrf_v2'])) {
        $_SESSION['bm_admin_csrf_v2'] = bin2hex(random_bytes(32));
    }
    return (string)$_SESSION['bm_admin_csrf_v2'];
}

function bm_verify_csrf(): void {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') return;
    $posted = (string)($_POST['bm_admin_csrf'] ?? '');
    if ($posted === '' || !hash_equals(bm_csrf_token(), $posted)) {
        http_response_code(403);
        exit('درخواست نامعتبر است. صفحه را تازه‌سازی کن.');
    }
}

function bm_default_config(): array {
    return [
        'schema_version' => 5,
        'ready' => true,
        'message' => 'اپ موقتاً در دسترس نیست.',
        'active_domain' => 'https://bankmoviee.ir',
        'api_url' => 'https://bankmoviee.ir/app_api.php',
        'account_api_url' => 'https://bankmoviee.ir/app_user_api.php',
        'account_api_urls' => ['https://bankmoviee.ir/app_user_api.php'],
        'servers' => [
            [
                'name' => 'سرور اصلی',
                'enabled' => true,
                'priority' => 1,
                'domain' => 'https://bankmoviee.ir',
                'api_url' => 'https://bankmoviee.ir/app_api.php'
            ]
        ],
        'url_rewrites' => [],
        'features' => [
            'registration_enabled'=>true,'login_enabled'=>true,'comments_enabled'=>true,
            'comment_replies_enabled'=>true,'comment_votes_enabled'=>true,'comment_reports_enabled'=>true,'comment_spoiler_enabled'=>true,
            'notification_center_enabled'=>true,'internal_downloader_enabled'=>true,'multipart_download_enabled'=>true,
            'download_path_selection_enabled'=>true,'advanced_search_enabled'=>true,'categories_enabled'=>true,
            'watchlist_enabled'=>true,'continue_watching_enabled'=>true,'tv_quick_menu_enabled'=>true,
            'login_poster_url'=>'','download_limit'=>2,
            'archives'=>[
                'archive1_enabled'=>true,'archive1_hidden'=>false,
                'archive2_enabled'=>true,'archive2_hidden'=>false,
                'archive3_enabled'=>true,'archive3_hidden'=>false
            ]
        ],
        'comments'=>['edit_minutes'=>10,'rate_count'=>3,'rate_minutes'=>10,'auto_approve_admin'=>true,'auto_approve_vip'=>true],
        'downloads'=>['concurrent_limit'=>2,'retry_count'=>4,'retry_delay_seconds'=>8,'min_free_mb'=>256,'multipart_parts'=>4],
        'home'=>[
            'archive1_sections'=>['updated_movies','updated_series','korean_series','dubbed','chinese_series','top_2026','anime','turkish','collections'],
            'archive2_sections'=>['updated_movies','updated_series','dubbed','animation','action','drama'],
            'archive3_sections'=>['new_movies','new_series','updated_animations','updated_anime','dubbed_movies','subtitled_movies']
        ],
        'notice' => [
            'enabled' => false,
            'id' => '',
            'type' => 'admin',
            'title' => '',
            'message' => '',
            'target' => [],
            'dismissible' => true
        ],
        'update' => [
            'enabled' => false,
            'version_code' => 1110000,
            'version_name' => '1.4',
            'apk_url' => '',
            'apk_urls' => [
                'universal' => '',
                'arm64_v8a' => '',
                'armeabi_v7a' => ''
            ],
            'force' => false,
            'title' => 'آپدیت جدید آماده است',
            'message' => 'نسخه جدید Bankmovie آماده دانلود است.',
            'changes' => []
        ],
        'version_policy' => [
            'enabled' => true,
            'minimum_version_code' => 0,
            'minimum_version_name' => '',
            'blocked_version_names' => [],
            'blocked_version_codes' => [],
            'force_update_blocked' => true,
            'latest_version_only' => false,
            'block_message' => 'این نسخه از Bankmovie غیرفعال شده است. برای ادامه نسخه جدید را نصب کنید.'
        ],
        'updated_at' => gmdate('c')
    ];
}

function bm_load_config(string $file): array {
    $cfg = bm_default_config();
    if (!is_file($file)) return $cfg;
    $raw = file_get_contents($file);
    $saved = is_string($raw) ? json_decode($raw, true) : null;
    return is_array($saved) ? array_replace_recursive($cfg, $saved) : $cfg;
}

function bm_bool(string $name): bool {
    return isset($_POST[$name]) && (string)$_POST[$name] === '1';
}

function bm_lines(string $raw): array {
    $raw = str_replace(["\r\n", "\r", ',', '،'], "\n", $raw);
    $items = array_map('trim', explode("\n", $raw));
    $items = array_values(array_unique(array_filter($items, static fn($v) => $v !== '')));
    return array_slice($items, 0, 100);
}

function bm_int_lines(string $raw): array {
    $out = [];
    foreach (bm_lines($raw) as $item) {
        $value = (int)$item;
        if ($value > 0) $out[] = $value;
    }
    return array_values(array_unique($out));
}

function bm_clean_url(string $url, bool $allowEmpty = true): string {
    $url = trim($url);
    if ($url === '' && $allowEmpty) return '';
    if (!preg_match('~^https?://~i', $url)) $url = 'https://' . ltrim($url, '/');
    if (!filter_var($url, FILTER_VALIDATE_URL)) throw new RuntimeException('یکی از لینک‌ها معتبر نیست.');
    return $url;
}

function bm_parse_servers(): array {
    $names = isset($_POST['server_name']) && is_array($_POST['server_name']) ? $_POST['server_name'] : [];
    $domains = isset($_POST['server_domain']) && is_array($_POST['server_domain']) ? $_POST['server_domain'] : [];
    $apis = isset($_POST['server_api']) && is_array($_POST['server_api']) ? $_POST['server_api'] : [];
    $priorities = isset($_POST['server_priority']) && is_array($_POST['server_priority']) ? $_POST['server_priority'] : [];
    $enabledMap = isset($_POST['server_enabled']) && is_array($_POST['server_enabled']) ? $_POST['server_enabled'] : [];

    $indexes = array_values(array_unique(array_merge(
        array_keys($names), array_keys($domains), array_keys($apis), array_keys($priorities)
    )));
    $servers = [];

    foreach ($indexes as $index) {
        $name = trim((string)($names[$index] ?? ''));
        $domainRaw = trim((string)($domains[$index] ?? ''));
        $apiRaw = trim((string)($apis[$index] ?? ''));
        if ($name === '' && $domainRaw === '' && $apiRaw === '') continue;

        $domain = rtrim(bm_clean_url($domainRaw, false), '/');
        $api = $apiRaw === '' ? $domain . '/app_api.php' : bm_clean_url($apiRaw, false);
        $servers[] = [
            'name' => $name !== '' ? $name : ('سرور ' . (count($servers) + 1)),
            'enabled' => isset($enabledMap[$index]) && (string)$enabledMap[$index] === '1',
            'priority' => max(1, (int)($priorities[$index] ?? (count($servers) + 1))),
            'domain' => $domain,
            'api_url' => $api
        ];
    }

    usort($servers, static fn(array $a, array $b): int => ($a['priority'] <=> $b['priority']));
    if (!$servers) throw new RuntimeException('حداقل یک سرور باید ثبت شود.');
    if (!array_filter($servers, static fn(array $server): bool => !empty($server['enabled']))) {
        throw new RuntimeException('حداقل یک سرور باید فعال باشد.');
    }
    return array_values($servers);
}

function bm_parse_rewrites(): array {
    $froms = isset($_POST['rewrite_from']) && is_array($_POST['rewrite_from']) ? $_POST['rewrite_from'] : [];
    $tos = isset($_POST['rewrite_to']) && is_array($_POST['rewrite_to']) ? $_POST['rewrite_to'] : [];
    $modes = isset($_POST['rewrite_mode']) && is_array($_POST['rewrite_mode']) ? $_POST['rewrite_mode'] : [];
    $enabledMap = isset($_POST['rewrite_enabled']) && is_array($_POST['rewrite_enabled']) ? $_POST['rewrite_enabled'] : [];

    $indexes = array_values(array_unique(array_merge(array_keys($froms), array_keys($tos), array_keys($modes))));
    $rules = [];
    foreach ($indexes as $index) {
        $from = trim((string)($froms[$index] ?? ''));
        $to = trim((string)($tos[$index] ?? ''));
        $mode = (string)($modes[$index] ?? 'replace');
        if ($from === '') continue;
        if (!in_array($mode, ['replace', 'active'], true)) $mode = 'replace';
        if ($mode === 'active') {
            $to = 'ACTIVE';
        } elseif ($to === '') {
            throw new RuntimeException('برای قانون جایگزینی دامنه، دامنه مقصد را وارد کن.');
        } else {
            $to = rtrim(bm_clean_url($to, false), '/');
        }
        $rules[] = [
            'enabled' => isset($enabledMap[$index]) && (string)$enabledMap[$index] === '1',
            'from' => $from,
            'to' => $to,
            'mode' => $mode
        ];
    }
    return $rules;
}

function bm_atomic_save(string $file, array $config): void {
    $json = json_encode($config, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if (!is_string($json)) throw new RuntimeException('ساخت JSON تنظیمات ناموفق بود.');

    if (is_file($file)) @copy($file, $file . '.backup');
    $tmp = $file . '.tmp.' . bin2hex(random_bytes(5));
    if (file_put_contents($tmp, $json . "\n", LOCK_EX) === false) {
        throw new RuntimeException('امکان نوشتن فایل تنظیمات وجود ندارد.');
    }
    @chmod($tmp, 0640);
    if (!@rename($tmp, $file)) {
        @unlink($tmp);
        throw new RuntimeException('جایگزینی امن فایل تنظیمات ناموفق بود.');
    }
}

function bm_audit(string $file, array $user, string $action, array $details = []): void {
    $record = [
        'time' => gmdate('c'),
        'admin_id' => $user['id'] ?? null,
        'admin' => $user['username'] ?? $user['email'] ?? 'admin',
        'action' => $action,
        'details' => $details,
        'ip_hash' => substr(hash('sha256', (string)($_SERVER['REMOTE_ADDR'] ?? '')), 0, 12)
    ];
    @file_put_contents($file, json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n", FILE_APPEND | LOCK_EX);
}

function bm_last_audits(string $file, int $limit = 8): array {
    if (!is_file($file)) return [];
    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
    $out = [];
    foreach (array_slice(array_reverse($lines), 0, $limit) as $line) {
        $row = json_decode($line, true);
        if (is_array($row)) $out[] = $row;
    }
    return $out;
}

bm_verify_csrf();

$configFile = __DIR__ . '/bankmovie_remote_config.json';
$auditFile = __DIR__ . '/bankmovie_admin_audit.log';
$user = bm_admin_user();
$config = bm_load_config($configFile);
$savedOk = false;
$saveError = '';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    try {
        $action = (string)($_POST['action'] ?? 'save');

        if (in_array($action, ['comment_approve','comment_reject','comment_delete','comment_pin','comment_unpin','comment_spoiler','comment_unspoiler'], true)) {
            $source = ((string)($_POST['comment_source'] ?? 'database') === 'archive1') ? 'archive1' : 'database';
            $table = $source === 'archive1' ? 'archive1_comments' : 'comments';
            $likes = $source === 'archive1' ? 'archive1_comment_likes' : 'comment_likes';
            $id = max(0, (int)($_POST['comment_id'] ?? 0));
            if ($id <= 0 || !bm_admin_table_exists($pdo, $table)) throw new RuntimeException('دیدگاه پیدا نشد.');
            $metaStmt=$pdo->prepare("SELECT user_id,movie_id FROM `{$table}` WHERE id=? LIMIT 1");
            $metaStmt->execute([$id]);
            $commentMeta=$metaStmt->fetch(PDO::FETCH_ASSOC)?:[];
            if ($action === 'comment_approve') {
                $pdo->prepare("UPDATE `{$table}` SET status='approved' WHERE id=?")->execute([$id]);
            } elseif ($action === 'comment_reject') {
                $pdo->prepare("UPDATE `{$table}` SET status='rejected' WHERE id=?")->execute([$id]);
            } elseif ($action === 'comment_pin' || $action === 'comment_unpin') {
                $pin = $action === 'comment_pin' ? 1 : 0;
                $pdo->prepare("UPDATE `{$table}` SET is_pinned=?,pinned_at=IF(?=1,NOW(),NULL) WHERE id=?")->execute([$pin,$pin,$id]);
            } elseif ($action === 'comment_spoiler' || $action === 'comment_unspoiler') {
                $spoiler = $action === 'comment_spoiler' ? 1 : 0;
                $pdo->prepare("UPDATE `{$table}` SET spoiler=? WHERE id=?")->execute([$spoiler,$id]);
            } else {
                $idsStmt = $pdo->prepare("SELECT id FROM `{$table}` WHERE id=? OR parent_id=?");
                $idsStmt->execute([$id,$id]);
                $ids = array_map('intval', $idsStmt->fetchAll(PDO::FETCH_COLUMN) ?: []);
                if ($ids && bm_admin_table_exists($pdo, $likes)) {
                    $marks = implode(',', array_fill(0, count($ids), '?'));
                    $pdo->prepare("DELETE FROM `{$likes}` WHERE comment_id IN ({$marks})")->execute($ids);
                }
                $pdo->prepare("DELETE FROM `{$table}` WHERE id=? OR parent_id=?")->execute([$id,$id]);
            }
            if ($action === 'comment_approve' || $action === 'comment_reject') {
                bm_site_comment_notify_status(
                    $pdo,(int)($commentMeta['user_id']??0),$source==='archive1'?1:2,
                    (int)($commentMeta['movie_id']??0),$id,$action==='comment_approve'?'approved':'rejected'
                );
            }
            bm_audit($auditFile, $user, $action, ['source'=>$source,'comment_id'=>$id]);
            $savedOk = true;
        } elseif (in_array($action,['comment_report_resolve','comment_report_reject'],true)) {
            $reportId=max(0,(int)($_POST['report_id']??0));
            if ($reportId<=0 || !bm_admin_table_exists($pdo,'comment_reports')) throw new RuntimeException('گزارش پیدا نشد.');
            $status=$action==='comment_report_resolve'?'resolved':'rejected';
            $pdo->prepare("UPDATE comment_reports SET status=?,reviewed_at=NOW(),reviewed_by=? WHERE id=?")->execute([$status,(int)($user['id']??0),$reportId]);
            bm_audit($auditFile,$user,$action,['report_id'=>$reportId]);
            $savedOk=true;
        } elseif ($action === 'block_13' || $action === 'unblock_13') {
            $blocked = array_map('strval', (array)($config['version_policy']['blocked_version_names'] ?? []));
            $blocked = array_values(array_unique(array_filter(array_map('trim', $blocked))));
            if ($action === 'block_13' && !in_array('1.3', $blocked, true)) $blocked[] = '1.3';
            if ($action === 'unblock_13') $blocked = array_values(array_filter($blocked, static fn($v) => $v !== '1.3'));
            $config['version_policy']['enabled'] = true;
            $config['version_policy']['blocked_version_names'] = $blocked;
            $config['updated_at'] = gmdate('c');
            bm_atomic_save($configFile, $config);
            bm_audit($auditFile, $user, $action, ['version' => '1.3']);
            $savedOk = true;
        } else {
            $servers = bm_parse_servers();
            $rewrites = bm_parse_rewrites();
            $firstEnabled = null;
            foreach ($servers as $server) {
                if (!empty($server['enabled'])) {
                    $firstEnabled = $server;
                    break;
                }
            }
            if (!$firstEnabled) throw new RuntimeException('سرور فعال پیدا نشد.');
            $activeDomain = (string)$firstEnabled['domain'];
            $apiUrl = (string)$firstEnabled['api_url'];
            $universal = bm_clean_url((string)($_POST['apk_universal'] ?? ''), true);
            $arm64 = bm_clean_url((string)($_POST['apk_arm64'] ?? ''), true);
            $v7a = bm_clean_url((string)($_POST['apk_v7a'] ?? ''), true);
            $fallback = $universal;

            $noticeMessage = trim((string)($_POST['notice_message'] ?? ''));
            $noticeId = trim((string)($_POST['notice_id'] ?? ''));
            if ($noticeMessage !== '' && $noticeId === '') $noticeId = 'notice_' . time();

            $versionName = trim((string)($_POST['version_name'] ?? '1.4'));
            if ($versionName === '') throw new RuntimeException('Version Name نمی‌تواند خالی باشد.');

            $config = [
                'schema_version' => 5,
                'ready' => bm_bool('ready'),
                'message' => trim((string)($_POST['maintenance_message'] ?? 'اپ موقتاً در دسترس نیست.')),
                'active_domain' => $activeDomain,
                'api_url' => $apiUrl,
                'account_api_url' => rtrim($activeDomain, '/') . '/app_user_api.php',
                'account_api_urls' => array_values(array_unique(array_map(static fn($sv) => rtrim((string)($sv['domain']??''),'/').'/app_user_api.php', array_filter($servers, static fn($sv) => !empty($sv['enabled']))))),
                'servers' => $servers,
                'url_rewrites' => $rewrites,
                'features' => [
                    'registration_enabled'=>bm_bool('registration_enabled'),
                    'login_enabled'=>bm_bool('login_enabled'),
                    'comments_enabled'=>bm_bool('comments_enabled'),
                    'comment_replies_enabled'=>bm_bool('comment_replies_enabled'),
                    'comment_votes_enabled'=>bm_bool('comment_votes_enabled'),
                    'comment_reports_enabled'=>bm_bool('comment_reports_enabled'),
                    'comment_spoiler_enabled'=>bm_bool('comment_spoiler_enabled'),
                    'notification_center_enabled'=>bm_bool('notification_center_enabled'),
                    'internal_downloader_enabled'=>bm_bool('internal_downloader_enabled'),
                    'multipart_download_enabled'=>bm_bool('multipart_download_enabled'),
                    'download_path_selection_enabled'=>bm_bool('download_path_selection_enabled'),
                    'advanced_search_enabled'=>bm_bool('advanced_search_enabled'),
                    'categories_enabled'=>bm_bool('categories_enabled'),
                    'watchlist_enabled'=>bm_bool('watchlist_enabled'),
                    'continue_watching_enabled'=>bm_bool('continue_watching_enabled'),
                    'tv_quick_menu_enabled'=>bm_bool('tv_quick_menu_enabled'),
                    'login_poster_url'=>trim((string)($_POST['login_poster_url']??'')),
                    'download_limit'=>max(1,min(4,(int)($_POST['download_limit']??2))),
                    'archives'=>[
                        'archive1_enabled'=>bm_bool('archive1_enabled'),'archive1_hidden'=>bm_bool('archive1_hidden'),
                        'archive2_enabled'=>bm_bool('archive2_enabled'),'archive2_hidden'=>bm_bool('archive2_hidden'),
                        'archive3_enabled'=>bm_bool('archive3_enabled'),'archive3_hidden'=>bm_bool('archive3_hidden')
                    ]
                ],
                'comments'=>[
                    'edit_minutes'=>max(0,min(1440,(int)($_POST['comment_edit_minutes']??10))),
                    'rate_count'=>max(1,min(30,(int)($_POST['comment_rate_count']??3))),
                    'rate_minutes'=>max(1,min(1440,(int)($_POST['comment_rate_minutes']??10))),
                    'auto_approve_admin'=>bm_bool('comment_auto_approve_admin'),
                    'auto_approve_vip'=>bm_bool('comment_auto_approve_vip')
                ],
                'downloads'=>[
                    'concurrent_limit'=>max(1,min(4,(int)($_POST['download_limit']??2))),
                    'retry_count'=>max(0,min(12,(int)($_POST['download_retry_count']??4))),
                    'retry_delay_seconds'=>max(2,min(300,(int)($_POST['download_retry_delay_seconds']??8))),
                    'min_free_mb'=>max(32,min(8192,(int)($_POST['download_min_free_mb']??256))),
                    'multipart_parts'=>max(2,min(6,(int)($_POST['multipart_parts']??4)))
                ],
                'home'=>[
                    'archive1_sections'=>bm_lines((string)($_POST['home_archive1_sections']??'')),
                    'archive2_sections'=>bm_lines((string)($_POST['home_archive2_sections']??'')),
                    'archive3_sections'=>bm_lines((string)($_POST['home_archive3_sections']??''))
                ],
                'notice' => [
                    'enabled' => bm_bool('notice_enabled'),
                    'id' => $noticeId,
                    'type' => in_array((string)($_POST['notice_type'] ?? 'admin'), ['admin','system','update','maintenance'], true) ? (string)$_POST['notice_type'] : 'admin',
                    'title' => trim((string)($_POST['notice_title'] ?? '')),
                    'message' => $noticeMessage,
                    'dismissible' => bm_bool('notice_dismissible'),
                    'target' => ['url'=>trim((string)($_POST['notice_target_url'] ?? ''))]
                ],
                'update' => [
                    'enabled' => bm_bool('update_enabled'),
                    'version_code' => max(0, (int)($_POST['version_code'] ?? 0)),
                    'version_name' => $versionName,
                    'apk_url' => $fallback,
                    'apk_urls' => [
                        'universal' => $universal,
                        'arm64_v8a' => $arm64,
                        'armeabi_v7a' => $v7a
                    ],
                    'force' => bm_bool('force_update'),
                    'title' => trim((string)($_POST['update_title'] ?? 'آپدیت جدید آماده است')),
                    'message' => trim((string)($_POST['update_message'] ?? 'نسخه جدید Bankmovie آماده دانلود است.')),
                    'changes' => bm_lines((string)($_POST['changes'] ?? ''))
                ],
                'version_policy' => [
                    'enabled' => bm_bool('version_policy_enabled'),
                    'minimum_version_code' => max(0, (int)($_POST['minimum_version_code'] ?? 0)),
                    'minimum_version_name' => trim((string)($_POST['minimum_version_name'] ?? '')),
                    'blocked_version_names' => bm_lines((string)($_POST['blocked_version_names'] ?? '')),
                    'blocked_version_codes' => bm_int_lines((string)($_POST['blocked_version_codes'] ?? '')),
                    'force_update_blocked' => bm_bool('force_update_blocked'),
                    'latest_version_only' => bm_bool('latest_version_only'),
                    'block_message' => trim((string)($_POST['block_message'] ?? 'این نسخه از Bankmovie غیرفعال شده است. برای ادامه نسخه جدید را نصب کنید.'))
                ],
                'updated_at' => gmdate('c')
            ];

            bm_atomic_save($configFile, $config);
            bm_audit($auditFile, $user, 'save_config', [
                'version_name' => $versionName,
                'update_enabled' => $config['update']['enabled'],
                'blocked_versions' => $config['version_policy']['blocked_version_names'],
                'server_count' => count($servers),
                'rewrite_count' => count($rewrites)
            ]);
            $savedOk = true;
        }
        $config = bm_load_config($configFile);
    } catch (Throwable $e) {
        $saveError = $e->getMessage();
    }
}

$changesText = implode("\n", (array)($config['update']['changes'] ?? []));
$homeArchive1Text = implode("\n", array_map('strval', (array)($config['home']['archive1_sections'] ?? [])));
$homeArchive2Text = implode("\n", array_map('strval', (array)($config['home']['archive2_sections'] ?? [])));
$homeArchive3Text = implode("\n", array_map('strval', (array)($config['home']['archive3_sections'] ?? [])));
$blockedNamesText = implode("\n", array_map('strval', (array)($config['version_policy']['blocked_version_names'] ?? [])));
$blockedCodesText = implode("\n", array_map('strval', (array)($config['version_policy']['blocked_version_codes'] ?? [])));
$servers = array_values((array)($config['servers'] ?? []));
if (!$servers) {
    $servers = [[
        'name' => 'سرور اصلی',
        'enabled' => true,
        'priority' => 1,
        'domain' => (string)($config['active_domain'] ?? 'https://bankmoviee.ir'),
        'api_url' => (string)($config['api_url'] ?? 'https://bankmoviee.ir/app_api.php')
    ]];
}
$rewrites = array_values((array)($config['url_rewrites'] ?? []));
$audits = bm_last_audits($auditFile);
$adminName = $user['username'] ?? $user['email'] ?? 'admin';
$blocked13 = in_array('1.3', (array)($config['version_policy']['blocked_version_names'] ?? []), true);
$bmPendingComments = [];
try {
    $parts = [];
    if (bm_admin_table_exists($pdo, 'comments')) {
        $parts[] = "SELECT c.id,c.comment,c.created_at,c.username,COALESCE(u.username,c.username,'کاربر') user_name,'database' comment_source,COALESCE(m.title_fa,m.title,CONCAT('#',c.movie_id)) movie_title FROM comments c LEFT JOIN users u ON u.id=c.user_id LEFT JOIN movies m ON m.id=c.movie_id WHERE c.status='pending'";
    }
    if (bm_admin_table_exists($pdo, 'archive1_comments')) {
        $title = bm_admin_table_exists($pdo, 'archive1_items') ? "COALESCE(NULLIF(ai.item_title_fa,''),NULLIF(ai.item_title,''),CONCAT('آرشیو خارجی • ',c.movie_id))" : "CONCAT('آرشیو خارجی • ',c.movie_id)";
        $join = bm_admin_table_exists($pdo, 'archive1_items') ? " LEFT JOIN archive1_items ai ON ai.virtual_movie_id=c.movie_id " : " ";
        $parts[] = "SELECT c.id,c.comment,c.created_at,c.username,COALESCE(u.username,c.username,'کاربر') user_name,'archive1' comment_source,{$title} movie_title FROM archive1_comments c {$join} LEFT JOIN users u ON u.id=c.user_id WHERE c.status='pending'";
    }
    if ($parts) $bmPendingComments = $pdo->query("SELECT * FROM (" . implode(' UNION ALL ', $parts) . ") q ORDER BY created_at DESC,id DESC LIMIT 40")->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
    $saveError = $saveError !== '' ? $saveError : ('خطا در دریافت دیدگاه‌ها: ' . $e->getMessage());
}
$bmRecentComments=[];
$bmOpenCommentReports=[];
try {
    $parts=[];
    if (bm_admin_table_exists($pdo,'comments')) $parts[]="SELECT c.id,c.comment,c.created_at,c.is_pinned,c.spoiler,COALESCE(u.username,c.username,'کاربر') user_name,'database' comment_source,COALESCE(m.title_fa,m.title,CONCAT('#',c.movie_id)) movie_title FROM comments c LEFT JOIN users u ON u.id=c.user_id LEFT JOIN movies m ON m.id=c.movie_id WHERE LOWER(TRIM(CAST(c.status AS CHAR))) IN ('approved','active','1')";
    if (bm_admin_table_exists($pdo,'archive1_comments')) {
        $title=bm_admin_table_exists($pdo,'archive1_items')?"COALESCE(NULLIF(ai.item_title_fa,''),NULLIF(ai.item_title,''),CONCAT('آرشیو خارجی • ',c.movie_id))":"CONCAT('آرشیو خارجی • ',c.movie_id)";
        $join=bm_admin_table_exists($pdo,'archive1_items')?" LEFT JOIN archive1_items ai ON ai.virtual_movie_id=c.movie_id ":" ";
        $parts[]="SELECT c.id,c.comment,c.created_at,c.is_pinned,c.spoiler,COALESCE(u.username,c.username,'کاربر') user_name,'archive1' comment_source,{$title} movie_title FROM archive1_comments c {$join} LEFT JOIN users u ON u.id=c.user_id WHERE LOWER(TRIM(CAST(c.status AS CHAR))) IN ('approved','active','1')";
    }
    if($parts)$bmRecentComments=$pdo->query("SELECT * FROM (".implode(' UNION ALL ',$parts).") q ORDER BY created_at DESC,id DESC LIMIT 30")->fetchAll(PDO::FETCH_ASSOC)?:[];
    if(bm_admin_table_exists($pdo,'comment_reports')){
        $bmOpenCommentReports=$pdo->query("SELECT r.*,COALESCE(u.username,u.email,CONCAT('کاربر #',r.reporter_user_id)) reporter_name FROM comment_reports r LEFT JOIN users u ON u.id=r.reporter_user_id WHERE r.status='open' ORDER BY r.created_at DESC LIMIT 40")->fetchAll(PDO::FETCH_ASSOC)?:[];
    }
} catch(Throwable $e){$saveError=$saveError!==''?$saveError:('خطا در مدیریت گزارش دیدگاه: '.$e->getMessage());}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>BM Admin — مدیریت اپ</title>
<style>
:root{--bg:#05070d;--card:#0d1421;--card2:#080d16;--line:rgba(255,255,255,.11);--text:#fff;--muted:#aebbd1;--accent:#8b5cf6;--green:#22c55e;--red:#ef4444;--amber:#f59e0b}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 78% 0,rgba(139,92,246,.19),transparent 27%),linear-gradient(180deg,#05070d,#070b13);color:var(--text);font-family:tahoma,Arial,sans-serif}.wrap{max-width:1160px;margin:24px auto;padding:16px}.top{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:14px}.top h1{font-size:24px;margin:0}.badge-row{display:flex;gap:8px;flex-wrap:wrap}.badge,.badge-row a{padding:9px 13px;border:1px solid var(--line);background:rgba(255,255,255,.055);border-radius:999px;color:#dbe8ff;text-decoration:none;font-size:12px;font-weight:800}.dashboard{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:14px}.stat{background:linear-gradient(145deg,rgba(16,24,39,.94),rgba(8,10,18,.96));border:1px solid var(--line);border-radius:22px;padding:16px}.stat small{color:var(--muted)}.stat b{display:block;font-size:19px;margin-top:7px}.card{background:linear-gradient(145deg,rgba(16,24,39,.94),rgba(8,10,18,.96));border:1px solid var(--line);border-radius:26px;padding:22px;margin-bottom:14px;box-shadow:0 20px 60px rgba(0,0,0,.26)}h2{font-size:18px;margin:0 0 8px}h3{font-size:15px;margin:22px 0 8px;color:#e9e7ff}.desc,.note{color:var(--muted);font-size:12.5px;line-height:1.9}.note{padding:12px;border:1px solid var(--line);background:rgba(255,255,255,.04);border-radius:15px}.security{border-color:rgba(34,197,94,.35);background:rgba(34,197,94,.08)}.row{display:grid;grid-template-columns:1fr 1fr;gap:13px}.row3{display:grid;grid-template-columns:repeat(3,1fr);gap:13px}label{display:block;margin:13px 0 6px;color:#cbd6e8;font-size:13px;font-weight:800}input,textarea,select{width:100%;border-radius:14px;border:1px solid rgba(255,255,255,.15);background:#060a12;color:#fff;padding:12px 13px;font:inherit;outline:none}select{border-radius:14px;border:1px solid rgba(255,255,255,.15);background:#060a12;color:#fff;padding:12px 13px;font:inherit;outline:none}textarea{min-height:100px;resize:vertical}.checks{display:flex;gap:9px;flex-wrap:wrap;margin:14px 0}.chk{display:flex;align-items:center;gap:7px;border:1px solid var(--line);background:rgba(255,255,255,.05);border-radius:999px;padding:10px 13px;font-size:12px;font-weight:800}.chk input{width:auto}.btn{display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:999px;padding:12px 20px;background:linear-gradient(135deg,#8b5cf6,#5b35dc);color:#fff;font-weight:900;cursor:pointer;text-decoration:none}.btn.red{background:linear-gradient(135deg,#ef4444,#a91d2d)}.btn.green{background:linear-gradient(135deg,#22c55e,#14863e)}.quick{display:flex;gap:10px;flex-wrap:wrap}.ok,.err{border-radius:14px;padding:12px;margin-bottom:14px}.ok{background:#0d3b25;border:1px solid #1fb86a;color:#c9ffdc}.err{background:#3b1111;border:1px solid #ff5b5b;color:#ffd0d0}.audit{display:grid;gap:8px}.audit-item{padding:11px 13px;border:1px solid var(--line);background:rgba(255,255,255,.035);border-radius:14px;font-size:12px;color:#cbd6e8}.split{display:grid;grid-template-columns:1.25fr .75fr;gap:14px}.server-list,.rewrite-list{display:grid;gap:10px}.server-row,.rewrite-row{border:1px solid var(--line);background:rgba(255,255,255,.028);border-radius:18px;padding:12px}.server-grid{display:grid;grid-template-columns:1.1fr 1.7fr 1.9fr .55fr;gap:9px;align-items:end}.rewrite-grid{display:grid;grid-template-columns:1.35fr 1.35fr .8fr;gap:9px;align-items:end}.mini-actions{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-top:8px}.remove-row{border:0;background:rgba(239,68,68,.16);color:#ffb8b8;border-radius:999px;padding:8px 12px;cursor:pointer;font-weight:800}.add-row{border:1px dashed rgba(139,92,246,.7);background:rgba(139,92,246,.08);color:#e9dcff;border-radius:15px;padding:11px 14px;cursor:pointer;font-weight:900;margin-top:9px;width:100%}@media(max-width:900px){.dashboard{grid-template-columns:1fr 1fr}.split{grid-template-columns:1fr}}@media(max-width:680px){.row,.row3,.dashboard,.server-grid,.rewrite-grid{grid-template-columns:1fr}.wrap{padding:10px;margin:0}.card{border-radius:20px;padding:16px}.top{align-items:flex-start}}
</style>
</head>
<body>
<div class="wrap">
  <div class="top">
    <h1>BM Admin — مدیریت کامل اپ</h1>
    <div class="badge-row">
      <span class="badge">نقش تأییدشده: admin — <?= bm_h($adminName) ?></span>
      <a href="admin.php">پنل اصلی</a>
      <a href="logout.php">خروج</a>
    </div>
  </div>

  <?php if ($savedOk): ?><div class="ok">تنظیمات با موفقیت و به‌صورت امن ذخیره شد.</div><?php endif; ?>
  <?php if ($saveError !== ''): ?><div class="err"><?= bm_h($saveError) ?></div><?php endif; ?>

  <div class="dashboard">
    <div class="stat"><small>وضعیت اپ</small><b><?= !empty($config['ready']) ? 'فعال' : 'غیرفعال' ?></b></div>
    <div class="stat"><small>نسخه انتشار</small><b><?= bm_h($config['update']['version_name'] ?? '-') ?></b></div>
    <div class="stat"><small>آپدیت</small><b><?= !empty($config['update']['enabled']) ? 'فعال' : 'خاموش' ?></b></div>
    <div class="stat"><small>سرورهای فعال</small><b><?= count(array_filter($servers, static fn($v) => !empty($v['enabled']))) ?> / <?= count($servers) ?></b></div>
  </div>

  <div class="note security">این صفحه هیچ رمز مستقل یا رمز هاردکدشده‌ای ندارد. فقط نشست ورود سایت و کاربر دارای <b>users.role = admin</b> پذیرفته می‌شود. ذخیره‌ها CSRF، بکاپ، نوشتن اتمیک و گزارش فعالیت دارند.</div>

  <div class="split">
    <form method="post" class="card">
      <input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>">
      <input type="hidden" name="action" value="save">

      <h2>کنترل عملیاتی</h2>
      <div class="checks">
        <label class="chk"><input type="checkbox" name="ready" value="1" <?= !empty($config['ready'])?'checked':'' ?>> اپ فعال</label>
        <label class="chk"><input type="checkbox" name="notice_enabled" value="1" <?= !empty($config['notice']['enabled'])?'checked':'' ?>> پیام داخل اپ</label>
        <label class="chk"><input type="checkbox" name="notice_dismissible" value="1" <?= !array_key_exists('dismissible',(array)($config['notice']??[])) || !empty($config['notice']['dismissible'])?'checked':'' ?>> پیام قابل بستن باشد</label>
        <label class="chk"><input type="checkbox" name="update_enabled" value="1" <?= !empty($config['update']['enabled'])?'checked':'' ?>> آپدیت فعال</label>
        <label class="chk"><input type="checkbox" name="force_update" value="1" <?= !empty($config['update']['force'])?'checked':'' ?>> اجبار فقط برای نسخه جدیدتر</label>
        <label class="chk"><input type="checkbox" name="version_policy_enabled" value="1" <?= !empty($config['version_policy']['enabled'])?'checked':'' ?>> سیاست نسخه فعال</label>
        <label class="chk"><input type="checkbox" name="force_update_blocked" value="1" <?= !empty($config['version_policy']['force_update_blocked'])?'checked':'' ?>> نسخه مسدود قابل بستن نباشد</label>
        <label class="chk"><input type="checkbox" name="latest_version_only" value="1" <?= !empty($config['version_policy']['latest_version_only'])?'checked':'' ?>> فقط آخرین نسخه مجاز باشد</label>
      </div>
      <label>پیام حالت تعطیلی اپ</label>
      <input name="maintenance_message" value="<?= bm_h($config['message'] ?? '') ?>">

      <h3>کنترل قابلیت‌های اپ بدون انتشار APK</h3>
      <div class="checks">
        <?php foreach ([
          'registration_enabled'=>'ثبت‌نام','login_enabled'=>'ورود','comments_enabled'=>'کامنت','comment_replies_enabled'=>'پاسخ کامنت',
          'comment_votes_enabled'=>'لایک/دیس‌لایک','comment_reports_enabled'=>'گزارش تخلف کامنت','comment_spoiler_enabled'=>'اسپویلر کامنت',
          'notification_center_enabled'=>'مرکز اعلان','internal_downloader_enabled'=>'دانلودر داخلی','multipart_download_enabled'=>'دانلود چندبخشی',
          'download_path_selection_enabled'=>'انتخاب مسیر دانلود','advanced_search_enabled'=>'جست‌وجوی پیشرفته','categories_enabled'=>'دسته‌بندی',
          'watchlist_enabled'=>'علاقه‌مندی‌ها','continue_watching_enabled'=>'ادامه تماشا','tv_quick_menu_enabled'=>'منوی سریع TV'
        ] as $key=>$label): ?>
          <label class="chk"><input type="checkbox" name="<?= bm_h($key) ?>" value="1" <?= !array_key_exists($key,(array)($config['features']??[])) || !empty($config['features'][$key])?'checked':'' ?>> <?= bm_h($label) ?> فعال</label>
        <?php endforeach; ?>
      </div>
      <h3>کنترل مستقل آرشیوها</h3>
      <div class="note">برای هر آرشیو دو کنترل مستقل داری: «فعال» اجازه انتخاب و دریافت محتوا می‌دهد؛ «محو از اپ» دکمه آرشیو را کاملاً از موبایل و TV حذف می‌کند. ترکیب هر دو حالت نیز پشتیبانی می‌شود.</div>
      <div class="row3">
        <?php foreach ([1=>'آرشیو ۱',2=>'آرشیو ۲',3=>'آرشیو ۳'] as $archiveNo=>$archiveTitle): $ak='archive'.$archiveNo; ?>
          <div style="border:1px solid rgba(148,163,184,.22);border-radius:16px;padding:14px">
            <b><?= bm_h($archiveTitle) ?></b>
            <label class="chk" style="margin-top:10px"><input type="checkbox" name="<?= bm_h($ak) ?>_enabled" value="1" <?= !array_key_exists($ak.'_enabled',(array)($config['features']['archives']??[])) || !empty($config['features']['archives'][$ak.'_enabled'])?'checked':'' ?>> فعال و قابل انتخاب</label>
            <label class="chk"><input type="checkbox" name="<?= bm_h($ak) ?>_hidden" value="1" <?= !empty($config['features']['archives'][$ak.'_hidden'])?'checked':'' ?>> محو کامل از اپ</label>
          </div>
        <?php endforeach; ?>
      </div>
      <div class="row">
        <div><label>لینک پوستر صفحه ورود</label><input name="login_poster_url" dir="ltr" placeholder="https://.../poster.webp" value="<?= bm_h($config['features']['login_poster_url'] ?? '') ?>"></div>
        <div><label>حد دانلود هم‌زمان</label><input type="number" min="1" max="4" name="download_limit" value="<?= bm_h($config['downloads']['concurrent_limit'] ?? $config['features']['download_limit'] ?? 2) ?>"></div>
      </div>
      <div class="row3">
        <div><label>تلاش مجدد دانلود</label><input type="number" min="0" max="12" name="download_retry_count" value="<?= bm_h($config['downloads']['retry_count'] ?? 4) ?>"></div>
        <div><label>فاصله تلاش مجدد (ثانیه)</label><input type="number" min="2" max="300" name="download_retry_delay_seconds" value="<?= bm_h($config['downloads']['retry_delay_seconds'] ?? 8) ?>"></div>
        <div><label>حداقل فضای آزاد (MB)</label><input type="number" min="32" max="8192" name="download_min_free_mb" value="<?= bm_h($config['downloads']['min_free_mb'] ?? 256) ?>"></div>
      </div>
      <div class="row3">
        <div><label>تعداد بخش دانلود چندبخشی</label><input type="number" min="2" max="6" name="multipart_parts" value="<?= bm_h($config['downloads']['multipart_parts'] ?? 4) ?>"></div>
        <div><label>حداکثر کامنت در بازه</label><input type="number" min="1" max="30" name="comment_rate_count" value="<?= bm_h($config['comments']['rate_count'] ?? 3) ?>"></div>
        <div><label>بازه ضداسپم (دقیقه)</label><input type="number" min="1" max="1440" name="comment_rate_minutes" value="<?= bm_h($config['comments']['rate_minutes'] ?? 10) ?>"></div>
      </div>
      <div class="row">
        <div><label>مدت مجاز ویرایش کامنت (دقیقه)</label><input type="number" min="0" max="1440" name="comment_edit_minutes" value="<?= bm_h($config['comments']['edit_minutes'] ?? 10) ?>"></div>
        <div></div>
      </div>

      <div class="checks">
        <label class="chk"><input type="checkbox" name="comment_auto_approve_admin" value="1" <?= !array_key_exists('auto_approve_admin',(array)($config['comments']??[])) || !empty($config['comments']['auto_approve_admin'])?'checked':'' ?>> تأیید مستقیم مدیر</label>
        <label class="chk"><input type="checkbox" name="comment_auto_approve_vip" value="1" <?= !array_key_exists('auto_approve_vip',(array)($config['comments']??[])) || !empty($config['comments']['auto_approve_vip'])?'checked':'' ?>> تأیید مستقیم عضو ویژه</label>
      </div>
      <h3>ترتیب بخش‌های صفحه اصلی</h3>
      <div class="note">هر خط یک کلید بخش است. حذف یک کلید، آن بخش را بدون انتشار APK مخفی می‌کند.</div>
      <div class="row3">
        <div><label>آرشیو ۱</label><textarea name="home_archive1_sections" dir="ltr"><?= bm_h($homeArchive1Text) ?></textarea></div>
        <div><label>آرشیو ۲</label><textarea name="home_archive2_sections" dir="ltr"><?= bm_h($homeArchive2Text) ?></textarea></div>
        <div><label>آرشیو ۳</label><textarea name="home_archive3_sections" dir="ltr"><?= bm_h($homeArchive3Text) ?></textarea></div>
      </div>

      <h3>مرکز اعلان و پیام مدیریت</h3>
      <div class="row3">
        <div><label>نوع اعلان</label><select name="notice_type"><option value="admin" <?= (($config['notice']['type']??'admin')==='admin')?'selected':'' ?>>پیام مدیریت</option><option value="system" <?= (($config['notice']['type']??'')==='system')?'selected':'' ?>>سیستمی</option><option value="update" <?= (($config['notice']['type']??'')==='update')?'selected':'' ?>>آپدیت</option><option value="maintenance" <?= (($config['notice']['type']??'')==='maintenance')?'selected':'' ?>>تعمیرات</option></select></div>
        <div><label>شناسه اعلان</label><input name="notice_id" dir="ltr" value="<?= bm_h($config['notice']['id'] ?? '') ?>"></div>
        <div><label>عنوان اعلان</label><input name="notice_title" value="<?= bm_h($config['notice']['title'] ?? '') ?>"></div>
      </div>
      <label>متن اعلان</label><textarea name="notice_message"><?= bm_h($config['notice']['message'] ?? '') ?></textarea>
      <label>لینک مقصد اختیاری اعلان</label><input name="notice_target_url" dir="ltr" value="<?= bm_h($config['notice']['target']['url'] ?? '') ?>">

      <h3>سرورها و Failover خودکار</h3>
      <div class="note">سرورها بر اساس اولویت امتحان می‌شوند. اگر دامنه اول فیلتر، قطع یا دارای خطای موقت باشد، اپ خودکار سرور بعدی را امتحان می‌کند. اولین سرور فعال برای نسخه‌های قدیمی هم به‌عنوان دامنه اصلی منتشر می‌شود.</div>
      <div id="serverRows" class="server-list">
        <?php foreach ($servers as $i => $server): ?>
          <div class="server-row">
            <div class="server-grid">
              <div><label>نام سرور</label><input name="server_name[<?= (int)$i ?>]" value="<?= bm_h($server['name'] ?? '') ?>"></div>
              <div><label>دامنه محتوا</label><input name="server_domain[<?= (int)$i ?>]" dir="ltr" value="<?= bm_h($server['domain'] ?? '') ?>"></div>
              <div><label>آدرس API</label><input name="server_api[<?= (int)$i ?>]" dir="ltr" value="<?= bm_h($server['api_url'] ?? '') ?>"></div>
              <div><label>اولویت</label><input type="number" min="1" name="server_priority[<?= (int)$i ?>]" value="<?= bm_h($server['priority'] ?? ($i + 1)) ?>"></div>
            </div>
            <div class="mini-actions">
              <label class="chk"><input type="checkbox" name="server_enabled[<?= (int)$i ?>]" value="1" <?= !empty($server['enabled'])?'checked':'' ?>> فعال</label>
              <button type="button" class="remove-row" onclick="this.closest('.server-row').remove()">حذف ردیف</button>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
      <button type="button" class="add-row" onclick="addServerRow()">+ افزودن سرور جایگزین</button>

      <h3>حذف یا جایگزینی دامنه‌های قدیمی داخل API</h3>
      <div class="note">در ستون مبدأ می‌توانی دامنه کامل یا فقط عبارت <b>OLDTOWNS</b> را بنویسی. حالت «استفاده از سرور فعال» دامنه قدیمی را حذف می‌کند و مسیر فایل را روی سرور فعال می‌گذارد. حالت «جایگزینی» آن را با دامنه مقصد عوض می‌کند.</div>
      <div id="rewriteRows" class="rewrite-list">
        <?php foreach ($rewrites as $i => $rule): ?>
          <div class="rewrite-row">
            <div class="rewrite-grid">
              <div><label>دامنه/عبارت قدیمی</label><input name="rewrite_from[<?= (int)$i ?>]" dir="ltr" placeholder="OLDTOWNS یا old.example.com" value="<?= bm_h($rule['from'] ?? '') ?>"></div>
              <div><label>دامنه مقصد</label><input name="rewrite_to[<?= (int)$i ?>]" dir="ltr" placeholder="https://new.example.com" value="<?= bm_h(($rule['mode'] ?? '') === 'active' ? '' : ($rule['to'] ?? '')) ?>"></div>
              <div><label>نوع عملیات</label><select name="rewrite_mode[<?= (int)$i ?>]"><option value="active" <?= (($rule['mode'] ?? '')==='active')?'selected':'' ?>>استفاده از سرور فعال</option><option value="replace" <?= (($rule['mode'] ?? '')!=='active')?'selected':'' ?>>جایگزینی دامنه</option></select></div>
            </div>
            <div class="mini-actions">
              <label class="chk"><input type="checkbox" name="rewrite_enabled[<?= (int)$i ?>]" value="1" <?= !array_key_exists('enabled',$rule) || !empty($rule['enabled'])?'checked':'' ?>> فعال</label>
              <button type="button" class="remove-row" onclick="this.closest('.rewrite-row').remove()">حذف ردیف</button>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
      <button type="button" class="add-row" onclick="addRewriteRow()">+ افزودن قانون دامنه</button>

      <h3>انتشار و آپدیت</h3>
      <div class="row">
        <div><label>Version Name</label><input name="version_name" dir="ltr" value="<?= bm_h($config['update']['version_name'] ?? '1.4') ?>"></div>
        <div><label>Version Code</label><input type="number" name="version_code" dir="ltr" value="<?= bm_h($config['update']['version_code'] ?? 0) ?>"></div>
      </div>
      <div class="row3">
        <div><label>APK Universal</label><input name="apk_universal" dir="ltr" value="<?= bm_h($config['update']['apk_urls']['universal'] ?? $config['update']['apk_url'] ?? '') ?>"></div>
        <div><label>APK ARM64</label><input name="apk_arm64" dir="ltr" value="<?= bm_h($config['update']['apk_urls']['arm64_v8a'] ?? '') ?>"></div>
        <div><label>APK V7A</label><input name="apk_v7a" dir="ltr" value="<?= bm_h($config['update']['apk_urls']['armeabi_v7a'] ?? '') ?>"></div>
      </div>
      <div class="row">
        <div><label>عنوان آپدیت</label><input name="update_title" value="<?= bm_h($config['update']['title'] ?? '') ?>"></div>
        <div><label>پیام آپدیت</label><input name="update_message" value="<?= bm_h($config['update']['message'] ?? '') ?>"></div>
      </div>
      <label>تغییرات نسخه — هر خط یک مورد</label>
      <textarea name="changes"><?= bm_h($changesText) ?></textarea>

      <h3>مدیریت و غیرفعال‌سازی نسخه‌ها</h3>
      <div class="note">برای غیرفعال‌کردن نسخه 1.3 فقط عدد <b>1.3</b> را در فهرست نسخه‌های مسدود بنویس. اپ آن نسخه قبل از دریافت صفحه اصلی متوقف می‌شود و به APK مناسب دستگاه هدایت می‌شود.</div>
      <div class="row">
        <div><label>حداقل Version Name مجاز</label><input name="minimum_version_name" dir="ltr" placeholder="مثلاً 1.4" value="<?= bm_h($config['version_policy']['minimum_version_name'] ?? '') ?>"></div>
        <div><label>حداقل Version Code مجاز</label><input type="number" name="minimum_version_code" dir="ltr" value="<?= bm_h($config['version_policy']['minimum_version_code'] ?? 0) ?>"></div>
      </div>
      <div class="row">
        <div><label>Version Nameهای مسدود — هر خط یکی</label><textarea name="blocked_version_names" dir="ltr" placeholder="1.3\n1.3.1"><?= bm_h($blockedNamesText) ?></textarea></div>
        <div><label>Version Codeهای مسدود — هر خط یکی</label><textarea name="blocked_version_codes" dir="ltr" placeholder="980001\n980002"><?= bm_h($blockedCodesText) ?></textarea></div>
      </div>
      <label>پیام نسخه غیرفعال</label>
      <textarea name="block_message"><?= bm_h($config['version_policy']['block_message'] ?? '') ?></textarea>


      <button class="btn" type="submit">ذخیره همه تنظیمات</button>
    </form>

    <div>
      <div class="card">
        <h2>عملیات سریع نسخه 1.3</h2>
        <p class="desc">پیش از مسدودکردن، حداقل لینک Universal یا لینک‌های ARM را ثبت کن.</p>
        <div class="quick">
          <?php if (!$blocked13): ?>
          <form method="post"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="block_13"><button class="btn red" type="submit">غیرفعال‌کردن 1.3</button></form>
          <?php else: ?>
          <form method="post"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="unblock_13"><button class="btn green" type="submit">فعال‌کردن دوباره 1.3</button></form>
          <?php endif; ?>
        </div>
      </div>

      <div class="card">
        <h2>خروجی عمومی تنظیمات</h2>
        <p class="desc">اپ فایل زیر را می‌خواند. اطلاعات محرمانه‌ای داخل آن قرار نده.</p>
        <a class="btn" href="app_config.php" target="_blank" rel="noopener">مشاهده app_config.php</a>
      </div>

      <div class="card">
        <h2>دیدگاه‌های در انتظار اپ و سایت</h2>
        <p class="desc">دیدگاه‌های دیتابیس اصلی و همه آرشیوهای خارجی از همین‌جا تأیید می‌شوند.</p>
        <?php if (!$bmPendingComments): ?>
          <div class="audit-item">دیدگاه در انتظاری وجود ندارد.</div>
        <?php endif; ?>
        <?php foreach ($bmPendingComments as $comment): ?>
          <div class="audit-item" style="margin-bottom:10px;line-height:1.9">
            <b><?= bm_h($comment['user_name'] ?? 'کاربر') ?></b>
            <small style="display:block;color:#9ca3af"><?= bm_h($comment['movie_title'] ?? '') ?> · <?= bm_h($comment['created_at'] ?? '') ?></small>
            <div style="margin:8px 0"><?= bm_h($comment['comment'] ?? '') ?></div>
            <div class="quick" style="gap:6px;flex-wrap:wrap">
              <form method="post"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="comment_approve"><input type="hidden" name="comment_id" value="<?= (int)$comment['id'] ?>"><input type="hidden" name="comment_source" value="<?= bm_h($comment['comment_source']) ?>"><button class="btn green" type="submit">تأیید</button></form>
              <form method="post"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="comment_reject"><input type="hidden" name="comment_id" value="<?= (int)$comment['id'] ?>"><input type="hidden" name="comment_source" value="<?= bm_h($comment['comment_source']) ?>"><button class="btn red" type="submit">رد</button></form>
              <form method="post" onsubmit="return confirm('دیدگاه حذف شود؟')"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="comment_delete"><input type="hidden" name="comment_id" value="<?= (int)$comment['id'] ?>"><input type="hidden" name="comment_source" value="<?= bm_h($comment['comment_source']) ?>"><button class="btn red" type="submit">حذف</button></form>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="card">
        <h2>دیدگاه‌های تأییدشده اخیر</h2>
        <p class="desc">پین، اسپویلر و حذف از همین بخش انجام می‌شود.</p>
        <?php if(!$bmRecentComments): ?><div class="audit-item">دیدگاهی وجود ندارد.</div><?php endif; ?>
        <?php foreach($bmRecentComments as $comment): ?>
          <div class="audit-item" style="margin-bottom:10px;line-height:1.9">
            <b><?= bm_h($comment['user_name']??'کاربر') ?></b>
            <small style="display:block;color:#9ca3af"><?= bm_h($comment['movie_title']??'') ?> · <?= bm_h($comment['created_at']??'') ?></small>
            <div style="margin:8px 0"><?= bm_h($comment['comment']??'') ?></div>
            <div class="quick" style="gap:6px">
              <form method="post"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="<?= !empty($comment['is_pinned'])?'comment_unpin':'comment_pin' ?>"><input type="hidden" name="comment_id" value="<?= (int)$comment['id'] ?>"><input type="hidden" name="comment_source" value="<?= bm_h($comment['comment_source']) ?>"><button class="btn" type="submit"><?= !empty($comment['is_pinned'])?'برداشتن پین':'پین' ?></button></form>
              <form method="post"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="<?= !empty($comment['spoiler'])?'comment_unspoiler':'comment_spoiler' ?>"><input type="hidden" name="comment_id" value="<?= (int)$comment['id'] ?>"><input type="hidden" name="comment_source" value="<?= bm_h($comment['comment_source']) ?>"><button class="btn" type="submit"><?= !empty($comment['spoiler'])?'حذف اسپویلر':'علامت اسپویلر' ?></button></form>
              <form method="post" onsubmit="return confirm('دیدگاه حذف شود؟')"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="comment_delete"><input type="hidden" name="comment_id" value="<?= (int)$comment['id'] ?>"><input type="hidden" name="comment_source" value="<?= bm_h($comment['comment_source']) ?>"><button class="btn red" type="submit">حذف</button></form>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="card">
        <h2>گزارش‌های تخلف کامنت</h2>
        <p class="desc">این بخش فقط گزارش محتوای کامنت است؛ گزارش خرابی لینک عمداً در این نسخه اضافه نشده.</p>
        <?php if(!$bmOpenCommentReports): ?><div class="audit-item">گزارش بازی وجود ندارد.</div><?php endif; ?>
        <?php foreach($bmOpenCommentReports as $report): ?>
          <div class="audit-item" style="margin-bottom:10px;line-height:1.9">
            <b><?= bm_h($report['reporter_name']??'کاربر') ?> — <?= bm_h($report['reason']??'other') ?></b>
            <small style="display:block;color:#9ca3af">دیدگاه #<?= (int)$report['comment_id'] ?> · آرشیو <?= (int)$report['archive_no'] ?> · <?= bm_h($report['created_at']??'') ?></small>
            <?php if(!empty($report['details'])): ?><div style="margin:8px 0"><?= bm_h($report['details']) ?></div><?php endif; ?>
            <div class="quick">
              <form method="post"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="comment_report_resolve"><input type="hidden" name="report_id" value="<?= (int)$report['id'] ?>"><button class="btn green" type="submit">رسیدگی شد</button></form>
              <form method="post"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="comment_report_reject"><input type="hidden" name="report_id" value="<?= (int)$report['id'] ?>"><button class="btn red" type="submit">رد گزارش</button></form>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="card">
        <h2>آخرین فعالیت‌های مدیریت</h2>
        <div class="audit">
          <?php if (!$audits): ?><div class="audit-item">هنوز گزارشی ثبت نشده است.</div><?php endif; ?>
          <?php foreach ($audits as $row): ?>
            <div class="audit-item"><b><?= bm_h($row['action'] ?? '') ?></b><br><?= bm_h($row['admin'] ?? '') ?> — <?= bm_h($row['time'] ?? '') ?></div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
let nextServerIndex = <?= count($servers) ?>;
let nextRewriteIndex = <?= count($rewrites) ?>;

function addServerRow() {
  const i = nextServerIndex++;
  const wrap = document.createElement('div');
  wrap.className = 'server-row';
  wrap.innerHTML = `
    <div class="server-grid">
      <div><label>نام سرور</label><input name="server_name[${i}]" value="سرور ${i + 1}"></div>
      <div><label>دامنه محتوا</label><input name="server_domain[${i}]" dir="ltr" placeholder="https://server.example.com"></div>
      <div><label>آدرس API</label><input name="server_api[${i}]" dir="ltr" placeholder="https://server.example.com/app_api.php"></div>
      <div><label>اولویت</label><input type="number" min="1" name="server_priority[${i}]" value="${i + 1}"></div>
    </div>
    <div class="mini-actions">
      <label class="chk"><input type="checkbox" name="server_enabled[${i}]" value="1" checked> فعال</label>
      <button type="button" class="remove-row" onclick="this.closest('.server-row').remove()">حذف ردیف</button>
    </div>`;
  document.getElementById('serverRows').appendChild(wrap);
}

function addRewriteRow() {
  const i = nextRewriteIndex++;
  const wrap = document.createElement('div');
  wrap.className = 'rewrite-row';
  wrap.innerHTML = `
    <div class="rewrite-grid">
      <div><label>دامنه/عبارت قدیمی</label><input name="rewrite_from[${i}]" dir="ltr" placeholder="OLDTOWNS"></div>
      <div><label>دامنه مقصد</label><input name="rewrite_to[${i}]" dir="ltr" placeholder="https://new.example.com"></div>
      <div><label>نوع عملیات</label><select name="rewrite_mode[${i}]"><option value="active">استفاده از سرور فعال</option><option value="replace">جایگزینی دامنه</option></select></div>
    </div>
    <div class="mini-actions">
      <label class="chk"><input type="checkbox" name="rewrite_enabled[${i}]" value="1" checked> فعال</label>
      <button type="button" class="remove-row" onclick="this.closest('.rewrite-row').remove()">حذف ردیف</button>
    </div>`;
  document.getElementById('rewriteRows').appendChild(wrap);
}
</script>
</body>
</html>
