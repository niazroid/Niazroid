#!/usr/bin/env bash
set -euo pipefail

gradle='app/build.gradle'
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
source='BANKMOVIE_BUILD_SOURCE_2_3.txt'

need() { grep -Fq -- "$1" "$2" || { echo "Missing V7.21.1 marker: $1 in $2" >&2; exit 1; }; }

# MediaRouteChooserDialog is an AppCompatDialog subclass, so appcompat must be on the app classpath.
need "implementation 'androidx.appcompat:appcompat:1.7.1'" "$gradle"
need "implementation 'androidx.mediarouter:mediarouter:1.8.1'" "$gradle"
need 'import androidx.mediarouter.app.MediaRouteChooserDialog' "$player"
need 'MediaRouteChooserDialog(this).apply {' "$player"
need 'routeSelector = castRouteSelector' "$player"
need 'setTitle("Cast to")' "$player"
need 'show()' "$player"
need 'sourceMainUpdateThirdHotfixTag=BANKMOVIE-2.3-V7211-20260910' "$source"

# Regression: local LibVLC startup must remain independent from the Cast chooser.
need 'class PlayerActivity : Activity()' "$player"
need 'handler.postDelayed({ runCatching { initCastRenderer() } }, 450L)' "$player"

# Catch the exact classpath regression from the failed V7.21 build.
if ! grep -Fq "androidx.appcompat:appcompat:" "$gradle"; then
  echo 'MediaRouteChooserDialog requires androidx.appcompat on the app classpath.' >&2
  exit 1
fi

echo V7211_CAST_CHOOSER_APPCOMPAT_HOTFIX_OK
