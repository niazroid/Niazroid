package ir.bankmoviee.app

import android.content.Context
import android.graphics.Color
import kotlin.math.roundToInt

object UiPreferences {
    const val PREFS = "bm_smart_cinema"

    const val KEY_THEME = "ui_theme_mode"
    const val KEY_APP_FONT = "ui_app_font_mode"
    const val KEY_ACCENT = "ui_accent"
    const val KEY_SEEK_SECONDS = "player_seek_seconds"
    const val KEY_SUB_ENABLED = "subtitle_enabled"
    const val KEY_SUB_TEXT_COLOR = "subtitle_text_color"
    const val KEY_SUB_BG_MODE = "subtitle_background_mode"
    const val KEY_SUB_SCALE = "subtitle_scale"
    const val KEY_SUB_DELAY = "subtitle_delay_ms"
    const val KEY_SUB_FONT = "subtitle_font_mode"
    const val KEY_AUTO_NEXT = "player_auto_next"

    data class Palette(
        val background: Int,
        val background2: Int,
        val panel: Int,
        val panel2: Int,
        val card: Int,
        val stroke: Int,
        val primary: Int,
        val primary2: Int,
        val onPrimary: Int,
        val text: Int,
        val muted: Int,
        val faint: Int,
        val light: Boolean
    )

    fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun themeMode(context: Context): String = prefs(context).getString(KEY_THEME, "black") ?: "black"
    fun appFontMode(context: Context): String = prefs(context).getString(KEY_APP_FONT, "system") ?: "system"
    fun accentName(context: Context): String = prefs(context).getString(KEY_ACCENT, "blue") ?: "blue"

    fun accentColor(name: String): Int = when (name) {
        "gold" -> Color.rgb(245, 184, 46)
        "orange" -> Color.rgb(255, 122, 0)
        "red" -> Color.rgb(229, 57, 53)
        "purple" -> Color.rgb(139, 92, 246)
        "teal" -> Color.rgb(0, 166, 166)
        "green" -> Color.rgb(25, 166, 84)
        else -> Color.rgb(25, 118, 255)
    }

    fun accentColor(context: Context): Int = accentColor(accentName(context))

    fun palette(context: Context): Palette {
        val mode = themeMode(context)
        val primary = accentColor(context)
        val primary2 = blend(primary, Color.WHITE, if (mode == "light") 0.10f else 0.24f)
        val onPrimary = if (luminance(primary) > 0.62f) Color.rgb(12, 12, 12) else Color.WHITE

        return when (mode) {
            "light" -> Palette(
                background = Color.rgb(242, 244, 248),
                background2 = Color.rgb(255, 255, 255),
                panel = Color.rgb(255, 255, 255),
                panel2 = Color.rgb(236, 240, 246),
                card = Color.rgb(255, 255, 255),
                stroke = Color.rgb(211, 217, 228),
                primary = primary,
                primary2 = primary2,
                onPrimary = onPrimary,
                text = Color.rgb(18, 21, 27),
                muted = Color.rgb(88, 96, 111),
                faint = Color.rgb(128, 137, 153),
                light = true
            )
            "dark" -> Palette(
                background = Color.rgb(2, 7, 16),
                background2 = Color.rgb(6, 13, 25),
                panel = Color.rgb(10, 20, 36),
                panel2 = Color.rgb(15, 30, 50),
                card = Color.rgb(12, 24, 42),
                stroke = Color.rgb(42, 67, 101),
                primary = primary,
                primary2 = primary2,
                onPrimary = onPrimary,
                text = Color.WHITE,
                muted = Color.rgb(180, 191, 209),
                faint = Color.rgb(111, 130, 158),
                light = false
            )
            else -> Palette(
                background = Color.BLACK,
                background2 = Color.rgb(4, 4, 5),
                panel = Color.rgb(13, 13, 15),
                panel2 = Color.rgb(24, 24, 27),
                card = Color.rgb(18, 18, 20),
                stroke = Color.rgb(53, 53, 58),
                primary = primary,
                primary2 = primary2,
                onPrimary = onPrimary,
                text = Color.WHITE,
                muted = Color.rgb(190, 190, 196),
                faint = Color.rgb(124, 124, 132),
                light = false
            )
        }
    }

    fun seekSeconds(context: Context): Int = prefs(context).getInt(KEY_SEEK_SECONDS, 10).coerceIn(5, 60)
    fun autoNext(context: Context): Boolean = prefs(context).getBoolean(KEY_AUTO_NEXT, true)
    fun subtitleEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_SUB_ENABLED, true)
    fun subtitleTextColor(context: Context): Int = prefs(context).getInt(KEY_SUB_TEXT_COLOR, Color.YELLOW)
    fun subtitleBackgroundMode(context: Context): String = prefs(context).getString(KEY_SUB_BG_MODE, "black") ?: "black"
    fun subtitleScale(context: Context): Int = prefs(context).getInt(KEY_SUB_SCALE, 112).coerceIn(80, 170)
    fun subtitleDelayMs(context: Context): Int = prefs(context).getInt(KEY_SUB_DELAY, 0).coerceIn(-10000, 10000)
    fun subtitleFontMode(context: Context): String = prefs(context).getString(KEY_SUB_FONT, "system") ?: "system"

    fun subtitleBackgroundColor(context: Context): Int = when (subtitleBackgroundMode(context)) {
        "white" -> Color.WHITE
        "yellow" -> Color.YELLOW
        "red" -> Color.RED
        "blue" -> Color.BLUE
        "pink" -> Color.rgb(236, 64, 122)
        "transparent" -> Color.BLACK
        else -> Color.BLACK
    }

    fun subtitleBackgroundOpacity(context: Context): Int = when (subtitleBackgroundMode(context)) {
        "transparent" -> 0
        "white" -> 225
        else -> 215
    }


    fun reset(context: Context) {
        prefs(context).edit()
            .remove(KEY_THEME)
            .remove(KEY_APP_FONT)
            .remove(KEY_ACCENT)
            .remove(KEY_SEEK_SECONDS)
            .remove(KEY_SUB_ENABLED)
            .remove(KEY_SUB_TEXT_COLOR)
            .remove(KEY_SUB_BG_MODE)
            .remove(KEY_SUB_SCALE)
            .remove(KEY_SUB_DELAY)
            .remove(KEY_SUB_FONT)
            .remove(KEY_AUTO_NEXT)
            .apply()
    }

    fun blend(a: Int, b: Int, fraction: Float): Int {
        val f = fraction.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * f).roundToInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * f).roundToInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).roundToInt()
        )
    }

    private fun luminance(color: Int): Float {
        fun channel(v: Int): Float {
            val c = v / 255f
            return if (c <= 0.03928f) c / 12.92f else Math.pow(((c + 0.055f) / 1.055f).toDouble(), 2.4).toFloat()
        }
        return 0.2126f * channel(Color.red(color)) + 0.7152f * channel(Color.green(color)) + 0.0722f * channel(Color.blue(color))
    }
}
