<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/includes/archive_control.php';
require_once __DIR__ . '/includes/vip_sales.php';

@ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
bm_security_cors(['GET','OPTIONS'], ['Content-Type'], true);
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
bm_security_enforce_rate_limit('app_config_public', 300, 300, bm_security_client_ip(), true);

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$configFile = __DIR__ . '/bankmovie_remote_config.json';
$default = [
    'schema_version' => 6,
    'ready' => true,
    'message' => 'اپ موقتاً در دسترس نیست.',
    'active_domain' => 'https://bankmovie.top',
    'api_url' => 'https://bankmovie.top/app_api.php',
    'account_api_url' => 'https://bankmovie.top/app_user_api.php',
    'account_api_urls' => ['https://bankmovie.top/app_user_api.php'],
    'servers' => [
        [
            'name' => 'سرور محتوای اصلی bankmovie.top',
            'enabled' => true,
            'priority' => 1,
            'domain' => 'https://bankmovie.top',
            'api_url' => 'https://bankmovie.top/app_api.php'
        ]
    ],
    'url_rewrites' => [],
    'features' => [
        'registration_enabled'=>true,'login_enabled'=>true,'comments_enabled'=>true,
        'comment_replies_enabled'=>true,'comment_votes_enabled'=>true,'comment_reports_enabled'=>true,'comment_spoiler_enabled'=>true,
        'notification_center_enabled'=>true,'internal_downloader_enabled'=>true,'multipart_download_enabled'=>true,
        'download_path_selection_enabled'=>true,'advanced_search_enabled'=>true,'categories_enabled'=>true,
        'watchlist_enabled'=>true,'continue_watching_enabled'=>true,'tv_quick_menu_enabled'=>true,
        'profile_cleanup_enabled'=>true,'tv_detail_story_enabled'=>true,'tv_detail_more_info_enabled'=>true,
        'external_player_fallback_enabled'=>true,
        'watch_party_scope'=>'vip','internal_player_scope'=>'public','external_player_scope'=>'public','all_players_scope'=>'public',
        'search_auto_page_limit'=>10,
        'login_poster_url'=>'','download_limit'=>2,
        'archives'=>[
            'archive1_enabled'=>true,'archive1_hidden'=>false,
            'archive2_enabled'=>true,'archive2_hidden'=>false,
            'archive3_enabled'=>true,'archive3_hidden'=>false,
            'archive4_enabled'=>true,'archive4_hidden'=>false,
            'archive1_download_vip'=>false,'archive1_stream_vip'=>false,
            'archive2_download_vip'=>false,'archive2_stream_vip'=>false,
            'archive3_download_vip'=>false,'archive3_stream_vip'=>false,
            'archive4_download_vip'=>false,'archive4_stream_vip'=>false
        ]
    ],
    'comments' => ['edit_minutes'=>10,'rate_count'=>3,'rate_minutes'=>10,'auto_approve_admin'=>true,'auto_approve_vip'=>true],
    'downloads' => ['concurrent_limit'=>2,'retry_count'=>4,'retry_delay_seconds'=>8,'min_free_mb'=>256,'multipart_parts'=>4],
    'home' => [
        'archive1_sections'=>['updated_movies','updated_series','korean_series','dubbed','chinese_series','top_2026','anime','turkish','collections'],
        'archive2_sections'=>['updated_movies','updated_series','dubbed','animation','action','drama','collections'],
        'archive3_sections'=>['new_movies','new_series','updated_animations','updated_anime','dubbed_movies','subtitled_movies','dubbed_series','subtitled_series','mini_series','korean_series','turkish_series','collections'],
        'archive4_sections'=>['new_movies','new_series','updated_animations','updated_anime','dubbed_movies','subtitled_movies','collections']
    ],
    'home_section_policy' => [],
    'ui' => [
        'display_year'=>0,
        'search_max_year'=>0,
        'text_overrides'=>['fa'=>[], 'en'=>[]]
    ],
    'notice'  => ['enabled'=>false,'id'=>'','type'=>'admin','title'=>'','message'=>'','dismissible'=>true,'target'=>['url'=>'']],
    'update' => [
        'enabled' => false,
        'version_code' => 5300001,
        'version_name' => '2.2',
        'apk_url' => '',
        'apk_urls' => ['universal'=>'','arm64_v8a'=>'','armeabi_v7a'=>''],
        'force' => false,
        'title' => 'آپدیت جدید آماده است',
        'message' => 'نسخه جدید Bankmovie آماده دانلود است.',
        'changes' => []
    ],
    'version_policy' => [
        'enabled' => false,
        'minimum_version_code' => 0,
        'minimum_version_name' => '',
        'blocked_version_names' => [],
        'blocked_version_codes' => [],
        'force_update_blocked' => false,
        'latest_version_only' => false,
        'block_message' => 'این نسخه از Bankmovie غیرفعال شده است. برای ادامه نسخه جدید را نصب کنید.'
    ],
    'updated_at' => gmdate('c')
];

if (is_file($configFile)) {
    $raw = file_get_contents($configFile);
    $saved = is_string($raw) ? json_decode($raw, true) : null;
    if (is_array($saved)) $default = array_replace_recursive($default, $saved);
}

// Schema v6 separates the controller from content infrastructure. This file
// is fetched from bankmoviee.ir, while every API/account/content address below
// is an admin-managed secondary server (bankmovie.top by default).
if ((int)($default['schema_version'] ?? 0) < 6) {
    $servers = array_values(array_filter((array)($default['servers'] ?? []), static function ($server): bool {
        if (!is_array($server)) return false;
        $host = strtolower((string)(parse_url((string)($server['domain'] ?? ''), PHP_URL_HOST) ?: ''));
        return !in_array($host, ['bankmoviee.ir','www.bankmoviee.ir'], true);
    }));
    if (!$servers) $servers = [[
        'name'=>'سرور محتوای اصلی bankmovie.top','enabled'=>true,'priority'=>1,
        'domain'=>'https://bankmovie.top','api_url'=>'https://bankmovie.top/app_api.php'
    ]];
    usort($servers, static fn($a, $b): int => ((int)($a['priority'] ?? 99)) <=> ((int)($b['priority'] ?? 99)));
    $primary = null;
    foreach ($servers as $server) {
        if (!empty($server['enabled'])) { $primary = $server; break; }
    }
    if (!$primary) { $servers[0]['enabled'] = true; $primary = $servers[0]; }
    $domain = rtrim((string)($primary['domain'] ?? 'https://bankmovie.top'), '/');
    $apiUrl = (string)($primary['api_url'] ?? ($domain . '/app_api.php'));
    $default['schema_version'] = 6;
$default['downloads']['redirect_enabled'] = function_exists('bm_archive_download_redirect_enabled') ? bm_archive_download_redirect_enabled() : true;
    $default['servers'] = $servers;
    $default['active_domain'] = $domain;
    $default['api_url'] = $apiUrl;
    $default['account_api_url'] = $domain . '/app_user_api.php';
    $default['account_api_urls'] = array_values(array_unique(array_map(
        static fn($server): string => rtrim((string)($server['domain'] ?? ''), '/') . '/app_user_api.php',
        array_filter($servers, static fn($server): bool => !empty($server['enabled']))
    )));
}

// Enforce the controller/content boundary even if the JSON file was edited by
// hand. The app must never receive bankmoviee.ir as a media/API server.
$contentServers = array_values(array_filter((array)($default['servers'] ?? []), static function ($server): bool {
    if (!is_array($server)) return false;
    $host = strtolower((string)(parse_url((string)($server['domain'] ?? ''), PHP_URL_HOST) ?: ''));
    return !in_array($host, ['bankmoviee.ir','www.bankmoviee.ir'], true);
}));
if (!$contentServers) $contentServers = [[
    'name'=>'سرور محتوای اصلی bankmovie.top','enabled'=>true,'priority'=>1,
    'domain'=>'https://bankmovie.top','api_url'=>'https://bankmovie.top/app_api.php'
]];
usort($contentServers, static fn($a, $b): int => ((int)($a['priority'] ?? 99)) <=> ((int)($b['priority'] ?? 99)));
$primaryContentServer = null;
foreach ($contentServers as &$contentServer) {
    if ($primaryContentServer === null && !empty($contentServer['enabled'])) $primaryContentServer = $contentServer;
}
unset($contentServer);
if ($primaryContentServer === null) {
    $contentServers[0]['enabled'] = true;
    $primaryContentServer = $contentServers[0];
}
$contentDomain = rtrim((string)($primaryContentServer['domain'] ?? 'https://bankmovie.top'), '/');
$default['schema_version'] = 6;
$default['servers'] = $contentServers;
$default['active_domain'] = $contentDomain;
$default['api_url'] = (string)($primaryContentServer['api_url'] ?? ($contentDomain . '/app_api.php'));
$default['account_api_url'] = $contentDomain . '/app_user_api.php';
$default['account_api_urls'] = array_values(array_unique(array_map(
    static fn($server): string => rtrim((string)($server['domain'] ?? ''), '/') . '/app_user_api.php',
    array_filter($contentServers, static fn($server): bool => !empty($server['enabled']))
)));

// Keep website archive runtime metadata available, but publish Android access
// policy from BM Admin's app-only policy when it exists. This prevents website
// VIP/visibility changes from unexpectedly locking the Android client.
$siteArchivePublic = [];
if (function_exists('bm_archive_get_settings')) {
    $archiveSettings = bm_archive_get_settings();
    $archiveOrder = function_exists('bm_archive_order') ? bm_archive_order(true) : ['archive1','archive2','archive3','archive4'];
    foreach ($archiveOrder as $archiveId) {
        $row = is_array($archiveSettings['archives'][$archiveId] ?? null) ? $archiveSettings['archives'][$archiveId] : [];
        $enabled = function_exists('bm_archive_is_enabled') ? bm_archive_is_enabled($archiveId) : !empty($row['enabled']);
        $siteArchivePublic[(string)$archiveId] = [
            'label'=>(string)($row['label'] ?? ''),
            'enabled'=>$enabled,
            'access_scope'=>(string)($row['access_scope'] ?? 'public'),
            'download_access_scope'=>(string)($row['download_access_scope'] ?? 'public'),
            'stream_access_scope'=>(string)($row['stream_access_scope'] ?? 'public'),
            'download_link_mode'=>function_exists('bm_archive_download_link_mode') ? bm_archive_download_link_mode($archiveId) : (string)($row['download_link_mode'] ?? 'redirect'),
            'download_client_mode'=>function_exists('bm_archive_download_client_mode') ? bm_archive_download_client_mode($archiveId) : (string)($row['download_client_mode'] ?? 'adm_copy'),
            'player_gates'=>function_exists('bm_archive_player_gates_public') ? bm_archive_player_gates_public($archiveId) : (array)($row['player_gates'] ?? []),
            'disabled_mode'=>(string)($row['disabled_mode'] ?? 'visible'),
            'disabled_message'=>function_exists('bm_archive_disabled_message') ? bm_archive_disabled_message($archiveId) : (string)($row['disabled_message'] ?? ''),
            'display_order'=>(int)(array_search($archiveId, $archiveOrder, true) + 1),
            'is_default'=>function_exists('bm_archive_effective_default_id') && bm_archive_effective_default_id() === $archiveId,
        ];
    }
    $default['archive_runtime'] = [
        'order'=>$archiveOrder,
        'default_archive'=>function_exists('bm_archive_effective_default_id') ? bm_archive_effective_default_id() : (string)($archiveSettings['default_archive'] ?? 'archive1'),
        'configured_default_archive'=>(string)($archiveSettings['default_archive'] ?? 'archive1'),
        'fallback_archive'=>function_exists('bm_archive_fallback_id') ? bm_archive_fallback_id() : (string)($archiveSettings['fallback_archive'] ?? 'archive2'),
        'emergency'=>function_exists('bm_archive_emergency_settings') ? bm_archive_emergency_settings() : (array)($archiveSettings['emergency'] ?? []),
    ];
}

$appPolicy = is_array($default['app_archive_policy'] ?? null) ? $default['app_archive_policy'] : [];
if (!isset($default['features']['archives']) || !is_array($default['features']['archives'])) $default['features']['archives'] = [];
$featureArchives = $default['features']['archives'];
$archivePublic = [];
foreach ([1=>'archive1',2=>'archive2',3=>'archive3',4=>'archive4'] as $number => $archiveId) {
    $siteRow = is_array($siteArchivePublic[$archiveId] ?? null) ? $siteArchivePublic[$archiveId] : [];
    $row = is_array($appPolicy[$archiveId] ?? null) ? $appPolicy[$archiveId] : [];
    $enabled = array_key_exists('enabled', $row)
        ? !empty($row['enabled'])
        : (array_key_exists('archive'.$number.'_enabled', $featureArchives)
            ? !empty($featureArchives['archive'.$number.'_enabled'])
            : (!empty($siteRow) ? !empty($siteRow['enabled']) : true));
    $hidden = array_key_exists('hidden', $row)
        ? !empty($row['hidden'])
        : (array_key_exists('archive'.$number.'_hidden', $featureArchives)
            ? !empty($featureArchives['archive'.$number.'_hidden'])
            : (($siteRow['disabled_mode'] ?? 'visible') === 'hide'));
    if ($hidden) $enabled = false;

    $accessScope = strtolower(trim((string)($row['access_scope'] ?? ($siteRow['access_scope'] ?? 'public'))));
    $downloadScope = strtolower(trim((string)($row['download_access_scope'] ?? (!empty($featureArchives['archive'.$number.'_download_vip']) ? 'vip' : ($siteRow['download_access_scope'] ?? 'public')))));
    $streamScope = strtolower(trim((string)($row['stream_access_scope'] ?? (!empty($featureArchives['archive'.$number.'_stream_vip']) ? 'vip' : ($siteRow['stream_access_scope'] ?? 'public')))));
    $downloadLinkMode = strtolower(trim((string)($siteRow['download_link_mode'] ?? ($row['download_link_mode'] ?? 'redirect'))));
    if (!in_array($downloadLinkMode, ['redirect','original','disabled'], true)) $downloadLinkMode = 'redirect';
    $downloadClientMode = strtolower(trim((string)($siteRow['download_client_mode'] ?? ($row['download_client_mode'] ?? 'adm_copy'))));
    if (!in_array($downloadClientMode, ['adm_copy','all','disabled'], true)) $downloadClientMode = 'adm_copy';
    $watchPartyScope = strtolower(trim((string)($row['watch_party_access_scope'] ?? ($default['features']['watch_party_scope'] ?? 'vip'))));
    $internalPlayerScope = strtolower(trim((string)($row['internal_player_access_scope'] ?? ($default['features']['internal_player_scope'] ?? 'public'))));
    $externalPlayerScope = strtolower(trim((string)($row['external_player_access_scope'] ?? ($default['features']['external_player_scope'] ?? 'public'))));
    $allPlayersScope = strtolower(trim((string)($row['all_players_access_scope'] ?? ($default['features']['all_players_scope'] ?? 'public'))));

    if (!in_array($accessScope, ['public','member','vip','admin'], true)) $accessScope = 'public';
    if (!in_array($downloadScope, ['public','member','vip','admin','disabled'], true)) $downloadScope = 'public';
    if (!in_array($streamScope, ['public','member','vip','admin','disabled'], true)) $streamScope = 'public';
    if (!in_array($watchPartyScope, ['public','member','vip','admin','disabled'], true)) $watchPartyScope = 'vip';
    if (!in_array($internalPlayerScope, ['public','member','vip','admin','disabled'], true)) $internalPlayerScope = 'public';
    if (!in_array($externalPlayerScope, ['public','member','vip','admin','disabled'], true)) $externalPlayerScope = 'public';
    if (!in_array($allPlayersScope, ['public','member','vip','admin','disabled'], true)) $allPlayersScope = 'public';

    $archivePublic[$archiveId] = [
        'label'=>(string)($siteRow['label'] ?? ('آرشیو '.$number)),
        'enabled'=>$enabled,
        'hidden'=>$hidden,
        'access_scope'=>$accessScope,
        'download_access_scope'=>$downloadScope,
        'stream_access_scope'=>$streamScope,
        'download_link_mode'=>$downloadLinkMode,
        'download_client_mode'=>$downloadClientMode,
        'watch_party_access_scope'=>$watchPartyScope,
        'internal_player_access_scope'=>$internalPlayerScope,
        'external_player_access_scope'=>$externalPlayerScope,
        'all_players_access_scope'=>$allPlayersScope,
        'downloads_allowed'=>$enabled && $downloadScope === 'public' && $downloadLinkMode !== 'disabled' && $downloadClientMode !== 'disabled',
        'stream_allowed'=>$enabled && $streamScope === 'public',
        'disabled_mode'=>$hidden ? 'hide' : 'visible',
        'disabled_message'=>(string)($row['disabled_message'] ?? ($siteRow['disabled_message'] ?? 'این آرشیو در اپ موقتاً غیرفعال است.')),
    ];
    $default['features']['archives']['archive'.$number.'_enabled'] = $enabled;
    $default['features']['archives']['archive'.$number.'_hidden'] = $hidden;
    $default['features']['archives']['archive'.$number.'_download_vip'] = $downloadScope === 'vip';
    $default['features']['archives']['archive'.$number.'_stream_vip'] = $streamScope === 'vip';
}
$default['archive_policy'] = $archivePublic;

// Archive 4 is a first-class app source. Its Home rails are controlled by
// BM Admin app section policy, not by the website archive switches. This keeps
// Android controls independent and prevents a website-only toggle from
// unexpectedly hiding or resurrecting an app rail.
$default['archive4_site_api_url'] = $contentDomain . '/api4.php';
if (!isset($default['home']) || !is_array($default['home'])) $default['home'] = [];

// V7.36: home-section visibility is authoritative per section (legacy verifier marker; V7.43 expands it to Archives 1-4).
// Legacy Android verifier compatibility marker: config_revision
// V7.43 publishes one normalized section policy for all four archives. The
// Android client uses it for Home visibility/access and the APIs use the same
// keys to fail closed on direct section requests.
$sectionCatalog = [
    'archive1'=>['updated_movies','updated_series','korean_series','dubbed','chinese_series','top_2026','top_movies','top_series','anime','turkish','collections'],
    'archive2'=>['updated_movies','updated_series','dubbed','animation','action','drama','collections'],
    'archive3'=>['new_movies','new_series','updated_animations','updated_anime','dubbed_movies','subtitled_movies','dubbed_series','subtitled_series','mini_series','korean_series','turkish_series','collections'],
    'archive4'=>['new_movies','new_series','updated_animations','updated_anime','dubbed_movies','subtitled_movies','collections'],
];
$storedSectionPolicy = is_array($default['home_section_policy'] ?? null) ? $default['home_section_policy'] : [];
$publicSectionPolicy = [];
foreach ($sectionCatalog as $archiveId => $sectionKeys) {
    $archiveNumber = (int)preg_replace('/\D+/', '', $archiveId);
    $homeKey = 'archive' . $archiveNumber . '_sections';
    $ordered = is_array($default['home'][$homeKey] ?? null) ? $default['home'][$homeKey] : $sectionKeys;
    $orderedNormalized = array_values(array_unique(array_filter(array_map(static function ($v): string {
        return strtolower(str_replace('-', '_', trim((string)$v)));
    }, $ordered), static fn($v): bool => $v !== '')));
    $sourceRow = is_array($storedSectionPolicy[$archiveId] ?? null) ? $storedSectionPolicy[$archiveId] : [];
    $publicSectionPolicy[$archiveId] = [];
    foreach ($sectionKeys as $sectionKey) {
        $raw = $sourceRow[$sectionKey] ?? null;
        $enabled = in_array($sectionKey, $orderedNormalized, true);
        // V7.45.5 migration: Top 250 catalogue pages were never Home rails, so
        // legacy home.archive1_sections lists do not contain them. Default these
        // two catalogue policies to enabled only when no explicit stored policy
        // exists; any explicit BM Admin value still overrides below.
        if ($archiveId === 'archive1' && in_array($sectionKey, ['top_movies','top_series'], true) && $raw === null) $enabled = true;
        $scope = 'public';
        if (is_array($raw)) {
            if (array_key_exists('enabled', $raw)) $enabled = !empty($raw['enabled']);
            $scope = strtolower(trim((string)($raw['access_scope'] ?? 'public')));
        } elseif (is_bool($raw)) {
            $enabled = $raw;
        } elseif (is_string($raw) && trim($raw) !== '') {
            $scope = strtolower(trim($raw));
        }
        if (!in_array($scope, ['public','member','vip','admin','disabled'], true)) $scope = 'public';
        // V7.43.1: disabled is a hard-hide state. Older V7.43 clients already
        // honor enabled=false when building Home/quick tabs, so publishing both
        // signals prevents a disabled API from turning into a visible retry row.
        if ($scope === 'disabled') $enabled = false;
        $publicSectionPolicy[$archiveId][$sectionKey] = [
            'enabled'=>$enabled,
            'access_scope'=>$scope,
        ];
    }
    // Keep custom/forward-compatible keys too, but normalize their public form.
    foreach ($sourceRow as $sectionKey => $raw) {
        $sectionKey = strtolower(str_replace('-', '_', trim((string)$sectionKey)));
        if ($sectionKey === '' || isset($publicSectionPolicy[$archiveId][$sectionKey])) continue;
        $enabled = true;
        $scope = 'public';
        if (is_array($raw)) {
            $enabled = array_key_exists('enabled', $raw) ? !empty($raw['enabled']) : true;
            $scope = strtolower(trim((string)($raw['access_scope'] ?? 'public')));
        } elseif (is_bool($raw)) $enabled = $raw;
        elseif (is_string($raw) && trim($raw) !== '') $scope = strtolower(trim($raw));
        if (!in_array($scope, ['public','member','vip','admin','disabled'], true)) $scope = 'public';
        if ($scope === 'disabled') $enabled = false;
        $publicSectionPolicy[$archiveId][$sectionKey] = ['enabled'=>$enabled,'access_scope'=>$scope];
    }
}
$default['home_section_policy'] = $publicSectionPolicy;

if (function_exists('bm_vip_sales_settings')) {
    $sales = bm_vip_sales_settings();
    $default['vip'] = [
        'plans' => array_values(array_filter(array_map(static function ($plan) {
            if (!is_array($plan) || empty($plan['enabled'])) return null;
            return [
                'name'=>(string)($plan['name'] ?? ''), 'latin'=>(string)($plan['latin'] ?? ''),
                'price'=>(string)($plan['price'] ?? ''), 'period'=>(string)($plan['period'] ?? ''),
                'badge'=>(string)($plan['badge'] ?? ''), 'saving'=>(string)($plan['saving'] ?? ''),
                'featured'=>!empty($plan['featured']), 'tone'=>(string)($plan['tone'] ?? 'blue'),
            ];
        }, (array)($sales['plans'] ?? [])))),
        'telegram_username'=>(string)($sales['telegram_username'] ?? 'bankmovie_supp'),
        'purchase_enabled'=>!empty($sales['purchase_enabled']),
        'purchase_message_template'=>(string)($sales['purchase_message_template'] ?? ''),
        'section_title'=>(string)($sales['section_title'] ?? 'BankMovie VIP'),
        'section_description'=>(string)($sales['section_description'] ?? ''),
        'features'=>array_values(array_filter(array_map(static function ($feature) {
            return is_array($feature) && !empty($feature['enabled']) ? (string)($feature['label'] ?? '') : '';
        }, (array)($sales['features'] ?? [])))),
    ];
}

echo json_encode($default, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
