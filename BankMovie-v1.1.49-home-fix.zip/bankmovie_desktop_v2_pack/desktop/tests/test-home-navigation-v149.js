/* Verify the exact production Home-handler code in a controlled environment. */
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const src=fs.readFileSync(require('node:path').join(__dirname,'../src/app.js'),'utf8');
const start=src.indexOf('/* ===== BankMovie Desktop v1.1.49 — dependable header Home navigation');
assert.ok(start!==-1);
let click, calls=0, lock=false, atHome=false, scroller={scrollTop:88}, warnings=[];
const page={body:{classList:{contains:()=>atHome}},addEventListener:(name,fn,capture)=>{assert.equal(name,'click');assert.equal(capture,true);click=fn;}};
const ctx={
 document:page,
 state:{get lastView(){return atHome?'home':'detail';}},
 get bm196NavLock(){return lock;},
 sleep:async()=>{lock=false;},
 route:async(v,force)=>{assert.equal(v,'home');assert.equal(force,false);calls++;atHome=true;},
 $:(q)=>q==='#mainScroller'?scroller:(q==='#view .home-content'&&atHome?{}:null),
 toast:(x)=>warnings.push(x), Date, console
};
vm.runInNewContext(src.slice(start),ctx);
const target={closest:(sel)=>sel.includes('#headerHome')?{}:null};
const fire=()=>{let blocked=false;click({target,preventDefault:()=>{},stopImmediatePropagation:()=>{blocked=true;}});assert.ok(blocked)};
function wait(){return new Promise(r=>setTimeout(r,5))}
(async()=>{
 fire();await wait();assert.equal(calls,1);assert.equal(scroller.scrollTop,0);
 scroller.scrollTop=90;fire();await wait();assert.equal(calls,1);assert.equal(scroller.scrollTop,0);
 atHome=false;lock=true;fire();await wait();assert.equal(calls,2);assert.equal(warnings.length,0);
 // A click on an unrelated control must not be hijacked.
 click({target:{closest:()=>null},preventDefault:()=>{throw Error('unexpected')},stopImmediatePropagation:()=>{throw Error('unexpected')}});
 console.log('Home logo, Home nav, locked transition, no duplicate route: PASS');
})().catch(e=>{console.error(e);process.exitCode=1});
