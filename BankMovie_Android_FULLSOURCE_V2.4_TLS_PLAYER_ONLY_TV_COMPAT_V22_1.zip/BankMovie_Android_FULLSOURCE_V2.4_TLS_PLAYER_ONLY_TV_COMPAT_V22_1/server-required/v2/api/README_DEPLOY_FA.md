# BankMovie V22 secured gateway

- Deploy the **entire v2/api/** folder (including hidden `.private/.htaccess`) to the primary public API domain; do not upload `config.php`, SQL dumps or real keys from your development PC.
- Requires PHP 8.1+ with OpenSSL. `v2/api/.private/` must be writable by PHP but blocked to HTTP. Apache uses the included `.htaccess`; **Nginx MUST additionally configure `location ^~ /v2/api/.private/ { deny all; }`**. Verify `https://DOMAIN/v2/api/.private/signing.php` returns 403/404 (never source content).
- The HMAC signing secret is created automatically using 32 cryptographically secure random bytes on first session; lives in `.private/signing.php` with PHP exit guard and file permissions 0600. Do not place a copy in the APK or repository. Losing this file immediately invalidates all tokens.
- The loginless guest bootstrap `POST v2/api/auth.php` requires a P-256 public key, registration signature, and controls for abuse. It is *not* Google Play dependent. Authenticity of the official APK **cannot** be guaranteed solely with this method; user auth / additional abuse checks required for sensitive operations.
- Access tokens expire in 1800 seconds. All protected endpoints require `X-BM-Access-Token`, `X-BM-Proof-Ts`, `X-BM-Proof-Nonce`, `X-BM-Proof`. Proof is ECDSA SHA256 of `BMV22|METHOD|PATH?QUERY|SHA256(BODY)|SHA256(TOKEN)|TIMESTAMP|NONCE`.
- File rate limits are per-device 50/60s by default, also IP 200/60s. Live search has a separate IP limit. These limits only work across requests on a **single host**; for multiple content servers route secured traffic through this one gateway. There is no MySQL/Redis requirement.
- Old root endpoints (`/app_api.php`, `/api5.php`, `/api2.php`, etc.) remain legacy until rollout; they are **not protected** by the new guard. After migration, block the old paths at server level to prevent bypass. New folder does not magically protect legacy endpoints.
- Run `php /SITE/v2/api/cleanup_private.php` periodically (e.g. hourly) to avoid rate-file accumulation. Do not invoke via HTTP.
- When configuring a reverse proxy, ensure PHP receives HTTPS=on **only if TLS really was validated at a trusted proxy**. Do not trust arbitrary X-Forwarded-Proto headers.
- No HTTP fallback for credentials/API. Optional HTTP media fallback is separate from this gateway and must never carry any auth headers or signed URLs.
- For all admin settings modify via bm_admin.php; check website PHP process user write permission to `.private/policy.php`.

- User/installation quotas are distinct: 50 requests per installation per minute (adjustable), not a strict human-account quota. The default IP limits are intentionally more generous for shared carrier NATs.
- The optional `api2.php`, `api_explorer.php`, `api_discover.php`, `api_boxoffice.php` wrappers require matching original website scripts on the live server; the source patch cannot synthesize those APIs.
- The Android Keystore device proof does not validate an official APK or prevent modified clients from enrolling their own device keys. For premium operations keep the existing website login/VIP checks and monitor abuse.
- Emergency TLS uses normal Android platform trusted CAs. A fully offline Private CA requires its certificate to be provisioned in the APK and maintained separately; this package does NOT ship a Private CA.
