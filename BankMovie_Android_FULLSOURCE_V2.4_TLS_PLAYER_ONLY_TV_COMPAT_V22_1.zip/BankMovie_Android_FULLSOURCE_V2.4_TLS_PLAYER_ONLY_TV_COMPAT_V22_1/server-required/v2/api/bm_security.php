<?php
/**
 * BankMovie V22 — per-installation signed 30-minute sessions.
 * Signing key is SERVER-ONLY. Prefer Android Keystore P-256 proof; old TV boxes may
 * use an in-memory ephemeral EC key for this process while keeping proof mandatory.
 * Access token alone is insufficient: each protected API call must carry an EC signature.
 *
 * Signing key, policy, anti-replay and counters live under v2/api/.private/.
 * Existing root APIs are NOT modified during the migration period.
 * The /v2/api/ endpoints are always proof-protected (except public config,
 * health and issuance); no shared HMAC secret exists in the Android APK.
 * All protected requests MUST reach this same gateway host for an exact quota.
 */
if (defined('BM_V22_AUTH_INCLUDED')) return;
define('BM_V22_AUTH_INCLUDED', true);

function bm22_env(string $key, string $default = ''): string {
    $value = getenv($key);
    return $value === false ? $default : (string)$value;
}
function bm22_enforced(): bool { return true; } // New /v2/api/ endpoints are strictly authenticated.
function bm22_b64url(string $raw): string { return rtrim(strtr(base64_encode($raw), '+/', '-_'), '='); }
function bm22_unb64(string $encoded): string|false {
    if ($encoded === '' || !preg_match('/^[A-Za-z0-9_-]+$/D', $encoded)) return false;
    return base64_decode(strtr($encoded, '-_', '+/') . str_repeat('=', (4 - strlen($encoded) % 4) % 4), true);
}
function bm22_header(string $name): string {
    return trim((string)($_SERVER['HTTP_' . strtoupper(str_replace('-', '_', $name))] ?? ''));
}
function bm22_fail(int $status, string $code, int $retryAfter = 0): never {
    if ($retryAfter > 0) header('Retry-After: ' . $retryAfter);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    http_response_code($status);
    echo json_encode(['status'=>'error','success'=>false,'error_code'=>$code,'http_status'=>$status,
        'message'=>$status === 429 ? 'درخواست‌های زیادی ارسال شده؛ کمی بعد تلاش کنید.' : 'دسترسی معتبر نیست.'], JSON_UNESCAPED_UNICODE);
    exit;
}
function bm22_private_dir(): string {
    $dir = __DIR__ . '/.private';
    if (!is_dir($dir) || !is_writable($dir)) bm22_fail(503,'private_directory_unavailable');
    return $dir;
}
function bm22_policy(): array {
    $defaults = [
        'enabled'=>true, 'limit_per_minute'=>50, 'ip_limit_per_minute'=>1200,
        'live_search_ip_limit'=>120, 'register_ip_limit'=>150,
        'register_device_limit'=>5, 'token_ttl_seconds'=>1800,
        'http_video_fallback'=>false, 'emergency_mode'=>false,
        'video_http_hosts'=>[], 'emergency_base_urls'=>[],
    ];
    $file = bm22_private_dir() . '/policy.php';
    if (!is_file($file)) return $defaults;
    $data=@file_get_contents($file);
    if (!is_string($data)) return $defaults;
    $prefix="<?php http_response_code(404); exit; __halt_compiler(); ?>\n";
    if (!str_starts_with($data,$prefix)) return $defaults;
    $value=json_decode(substr($data,strlen($prefix)),true);
    if (!is_array($value)) return $defaults;
    $out=array_intersect_key($value,$defaults)+$defaults;
    foreach (['limit_per_minute'=>[1,300],'ip_limit_per_minute'=>[20,20000],
       'live_search_ip_limit'=>[10,1200],'register_ip_limit'=>[1,2000],
       'register_device_limit'=>[1,30]] as $name=>$bounds) {
        $out[$name]=max($bounds[0],min($bounds[1],(int)$out[$name]));
    }
    // For interoperability with existing clients the duration is intentionally fixed.
    $out['token_ttl_seconds']=1800;
    return $out;
}
function bm22_save_policy(array $new): bool {
    $folder=bm22_private_dir();
    $payload="<?php http_response_code(404); exit; __halt_compiler(); ?>\n"
         . json_encode($new,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    $path=$folder.'/policy.php';
    $tmp=@tempnam($folder,'policy_');
    if (!$tmp) return false;
    @chmod($tmp,0600);
    if (file_put_contents($tmp,$payload,LOCK_EX)===false || !@rename($tmp,$path)) {
        @unlink($tmp); return false;
    }
    @chmod($path,0600);
    return true;
}
function bm22_secret(): string {
    // Never hash the secret: HMAC needs the original random signing key.
    // The PHP stop prefix prevents downloading it if a dot-dir is accidentally exposed.
    $path=bm22_private_dir().'/signing.php';
    $prefix="<?php http_response_code(404); exit; __halt_compiler(); ?>\n";
    if (!is_file($path)) {
        $tmp=@tempnam(bm22_private_dir(),'seed_');
        if (!$tmp) bm22_fail(503,'key_store_unavailable');
        @chmod($tmp,0600);
        $data=$prefix.base64_encode(random_bytes(32));
        if (file_put_contents($tmp,$data,LOCK_EX)===false) {
            @unlink($tmp); bm22_fail(503,'key_store_unavailable');
        }
        // O_EXCL semantics from link(): do not overwrite a key created concurrently!
        if (!@link($tmp,$path) && !is_file($path)) {
            @unlink($tmp); bm22_fail(503,'key_store_unavailable');
        }
        @unlink($tmp);
        @chmod($path,0600);
    }
    $encoded=@file_get_contents($path);
    if (!is_string($encoded) || !str_starts_with($encoded,$prefix)) bm22_fail(503,'key_store_invalid');
    $raw=base64_decode(trim(substr($encoded,strlen($prefix))),true);
    if (!is_string($raw) || strlen($raw)!==32) bm22_fail(503,'key_store_invalid');
    return $raw;
}
function bm22_client_ip(): string {
    // NEVER trust an unverified user-supplied forwarding header.
    return (string)($_SERVER['REMOTE_ADDR']??'unknown');
}
/** File-only, atomic, exact sliding window. All gateway traffic must land on ONE host. */
function bm22_limit(string $namespace, string $actor, int $max, int $seconds): int {
    if ($max < 1 || $seconds < 1) bm22_fail(503,'rate_config_invalid');
    $hash=hash('sha256',$namespace.'|'.$actor);
    $path=bm22_private_dir().'/rate_'.$hash.'.php';
    $prefix="<?php http_response_code(404); exit; __halt_compiler(); ?>\n";
    $file=@fopen($path,'c+');
    if (!$file) bm22_fail(503,'rate_store_unavailable');
    @chmod($path,0600);
    try {
        if (!@flock($file,LOCK_EX)) bm22_fail(503,'rate_store_unavailable');
        rewind($file);
        $raw=stream_get_contents($file);
        $found=(is_string($raw) && str_starts_with($raw,$prefix))?
            json_decode(substr($raw,strlen($prefix)),true):[];
        $now=microtime(true);
        $events=[];
        foreach (is_array($found)?$found:[] as $t) {
            if (is_numeric($t) && $t > $now-$seconds && $t < $now+30) $events[]=(float)$t;
        }
        $retry=0;
        if (count($events) >= $max) $retry=max(1,(int)ceil(min($events)+$seconds-$now));
        else $events[]=$now;
        rewind($file);ftruncate($file,0);
        if (fwrite($file,$prefix.json_encode($events))===false) bm22_fail(503,'rate_store_unavailable');
        fflush($file);flock($file,LOCK_UN);
        return $retry;
    } finally { fclose($file); }
}
/** One rolling anti-replay file per installation, not one file per nonce. */
function bm22_replay_check(string $deviceHash,string $nonce,int $seconds=180): bool {
    $path=bm22_private_dir().'/nonce_'.hash('sha256',$deviceHash).'.php';
    $prefix="<?php http_response_code(404); exit; __halt_compiler(); ?>\n";
    $f=@fopen($path,'c+');
    if (!$f) bm22_fail(503,'replay_store_unavailable');
    @chmod($path,0600);
    try {
        if (!@flock($f,LOCK_EX)) bm22_fail(503,'replay_store_unavailable');
        rewind($f);
        $raw=stream_get_contents($f);
        $entries=(is_string($raw) && str_starts_with($raw,$prefix))?
          json_decode(substr($raw,strlen($prefix)),true):[];
        if (!is_array($entries)) $entries=[];
        $now=time();
        foreach ($entries as $k=>$v) if (!is_int($v) || $v < $now-$seconds) unset($entries[$k]);
        $key=hash('sha256',$nonce);
        $fresh=!isset($entries[$key]);
        if ($fresh) $entries[$key]=$now;
        rewind($f);ftruncate($f,0);
        fwrite($f,$prefix.json_encode($entries));fflush($f);flock($f,LOCK_UN);
        return $fresh;
    } finally {fclose($f);}
}
function bm22_public_key(string $encoded): OpenSSLAsymmetricKey|false {
    $der = bm22_unb64($encoded);
    if ($der === false || strlen($der) > 512 || strlen($der) < 60) return false;
    $pem = "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($der),64,"\n") . "-----END PUBLIC KEY-----\n";
    $pub = @openssl_pkey_get_public($pem);
    if (!$pub) return false;
    $details = openssl_pkey_get_details($pub);
    if (($details['type'] ?? null) !== OPENSSL_KEYTYPE_EC || ($details['ec']['curve_name'] ?? null) !== 'prime256v1') return false;
    return $pub;
}
function bm22_token_issue(string $device, string $publicKey): array {
    $now = time();
    $claims = [
        'iss'=>'bankmovie-v22', 'aud'=>'bankmovie-android', 'iat'=>$now, 'nbf'=>$now-5,
        'exp'=>$now+1800, 'sub'=>hash('sha256',$publicKey), 'device'=>substr($device,0,80),
        'pk'=>$publicKey, 'jti'=>bin2hex(random_bytes(16))
    ];
    $head = bm22_b64url(json_encode(['alg'=>'HS256','typ'=>'BM22'], JSON_UNESCAPED_SLASHES));
    $body = bm22_b64url(json_encode($claims, JSON_UNESCAPED_SLASHES));
    $input = $head . '.' . $body;
    return ['access_token'=>$input . '.' . bm22_b64url(hash_hmac('sha256',$input,bm22_secret(),true)),
        'token_type'=>'BM22-Proof', 'expires_in'=>1800];
}
function bm22_token_claims(string $token): array|false {
    if (strlen($token)>4096 || count($parts=explode('.',$token))!==3) return false;
    [$h,$p,$s]=$parts;
    $header=json_decode((string)bm22_unb64($h),true);
    $claims=json_decode((string)bm22_unb64($p),true);
    $signature=bm22_unb64($s);
    if (!is_array($header) || ($header['alg']??'')!=='HS256' || ($header['typ']??'')!=='BM22'
        || !is_array($claims) || $signature===false) return false;
    $expected=hash_hmac('sha256',$h.'.'.$p,bm22_secret(),true);
    if (!hash_equals($expected,$signature)) return false;
    $now=time();
    if (($claims['iss']??'')!=='bankmovie-v22' || ($claims['aud']??'')!=='bankmovie-android'
        || !is_int($claims['exp']??null) || $claims['exp'] <= $now
        || !is_int($claims['iat']??null) || $claims['iat'] > $now + 120
        || ($claims['nbf']??0) > $now + 15 || $claims['exp'] - $claims['iat'] > 1800
        || ($claims['sub']??'')!==hash('sha256',(string)($claims['pk']??''))) return false;
    return $claims;
}
function bm22_request_target(): string {
    $uri = (string)($_SERVER['REQUEST_URI'] ?? '');
    $path = (string)(parse_url($uri,PHP_URL_PATH) ?: '/');
    $query = (string)(parse_url($uri,PHP_URL_QUERY) ?: '');
    return $path . ($query !== '' ? '?' . $query : '');
}
function bm22_validate_proof(string $pubKey, string $token): bool {
    $ts=bm22_header('X-BM-Proof-Ts');
    $nonce=bm22_header('X-BM-Proof-Nonce');
    $sig=bm22_unb64(bm22_header('X-BM-Proof'));
    if (!ctype_digit($ts) || abs(time()-(int)$ts)>120 || !preg_match('/^[a-f0-9]{32}$/D',$nonce)
        || $sig===false || strlen($sig)>256) return false;
    $method=strtoupper((string)($_SERVER['REQUEST_METHOD']??'GET'));
    // php://input can be read again by normal downstream PHP JSON handlers.
    $body=file_get_contents('php://input');
    $hash=hash('sha256',$body===false?'':$body);
    $canonical='BMV22|'.$method.'|'.bm22_request_target().'|'.$hash.'|'.hash('sha256',$token).'|'.$ts.'|'.$nonce;
    $pk=bm22_public_key($pubKey);
    return $pk && openssl_verify($canonical,$sig,$pk,OPENSSL_ALGO_SHA256)===1;
}
function bm22_is_live_search(string $endpoint): bool {
    $action=strtolower(trim((string)($_GET['action']??'')));
    if ($endpoint==='app_api') return in_array($action,['live_search','search_suggest'],true);
    if ($endpoint==='archive1_live') return isset($_GET['search']) || isset($_GET['suggest']);
    if ($endpoint==='api2') return isset($_GET['live_search']);
    // Dedicated archive APIs use full-list filters and do not implement a safe
    // separate live-search route; they remain under the normal quota.
    return false;
}
function bm22_guard(string $endpoint=''): bool {
    // Only HTTPS may carry secrets or bearer tokens; never disable TLS verification.
    if (empty($_SERVER['HTTPS']) || strtolower((string)$_SERVER['HTTPS'])==='off') bm22_fail(403,'https_required');
    $token=bm22_header('X-BM-Access-Token');
    if ($token==='') bm22_fail(401,'access_token_required');
    $claims=bm22_token_claims($token);
    if (!is_array($claims) || !bm22_validate_proof((string)$claims['pk'],$token)) bm22_fail(401,'invalid_token_proof');
    $device=(string)$claims['sub'];
    $installationId=(string)($claims['device']??'');
    if (!preg_match('/^[a-f0-9-]{36}$/D',$installationId)) bm22_fail(401,'invalid_installation');
    $nonce=bm22_header('X-BM-Proof-Nonce');
    if (!bm22_replay_check($device,$nonce)) bm22_fail(401,'replayed_request');
    $policy=bm22_policy();
    $ip=bm22_client_ip();
    if (bm22_is_live_search($endpoint)) {
       $retry=bm22_limit('live-search-ip',$ip,(int)$policy['live_search_ip_limit'],60);
       if ($retry) bm22_fail(429,'live_search_rate_limited',$retry);
    } else {
       $retry=bm22_limit('per-installation',$installationId,(int)$policy['limit_per_minute'],60);
       if ($retry) bm22_fail(429,'per_device_rate_limited',$retry);
    }
    $retry=bm22_limit('per-ip',$ip,(int)$policy['ip_limit_per_minute'],60);
    if ($retry) bm22_fail(429,'per_ip_rate_limited',$retry);
    $GLOBALS['bm22_verified_access']=$claims;
    return true;
}
