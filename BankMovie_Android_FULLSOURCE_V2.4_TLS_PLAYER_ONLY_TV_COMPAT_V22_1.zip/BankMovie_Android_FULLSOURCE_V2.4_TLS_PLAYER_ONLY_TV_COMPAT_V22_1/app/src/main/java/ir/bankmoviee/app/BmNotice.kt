package ir.bankmoviee.app

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

object BmNotice {
    enum class Kind { SUCCESS, INFO, WARNING, ERROR }
    private const val TAG = "bm_notice_overlay"

    fun show(context: Context, message: String, kind: Kind = Kind.INFO, durationMs: Long = 2400L) {
        val activity = context as? Activity
        if (activity == null || activity.isFinishing) {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            return
        }
        activity.runOnUiThread {
            val decor = activity.window.decorView as? ViewGroup
            if (decor == null) {
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                return@runOnUiThread
            }
            decor.findViewWithTag<View>(TAG)?.let { decor.removeView(it) }
            val palette = UiPreferences.palette(activity)
            val accent = when (kind) {
                Kind.SUCCESS -> Color.rgb(33, 190, 112)
                Kind.WARNING -> Color.rgb(245, 177, 47)
                Kind.ERROR -> Color.rgb(232, 76, 91)
                Kind.INFO -> palette.primary
            }
            val iconText = when (kind) {
                Kind.SUCCESS -> "✓"
                Kind.WARNING -> "!"
                Kind.ERROR -> "×"
                Kind.INFO -> "i"
            }
            val title = when (kind) {
                Kind.SUCCESS -> "انجام شد"
                Kind.WARNING -> "توجه"
                Kind.ERROR -> "خطا"
                Kind.INFO -> "بانک مووی"
            }
            val row = LinearLayout(activity).apply {
                tag = TAG
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(activity, 13), dp(activity, 10), dp(activity, 13), dp(activity, 10))
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                    UiPreferences.blend(palette.panel, accent, if (palette.light) 0.06f else 0.16f),
                    palette.panel
                )).apply {
                    cornerRadius = dp(activity, 22).toFloat()
                    setStroke(dp(activity, 1), Color.argb(155, Color.red(accent), Color.green(accent), Color.blue(accent)))
                }
                elevation = dp(activity, 18).toFloat()
                alpha = 0f
                translationY = dp(activity, 56).toFloat()
            }
            row.addView(TextView(activity).apply {
                text = iconText
                setTextColor(if (UiPreferences.contrastRatio(Color.BLACK, accent) >= UiPreferences.contrastRatio(Color.WHITE, accent)) Color.BLACK else Color.WHITE)
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(accent) }
            }, LinearLayout.LayoutParams(dp(activity, 40), dp(activity, 40)).apply { marginEnd = dp(activity, 12) })
            row.addView(LinearLayout(activity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT
                addView(TextView(activity).apply {
                    text = title
                    setTextColor(palette.text)
                    textSize = 12.8f
                    typeface = BankmovieFonts.bold(activity)
                    gravity = Gravity.RIGHT
                })
                addView(TextView(activity).apply {
                    text = message
                    setTextColor(palette.muted)
                    textSize = 11.8f
                    typeface = BankmovieFonts.regular(activity)
                    gravity = Gravity.RIGHT
                    maxLines = 2
                    setPadding(0, dp(activity, 2), 0, 0)
                })
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val params = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            ).apply {
                marginStart = dp(activity, 18)
                marginEnd = dp(activity, 18)
                bottomMargin = dp(activity, 102)
            }
            decor.addView(row, params)
            row.animate().alpha(1f).translationY(0f).setDuration(230L)
                .setInterpolator(PathInterpolator(0.16f, 1f, 0.3f, 1f)).start()
            Handler(Looper.getMainLooper()).postDelayed({
                if (row.parent != null) {
                    row.animate().alpha(0f).translationY(dp(activity, 30).toFloat()).setDuration(180L)
                        .setInterpolator(PathInterpolator(0.4f, 0f, 1f, 1f))
                        .withEndAction { (row.parent as? ViewGroup)?.removeView(row) }.start()
                }
            }, durationMs)
        }
    }

    /** Floating cinematic toast with a real button; intentionally never blocks the detail screen. */
    fun showAction(
        context: Context,
        title: String,
        message: String,
        actionLabel: String,
        onAction: () -> Unit,
        durationMs: Long = 9500L
    ) {
        val activity = context as? Activity ?: return
        if (activity.isFinishing || activity.isDestroyed) return
        activity.runOnUiThread {
            val decor = activity.window.decorView as? ViewGroup ?: return@runOnUiThread
            decor.findViewWithTag<View>(TAG)?.let { decor.removeView(it) }
            val palette = UiPreferences.palette(activity)
            val accent = palette.primary
            val card = LinearLayout(activity).apply {
                tag = TAG
                orientation = LinearLayout.VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(activity, 16), dp(activity, 15), dp(activity, 16), dp(activity, 14))
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                    UiPreferences.blend(palette.panel, accent, if (palette.light) .12f else .25f),
                    palette.panel
                )).apply {
                    cornerRadius = dp(activity, 24).toFloat()
                    setStroke(dp(activity, 1), UiPreferences.blend(accent, Color.WHITE, .15f))
                }
                elevation = dp(activity, 20).toFloat()
                alpha = 0f
                translationY = dp(activity, 65).toFloat()
            }
            val heading = LinearLayout(activity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
            }
            val symbol = TextView(activity).apply {
                text = "✦"
                textSize = 21f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(accent, UiPreferences.blend(accent, Color.WHITE, .28f))).apply {
                    cornerRadius = dp(activity, 13).toFloat()
                }
            }
            heading.addView(symbol, LinearLayout.LayoutParams(dp(activity, 42), dp(activity, 42)).apply { marginEnd = dp(activity, 12) })
            heading.addView(LinearLayout(activity).apply {
                orientation = LinearLayout.VERTICAL
                addView(TextView(activity).apply {
                    text = "BANKMOVIE · WATCHLIST"
                    textSize = 8.5f
                    letterSpacing = .12f
                    setTextColor(palette.muted)
                    gravity = Gravity.RIGHT
                })
                addView(TextView(activity).apply {
                    text = title
                    textSize = 16.5f
                    typeface = BankmovieFonts.bold(activity)
                    setTextColor(palette.text)
                    gravity = Gravity.RIGHT
                    setPadding(0, dp(activity, 3), 0, 0)
                })
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val dismiss = TextView(activity).apply {
                text = "×"
                textSize = 23f
                gravity = Gravity.CENTER
                contentDescription = "بستن پیام"
                setTextColor(palette.muted)
                setOnClickListener { (card.parent as? ViewGroup)?.removeView(card) }
            }
            heading.addView(dismiss, LinearLayout.LayoutParams(dp(activity, 32), dp(activity, 42)))
            card.addView(heading)
            card.addView(TextView(activity).apply {
                text = message
                textSize = 11.9f
                typeface = BankmovieFonts.regular(activity)
                setTextColor(palette.muted)
                gravity = Gravity.RIGHT
                maxLines = 3
                setPadding(0, dp(activity, 10), 0, dp(activity, 11))
            })
            card.addView(View(activity).apply {
                background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(accent, UiPreferences.blend(accent, Color.WHITE, .55f))).apply {
                    cornerRadius = dp(activity, 3).toFloat()
                }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(activity, 3)))
            val buttons = LinearLayout(activity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(activity, 12), 0, 0)
            }
            val action = TextView(activity).apply {
                text = actionLabel + " ✦"
                textSize = 12f
                typeface = BankmovieFonts.bold(activity)
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(dp(activity, 18), dp(activity, 10), dp(activity, 18), dp(activity, 10))
                isClickable = true
                isFocusable = true
                background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(accent, UiPreferences.blend(accent, Color.WHITE, .15f))).apply {
                    cornerRadius = dp(activity, 13).toFloat()
                }
                setOnClickListener {
                    (card.parent as? ViewGroup)?.removeView(card)
                    onAction()
                }
            }
            buttons.addView(action)
            buttons.addView(TextView(activity).apply {
                text = "بعداً"
                textSize = 11.5f
                setTextColor(palette.muted)
                setPadding(dp(activity, 16), dp(activity, 9), dp(activity, 16), dp(activity, 9))
                isClickable = true
                isFocusable = true
                setOnClickListener { (card.parent as? ViewGroup)?.removeView(card) }
            })
            card.addView(buttons)
            val params = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
                marginStart = dp(activity, 16)
                marginEnd = dp(activity, 16)
                bottomMargin = dp(activity, 100)
            }
            decor.addView(card, params)
            card.animate().alpha(1f).translationY(0f).setDuration(360L)
                .setInterpolator(PathInterpolator(.18f, 1f, .32f, 1f)).start()
            Handler(Looper.getMainLooper()).postDelayed({
                if (card.parent != null) card.animate().alpha(0f).translationY(dp(activity, 38).toFloat())
                    .setDuration(220L).withEndAction { (card.parent as? ViewGroup)?.removeView(card) }.start()
            }, durationMs)
        }
    }

    private fun dp(context: Context, value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()
}
