#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
cp server-required/v2/api/bm_security.php "$TMP/bm_security.php"
mkdir "$TMP/.private"
cat > "$TMP/test.php" <<'PHP'
<?php
error_reporting(E_ALL);
require __DIR__.'/bm_security.php';
$_SERVER['REMOTE_ADDR']='192.0.2.88';
$_SERVER['HTTPS']='on';
$_SERVER['REQUEST_METHOD']='GET';
$_SERVER['REQUEST_URI']='/v2/api/api5.php?id=tt123';
// Generate a fresh EC P256 keypair to emulate a legitimate Android install.
$private=openssl_pkey_new(['private_key_type'=>OPENSSL_KEYTYPE_EC,'curve_name'=>'prime256v1']);
assert($private instanceof OpenSSLAsymmetricKey);
$details=openssl_pkey_get_details($private);
// Assemble SPKI DER from exported PEM public key.
$pem=$details['key'];
$der=base64_decode(preg_replace('/-----[^-]+-----|\s+/','',$pem));
$public=bm22_b64url($der);
assert(bm22_public_key($public) instanceof OpenSSLAsymmetricKey);
$token=bm22_token_issue('74cb77a5-f1e8-4e5a-96a1-750d94758615',$public)['access_token'];
assert(is_array(bm22_token_claims($token)));
$stamp=(string)time();$nonce=bin2hex(random_bytes(16));
$canonical='BMV22|GET|/v2/api/api5.php?id=tt123|'.hash('sha256','').'|'.hash('sha256',$token).'|'.$stamp.'|'.$nonce;
openssl_sign($canonical,$sig,$private,OPENSSL_ALGO_SHA256);
$_SERVER['HTTP_X_BM_ACCESS_TOKEN']=$token;
$_SERVER['HTTP_X_BM_PROOF_TS']=$stamp;
$_SERVER['HTTP_X_BM_PROOF_NONCE']=$nonce;
$_SERVER['HTTP_X_BM_PROOF']=bm22_b64url($sig);
assert(bm22_validate_proof($public,$token));
assert(bm22_guard('api5'));
assert(!bm22_replay_check(hash('sha256',$public),$nonce));
$bad=$token; $bad[strlen($bad)-1]=($bad[strlen($bad)-1] !=='A' ?'A':'B');
assert(bm22_token_claims($bad)===false);
for($i=0;$i<49;$i++) assert(bm22_limit('fixture-50','one-user',50,60)===0);
assert(bm22_limit('fixture-50','one-user',50,60)===0);
assert(bm22_limit('fixture-50','one-user',50,60)>0);
$orig=bm22_policy();assert($orig['limit_per_minute']===50);
assert(bm22_save_policy(array_merge($orig,['limit_per_minute'=>42])));
assert(bm22_policy()['limit_per_minute']===42);
$stored=file_get_contents(__DIR__.'/.private/signing.php');
assert(str_starts_with($stored,'<?php http_response_code(404); exit;'));
assert(strlen(bm22_secret())===32);
echo "PASS: EC proof, HMAC token, anti-replay, sliding 50/min, private policy+key\n";
PHP
php -d zend.assertions=1 -d assert.exception=1 "$TMP/test.php"
PHP_COUNT=0
while IFS= read -r -d '' f; do
  php -l "$f" >/dev/null
  PHP_COUNT=$((PHP_COUNT+1))
done < <(find server-required/v2/api -maxdepth 1 -name '*.php' -print0)
echo "PASS: $PHP_COUNT V22 PHP files syntax"

python3 - <<'PYTEST'
from pathlib import Path
root=Path('server-required/v2/api')
for endpoint in ('app_api','app_user_api','app_home_feed','archive1_live','api2','api4','api5','api6','api_explorer','api_discover','api_boxoffice'):
    p=root/f'{endpoint}.php'
    assert p.exists(), p
    assert f"bm22_guard('{endpoint}')" in p.read_text(), p
auth=(root/'bm_security.php').read_text()
for feature in ('bm22_token_issue(', 'bm22_validate_proof(', 'bm22_replay_check(', 'bm22_limit(', 'bm22_client_ip(', "bm22_is_live_search("):
    assert feature in auth, feature
assert not (root/'.private/signing.php').exists(), 'Secret MUST NOT be in release zip'
client=Path('app/src/main/java/ir/bankmoviee/app/BmV22Client.kt').read_text()
for feature in ('AndroidKeyStore','ECDSA', 'BMV22|', 'X-BM-Proof-Nonce', 'api_boxoffice.php','api_explorer.php','api2.php','app_config.php'):
    assert feature in client, feature
for f in ('MainActivity.kt','AccountApi.kt','AdminPushJobService.kt'):
    code=(Path('app/src/main/java/ir/bankmoviee/app')/f).read_text()
    assert 'BmV22Client.attach(' in code, f
assert 'return (normal + emergency).distinct().map { BmV22Client.urlForApi(it) }' in (Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt')).read_text()
assert 'instanceFollowRedirects = false' in (Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt')).read_text()
assert 'X-BM-Access-Token' not in Path('app/src/main/java/ir/bankmoviee/app/RuntimeVault.kt').read_text()
assert (Path('server-required/bm_admin.php')).exists(), 'Embedded BM ADMIN source missing'
print('BANKMOVIE_V22_API_FACADES_DEVICE_PROOF_ADMIN_POLICY_OK')
PYTEST
