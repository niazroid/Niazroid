'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const app=fs.readFileSync(path.join(__dirname,'../src/app.js'),'utf8');
const html=fs.readFileSync(path.join(__dirname,'../src/index.html'),'utf8');
const ui=fs.readFileSync(path.join(__dirname,'../src/desktop-policy-ui.js'),'utf8');
const begin=app.indexOf('function archivePolicy(no){');
const end=app.indexOf('function setActiveNav(view){',begin);
assert.ok(begin>0&&end>begin);
const code=app.slice(begin,end);
function enabled(config){
  const context={state:{config}};vm.createContext(context);vm.runInContext(code,context);
  return Array.from(context.enabledArchives());
}
const full=[1,2,3,4,5];
assert.deepEqual(enabled({desktop:{archives:{archive4:{enabled:false}}},app_archive_policy:{archive4:{enabled:true}}}),[1,2,3,5]);
assert.deepEqual(enabled({desktop:{archives:{archive5:{hidden:true}}},app_archive_policy:{archive5:{hidden:false}}}),[1,2,3,4]);
assert.deepEqual(enabled({desktop:{archives:{archive3:{enabled:true}}},app_archive_policy:{archive3:{enabled:false}}}),[1,2,4,5]);
assert.deepEqual(enabled({features:{archives:{archive2_enabled:false}}}),[1,3,4,5]);
assert.deepEqual(enabled({desktop:{archives:{archive1:{enabled:false},archive2:{enabled:false},archive3:{enabled:false},archive4:{enabled:false},archive5:{enabled:false}}}}),[]);
assert.deepEqual(enabled({}),full);
const candBegin=app.indexOf('function bm1124ArchiveCandidates(preferred){');
const candEnd=app.indexOf('async function bm1124LoadHomeArchive(',candBegin);
assert.ok(candBegin>0&&candEnd>candBegin);
const cb=app.slice(candBegin,candEnd);
function choices(allowed,preferred){const ctx={enabledArchives:()=>allowed};vm.createContext(ctx);vm.runInContext(cb,ctx);return Array.from(ctx.bm1124ArchiveCandidates(preferred));}
assert.deepEqual(choices([1,3,5],1),[1,3,5]);
assert.deepEqual(choices([3,5],1),[3,5]);
assert.deepEqual(choices([],1),[]);
assert.match(ui,/appArchives:x\?\.app_archive_policy/);
assert.match(ui,/state\.homeCache=\{\}/);
assert.match(html,/bm-startup-version[^>]*>آخرین نسخه: 1\.0\.0/);
assert.match(app,/bm-auth-version/);
assert.doesNotMatch(app,/function setLoading[^\n]+bm-release-version/);
console.log('PASS disabled archives override inherited desktop/site policy, fallback skips disabled archives, 1.0.0 only on splash + sign-in');
