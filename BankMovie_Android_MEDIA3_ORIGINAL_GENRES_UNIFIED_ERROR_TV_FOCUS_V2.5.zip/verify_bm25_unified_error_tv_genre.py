#!/usr/bin/env python3
"""Static release guard: this is not a substitute for APK/device UI testing."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent
src = (root/'app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')
icon = root/'app/src/main/res/drawable/bm_no_wifi_original.xml'
ET.parse(icon)
assert icon.is_file()
assert 'bm_unified_network_error' in src
assert 'setImageResource(R.drawable.bm_no_wifi_original)' in src
assert 'setImageResource(R.drawable.bm_v14_clapperboard)' in src
assert 'private fun unifiedNetworkFailureCard(' in src
assert 'private var homeSharedErrorHost:' in src
assert 'private val homeFailedRailBoxes' in src
assert 'homeBody.addView(sharedErrorHost' in src
assert 'refreshHomeSharedErrorCard()' in src
assert 'box.visibility = View.GONE\n            homeFailedRailBoxes.add(box)' in src
assert 'if (homeFailedRailBoxes.remove(box))' in src
assert 'renderedPublicPageKey = ""\n                    renderedHomeContext = ""\n                    showHome()' in src
assert 'text = t("بارگذاری انجام نشد"' in src
assert 'text = t("لطفاً موارد زیر را به‌ترتیب بررسی کنید:' in src
assert 'text = t("تلاش دوباره"' in src
assert 'text = emergencyChannelLabel()' in src
instructions = src.split('val instructions = listOf(',1)[1].split(')\n        instructions.forEachIndexed',1)[0]
assert instructions.count('            t("') == 5
assert 'VPN' in instructions and 'تلگرام' in instructions and 'آرشیو دیگر' in instructions
shared_card = src.split('private fun unifiedNetworkFailureCard(',1)[1].split('private fun errorView(',1)[0]
assert 'showHelpCenter' not in shared_card and 'اطلاعات بیشتر' not in shared_card and 'راهنما' not in shared_card
assert 'handleHomeSharedErrorDirectionalFocus(focused, keyCode)' in src
assert 'private fun handleV74CategoryDirectionalFocus(' in src
nav = src.split('private fun handleV74CategoryDirectionalFocus(',1)[1].split('private fun wireV73CategoryGrid(',1)[0]
assert 'index / columnCount' in nav and 'index - columnCount' in nav and 'index + columnCount' in nav
assert 'grid.tag = "bm_v73_category_grid"' in src
assert 'tag = "bm_genre_archive_tab_${pair.first}"' in src
assert 'if (tv) 1.018f else 1.025f' in src
assert (root/'GENRE_ORIGINAL_ASSET_MAP.json').is_file()
print('BM25_UNIFIED_ERROR_TV_GENRES_STATIC_CHECKS_OK (not a compile or TV test)')
