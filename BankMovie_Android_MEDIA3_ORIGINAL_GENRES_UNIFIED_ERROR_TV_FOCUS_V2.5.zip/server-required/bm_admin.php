<?php
declare(strict_types=1);
/* BANKMOVIE_ROOT_DECLUTTER_V235 */
if (!defined('BM_ROOT_DIR')) define('BM_ROOT_DIR', dirname(__DIR__, 2));
@chdir(BM_ROOT_DIR);
require_once BM_ROOT_DIR . '/includes/security_bootstrap.php';
if (PHP_SAPI !== 'cli') {
    require_once BM_ROOT_DIR . '/includes/admin_guard.php';
    require_admin();
    if (!headers_sent()) { header('X-Robots-Tag: noindex, nofollow, noarchive'); header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0'); }
}


/**
 * Bankmovie App Admin v3
 * Security: site session + users.role=admin only. No standalone password.
 */

@ini_set('display_errors', '0');
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header("Permissions-Policy: camera=(), microphone=(), geolocation=()");

require_once BM_ROOT_DIR . '/includes/sticker_packs.php';
require_once BM_ROOT_DIR . '/includes/archive_control.php';
require_once BM_ROOT_DIR . '/includes/bm_admin_archive_sync.php';
require_once BM_ROOT_DIR . '/includes/site_content_control.php';
require_once BM_ROOT_DIR . '/includes/admin_archive_dashboard.php';
require_once BM_ROOT_DIR . '/api6_lib.php';
require_once BM_ROOT_DIR . '/includes/notification_retention.php';
require_once BM_ROOT_DIR . '/includes/fcm_push.php';
require_once BM_ROOT_DIR . '/includes/app_push_notifications.php';
require_once BM_ROOT_DIR . '/v2/api/bm_security.php';

$usedSharedAdminGuard = false;
if (is_file(BM_ROOT_DIR . '/includes/admin_guard.php')) {
    require_once BM_ROOT_DIR . '/includes/admin_guard.php';
    if (function_exists('require_admin')) {
        require_admin();
        $usedSharedAdminGuard = true;
    }
}

if (!$usedSharedAdminGuard) {
    if (!is_file(BM_ROOT_DIR . '/config.php')) {
        http_response_code(500);
        exit('config.php پیدا نشد. bm_admin.php باید در ریشه سایت نصب شود.');
    }
    require_once BM_ROOT_DIR . '/config.php';
require_once BM_ROOT_DIR . '/includes/session_lifecycle.php';
bm_session_lifecycle_boot($pdo ?? null);
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();

    $bmRoleUser = (isset($currentUser) && is_array($currentUser)) ? $currentUser : null;

    // Compatible fallback for the site's session_token authentication.
    if (!$bmRoleUser && !empty($_COOKIE['session_token'])) {
        try {
            if (isset($userObj) && is_object($userObj) && method_exists($userObj, 'checkSession')) {
                $candidate = $userObj->checkSession((string)$_COOKIE['session_token']);
                if (is_array($candidate)) $bmRoleUser = $candidate;
            }
        } catch (Throwable $e) {
            $bmRoleUser = null;
        }
    }

    if (!$bmRoleUser || (($bmRoleUser['role'] ?? '') !== 'admin')) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'] ?? 'bm_admin.php';
        header('Location: /login.php', true, 302);
        exit;
    }
    $currentUser = $bmRoleUser;
}

if (!isset($pdo) || !($pdo instanceof PDO)) {
    if (!is_file(BM_ROOT_DIR . '/config.php')) {
        http_response_code(500);
        exit('config.php پیدا نشد.');
    }
    require_once BM_ROOT_DIR . '/config.php';
}

require_once BM_ROOT_DIR . '/includes/bankmovie_comment_upgrade.php';
bm_site_comment_upgrade_schema($pdo);

// V7.47.1.5: purge legacy APP notification history once.
// Website notification tables/views are intentionally preserved and remain independent.
$bmLegacyNotificationCleanup = ['ran'=>false,'already_done'=>false,'deleted'=>[]];
try {
    bm_push_ensure_schema($pdo);
    $bmLegacyNotificationCleanup = bm_push_legacy_cleanup($pdo, false, true);
    bm_push_cleanup_expired($pdo);
} catch (Throwable $e) {
    error_log('BM Admin push bootstrap: ' . $e->getMessage());
}

function bm_admin_table_exists(PDO $pdo, string $table): bool {
    $safe = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    if ($safe === '') return false;
    try {
        $stmt = $pdo->prepare('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? LIMIT 1');
        $stmt->execute([$safe]);
        return (bool)$stmt->fetchColumn();
    } catch (Throwable $e) {
        return false;
    }
}

function bm_admin_user(): array {
    if (function_exists('admin_current_user')) {
        $u = admin_current_user();
        if (is_array($u)) return $u;
    }
    global $currentUser;
    return (isset($currentUser) && is_array($currentUser)) ? $currentUser : [];
}

function bm_h(mixed $value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function bm_csrf_token(): string {
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    if (empty($_SESSION['bm_admin_csrf_v2'])) {
        $_SESSION['bm_admin_csrf_v2'] = bin2hex(random_bytes(32));
    }
    return (string)$_SESSION['bm_admin_csrf_v2'];
}

function bm_verify_csrf(): void {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') return;
    $posted = (string)($_POST['bm_admin_csrf'] ?? '');
    if ($posted === '' || !hash_equals(bm_csrf_token(), $posted)) {
        http_response_code(403);
        exit('درخواست نامعتبر است. صفحه را تازه‌سازی کن.');
    }
}

function bm_default_config(): array {
    return [
        'schema_version' => 6,
        'ready' => true,
        'message' => 'اپ موقتاً در دسترس نیست.',
        'active_domain' => 'https://bankmovie.top',
        'api_url' => 'https://bankmovie.top/app_api.php',
        'account_api_url' => 'https://bankmovie.top/app_user_api.php',
        'account_api_urls' => ['https://bankmovie.top/app_user_api.php'],
        'servers' => [
            [
                'name' => 'سرور محتوای اصلی',
                'enabled' => true,
                'priority' => 1,
                'domain' => 'https://bankmovie.top',
                'api_url' => 'https://bankmovie.top/app_api.php'
            ]
        ],
        'url_rewrites' => [],
        'features' => [
            'registration_enabled'=>true,'login_enabled'=>true,'comments_enabled'=>true,
            'comment_replies_enabled'=>true,'comment_votes_enabled'=>true,'comment_reports_enabled'=>true,'comment_spoiler_enabled'=>true,
            'notification_center_enabled'=>true,'internal_downloader_enabled'=>true,'multipart_download_enabled'=>true,
            'download_path_selection_enabled'=>true,'advanced_search_enabled'=>true,'categories_enabled'=>true,
            'watchlist_enabled'=>true,'continue_watching_enabled'=>true,'tv_quick_menu_enabled'=>true,
            'profile_cleanup_enabled'=>true,'tv_detail_story_enabled'=>true,'tv_detail_more_info_enabled'=>true,
            'external_player_fallback_enabled'=>true,'search_auto_page_limit'=>10,
            'login_poster_url'=>'','download_limit'=>2,
            'archives'=>[
                'archive1_enabled'=>true,'archive1_hidden'=>false,
                'archive2_enabled'=>true,'archive2_hidden'=>false,
                'archive3_enabled'=>true,'archive3_hidden'=>false,
                'archive4_enabled'=>true,'archive4_hidden'=>false,
                'archive5_enabled'=>true,'archive5_hidden'=>false,
                'archive1_download_vip'=>false,'archive1_stream_vip'=>false,
                'archive2_download_vip'=>false,'archive2_stream_vip'=>false,
                'archive3_download_vip'=>false,'archive3_stream_vip'=>false,
                'archive4_download_vip'=>false,'archive4_stream_vip'=>false,
                'archive5_download_vip'=>false,'archive5_stream_vip'=>false
            ]
        ],
        'comments'=>['edit_minutes'=>10,'rate_count'=>3,'rate_minutes'=>10,'auto_approve_admin'=>true,'auto_approve_vip'=>true],
        'downloads'=>['concurrent_limit'=>2,'retry_count'=>4,'retry_delay_seconds'=>8,'min_free_mb'=>256,'multipart_parts'=>4,'redirect_enabled'=>true,'modern_client_only'=>true],
        'home'=>[
            'archive1_sections'=>['updated_movies','updated_series','korean_series','dubbed','chinese_series','top_2026','anime','turkish','collections'],
            'archive2_sections'=>['updated_movies','updated_series','dubbed','animation','action','drama','collections'],
            'archive3_sections'=>['new_movies','new_series','updated_animations','updated_anime','dubbed_movies','subtitled_movies','dubbed_series','subtitled_series','korean_series','turkish_series','collections'],
            'archive4_sections'=>['new_movies','new_series','updated_animations','updated_anime','dubbed_movies','subtitled_movies','collections'],
            'archive5_sections'=>['new_movies','new_series','turkish','animation']
        ],
        // Empty by default for migration safety. Existing installs keep their
        // current archive state until BM Admin is explicitly saved once.
        'home_ad' => ['enabled'=>false,'title'=>'','text'=>'','image_url'=>'','link_url'=>'','button_text'=>'','button_icon'=>'arrow'],
        'app_archive_policy'=>[],
        'home_section_policy'=>[],
        'ui'=>[
            'display_year'=>0,
            'search_max_year'=>0,
            'text_overrides'=>['fa'=>[], 'en'=>[]]
        ],
        'notice' => [
            'enabled' => false,
            'id' => '',
            'type' => 'admin',
            'title' => '',
            'message' => '',
            'target' => [],
            'dismissible' => true
        ],
        // V7.47.1: Bale is an optional emergency/social route. It is OFF on
        // migration so existing Telegram behavior never changes until admin opts in.
        'social' => [
            'bale_enabled' => false,
            'bale_channel_url' => '',
            'bale_purchase_url' => '',
            'emergency_channel' => 'telegram',
            'vip_purchase_provider' => 'telegram'
        ],
        'update' => [
            'enabled' => false,
            'version_code' => 5300001,
            'version_name' => '2.2',
            'apk_url' => '',
            'apk_urls' => [
                'universal' => '',
                'arm64_v8a' => '',
                'armeabi_v7a' => ''
            ],
            'force' => false,
            'title' => 'آپدیت جدید آماده است',
            'message' => 'نسخه جدید Bankmovie آماده دانلود است.',
            'changes' => []
        ],
        'version_policy' => [
            'enabled' => false,
            'minimum_version_code' => 0,
            'minimum_version_name' => '',
            'blocked_version_names' => [],
            'blocked_version_codes' => [],
            'force_update_blocked' => false,
            'latest_version_only' => false,
            'block_message' => 'این نسخه از Bankmovie غیرفعال شده است. برای ادامه نسخه جدید را نصب کنید.'
        ],
        'updated_at' => gmdate('c')
    ];
}

function bm_app_home_section_catalog(): array {
    return [
        1 => [
            'updated_movies'=>'فیلم‌های بروز شده',
            'updated_series'=>'سریال‌های بروز شده',
            'korean_series'=>'سریال‌های کره‌ای',
            'dubbed'=>'دوبله فارسی',
            'chinese_series'=>'سریال‌های چینی',
            'top_2026'=>'برترین‌های 2026',
            'top_movies'=>'۲۵۰ فیلم برتر IMDb',
            'top_series'=>'۲۵۰ سریال برتر IMDb',
            'anime'=>'انیمه',
            'turkish'=>'سریال‌های ترکی',
            'collections'=>'کالکشن‌ها',
        ],
        2 => [
            'updated_movies'=>'اکران 2025 و 2026',
            'updated_series'=>'سریال‌های آپدیت‌شده',
            'dubbed'=>'دوبله فارسی',
            'animation'=>'انیمیشن',
            'action'=>'اکشن',
            'drama'=>'درام',
            'collections'=>'کالکشن‌ها',
        ],
        3 => [
            'new_movies'=>'جدیدترین فیلم‌ها',
            'new_series'=>'جدیدترین سریال‌ها',
            'updated_animations'=>'انیمیشن‌های به‌روزشده',
            'updated_anime'=>'انیمه‌های به‌روزشده',
            'dubbed_movies'=>'فیلم‌های دوبله',
            'subtitled_movies'=>'فیلم‌های زیرنویس‌دار',
            'dubbed_series'=>'سریال‌های دوبله',
            'subtitled_series'=>'سریال‌های زیرنویس‌دار',
            'mini_series'=>'مینی‌سریال‌ها',
            'korean_series'=>'سریال‌های کره‌ای',
            'turkish_series'=>'سریال‌های ترکی',
            'collections'=>'کالکشن‌ها',
        ],
        4 => [
            'new_movies'=>'جدیدترین فیلم‌ها',
            'new_series'=>'جدیدترین سریال‌ها',
            'updated_animations'=>'انیمیشن‌های به‌روزشده',
            'updated_anime'=>'انیمه‌های به‌روزشده',
            'dubbed_movies'=>'فیلم‌های دوبله',
            'subtitled_movies'=>'فیلم‌های زیرنویس‌دار',
            'collections'=>'کالکشن‌ها',
        ],
        5 => [
            'new_movies'=>'فیلم‌های جدید',
            'new_series'=>'سریال‌های جدید',
            'turkish'=>'ترکی',
            'animation'=>'انیمیشن و انیمه',
        ],
    ];
}

function bm_app_section_policy_value(array $config, int $archiveNumber, string $section): array {
    $archiveId = 'archive' . $archiveNumber;
    $row = (array)($config['home_section_policy'][$archiveId] ?? []);
    $raw = $row[$section] ?? null;
    if (is_array($raw)) {
        $enabled = array_key_exists('enabled', $raw) ? !empty($raw['enabled']) : true;
        $scope = strtolower(trim((string)($raw['access_scope'] ?? 'public')));
        if (!in_array($scope, ['public','member','vip','admin','disabled'], true)) $scope = 'public';
        if ($scope === 'disabled') $enabled = false;
        return ['enabled'=>$enabled, 'access_scope'=>$scope];
    }
    if (is_bool($raw)) return ['enabled'=>$raw, 'access_scope'=>'public'];
    if (is_string($raw) && trim($raw) !== '') {
        $scope = strtolower(trim($raw));
        if (!in_array($scope, ['public','member','vip','admin','disabled'], true)) $scope = 'public';
        return ['enabled'=>$scope !== 'disabled', 'access_scope'=>$scope];
    }
    $homeKey = 'archive' . $archiveNumber . '_sections';
    // V7.45.5: IMDb Top 250 are catalogue pages, not Home rails. Existing
    // configs therefore legitimately omit them from home.archive1_sections.
    // Show their new BM Admin controls as enabled until the admin explicitly saves
    // a policy row; after save, the explicit row above becomes authoritative.
    if ($archiveNumber === 1 && in_array($section, ['top_movies','top_series'], true)) {
        return ['enabled'=>true, 'access_scope'=>'public'];
    }
    if (array_key_exists($homeKey, (array)($config['home'] ?? []))) {
        $enabled = in_array($section, array_map(static fn($v): string => strtolower(str_replace('-', '_', trim((string)$v))), (array)$config['home'][$homeKey]), true);
        return ['enabled'=>$enabled, 'access_scope'=>'public'];
    }
    return ['enabled'=>true, 'access_scope'=>'public'];
}

function bm_load_config(string $file): array {
    $cfg = bm_default_config();
    if (!is_file($file)) return $cfg;
    $raw = file_get_contents($file);
    $saved = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($saved)) return $cfg;
    $merged = array_replace_recursive($cfg, $saved);
    if ((int)($merged['schema_version'] ?? 0) < 6) {
        $servers = array_values(array_filter((array)($merged['servers'] ?? []), static function ($server): bool {
            if (!is_array($server)) return false;
            $host = strtolower((string)(parse_url((string)($server['domain'] ?? ''), PHP_URL_HOST) ?: ''));
            return !in_array($host, ['bankmoviez.top','www.bankmoviez.top'], true);
        }));
        if (!$servers) $servers = $cfg['servers'];
        usort($servers, static fn(array $a, array $b): int => ((int)($a['priority'] ?? 99)) <=> ((int)($b['priority'] ?? 99)));
        $primary = null;
        foreach ($servers as &$server) {
            if ($primary === null && !empty($server['enabled'])) $primary = $server;
        }
        unset($server);
        if ($primary === null) { $servers[0]['enabled'] = true; $primary = $servers[0]; }
        $domain = rtrim((string)($primary['domain'] ?? 'https://bankmovie.top'), '/');
        $merged['schema_version'] = 6;
        $merged['servers'] = $servers;
        $merged['active_domain'] = $domain;
        $merged['api_url'] = (string)($primary['api_url'] ?? ($domain . '/app_api.php'));
        $merged['account_api_url'] = $domain . '/app_user_api.php';
        $merged['account_api_urls'] = array_values(array_unique(array_map(
            static fn($item): string => rtrim((string)($item['domain'] ?? ''), '/') . '/app_user_api.php',
            array_filter($servers, static fn($item): bool => !empty($item['enabled']))
        )));
    }
    return $merged;
}

function bm_bool(string $name): bool {
    return isset($_POST[$name]) && (string)$_POST[$name] === '1';
}

function bm_lines(string $raw): array {
    $raw = str_replace(["\r\n", "\r", ',', '،'], "\n", $raw);
    $items = array_map('trim', explode("\n", $raw));
    $items = array_values(array_unique(array_filter($items, static fn($v) => $v !== '')));
    return array_slice($items, 0, 100);
}


function bm_text_override_lines(string $raw): array {
    $out = [];
    foreach (preg_split('/\R/u', $raw) ?: [] as $line) {
        $line = trim((string)$line);
        if ($line === '' || str_starts_with($line, '#')) continue;
        $parts = preg_split('/\s*(?:=>|→|\|\|\|)\s*/u', $line, 2);
        if (!is_array($parts) || count($parts) !== 2) continue;
        $from = trim(str_replace('\\n', "\n", strip_tags((string)$parts[0])));
        $to = trim(str_replace('\\n', "\n", strip_tags((string)$parts[1])));
        $fromLen = function_exists('mb_strlen') ? mb_strlen($from, 'UTF-8') : strlen($from);
        $toLen = function_exists('mb_strlen') ? mb_strlen($to, 'UTF-8') : strlen($to);
        if ($from === '' || $fromLen > 1600 || $toLen > 1600) continue;
        $out[$from] = $to;
        if (count($out) >= 800) break;
    }
    return $out;
}

function bm_text_override_dump(array $items): string {
    $lines = [];
    foreach ($items as $from => $to) {
        if (!is_string($from) || (!is_string($to) && !is_numeric($to))) continue;
        $left = str_replace(["\r", "\n"], ['', '\\n'], $from);
        $right = str_replace(["\r", "\n"], ['', '\\n'], (string)$to);
        $lines[] = $left . ' => ' . $right;
    }
    return implode("\n", $lines);
}

function bm_int_lines(string $raw): array {
    $out = [];
    foreach (bm_lines($raw) as $item) {
        $value = (int)$item;
        if ($value > 0) $out[] = $value;
    }
    return array_values(array_unique($out));
}

function bm_clean_url(string $url, bool $allowEmpty = true): string {
    $url = trim($url);
    if ($url === '' && $allowEmpty) return '';
    if (!preg_match('~^https?://~i', $url)) $url = 'https://' . ltrim($url, '/');
    if (!filter_var($url, FILTER_VALIDATE_URL)) throw new RuntimeException('یکی از لینک‌ها معتبر نیست.');
    return $url;
}

function bm_parse_servers(): array {
    $names = isset($_POST['server_name']) && is_array($_POST['server_name']) ? $_POST['server_name'] : [];
    $domains = isset($_POST['server_domain']) && is_array($_POST['server_domain']) ? $_POST['server_domain'] : [];
    $apis = isset($_POST['server_api']) && is_array($_POST['server_api']) ? $_POST['server_api'] : [];
    $priorities = isset($_POST['server_priority']) && is_array($_POST['server_priority']) ? $_POST['server_priority'] : [];
    $enabledMap = isset($_POST['server_enabled']) && is_array($_POST['server_enabled']) ? $_POST['server_enabled'] : [];

    $indexes = array_values(array_unique(array_merge(
        array_keys($names), array_keys($domains), array_keys($apis), array_keys($priorities)
    )));
    $servers = [];

    foreach ($indexes as $index) {
        $name = trim((string)($names[$index] ?? ''));
        $domainRaw = trim((string)($domains[$index] ?? ''));
        $apiRaw = trim((string)($apis[$index] ?? ''));
        if ($name === '' && $domainRaw === '' && $apiRaw === '') continue;

        $domain = rtrim(bm_clean_url($domainRaw, false), '/');
        $domainHost = strtolower((string)(parse_url($domain, PHP_URL_HOST) ?: ''));
        if (in_array($domainHost, ['bankmoviez.top','www.bankmoviez.top'], true)) {
            throw new RuntimeException('bankmoviez.top فقط کنترلر ریموت است؛ اینجا دامنه سرور ثانویه محتوا را وارد کن.');
        }
        $api = $apiRaw === '' ? $domain . '/app_api.php' : bm_clean_url($apiRaw, false);
        $servers[] = [
            'name' => $name !== '' ? $name : ('سرور ' . (count($servers) + 1)),
            'enabled' => isset($enabledMap[$index]) && (string)$enabledMap[$index] === '1',
            'priority' => max(1, (int)($priorities[$index] ?? (count($servers) + 1))),
            'domain' => $domain,
            'api_url' => $api
        ];
    }

    usort($servers, static fn(array $a, array $b): int => ($a['priority'] <=> $b['priority']));
    if (!$servers) throw new RuntimeException('حداقل یک سرور باید ثبت شود.');
    if (!array_filter($servers, static fn(array $server): bool => !empty($server['enabled']))) {
        throw new RuntimeException('حداقل یک سرور باید فعال باشد.');
    }
    return array_values($servers);
}

function bm_parse_rewrites(): array {
    $froms = isset($_POST['rewrite_from']) && is_array($_POST['rewrite_from']) ? $_POST['rewrite_from'] : [];
    $tos = isset($_POST['rewrite_to']) && is_array($_POST['rewrite_to']) ? $_POST['rewrite_to'] : [];
    $modes = isset($_POST['rewrite_mode']) && is_array($_POST['rewrite_mode']) ? $_POST['rewrite_mode'] : [];
    $enabledMap = isset($_POST['rewrite_enabled']) && is_array($_POST['rewrite_enabled']) ? $_POST['rewrite_enabled'] : [];

    $indexes = array_values(array_unique(array_merge(array_keys($froms), array_keys($tos), array_keys($modes))));
    $rules = [];
    foreach ($indexes as $index) {
        $from = trim((string)($froms[$index] ?? ''));
        $to = trim((string)($tos[$index] ?? ''));
        $mode = (string)($modes[$index] ?? 'replace');
        if ($from === '') continue;
        if (!in_array($mode, ['replace', 'active'], true)) $mode = 'replace';
        if ($mode === 'active') {
            $to = 'ACTIVE';
        } elseif ($to === '') {
            throw new RuntimeException('برای قانون جایگزینی دامنه، دامنه مقصد را وارد کن.');
        } else {
            $to = rtrim(bm_clean_url($to, false), '/');
        }
        $rules[] = [
            'enabled' => isset($enabledMap[$index]) && (string)$enabledMap[$index] === '1',
            'from' => $from,
            'to' => $to,
            'mode' => $mode
        ];
    }
    return $rules;
}

function bm_admin_ensure_notification_table(PDO $pdo): void {
    // Kept for local compatibility; BM Admin Push is application-only now.
    if (function_exists('bm_push_ensure_schema')) bm_push_ensure_schema($pdo);
}

function bm_atomic_save(string $file, array $config): void {
    $json = json_encode($config, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if (!is_string($json)) throw new RuntimeException('ساخت JSON تنظیمات ناموفق بود.');

    if (is_file($file)) @copy($file, $file . '.backup');
    $tmp = $file . '.tmp.' . bin2hex(random_bytes(5));
    if (file_put_contents($tmp, $json . "\n", LOCK_EX) === false) {
        throw new RuntimeException('امکان نوشتن فایل تنظیمات وجود ندارد.');
    }
    @chmod($tmp, 0640);
    if (!@rename($tmp, $file)) {
        @unlink($tmp);
        throw new RuntimeException('جایگزینی امن فایل تنظیمات ناموفق بود.');
    }
}

function bm_audit(string $file, array $user, string $action, array $details = []): void {
    $record = [
        'time' => gmdate('c'),
        'admin_id' => $user['id'] ?? null,
        'admin' => $user['username'] ?? $user['email'] ?? 'admin',
        'action' => $action,
        'details' => $details,
        'ip_hash' => substr(hash('sha256', (string)($_SERVER['REMOTE_ADDR'] ?? '')), 0, 12)
    ];
    @file_put_contents($file, json_encode($record, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n", FILE_APPEND | LOCK_EX);
}

function bm_last_audits(string $file, int $limit = 8): array {
    if (!is_file($file)) return [];
    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
    $out = [];
    foreach (array_slice(array_reverse($lines), 0, $limit) as $line) {
        $row = json_decode($line, true);
        if (is_array($row)) $out[] = $row;
    }
    return $out;
}

bm_verify_csrf();

$configFile = BM_ROOT_DIR . '/bankmovie_remote_config.json';
$auditFile = BM_ROOT_DIR . '/logs/bankmovie_admin_audit.log';
$user = bm_admin_user();
$config = bm_load_config($configFile);
$savedOk = false;
$saveError = '';
$saveNotice = '';

// V20: read-only diagnostics for the *saved* mirror configuration. Never accept
// arbitrary URLs from the browser and never follow redirects. A mirror needs
// the same archive endpoints, not just a responding home page.
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && ($_POST['action'] ?? '') === 'check_content_mirror_v20') {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    $idx = filter_var($_POST['server_index'] ?? null, FILTER_VALIDATE_INT);
    $list = array_values((array)($config['servers'] ?? []));
    if ($idx === false || $idx === null || !isset($list[$idx]) || !is_array($list[$idx])) {
        http_response_code(400);
        echo json_encode(['success'=>false,'message'=>'ابتدا تنظیمات سرور را ذخیره کن.'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $base = rtrim((string)($list[$idx]['domain'] ?? ''), '/');
    $parsed = parse_url($base);
    $host = strtolower((string)($parsed['host'] ?? ''));
    $port = (int)($parsed['port'] ?? 443);
    if (($parsed['scheme'] ?? '') !== 'https' || $port !== 443 ||
        !preg_match('/^(?=.{4,253}$)[a-z0-9.-]+$/', $host) ||
        in_array($host, ['localhost','bankmoviez.top','www.bankmoviez.top'], true)) {
        http_response_code(400);
        echo json_encode(['success'=>false,'message'=>'دامنه محتوا معتبر نیست.'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $ips = @gethostbynamel($host) ?: [];
    $ip = '';
    foreach ($ips as $candidateIp) {
        if (filter_var($candidateIp, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            $ip = $candidateIp;
            break;
        }
    }
    if ($ip === '') {
        echo json_encode(['success'=>false,'message'=>'DNS عمومی این دامنه قابل بررسی نیست.'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    $basePath = rtrim((string)($parsed['path'] ?? ''), '/');
    $checks = [
        'اپ / API اصلی'=>'/app_api.php?action=section&archive=1&section=updated_movies&page=1&limit=1',
        'آرشیو ۱'=>'/archive1_live.php?section=chinese_series&page=1&limit=1',
        'آرشیو ۳'=>'/api6.php?action=options',
        'آرشیو ۴'=>'/api4.php?section=new_movies&page=1',
        'آرشیو ۵'=>'/api5.php?archive5=1&section=new_movies&page=1&limit=1',
    ];
    $results = [];
    foreach ($checks as $label => $suffix) {
        $context = stream_context_create(['ssl'=>[
            'verify_peer'=>true,'verify_peer_name'=>true,'peer_name'=>$host,
            'SNI_enabled'=>true,'SNI_server_name'=>$host,
        ]]);
        $errno = 0; $errstr = '';
        $socket = @stream_socket_client('ssl://' . $ip . ':443', $errno, $errstr, 2.0, STREAM_CLIENT_CONNECT, $context);
        if (!$socket) {
            $results[] = ['label'=>$label,'status'=>'unreachable','text'=>'اتصال HTTPS برقرار نشد'];
            continue;
        }
        stream_set_timeout($socket, 3);
        $target = $basePath . $suffix;
        $request = "GET $target HTTP/1.1\r\nHost: $host\r\nAccept: application/json\r\nUser-Agent: BankMovie-Admin-Health/1\r\nRange: bytes=0-16383\r\nConnection: close\r\n\r\n";
        @fwrite($socket, $request);
        $response = '';
        while (!feof($socket) && strlen($response) < 24576) {
            $chunk = @fread($socket, 4096);
            if ($chunk === false || $chunk === '') break;
            $response .= $chunk;
            if (str_contains($response, "\r\n\r\n") && strlen($response) >= 18000) break;
        }
        $meta = stream_get_meta_data($socket);
        fclose($socket);
        if (!preg_match('~^HTTP/\d(?:\.\d)?\s+(\d{3})~', $response, $hit)) {
            $results[] = ['label'=>$label,'status'=>'unreachable','text'=>!empty($meta['timed_out'])?'مهلت پاسخ تمام شد':'پاسخ HTTP معتبر نبود'];
            continue;
        }
        $http = (int)$hit[1];
        $headerEnd = strpos($response, "\r\n\r\n");
        $body = $headerEnd === false ? '' : trim(substr($response, $headerEnd + 4));
        $json = json_decode($body, true);
        $isUnavailable = is_array($json) && (!empty($json['source_unavailable']) || ($json['status'] ?? '') === 'degraded');
        if ($http >= 200 && $http < 300 && is_array($json) && !$isUnavailable) {
            $status='healthy'; $statusText='JSON معتبر دریافت شد';
        } elseif ($http === 401 || $http === 403) {
            $status='auth'; $statusText='مسیر هست؛ به اعتبارسنجی نیاز دارد';
        } elseif ($http === 429) {
            $status='rate'; $statusText='محدودیت تعداد درخواست';
        } elseif ($isUnavailable) {
            $status='down'; $statusText='منبع آرشیو از دسترس خارج است';
        } else {
            $status='down'; $statusText='پاسخ قابل استفاده نیست (HTTP ' . $http . ')';
        }
        $results[] = ['label'=>$label,'status'=>$status,'text'=>$statusText];
    }
    echo json_encode(['success'=>true,'domain'=>$base,'checks'=>$results,
        'note'=>'موفقیت این بررسی به معنی کارکرد پخش و ورود VIP نیست.'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    try {
        $action = (string)($_POST['action'] ?? 'save');

        if ($action === 'save_home_ad') {
            // Standalone CSRF-guarded BM Admin ad editor; preserves every unrelated setting.
            $oldAd = is_array($config['home_ad'] ?? null) ? $config['home_ad'] : [];
            $clip = static function($value, int $limit): string {
                $value = trim(strip_tags((string)$value));
                return function_exists('mb_substr') ? mb_substr($value,0,$limit,'UTF-8') : substr($value,0,$limit);
            };
            $url = static function($value): string {
                $value = trim((string)$value);
                if ($value === '') return '';
                if (strlen($value) > 1500 || preg_match('/[\x00-\x1f\x7f]/', $value)) throw new RuntimeException('آدرس تبلیغات نامعتبر است.');
                if (str_starts_with($value,'/') && !str_starts_with($value,'//') && !str_contains($value,'\\')) return $value;
                $parts = parse_url($value);
                if (!is_array($parts) || !in_array(strtolower((string)($parts['scheme']??'')),['https','http'],true) || empty($parts['host']) || isset($parts['user']) || isset($parts['pass'])) {
                    throw new RuntimeException('فقط لینک معتبر http(s) یا مسیر داخلی سایت مجاز است.');
                }
                return $value;
            };
            $image = $url($_POST['ad_image_url'] ?? ($oldAd['image_url'] ?? ''));
            if (isset($_POST['ad_remove_image'])) $image = '';
            $upload = $_FILES['ad_image_upload'] ?? null;
            if (is_array($upload) && (int)($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
                if ((int)($upload['error'] ?? -1) !== UPLOAD_ERR_OK || (int)($upload['size'] ?? 0) > 4*1024*1024 || (int)($upload['size'] ?? 0) <= 0) {
                    throw new RuntimeException('آپلود ناموفق است یا عکس بیشتر از ۴ مگابایت است.');
                }
                $tmp = (string)($upload['tmp_name'] ?? '');
                if (!is_uploaded_file($tmp)) throw new RuntimeException('فایل آپلودشده معتبر نیست.');
                $info = @getimagesize($tmp);
                $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
                $mime = is_array($info) ? (string)($info['mime'] ?? '') : '';
                if (!isset($allowed[$mime]) || (int)($info[0] ?? 0) > 6000 || (int)($info[1] ?? 0) > 6000) {
                    throw new RuntimeException('فقط JPG، PNG، WebP و GIF معتبر تا ۶۰۰۰ پیکسل مجازند.');
                }
                $uploadDir = BM_ROOT_DIR . '/uploads/bm-app-ads';
                if (!is_dir($uploadDir) && !@mkdir($uploadDir, 0755, true) && !is_dir($uploadDir)) {
                    throw new RuntimeException('ساخت پوشه عکس تبلیغ ممکن نیست.');
                }
                // Public artworks must be traversable by a separate nginx/static user.
                // Earlier releases used 0750 and produced blank images in both admin and app.
                @chmod($uploadDir, 0755);
                // Prevent executable uploads even if a proxy changes Content-Type.
                if (!is_file($uploadDir . '/.htaccess')) {
                    @file_put_contents($uploadDir . '/.htaccess', "Options -Indexes\n<FilesMatch \"\\.(php[0-9]?|phtml|phar|cgi|pl)$\">\nRequire all denied\n</FilesMatch>\n");
                }
                $name = bin2hex(random_bytes(14)) . '.' . $allowed[$mime];
                if (!move_uploaded_file($tmp, $uploadDir . '/' . $name)) throw new RuntimeException('ذخیره عکس روی سرور ناموفق بود.');
                @chmod($uploadDir . '/' . $name, 0644);
                $image = '/uploads/bm-app-ads/' . $name;
                // Create a mobile-sized derivative once, not on each app request.
                // If GD is missing (common on shared hosting), fall back to the
                // original while Android's persistent disk cache still works.
                if (function_exists('imagecreatetruecolor') && function_exists('imagecopyresampled')) {
                    $original = $uploadDir . '/' . $name;
                    $source = match ($mime) {
                        'image/jpeg' => function_exists('imagecreatefromjpeg') ? @imagecreatefromjpeg($original) : false,
                        'image/png' => function_exists('imagecreatefrompng') ? @imagecreatefrompng($original) : false,
                        'image/webp' => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($original) : false,
                        default => false, // preserve animated GIF instead of flattening it
                    };
                    if ($source !== false) {
                        try {
                            $w = imagesx($source); $h = imagesy($source);
                            $scale = min(1.0, 1200 / max(1,$w), 620 / max(1,$h));
                            $ow = max(1,(int)round($w*$scale)); $oh = max(1,(int)round($h*$scale));
                            $small = imagecreatetruecolor($ow,$oh);
                            imagealphablending($small,false); imagesavealpha($small,true);
                            imagecopyresampled($small,$source,0,0,0,0,$ow,$oh,$w,$h);
                            if (function_exists('imagewebp')) {
                                @imagewebp($small,$uploadDir.'/'.pathinfo($name,PATHINFO_FILENAME).'.optimized.webp',78);
                            } else if (function_exists('imagejpeg')) {
                                @imagejpeg($small,$uploadDir.'/'.pathinfo($name,PATHINFO_FILENAME).'.optimized.jpg',80);
                            }
                            imagedestroy($small);
                        } finally { imagedestroy($source); }
                    }
                }
            }
            $adLink = $url($_POST['ad_link_url'] ?? '');
            if (str_starts_with(strtolower($adLink), 'http://')) {
                throw new RuntimeException('لینک دکمه تبلیغ باید HTTPS باشد تا داخل اپ باز شود.');
            }
            $config['home_ad'] = [
                'enabled'=>!empty($_POST['ad_enabled']),
                'title'=>$clip($_POST['ad_title'] ?? '', 100),
                'text'=>$clip($_POST['ad_text'] ?? '', 1000),
                'image_url'=>$image,
                'link_url'=>$adLink,
                'button_text'=>$clip($_POST['ad_button_text'] ?? '', 48),
                'button_icon'=>in_array((string)($_POST['ad_button_icon'] ?? 'arrow'), ['arrow','eye','bag','play','external','none'], true) ? (string)$_POST['ad_button_icon'] : 'arrow',
            ];
            if ($config['home_ad']['enabled'] && $config['home_ad']['title'] === '' && $config['home_ad']['text'] === '' && $image === '') {
                throw new RuntimeException('برای فعال‌کردن تبلیغ، متن یا عکس وارد کن.');
            }
            $config['config_revision'] = max(1,(int)($config['config_revision'] ?? 0)+1);
            $config['updated_at'] = gmdate('c');
            bm_atomic_save($configFile, $config);
            bm_audit($auditFile, $user, 'save_home_ad', ['enabled'=>$config['home_ad']['enabled'],'has_image'=>$image!=='']);
            $savedOk = true;
            $saveNotice = 'باکس تبلیغات با موفقیت ذخیره شد.';
        } elseif ($action === 'save_v22_security') {
            // Separate form, admin+CSRF-gated. No changes to legacy API configuration.
            $old=bm22_policy();
            $next=$old;
            foreach (['limit_per_minute'=>[1,300],'ip_limit_per_minute'=>[20,20000],
               'live_search_ip_limit'=>[10,1200],'register_ip_limit'=>[1,2000],
               'register_device_limit'=>[1,30]] as $field=>$bounds) {
                 $next[$field]=max($bounds[0],min($bounds[1],(int)($_POST[$field]??$old[$field])));
            }
            $next['token_ttl_seconds']=1800;
            $next['http_video_fallback']=isset($_POST['http_video_fallback']);
            $next['emergency_mode']=isset($_POST['emergency_mode']);
            $hosts=explode("\n",str_replace("\r",'',(string)($_POST['video_http_hosts']??'')));
            $next['video_http_hosts']=array_values(array_unique(array_filter(array_map(static function($host): string {
                 $host=strtolower(trim($host));
                 return $host==='*' || preg_match('/^(?:[a-z0-9-]+\\.)+[a-z]{2,}$/D',$host)?$host:'';
            },$hosts))));
            $urls=explode("\n",str_replace("\r",'',(string)($_POST['emergency_base_urls']??'')));
            $next['emergency_base_urls']=array_values(array_unique(array_filter(array_map(static function($url): string {
                 $url=rtrim(trim($url),'/');
                 if (!preg_match('~^https://~i',$url) || !filter_var($url,FILTER_VALIDATE_URL)) return '';
                 return $url;
            },$urls))));
            if (count($next['video_http_hosts'])>30 || count($next['emergency_base_urls'])>10) {
                throw new RuntimeException('تعداد دامنه‌ها بیشتر از سقف مجاز است.');
            }
            if (!bm22_save_policy($next)) throw new RuntimeException('ذخیره سیاست API در پوشه خصوصی ممکن نشد.');
            bm_audit($auditFile,$user,'v22_security_settings',[
                 'limit'=>$next['limit_per_minute'],'emergency'=>$next['emergency_mode'],
                 'video_http'=>$next['http_video_fallback']]);
            $savedOk=true;
        } elseif (in_array($action, ['comment_approve','comment_reject','comment_delete','comment_pin','comment_unpin','comment_spoiler','comment_unspoiler'], true)) {
            $source = ((string)($_POST['comment_source'] ?? 'database') === 'archive1') ? 'archive1' : 'database';
            $table = $source === 'archive1' ? 'archive1_comments' : 'comments';
            $likes = $source === 'archive1' ? 'archive1_comment_likes' : 'comment_likes';
            $id = max(0, (int)($_POST['comment_id'] ?? 0));
            if ($id <= 0 || !bm_admin_table_exists($pdo, $table)) throw new RuntimeException('دیدگاه پیدا نشد.');
            $metaStmt=$pdo->prepare("SELECT user_id,movie_id FROM `{$table}` WHERE id=? LIMIT 1");
            $metaStmt->execute([$id]);
            $commentMeta=$metaStmt->fetch(PDO::FETCH_ASSOC)?:[];
            if ($action === 'comment_approve') {
                $pdo->prepare("UPDATE `{$table}` SET status='approved' WHERE id=?")->execute([$id]);
            } elseif ($action === 'comment_reject') {
                $pdo->prepare("UPDATE `{$table}` SET status='rejected' WHERE id=?")->execute([$id]);
            } elseif ($action === 'comment_pin' || $action === 'comment_unpin') {
                $pin = $action === 'comment_pin' ? 1 : 0;
                $pdo->prepare("UPDATE `{$table}` SET is_pinned=?,pinned_at=IF(?=1,NOW(),NULL) WHERE id=?")->execute([$pin,$pin,$id]);
            } elseif ($action === 'comment_spoiler' || $action === 'comment_unspoiler') {
                $spoiler = $action === 'comment_spoiler' ? 1 : 0;
                $pdo->prepare("UPDATE `{$table}` SET spoiler=? WHERE id=?")->execute([$spoiler,$id]);
            } else {
                $idsStmt = $pdo->prepare("SELECT id FROM `{$table}` WHERE id=? OR parent_id=?");
                $idsStmt->execute([$id,$id]);
                $ids = array_map('intval', $idsStmt->fetchAll(PDO::FETCH_COLUMN) ?: []);
                if ($ids && bm_admin_table_exists($pdo, $likes)) {
                    $marks = implode(',', array_fill(0, count($ids), '?'));
                    $pdo->prepare("DELETE FROM `{$likes}` WHERE comment_id IN ({$marks})")->execute($ids);
                }
                $pdo->prepare("DELETE FROM `{$table}` WHERE id=? OR parent_id=?")->execute([$id,$id]);
            }
            if ($action === 'comment_approve' || $action === 'comment_reject') {
                bm_site_comment_notify_status(
                    $pdo,(int)($commentMeta['user_id']??0),$source==='archive1'?1:2,
                    (int)($commentMeta['movie_id']??0),$id,$action==='comment_approve'?'approved':'rejected'
                );
            }
            bm_audit($auditFile, $user, $action, ['source'=>$source,'comment_id'=>$id]);
            $savedOk = true;
        } elseif (in_array($action,['comment_report_resolve','comment_report_reject'],true)) {
            $reportId=max(0,(int)($_POST['report_id']??0));
            if ($reportId<=0 || !bm_admin_table_exists($pdo,'comment_reports')) throw new RuntimeException('گزارش پیدا نشد.');
            $status=$action==='comment_report_resolve'?'resolved':'rejected';
            $pdo->prepare("UPDATE comment_reports SET status=?,reviewed_at=NOW(),reviewed_by=? WHERE id=?")->execute([$status,(int)($user['id']??0),$reportId]);
            bm_audit($auditFile,$user,$action,['report_id'=>$reportId]);
            $savedOk=true;
        } elseif ($action === 'send_push_notification') {
            $notificationTitle = trim((string)($_POST['push_title'] ?? 'پیام مدیریت بانک مووی'));
            $notificationMessage = trim((string)($_POST['push_message'] ?? ''));
            $notificationLink = trim((string)($_POST['push_link'] ?? ''));
            $expiresDays = max(1, min(7, (int)($_POST['push_expires_days'] ?? 7)));
            $notificationKind = (string)($_POST['push_kind'] ?? 'info');
            if (!in_array($notificationKind,['info','update','vip','channel','promo','content'],true)) $notificationKind='info';
            $audience=(string)($_POST['push_audience']??'all');
            if (!in_array($audience,['all','guest','member','vip','admin'],true)) $audience='all';
            $ctaLabel=mb_substr(trim((string)($_POST['push_cta_label']??'')),0,48,'UTF-8');
            $ctaUrl=trim((string)($_POST['push_cta_url']??''));
            $secondaryLabel=mb_substr(trim((string)($_POST['push_secondary_label']??'')),0,48,'UTF-8');
            $secondaryUrl=trim((string)($_POST['push_secondary_url']??''));
            $imageUrl=trim((string)($_POST['push_image_url']??''));
            foreach ([$ctaUrl,$secondaryUrl,$imageUrl] as $urlValue) {
                if ($urlValue!=='' && (!filter_var($urlValue,FILTER_VALIDATE_URL) || stripos($urlValue,'https://')!==0)) throw new RuntimeException('لینک‌ها و تصاویر باید HTTPS معتبر داشته باشند.');
            }
            if (($ctaLabel==='') !== ($ctaUrl==='')) throw new RuntimeException('متن و آدرس دکمه اصلی باید هر دو تکمیل شوند.');
            if (($secondaryLabel==='') !== ($secondaryUrl==='')) throw new RuntimeException('متن و آدرس دکمه دوم باید هر دو تکمیل شوند.');
            $iconMode=(string)($_POST['push_icon_mode']??'brand');
            if (!in_array($iconMode,['brand','svg'],true)) $iconMode='brand';
            $iconRaw=(string)($_POST['push_icon_svg']??'');
            if (!empty($_FILES['push_icon_file']['tmp_name']) && (int)($_FILES['push_icon_file']['error']??99)===UPLOAD_ERR_OK) {
                if ((int)($_FILES['push_icon_file']['size']??0)>40000) throw new RuntimeException('فایل SVG حداکثر ۴۰ کیلوبایت است.');
                $iconRaw=(string)file_get_contents((string)$_FILES['push_icon_file']['tmp_name']);
            }
            $iconSvg=$iconMode==='svg' ? bm_push_safe_svg($iconRaw) : '';
            if ($iconMode==='svg' && $iconSvg==='') throw new RuntimeException('برای آیکون سفارشی فایل SVG یا کد SVG لازم است.');
            $startRaw=trim((string)($_POST['push_starts_at']??''));
            $startsAt=null;
            if ($startRaw!=='') {
                $dt=DateTimeImmutable::createFromFormat('!Y-m-d\TH:i',$startRaw);
                if (!$dt) throw new RuntimeException('زمان آغاز معتبر نیست.');
                $startsAt=$dt->format('Y-m-d H:i:s');
            }
            $pushMeta=[
                'kind'=>$notificationKind,'audience'=>$audience,
                'cta_label'=>$ctaLabel,'cta_url'=>$ctaUrl,
                'secondary_label'=>$secondaryLabel,'secondary_url'=>$secondaryUrl,
                'image_url'=>$imageUrl,'icon_mode'=>$iconMode,'icon_svg'=>$iconSvg
            ];
            if ($notificationMessage === '') throw new RuntimeException('متن Push خالی است.');
            if ($notificationLink !== '' && !filter_var($notificationLink, FILTER_VALIDATE_URL)) throw new RuntimeException('لینک Push معتبر نیست.');
            bm_push_ensure_schema($pdo);
            bm_push_cleanup_expired($pdo);
            $expiresAt = date('Y-m-d H:i:s', time() + ($expiresDays * 86400));
            $safeTitle = mb_substr($notificationTitle !== '' ? $notificationTitle : 'پیام مدیریت بانک مووی', 0, 220, 'UTF-8');
            // Application-only storage: NEVER write BM Admin Push into website `notifications`.
            $notificationLink=$notificationLink!=='' ? $notificationLink : $ctaUrl;
            if ($startsAt!==null && strtotime($expiresAt) <= strtotime($startsAt)) throw new RuntimeException('انقضا باید بعد از زمان آغاز اعلان باشد.');
            $notificationId = bm_push_insert_v21($pdo, $safeTitle, $notificationMessage, $notificationLink, $expiresAt, $pushMeta, $startsAt);
            $isScheduled=$startsAt!==null && strtotime($startsAt)>time();
            $pushResult=$isScheduled ? ['ok'=>true,'configured'=>true,'message'=>'Scheduled'] : bm_fcm_send_topic($safeTitle, $notificationMessage, $notificationLink, $notificationId, $pushMeta);
            if (!$isScheduled) bm_push_mark_delivery($pdo, $notificationId, $pushResult);
            bm_audit($auditFile, $user, 'send_push_notification', [
                'push_id'=>$notificationId,
                'fcm_ok'=>!empty($pushResult['ok']),
                'fcm_configured'=>!empty($pushResult['configured'])
            ]);
            $savedOk = true;
            if (empty($pushResult['ok'])) {
                $saveError = !empty($pushResult['configured'])
                    ? 'Push ذخیره شد ولی FCM همان لحظه پاسخ موفق نداد؛ fallback داخل اپ فعال است.'
                    : 'Push ذخیره شد؛ FCM تنظیم نیست و fallback داخل اپ فعال است.';
            }
        } elseif ($action === 'delete_push_notification') {
            $pushId = max(0, (int)($_POST['push_id'] ?? 0));
            if ($pushId <= 0) throw new RuntimeException('شناسه Push نامعتبر است.');
            $deleted = bm_push_delete($pdo, $pushId);
            $revokeResult = function_exists('bm_fcm_send_revoke') ? bm_fcm_send_revoke($pushId) : ['ok'=>false];
            bm_audit($auditFile, $user, 'delete_push_notification', ['push_id'=>$pushId,'deleted'=>$deleted,'revoke_fcm_ok'=>!empty($revokeResult['ok'])]);
            $savedOk = true;
        } elseif ($action === 'resend_push_notification') {
            $pushId = max(0, (int)($_POST['push_id'] ?? 0));
            $row = bm_push_get($pdo, $pushId);
            if (!$row) throw new RuntimeException('Push پیدا نشد.');
            $title = trim((string)($row['title'] ?? 'پیام مدیریت بانک مووی'));
            $message = trim((string)($row['message'] ?? ''));
            $link = trim((string)($row['link'] ?? ''));
            if ($message === '') throw new RuntimeException('متن Push خالی است.');
            $pushResult = bm_fcm_send_topic($title, $message, $link, $pushId, bm_push_metadata($row));
            bm_push_mark_delivery($pdo, $pushId, $pushResult);
            bm_audit($auditFile, $user, 'resend_push_notification', ['push_id'=>$pushId,'fcm_ok'=>!empty($pushResult['ok'])]);
            $savedOk = true;
            if (empty($pushResult['ok'])) $saveError = 'ارسال مجدد FCM موفق نبود؛ رکورد برای fallback داخل اپ باقی ماند.';
        } elseif ($action === 'clear_push_notifications') {
            $deleted = bm_push_clear_all($pdo, true);
            $revokeResult = function_exists('bm_fcm_send_revoke_all') ? bm_fcm_send_revoke_all() : ['ok'=>false];
            bm_audit($auditFile, $user, 'clear_push_notifications', ['deleted'=>$deleted,'revoke_fcm_ok'=>!empty($revokeResult['ok'])]);
            $savedOk = true;
        } elseif ($action === 'cleanup_notifications') {
            // Manual safety button: purge legacy APP notification history/read/dismiss rows only.
            $gc = bm_push_legacy_cleanup($pdo, true, true);
            bm_audit($auditFile, $user, 'cleanup_legacy_notifications', ['deleted'=>$gc['deleted'] ?? []]);
            $savedOk = true;
        } elseif ($action === 'clear_archive3_cache') {
            $gc = function_exists('api6_cache_clear_all') ? api6_cache_clear_all() : ['deleted'=>0,'bytes'=>0];
            bm_audit($auditFile, $user, 'clear_archive3_cache', $gc);
            $savedOk = true;
            $saveNotice = 'کش آرشیو ۳ پاک شد: ' . (int)($gc['deleted'] ?? 0) . ' فایل.';
        } elseif ($action === 'block_13' || $action === 'unblock_13') {
            $blocked = array_map('strval', (array)($config['version_policy']['blocked_version_names'] ?? []));
            $blocked = array_values(array_unique(array_filter(array_map('trim', $blocked))));
            if ($action === 'block_13' && !in_array('1.3', $blocked, true)) $blocked[] = '1.3';
            if ($action === 'unblock_13') $blocked = array_values(array_filter($blocked, static fn($v) => $v !== '1.3'));
            $config['version_policy']['enabled'] = true;
            $config['version_policy']['blocked_version_names'] = $blocked;
            $config['updated_at'] = gmdate('c');
            bm_atomic_save($configFile, $config);
            bm_audit($auditFile, $user, $action, ['version' => '1.3']);
            $savedOk = true;
        } else {
            $servers = bm_parse_servers();
            $rewrites = bm_parse_rewrites();
            $firstEnabled = null;
            foreach ($servers as $server) {
                if (!empty($server['enabled'])) {
                    $firstEnabled = $server;
                    break;
                }
            }
            if (!$firstEnabled) throw new RuntimeException('سرور فعال پیدا نشد.');
            $activeDomain = (string)$firstEnabled['domain'];
            $apiUrl = (string)$firstEnabled['api_url'];
            $universal = bm_clean_url((string)($_POST['apk_universal'] ?? ''), true);
            $arm64 = bm_clean_url((string)($_POST['apk_arm64'] ?? ''), true);
            $v7a = bm_clean_url((string)($_POST['apk_v7a'] ?? ''), true);
            $fallback = $universal;

            $noticeMessage = trim((string)($_POST['notice_message'] ?? ''));
            $noticeId = trim((string)($_POST['notice_id'] ?? ''));
            if ($noticeMessage !== '' && $noticeId === '') $noticeId = 'notice_' . time();

            $versionName = trim((string)($_POST['version_name'] ?? '2.2'));
            if ($versionName === '') throw new RuntimeException('Version Name نمی‌تواند خالی باشد.');

            $archiveModes = [];
            $archiveAccessScopes = [];
            $archiveDownloadScopes = [];
            $archiveStreamScopes = [];
            $archiveDownloadLinkModes = [];
            $archiveDownloadClientModes = [];
            $archiveDownloadSourceModes = [];
            $archiveDownloadBaseUrls = [];
            $archiveSourceBaseUrls = [];
            $existingArchiveSettings = function_exists('bm_archive_get_settings') ? bm_archive_get_settings() : ['archives'=>[]];
            $downloadRedirectEnabled = bm_bool('download_redirect_enabled');
            $downloadModernClientOnly = bm_bool('download_modern_client_only');
            $archiveWatchPartyScopes = [];
            $archiveInternalPlayerScopes = [];
            $archiveExternalPlayerScopes = [];
            $archiveAllPlayerScopes = [];
            foreach ([1,2,3,4,5] as $archiveNumber) {
                $mode = strtolower(trim((string)($_POST['archive' . $archiveNumber . '_mode'] ?? 'enabled')));
                if (!in_array($mode, ['enabled','disabled','hidden'], true)) $mode = 'enabled';
                $archiveModes[$archiveNumber] = $mode;
                $accessScope = strtolower(trim((string)($_POST['archive' . $archiveNumber . '_access_scope'] ?? 'public')));
                $archiveAccessScopes[$archiveNumber] = in_array($accessScope, ['public','member','vip','admin'], true) ? $accessScope : 'public';
                $downloadScope = strtolower(trim((string)($_POST['archive' . $archiveNumber . '_download_scope'] ?? 'public')));
                $streamScope = strtolower(trim((string)($_POST['archive' . $archiveNumber . '_stream_scope'] ?? 'public')));
                $allowedScopes = ['public','member','vip','admin','disabled'];
                $archiveDownloadScopes[$archiveNumber] = in_array($downloadScope, $allowedScopes, true) ? $downloadScope : 'public';
                $archiveStreamScopes[$archiveNumber] = in_array($streamScope, $allowedScopes, true) ? $streamScope : 'public';
                $existingArchiveRow = is_array($existingArchiveSettings['archives']['archive'.$archiveNumber] ?? null) ? $existingArchiveSettings['archives']['archive'.$archiveNumber] : [];
                $downloadLinkMode = strtolower(trim((string)($_POST['archive'.$archiveNumber.'_download_link_mode'] ?? ($existingArchiveRow['download_link_mode'] ?? 'redirect'))));
                if (!in_array($downloadLinkMode, ['redirect','original','disabled'], true)) $downloadLinkMode = 'redirect';
                $downloadClientMode = strtolower(trim((string)($_POST['archive'.$archiveNumber.'_download_client_mode'] ?? ($existingArchiveRow['download_client_mode'] ?? 'adm_copy'))));
                if (!in_array($downloadClientMode, ['adm_copy','all','disabled'], true)) $downloadClientMode = 'adm_copy';
                $archiveDownloadLinkModes[$archiveNumber] = $downloadLinkMode;
                $archiveDownloadClientModes[$archiveNumber] = $downloadClientMode;
                if (in_array($archiveNumber, [3,4], true)) {
                    $sourceMode = strtolower(trim((string)($_POST['archive'.$archiveNumber.'_download_source_mode'] ?? ($existingArchiveRow['download_source_mode'] ?? ($archiveNumber === 4 ? 'vlc' : 'normal')))));
                    $archiveDownloadSourceModes[$archiveNumber] = in_array($sourceMode, ['normal','vlc'], true) ? $sourceMode : ($archiveNumber === 4 ? 'vlc' : 'normal');
                }

                $sourceField = 'archive' . $archiveNumber . '_source_base_url';
                $sourceRaw = array_key_exists($sourceField, $_POST)
                    ? (string)$_POST[$sourceField]
                    : (string)($existingArchiveRow['source_base_url'] ?? '');
                $archiveSourceBaseUrls[$archiveNumber] = function_exists('bm_archive_normalize_base_url')
                    ? bm_archive_normalize_base_url($sourceRaw, true)
                    : trim($sourceRaw);

                $downloadBasesField = 'archive' . $archiveNumber . '_download_base_urls';
                $downloadBasesRaw = array_key_exists($downloadBasesField, $_POST)
                    ? (string)$_POST[$downloadBasesField]
                    : (array)($existingArchiveRow['download_base_urls'] ?? ['https://dl10.bankmovie.top']);
                $archiveDownloadBaseUrls[$archiveNumber] = function_exists('bm_archive_normalize_url_list')
                    ? bm_archive_normalize_url_list($downloadBasesRaw, (array)($existingArchiveRow['download_base_urls'] ?? ['https://dl10.bankmovie.top']))
                    : (array)($existingArchiveRow['download_base_urls'] ?? ['https://dl10.bankmovie.top']);
                foreach ([
                    'watch_party' => 'vip',
                    'internal_player' => 'public',
                    'external_player' => 'public',
                    'all_players' => 'public',
                ] as $featureKey => $featureFallback) {
                    $field = 'archive' . $archiveNumber . '_' . $featureKey . '_scope';
                    $value = strtolower(trim((string)($_POST[$field] ?? $featureFallback)));
                    if (!in_array($value, $allowedScopes, true)) $value = $featureFallback;
                    if ($featureKey === 'watch_party') $archiveWatchPartyScopes[$archiveNumber] = $value;
                    elseif ($featureKey === 'internal_player') $archiveInternalPlayerScopes[$archiveNumber] = $value;
                    elseif ($featureKey === 'external_player') $archiveExternalPlayerScopes[$archiveNumber] = $value;
                    else $archiveAllPlayerScopes[$archiveNumber] = $value;
                }
            }

            // V7.36 verifier compatibility (legacy implementation marker only): 'enabled' => !empty($_POST['home_archive' . $arcNo . '_' . $sectionKey])
            // V7.43: fine-grained app section controls. Unknown/custom section
            // keys are preserved, while every known Home/archive rail gets an
            // explicit enable switch and an independent access scope.
            $homeSectionPolicy = is_array($config['home_section_policy'] ?? null) ? $config['home_section_policy'] : [];
            foreach (bm_app_home_section_catalog() as $sectionArchiveNumber => $sectionCatalog) {
                $archiveId = 'archive' . $sectionArchiveNumber;
                if (!isset($homeSectionPolicy[$archiveId]) || !is_array($homeSectionPolicy[$archiveId])) $homeSectionPolicy[$archiveId] = [];
                foreach ($sectionCatalog as $sectionKey => $_sectionLabel) {
                    $enabledField = 'section_archive' . $sectionArchiveNumber . '_' . $sectionKey . '_enabled';
                    $scopeField = 'section_archive' . $sectionArchiveNumber . '_' . $sectionKey . '_scope';
                    $sectionEnabled = isset($_POST[$enabledField]) && (string)$_POST[$enabledField] === '1';
                    $sectionScope = strtolower(trim((string)($_POST[$scopeField] ?? 'public')));
                    if (!in_array($sectionScope, ['public','member','vip','admin','disabled'], true)) $sectionScope = 'public';
                    // V7.43.1: choosing Disabled must remove the whole section from
                    // the app. VIP/member/admin remain visible access gates; only
                    // disabled is a true hard-hide state.
                    if ($sectionScope === 'disabled') $sectionEnabled = false;
                    $homeSectionPolicy[$archiveId][$sectionKey] = [
                        'enabled'=>$sectionEnabled,
                        'access_scope'=>$sectionScope,
                    ];
                }
            }

            $config = [
                'schema_version' => 6,
                'home_ad' => is_array($config['home_ad'] ?? null) ? $config['home_ad'] : [],
                'config_revision' => max(1,(int)($config['config_revision'] ?? 0)+1),
                'ready' => bm_bool('ready'),
                'message' => trim((string)($_POST['maintenance_message'] ?? 'اپ موقتاً در دسترس نیست.')),
                'active_domain' => $activeDomain,
                'api_url' => $apiUrl,
                'account_api_url' => rtrim($activeDomain, '/') . '/app_user_api.php',
                'account_api_urls' => array_values(array_unique(array_map(static fn($sv) => rtrim((string)($sv['domain']??''),'/').'/app_user_api.php', array_filter($servers, static fn($sv) => !empty($sv['enabled']))))),
                'servers' => $servers,
                'url_rewrites' => $rewrites,
                'features' => [
                    'registration_enabled'=>bm_bool('registration_enabled'),
                    'login_enabled'=>bm_bool('login_enabled'),
                    'comments_enabled'=>bm_bool('comments_enabled'),
                    'comment_replies_enabled'=>bm_bool('comment_replies_enabled'),
                    'comment_votes_enabled'=>bm_bool('comment_votes_enabled'),
                    'comment_reports_enabled'=>bm_bool('comment_reports_enabled'),
                    'comment_spoiler_enabled'=>bm_bool('comment_spoiler_enabled'),
                    'notification_center_enabled'=>bm_bool('notification_center_enabled'),
                    'internal_downloader_enabled'=>bm_bool('internal_downloader_enabled'),
                    'multipart_download_enabled'=>bm_bool('multipart_download_enabled'),
                    'download_path_selection_enabled'=>bm_bool('download_path_selection_enabled'),
                    'advanced_search_enabled'=>bm_bool('advanced_search_enabled'),
                    'categories_enabled'=>bm_bool('categories_enabled'),
                    'watchlist_enabled'=>bm_bool('watchlist_enabled'),
                    'continue_watching_enabled'=>bm_bool('continue_watching_enabled'),
                    'tv_quick_menu_enabled'=>bm_bool('tv_quick_menu_enabled'),
                    'profile_cleanup_enabled'=>bm_bool('profile_cleanup_enabled'),
                    'tv_detail_story_enabled'=>bm_bool('tv_detail_story_enabled'),
                    'tv_detail_more_info_enabled'=>bm_bool('tv_detail_more_info_enabled'),
                    'external_player_fallback_enabled'=>bm_bool('external_player_fallback_enabled'),
                    'search_auto_page_limit'=>max(1,min(10,(int)($_POST['search_auto_page_limit']??10))),
                    'login_poster_url'=>trim((string)($_POST['login_poster_url']??'')),
                    'download_limit'=>max(1,min(4,(int)($_POST['download_limit']??2))),
                    'archives'=>[
                        'archive1_enabled'=>$archiveModes[1] === 'enabled',
                        'archive1_hidden'=>$archiveModes[1] === 'hidden',
                        'archive1_download_vip'=>$archiveDownloadScopes[1] === 'vip',
                        'archive1_stream_vip'=>$archiveStreamScopes[1] === 'vip',
                        'archive2_enabled'=>$archiveModes[2] === 'enabled',
                        'archive2_hidden'=>$archiveModes[2] === 'hidden',
                        'archive2_download_vip'=>$archiveDownloadScopes[2] === 'vip',
                        'archive2_stream_vip'=>$archiveStreamScopes[2] === 'vip',
                        'archive3_enabled'=>$archiveModes[3] === 'enabled',
                        'archive3_hidden'=>$archiveModes[3] === 'hidden',
                        'archive3_download_vip'=>$archiveDownloadScopes[3] === 'vip',
                        'archive3_stream_vip'=>$archiveStreamScopes[3] === 'vip',
                        'archive4_enabled'=>$archiveModes[4] === 'enabled',
                        'archive4_hidden'=>$archiveModes[4] === 'hidden',
                        'archive4_download_vip'=>$archiveDownloadScopes[4] === 'vip',
                        'archive4_stream_vip'=>$archiveStreamScopes[4] === 'vip',
                        'archive5_enabled'=>$archiveModes[5] === 'enabled',
                        'archive5_hidden'=>$archiveModes[5] === 'hidden',
                        'archive5_download_vip'=>$archiveDownloadScopes[5] === 'vip',
                        'archive5_stream_vip'=>$archiveStreamScopes[5] === 'vip'
                    ]
                ],
                'app_archive_policy'=>[
                    'archive1'=>['enabled'=>$archiveModes[1] === 'enabled','hidden'=>$archiveModes[1] === 'hidden','access_scope'=>$archiveAccessScopes[1],'download_access_scope'=>$archiveDownloadScopes[1],'stream_access_scope'=>$archiveStreamScopes[1],'download_link_mode'=>$archiveDownloadLinkModes[1],'download_client_mode'=>$archiveDownloadClientModes[1],'watch_party_access_scope'=>$archiveWatchPartyScopes[1],'internal_player_access_scope'=>$archiveInternalPlayerScopes[1],'external_player_access_scope'=>$archiveExternalPlayerScopes[1],'all_players_access_scope'=>$archiveAllPlayerScopes[1]],
                    'archive2'=>['enabled'=>$archiveModes[2] === 'enabled','hidden'=>$archiveModes[2] === 'hidden','access_scope'=>$archiveAccessScopes[2],'download_access_scope'=>$archiveDownloadScopes[2],'stream_access_scope'=>$archiveStreamScopes[2],'download_link_mode'=>$archiveDownloadLinkModes[2],'download_client_mode'=>$archiveDownloadClientModes[2],'watch_party_access_scope'=>$archiveWatchPartyScopes[2],'internal_player_access_scope'=>$archiveInternalPlayerScopes[2],'external_player_access_scope'=>$archiveExternalPlayerScopes[2],'all_players_access_scope'=>$archiveAllPlayerScopes[2]],
                    'archive3'=>['enabled'=>$archiveModes[3] === 'enabled','hidden'=>$archiveModes[3] === 'hidden','access_scope'=>$archiveAccessScopes[3],'download_access_scope'=>$archiveDownloadScopes[3],'stream_access_scope'=>$archiveStreamScopes[3],'download_link_mode'=>$archiveDownloadLinkModes[3],'download_client_mode'=>$archiveDownloadClientModes[3],'watch_party_access_scope'=>$archiveWatchPartyScopes[3],'internal_player_access_scope'=>$archiveInternalPlayerScopes[3],'external_player_access_scope'=>$archiveExternalPlayerScopes[3],'all_players_access_scope'=>$archiveAllPlayerScopes[3]],
                    'archive4'=>['enabled'=>$archiveModes[4] === 'enabled','hidden'=>$archiveModes[4] === 'hidden','access_scope'=>$archiveAccessScopes[4],'download_access_scope'=>$archiveDownloadScopes[4],'stream_access_scope'=>$archiveStreamScopes[4],'download_link_mode'=>$archiveDownloadLinkModes[4],'download_client_mode'=>$archiveDownloadClientModes[4],'watch_party_access_scope'=>$archiveWatchPartyScopes[4],'internal_player_access_scope'=>$archiveInternalPlayerScopes[4],'external_player_access_scope'=>$archiveExternalPlayerScopes[4],'all_players_access_scope'=>$archiveAllPlayerScopes[4]],
                    'archive5'=>['enabled'=>$archiveModes[5] === 'enabled','hidden'=>$archiveModes[5] === 'hidden','access_scope'=>$archiveAccessScopes[5],'download_access_scope'=>$archiveDownloadScopes[5],'stream_access_scope'=>$archiveStreamScopes[5],'download_link_mode'=>$archiveDownloadLinkModes[5],'download_client_mode'=>$archiveDownloadClientModes[5],'watch_party_access_scope'=>$archiveWatchPartyScopes[5],'internal_player_access_scope'=>$archiveInternalPlayerScopes[5],'external_player_access_scope'=>$archiveExternalPlayerScopes[5],'all_players_access_scope'=>$archiveAllPlayerScopes[5]],
                ],
                'home_section_policy'=>$homeSectionPolicy,
                'comments'=>[
                    'edit_minutes'=>max(0,min(1440,(int)($_POST['comment_edit_minutes']??10))),
                    'rate_count'=>max(1,min(30,(int)($_POST['comment_rate_count']??3))),
                    'rate_minutes'=>max(1,min(1440,(int)($_POST['comment_rate_minutes']??10))),
                    'auto_approve_admin'=>bm_bool('comment_auto_approve_admin'),
                    'auto_approve_vip'=>bm_bool('comment_auto_approve_vip')
                ],
                'downloads'=>[
                    'concurrent_limit'=>max(1,min(4,(int)($_POST['download_limit']??2))),
                    'retry_count'=>max(0,min(12,(int)($_POST['download_retry_count']??4))),
                    'retry_delay_seconds'=>max(2,min(300,(int)($_POST['download_retry_delay_seconds']??8))),
                    'min_free_mb'=>max(32,min(8192,(int)($_POST['download_min_free_mb']??256))),
                    'multipart_parts'=>max(2,min(6,(int)($_POST['multipart_parts']??4))),
                    'redirect_enabled'=>$downloadRedirectEnabled,
                    'modern_client_only'=>$downloadModernClientOnly
                ],
                'home'=>[
                    'archive1_sections'=>bm_lines((string)($_POST['home_archive1_sections']??'')),
                    'archive2_sections'=>bm_lines((string)($_POST['home_archive2_sections']??'')),
                    'archive3_sections'=>bm_lines((string)($_POST['home_archive3_sections']??'')),
                    'archive4_sections'=>bm_lines((string)($_POST['home_archive4_sections']??'')),
                    'archive5_sections'=>bm_lines((string)($_POST['home_archive5_sections']??''))
                ],
                'ui'=>[
                    'display_year'=>max(0,min(2200,(int)($_POST['ui_display_year']??0))),
                    'search_max_year'=>max(0,min(2200,(int)($_POST['ui_search_max_year']??0))),
                    'text_overrides'=>[
                        'fa'=>bm_text_override_lines((string)($_POST['ui_text_overrides_fa']??'')),
                        'en'=>bm_text_override_lines((string)($_POST['ui_text_overrides_en']??''))
                    ]
                ],
                'notice' => [
                    'enabled' => bm_bool('notice_enabled'),
                    'id' => $noticeId,
                    'type' => in_array((string)($_POST['notice_type'] ?? 'admin'), ['admin','system','update','maintenance'], true) ? (string)$_POST['notice_type'] : 'admin',
                    'title' => trim((string)($_POST['notice_title'] ?? '')),
                    'message' => $noticeMessage,
                    'dismissible' => bm_bool('notice_dismissible'),
                    'target' => ['url'=>trim((string)($_POST['notice_target_url'] ?? ''))]
                ],
                'social' => (static function (): array {
                    $baleEnabled = bm_bool('bale_enabled');
                    $baleChannelUrl = bm_clean_url((string)($_POST['bale_channel_url'] ?? ''), true);
                    $balePurchaseUrl = bm_clean_url((string)($_POST['bale_purchase_url'] ?? ''), true);
                    $emergency = strtolower(trim((string)($_POST['emergency_channel'] ?? 'telegram')));
                    $purchaseProvider = strtolower(trim((string)($_POST['vip_purchase_provider'] ?? 'telegram')));
                    if (!$baleEnabled || $baleChannelUrl === '') $emergency = 'telegram';
                    if (!$baleEnabled || $balePurchaseUrl === '') $purchaseProvider = 'telegram';
                    if (!in_array($emergency, ['telegram','bale'], true)) $emergency = 'telegram';
                    if (!in_array($purchaseProvider, ['telegram','bale'], true)) $purchaseProvider = 'telegram';
                    return [
                        'bale_enabled'=>$baleEnabled,
                        'bale_channel_url'=>$baleChannelUrl,
                        'bale_purchase_url'=>$balePurchaseUrl,
                        'emergency_channel'=>$emergency,
                        'vip_purchase_provider'=>$purchaseProvider,
                    ];
                })(),
                'update' => [
                    'enabled' => bm_bool('update_enabled'),
                    'version_code' => max(0, (int)($_POST['version_code'] ?? 0)),
                    'version_name' => $versionName,
                    'apk_url' => $fallback,
                    'apk_urls' => [
                        'universal' => $universal,
                        'arm64_v8a' => $arm64,
                        'armeabi_v7a' => $v7a
                    ],
                    'force' => bm_bool('force_update'),
                    'title' => trim((string)($_POST['update_title'] ?? 'آپدیت جدید آماده است')),
                    'message' => trim((string)($_POST['update_message'] ?? 'نسخه جدید Bankmovie آماده دانلود است.')),
                    'changes' => bm_lines((string)($_POST['changes'] ?? ''))
                ],
                'version_policy' => [
                    'enabled' => bm_bool('version_policy_enabled'),
                    'minimum_version_code' => max(0, (int)($_POST['minimum_version_code'] ?? 0)),
                    'minimum_version_name' => trim((string)($_POST['minimum_version_name'] ?? '')),
                    'blocked_version_names' => bm_lines((string)($_POST['blocked_version_names'] ?? '')),
                    'blocked_version_codes' => bm_int_lines((string)($_POST['blocked_version_codes'] ?? '')),
                    'force_update_blocked' => bm_bool('force_update_blocked'),
                    'latest_version_only' => bm_bool('latest_version_only'),
                    'block_message' => trim((string)($_POST['block_message'] ?? 'این نسخه از Bankmovie غیرفعال شده است. برای ادامه نسخه جدید را نصب کنید.'))
                ],
                'updated_at' => gmdate('c')
            ];

            bm_atomic_save($configFile, $config);
            // Keep the website policy and the app Remote Config on one source
            // of truth. app_config.php publishes these scopes to every client.
            $archiveSettings = bm_archive_get_settings();
            foreach ([1,2,3,4,5] as $archiveNumber) {
                $archiveId = 'archive' . $archiveNumber;
                $oldArchive = is_array($archiveSettings['archives'][$archiveId] ?? null) ? $archiveSettings['archives'][$archiveId] : [];
                $archiveSettings['archives'][$archiveId] = array_merge($oldArchive, [
                    'enabled'=>$archiveModes[$archiveNumber] === 'enabled',
                    // Website audience was never written here: VIP/member stayed public.
                    'access_scope'=>$archiveAccessScopes[$archiveNumber],
                    'disabled_mode'=>$archiveModes[$archiveNumber] === 'hidden' ? 'hide' : 'visible',
                    'download_access_scope'=>$archiveDownloadScopes[$archiveNumber],
                    'stream_access_scope'=>$archiveStreamScopes[$archiveNumber],
                    'download_link_mode'=>$archiveDownloadLinkModes[$archiveNumber],
                    'download_client_mode'=>$archiveDownloadClientModes[$archiveNumber],
                    'source_base_url'=>$archiveSourceBaseUrls[$archiveNumber],
                    'download_base_urls'=>$archiveDownloadBaseUrls[$archiveNumber],
                ]);
                if (in_array($archiveNumber, [3,4], true)) {
                    $archiveSettings['archives'][$archiveId]['download_source_mode'] = $archiveDownloadSourceModes[$archiveNumber];
                }
            }
            // V11: seven-archive order is controlled in THIS existing BM Admin form.
            // Archive 6/7 remain site-managed only; older app clients keep their
            // original five-archive configuration and are never force-migrated.
            if (isset($_POST['bm_v11_archive_order_enabled'])) {
                $archiveSettings['archive_order'] = bm_archive_order_from_post($_POST, bm_archive_order(), 'flat');
                foreach ([6,7] as $siteArchiveNumber) {
                    $id = 'archive' . $siteArchiveNumber;
                    $row = (array)($archiveSettings['archives'][$id] ?? []);
                    $prefix = 'bm_v11_' . $id . '_';
                    $enabled = (string)($_POST[$prefix . 'state'] ?? 'off');
                    $scope = (string)($_POST[$prefix . 'scope'] ?? ($row['access_scope'] ?? 'admin'));
                    $downloadScope = (string)($_POST[$prefix . 'download'] ?? ($row['download_access_scope'] ?? 'public'));
                    $streamScope = (string)($_POST[$prefix . 'stream'] ?? ($row['stream_access_scope'] ?? 'public'));
                    $linkMode = (string)($_POST[$prefix . 'link'] ?? ($row['download_link_mode'] ?? 'original'));
                    $allowed = ['public','member','vip','admin','disabled'];
                    $row['enabled'] = $enabled === 'on';
                    $row['disabled_mode'] = $enabled === 'hide' ? 'hide' : 'visible';
                    $row['access_scope'] = $id === 'archive7' ? 'admin' : (in_array($scope, $allowed, true) ? $scope : 'admin');
                    $row['download_access_scope'] = in_array($downloadScope, $allowed, true) ? $downloadScope : 'public';
                    $row['stream_access_scope'] = in_array($streamScope, $allowed, true) ? $streamScope : 'public';
                    $row['download_link_mode'] = $id === 'archive7' ? 'original' : (in_array($linkMode, ['original','redirect','disabled'], true) ? $linkMode : 'original');
                    $archiveSettings['archives'][$id] = $row;
                }
            }
            $archiveSettings['download_redirect_enabled'] = $downloadRedirectEnabled;
            $archiveSettings['download_modern_client_only'] = $downloadModernClientOnly;
            if (!bm_archive_save_settings($archiveSettings)) throw new RuntimeException('ذخیره سیاست یکپارچه آرشیوها ناموفق بود.');
            if (!bm_admin_sync_app_archive_policies($archiveSettings, ['archive1','archive2','archive3','archive4','archive5'])) {
                throw new RuntimeException('سیاست سایت ذخیره شد، اما همگام‌سازی سیاست ورود/VIP اپ ناموفق بود. فایل bankmovie_remote_config.json را بررسی کنید.');
            }
            if (isset($_POST['bm_v11_watchlist_quota'])) {
                $quota = filter_var($_POST['bm_v11_watchlist_quota'], FILTER_VALIDATE_INT,
                    ['options'=>['min_range'=>1, 'max_range'=>500]]);
                if ($quota === false) throw new RuntimeException('سقف واچ‌لیست باید بین ۱ و ۵۰۰ باشد.');
                $siteSettings = bm_site_settings();
                $siteSettings['watchlist_free_limit'] = $quota;
                if (!bm_site_write_settings_file($siteSettings)) throw new RuntimeException('سقف واچ‌لیست ذخیره نشد.');
                bm_site_settings(true);
            }
            bm_audit($auditFile, $user, 'save_config', [
                'version_name' => $versionName,
                'update_enabled' => $config['update']['enabled'],
                'blocked_versions' => $config['version_policy']['blocked_version_names'],
                'server_count' => count($servers),
                'rewrite_count' => count($rewrites)
            ]);
            $savedOk = true;
        }
        $config = bm_load_config($configFile);
    } catch (Throwable $e) {
        $saveError = $e->getMessage();
    }
}

$changesText = implode("\n", (array)($config['update']['changes'] ?? []));
$homeArchive1Text = implode("\n", array_map('strval', (array)($config['home']['archive1_sections'] ?? [])));
$homeArchive2Text = implode("\n", array_map('strval', (array)($config['home']['archive2_sections'] ?? [])));
$homeArchive3Text = implode("\n", array_map('strval', (array)($config['home']['archive3_sections'] ?? [])));
$homeArchive4Text = implode("\n", array_map('strval', (array)($config['home']['archive4_sections'] ?? [])));
$homeArchive5Text = implode("\n", array_map('strval', (array)($config['home']['archive5_sections'] ?? [])));
$blockedNamesText = implode("\n", array_map('strval', (array)($config['version_policy']['blocked_version_names'] ?? [])));
$blockedCodesText = implode("\n", array_map('strval', (array)($config['version_policy']['blocked_version_codes'] ?? [])));
$uiTextOverridesFa = bm_text_override_dump((array)($config['ui']['text_overrides']['fa'] ?? []));
$uiTextOverridesEn = bm_text_override_dump((array)($config['ui']['text_overrides']['en'] ?? []));
$servers = array_values((array)($config['servers'] ?? []));
if (!$servers) {
    $servers = [[
        'name' => 'سرور اصلی',
        'enabled' => true,
        'priority' => 1,
        'domain' => (string)($config['active_domain'] ?? 'https://bankmovie.top'),
        'api_url' => (string)($config['api_url'] ?? 'https://bankmovie.top/app_api.php')
    ]];
}
$rewrites = array_values((array)($config['url_rewrites'] ?? []));
$audits = bm_last_audits($auditFile);
$adminName = $user['username'] ?? $user['email'] ?? 'admin';
$blocked13 = in_array('1.3', (array)($config['version_policy']['blocked_version_names'] ?? []), true);
$bmFcmStatus = function_exists('bm_fcm_config_status') ? bm_fcm_config_status() : ['ready'=>false,'message'=>'FCM helper پیدا نشد'];
$bmPushRows = [];
$bmPushCount = 0;
try {
    bm_push_ensure_schema($pdo);
    bm_push_cleanup_expired($pdo);
    $bmPushRows = bm_push_list($pdo, 30);
    $bmPushCount = bm_admin_table_exists($pdo, 'app_push_notifications') ? (int)$pdo->query('SELECT COUNT(*) FROM app_push_notifications')->fetchColumn() : 0;
} catch (Throwable $ignored) {}
if (!function_exists('bm_admin_comment_movie_url')) {
    function bm_admin_comment_movie_url(array $comment): string {
        $localId = (int)($comment['local_movie_id'] ?? 0);
        if ($localId > 0) {
            if (function_exists('bm_movie_url')) {
                return bm_movie_url([
                    'id' => $localId,
                    'title' => $comment['movie_title_en'] ?? ($comment['movie_title'] ?? 'movie')
                ]) . '#bmMovieComments';
            }
            $imdb = trim((string)($comment['movie_imdb'] ?? ''));
            if ($imdb !== '') return '/movie.php?imdb=' . rawurlencode($imdb) . '#bmMovieComments';
        }
        $archiveNo = (int)($comment['archive_no'] ?? 0);
        $slug = trim((string)($comment['archive_slug'] ?? ''));
        $type = trim((string)($comment['archive_type'] ?? ''));
        if ($archiveNo > 0 && $slug !== '') {
            return '/movie.php?arc=' . $archiveNo . '&slug=' . rawurlencode($slug)
                . ($type !== '' ? '&type=' . rawurlencode($type) : '') . '#bmMovieComments';
        }
        return '';
    }
}
$bmPendingComments = [];
try {
    $parts = [];
    $bmHasArchiveItems = bm_admin_table_exists($pdo, 'archive1_items');
    $legacyJoin = $bmHasArchiveItems ? " LEFT JOIN archive1_items ai ON ai.virtual_movie_id=c.movie_id " : " ";
    $legacyTitle = $bmHasArchiveItems ? "NULLIF(ai.item_title_fa,''),NULLIF(ai.item_title,'')," : "";
    $legacyArchiveNo = $bmHasArchiveItems ? "COALESCE(ai.archive_no,0)" : "0";
    $legacyArchiveSlug = $bmHasArchiveItems ? "COALESCE(ai.slug,'')" : "''";
    $legacyArchiveType = $bmHasArchiveItems ? "COALESCE(ai.item_type,'')" : "''";
    if (bm_admin_table_exists($pdo, 'comments')) {
        $parts[] = "SELECT c.id,c.comment,c.created_at,c.username,
                           COALESCE(u.username,c.username,'کاربر') user_name,
                           'database' comment_source,
                           COALESCE(NULLIF(m.title_fa,''),NULLIF(m.title,''),{$legacyTitle}'محتوای مرتبط') movie_title,
                           m.id local_movie_id,m.title movie_title_en,m.imdb_code movie_imdb,
                           {$legacyArchiveNo} archive_no,{$legacyArchiveSlug} archive_slug,{$legacyArchiveType} archive_type
                    FROM comments c
                    LEFT JOIN users u ON u.id=c.user_id
                    LEFT JOIN movies m ON m.id=c.movie_id
                    {$legacyJoin}
                    WHERE c.status='pending'";
    }
    if (bm_admin_table_exists($pdo, 'archive1_comments')) {
        $join = bm_admin_table_exists($pdo, 'archive1_items') ? " LEFT JOIN archive1_items ai ON ai.virtual_movie_id=c.movie_id " : " ";
        $title = bm_admin_table_exists($pdo, 'archive1_items')
            ? "COALESCE(NULLIF(ai.item_title_fa,''),NULLIF(ai.item_title,''),'محتوای آرشیو')"
            : "'محتوای آرشیو'";
        $archiveNo = bm_admin_table_exists($pdo, 'archive1_items') ? "COALESCE(ai.archive_no,1)" : "1";
        $archiveSlug = bm_admin_table_exists($pdo, 'archive1_items') ? "COALESCE(ai.slug,'')" : "''";
        $archiveType = bm_admin_table_exists($pdo, 'archive1_items') ? "COALESCE(ai.item_type,'')" : "''";
        $parts[] = "SELECT c.id,c.comment,c.created_at,c.username,
                           COALESCE(u.username,c.username,'کاربر') user_name,
                           'archive1' comment_source,{$title} movie_title,
                           0 local_movie_id,'' movie_title_en,'' movie_imdb,
                           {$archiveNo} archive_no,{$archiveSlug} archive_slug,{$archiveType} archive_type
                    FROM archive1_comments c {$join}
                    LEFT JOIN users u ON u.id=c.user_id
                    WHERE c.status='pending'";
    }
    if ($parts) {
        $bmPendingComments = $pdo->query("SELECT * FROM (" . implode(' UNION ALL ', $parts) . ") q ORDER BY created_at DESC,id DESC LIMIT 40")->fetchAll(PDO::FETCH_ASSOC) ?: [];
        foreach ($bmPendingComments as &$comment) $comment['movie_url'] = bm_admin_comment_movie_url($comment);
        unset($comment);
    }
} catch (Throwable $e) {
    $saveError = $saveError !== '' ? $saveError : ('خطا در دریافت دیدگاه‌ها: ' . $e->getMessage());
}
$bmRecentComments=[];
$bmOpenCommentReports=[];
try {
    $parts=[];
    $bmHasArchiveItems = bm_admin_table_exists($pdo, 'archive1_items');
    $legacyJoin = $bmHasArchiveItems ? " LEFT JOIN archive1_items ai ON ai.virtual_movie_id=c.movie_id " : " ";
    $legacyTitle = $bmHasArchiveItems ? "NULLIF(ai.item_title_fa,''),NULLIF(ai.item_title,'')," : "";
    $legacyArchiveNo = $bmHasArchiveItems ? "COALESCE(ai.archive_no,0)" : "0";
    $legacyArchiveSlug = $bmHasArchiveItems ? "COALESCE(ai.slug,'')" : "''";
    $legacyArchiveType = $bmHasArchiveItems ? "COALESCE(ai.item_type,'')" : "''";
    if (bm_admin_table_exists($pdo,'comments')) {
        $parts[]="SELECT c.id,c.comment,c.created_at,c.is_pinned,c.spoiler,
                         COALESCE(u.username,c.username,'کاربر') user_name,
                         'database' comment_source,
                         COALESCE(NULLIF(m.title_fa,''),NULLIF(m.title,''),{$legacyTitle}'محتوای مرتبط') movie_title,
                         m.id local_movie_id,m.title movie_title_en,m.imdb_code movie_imdb,
                         {$legacyArchiveNo} archive_no,{$legacyArchiveSlug} archive_slug,{$legacyArchiveType} archive_type
                  FROM comments c
                  LEFT JOIN users u ON u.id=c.user_id
                  LEFT JOIN movies m ON m.id=c.movie_id
                  {$legacyJoin}
                  WHERE LOWER(TRIM(CAST(c.status AS CHAR))) IN ('approved','active','1')";
    }
    if (bm_admin_table_exists($pdo,'archive1_comments')) {
        $join=bm_admin_table_exists($pdo,'archive1_items')?" LEFT JOIN archive1_items ai ON ai.virtual_movie_id=c.movie_id ":" ";
        $title=bm_admin_table_exists($pdo,'archive1_items')?"COALESCE(NULLIF(ai.item_title_fa,''),NULLIF(ai.item_title,''),'محتوای آرشیو')":"'محتوای آرشیو'";
        $archiveNo=bm_admin_table_exists($pdo,'archive1_items')?"COALESCE(ai.archive_no,1)":"1";
        $archiveSlug=bm_admin_table_exists($pdo,'archive1_items')?"COALESCE(ai.slug,'')":"''";
        $archiveType=bm_admin_table_exists($pdo,'archive1_items')?"COALESCE(ai.item_type,'')":"''";
        $parts[]="SELECT c.id,c.comment,c.created_at,c.is_pinned,c.spoiler,
                         COALESCE(u.username,c.username,'کاربر') user_name,
                         'archive1' comment_source,{$title} movie_title,
                         0 local_movie_id,'' movie_title_en,'' movie_imdb,
                         {$archiveNo} archive_no,{$archiveSlug} archive_slug,{$archiveType} archive_type
                  FROM archive1_comments c {$join}
                  LEFT JOIN users u ON u.id=c.user_id
                  WHERE LOWER(TRIM(CAST(c.status AS CHAR))) IN ('approved','active','1')";
    }
    if($parts){
        $bmRecentComments=$pdo->query("SELECT * FROM (".implode(' UNION ALL ',$parts).") q ORDER BY created_at DESC,id DESC LIMIT 30")->fetchAll(PDO::FETCH_ASSOC)?:[];
        foreach($bmRecentComments as &$comment) $comment['movie_url']=bm_admin_comment_movie_url($comment);
        unset($comment);
    }
    if(bm_admin_table_exists($pdo,'comment_reports')){
        $bmOpenCommentReports=$pdo->query("SELECT r.*,COALESCE(u.username,u.email,CONCAT('کاربر #',r.reporter_user_id)) reporter_name FROM comment_reports r LEFT JOIN users u ON u.id=r.reporter_user_id WHERE r.status='open' ORDER BY r.created_at DESC LIMIT 40")->fetchAll(PDO::FETCH_ASSOC)?:[];
    }
} catch(Throwable $e){$saveError=$saveError!==''?$saveError:('خطا در مدیریت گزارش دیدگاه: '.$e->getMessage());}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>BM Admin — مدیریت اپ</title>
<style>
:root{
  --bg:#070910;--surface:#0d111b;--surface-2:#121827;--surface-3:#171e2f;
  --line:rgba(255,255,255,.09);--line-strong:rgba(255,255,255,.15);
  --text:#f8fafc;--muted:#98a6bd;--accent:#8b5cf6;--accent-2:#6d4aff;
  --accent-soft:rgba(139,92,246,.14);--green:#22c55e;--red:#ef4444;--amber:#f59e0b;
  --shadow:0 18px 60px rgba(0,0,0,.28);--radius:22px;
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;min-height:100vh;background:
  radial-gradient(circle at 80% -10%,rgba(139,92,246,.18),transparent 28%),
  radial-gradient(circle at 8% 18%,rgba(37,99,235,.10),transparent 24%),
  linear-gradient(180deg,#06080e 0%,#090d16 48%,#070a12 100%);
  color:var(--text);font-family:Tahoma,"Segoe UI",Arial,sans-serif;line-height:1.65}
button,input,textarea,select{font-family:inherit}
a{color:inherit}
::selection{background:rgba(139,92,246,.35)}

.admin-shell{width:min(1500px,100%);margin:0 auto;padding:20px;display:grid;grid-template-columns:250px minmax(0,1fr);gap:20px;align-items:start}
.sidebar{position:sticky;top:20px;height:calc(100vh - 40px);display:flex;flex-direction:column;background:rgba(12,16,26,.88);border:1px solid var(--line);border-radius:26px;padding:18px;box-shadow:var(--shadow);backdrop-filter:blur(18px);overflow:hidden}
.brand{display:flex;align-items:center;gap:12px;padding:4px 3px 18px;border-bottom:1px solid var(--line);margin-bottom:14px}
.brand-logo{width:44px;height:44px;border-radius:15px;display:grid;place-items:center;background:linear-gradient(135deg,var(--accent),#4f46e5);box-shadow:0 10px 28px rgba(139,92,246,.3);font-size:22px}
.brand-title{font-weight:900;font-size:15px}.brand-subtitle{font-size:11px;color:var(--muted);margin-top:2px}
.sidebar-nav{display:grid;gap:5px;overflow:auto;padding-left:3px;scrollbar-width:thin}
.sidebar-nav a{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:13px;text-decoration:none;color:#c7d0df;font-size:12px;font-weight:800;border:1px solid transparent;transition:.18s ease}
.sidebar-nav a:hover,.sidebar-nav a:focus,.sidebar-nav a.active{background:var(--accent-soft);border-color:rgba(139,92,246,.26);color:#fff;transform:translateX(-2px)}
.nav-icon{width:24px;text-align:center;font-size:15px}
.sidebar-footer{margin-top:auto;border-top:1px solid var(--line);padding-top:14px;display:grid;gap:8px}
.sidebar-footer a{display:flex;justify-content:center;text-decoration:none;padding:10px 12px;border:1px solid var(--line);border-radius:13px;font-size:12px;font-weight:900;background:rgba(255,255,255,.035)}
.sidebar-footer a.logout{color:#ffc2c2;border-color:rgba(239,68,68,.22);background:rgba(239,68,68,.08)}
.content{min-width:0}.wrap{max-width:none;margin:0;padding:0}

.top{display:flex;justify-content:space-between;align-items:center;gap:18px;flex-wrap:wrap;background:rgba(13,17,27,.72);border:1px solid var(--line);border-radius:24px;padding:18px 20px;margin-bottom:14px;backdrop-filter:blur(14px)}
.title-wrap{display:flex;align-items:center;gap:13px}.title-mark{width:46px;height:46px;border-radius:16px;background:var(--accent-soft);border:1px solid rgba(139,92,246,.28);display:grid;place-items:center;font-size:22px}
.top h1{font-size:22px;line-height:1.35;margin:0}.top p{margin:3px 0 0;color:var(--muted);font-size:12px}
.badge-row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.badge,.badge-row a{padding:9px 12px;border:1px solid var(--line);background:rgba(255,255,255,.04);border-radius:12px;color:#dbe8ff;text-decoration:none;font-size:11px;font-weight:900}
.badge{background:rgba(34,197,94,.08);border-color:rgba(34,197,94,.22);color:#c8fbd9}

.ok,.err{border-radius:16px;padding:13px 15px;margin-bottom:14px;font-size:13px;font-weight:800}.ok{background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.35);color:#c9ffdc}.err{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.35);color:#ffd0d0}
.note{color:var(--muted);font-size:12px;line-height:1.9;padding:12px 14px;border:1px solid var(--line);background:rgba(255,255,255,.025);border-radius:14px}.security{border-color:rgba(34,197,94,.24);background:rgba(34,197,94,.055);color:#bfe9cd;margin-bottom:14px}
.dashboard{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:14px}
.stat{position:relative;overflow:hidden;background:linear-gradient(145deg,rgba(19,25,39,.96),rgba(10,14,23,.97));border:1px solid var(--line);border-radius:19px;padding:15px 16px;min-height:92px;box-shadow:0 12px 34px rgba(0,0,0,.16)}
.stat:after{content:"";position:absolute;inset:auto -18px -30px auto;width:75px;height:75px;border-radius:50%;background:var(--accent-soft)}
.stat small{display:block;color:var(--muted);font-size:11px;font-weight:800}.stat b{display:block;font-size:18px;margin-top:8px;position:relative;z-index:1}

.split{display:grid;grid-template-columns:minmax(0,1.48fr) minmax(320px,.72fr);gap:16px;align-items:start}
.card{background:linear-gradient(145deg,rgba(16,21,33,.96),rgba(9,13,22,.97));border:1px solid var(--line);border-radius:var(--radius);padding:18px;margin-bottom:14px;box-shadow:0 14px 44px rgba(0,0,0,.2)}
form.card{padding:14px;background:rgba(10,14,23,.72)}
.panel-section{position:relative;background:linear-gradient(145deg,rgba(19,25,39,.92),rgba(11,15,25,.94));border:1px solid var(--line);border-radius:18px;padding:18px;margin-bottom:12px;overflow:hidden}
.panel-section:before{content:"";position:absolute;top:0;right:0;width:4px;height:54px;border-radius:0 0 0 5px;background:linear-gradient(180deg,var(--accent),transparent)}
.section-heading{display:flex;align-items:center;gap:10px;margin-bottom:13px}.section-icon{width:34px;height:34px;border-radius:11px;display:grid;place-items:center;background:var(--accent-soft);border:1px solid rgba(139,92,246,.22);font-size:16px}
h2{font-size:16px;margin:0;color:#f8fbff}h3{font-size:15px;margin:0;color:#f2efff}.desc{color:var(--muted);font-size:12px;line-height:1.85;margin:6px 0 13px}
.section-divider{height:1px;background:var(--line);margin:15px 0}

.row{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:11px}.row3{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:11px}
label{display:block;margin:11px 0 6px;color:#d5deec;font-size:12px;font-weight:900}
input,textarea,select{width:100%;border-radius:12px;border:1px solid var(--line-strong);background:rgba(5,9,16,.86);color:#fff;padding:11px 12px;font-size:13px;outline:none;transition:border-color .18s ease,box-shadow .18s ease,background .18s ease}
input:hover,textarea:hover,select:hover{border-color:rgba(255,255,255,.22)}
input:focus,textarea:focus,select:focus{border-color:rgba(139,92,246,.8);box-shadow:0 0 0 3px rgba(139,92,246,.13);background:#080c15}
textarea{min-height:96px;resize:vertical}select{cursor:pointer}
.checks{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin:13px 0}
.chk{display:flex;align-items:center;gap:9px;margin:0;border:1px solid var(--line);background:rgba(255,255,255,.028);border-radius:12px;padding:10px 11px;font-size:11px;font-weight:900;cursor:pointer;min-height:42px;transition:.18s ease}
.chk:hover{background:rgba(139,92,246,.07);border-color:rgba(139,92,246,.22)}.chk input{width:17px;height:17px;margin:0;accent-color:var(--accent);flex:0 0 auto}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;border:1px solid rgba(139,92,246,.22);border-radius:12px;padding:10px 15px;background:linear-gradient(135deg,var(--accent),var(--accent-2));color:#fff;font-size:12px;font-weight:900;cursor:pointer;text-decoration:none;box-shadow:0 8px 24px rgba(109,74,255,.18);transition:.18s ease}
.btn:hover{transform:translateY(-1px);filter:brightness(1.07)}.btn:active{transform:translateY(0)}
.btn.red{background:linear-gradient(135deg,#ef4444,#b42335);border-color:rgba(239,68,68,.25);box-shadow:none}.btn.green{background:linear-gradient(135deg,#22c55e,#15803d);border-color:rgba(34,197,94,.25);box-shadow:none}
.quick{display:flex;gap:8px;flex-wrap:wrap}.quick form{margin:0}.quick .btn{padding:8px 11px;font-size:11px}
.save-bar{position:sticky;bottom:12px;z-index:12;display:flex;justify-content:flex-start;align-items:center;gap:10px;padding:11px 12px;margin-top:12px;background:rgba(10,14,23,.9);border:1px solid var(--line-strong);border-radius:16px;backdrop-filter:blur(16px);box-shadow:0 14px 38px rgba(0,0,0,.32)}.save-bar .btn{min-width:190px;padding:12px 18px}.save-hint{font-size:11px;color:var(--muted)}

.server-list,.rewrite-list{display:grid;gap:9px}.server-row,.rewrite-row{border:1px solid var(--line);background:rgba(255,255,255,.02);border-radius:15px;padding:12px}
.server-grid{display:grid;grid-template-columns:1.05fr 1.55fr 1.75fr .55fr;gap:8px;align-items:end}.rewrite-grid{display:grid;grid-template-columns:1.3fr 1.3fr .85fr;gap:8px;align-items:end}
.mini-actions{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-top:8px}.remove-row{border:1px solid rgba(239,68,68,.22);background:rgba(239,68,68,.08);color:#ffc3c3;border-radius:11px;padding:8px 11px;cursor:pointer;font-size:11px;font-weight:900}.add-row{border:1px dashed rgba(139,92,246,.5);background:rgba(139,92,246,.065);color:#eadfff;border-radius:13px;padding:10px 13px;cursor:pointer;font-size:12px;font-weight:900;margin-top:8px;width:100%}
.audit{display:grid;gap:8px}.audit-item{padding:12px 13px;border:1px solid var(--line);background:rgba(255,255,255,.025);border-radius:14px;font-size:12px;color:#d4ddec}.comment-item{margin-bottom:9px;line-height:1.85}.comment-item b{font-size:13px;color:#fff}.comment-item small{display:block;color:#8f9db2!important;margin-top:2px}.comment-item .quick{padding-top:8px;border-top:1px solid var(--line);margin-top:9px}

@media(max-width:1180px){.admin-shell{grid-template-columns:220px minmax(0,1fr)}.checks{grid-template-columns:repeat(2,minmax(0,1fr))}.split{grid-template-columns:1fr}.sidebar{height:auto;max-height:calc(100vh - 40px)}}
@media(max-width:860px){.admin-shell{display:block;padding:10px}.sidebar{position:relative;top:auto;height:auto;max-height:none;margin-bottom:12px;padding:12px;border-radius:18px}.brand{padding-bottom:12px;margin-bottom:10px}.sidebar-nav{display:flex;overflow-x:auto;padding-bottom:3px}.sidebar-nav a{white-space:nowrap;flex:0 0 auto}.sidebar-footer{grid-template-columns:1fr 1fr;margin-top:10px}.top{border-radius:18px;padding:15px}.dashboard{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:680px){.row,.row3,.server-grid,.rewrite-grid,.checks{grid-template-columns:1fr}.section-control-row{grid-template-columns:1fr!important}.section-control-row select{width:100%}.dashboard{grid-template-columns:1fr 1fr}.card{border-radius:18px;padding:13px}.panel-section{padding:15px;border-radius:15px}.top h1{font-size:18px}.title-mark{width:40px;height:40px}.badge-row{width:100%}.badge-row>*{flex:1;text-align:center}.save-bar{bottom:6px;display:block}.save-bar .btn{width:100%;min-width:0}.save-hint{display:block;margin-top:7px;text-align:center}}
@media(max-width:420px){.dashboard{grid-template-columns:1fr}.stat{min-height:78px}.sidebar-footer{grid-template-columns:1fr}.admin-shell{padding:7px}}
</style>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="/assets/css/bm-admin-main-match-v131.css?v=131">

<?php if (!function_exists('bm_site_bool') || bm_site_bool('ui_neon_checkbox_enabled', true)): ?>
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-uiverse-v14843.css?v=14843">
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-adapter-v14843.css?v=14843">
<style id="bm-neon-checkbox-settings">.neon-checkbox{--primary:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_color','#00ffaa'),ENT_QUOTES,'UTF-8') : '#00ffaa' ?>;--primary-dark:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_dark_color','#00cc88'),ENT_QUOTES,'UTF-8') : '#00cc88' ?>;--primary-light:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_light_color','#88ffdd'),ENT_QUOTES,'UTF-8') : '#88ffdd' ?>;--size:<?= function_exists('bm_site_get') ? max(24,min(38,(int)bm_site_get('ui_neon_checkbox_size',30))) : 30 ?>px}</style>
<script src="/assets/js/bm-neon-checkbox-v14843.js?v=14843" defer></script>
<?php endif; ?>
<link rel="stylesheet" href="/assets/css/bm-archive-sort-manager-v1.css?v=20261105-bm19">
</head>
<body>
<button type="button" class="bm-admin-menu-toggle" id="bmAdminMenuToggle" aria-label="بازکردن منوی مدیریت"><i class="fas fa-bars"></i></button>
<div class="bm-admin-sidebar-backdrop" id="bmAdminSidebarBackdrop" hidden></div>
<div class="theme-dock" aria-label="انتخاب تم پنل">
  <button type="button" data-theme="neon" class="theme-chip active" title="سبز نئونی"></button>
  <button type="button" data-theme="purple" class="theme-chip theme-purple-chip" title="بنفش سینمایی"></button>
  <button type="button" data-theme="red" class="theme-chip theme-red-chip" title="قرمز"></button>
  <button type="button" data-theme="gold" class="theme-chip theme-gold-chip" title="طلایی"></button>
</div>
<div class="admin-shell">
  <aside class="sidebar" id="bmAdminSidebar">
    <div class="brand">
      <div class="brand-logo"><i class="fas fa-mobile-screen-button"></i></div>
      <div><div class="brand-title">BankMovie</div><div class="brand-subtitle">کنترل اپلیکیشن</div></div>
    </div>
    <nav class="sidebar-nav" aria-label="منوی مدیریت اپ">
      <a href="#overview"><i class="fas fa-gauge-high nav-icon"></i>نمای کلی</a>
      <a href="#operations"><i class="fas fa-power-off nav-icon"></i>کنترل عملیاتی</a>
      <a href="#features"><i class="fas fa-sliders nav-icon"></i>قابلیت‌های اپ</a>
      <a href="#bmV11ArchiveManager"><i class="fas fa-layer-group nav-icon"></i>هفت آرشیو و واچ‌لیست</a>
      <a href="#section-controls"><i class="fas fa-table-cells-large nav-icon"></i>کنترل بخش‌ها</a>
      <a href="#home-order"><i class="fas fa-house nav-icon"></i>صفحه اصلی</a>
      <a href="#bm-home-ads"><i class="fas fa-rectangle-ad nav-icon"></i>تبلیغات اپ</a>
      <a href="#notices"><i class="fas fa-bell nav-icon"></i>اعلان داخل اپ</a>
      <a href="#push-notification"><i class="fas fa-paper-plane nav-icon"></i>Push Notification</a>
      <a href="#social-channels"><i class="fas fa-share-alt nav-icon"></i>کانال‌ها و بله</a>
      <a href="#servers"><i class="fas fa-server nav-icon"></i>سرورها</a>
      <a href="#v22-security"><i class="fas fa-shield-halved nav-icon"></i>امنیت API V22</a>
      <a href="#rewrites"><i class="fas fa-shuffle nav-icon"></i>دامنه‌ها</a>
      <a href="#release"><i class="fas fa-box-open nav-icon"></i>انتشار و آپدیت</a>
      <a href="#versions"><i class="fas fa-shield-halved nav-icon"></i>کنترل نسخه‌ها</a>
      <a href="#pending-comments"><i class="fas fa-comments nav-icon"></i>دیدگاه‌های منتظر</a>
      <a href="#recent-comments"><i class="fas fa-circle-check nav-icon"></i>دیدگاه‌های اخیر</a>
      <a href="#comment-reports"><i class="fas fa-flag nav-icon"></i>گزارش‌های کامنت</a>
      <a href="#audit-log"><i class="fas fa-clock-rotate-left nav-icon"></i>فعالیت مدیریت</a>
    </nav>
    <div class="sidebar-footer">
      <a href="/_lider/admin.php"><i class="fas fa-gauge"></i> پنل اصلی سایت</a>
      <a class="logout" href="/logout.php"><i class="fas fa-right-from-bracket"></i> خروج از حساب</a>
    </div>
  </aside>
  <main class="content">
<div class="wrap" id="overview">
  <div class="top">
    <div class="title-wrap">
      <div class="title-mark"><i class="fas fa-mobile-screen-button"></i></div>
      <div><h1>مدیریت اپ بانک مووی</h1><p>کنترل نسخه، سرور، امکانات، دانلود و دیدگاه‌ها از یک پنل واحد</p></div>
    </div>
    <div class="badge-row">
      <span class="badge">نقش تأییدشده: admin — <?= bm_h($adminName) ?></span>
      <a href="/app_config.php" target="_blank" rel="noopener">خروجی عمومی API</a>
    </div>
  </div>

  <?php if ($saveNotice !== ''): ?><div class="ok"><?= bm_h($saveNotice) ?></div><?php elseif ($savedOk): ?><div class="ok">تنظیمات با موفقیت و به‌صورت امن ذخیره شد.</div><?php endif; ?>
  <?php if ($saveError !== ''): ?><div class="err"><?= bm_h($saveError) ?></div><?php endif; ?>

  <div class="dashboard">
    <div class="stat"><small>وضعیت اپ</small><b><?= !empty($config['ready']) ? 'فعال' : 'غیرفعال' ?></b></div>
    <div class="stat"><small>نسخه انتشار</small><b><?= bm_h($config['update']['version_name'] ?? '-') ?></b></div>
    <div class="stat"><small>ریدایرکت دانلود</small><b><?= function_exists('bm_archive_download_redirect_enabled') && bm_archive_download_redirect_enabled() ? 'روشن' : 'خاموش / لینک عادی' ?></b></div>
    <div class="stat"><small>آپدیت</small><b><?= !empty($config['update']['enabled']) ? 'فعال' : 'خاموش' ?></b></div>
    <div class="stat"><small>سرورهای فعال</small><b><?= count(array_filter($servers, static fn($v) => !empty($v['enabled']))) ?> / <?= count($servers) ?></b></div>
    <div class="stat"><small>آرشیو ۳ در اپ</small><b><?php
      $bmArc3Cfg = (array)($config['features']['archives'] ?? []);
      echo !empty($bmArc3Cfg['archive3_hidden']) ? 'مخفی' : (!array_key_exists('archive3_enabled',$bmArc3Cfg) || !empty($bmArc3Cfg['archive3_enabled']) ? 'فعال' : 'غیرفعال');
    ?></b></div>
  </div>

  <div class="note security">این صفحه هیچ رمز مستقل یا رمز هاردکدشده‌ای ندارد. فقط نشست ورود سایت و کاربر دارای <b>users.role = admin</b> پذیرفته می‌شود. ذخیره‌ها CSRF، بکاپ، نوشتن اتمیک و گزارش فعالیت دارند.</div>

  <div class="split">
    <form method="post" class="card settings-form">
      <input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>">
      <input type="hidden" name="action" value="save">

      <section class="panel-section" id="operations">
      <div class="section-heading"><span class="section-icon">⚙️</span><h2>کنترل عملیاتی</h2></div>
      <div class="checks">
        <label class="chk"><input type="checkbox" name="ready" value="1" <?= !empty($config['ready'])?'checked':'' ?>> اپ فعال</label>
        <label class="chk"><input type="checkbox" name="notice_enabled" value="1" <?= !empty($config['notice']['enabled'])?'checked':'' ?>> پیام داخل اپ</label>
        <label class="chk"><input type="checkbox" name="notice_dismissible" value="1" <?= !array_key_exists('dismissible',(array)($config['notice']??[])) || !empty($config['notice']['dismissible'])?'checked':'' ?>> پیام قابل بستن باشد</label>
        <label class="chk"><input type="checkbox" name="update_enabled" value="1" <?= !empty($config['update']['enabled'])?'checked':'' ?>> آپدیت فعال</label>
        <label class="chk"><input type="checkbox" name="force_update" value="1" <?= !empty($config['update']['force'])?'checked':'' ?>> اجبار فقط برای نسخه جدیدتر</label>
        <label class="chk"><input type="checkbox" name="version_policy_enabled" value="1" <?= !empty($config['version_policy']['enabled'])?'checked':'' ?>> سیاست نسخه فعال</label>
        <label class="chk"><input type="checkbox" name="force_update_blocked" value="1" <?= !empty($config['version_policy']['force_update_blocked'])?'checked':'' ?>> نسخه مسدود قابل بستن نباشد</label>
        <label class="chk"><input type="checkbox" name="latest_version_only" value="1" <?= !empty($config['version_policy']['latest_version_only'])?'checked':'' ?>> فقط آخرین نسخه مجاز باشد</label>
      </div>
      <label>پیام حالت تعطیلی اپ</label>
      <input name="maintenance_message" value="<?= bm_h($config['message'] ?? '') ?>">

      </section>
      <section class="panel-section" id="features">
      <div class="section-heading"><span class="section-icon">🎛️</span><h3>کنترل قابلیت‌های اپ بدون انتشار APK</h3></div>
      <div class="checks">
        <?php foreach ([
          'registration_enabled'=>'ثبت‌نام','login_enabled'=>'ورود','comments_enabled'=>'کامنت','comment_replies_enabled'=>'پاسخ کامنت',
          'comment_votes_enabled'=>'لایک/دیس‌لایک','comment_reports_enabled'=>'گزارش تخلف کامنت','comment_spoiler_enabled'=>'اسپویلر کامنت',
          'notification_center_enabled'=>'مرکز اعلان','internal_downloader_enabled'=>'دانلودر داخلی','multipart_download_enabled'=>'دانلود چندبخشی',
          'download_path_selection_enabled'=>'انتخاب مسیر دانلود','advanced_search_enabled'=>'جست‌وجوی پیشرفته','categories_enabled'=>'دسته‌بندی',
          'watchlist_enabled'=>'علاقه‌مندی‌ها','continue_watching_enabled'=>'ادامه تماشا','tv_quick_menu_enabled'=>'منوی سریع TV',
          'profile_cleanup_enabled'=>'مرکز پاک‌سازی پروفایل','tv_detail_story_enabled'=>'داستان در جزئیات TV',
          'tv_detail_more_info_enabled'=>'مشخصات بیشتر در TV','external_player_fallback_enabled'=>'انتخاب دستی پلیر در دستگاه‌های قدیمی'
        ] as $key=>$label): ?>
          <label class="chk"><input type="checkbox" name="<?= bm_h($key) ?>" value="1" <?= !array_key_exists($key,(array)($config['features']??[])) || !empty($config['features'][$key])?'checked':'' ?>> <?= bm_h($label) ?> فعال</label>
        <?php endforeach; ?>
      </div>
      <?php
        $bmArchiveCfg = (array)($config['features']['archives'] ?? []);
        $bmSiteArchiveSettings = function_exists('bm_archive_get_settings') ? bm_archive_get_settings() : ['archives'=>[]];
        $bmAppArchiveSettings = (array)($config['app_archive_policy'] ?? []);
        $bmDownloadRedirectEnabled = function_exists('bm_archive_download_redirect_enabled')
          ? bm_archive_download_redirect_enabled()
          : !empty($config['downloads']['redirect_enabled']);
        $bmDownloadModernClientOnly = function_exists('bm_archive_download_modern_client_only')
          ? bm_archive_download_modern_client_only()
          : !empty($config['downloads']['modern_client_only']);
      ?>
      <!-- Seven archives and shared watchlist quota live inside the EXISTING BM Admin settings form. -->
      <div class="archive3-control-card" id="bmV11ArchiveManager" style="margin-bottom:14px">
        <div class="archive3-control-head"><span class="archive3-control-icon"><i class="fas fa-layer-group"></i></span>
          <div><b>هفت آرشیو · وضعیت و ترتیب جایگزینی</b><small>همان سیاست سایت؛ ۶ و ۷ فقط از سرور مدیریت می‌شوند و وارد منوی اپ نمی‌شوند.</small></div></div>
        <input type="hidden" name="bm_v11_archive_order_enabled" value="1">
        <div class="row" style="margin:12px 0">
          <div><label>سقف واچ‌لیست کاربر عادی (سایت و اپ)</label>
          <input type="number" name="bm_v11_watchlist_quota" min="1" max="500" required value="<?= (int)bm_site_get('watchlist_free_limit',100) ?>">
          <small>پیش‌فرض ۱۰۰؛ VIP طبق سیاست سرور نامحدود است.</small></div>
        </div>
        <?php
          $bmV11Cards = [];
          foreach (bm_ad_archive_dashboard_data() as $bmV11Card) $bmV11Cards[$bmV11Card['id']] = $bmV11Card;
          $bmV11Order = bm_archive_order();
          $bmV11Position = array_flip($bmV11Order);
        ?>
        <!-- Same pointer/touch and keyboard reorder model as the website admin. -->
        <div class="bm-sort-area" style="margin:12px 0 16px">
          <b>چیدمان هفت آرشیو</b>
          <p>دستهٔ ⠿ را بکش، از فلش‌ها استفاده کن یا جایگاه را انتخاب کن؛ سپس «ذخیره تنظیمات» همین فرم را بزن.</p>
          <div class="bm-sort-archives" id="bmAdminArchiveSortable" aria-label="چیدمان آرشیوها">
            <?php foreach ($bmV11Order as $bmSortId): $bmSortRank=(int)($bmV11Position[$bmSortId]??0)+1; ?>
            <div class="bm-sort-row" data-archive-id="<?= bm_h($bmSortId) ?>">
              <span class="bm-sort-handle" role="button" tabindex="0" title="جابه‌جایی با لمس، ماوس یا کلیدهای جهت‌دار">⠿</span>
              <strong>آرشیو <?= (int)substr($bmSortId,-1) ?></strong>
              <small><?= bm_h($bmSortId) ?></small>
              <label class="bm-sort-pos">جایگاه <select name="<?= bm_h($bmSortId) ?>_position" aria-label="جایگاه آرشیو <?= (int)substr($bmSortId,-1) ?>">
                <?php for($bmRank=1;$bmRank<=7;$bmRank++): ?><option value="<?= $bmRank ?>" <?= $bmSortRank===$bmRank?'selected':'' ?>><?= $bmRank ?></option><?php endfor; ?>
              </select></label>
              <button type="button" class="bm-sort-step" data-move="up" aria-label="بالا بردن آرشیو">↑</button>
              <button type="button" class="bm-sort-step" data-move="down" aria-label="پایین بردن آرشیو">↓</button>
              <input type="hidden" name="archive_order[]" value="<?= bm_h($bmSortId) ?>" disabled>
            </div>
            <?php endforeach; ?>
          </div>
          <div class="bm-sort-actions">
            <span class="bm-sort-status" aria-live="polite">برای مرتب‌سازی از دسته یا فلش‌ها استفاده کن.</span>
            <button type="button" class="bm-sort-reset" data-sort-reset disabled>بازگرداندن ترتیب</button>
          </div>
        </div>
        <div style="display:grid;gap:10px">
          <?php foreach ($bmV11Order as $bmV11Id):
            $bmV11Data = $bmV11Cards[$bmV11Id] ?? [];
            $bmV11Row = (array)($bmSiteArchiveSettings['archives'][$bmV11Id] ?? []);
            $bmV11Auth = (array)($bmV11Data['auth'] ?? []);
            $bmV11Number = (int)substr($bmV11Id,-1);
            $bmV11SiteManaged = $bmV11Number >= 6;
            $bmV11State = empty($bmV11Row['enabled']) ? 'off' : (($bmV11Row['disabled_mode'] ?? 'visible') === 'hide' ? 'hide' : 'on');
          ?>
          <div class="archive3-control-card" style="margin:0;padding:13px">
            <div class="archive3-control-head"><span class="archive3-control-icon"><i class="fas fa-film"></i></span>
              <div><b><?= bm_h($bmV11Data['name'] ?? $bmV11Id) ?></b>
                <small><?= bm_h($bmV11Data['scraper']['label'] ?? 'در انتظار بررسی') ?> · ورود: <?= bm_h($bmV11Auth['label'] ?? 'نامشخص') ?> · <?= $bmV11SiteManaged ? 'فقط تنظیمات سرور' : 'کنترل اپ در پایین همین صفحه' ?></small></div>
            </div>
            <div class="row" style="margin-top:9px">
              <div><label>وضعیت ورود</label><div class="note" style="margin:0"><?= bm_h($bmV11Auth['mode_label'] ?? 'نامشخص') ?> · <?= bm_h($bmV11Auth['note'] ?? 'نیاز به بررسی') ?></div>
                <?php if (!empty($bmV11Data['renew_url'])): ?><a target="_blank" rel="noopener" href="<?= bm_h($bmV11Data['renew_url']) ?>">مدیریت نشست / تمدید ورود</a><?php endif; ?>
              </div>
            </div>
            <?php if ($bmV11SiteManaged): ?>
            <div class="row" style="margin-top:9px">
              <div><label>نمایش آرشیو در سایت</label><select name="bm_v11_<?= bm_h($bmV11Id) ?>_state">
                <?php foreach (['on'=>'فعال','off'=>'خاموش','hide'=>'مخفی'] as $v=>$l): ?><option value="<?= $v ?>" <?= $bmV11State===$v?'selected':'' ?>><?= $l ?></option><?php endforeach; ?>
              </select></div>
              <div><label>سطح نمایش</label><select name="bm_v11_<?= bm_h($bmV11Id) ?>_scope">
                <?php foreach (['public'=>'عموم','member'=>'عضو','vip'=>'VIP','admin'=>'مدیر','disabled'=>'مسدود'] as $v=>$l): ?><option value="<?= $v ?>" <?= ($bmV11Row['access_scope'] ?? '')===$v?'selected':'' ?>><?= $l ?></option><?php endforeach; ?>
              </select></div>
              <div><label>لینک دانلود</label><select name="bm_v11_<?= bm_h($bmV11Id) ?>_download">
                <?php foreach (['public'=>'عموم','member'=>'عضو','vip'=>'VIP','admin'=>'مدیر','disabled'=>'بسته'] as $v=>$l): ?><option value="<?= $v ?>" <?= ($bmV11Row['download_access_scope'] ?? 'public')===$v?'selected':'' ?>><?= $l ?></option><?php endforeach; ?>
              </select></div>
              <div><label>پخش آنلاین</label><select name="bm_v11_<?= bm_h($bmV11Id) ?>_stream">
                <?php foreach (['public'=>'عموم','member'=>'عضو','vip'=>'VIP','admin'=>'مدیر','disabled'=>'بسته'] as $v=>$l): ?><option value="<?= $v ?>" <?= ($bmV11Row['stream_access_scope'] ?? 'public')===$v?'selected':'' ?>><?= $l ?></option><?php endforeach; ?>
              </select></div>
              <div><label>نوع لینک</label><select name="bm_v11_<?= bm_h($bmV11Id) ?>_link">
                <?php foreach (['original'=>'اصلی','redirect'=>'ریدایرکت','disabled'=>'غیرفعال'] as $v=>$l): ?><option value="<?= $v ?>" <?= ($bmV11Row['download_link_mode'] ?? 'original')===$v?'selected':'' ?>><?= $l ?></option><?php endforeach; ?>
              </select></div>
            </div>
            <?php endif; ?>
          </div>
          <?php endforeach; ?>
        </div>
        <small>دکمه «ذخیره تنظیمات» همین فرم، ترتیب و سقف واچ‌لیست را هم ذخیره می‌کند. اطلاعات خصوصی ورود تغییر نمی‌کنند.</small>
      </div>
      <div class="archive3-control-card" style="margin-bottom:14px">
        <div class="archive3-control-head">
          <span class="archive3-control-icon"><i class="fas fa-link"></i></span>
          <div><b>سیستم لینک دانلود</b><small>کلید اضطراری + حالت امن برای نسخه عمومی 2.2</small></div>
        </div>
        <div class="checks" style="margin-top:10px">
          <label class="chk"><input type="checkbox" name="download_redirect_enabled" value="1" <?= $bmDownloadRedirectEnabled?'checked':'' ?>> ریدایرکت دانلود روشن باشد</label>
          <label class="chk"><input type="checkbox" name="download_modern_client_only" value="1" <?= $bmDownloadModernClientOnly?'checked':'' ?>> فقط کلاینت جدید؛ نسخه 2.2 روی لینک و دانلود قدیمی بماند</label>
        </div>
        <small>اگر ریدایرکت را خاموش کنی، همه آرشیوها فوری به لینک عادی/رفتار قدیمی برمی‌گردند و آدرس‌های ساب‌دامین پاک نمی‌شوند.</small>
      </div>
      <?php foreach ([1=>'آرشیو ۱',2=>'آرشیو ۲',3=>'آرشیو ۳',4=>'آرشیو ۴',5=>'آرشیو ۵'] as $bmArchiveNumber=>$bmArchiveLabel):
        $bmArchiveId = 'archive' . $bmArchiveNumber;
        $bmSiteRow = (array)($bmSiteArchiveSettings['archives'][$bmArchiveId] ?? []);
        $bmManagedRow = (array)($bmAppArchiveSettings[$bmArchiveId] ?? []);
        $bmArchiveHidden = array_key_exists('hidden', $bmManagedRow) ? !empty($bmManagedRow['hidden']) : (($bmSiteRow['disabled_mode'] ?? 'visible') === 'hide');
        $bmArchiveEnabled = array_key_exists('enabled', $bmManagedRow) ? !empty($bmManagedRow['enabled']) : (!empty($bmSiteRow['enabled']));
        $bmArchiveMode = $bmArchiveHidden ? 'hidden' : ($bmArchiveEnabled ? 'enabled' : 'disabled');
        $bmAccessScope = (string)($bmManagedRow['access_scope'] ?? 'public');
        $bmDownloadScope = (string)($bmManagedRow['download_access_scope'] ?? ($bmSiteRow['download_access_scope'] ?? (!empty($bmArchiveCfg[$bmArchiveId . '_download_vip']) ? 'vip' : 'public')));
        $bmStreamScope = (string)($bmManagedRow['stream_access_scope'] ?? ($bmSiteRow['stream_access_scope'] ?? (!empty($bmArchiveCfg[$bmArchiveId . '_stream_vip']) ? 'vip' : 'public')));
        $bmDownloadLinkMode = strtolower((string)($bmManagedRow['download_link_mode'] ?? ($bmSiteRow['download_link_mode'] ?? 'redirect')));
        if (!in_array($bmDownloadLinkMode, ['redirect','original','disabled'], true)) $bmDownloadLinkMode = 'redirect';
        $bmDownloadSourceMode = (string)($bmSiteRow['download_source_mode'] ?? ($bmArchiveNumber === 4 ? 'vlc' : 'normal'));
        $bmDownloadClientMode = strtolower((string)($bmManagedRow['download_client_mode'] ?? ($bmSiteRow['download_client_mode'] ?? 'adm_copy')));
        if (!in_array($bmDownloadClientMode, ['adm_copy','all','disabled'], true)) $bmDownloadClientMode = 'adm_copy';
        $bmSourceBaseUrl = (string)($bmSiteRow['source_base_url'] ?? '');
        $bmDownloadBaseUrls = (array)($bmSiteRow['download_base_urls'] ?? ['https://dl10.bankmovie.top']);
        $bmDownloadBaseUrlsText = implode("\n", array_values(array_filter(array_map('strval', $bmDownloadBaseUrls))));
        $bmWatchPartyScope = (string)($bmManagedRow['watch_party_access_scope'] ?? 'vip');
        $bmInternalPlayerScope = (string)($bmManagedRow['internal_player_access_scope'] ?? 'public');
        $bmExternalPlayerScope = (string)($bmManagedRow['external_player_access_scope'] ?? 'public');
        $bmAllPlayerScope = (string)($bmManagedRow['all_players_access_scope'] ?? 'public');
      ?>
      <div class="archive3-control-card">
        <div class="archive3-control-head">
          <span class="archive3-control-icon"><i class="fas fa-layer-group"></i></span>
          <div><b>کنترل یکپارچه <?= bm_h($bmArchiveLabel) ?></b><small>وضعیت، مخفی‌سازی، دانلود و پخش با سایت همگام است؛ دسترسی آرشیو، Watch Party و پلیرها مخصوص اپ کنترل می‌شوند.</small></div>
        </div>
        <div class="archive3-mode-grid">
          <label class="archive3-mode">
            <input type="radio" name="archive<?= (int)$bmArchiveNumber ?>_mode" value="enabled" <?= $bmArchiveMode==='enabled'?'checked':'' ?>>
            <span><i class="fas fa-circle-check"></i><b>فعال</b><small>نمایش و بارگیری کامل</small></span>
          </label>
          <label class="archive3-mode">
            <input type="radio" name="archive<?= (int)$bmArchiveNumber ?>_mode" value="disabled" <?= $bmArchiveMode==='disabled'?'checked':'' ?>>
            <span><i class="fas fa-circle-pause"></i><b>غیرفعال</b><small>گزینه دیده می‌شود ولی محتوا لود نمی‌شود</small></span>
          </label>
          <label class="archive3-mode">
            <input type="radio" name="archive<?= (int)$bmArchiveNumber ?>_mode" value="hidden" <?= $bmArchiveMode==='hidden'?'checked':'' ?>>
            <span><i class="fas fa-eye-slash"></i><b>مخفی کامل</b><small>از انتخابگر و صفحه اصلی اپ حذف می‌شود</small></span>
          </label>
        </div>
        <div class="row3" style="margin-top:12px">
          <div><label>دسترسی خود آرشیو در اپ</label><select name="archive<?= (int)$bmArchiveNumber ?>_access_scope">
            <?php foreach (['public'=>'عمومی','member'=>'کاربر واردشده','vip'=>'فقط VIP','admin'=>'فقط مدیر'] as $scopeValue=>$scopeLabel): ?>
            <option value="<?= bm_h($scopeValue) ?>" <?= $bmAccessScope===$scopeValue?'selected':'' ?>><?= bm_h($scopeLabel) ?></option>
            <?php endforeach; ?>
          </select></div>
          <div><label>دسترسی لینک دانلود</label><select name="archive<?= (int)$bmArchiveNumber ?>_download_scope">
            <?php foreach (['public'=>'عمومی','member'=>'کاربر واردشده','vip'=>'فقط VIP','admin'=>'فقط مدیر','disabled'=>'کاملاً بسته'] as $scopeValue=>$scopeLabel): ?>
            <option value="<?= bm_h($scopeValue) ?>" <?= $bmDownloadScope===$scopeValue?'selected':'' ?>><?= bm_h($scopeLabel) ?></option>
            <?php endforeach; ?>
          </select></div>
          <div><label>دسترسی پخش آنلاین</label><select name="archive<?= (int)$bmArchiveNumber ?>_stream_scope">
            <?php foreach (['public'=>'عمومی','member'=>'کاربر واردشده','vip'=>'فقط VIP','admin'=>'فقط مدیر','disabled'=>'کاملاً بسته'] as $scopeValue=>$scopeLabel): ?>
            <option value="<?= bm_h($scopeValue) ?>" <?= $bmStreamScope===$scopeValue?'selected':'' ?>><?= bm_h($scopeLabel) ?></option>
            <?php endforeach; ?>
          </select></div>
        </div>
        <?php if (in_array($bmArchiveNumber, [3,4], true)): ?>
        <div class="row" style="margin-top:12px">
          <div style="flex:1 1 100%"><label>منبع لینک دانلود — <?= bm_h($bmArchiveLabel) ?></label>
            <select name="archive<?= (int)$bmArchiveNumber ?>_download_source_mode">
              <option value="normal" <?= $bmDownloadSourceMode==='normal'?'selected':'' ?>>دانلود عادی (لینک روی دکمه دانلود منبع)</option>
              <option value="vlc" <?= $bmDownloadSourceMode==='vlc'?'selected':'' ?>>لینک VLC (فایل داخل پلیر منبع)</option>
            </select>
            <small>این انتخاب فقط منبع لینک را تغییر می‌دهد؛ دسترسی VIP، ریدایرکت و API اپ مستقل هستند. md5/expires حذف یا بازنویسی نمی‌شوند.</small>
          </div>
        </div>
        <?php endif; ?>
        <div class="row" style="margin-top:12px">
          <div><label>نوع لینک دانلود</label><select name="archive<?= (int)$bmArchiveNumber ?>_download_link_mode">
            <option value="redirect" <?= $bmDownloadLinkMode==='redirect'?'selected':'' ?>>ریدایرکت BankMovie / ساب‌دامین آرشیو</option>
            <option value="original" <?= $bmDownloadLinkMode==='original'?'selected':'' ?>>لینک اصلی / حالت عادی</option>
            <option value="disabled" <?= $bmDownloadLinkMode==='disabled'?'selected':'' ?>>دانلود غیرفعال</option>
          </select></div>
          <div><label>روش دانلود در اپ جدید</label><select name="archive<?= (int)$bmArchiveNumber ?>_download_client_mode">
            <option value="adm_copy" <?= $bmDownloadClientMode==='adm_copy'?'selected':'' ?>>دانلودر داخلی + ADM + کپی لینک</option>
            <option value="all" <?= $bmDownloadClientMode==='all'?'selected':'' ?>>حالت کامل قدیمی</option>
            <option value="disabled" <?= $bmDownloadClientMode==='disabled'?'selected':'' ?>>دانلود غیرفعال</option>
          </select></div>
        </div>
        <div class="row" style="margin-top:12px">
          <div style="flex:1 1 100%">
            <label>دامنه منبع محتوای <?= bm_h($bmArchiveLabel) ?></label>
            <input type="url" name="archive<?= (int)$bmArchiveNumber ?>_source_base_url" dir="ltr" value="<?= bm_h($bmSourceBaseUrl) ?>" placeholder="https://example.com">
            <small><?= $bmArchiveNumber===3 ? 'برای آرشیو ۳، API6 از همین دامنه در لحظه استفاده می‌کند؛ تغییرش نیاز به APK یا Build جدید ندارد. فقط دامنه‌ای با قالب سازگار وارد کن.' : 'دامنه منبع سمت سرور؛ تغییر آن APK را تغییر نمی‌دهد.' ?></small>
          </div>
        </div>
        <?php if ($bmArchiveNumber === 3): ?>
        <div class="row" style="margin-top:10px">
          <div style="flex:1 1 100%">
            <button type="submit" name="action" value="clear_archive3_cache" class="secondary" onclick="return confirm('کش آرشیو ۳ پاک شود؟')"><i class="fas fa-broom"></i> پاک‌کردن کش آرشیو ۳</button>
            <small>فقط کش HTML آرشیو ۳ حذف می‌شود؛ تنظیمات، کاربران، دانلودها و کش سایر آرشیوها دست‌نخورده می‌مانند.</small>
          </div>
        </div>
        <?php endif; ?>
        <div class="row" style="margin-top:12px">
          <div style="flex:1 1 100%">
            <label>دامنه‌های ریدایرکت دانلود همین آرشیو</label>
            <textarea name="archive<?= (int)$bmArchiveNumber ?>_download_base_urls" dir="ltr" rows="3" placeholder="https://dl10.bankmovie.top&#10;https://dl11.bankmovie.top"><?= bm_h($bmDownloadBaseUrlsText) ?></textarea>
            <small>برای هر آرشیو مستقل است؛ هر ساب‌دامین واقعی را در یک خط وارد کن. سایت و اپ از همین تنظیم استفاده می‌کنند و Android هیچ ساب‌دامینی را Hardcode نمی‌کند. تغییر این لیست نیاز به APK جدید ندارد.</small>
          </div>
        </div>
        <div class="row" style="margin-top:12px">
          <div><label>Watch Party همین آرشیو</label><select name="archive<?= (int)$bmArchiveNumber ?>_watch_party_scope">
            <?php foreach (['public'=>'عمومی','member'=>'کاربر واردشده','vip'=>'فقط VIP','admin'=>'فقط مدیر','disabled'=>'کاملاً بسته'] as $scopeValue=>$scopeLabel): ?>
            <option value="<?= bm_h($scopeValue) ?>" <?= $bmWatchPartyScope===$scopeValue?'selected':'' ?>><?= bm_h($scopeLabel) ?></option>
            <?php endforeach; ?>
          </select></div>
          <div><label>قفل کلی همه پلیرهای همین آرشیو</label><select name="archive<?= (int)$bmArchiveNumber ?>_all_players_scope">
            <?php foreach (['public'=>'بدون قفل','member'=>'کاربر واردشده','vip'=>'فقط VIP','admin'=>'فقط مدیر','disabled'=>'کاملاً بسته'] as $scopeValue=>$scopeLabel): ?>
            <option value="<?= bm_h($scopeValue) ?>" <?= $bmAllPlayerScope===$scopeValue?'selected':'' ?>><?= bm_h($scopeLabel) ?></option>
            <?php endforeach; ?>
          </select></div>
        </div>
        <div class="row" style="margin-top:12px">
          <div><label>پلیر داخلی همین آرشیو</label><select name="archive<?= (int)$bmArchiveNumber ?>_internal_player_scope">
            <?php foreach (['public'=>'عمومی','member'=>'کاربر واردشده','vip'=>'فقط VIP','admin'=>'فقط مدیر','disabled'=>'کاملاً بسته'] as $scopeValue=>$scopeLabel): ?>
            <option value="<?= bm_h($scopeValue) ?>" <?= $bmInternalPlayerScope===$scopeValue?'selected':'' ?>><?= bm_h($scopeLabel) ?></option>
            <?php endforeach; ?>
          </select></div>
          <div><label>پلیرهای خارجی همین آرشیو</label><select name="archive<?= (int)$bmArchiveNumber ?>_external_player_scope">
            <?php foreach (['public'=>'عمومی','member'=>'کاربر واردشده','vip'=>'فقط VIP','admin'=>'فقط مدیر','disabled'=>'کاملاً بسته'] as $scopeValue=>$scopeLabel): ?>
            <option value="<?= bm_h($scopeValue) ?>" <?= $bmExternalPlayerScope===$scopeValue?'selected':'' ?>><?= bm_h($scopeLabel) ?></option>
            <?php endforeach; ?>
          </select></div>
        </div>
      </div>
      <?php endforeach; ?>
      <div class="row">
        <div><label>لینک پوستر صفحه ورود</label><input name="login_poster_url" dir="ltr" placeholder="https://.../poster.webp" value="<?= bm_h($config['features']['login_poster_url'] ?? '') ?>"></div>
        <div><label>حد دانلود هم‌زمان</label><input type="number" min="1" max="4" name="download_limit" value="<?= bm_h($config['downloads']['concurrent_limit'] ?? $config['features']['download_limit'] ?? 2) ?>"></div>
      </div>
      <div class="row">
        <div><label>حد صفحات اسکرول خودکار جست‌وجو</label><input type="number" min="1" max="10" name="search_auto_page_limit" value="<?= bm_h($config['features']['search_auto_page_limit'] ?? 10) ?>"><small>بعد از این تعداد، صفحه‌بندی قبل/بعد نمایش داده می‌شود.</small></div>
        <div></div>
      </div>
      <div class="row3">
        <div><label>تلاش مجدد دانلود</label><input type="number" min="0" max="12" name="download_retry_count" value="<?= bm_h($config['downloads']['retry_count'] ?? 4) ?>"></div>
        <div><label>فاصله تلاش مجدد (ثانیه)</label><input type="number" min="2" max="300" name="download_retry_delay_seconds" value="<?= bm_h($config['downloads']['retry_delay_seconds'] ?? 8) ?>"></div>
        <div><label>حداقل فضای آزاد (MB)</label><input type="number" min="32" max="8192" name="download_min_free_mb" value="<?= bm_h($config['downloads']['min_free_mb'] ?? 256) ?>"></div>
      </div>
      <div class="row3">
        <div><label>تعداد بخش دانلود چندبخشی</label><input type="number" min="2" max="6" name="multipart_parts" value="<?= bm_h($config['downloads']['multipart_parts'] ?? 4) ?>"></div>
        <div><label>حداکثر کامنت در بازه</label><input type="number" min="1" max="30" name="comment_rate_count" value="<?= bm_h($config['comments']['rate_count'] ?? 3) ?>"></div>
        <div><label>بازه ضداسپم (دقیقه)</label><input type="number" min="1" max="1440" name="comment_rate_minutes" value="<?= bm_h($config['comments']['rate_minutes'] ?? 10) ?>"></div>
      </div>
      <div class="row">
        <div><label>مدت مجاز ویرایش کامنت (دقیقه)</label><input type="number" min="0" max="1440" name="comment_edit_minutes" value="<?= bm_h($config['comments']['edit_minutes'] ?? 10) ?>"></div>
        <div></div>
      </div>

      <div class="checks">
        <label class="chk"><input type="checkbox" name="comment_auto_approve_admin" value="1" <?= !array_key_exists('auto_approve_admin',(array)($config['comments']??[])) || !empty($config['comments']['auto_approve_admin'])?'checked':'' ?>> تأیید مستقیم مدیر</label>
        <label class="chk"><input type="checkbox" name="comment_auto_approve_vip" value="1" <?= !array_key_exists('auto_approve_vip',(array)($config['comments']??[])) || !empty($config['comments']['auto_approve_vip'])?'checked':'' ?>> تأیید مستقیم عضو ویژه</label>
      </div>
      </section>
      <section class="panel-section" id="section-controls">
      <div class="section-heading"><span class="section-icon">🧩</span><h3>کنترل ریز بخش‌های هر آرشیو</h3></div>
      <div class="note">هر ردیف مستقل است: با خاموش‌کردن یا انتخاب «غیرفعال / مخفی کامل»، کل بخش از Home و میانبرهای اپ حذف می‌شود و API مستقیمش هم داده برنمی‌گرداند. سطح‌های عضو، VIP و مدیر همچنان بخش را به‌صورت قفل دسترسی نگه می‌دارند.</div>
      <?php foreach (bm_app_home_section_catalog() as $bmSectionArchiveNumber=>$bmSectionCatalog): ?>
        <div class="archive3-control-card" style="margin-top:12px">
          <div class="archive3-control-head"><b>بخش‌های آرشیو <?= (int)$bmSectionArchiveNumber ?></b><small>کنترل مستقل نمایش و دسترسی</small></div>
          <div style="display:grid;gap:8px;margin-top:10px">
          <?php foreach ($bmSectionCatalog as $bmSectionKey=>$bmSectionLabel):
            $bmSectionState = bm_app_section_policy_value($config, (int)$bmSectionArchiveNumber, (string)$bmSectionKey);
            $bmSectionEnabled = !empty($bmSectionState['enabled']);
            $bmSectionScope = (string)($bmSectionState['access_scope'] ?? 'public');
          ?>
            <div class="section-control-row" style="display:grid;grid-template-columns:minmax(180px,1fr) minmax(120px,.55fr) minmax(175px,.7fr);gap:10px;align-items:center;padding:10px 12px;border:1px solid var(--line);border-radius:12px;background:rgba(255,255,255,.02)">
              <div><b><?= bm_h($bmSectionLabel) ?></b><small dir="ltr" style="display:block;opacity:.7;margin-top:3px"><?= bm_h($bmSectionKey) ?></small></div>
              <label class="chk" style="margin:0"><input type="hidden" name="section_archive<?= (int)$bmSectionArchiveNumber ?>_<?= bm_h($bmSectionKey) ?>_enabled" value="0"><input type="checkbox" name="section_archive<?= (int)$bmSectionArchiveNumber ?>_<?= bm_h($bmSectionKey) ?>_enabled" value="1" <?= $bmSectionEnabled?'checked':'' ?>> نمایش بخش</label>
              <select name="section_archive<?= (int)$bmSectionArchiveNumber ?>_<?= bm_h($bmSectionKey) ?>_scope">
                <?php foreach (['public'=>'عمومی','member'=>'کاربر واردشده','vip'=>'فقط VIP','admin'=>'فقط مدیر','disabled'=>'غیرفعال / مخفی کامل'] as $scopeValue=>$scopeLabel): ?>
                  <option value="<?= bm_h($scopeValue) ?>" <?= $bmSectionScope===$scopeValue?'selected':'' ?>><?= bm_h($scopeLabel) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          <?php endforeach; ?>
          </div>
        </div>
      <?php endforeach; ?>
      </section>
      <section class="panel-section" id="home-order">
      <div class="section-heading"><span class="section-icon">🏠</span><h3>ترتیب بخش‌های صفحه اصلی</h3></div>
      <div class="note">هر خط یک کلید بخش است. حذف یک کلید، آن بخش را بدون انتشار APK مخفی می‌کند.</div>
      <div class="row">
        <div><label>آرشیو ۱</label><textarea name="home_archive1_sections" dir="ltr"><?= bm_h($homeArchive1Text) ?></textarea></div>
        <div><label>آرشیو ۲</label><textarea name="home_archive2_sections" dir="ltr"><?= bm_h($homeArchive2Text) ?></textarea></div>
      </div>
      <div class="row">
        <div><label>آرشیو ۳</label><textarea name="home_archive3_sections" dir="ltr"><?= bm_h($homeArchive3Text) ?></textarea></div>
        <div><label>آرشیو ۴</label><textarea name="home_archive4_sections" dir="ltr"><?= bm_h($homeArchive4Text) ?></textarea></div>
      </div>
      <div class="row">
        <div><label>آرشیو 5</label><textarea name="home_archive5_sections" dir="ltr"><?= bm_h($homeArchive5Text) ?></textarea></div>
        <div></div>
      </div>

      </section>
      <section class="panel-section" id="notices">
      <div class="section-heading"><span class="section-icon">🔔</span><h3>مرکز اعلان و پیام مدیریت</h3></div>
      <div class="row3">
        <div><label>نوع اعلان</label><select name="notice_type"><option value="admin" <?= (($config['notice']['type']??'admin')==='admin')?'selected':'' ?>>پیام مدیریت</option><option value="system" <?= (($config['notice']['type']??'')==='system')?'selected':'' ?>>سیستمی</option><option value="update" <?= (($config['notice']['type']??'')==='update')?'selected':'' ?>>آپدیت</option><option value="maintenance" <?= (($config['notice']['type']??'')==='maintenance')?'selected':'' ?>>تعمیرات</option></select></div>
        <div><label>شناسه اعلان</label><input name="notice_id" dir="ltr" value="<?= bm_h($config['notice']['id'] ?? '') ?>"></div>
        <div><label>عنوان اعلان</label><input name="notice_title" value="<?= bm_h($config['notice']['title'] ?? '') ?>"></div>
      </div>
      <label>متن اعلان</label><textarea name="notice_message"><?= bm_h($config['notice']['message'] ?? '') ?></textarea>
      <label>لینک مقصد اختیاری اعلان</label><input name="notice_target_url" dir="ltr" value="<?= bm_h($config['notice']['target']['url'] ?? '') ?>">

      </section>
      <section class="panel-section" id="social-channels">
      <div class="section-heading"><span class="section-icon">🟢</span><h3>کانال جایگزین بله و مسیر خرید VIP</h3></div>
      <div class="note">بله به‌صورت پیش‌فرض خاموش است. وقتی فعالش کنی می‌توانی آن را کنار شبکه‌های اجتماعی اپ نمایش بدهی، در صفحه خطای اتصال به‌عنوان کانال اضطراری استفاده کنی، یا دکمه خرید VIP را از تلگرام به لینک بله تغییر بدهی. با خاموش‌کردن دوباره، کل اپ خودکار به تلگرام برمی‌گردد.</div>
      <div class="checks">
        <label class="chk"><input type="checkbox" name="bale_enabled" value="1" <?= !empty($config['social']['bale_enabled'])?'checked':'' ?>> فعال‌کردن بله در اپ</label>
      </div>
      <div class="row">
        <div><label>لینک کانال بله</label><input name="bale_channel_url" dir="ltr" placeholder="https://ble.ir/..." value="<?= bm_h($config['social']['bale_channel_url'] ?? '') ?>"></div>
        <div><label>لینک خرید VIP در بله</label><input name="bale_purchase_url" dir="ltr" placeholder="https://ble.ir/..." value="<?= bm_h($config['social']['bale_purchase_url'] ?? '') ?>"></div>
      </div>
      <div class="row">
        <div><label>کانال اضطراری هنگام خطای اتصال</label><select name="emergency_channel"><option value="telegram" <?= (($config['social']['emergency_channel']??'telegram')==='telegram')?'selected':'' ?>>تلگرام</option><option value="bale" <?= (($config['social']['emergency_channel']??'telegram')==='bale')?'selected':'' ?>>بله</option></select></div>
        <div><label>مسیر خرید اشتراک ویژه</label><select name="vip_purchase_provider"><option value="telegram" <?= (($config['social']['vip_purchase_provider']??'telegram')==='telegram')?'selected':'' ?>>خرید در تلگرام</option><option value="bale" <?= (($config['social']['vip_purchase_provider']??'telegram')==='bale')?'selected':'' ?>>خرید در بله</option></select></div>
      </div>
      </section>
      <section class="panel-section" id="servers">
      <div class="section-heading"><span class="section-icon">🌐</span><h3>سرورها و Failover خودکار</h3></div>
      <div class="note"><b>دامنه ریموت فقط تنظیمات را ارسال می‌کند.</b> دامنه دوم باید علاوه بر app_api.php، مسیرهای archive1_live.php، api6.php، api4.php و api5.php را نیز داشته باشد. تغییر دامنه، منبع آرشیو را عوض نمی‌کند. آرشیو غیرفعال را نمی‌توان با Failover دور زد. قبل از تغییر اولویت، تنظیمات را ذخیره کن و اتصال APIها را آزمایش کن.</div>
      <div id="serverRows" class="server-list">
        <?php foreach ($servers as $i => $server): ?>
          <div class="server-row">
            <div class="server-grid">
              <div><label>نام سرور</label><input name="server_name[<?= (int)$i ?>]" value="<?= bm_h($server['name'] ?? '') ?>"></div>
              <div><label>دامنه محتوا</label><input name="server_domain[<?= (int)$i ?>]" dir="ltr" value="<?= bm_h($server['domain'] ?? '') ?>"></div>
              <div><label>آدرس API</label><input name="server_api[<?= (int)$i ?>]" dir="ltr" value="<?= bm_h($server['api_url'] ?? '') ?>"></div>
              <div><label>اولویت</label><input type="number" min="1" name="server_priority[<?= (int)$i ?>]" value="<?= bm_h($server['priority'] ?? ($i + 1)) ?>"></div>
            </div>
            <div class="mini-actions">
              <label class="chk"><input type="checkbox" name="server_enabled[<?= (int)$i ?>]" value="1" <?= !empty($server['enabled'])?'checked':'' ?>> فعال</label>
              <button type="button" class="remove-row" onclick="this.closest('.server-row').remove()">حذف ردیف</button>
              <button type="button" class="add-row" onclick="checkBmContentMirrorV20(<?= (int)$i ?>, this)">آزمایش APIهای سرور</button>
            </div>
            <div class="bm-mirror-health-output" aria-live="polite" style="font-size:12px;line-height:2;color:#cbd5e1;padding:8px"></div>
          </div>
        <?php endforeach; ?>
      </div>
      <button type="button" class="add-row" onclick="addServerRow()">+ افزودن سرور جایگزین</button>

      </section>
      <section class="panel-section" id="rewrites">
      <div class="section-heading"><span class="section-icon">🔁</span><h3>حذف یا جایگزینی دامنه‌های قدیمی داخل API</h3></div>
      <div class="note">در ستون مبدأ می‌توانی دامنه کامل یا فقط عبارت <b>OLDTOWNS</b> را بنویسی. حالت «استفاده از سرور فعال» دامنه قدیمی را حذف می‌کند و مسیر فایل را روی سرور فعال می‌گذارد. حالت «جایگزینی» آن را با دامنه مقصد عوض می‌کند.</div>
      <div id="rewriteRows" class="rewrite-list">
        <?php foreach ($rewrites as $i => $rule): ?>
          <div class="rewrite-row">
            <div class="rewrite-grid">
              <div><label>دامنه/عبارت قدیمی</label><input name="rewrite_from[<?= (int)$i ?>]" dir="ltr" placeholder="OLDTOWNS یا old.example.com" value="<?= bm_h($rule['from'] ?? '') ?>"></div>
              <div><label>دامنه مقصد</label><input name="rewrite_to[<?= (int)$i ?>]" dir="ltr" placeholder="https://new.example.com" value="<?= bm_h(($rule['mode'] ?? '') === 'active' ? '' : ($rule['to'] ?? '')) ?>"></div>
              <div><label>نوع عملیات</label><select name="rewrite_mode[<?= (int)$i ?>]"><option value="active" <?= (($rule['mode'] ?? '')==='active')?'selected':'' ?>>استفاده از سرور فعال</option><option value="replace" <?= (($rule['mode'] ?? '')!=='active')?'selected':'' ?>>جایگزینی دامنه</option></select></div>
            </div>
            <div class="mini-actions">
              <label class="chk"><input type="checkbox" name="rewrite_enabled[<?= (int)$i ?>]" value="1" <?= !array_key_exists('enabled',$rule) || !empty($rule['enabled'])?'checked':'' ?>> فعال</label>
              <button type="button" class="remove-row" onclick="this.closest('.rewrite-row').remove()">حذف ردیف</button>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
      <button type="button" class="add-row" onclick="addRewriteRow()">+ افزودن قانون دامنه</button>

      </section>
      <section class="panel-section" id="ui-texts">
      <div class="section-heading"><span class="section-icon">✍️</span><h3>کنترل ریموت تمام متن‌های اپ</h3></div>
      <div class="note">هر خط را به شکل <b>متن فعلی =&gt; متن جدید</b> وارد کن. متن‌های داخل Activityها، Hintها و بسیاری از متن‌های قدیمی هم بدون انتشار APK جدید جایگزین می‌شوند. برای سال‌ها می‌توانی از <b>{{year}}</b>، <b>{{prev_year}}</b> و <b>{{next_year}}</b> استفاده کنی. مقدار سال 0 یعنی خودکار.</div>
      <div class="row">
        <div><label>سال نمایشی اپ (0 = خودکار)</label><input type="number" min="0" max="2200" name="ui_display_year" dir="ltr" value="<?= bm_h($config['ui']['display_year'] ?? 0) ?>"></div>
        <div><label>بیشترین سال جستجو (0 = خودکار)</label><input type="number" min="0" max="2200" name="ui_search_max_year" dir="ltr" value="<?= bm_h($config['ui']['search_max_year'] ?? 0) ?>"></div>
      </div>
      <div class="row">
        <div><label>جایگزینی متن فارسی — هر خط یک قانون</label><textarea name="ui_text_overrides_fa" rows="12" placeholder="برترین‌های 2026 => فیلم‌های منتخب {{year}}
اکران 2025 و 2026 => اکران {{prev_year}} و {{year}}"><?= bm_h($uiTextOverridesFa) ?></textarea></div>
        <div><label>English text overrides — one rule per line</label><textarea name="ui_text_overrides_en" rows="12" dir="ltr" placeholder="Best of 2026 => Picks of {{year}}
2025 and 2026 Releases => {{prev_year}} and {{year}} Releases"><?= bm_h($uiTextOverridesEn) ?></textarea></div>
      </div>
      </section>
      <section class="panel-section" id="release">
      <div class="section-heading"><span class="section-icon">📦</span><h3>انتشار و آپدیت</h3></div>
      <div class="row">
        <div><label>Version Name</label><input name="version_name" dir="ltr" value="<?= bm_h($config['update']['version_name'] ?? '2.2') ?>"></div>
        <div><label>Version Code</label><input type="number" name="version_code" dir="ltr" value="<?= bm_h($config['update']['version_code'] ?? 0) ?>"></div>
      </div>
      <div class="row3">
        <div><label>APK Universal</label><input name="apk_universal" dir="ltr" value="<?= bm_h($config['update']['apk_urls']['universal'] ?? $config['update']['apk_url'] ?? '') ?>"></div>
        <div><label>APK ARM64</label><input name="apk_arm64" dir="ltr" value="<?= bm_h($config['update']['apk_urls']['arm64_v8a'] ?? '') ?>"></div>
        <div><label>APK V7A</label><input name="apk_v7a" dir="ltr" value="<?= bm_h($config['update']['apk_urls']['armeabi_v7a'] ?? '') ?>"></div>
      </div>
      <div class="row">
        <div><label>عنوان آپدیت</label><input name="update_title" value="<?= bm_h($config['update']['title'] ?? '') ?>"></div>
        <div><label>پیام آپدیت</label><input name="update_message" value="<?= bm_h($config['update']['message'] ?? '') ?>"></div>
      </div>
      <label>تغییرات نسخه — هر خط یک مورد</label>
      <textarea name="changes"><?= bm_h($changesText) ?></textarea>

      </section>
      <section class="panel-section" id="versions">
      <div class="section-heading"><span class="section-icon">🛡️</span><h3>مدیریت و غیرفعال‌سازی نسخه‌ها</h3></div>
      <div class="note">برای غیرفعال‌کردن نسخه 1.3 فقط عدد <b>1.3</b> را در فهرست نسخه‌های مسدود بنویس. اپ آن نسخه قبل از دریافت صفحه اصلی متوقف می‌شود و به APK مناسب دستگاه هدایت می‌شود.</div>
      <div class="row">
        <div><label>حداقل Version Name مجاز</label><input name="minimum_version_name" dir="ltr" placeholder="مثلاً 1.4" value="<?= bm_h($config['version_policy']['minimum_version_name'] ?? '') ?>"></div>
        <div><label>حداقل Version Code مجاز</label><input type="number" name="minimum_version_code" dir="ltr" value="<?= bm_h($config['version_policy']['minimum_version_code'] ?? 0) ?>"></div>
      </div>
      <div class="row">
        <div><label>Version Nameهای مسدود — هر خط یکی</label><textarea name="blocked_version_names" dir="ltr" placeholder="1.3\n1.3.1"><?= bm_h($blockedNamesText) ?></textarea></div>
        <div><label>Version Codeهای مسدود — هر خط یکی</label><textarea name="blocked_version_codes" dir="ltr" placeholder="980001\n980002"><?= bm_h($blockedCodesText) ?></textarea></div>
      </div>
      <label>پیام نسخه غیرفعال</label>
      <textarea name="block_message"><?= bm_h($config['version_policy']['block_message'] ?? '') ?></textarea>


      </section>
      <div class="save-bar"><button class="btn" type="submit">ذخیره همه تنظیمات</button><span class="save-hint">تغییرات پس از ذخیره از طریق تنظیمات راه دور به اپ ارسال می‌شوند.</span></div>
    </form>

    <div class="card" id="bm-home-ads">
      <div class="section-heading"><span class="section-icon">📣</span><h3>تبلیغات صفحه اصلی اپ</h3></div>
      <p class="note">این باکس درست بعد از دکمه‌های آرشیو در صفحه اصلی موبایل و تلویزیون نمایش داده می‌شود. فقط متن، فقط عکس یا هر دو را همزمان می‌توانی قرار بدهی. گوشه‌ها نرم و گرد هستند. با ذخیره، بدون بیلد مجدد اپ محتوای آنلاین تغییر می‌کند.</p>
      <?php $bmCurrentHomeAd = is_array($config['home_ad'] ?? null) ? $config['home_ad'] : []; ?>
      <form method="post" enctype="multipart/form-data" id="bmHomeAdsEditor" style="display:grid;gap:12px">
        <input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>">
        <input type="hidden" name="action" value="save_home_ad">
        <label class="chk"><input type="checkbox" name="ad_enabled" value="1" <?= !empty($bmCurrentHomeAd['enabled'])?'checked':'' ?>> نمایش تبلیغات در اپ فعال باشد</label>
        <div class="row"><div><label>عنوان باکس (اختیاری)</label><input name="ad_title" maxlength="100" value="<?= bm_h($bmCurrentHomeAd['title']??'') ?>" placeholder="مثلاً پیشنهاد ویژه این هفته"></div>
          <div><label>متن دکمه لینک (اختیاری)</label><input name="ad_button_text" maxlength="48" value="<?= bm_h($bmCurrentHomeAd['button_text']??'') ?>" placeholder="مثلاً مشاهده یا خرید اشتراک"></div></div>
        <div><label>آیکون SVG آفلاین دکمه (داخل اپ؛ بدون دانلود شبکه)</label>
          <select name="ad_button_icon">
            <?php foreach (['arrow'=>'فلش / مشاهده','eye'=>'چشم / دیدن','bag'=>'کیف خرید','play'=>'پخش','external'=>'باز کردن لینک','none'=>'بدون آیکون'] as $key=>$label): ?>
              <option value="<?= bm_h($key) ?>" <?= ($bmCurrentHomeAd['button_icon'] ?? 'arrow') === $key?'selected':'' ?>><?= bm_h($label) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <label>متن تبلیغ (اختیاری؛ تا ۱۰۰۰ کاراکتر)</label>
        <textarea name="ad_text" maxlength="1000" rows="4" placeholder="پیام، خبر یا توضیحات تبلیغ را بنویس..."><?= bm_h($bmCurrentHomeAd['text']??'') ?></textarea>
        <div class="row"><div><label>آدرس تصویر (اختیاری)</label><input name="ad_image_url" dir="ltr" value="<?= bm_h($bmCurrentHomeAd['image_url']??'') ?>" placeholder="https://... یا /uploads/..."></div>
          <div><label>آپلود تصویر جدید (JPG/PNG/WebP/GIF، حداکثر ۴MB)</label><input type="file" name="ad_image_upload" accept="image/jpeg,image/png,image/webp,image/gif"></div></div>
        <?php
          $bmAdPreviewUrl = trim((string)($bmCurrentHomeAd['image_url'] ?? ''));
          if (preg_match('~^/uploads/bm-app-ads/[a-f0-9]{28}\.(?:jpg|png|webp|gif)$~iD', $bmAdPreviewUrl)) {
              $bmAdPreviewUrl = '/app_ad_image.php?v=' . max(0, (int)($config['config_revision'] ?? 0));
          }
        ?>
        <div id="bmAdLivePreview" style="position:relative;overflow:hidden;border-radius:25px;border:1px solid rgba(255,255,255,.22);background:linear-gradient(140deg,#222a38,#080c15);box-shadow:0 12px 32px rgba(0,0,0,.24);min-height:98px;max-width:550px">
          <img id="bmAdPreviewImage" alt="پیش‌نمایش عکس تبلیغات" src="<?= bm_h($bmAdPreviewUrl) ?>" style="display:<?= $bmAdPreviewUrl!==''?'block':'none' ?>;width:100%;height:210px;object-fit:cover;" />
          <div id="bmAdPreviewImageError" style="display:none;padding:15px;color:#ffb6b6">تصویر در دسترس نیست؛ مسیر عکس یا مجوز خواندن فایل روی سرور را بررسی کن.</div>
          <div style="position:relative;padding:14px 18px;background:linear-gradient(90deg,rgba(14,17,28,.94),rgba(24,30,43,.77));color:#fff">
            <strong id="bmAdPreviewTitle" style="display:block;font-size:16px"></strong>
            <span id="bmAdPreviewText" style="display:block;margin-top:5px;white-space:pre-wrap;line-height:1.7"></span>
          </div>
          <div id="bmAdPreviewCtaWrap" style="display:none;padding:12px 16px;background:#0c1423">
            <div style="margin:auto;display:flex;gap:9px;justify-content:center;align-items:center;max-width:440px;min-height:45px;border-radius:16px;color:white;font-weight:800;background:linear-gradient(115deg,#1c74f4,#53a3ff);box-shadow:0 6px 22px #154c9a55">
              <span id="bmAdPreviewCta"></span><span id="bmAdPreviewIcon" style="display:inline-flex"></span>
            </div>
          </div>
        </div>
        <?php if (!empty($bmCurrentHomeAd['image_url'])): ?>
          <div style="display:flex;flex-wrap:wrap;align-items:center;gap:10px;margin:4px 0 0">
            <button type="button" id="bmAdPublicImageCheck" class="btn" style="min-height:38px">آزمایش نمایش عکس بدون ورود</button>
            <span id="bmAdPublicImageStatus" aria-live="polite" style="font-size:12px;opacity:.85">این آزمایش بدون کوکی ورود پنل انجام می‌شود تا نمایش عکس در اپ بررسی شود.</span>
          </div>
          <label class="chk"><input type="checkbox" name="ad_remove_image" value="1"> حذف تصویر فعلی</label>
        <?php endif; ?>
        <label>لینک کلیک روی تبلیغ (اختیاری)</label>
        <input name="ad_link_url" dir="ltr" value="<?= bm_h($bmCurrentHomeAd['link_url']??'') ?>" placeholder="https://bankmovie.top/... یا /movie/...">
        <div class="save-bar"><button type="submit" class="btn green">ذخیره تبلیغات</button><small class="save-hint">با خاموش‌کردن نمایش، باکس از همه آرشیوها مخفی می‌شود.</small></div>
      </form>
      <script>
      (() => {
        const form = document.getElementById('bmHomeAdsEditor');
        const image = document.getElementById('bmAdPreviewImage');
        const error = document.getElementById('bmAdPreviewImageError');
        const title = document.getElementById('bmAdPreviewTitle');
        const text = document.getElementById('bmAdPreviewText');
        if (!form || !image || !error || !title || !text) return;
        const urlInput = form.elements.namedItem('ad_image_url');
        const uploadInput = form.elements.namedItem('ad_image_upload');
        const removeInput = form.elements.namedItem('ad_remove_image');
        const ctaWrap = document.getElementById('bmAdPreviewCtaWrap');
        const ctaText = document.getElementById('bmAdPreviewCta');
        const ctaIcon = document.getElementById('bmAdPreviewIcon');
        const iconPaths = {
          arrow: '<path d="M5 12h14M12 5l7 7-7 7"/>',
          eye: '<path d="M2 12c2.5-4 6-6 10-6s7.5 2 10 6c-2.5 4-6 6-10 6s-7.5-2-10-6z"/><circle cx="12" cy="12" r="3"/>',
          bag: '<path d="M4 8h16l-1 13H5zM9 8V6a3 3 0 0 1 6 0v2"/>',
          play: '<path d="M9 5l11 7-11 7z" fill="white" stroke="none"/>',
          external: '<path d="M13 4h7v7M20 4L10 14M19 14v5H5V5h5"/>'
        };
        const updateCta = () => {
          const link = form.elements.namedItem('ad_link_url')?.value.trim() || '';
          ctaWrap.style.display = /^https?:\/\//i.test(link) || (link.startsWith('/') && !link.startsWith('//')) ? 'block' : 'none';
          ctaText.textContent = form.elements.namedItem('ad_button_text')?.value.trim() || 'مشاهده';
          const icon = form.elements.namedItem('ad_button_icon')?.value || 'arrow';
          ctaIcon.innerHTML = iconPaths[icon] ? '<svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'+ iconPaths[icon] +'</svg>' : '';
        };
        ['ad_link_url','ad_button_text','ad_button_icon'].forEach(name => {
          const el = form.elements.namedItem(name);
          el?.addEventListener('change', updateCta);
          el?.addEventListener('input', updateCta);
        });
        updateCta();
        const publicTest = document.getElementById('bmAdPublicImageCheck');
        const publicStatus = document.getElementById('bmAdPublicImageStatus');
        publicTest?.addEventListener('click', async () => {
          if (!publicStatus) return;
          publicStatus.textContent = 'در حال بررسی دسترسی عمومی عکس...';
          try {
            const response = await fetch('/v2/api/app_config.php?bm_home_ad_image=1&ad_test=' + Date.now(),
              {credentials: 'omit', cache: 'no-store', headers: {Accept: 'image/*'}});
            const type = response.headers.get('content-type') || '';
            const blob = response.ok && type.startsWith('image/') ? await response.blob() : null;
            if (!blob || !blob.size) throw new Error('HTTP ' + response.status + ' / ' + type);
            publicStatus.textContent = 'عکس بدون ورود قابل دریافت است (HTTP ' + response.status + '، ' + Math.round(blob.size / 1024) + ' KB).';
            publicStatus.style.color = '#68e5af';
          } catch (error) {
            publicStatus.textContent = 'دسترسی عمومی عکس ناموفق است؛ پچ app_config.php و app_ad_image.php را در سرور کنترل بررسی کن: ' + String(error.message || error);
            publicStatus.style.color = '#ffaaaa';
          }
        });

        let blobUrl = '';
        const showImage = (src) => {
          if (!src) { image.style.display = 'none'; error.style.display = 'none'; image.removeAttribute('src'); return; }
          image.style.display = 'block'; error.style.display = 'none'; image.src = src;
        };
        image.addEventListener('error', () => { image.style.display = 'none'; error.style.display = 'block'; });
        image.addEventListener('load', () => { image.style.display = 'block'; error.style.display = 'none'; });
        const update = () => {
          title.textContent = form.elements.namedItem('ad_title')?.value || '';
          text.textContent = form.elements.namedItem('ad_text')?.value || '';
          if (blobUrl) { URL.revokeObjectURL(blobUrl); blobUrl = ''; }
          if (removeInput?.checked) { showImage(''); return; }
          const file = uploadInput?.files?.[0];
          if (file) { blobUrl = URL.createObjectURL(file); showImage(blobUrl); return; }
          const raw = urlInput?.value.trim() || '';
          const saved = <?= json_encode((string)($bmCurrentHomeAd['image_url'] ?? ''), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
          const preview = <?= json_encode($bmAdPreviewUrl, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
          showImage(raw === saved ? preview : raw);
        };
        ['ad_title', 'ad_text', 'ad_image_url', 'ad_image_upload', 'ad_remove_image'].forEach(name => {
          const el = form.elements.namedItem(name); if (el) { el.addEventListener('change', update); el.addEventListener('input', update); }
        });
        title.textContent = form.elements.namedItem('ad_title')?.value || '';
        text.textContent = form.elements.namedItem('ad_text')?.value || '';
        if (image.getAttribute('src') === '') image.style.display = 'none';
      })();
      </script>
    </div>

    <?php $bmV22Policy=bm22_policy(); ?>
    <div class="card" id="v22-security">
      <div class="section-heading"><span class="section-icon">🛡️</span><h2>امنیت API نسخه V22</h2></div>
      <p class="desc">مسیرهای قدیمی فعلاً فعال می‌مانند. مسیرهای جدید <code dir="ltr">/v2/api/</code> توکن ۳۰ دقیقه‌ای HMAC و امضای دستگاه می‌خواهند. تنظیمات این قسمت در فایل خصوصی ذخیره می‌شود؛ دیتابیس سایت تغییر نمی‌کند.</p>
      <form method="post">
        <input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>">
        <input type="hidden" name="action" value="save_v22_security">
        <div class="server-grid">
          <div><label>سقف درخواست‌های واقعی انتخابی هر نصب / دقیقه</label><input type="number" min="1" max="300" name="limit_per_minute" value="<?= (int)$bmV22Policy['limit_per_minute'] ?>"></div>
          <div><label>سقف کلی ضداسپم IP / یک دقیقه (مستقل از سهمیه عملیات واقعی)</label><input type="number" min="20" max="20000" name="ip_limit_per_minute" value="<?= (int)$bmV22Policy['ip_limit_per_minute'] ?>"></div>
          <div><label>سقف جست‌وجوی زنده IP / یک دقیقه (خارج از سهمیه اصلی)</label><input type="number" min="10" max="1200" name="live_search_ip_limit" value="<?= (int)$bmV22Policy['live_search_ip_limit'] ?>"></div>
          <div><label>درخواست ثبت دستگاه / IP در پنج دقیقه</label><input type="number" min="1" max="2000" name="register_ip_limit" value="<?= (int)$bmV22Policy['register_ip_limit'] ?>"></div>
          <div><label>تمدید توکن / دستگاه در یک دقیقه</label><input type="number" min="1" max="30" name="register_device_limit" value="<?= (int)$bmV22Policy['register_device_limit'] ?>"></div>
          <div><label>اعتبار توکن</label><input type="text" value="۳۰ دقیقه (ثابت و امن)" disabled></div>
        </div>
        <p class="desc">📌 این عدد، سهمیه <b>درخواست‌های واقعی API</b> است: بازکردن جزئیات فیلم و سریال، ورود به کالکشن، ژانر و فهرست انتخابی، نتایج جست‌وجوی پیشرفته، بخش‌های انتخاب‌شده «چی ببینیم؟»، ورود و ثبت‌نام، انتخاب آواتار، خواندن و تغییر واچ‌لیست و ثبت دیدگاه. باز شدن صفحه اصلی، پوستر، بارگذاری خودکار، دریافت تنظیمات و اعلان، صفحه‌بندی و همگام‌سازی خودکار سهمیه اصلی را کم نمی‌کنند. این برنامه رویداد کلیک جداگانه ارسال نمی‌کند؛ یک شناسه روی همان درخواست واقعی امضاشده برای جلوگیری از شمارش مجدد ارسال می‌شود. مسیر قدیمی <code dir="ltr">action.php</code> فقط برای سازگاری کاربران نسخه V22.4 پاسخ خالی دارد و سهمیه‌ای مصرف نمی‌کند. سقف مستقل IP همچنان برای محافظت سرور فعال است.</p>
        <div style="margin:14px 0">
          <label class="chk"><input type="checkbox" name="emergency_mode" value="1" <?= !empty($bmV22Policy['emergency_mode'])?'checked':'' ?>> فعال‌کردن حالت اضطراری ارتباط (فقط HTTPS معتبر)</label>
          <label>آدرس‌های HTTPS اضطراری — هر آدرس در یک خط</label>
          <textarea name="emergency_base_urls" rows="3" dir="ltr" placeholder="https://emergency.example.com"><?= bm_h(implode("\n",(array)$bmV22Policy['emergency_base_urls'])) ?></textarea>
        </div>
        <div style="margin:14px 0">
          <label class="chk"><input type="checkbox" name="http_video_fallback" value="1" <?= !empty($bmV22Policy['http_video_fallback'])?'checked':'' ?>> اجازه تلاش HTTP فقط برای پخش رسانهٔ خارجی بدون توکن (پیش‌فرض خاموش)</label>
          <label>دامنه‌های مجاز HTTP پخش — هر خط یک میزبان یا * برای همهٔ دامنه‌های خارجی</label>
          <textarea name="video_http_hosts" rows="3" dir="ltr" placeholder="cdn.example.com"><?= bm_h(implode("\n",(array)$bmV22Policy['video_http_hosts'])) ?></textarea>
        </div>
        <p class="desc">HTTP فقط برای ویدئوی خارجیِ بدون توکن و بعد از اثبات خطای TLS، در پلیر داخلی مجاز است. علامت * دامنه‌های خارجی بیشتری را پوشش می‌دهد و خطر شنود/دستکاری پخش را افزایش می‌دهد. API و حساب همیشه HTTPS هستند.</p>
        <p class="desc">برای جلوگیری از دورزدن سهمیه، تمام APIهای محافظت‌شده باید از یک درگاه مرکزی عبور کنند. تنظیم HTTP مربوط به پلیر است، نه API. برای Nginx بستن دسترسی به پوشه <code>.private</code> را جداگانه انجام بده.</p>
        <button class="btn green" type="submit">ذخیره تنظیمات امنیت V22</button>
      </form>
    </div>

    <div>
      <div class="card" id="quick-version">
        <div class="section-heading"><span class="section-icon">⚡</span><h2>عملیات سریع نسخه 1.3</h2></div>
        <p class="desc">پیش از مسدودکردن، حداقل لینک Universal یا لینک‌های ARM را ثبت کن.</p>
        <div class="quick">
          <?php if (!$blocked13): ?>
          <form method="post"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="block_13"><button class="btn red" type="submit">غیرفعال‌کردن 1.3</button></form>
          <?php else: ?>
          <form method="post"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="unblock_13"><button class="btn green" type="submit">فعال‌کردن دوباره 1.3</button></form>
          <?php endif; ?>
        </div>
      </div>

      <div class="card" id="public-output">
        <div class="section-heading"><span class="section-icon">🔗</span><h2>خروجی عمومی تنظیمات</h2></div>
        <p class="desc">اپ فایل زیر را می‌خواند. اطلاعات محرمانه‌ای داخل آن قرار نده.</p>
        <a class="btn" href="/app_config.php" target="_blank" rel="noopener">مشاهده app_config.php</a>
      </div>

      <style>
      .bm-push-builder{background:linear-gradient(145deg,rgba(21,34,60,.75),rgba(9,15,27,.85));border:1px solid rgba(61,127,249,.35);border-radius:22px;padding:18px;margin:12px 0}
      .bm-push-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
      .bm-push-builder label{display:block;font-size:13px;font-weight:700;margin-top:10px;color:#e1eaff}
      .bm-push-builder input,.bm-push-builder select,.bm-push-builder textarea{width:100%;box-sizing:border-box;max-width:100%;background:#101928;border:1px solid #344461;border-radius:12px;color:#fff;padding:11px;min-height:42px}
      .bm-push-types{display:flex;flex-wrap:wrap;gap:8px;margin:12px 0}
      .bm-push-types label{display:flex;align-items:center;gap:5px;padding:8px 11px;background:#15233a;border:1px solid #344566;border-radius:12px;margin:0;cursor:pointer}
      .bm-push-types input{width:auto;min-height:0}
      .bm-push-preview{border-radius:17px;border:1px solid #397be2;padding:15px;margin:12px 0;background:linear-gradient(120deg,#152b50,#101723);box-shadow:0 8px 22px #0004}
      .bm-push-preview .bm-push-preview-type{font-size:11px;color:#8fc3ff;margin-bottom:5px}
      .bm-push-cta-sample{display:inline-flex;padding:9px 16px;border-radius:10px;background:linear-gradient(100deg,#2469f3,#539eff);font-weight:bold;margin-top:8px}
      .bm-push-hint{font-size:12px;color:#acbad5;margin-top:8px;line-height:1.8}
      @media(max-width:750px){.bm-push-grid{grid-template-columns:1fr}.bm-push-builder{padding:12px}}
      </style>
      <div class="card" id="push-notification">
        <div class="section-heading"><span class="section-icon">📣</span><h2>Push Notification اپلیکیشن</h2></div>
        <p class="desc">این بخش فقط برای Push اپ است. هیچ پیام جدیدی از اینجا وارد جدول اعلان سایت نمی‌شود و روی وب نمایش داده نخواهد شد. رکوردها فقط برای FCM و fallback خود اپ نگه‌داری می‌شوند و حداکثر ۷ روز عمر دارند.</p>
        <div class="note" style="margin-bottom:12px">وضعیت FCM: <b><?= !empty($bmFcmStatus['ready']) ? 'آماده ✅' : 'تنظیم نشده / خطا ⚠️' ?></b><br><span dir="ltr"><?= bm_h($bmFcmStatus['project_id'] ?? '') ?></span><br>Pushهای ذخیره‌شده: <b><?= (int)$bmPushCount ?></b></div>
        <form method="post" enctype="multipart/form-data" id="bm-push-builder-form">
          <input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>">
          <input type="hidden" name="action" value="send_push_notification">
          <div class="bm-push-builder">
          <label>نوع اعلان</label>
          <div class="bm-push-types">
            <?php foreach (['info'=>'🔔 اطلاعیه','update'=>'⬇ آپدیت','vip'=>'👑 VIP','channel'=>'✈ کانال','promo'=>'📣 تبلیغ','content'=>'▶ محتوا'] as $kind=>$caption): ?>
              <label><input type="radio" name="push_kind" value="<?= bm_h($kind) ?>" <?= $kind==='info'?'checked':'' ?>> <?= bm_h($caption) ?></label>
            <?php endforeach; ?>
          </div>
          <div class="bm-push-grid">
            <div><label>عنوان اعلان *</label><input name="push_title" id="bm-push-title" maxlength="220" value="پیام مدیریت بانک مووی" required></div>
            <div><label>مخاطب</label><select name="push_audience"><option value="all">همه کاربران</option><option value="guest">فقط مهمان</option><option value="member">کاربر واردشده</option><option value="vip">فقط VIP</option><option value="admin">مدیر</option></select></div>
          </div>
          <label>متن پیام *</label><textarea id="bm-push-message" name="push_message" rows="3" required placeholder="توضیح کوتاه و جذاب..."></textarea>
          <div class="bm-push-grid">
            <div><label>متن دکمه اصلی</label><input id="bm-push-cta-label" name="push_cta_label" maxlength="48" placeholder="مثلاً مشاهده فیلم"></div>
            <div><label>لینک مقصد اصلی (HTTPS)</label><input name="push_cta_url" dir="ltr" type="url" placeholder="https://..."></div>
            <div><label>متن دکمه دوم (اختیاری)</label><input name="push_secondary_label" maxlength="48" placeholder="مثلاً جزئیات"></div>
            <div><label>لینک دکمه دوم (HTTPS)</label><input name="push_secondary_url" dir="ltr" type="url" placeholder="https://..."></div>
          </div>
          <label>لینک جایگزین برای اپ‌های قدیمی (اختیاری)</label><input name="push_link" dir="ltr" type="url" placeholder="https://...">
          <div class="bm-push-grid">
            <div><label>آدرس تصویر پوستر (اختیاری)</label><input name="push_image_url" dir="ltr" type="url" placeholder="https://...jpg"></div>
            <div><label>آیکون اعلان</label><select name="push_icon_mode" id="bm-push-icon-mode"><option value="brand">آیکون خود بانک‌مووی (پیشنهادی)</option><option value="svg">SVG سفارشی</option></select></div>
          </div>
          <div id="bm-push-svg-fields" hidden>
            <label>بارگذاری SVG سفارشی</label><input type="file" name="push_icon_file" accept=".svg,image/svg+xml">
            <label>یا کد SVG را وارد کن</label><textarea name="push_icon_svg" rows="4" dir="ltr" placeholder="&lt;svg viewBox=&quot;0 0 24 24&quot;&gt;...&lt;/svg&gt;"></textarea>
            <div class="bm-push-hint">فقط اشکال برداری بی‌خطر پذیرفته می‌شود؛ اسکریپت، CSS، لینک خارجی و رویدادها حذف/رد می‌شوند. آیکون نوار اعلان اندروید همیشه نسخه تک‌رنگ بانک‌مووی است.</div>
          </div>
          <div class="bm-push-grid">
            <div><label>شروع نمایش (اختیاری)</label><input name="push_starts_at" type="datetime-local"><small class="bm-push-hint">ارسال زمان‌دار هنگام اولین بررسی بعد از موعد انجام می‌شود.</small></div>
            <div><label>انقضا</label><select name="push_expires_days"><option value="1">۱ روز</option><option value="3">۳ روز</option><option value="7" selected>۷ روز</option></select></div>
          </div>
          <div class="bm-push-preview" aria-live="polite"><div class="bm-push-preview-type">BANKMOVIE / اعلان جدید</div><b id="bm-push-preview-title">پیام مدیریت بانک مووی</b><p id="bm-push-preview-message">متن اعلان اینجا پیش‌نمایش داده می‌شود</p><span class="bm-push-cta-sample" id="bm-push-preview-cta">مشاهده</span></div>
          <button class="btn green" type="submit" style="width:100%;font-weight:800"><i class="fas fa-paper-plane"></i> ثبت و ارسال اعلان</button>
          </div>
        </form>
        <script>
        (function(){
          const form=document.getElementById('bm-push-builder-form');if(!form)return;
          const update=()=>{
            document.getElementById('bm-push-preview-title').textContent=form.elements.push_title.value||'اعلان بانک‌مووی';
            document.getElementById('bm-push-preview-message').textContent=form.elements.push_message.value||'متن اعلان اینجا پیش‌نمایش داده می‌شود';
            document.getElementById('bm-push-preview-cta').textContent=form.elements.push_cta_label.value||'مشاهده';
            document.getElementById('bm-push-svg-fields').hidden=form.elements.push_icon_mode.value!=='svg';
          };
          form.addEventListener('input',update);form.addEventListener('change',update);update();
        })();
        </script>

        <div style="margin-top:18px;border-top:1px solid rgba(255,255,255,.08);padding-top:14px">
          <div class="section-heading" style="margin-bottom:8px"><span class="section-icon">🗂️</span><h2 style="font-size:17px">مدیریت Pushها</h2></div>
          <?php if (!$bmPushRows): ?>
            <div class="audit-item">Push ذخیره‌شده‌ای وجود ندارد.</div>
          <?php endif; ?>
          <?php foreach ($bmPushRows as $push): ?>
            <?php
              $pushStatus=(string)($push['status']??'stored');
              $statusText=$pushStatus==='sent'?'ارسال شد ✅':($pushStatus==='fcm_failed'?'FCM ناموفق ⚠️':($pushStatus==='fallback'?'Fallback فعال 🟡':'ذخیره شده'));
            ?>
            <div class="audit-item" style="margin-bottom:9px">
              <div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start;flex-wrap:wrap">
                <div style="min-width:0;flex:1">
                  <b><?= bm_h($push['title'] ?? 'Push') ?></b> <small> <?= bm_h($push['kind'] ?? 'info') ?> · <?= bm_h($push['audience'] ?? 'all') ?></small>
                  <?php if (!empty($push['icon_svg'])): ?><img alt="آیکون اعلان" src="data:image/svg+xml;base64,<?= base64_encode((string)$push['icon_svg']) ?>" style="display:inline-block;width:32px;height:32px;vertical-align:middle;padding:4px;border-radius:10px;background:#213354" /><?php endif; ?>
                  <small style="display:block;color:#9ca3af;margin-top:3px"><?= bm_h($statusText) ?> · <?= bm_h($push['created_at'] ?? '') ?></small>
                  <div style="margin-top:7px;white-space:pre-wrap"><?= bm_h($push['message'] ?? '') ?></div>
                  <?php if(trim((string)($push['link']??''))!==''): ?><small dir="ltr" style="display:block;margin-top:6px;color:#7dd3fc;overflow-wrap:anywhere"><?= bm_h($push['link']) ?></small><?php endif; ?>
                </div>
                <div class="quick" style="gap:6px;flex-wrap:wrap">
                  <form method="post"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="resend_push_notification"><input type="hidden" name="push_id" value="<?= (int)$push['id'] ?>"><button class="btn" type="submit">ارسال مجدد</button></form>
                  <form method="post" onsubmit="return confirm('این Push حذف شود؟')"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="delete_push_notification"><input type="hidden" name="push_id" value="<?= (int)$push['id'] ?>"><button class="btn red" type="submit">حذف</button></form>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>

        <form method="post" style="margin-top:10px" onsubmit="return confirm('همه Pushهای ذخیره‌شده حذف شوند؟')">
          <input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>">
          <input type="hidden" name="action" value="clear_push_notifications">
          <button class="btn red" type="submit" style="width:100%"><i class="fas fa-trash"></i> حذف همه Pushهای ذخیره‌شده</button>
        </form>
        <form method="post" style="margin-top:10px" onsubmit="return confirm('اعلان‌های قدیمی داخل اپ و رکوردهای Read/Dismiss اپ حذف و جدول‌ها فشرده شوند؟ اعلان‌های سایت دست‌نخورده می‌مانند.')">
          <input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>">
          <input type="hidden" name="action" value="cleanup_notifications">
          <button class="btn red" type="submit" style="width:100%"><i class="fas fa-broom"></i> پاکسازی اعلان‌های قدیمی اپ</button>
        </form>
      </div>

      <div class="card" id="pending-comments">
        <div class="section-heading"><span class="section-icon">💬</span><h2>دیدگاه‌های در انتظار اپ و سایت</h2></div>
        <p class="desc">دیدگاه‌های دیتابیس اصلی و همه آرشیوهای خارجی از همین‌جا تأیید می‌شوند.</p>
        <?php if (!$bmPendingComments): ?>
          <div class="audit-item">دیدگاه در انتظاری وجود ندارد.</div>
        <?php endif; ?>
        <?php foreach ($bmPendingComments as $comment): ?>
          <div class="audit-item comment-item">
            <b><?= bm_h($comment['user_name'] ?? 'کاربر') ?></b>
            <small style="display:block;color:#9ca3af"><?php if(!empty($comment['movie_url'])): ?><a href="<?= bm_h($comment['movie_url']) ?>" target="_blank" rel="noopener" style="color:var(--accent);font-weight:800;text-decoration:none"><?= bm_h($comment['movie_title'] ?? 'مشاهده فیلم') ?></a><?php else: ?><?= bm_h($comment['movie_title'] ?? 'محتوای مرتبط') ?><?php endif; ?> · <?= bm_h($comment['created_at'] ?? '') ?></small>
            <div style="margin:8px 0"><?= bm_h(bm_comment_media_admin_label((string)($comment['comment'] ?? ''))) ?></div>
            <div class="quick" style="gap:6px;flex-wrap:wrap">
              <?php if(!empty($comment['movie_url'])): ?><a class="btn" href="<?= bm_h($comment['movie_url']) ?>" target="_blank" rel="noopener">مشاهده و پاسخ</a><?php endif; ?>
              <form method="post"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="comment_approve"><input type="hidden" name="comment_id" value="<?= (int)$comment['id'] ?>"><input type="hidden" name="comment_source" value="<?= bm_h($comment['comment_source']) ?>"><button class="btn green" type="submit">تأیید</button></form>
              <form method="post"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="comment_reject"><input type="hidden" name="comment_id" value="<?= (int)$comment['id'] ?>"><input type="hidden" name="comment_source" value="<?= bm_h($comment['comment_source']) ?>"><button class="btn red" type="submit">رد</button></form>
              <form method="post" onsubmit="return confirm('دیدگاه حذف شود؟')"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="comment_delete"><input type="hidden" name="comment_id" value="<?= (int)$comment['id'] ?>"><input type="hidden" name="comment_source" value="<?= bm_h($comment['comment_source']) ?>"><button class="btn red" type="submit">حذف</button></form>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="card" id="recent-comments">
        <div class="section-heading"><span class="section-icon">✅</span><h2>دیدگاه‌های تأییدشده اخیر</h2></div>
        <p class="desc">پین، اسپویلر و حذف از همین بخش انجام می‌شود.</p>
        <?php if(!$bmRecentComments): ?><div class="audit-item">دیدگاهی وجود ندارد.</div><?php endif; ?>
        <?php foreach($bmRecentComments as $comment): ?>
          <div class="audit-item comment-item">
            <b><?= bm_h($comment['user_name']??'کاربر') ?></b>
            <small style="display:block;color:#9ca3af"><?php if(!empty($comment['movie_url'])): ?><a href="<?= bm_h($comment['movie_url']) ?>" target="_blank" rel="noopener" style="color:var(--accent);font-weight:800;text-decoration:none"><?= bm_h($comment['movie_title']??'مشاهده فیلم') ?></a><?php else: ?><?= bm_h($comment['movie_title']??'محتوای مرتبط') ?><?php endif; ?> · <?= bm_h($comment['created_at']??'') ?></small>
            <div style="margin:8px 0"><?= bm_h(bm_comment_media_admin_label((string)($comment['comment']??''))) ?></div>
            <div class="quick" style="gap:6px;flex-wrap:wrap">
              <?php if(!empty($comment['movie_url'])): ?><a class="btn" href="<?= bm_h($comment['movie_url']) ?>" target="_blank" rel="noopener">مشاهده و پاسخ</a><?php endif; ?>
              <form method="post"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="<?= !empty($comment['is_pinned'])?'comment_unpin':'comment_pin' ?>"><input type="hidden" name="comment_id" value="<?= (int)$comment['id'] ?>"><input type="hidden" name="comment_source" value="<?= bm_h($comment['comment_source']) ?>"><button class="btn" type="submit"><?= !empty($comment['is_pinned'])?'برداشتن پین':'پین' ?></button></form>
              <form method="post"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="<?= !empty($comment['spoiler'])?'comment_unspoiler':'comment_spoiler' ?>"><input type="hidden" name="comment_id" value="<?= (int)$comment['id'] ?>"><input type="hidden" name="comment_source" value="<?= bm_h($comment['comment_source']) ?>"><button class="btn" type="submit"><?= !empty($comment['spoiler'])?'حذف اسپویلر':'علامت اسپویلر' ?></button></form>
              <form method="post" onsubmit="return confirm('دیدگاه حذف شود؟')"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="comment_delete"><input type="hidden" name="comment_id" value="<?= (int)$comment['id'] ?>"><input type="hidden" name="comment_source" value="<?= bm_h($comment['comment_source']) ?>"><button class="btn red" type="submit">حذف</button></form>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="card" id="comment-reports">
        <div class="section-heading"><span class="section-icon">🚩</span><h2>گزارش‌های تخلف کامنت</h2></div>
        <p class="desc">این بخش فقط گزارش محتوای کامنت است؛ گزارش خرابی لینک عمداً در این نسخه اضافه نشده.</p>
        <?php if(!$bmOpenCommentReports): ?><div class="audit-item">گزارش بازی وجود ندارد.</div><?php endif; ?>
        <?php foreach($bmOpenCommentReports as $report): ?>
          <div class="audit-item comment-item">
            <b><?= bm_h($report['reporter_name']??'کاربر') ?> — <?= bm_h($report['reason']??'other') ?></b>
            <small style="display:block;color:#9ca3af">دیدگاه #<?= (int)$report['comment_id'] ?> · آرشیو <?= (int)$report['archive_no'] ?> · <?= bm_h($report['created_at']??'') ?></small>
            <?php if(!empty($report['details'])): ?><div style="margin:8px 0"><?= bm_h($report['details']) ?></div><?php endif; ?>
            <div class="quick">
              <form method="post"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="comment_report_resolve"><input type="hidden" name="report_id" value="<?= (int)$report['id'] ?>"><button class="btn green" type="submit">رسیدگی شد</button></form>
              <form method="post"><input type="hidden" name="bm_admin_csrf" value="<?= bm_h(bm_csrf_token()) ?>"><input type="hidden" name="action" value="comment_report_reject"><input type="hidden" name="report_id" value="<?= (int)$report['id'] ?>"><button class="btn red" type="submit">رد گزارش</button></form>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="card" id="audit-log">
        <div class="section-heading"><span class="section-icon">🧾</span><h2>آخرین فعالیت‌های مدیریت</h2></div>
        <div class="audit">
          <?php if (!$audits): ?><div class="audit-item">هنوز گزارشی ثبت نشده است.</div><?php endif; ?>
          <?php foreach ($audits as $row): ?>
            <div class="audit-item"><b><?= bm_h($row['action'] ?? '') ?></b><br><?= bm_h($row['admin'] ?? '') ?> — <?= bm_h($row['time'] ?? '') ?></div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</div>
  </main>
</div>

<script>
const bmNavLinks = [...document.querySelectorAll('.sidebar-nav a[href^="#"]')];
const bmSections = bmNavLinks.map(link => document.querySelector(link.getAttribute('href'))).filter(Boolean);
const bmObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (!entry.isIntersecting) return;
    bmNavLinks.forEach(link => link.classList.toggle('active', link.getAttribute('href') === '#' + entry.target.id));
  });
}, {rootMargin:'-25% 0px -65% 0px',threshold:0});
bmSections.forEach(section => bmObserver.observe(section));

async function checkBmContentMirrorV20(index, button) {
  const display = button.closest('.server-row')?.querySelector('.bm-mirror-health-output');
  if (!display) return;
  button.disabled = true;
  display.textContent = 'در حال آزمایش مسیرهای واقعی آرشیو...';
  try {
    const params = new URLSearchParams({
      action: 'check_content_mirror_v20',
      server_index: String(index),
      bm_admin_csrf: <?= json_encode(bm_csrf_token(), JSON_UNESCAPED_SLASHES) ?>
    });
    const response = await fetch(location.pathname, {method:'POST', body:params, credentials:'same-origin'});
    const data = await response.json();
    if (!data.success) { display.textContent = data.message || 'بررسی امکان‌پذیر نبود'; return; }
    display.replaceChildren();
    (data.checks || []).forEach(row => {
      const line = document.createElement('div');
      line.style.color = row.status === 'healthy' ? '#86efac' :
        row.status === 'auth' ? '#fbbf24' : '#fca5a5';
      line.textContent = row.label + ' — ' + row.text;
      display.appendChild(line);
    });
    const note = document.createElement('small');
    note.textContent = data.note || '';
    display.appendChild(note);
  } catch (err) {
    display.textContent = 'اتصال بررسی در دسترس نیست؛ مجوز نشست یا اتصال سرور را بررسی کن.';
  } finally { button.disabled = false; }
}

let nextServerIndex = <?= count($servers) ?>;
let nextRewriteIndex = <?= count($rewrites) ?>;

function addServerRow() {
  const i = nextServerIndex++;
  const wrap = document.createElement('div');
  wrap.className = 'server-row';
  wrap.innerHTML = `
    <div class="server-grid">
      <div><label>نام سرور</label><input name="server_name[${i}]" value="سرور ${i + 1}"></div>
      <div><label>دامنه محتوا</label><input name="server_domain[${i}]" dir="ltr" placeholder="https://server.example.com"></div>
      <div><label>آدرس API</label><input name="server_api[${i}]" dir="ltr" placeholder="https://server.example.com/app_api.php"></div>
      <div><label>اولویت</label><input type="number" min="1" name="server_priority[${i}]" value="${i + 1}"></div>
    </div>
    <div class="mini-actions">
      <label class="chk"><input type="checkbox" name="server_enabled[${i}]" value="1" checked> فعال</label>
      <button type="button" class="remove-row" onclick="this.closest('.server-row').remove()">حذف ردیف</button>
    </div>`;
  document.getElementById('serverRows').appendChild(wrap);
}

function addRewriteRow() {
  const i = nextRewriteIndex++;
  const wrap = document.createElement('div');
  wrap.className = 'rewrite-row';
  wrap.innerHTML = `
    <div class="rewrite-grid">
      <div><label>دامنه/عبارت قدیمی</label><input name="rewrite_from[${i}]" dir="ltr" placeholder="OLDTOWNS"></div>
      <div><label>دامنه مقصد</label><input name="rewrite_to[${i}]" dir="ltr" placeholder="https://new.example.com"></div>
      <div><label>نوع عملیات</label><select name="rewrite_mode[${i}]"><option value="active">استفاده از سرور فعال</option><option value="replace">جایگزینی دامنه</option></select></div>
    </div>
    <div class="mini-actions">
      <label class="chk"><input type="checkbox" name="rewrite_enabled[${i}]" value="1" checked> فعال</label>
      <button type="button" class="remove-row" onclick="this.closest('.rewrite-row').remove()">حذف ردیف</button>
    </div>`;
  document.getElementById('rewriteRows').appendChild(wrap);
}
</script>
<script>
(() => {
  const root = document.documentElement;
  const sidebar = document.getElementById('bmAdminSidebar');
  const toggle = document.getElementById('bmAdminMenuToggle');
  const backdrop = document.getElementById('bmAdminSidebarBackdrop');
  const setSidebar = open => {
    sidebar?.classList.toggle('is-open', open);
    if (backdrop) { backdrop.hidden = !open; backdrop.classList.toggle('is-open', open); }
    document.body.classList.toggle('bm-admin-menu-open', open);
  };
  toggle?.addEventListener('click', () => setSidebar(!sidebar?.classList.contains('is-open')));
  backdrop?.addEventListener('click', () => setSidebar(false));
  document.querySelectorAll('.sidebar-nav a').forEach(a => a.addEventListener('click', () => {
    if (window.innerWidth <= 980) setSidebar(false);
  }));

  const themes = {
    neon: ['#2dd4bf','#0f766e'],
    purple: ['#a78bfa','#6d28d9'],
    red: ['#fb7185','#be123c'],
    gold: ['#fbbf24','#b45309']
  };
  const applyTheme = name => {
    const pair = themes[name] || themes.neon;
    root.style.setProperty('--accent', pair[0]);
    root.style.setProperty('--accent-dark', pair[1]);
    localStorage.setItem('bm-admin-theme', name);
    document.querySelectorAll('.theme-chip').forEach(chip => chip.classList.toggle('active', chip.dataset.theme === name));
  };
  document.querySelectorAll('.theme-chip').forEach(chip => chip.addEventListener('click', () => applyTheme(chip.dataset.theme || 'neon')));
  applyTheme(localStorage.getItem('bm-admin-theme') || 'neon');

  // V7.43.1: selecting Disabled is a hard-hide action. Mirror that intent
  // immediately in the UI so the checkbox cannot misleadingly stay enabled.
  document.querySelectorAll('.section-control-row').forEach(row => {
    const select = row.querySelector('select[name*="_scope"]');
    const checkbox = row.querySelector('input[type="checkbox"][name*="_enabled"]');
    if (!select || !checkbox) return;
    const sync = () => {
      if (select.value === 'disabled') checkbox.checked = false;
    };
    select.addEventListener('change', sync);
    sync();
  });
})();
</script>
<script src="/assets/js/bm-archive-sort-manager-v1.js?v=20261105-bm19" defer></script>
</body>
</html>
