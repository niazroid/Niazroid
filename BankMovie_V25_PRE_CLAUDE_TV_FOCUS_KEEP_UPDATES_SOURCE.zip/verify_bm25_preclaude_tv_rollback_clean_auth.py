#!/usr/bin/env python3
"""Regression guards for rollback of the second-AI TV Home cache/focus change.
    Structural checks do NOT replace a real Android TV D-pad test.
"""
from pathlib import Path
import hashlib
root=Path(__file__).resolve().parent
src=root/'app/src/main/java/ir/bankmoviee/app'
main=(src/'MainActivity.kt').read_text(encoding='utf-8')
auth=(src/'AuthActivity.kt').read_text(encoding='utf-8')
loader=(src/'ThemeWindowLoadingView.kt').read_text(encoding='utf-8')
gradle=(root/'app/build.gradle').read_text(encoding='utf-8')
assert hashlib.sha256((src/'MainActivity.kt').read_bytes()).hexdigest()=="c130adbef9dccccb3ce141ff1aef8034c72fdbc10e810a58a72407ca6965bb97", "MainActivity changed from pre-Claude baseline"
remember=main.split('private fun rememberHomeForSession()',1)[1].split('private fun tryRestoreHomeSession()',1)[0]
restore=main.split('private fun tryRestoreHomeSession()',1)[1].split('private fun restoreRetainedNavigationScreen(',1)[0]
assert 'retainedHomeSession = null' in remember and 'if (isTvLike())' in remember
assert 'retainedHomeSession = null' in restore and 'if (isTvLike())' in restore
assert 'private fun animateTvPosterRailFocus(' not in main
assert 'showTvWatchPartyNumericJoinDialog' in main
assert 'archive != 1 && archive != 2' in main
assert 'bm_auth_submit_spinner' in auth
assert 'ThemeWindowLoadingView(this@AuthActivity)' in auth
assert 'setIndicatorColor(palette.onPrimary)' in auth
assert 'submit?.isClickable = !value' in auth
assert 'fun setIndicatorColor(color: Int)' in loader
assert 'BANKMOVIE_SIGNING_STORE_PASSWORD' in gradle and 'bankmovieSigningConfigured' in gradle
print('PRE_CLAUDE_TV_ROLLBACK_AND_CLEAN_AUTH_VERIFIED')
