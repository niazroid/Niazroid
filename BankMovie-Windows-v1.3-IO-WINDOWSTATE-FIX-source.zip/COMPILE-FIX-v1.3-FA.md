# اصلاح کامپایل نسخه 1.3

- تمام Path/File/Directory به صورت صریح با System.IO نوشته شدند.
- شرط ToggleMaximize پلیر با مقایسه صحیح WindowState اصلاح شد.
- نام سورس مورد انتظار Workflow ثابت است.
