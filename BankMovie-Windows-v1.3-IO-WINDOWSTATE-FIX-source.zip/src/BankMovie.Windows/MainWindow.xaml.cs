using System.Diagnostics;
using System.Text.Json;
using System.Windows;
using System.Windows.Input;
using BankMovie.Windows.Models;
using BankMovie.Windows.Services;
using Microsoft.Web.WebView2.Core;
using Microsoft.Win32;

namespace BankMovie.Windows;

public partial class MainWindow : Window
{
    private readonly AppConfig _config = ConfigService.Load();
    private bool _webReady;

    private const string DesktopBridgeScript = """
(() => {
  if (window.__bmWindowsBridgeInstalled) return;
  window.__bmWindowsBridgeInstalled = true;
  document.documentElement.classList.add('bm-windows-app');

  const style = document.createElement('style');
  style.textContent = `
    .bm-windows-app [data-pwa-install],
    .bm-windows-app #installPwaButton,
    .bm-windows-app .pwa-install-button,
    .bm-windows-app .install-app-btn { display:none !important; }
  `;
  document.documentElement.appendChild(style);

  const playSelector = [
    '.bm-local-play-choice',
    '.bm-download-play-choice',
    '.bm-poster-play',
    '.arc1-play-btn',
    '.arc1-play-inline[data-url]',
    '[data-direct-player="1"][data-url]'
  ].join(',');

  function safeText(v) { return String(v || '').trim(); }
  function nearestText(el, selector) {
    try {
      const row = el.closest('.arc1-link-row,.download-link,.premium-download-card,.movie-detail,.movie-hero');
      const node = row && row.querySelector(selector);
      return node ? safeText(node.textContent).replace(/\s+/g, ' ') : '';
    } catch (_) { return ''; }
  }
  function resolvePlay(target) {
    let url = safeText(target.getAttribute('data-url'));
    if (!url && target.tagName === 'A') url = safeText(target.getAttribute('href'));
    if (!url && typeof window.bmGetCurrentMoviePlayUrl === 'function') {
      try { url = safeText(window.bmGetCurrentMoviePlayUrl()); } catch (_) {}
    }
    let subtitleUrl = safeText(target.getAttribute('data-subtitle-url'));
    if (!subtitleUrl && url && typeof window.bmFindSubtitleForVideoUrl === 'function') {
      try { subtitleUrl = safeText(window.bmFindSubtitleForVideoUrl(url)); } catch (_) {}
    }
    let label = safeText(target.getAttribute('data-label'));
    if (!label) label = [nearestText(target,'.quality,.bm-archive2-quality-halo'), nearestText(target,'.download-type-badge')].filter(Boolean).join(' · ');
    if (!label) label = safeText(document.querySelector('h1,.movie-title,.hero-title')?.textContent) || document.title || 'BankMovie Player';
    return { url, subtitleUrl, label };
  }
  function isHttpUrl(value) {
    try { const u = new URL(value, location.href); return u.protocol === 'http:' || u.protocol === 'https:'; }
    catch (_) { return false; }
  }
  function sendPlay(target, event) {
    const item = resolvePlay(target);
    if (!isHttpUrl(item.url)) return false;
    event.preventDefault();
    event.stopPropagation();
    if (event.stopImmediatePropagation) event.stopImmediatePropagation();
    try {
      window.chrome.webview.postMessage({
        type: 'play',
        url: new URL(item.url, location.href).href,
        subtitleUrl: item.subtitleUrl ? new URL(item.subtitleUrl, location.href).href : '',
        label: item.label,
        referer: location.href,
        userAgent: navigator.userAgent
      });
      return true;
    } catch (_) { return false; }
  }
  document.addEventListener('click', event => {
    const target = event.target && event.target.closest ? event.target.closest(playSelector) : null;
    if (target) sendPlay(target, event);
  }, true);

  window.addEventListener('keydown', event => {
    if (event.ctrlKey && event.key.toLowerCase() === 'l') {
      event.preventDefault();
      window.chrome.webview.postMessage({ type:'open-manual-player' });
    }
  });
})();
""";

    public MainWindow()
    {
        InitializeComponent();
        Browser.DefaultBackgroundColor = System.Drawing.Color.FromArgb(5, 7, 12);
        Loaded += MainWindow_Loaded;
    }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        await InitializeBrowserAsync();
    }

    private async Task InitializeBrowserAsync()
    {
        try
        {
            var dataDir = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "BankMovie", "WebView2");
            System.IO.Directory.CreateDirectory(dataDir);
            var environment = await CoreWebView2Environment.CreateAsync(userDataFolder: dataDir);
            await Browser.EnsureCoreWebView2Async(environment);

            Browser.CoreWebView2.Settings.AreDefaultContextMenusEnabled = true;
            Browser.CoreWebView2.Settings.AreDevToolsEnabled = false;
            Browser.CoreWebView2.Settings.IsStatusBarEnabled = false;
            Browser.CoreWebView2.Settings.IsZoomControlEnabled = true;
            Browser.CoreWebView2.Settings.AreBrowserAcceleratorKeysEnabled = true;

            await Browser.CoreWebView2.AddScriptToExecuteOnDocumentCreatedAsync(DesktopBridgeScript);
            Browser.CoreWebView2.WebMessageReceived += CoreWebView2_WebMessageReceived;
            Browser.CoreWebView2.NavigationStarting += CoreWebView2_NavigationStarting;
            Browser.CoreWebView2.NavigationCompleted += CoreWebView2_NavigationCompleted;
            Browser.CoreWebView2.DocumentTitleChanged += (_, _) => Dispatcher.Invoke(() => PageTitle.Text = Browser.CoreWebView2.DocumentTitle ?? "بانک مووی");
            Browser.CoreWebView2.HistoryChanged += (_, _) => Dispatcher.Invoke(UpdateHistoryButtons);
            Browser.CoreWebView2.NewWindowRequested += CoreWebView2_NewWindowRequested;
            Browser.CoreWebView2.DownloadStarting += CoreWebView2_DownloadStarting;
            Browser.CoreWebView2.ProcessFailed += (_, _) => Dispatcher.Invoke(() => ShowOffline());

            _webReady = true;
            Navigate(_config.SiteUrl);
        }
        catch (Exception ex)
        {
            ShowOffline();
            MessageBox.Show("WebView2 راه‌اندازی نشد:\n" + ex.Message, "BankMovie", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private async void CoreWebView2_WebMessageReceived(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
    {
        try
        {
            var message = JsonSerializer.Deserialize<WebBridgeMessage>(e.WebMessageAsJson, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            if (message?.Type == "open-manual-player")
            {
                OpenManualPlayer();
                return;
            }
            if (message?.Type != "play" || !IsSafeMediaUrl(message.Url)) return;

            var cookieHeader = await GetCookieHeaderAsync(message.Url!);
            var request = new PlaybackRequest
            {
                Url = message.Url!,
                SubtitleUrl = IsSafeMediaUrl(message.SubtitleUrl) ? message.SubtitleUrl : null,
                Title = message.Label,
                Referer = IsSafeMediaUrl(message.Referer) ? message.Referer : Browser.Source?.ToString(),
                UserAgent = message.UserAgent,
                CookieHeader = cookieHeader
            };
            OpenPlayer(request);
        }
        catch (Exception ex)
        {
            MessageBox.Show("لینک پخش قابل بازکردن نبود.\n" + ex.Message, "BankMovie Player", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private async Task<string?> GetCookieHeaderAsync(string url)
    {
        try
        {
            var cookies = await Browser.CoreWebView2.CookieManager.GetCookiesAsync(url);
            return cookies.Count == 0 ? null : string.Join("; ", cookies.Select(c => $"{c.Name}={c.Value}"));
        }
        catch { return null; }
    }

    private void CoreWebView2_NavigationStarting(object? sender, CoreWebView2NavigationStartingEventArgs e)
    {
        LoadingOverlay.Visibility = Visibility.Visible;
        OfflineOverlay.Visibility = Visibility.Collapsed;
        if (!IsInternalNavigation(e.Uri))
        {
            e.Cancel = true;
            OpenExternal(e.Uri);
        }
    }

    private void CoreWebView2_NavigationCompleted(object? sender, CoreWebView2NavigationCompletedEventArgs e)
    {
        LoadingOverlay.Visibility = Visibility.Collapsed;
        if (!e.IsSuccess) ShowOffline();
        else OfflineOverlay.Visibility = Visibility.Collapsed;
        UpdateHistoryButtons();
    }

    private void CoreWebView2_NewWindowRequested(object? sender, CoreWebView2NewWindowRequestedEventArgs e)
    {
        e.Handled = true;
        if (IsInternalNavigation(e.Uri)) Navigate(e.Uri);
        else OpenExternal(e.Uri);
    }

    private void CoreWebView2_DownloadStarting(object? sender, CoreWebView2DownloadStartingEventArgs e)
    {
        try
        {
            var suggested = System.IO.Path.GetFileName(e.ResultFilePath);
            if (string.IsNullOrWhiteSpace(suggested)) suggested = "BankMovie-download";
            var dialog = new SaveFileDialog { FileName = suggested, Title = "ذخیره فایل بانک مووی" };
            if (dialog.ShowDialog(this) == true)
            {
                e.ResultFilePath = dialog.FileName;
                e.Handled = false;
            }
            else
            {
                e.Cancel = true;
            }
        }
        catch { }
    }

    private void Navigate(string? url)
    {
        if (!_webReady || string.IsNullOrWhiteSpace(url)) return;
        try { Browser.CoreWebView2.Navigate(url); }
        catch { ShowOffline(); }
    }

    private bool IsInternalNavigation(string? value)
    {
        if (!Uri.TryCreate(value, UriKind.Absolute, out var uri)) return false;
        if (uri.Scheme is not ("http" or "https")) return false;
        return _config.AllowedHosts.Any(host => string.Equals(uri.Host, host, StringComparison.OrdinalIgnoreCase));
    }

    private static bool IsSafeMediaUrl(string? value)
    {
        return Uri.TryCreate(value, UriKind.Absolute, out var uri) && uri.Scheme is "http" or "https";
    }

    private static void OpenExternal(string? value)
    {
        if (!Uri.TryCreate(value, UriKind.Absolute, out var uri)) return;
        try { Process.Start(new ProcessStartInfo(uri.ToString()) { UseShellExecute = true }); } catch { }
    }

    private void OpenPlayer(PlaybackRequest request)
    {
        if (App.SharedLibVlc is null)
        {
            MessageBox.Show("موتور پخش داخلی در دسترس نیست.", "BankMovie Player", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        var player = new PlayerWindow(request, _config.Player) { Owner = this };
        player.Show();
    }

    private void OpenManualPlayer()
    {
        var dialog = new OpenMediaWindow { Owner = this };
        if (dialog.ShowDialog() == true && IsSafeMediaUrl(dialog.MediaUrl))
        {
            OpenPlayer(new PlaybackRequest
            {
                Url = dialog.MediaUrl!,
                SubtitleUrl = IsSafeMediaUrl(dialog.SubtitleUrl) ? dialog.SubtitleUrl : null,
                Title = "BankMovie Player",
                Referer = Browser.Source?.ToString(),
                UserAgent = null
            });
        }
    }

    private void ShowOffline()
    {
        LoadingOverlay.Visibility = Visibility.Collapsed;
        OfflineOverlay.Visibility = Visibility.Visible;
    }

    private void UpdateHistoryButtons()
    {
        if (!_webReady) return;
        BackButton.IsEnabled = Browser.CoreWebView2.CanGoBack;
        ForwardButton.IsEnabled = Browser.CoreWebView2.CanGoForward;
    }

    private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ClickCount == 2) ToggleMaximize();
        else if (e.ButtonState == MouseButtonState.Pressed) DragMove();
    }

    private void Back_Click(object sender, RoutedEventArgs e) { if (_webReady && Browser.CoreWebView2.CanGoBack) Browser.CoreWebView2.GoBack(); }
    private void Forward_Click(object sender, RoutedEventArgs e) { if (_webReady && Browser.CoreWebView2.CanGoForward) Browser.CoreWebView2.GoForward(); }
    private void Reload_Click(object sender, RoutedEventArgs e) { if (_webReady) Browser.CoreWebView2.Reload(); }
    private void Home_Click(object sender, RoutedEventArgs e) => Navigate(_config.HomeUrl);
    private void Retry_Click(object sender, RoutedEventArgs e) => Navigate(_config.SiteUrl);
    private void OpenPlayer_Click(object sender, RoutedEventArgs e) => OpenManualPlayer();
    private void Minimize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
    private void Maximize_Click(object sender, RoutedEventArgs e) => ToggleMaximize();
    private void Close_Click(object sender, RoutedEventArgs e) => Close();
    private void ToggleMaximize() => WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
}
