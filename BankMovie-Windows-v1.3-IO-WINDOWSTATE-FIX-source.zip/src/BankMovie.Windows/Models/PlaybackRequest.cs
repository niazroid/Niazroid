namespace BankMovie.Windows.Models;

public sealed class PlaybackRequest
{
    public required string Url { get; init; }
    public string? SubtitleUrl { get; init; }
    public string? Title { get; init; }
    public string? Referer { get; init; }
    public string? UserAgent { get; init; }
    public string? CookieHeader { get; init; }
}

public sealed class WebBridgeMessage
{
    public string? Type { get; set; }
    public string? Url { get; set; }
    public string? SubtitleUrl { get; set; }
    public string? Label { get; set; }
    public string? Referer { get; set; }
    public string? UserAgent { get; set; }
}
