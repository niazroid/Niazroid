namespace BankMovie.Windows.Models;

public sealed class AppConfig
{
    public string SiteUrl { get; set; } = "https://bankmovie.top/?source=windows-app";
    public string HomeUrl { get; set; } = "https://bankmovie.top/?source=windows-app";
    public List<string> AllowedHosts { get; set; } = ["bankmovie.top", "www.bankmovie.top"];
    public PlayerConfig Player { get; set; } = new();
}

public sealed class PlayerConfig
{
    public uint NetworkCachingMs { get; set; } = 2200;
    public bool HardwareDecoding { get; set; } = true;
    public bool RememberPosition { get; set; } = true;
    public bool AutoLoadProvidedSubtitle { get; set; } = true;
}
