namespace BankMovie.Windows.Models;

public sealed record TrackChoice(int Id, string Name)
{
    public override string ToString() => Name;
}
