using System.Windows;

namespace BankMovie.Windows;

public partial class OpenMediaWindow : Window
{
    public string? MediaUrl => MediaUrlBox.Text.Trim();
    public string? SubtitleUrl => SubtitleUrlBox.Text.Trim();

    public OpenMediaWindow()
    {
        InitializeComponent();
        Loaded += (_, _) => MediaUrlBox.Focus();
    }

    private void Play_Click(object sender, RoutedEventArgs e)
    {
        if (!Uri.TryCreate(MediaUrl, UriKind.Absolute, out var uri) || uri.Scheme is not ("http" or "https"))
        {
            MessageBox.Show("لینک ویدیو معتبر نیست.", "BankMovie Player", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        DialogResult = true;
    }

    private void Cancel_Click(object sender, RoutedEventArgs e) => DialogResult = false;
}
