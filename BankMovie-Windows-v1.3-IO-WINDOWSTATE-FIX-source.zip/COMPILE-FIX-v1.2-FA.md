# اصلاح کامپایل v1.2

این نسخه سه خطای تداخل نام میان WPF و Windows Forms را رفع می‌کند:

- `Application` به `System.Windows.Application` صریح شده است.
- `KeyEventArgs` به نوع WPF صریح شده است.
- `MouseEventArgs` به نوع WPF صریح شده است.
- گزینهٔ غیرضروری `UseWindowsForms` از پروژه حذف شده است.

Workflow قبلی ZIP-AUTO-FIX قابل استفاده است.
