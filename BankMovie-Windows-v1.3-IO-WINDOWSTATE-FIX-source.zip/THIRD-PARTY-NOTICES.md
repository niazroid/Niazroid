# Third-party notices

BankMovie Windows uses:

- Microsoft Edge WebView2 SDK — Microsoft
- LibVLCSharp.WPF — VideoLAN, LGPL-2.1-or-later
- VideoLAN.LibVLC.Windows — VideoLAN, LGPL-2.1-or-later

The application source does not modify these libraries. Native runtime files are restored from their official NuGet packages during the GitHub Actions build.
