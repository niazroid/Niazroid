#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
UI="$ROOT/app/src/main/java/ir/bankmoviee/app/UiPreferences.kt"
API="$ROOT/app/src/main/java/ir/bankmoviee/app/AccountApi.kt"
SHIMMER="$ROOT/app/src/main/java/ir/bankmoviee/app/PosterShimmerDrawable.kt"
SERVER="$ROOT/server-required/app_user_api.php"
ONBOARD="$ROOT/app/src/main/java/ir/bankmoviee/app/OnboardingActivity.kt"

for f in "$MAIN" "$UI" "$API" "$SHIMMER" "$SERVER" "$ONBOARD"; do test -s "$f"; done

# Account-persistent app Light/Black mode, separate from website Accent theme.
grep -Fq 'KEY_THEME_SYNC_PENDING' "$UI"
grep -Fq 'KEY_THEME_ACCOUNT_SYNC_INITIALIZED' "$UI"
grep -Fq 'fun saveThemeSelection(context: Context, mode: String, markForAccountSync: Boolean = true)' "$UI"
grep -Fq 'action = "app_theme_update"' "$API"
grep -Fq 'private fun syncAccountAppTheme(context: Context, user: JSONObject): JSONObject' "$API"
grep -Fq 'AccountApi.updateAppTheme(this, "light")' "$MAIN"
grep -Fq 'AccountApi.updateAppTheme(this, "black")' "$MAIN"
grep -Fq 'AccountApi.updateAppTheme(this, theme)' "$ONBOARD"
grep -Fq "ADD COLUMN app_theme_mode" "$SERVER"
grep -Fq "if (\$action === 'app_theme_update')" "$SERVER"
grep -Fq "'app_theme_mode'" "$SERVER"

# Mobile detail artwork is truly edge-to-edge while body retains the legacy inset.
grep -Fq 'if (isTvLike()) setPadding(dp(12), 0, dp(12), dp(30)) else setPadding(0, 0, 0, dp(30))' "$MAIN"
grep -Fq 'private fun applyMobileDetailDirectInsets(page: LinearLayout, edgeToEdgeChild: View, insetDp: Int = 12)' "$MAIN"
grep -Fq 'applyMobileDetailDirectInsets(page, hero)' "$MAIN"
grep -Fq 'val detailBottomBlend = detailPalette.background' "$MAIN"
grep -Fq 'Soft lower cut, matching the Home slider' "$MAIN"

# Light-theme skeleton system is independent from the dark palette.
grep -Fq 'private val lightTheme: Boolean = false' "$SHIMMER"
grep -Fq 'if (lightTheme) Color.rgb(236, 239, 243)' "$SHIMMER"
grep -Fq 'PosterShimmerDrawable(lowEndDevice, skeletonPalette.light)' "$MAIN"
grep -Fq 'private fun collectionGridLoadingSkeleton(columns: Int, rows: Int, collectionStyle: Boolean): View' "$MAIN"
grep -Fq 'collectionGridLoadingSkeleton(if (tv) 5 else 2' "$MAIN"
grep -Fq 'collectionGridLoadingSkeleton(if (tv) 8 else 3' "$MAIN"
grep -Fq 'PosterShimmerDrawable(lowEndDevice, p.light)' "$MAIN"

# Box Office has a real Light surface instead of forcing black.
grep -Fq 'val rowBg = if (p.light) p.panel2 else Color.rgb(22, 30, 42)' "$MAIN"
grep -Fq 'background = ColorDrawable(p.background)' "$MAIN"
grep -Fq 'setBackgroundColor(p.background)' "$MAIN"
grep -Fq 'section.background = rounded(p.card, dp(26), p.stroke)' "$MAIN"
grep -Fq 'background = if (p.light) rounded(p.card, dp(28), p.stroke)' "$MAIN"

php -l "$SERVER" >/dev/null

echo BANKMOVIE_V7471_19_THEME_ACCOUNT_HERO_SKELETON_BOXOFFICE_OK
