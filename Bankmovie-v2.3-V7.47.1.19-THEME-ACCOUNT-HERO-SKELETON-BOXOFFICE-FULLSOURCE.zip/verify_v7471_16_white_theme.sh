#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
ui="$root/app/src/main/java/ir/bankmoviee/app/UiPreferences.kt"
main="$root/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
onboard="$root/app/src/main/java/ir/bankmoviee/app/OnboardingActivity.kt"
offline="$root/app/src/main/java/ir/bankmoviee/app/OfflineLibraryActivity.kt"

grep -q '"light" -> Palette(' "$ui"
grep -q 'background = Color.rgb(250, 250, 251)' "$ui"
grep -q 'text = Color.rgb(17, 18, 20)' "$ui"
grep -Eq 'return when \(raw\)|return when \(raw\?\.trim' "$ui"
grep -q 'var themeMode = UiPreferences.themeMode(this)' "$main"
grep -q 'text = t("پوسته برنامه", "App theme")' "$main"
grep -Eq 'putString\(UiPreferences.KEY_THEME, themeMode\)|AccountApi\.updateAppTheme\(this@MainActivity, themeMode\)' "$main"
grep -q 'theme = UiPreferences.themeMode(this)' "$onboard"
grep -q 'if (p.light) p.panel else p.panel2' "$offline"
if grep -q 'val mode = "black"' "$ui"; then
  echo 'ERROR: light theme is still hard-disabled in UiPreferences' >&2
  exit 1
fi
if grep -q 'emergency_bootstrap' "$root/app/src/main/java/ir/bankmoviee/app"/*.kt 2>/dev/null; then
  echo 'ERROR: emergency bootstrap from V7.47.1.15 leaked into this build' >&2
  exit 1
fi
echo BANKMOVIE_V7471_16_WHITE_THEME_OK
