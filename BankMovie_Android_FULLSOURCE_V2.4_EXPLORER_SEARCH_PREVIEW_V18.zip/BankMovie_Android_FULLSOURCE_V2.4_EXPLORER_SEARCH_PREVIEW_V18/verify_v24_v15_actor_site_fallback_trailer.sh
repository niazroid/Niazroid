#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PYTEST'
from pathlib import Path
import re
import xml.etree.ElementTree as ET

s=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')
res=Path('app/src/main/res/drawable')
ns='{http://schemas.android.com/apk/res/android}'

# Site SVG for missing images: exact movie.php head + shoulders vector, and blue round mask.
site=ET.parse(res/'bm_v15_actor_site_placeholder.xml').getroot()
assert site.tag=='vector'
assert len(site)==2
assert 'M5.5,20c0.5,-4.05' in site[1].get(ns+'pathData','')
assert 'private fun siteActorAvatar(photo: String): FrameLayout' in s
assert 'setImageResource(R.drawable.bm_v15_actor_site_placeholder)' in s
assert 'loadImage(photo, picture)' in s
assert 'fallback.visibility = View.INVISIBLE' in s
assert 'alpha = 0f  // Broken image requests must not cover the fallback.' in s
for needle in [
    'addView(siteActorAvatar(portraitUrl)',
    'row.addView(siteActorAvatar(person.optString("image")',
    'addView(siteActorAvatar(photo)',
    'card.addView(siteActorAvatar(image)',
]:
    assert needle in s, needle

# Clapperboard is the NEW simple 3-stripe icon, not the old V14 angled clapper.
clapper=ET.parse(res/'bm_v15_trailer.xml').getroot()
paths=[p.get(ns+'pathData','') for p in clapper]
assert len(paths)==5, paths
for part in ['M2,7H22','M12,7V3','M7,7V3','M17,7V3']:
    assert part in paths
assert s.count('R.drawable.bm_v15_trailer') >= 3
assert 'setImageResource(R.drawable.ic_trailer)' not in s

# Actor badge uses user-supplied profile_favorite while missing-photo avatar uses site SVG.
profile=ET.parse(res/'bm_v15_cast_favorite.xml').getroot()
assert profile.find('group') is not None
assert profile.find('group').get(ns+'translateY')=='-2039'
assert '-> R.drawable.bm_v15_cast_favorite' in s

# Unwanted V14 icon replacements are rolled back; retain only metadata/promo upgrades.
assert 'R.drawable.bm_v14_' not in s
for icon in [
    'R.drawable.ic_copy_link',
    'R.drawable.ic_download',
    'R.drawable.ic_info_archive',
    'R.drawable.ic_chevron_down',
    'R.drawable.bm_ic_episode_play',
]:
    assert icon in s, icon
assert 'isArchive5Promo(raw)' in s
assert 'archive5_metadata' in s
assert 'if (detailArchive != 5) {' in s
assert not re.search(r'(?<!fun )\bdownloadNotice\s*\(',s)

print('BANKMOVIE_V15_ACTOR_SITE_FALLBACK_TRAILER_OK')
PYTEST
