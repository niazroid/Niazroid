# Bankmovie Glass Redesign — Pass 1

این پاس بر اساس ویدیوی واقعی اپ و کانسپت شماره ۱ انجام شده است.

## تغییرات این پاس
- بازطراحی کامل صفحه جزئیات موبایل با Hero سینمایی و حذف پوستر تکراری شناور.
- افزودن Play Orb شیشه‌ای در Hero.
- نوار یکپارچه امتیاز و متادیتا.
- اکشن‌های دانلود، تریلر/پخش و لیست من با کارت‌های شیشه‌ای هم‌خانواده.
- انتقال خلاصه داستان از Hero شلوغ به کارت مستقل و خواناتر.
- ایجاد Design System پایه برای Glass Surface / Primary Glass / Section / Mini Action.
- هماهنگ‌سازی دکمه‌های شیشه‌ای Detail با Design System جدید.
- شروع یکدست‌سازی مودال دانلود با Shell شیشه‌ای جدید.
- Focus state برای کنترل ریموت/TV در کامپوننت‌های جدید حفظ شده است.

## مسیر اصلی تغییر
`app/src/main/java/ir/bankmoviee/app/MainActivity.kt`

## نکته
این Pass 1 است: هدف اول تثبیت زبان طراحی در Detail و ساخت کامپوننت‌های قابل استفاده مجدد بوده است. در Pass بعدی Drawer، Home cards، Search، Categories، Download modalها، Comments و سایر Dialogها روی همین Design System یکدست می‌شوند.
