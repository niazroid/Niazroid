#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
DL="$ROOT/app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt"
ACCOUNT="$ROOT/app/src/main/java/ir/bankmoviee/app/AccountApi.kt"
USER_API="$ROOT/server-required/app_user_api.php"

for f in "$MAIN" "$DL" "$ACCOUNT" "$USER_API"; do test -s "$f"; done

grep -F 'comment_media_recent_v2' "$MAIN" >/dev/null
grep -F 'private fun commentLoadingSpinner()' "$MAIN" >/dev/null
grep -F '۲۵۰ فیلم برتر IMDb' "$MAIN" >/dev/null
grep -F '۲۵۰ سریال برتر IMDb' "$MAIN" >/dev/null
! grep -F 'text = t("نوع محتوا", "Browse")' "$MAIN" >/dev/null
grep -F 'accountUserIsVip' "$MAIN" >/dev/null
grep -F 'AccountApi.refreshMe(this)' "$MAIN" >/dev/null
grep -F 'marginEnd = dp(16)' "$DL" >/dev/null
grep -F 'fun uploadAvatar' "$ACCOUNT" >/dev/null
grep -F "if (\$action === 'avatar_upload')" "$USER_API" >/dev/null
grep -F "'is_vip' => \$isVip" "$USER_API" >/dev/null
php -l "$USER_API" >/dev/null

# Installed old APKs rely on these legacy files: they must remain byte-identical.
echo '6ef23c64a58ffeb0f60d431f5ccfb7fcdbd75295e1a125b2ce075e0ea0c680e0  '"$ROOT/server-required/api5.php" | sha256sum -c - >/dev/null
echo '9a3357dfda36fe0548ee0049339f56a642c4727122a0c4ffc87b7cdf057ddfdb  '"$ROOT/server-required/api5_lib.php" | sha256sum -c - >/dev/null

# Phase 9.1 Kotlin compile regression guards.
grep -F 'setBackgroundColor(Color.TRANSPARENT)' "$MAIN" >/dev/null
grep -F 'android.view.ViewGroup.LayoutParams.WRAP_CONTENT' "$MAIN" >/dev/null
! grep -F 'scroll.addView(grid, ScrollView.LayoutParams(-1, -2))' "$MAIN" >/dev/null

echo PHASE9_1_VERIFY_OK
