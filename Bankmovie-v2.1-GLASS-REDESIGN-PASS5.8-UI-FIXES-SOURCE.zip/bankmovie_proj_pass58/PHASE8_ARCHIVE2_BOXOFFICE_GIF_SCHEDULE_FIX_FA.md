# Bankmovie V2.1 — Phase 8 Fix Pack

این فاز روی رفع ریشه‌ای Archive 2 و امکانات درخواستی متمرکز است.

## 1) Archive 2 / HTTP 500
- `app_api.php` دیگر `api2_lib.php` و `api3_lib.php` را اشتباه از کنار خودش require نمی‌کند؛ مسیر واقعی `/includes` را resolve می‌کند.
- `action=ping` قبل از اسکرپرها اجرا می‌شود و مستقیماً اتصال دیتابیس سایت را بررسی می‌کند.
- پاسخ ping شامل `database_ready`, `database`, و وضعیت `site_libs` است.
- اتصال Archive 2 همان PDO انتخاب‌شده توسط `config.php` سایت است؛ اسکن خودکار schema حذف شده است.
- Archive 2 در خطای DB دیگر به `advancedSearch()` آرشیو 1 سقوط نمی‌کند.

## 2) Poster / Collection covers
- مسیرهای قدیمی دیتابیس مثل `/home/.../public_html/uploads/...`, `/htdocs/...`, `/www/...` به URL عمومی Bankmovie تبدیل می‌شوند.
- همین canonicalization در API و Android انجام می‌شود.
- کاور کالکشن از `cover_image` دیتابیس استفاده می‌کند و فقط در نبود آن از اولین فیلم کالکشن fallback می‌گیرد.

## 3) Categories مطابق سورس سایت
چهار کارت اصلی از `categories.php` سایت بازسازی شده‌اند:
- ژانرها
- کالکشن‌ها
- 250 فیلم برتر
- 250 سریال برتر

کاورها مستقیماً از `assets/categories` سورس سایت داخل APK کپی شده‌اند.
Top 250 به endpoint واقعی سایت در `api2_lib.php` (`top-movies` / `top-series`) متصل است، نه sort محلی IMDb.

## 4) Box Office
- آیتم Box Office به منوی همبرگری اضافه شد.
- صفحه native با Hero، صدرنشین، فروش آخر هفته، جمع فروش آخر هفته، رتبه، فروش کل و هفته اکران ساخته شد.
- منبع داده: `/api_boxoffice.php` همان سایت.

## 5) Downloader schedule / background
- presetهای مدت‌زمان حذف شدند.
- کاربر ساعت شروع و ساعت پایان را خودش انتخاب می‌کند.
- پایان بازه دانلودهای فعال/صف را Pause می‌کند و partial file حفظ می‌شود.
- شروع بازه صف Scheduled را آزاد می‌کند.
- درخواست دسترسی Exact Alarm و Battery Optimization exemption در صورت نیاز اضافه شده است.
- Boot receiver دیگر dataSync foreground service را مستقیم از BOOT_COMPLETED اجرا نمی‌کند؛ فقط alarmها را restore می‌کند.
- در timeout سرویس dataSync روی Android جدید، صف قبل از stop شدن به حالت قابل Resume می‌رود.

## 6) Comments GIF / stickers
- API اپ marker واقعی سایت `[bm-sticker:pack:id]` را پشتیبانی می‌کند.
- catalog گیف/استیکر از `includes/sticker_packs.php` سایت خوانده می‌شود.
- GIF/animated WebP در Android متحرک و WEBM به صورت loop/muted نمایش داده می‌شود.
- ارسال media-only و text + یک media marker پشتیبانی می‌شود.

## 7) Skeleton loaders
- loaderهای محتوایی به skeleton/shimmer تبدیل شده‌اند.
- Search عمداً loader قبلی خودش را نگه داشته است.
- splash / اولین ورود عمداً تغییر نکرده است.

## فایل‌های اصلی تغییرکرده
- `server-required/app_api.php`
- `server-required/app_user_api.php`
- `app/src/main/java/ir/bankmoviee/app/MainActivity.kt`
- `app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt`
- `app/src/main/java/ir/bankmoviee/app/DownloadScheduleManager.kt`
- `app/src/main/java/ir/bankmoviee/app/InternalDownloadService.kt`
- `app/src/main/java/ir/bankmoviee/app/DownloadBootReceiver.kt`
- `app/src/main/java/ir/bankmoviee/app/AccountApi.kt`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/res/drawable-nodpi/bm_category_*.webp`

## تست قبل از انتشار
`bash verify_phase8.sh`

نکته: HTTP 500 روی دامنه زنده تا وقتی `server-required/app_api.php` جدید در ریشه سایت جایگزین نشود، طبیعتاً تغییر نمی‌کند.
