#!/usr/bin/env bash
set -euo pipefail
PLAYER='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
test -s "$PLAYER"
grep -F 'BANKMOVIE_PASS4_6_2_SOURCE_FINGERPRINT: player-lifecycle-guest-glass-viewgroup-compile-fix' "$PLAYER" >/dev/null
grep -F 'import android.view.ViewGroup' "$PLAYER" >/dev/null
grep -F 'private fun setPlaybackControlTreeEnabled(view: View, enabled: Boolean)' "$PLAYER" >/dev/null
grep -F 'if (view is ViewGroup)' "$PLAYER" >/dev/null
grep -F 'for (i in 0 until view.childCount) setPlaybackControlTreeEnabled(view.getChildAt(i), enabled)' "$PLAYER" >/dev/null
! grep -F 'releaseRtc()' "$PLAYER" >/dev/null
printf 'PASS 4.6.2 ViewGroup compile fix verified.\n'
