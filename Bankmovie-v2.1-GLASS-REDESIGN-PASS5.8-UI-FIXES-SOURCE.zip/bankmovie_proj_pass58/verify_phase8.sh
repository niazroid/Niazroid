#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

php -l server-required/app_api.php >/dev/null
php -l server-required/app_user_api.php >/dev/null

grep -F "bm_app_require_site_lib('api2_lib.php')" server-required/app_api.php >/dev/null
grep -F "bm_app_require_site_lib('api3_lib.php')" server-required/app_api.php >/dev/null
grep -F "database_ready" server-required/app_api.php >/dev/null
grep -F "Strict Archive 2 isolation" server-required/app_api.php >/dev/null
grep -F "bm_app_collection_fallback_cover" server-required/app_api.php >/dev/null
grep -F "comment_media_catalog" server-required/app_user_api.php >/dev/null

grep -F 'private fun showBoxOffice()' app/src/main/java/ir/bankmoviee/app/MainActivity.kt >/dev/null
grep -F 'private fun showCategories()' app/src/main/java/ir/bankmoviee/app/MainActivity.kt >/dev/null
grep -F 'top-movies' app/src/main/java/ir/bankmoviee/app/MainActivity.kt >/dev/null
grep -F 'top-series' app/src/main/java/ir/bankmoviee/app/MainActivity.kt >/dev/null
grep -F 'commentMediaCatalog' app/src/main/java/ir/bankmoviee/app/AccountApi.kt >/dev/null
grep -F 'fun scheduleWindow' app/src/main/java/ir/bankmoviee/app/DownloadScheduleManager.kt >/dev/null
grep -F 'ACTION_ARM_SCHEDULE' app/src/main/java/ir/bankmoviee/app/InternalDownloadService.kt >/dev/null
grep -F 'REQUEST_IGNORE_BATTERY_OPTIMIZATIONS' app/src/main/AndroidManifest.xml >/dev/null

for f in \
  bm_category_genres.webp \
  bm_category_collections.webp \
  bm_category_top_movies.webp \
  bm_category_top_series.webp; do
  test -s "app/src/main/res/drawable-nodpi/$f"
done

# Search is explicitly exempt from the global skeleton conversion.
search_calls=$(grep -n 'fancySpinnerText' app/src/main/java/ir/bankmoviee/app/MainActivity.kt | grep -v 'private fun fancySpinnerText' | wc -l | tr -d ' ')
test "$search_calls" = "3"

# Dormant helper only: old quick tabs must not be invoked.
python3 - <<'PY'
import re
from pathlib import Path
main=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')
assert len(re.findall(r'\baddQuickTabs\s*\(', main)) == 1
assert r'.joinToString("\n")' in main
print('Kotlin source invariants: OK')
PY

echo 'PHASE8_VERIFY_OK'
