#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
PLAYER='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
grep -F 'handler.postDelayed(this, if (partyIsHost) 420L else 360L)' "$PLAYER"
grep -F 'private fun showPartyMessageOverlay' "$PLAYER"
grep -F 'private fun showWatchPartyLobby' "$PLAYER"
grep -F 'همان بسته‌های گفت‌وگو و کامنت بانک‌مووی' "$PLAYER"
grep -F 'setUseHardwareAcousticEchoCanceler(false)' "$PLAYER"
grep -F 'val rating = if (hasRating) rawRating else "N/A"' "$MAIN"
grep -F 'return "0%"' "$MAIN"
grep -F 'Watch Party / تماشای دونفره' "$MAIN"
grep -F 'text=t("دونفره","Party")' "$MAIN"
echo PASS4_2_WATCH_PARTY_POLISH_OK
