# BankMovie Android Phase 6.1 — Kotlin type fix

- Fixes the Phase 6 Kotlin compilation failure in `MainActivity.kt` skeleton hero.
- `FrameLayout.background` requires a Drawable; the erroneous integer color assignment was replaced with `setBackgroundColor(Color.BLACK)`.
- All Phase 6 functionality remains unchanged: Archive 2 database API, future download subdomain preservation, smooth scrolling, player lock/control improvements, and detail skeleton loader.
