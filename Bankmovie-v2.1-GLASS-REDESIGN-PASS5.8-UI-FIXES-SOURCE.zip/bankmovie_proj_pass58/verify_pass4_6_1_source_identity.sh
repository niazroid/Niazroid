#!/usr/bin/env bash
set -euo pipefail
PLAYER='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'

test -s "$PLAYER"
grep -F 'BANKMOVIE_PASS4_6_1_SOURCE_FINGERPRINT: player-lifecycle-guest-glass-stale-source-guard' "$PLAYER"
! grep -F 'releaseRtc()' "$PLAYER"
! grep -F 'cornerRadii=floatArrayOf(dp(26f)' "$PLAYER"
! grep -F 'background=Color.rgb(5,27,28)' "$PLAYER"
! grep -F 'background=Color.TRANSPARENT;loadPartyImage' "$PLAYER"
grep -F 'setCornerRadii(floatArrayOf' "$PLAYER"
grep -F 'showGuestPlaybackLockedNotice()' "$PLAYER"
grep -F 'pauseAfterLifecycleRestore = false' "$PLAYER"
echo 'PASS4.6.1 source identity / stale-source guard: OK'
