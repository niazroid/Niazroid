# BankMovie Android Phase 5.1

- رفع خطای Verify workflow در Phase 5.
- حذف کامل کد مرده Dynamic Palette از MainActivity.kt.
- حفظ چیدمان جدید اطلاعات، پوستر کوچک و دکمه‌های Premium.
- Detail از رنگ‌بندی ثابت اپ استفاده می‌کند.
- Workflow اکنون نبودن Palette را بررسی می‌کند، نه وجود آن را.
