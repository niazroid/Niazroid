# Bankmovie v2.1 — Pass 4 Native Watch Party

این نسخه Watch Party سایت را به صورت Native وارد اپ اندروید می‌کند و از همان دیتابیس و منطق سمت سایت استفاده می‌کند؛ سیستم دوم و جداگانه ساخته نشده است.

## قابلیت‌ها

- دکمه «تماشای دونفره VIP» کنار هر کیفیت قابل پخش.
- ساخت/Reuse اتاق با منطق اصلی سایت و دعوت رایگان همراه از لینک سایت.
- همگام‌سازی Play / Pause / Seek با sequence number و زمان سرور.
- heartbeat میزبان و اصلاح drift مهمان بدون seekهای پی‌درپی.
- چت خصوصی داخل پلیر، unread badge و نمایش واکنش روی ویدئو.
- Sticker/GIF با همان catalog و markerهای سایت.
- لیست اعضا، کپی لینک دعوت، وضعیت میزبان/همراه و تم‌های اتاق.
- Voice Call صوتی Native با WebRTC؛ PHP/MySQL فقط signaling را حمل می‌کنند.
- VIP gate و پلن‌های پویا از تنظیمات واقعی سایت.
- کنترل اتاق فقط توسط میزبان، همانند سایت.
- UI شیشه‌ای هماهنگ با Pass 3.x و Focus مناسب Android TV.

## نصب سمت سایت

فایل `server-required/app_user_api.php` و پوشه `server-required/includes/` برای مرجع داخل سورس قرار داده شده‌اند. برای سایت واقعی، ZIP جداگانه‌ی `Bankmovie-SITE-PASS4-WATCH-PARTY-BRIDGE.zip` را در روت سایت Merge کنید. فایل‌های Watch Party داخل آن از سورس خود سایت گرفته شده‌اند و Bridge اندروید به همان توابع متصل است.

## Build

Dependency تماس صوتی در `app/build.gradle` اضافه شده و مجوزهای `RECORD_AUDIO` و `MODIFY_AUDIO_SETTINGS` در Manifest فعال‌اند.

Workflow همراه سورس Java 17، Android SDK 35، Gradle 8.10.2 و هر دو خانواده ABI2/ABI4 را حفظ می‌کند.
