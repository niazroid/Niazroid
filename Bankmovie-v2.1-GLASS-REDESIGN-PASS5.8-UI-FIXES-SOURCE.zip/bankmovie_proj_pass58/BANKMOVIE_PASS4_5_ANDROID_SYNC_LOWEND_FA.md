# Bankmovie Pass 4.5 — Android Sync + Low-End Stability

این مرحله سه باگ فوری نسخه Watch Party را هدف می‌گیرد:

1. **Android به Android**: اگر مهمان هنوز Player محلی نداشته باشد و میزبان Play کند، منبع مشترک اتاق روی گوشی مهمان آماده و پخش می‌شود. رویداد Play میزبان نیز به‌صورت صریح به سرور ارسال می‌شود و درخواست‌های مهم Play/Pause/Seek یک Retry کوتاه دارند.
2. **گوشی‌های ضعیف / ANR هنگام خروج و بازگشت**: Player در Resume بی‌دلیل Destroy/Recreate نمی‌شود. هنگام خروج نیز Stop/Release سنگین VLC روی Thread پس‌زمینه انجام می‌شود تا Main Thread قفل نشود.
3. **Avatar واقعی در Chat/Member list**: `avatar_key` کاربران preset هم resolve می‌شود، آدرس نسبی Avatar در API به URL کامل تبدیل می‌شود، و Android نیز URL نسبی را به دامنه Bankmovie متصل می‌کند.

WebRTC و مجوز میکروفن همچنان حذف هستند و تعداد تلاش مجدد Player عادی ۵ بار باقی مانده است.
