#!/usr/bin/env bash
set -euo pipefail
P=app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt
M=app/src/main/java/ir/bankmoviee/app/MainActivity.kt
A=app/src/main/java/ir/bankmoviee/app/AccountApi.kt
S=server-required/includes/watch_party.php
U=server-required/app_user_api.php
G=app/build.gradle
MAN=app/src/main/AndroidManifest.xml

test -s "$P"
test -s "$M"
test -s "$A"
test -s "$S"
test -s "$U"
test -s app/src/main/res/drawable/ic_party_emoji.xml

# Chat-only Watch Party remains compact.
! grep -q 'org.webrtc' "$P"
! grep -q 'webrtc-sdk' "$G"
! grep -q 'RECORD_AUDIO' "$MAN"

# Room reuse: Android remembers the host code, server validates and reuses it.
grep -Fq 'watch_party_host_room_code' "$A"
grep -Fq 'rememberedWatchPartyRoomCode(context)' "$A"
grep -Fq "'room_code'=>(string)bm_user_api_param('room_code','')" "$U"
grep -Fq '$preferredRoomCode = bm_watch_party_normalize_code' "$S"
grep -Fq "if (\$code === '') \$code = bm_watch_party_issue_room_alias" "$S"

# Telegram-like chat polish + real avatars + correct mine/other side.
grep -Fq 'private fun partyAvatarView(' "$P"
grep -Fq 'avatar_url' "$P"
grep -Fq 'R.drawable.ic_party_emoji' "$P"
grep -Fq 'minimumHeight = dp(if (isTvLike()) 330 else 260)' "$P"
grep -Fq "['is_mine']" "$S"

# UX requested in Pass 4.4.
grep -Fq 'آماده‌ام شروع کن' "$P"
grep -Fq 'partyPlaybackStarted' "$P"
grep -Fq 'handler.postDelayed(partyChromeHideRunnable, 5000L)' "$P"
grep -Fq 'val scroll = ScrollView(this).apply' "$P"
grep -Fq 'private val maxPlaybackRetries = 5' "$P"
grep -Fq 'تلاش مجدد ${playbackRetryCount}/$maxPlaybackRetries' "$P"
grep -Fq 'LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginStart = dp(10) }' "$M"
! grep -Fq 'text=t("دونفره","Party")' "$M"

php -l "$U" >/dev/null
php -l "$S" >/dev/null

echo PASS4_4_WATCH_PARTY_ROOM_POLISH_OK
