# Bankmovie Pass 4.2 — Watch Party Polish

- همگام‌سازی سریع‌تر: polling مهمان 360ms و میزبان 420ms، heartbeat حدود 900ms و تصحیح drift دقیق‌تر.
- Lobby واقعی اتاق قبل از ورود کامل به سینما با کد اتاق، دعوت و اعضا.
- چت Responsive و جمع‌وجورتر با bubble پیام و نمایش پیام دریافتی روی خود فیلم.
- Picker استیکر/GIF بسته‌بندی‌شده با تب هر pack و Grid واکنش‌گرا؛ همان catalog کامنت‌ها.
- تم اتاق روی status/dock هماهنگ‌تر و شیشه‌ای‌تر.
- Voice Call پایدارتر با AudioDevice software AEC/NS و MODE_IN_COMMUNICATION برای کاهش crash دستگاه‌ها.
- Watch Party به صفحه پروفایل اضافه شد.
- دکمه Watch Party کیفیت‌ها گرد و دارای متن «دونفره» + نشان VIP شد؛ دکمه دانلود هم گردتر شد.
- IMDb همیشه نمایش داده می‌شود و در نبود امتیاز N/A است؛ رضایت در نبود داده 0% است.
- Light theme شیشه‌ای‌تر و نزدیک‌تر به iOS frosted glass شد.
