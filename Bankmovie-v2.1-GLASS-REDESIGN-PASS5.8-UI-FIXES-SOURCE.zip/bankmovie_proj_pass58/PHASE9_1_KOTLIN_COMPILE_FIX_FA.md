# Phase 9.1 Kotlin Compile Fix

رفع دو خطای Kotlin گزارش‌شده در GitHub Actions:

1. در drawer جدید، انتساب عدد رنگ به property از نوع Drawable اصلاح شد و از `setBackgroundColor(Color.TRANSPARENT)` استفاده شد.
2. در GIF picker، `ScrollView.LayoutParams` مبهم/resolve نشده با `android.view.ViewGroup.LayoutParams` صریح جایگزین شد.

هیچ فایل API سمت سرور در این مرحله تغییر نکرده است. فایل‌های legacy `api5.php` و `api5_lib.php` نیز byte-identical باقی مانده‌اند.
