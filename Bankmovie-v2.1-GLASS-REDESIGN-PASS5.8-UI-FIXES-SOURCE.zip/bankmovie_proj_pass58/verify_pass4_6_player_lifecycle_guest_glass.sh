#!/usr/bin/env bash
set -euo pipefail
P='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
test -s "$P"

grep -Fq 'PASS 4.6 lifecycle/surface fix' "$P"
grep -Fq 'private fun releasePlayerAsyncForRebuild()' "$P"
grep -Fq 'runCatching { current?.detachViews(); lifecycleViewsDetached = current != null }' "$P"
grep -Fq 'releasePlayerAsyncForRebuild()' "$P"
grep -Fq 'videoLayout.postDelayed({' "$P"
grep -Fq 'private fun partyGuestPlaybackLocked(): Boolean = partyActive && !partyIsHost' "$P"
grep -Fq 'کنترل پخش دست میزبان است · فقط صدا برای شما آزاد است' "$P"
grep -Fq 'gestureMode = if (partyGuestPlaybackLocked()) 2' "$P"
grep -Fq 'setPlaybackControlTreeEnabled(centerControls, enabled)' "$P"
grep -Fq 'private fun playerGlassSurface' "$P"
grep -Fq 'background = playerGlassSurface(30, 248, 88)' "$P"
grep -Fq 'background = playerGlassAccent(15)' "$P"
grep -Fq 'bubble.addView(partyAvatarView(message, 36)' "$P"
grep -Fq 'private val maxPlaybackRetries = 5' "$P"
! grep -q 'org.webrtc' "$P"
python3 - "$P" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text(encoding='utf-8')
# Basic regression guard for accidental truncation / unbalanced braces outside strings is
# intentionally lightweight; the real Kotlin compile is performed by the workflow.
assert s.count('private fun ') > 90
assert 'override fun onResume()' in s and 'override fun onPause()' in s
assert s.count('releasePlayerAsyncForRebuild()') >= 4
print('PASS4_6_PLAYER_LIFECYCLE_GUEST_GLASS_OK')
PY
