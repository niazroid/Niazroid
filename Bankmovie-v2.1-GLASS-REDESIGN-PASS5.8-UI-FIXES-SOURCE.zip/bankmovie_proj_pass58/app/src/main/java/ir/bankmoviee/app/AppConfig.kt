package ir.bankmoviee.app

object AppConfig {
    val BASE_URL: String get() = RuntimeVault.base_url
    val BASE_DOMAIN: String get() = RuntimeVault.base_domain
    val ACCOUNT_API_URL: String get() = RuntimeVault.account_api_url
    val GENRE_ASSET_BASE_URL: String get() = RuntimeVault.genre_asset_base_url
    val CONFIG_URL_PRIMARY: String get() = RuntimeVault.config_url_primary
    val CONFIG_URL_SECONDARY: String get() = RuntimeVault.config_url_secondary
    val APP_API_URL: String get() = RuntimeVault.app_api_url
    val ARCHIVE3_API_URL: String get() = BASE_DOMAIN.trimEnd('/') + "/api6.php"
    val ARCHIVE1_LIVE_URL: String get() = RuntimeVault.archive1_live_url
    val TELEGRAM_URL: String get() = RuntimeVault.telegram_url
    val TELEGRAM_HANDLE: String get() = RuntimeVault.telegram_handle
    val APP_KEY: String get() = RuntimeVault.app_key
    val APP_SECRET: String get() = RuntimeVault.app_secret

    const val APP_SCHEME = "bankmoviee"
    const val PLAY_HOST = "play"
    const val USER_AGENT_SUFFIX = " BankMovieeAndroid/1.0"

    val TRUSTED_HOSTS: Set<String>
        get() = setOf(
            RuntimeVault.host_primary,
            RuntimeVault.host_primary_www,
            RuntimeVault.host_secondary,
            RuntimeVault.host_secondary_www
        )

    val DIRECT_VIDEO_EXTENSIONS = listOf(
        ".mp4", ".mkv", ".m3u8", ".avi", ".mov", ".webm", ".ts"
    )

    val SUBTITLE_EXTENSIONS = listOf(
        ".srt", ".ass", ".ssa", ".vtt"
    )
}
