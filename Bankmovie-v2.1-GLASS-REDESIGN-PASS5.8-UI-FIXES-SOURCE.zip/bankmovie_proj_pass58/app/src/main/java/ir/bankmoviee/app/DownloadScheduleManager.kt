package ir.bankmoviee.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat

/**
 * One-shot user-defined download window.
 * The user chooses both start and finish times. Downloads waiting before the
 * start are released at ACTION_START_WINDOW; all active/queued downloads are
 * paused safely at ACTION_END_WINDOW and can be resumed later without deleting
 * partial files.
 */
object DownloadScheduleManager {
    private const val PREFS = "bankmovie_download_schedule"
    private const val KEY_START_AT = "start_at"
    private const val KEY_END_AT = "end_at"
    const val ACTION_START_WINDOW = "ir.bankmoviee.app.download.SCHEDULE_START"
    const val ACTION_END_WINDOW = "ir.bankmoviee.app.download.SCHEDULE_END"
    private const val REQUEST_START = 19121
    private const val REQUEST_END = 19122

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun startAt(context: Context): Long = prefs(context).getLong(KEY_START_AT, 0L)
    fun endAt(context: Context): Long = prefs(context).getLong(KEY_END_AT, 0L)

    fun isActive(context: Context): Boolean = endAt(context) > System.currentTimeMillis()

    fun scheduleWindow(context: Context, startMillis: Long, endMillis: Long) {
        val now = System.currentTimeMillis()
        val safeStart = startMillis.coerceAtLeast(now + 5_000L)
        require(endMillis > safeStart) { "Download end time must be after start time" }
        prefs(context).edit().putLong(KEY_START_AT, safeStart).putLong(KEY_END_AT, endMillis).apply()
        arm(context, safeStart, pendingStart(context))
        arm(context, endMillis, pendingEnd(context))
    }

    fun cancel(context: Context) {
        prefs(context).edit().remove(KEY_START_AT).remove(KEY_END_AT).apply()
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.cancel(pendingStart(context))
        alarm.cancel(pendingEnd(context))
    }

    fun reschedule(context: Context) {
        val now = System.currentTimeMillis()
        val start = startAt(context)
        val end = endAt(context)
        if (end <= 0L) return
        if (end <= now) {
            stopNow(context)
            return
        }
        if (start > now) arm(context, start, pendingStart(context)) else if (start > 0L) fireNow(context)
        arm(context, end, pendingEnd(context))
    }

    private fun arm(context: Context, atMillis: Long, pi: PendingIntent) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarm.canScheduleExactAlarms() ->
                alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi)
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ->
                alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi)
            else -> alarm.set(AlarmManager.RTC_WAKEUP, atMillis, pi)
        }
    }

    private fun pendingStart(context: Context): PendingIntent = PendingIntent.getBroadcast(
        context,
        REQUEST_START,
        Intent(context, DownloadScheduleReceiver::class.java).apply { action = ACTION_START_WINDOW },
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun pendingEnd(context: Context): PendingIntent = PendingIntent.getBroadcast(
        context,
        REQUEST_END,
        Intent(context, DownloadScheduleReceiver::class.java).apply { action = ACTION_END_WINDOW },
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun fireNow(context: Context) {
        // Keep END_AT so the finish alarm remains authoritative for this window.
        prefs(context).edit().remove(KEY_START_AT).apply()
        InternalDownloadStore.releaseScheduled(context)
        val service = Intent(context, InternalDownloadService::class.java).apply {
            action = InternalDownloadService.ACTION_RESTORE
        }
        ContextCompat.startForegroundService(context, service)
    }

    fun stopNow(context: Context) {
        prefs(context).edit().remove(KEY_START_AT).remove(KEY_END_AT).apply()
        val service = Intent(context, InternalDownloadService::class.java).apply {
            action = InternalDownloadService.ACTION_PAUSE_ALL
        }
        ContextCompat.startForegroundService(context, service)
    }
}

class DownloadScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            DownloadScheduleManager.ACTION_START_WINDOW -> DownloadScheduleManager.fireNow(context)
            DownloadScheduleManager.ACTION_END_WINDOW -> DownloadScheduleManager.stopNow(context)
        }
    }
}
