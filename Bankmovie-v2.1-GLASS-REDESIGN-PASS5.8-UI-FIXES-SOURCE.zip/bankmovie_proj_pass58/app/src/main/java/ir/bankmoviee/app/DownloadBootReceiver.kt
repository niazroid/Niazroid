package ir.bankmoviee.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restores queued downloads after reboot or app replacement without changing saved files. */
class DownloadBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action.orEmpty()
        if (action !in setOf(Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED, Intent.ACTION_LOCKED_BOOT_COMPLETED)) return
        AdminPushScheduler.ensureScheduled(context)
        AdminPushScheduler.runNow(context)
        runCatching { DownloadScheduleManager.reschedule(context) }
        // Android 15 disallows launching a dataSync foreground service directly
        // from BOOT_COMPLETED. Keep the persisted queue untouched; scheduled
        // alarms are restored above and user-initiated downloads resume normally.
        // This avoids boot-time ForegroundServiceStartNotAllowedException loops.
    }
}
