package ir.bankmoviee.app

import android.content.Context
import android.os.Handler
import android.net.Uri
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object AccountApi {
    data class Result(
        val success: Boolean,
        val json: JSONObject? = null,
        val message: String = "",
        val statusCode: Int = 0
    )

    private val APP_KEY: String get() = AppConfig.APP_KEY
    private val APP_SECRET: String get() = AppConfig.APP_SECRET

    private const val SMART_PREFS = "bm_smart_cinema"
    private const val FAVORITES_KEY = "favorites"
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var clockOffsetSec = 0L
    @Volatile private var syncRunning = false

    private fun accountEndpointBases(context: Context): List<String> {
        val prefs = context.getSharedPreferences(SMART_PREFS, Context.MODE_PRIVATE)
        val configured = prefs.getString("account_api_url", "").orEmpty().trim()
        val values = linkedSetOf<String>()
        configured.takeIf { it.startsWith("http", true) }?.let { values.add(it.trimEnd('?')) }
        val raw = prefs.getString("account_api_fallback_urls", "[]").orEmpty()
        runCatching { JSONArray(raw) }.getOrNull()?.let { arr ->
            for (i in 0 until arr.length()) arr.optString(i).trim().takeIf { it.startsWith("http", true) }?.let { values.add(it.trimEnd('?')) }
        }
        values.add(AppConfig.ACCOUNT_API_URL.trimEnd('?'))
        return values.toList()
    }

    private fun endpoint(base: String, action: String): String {
        val separator = if (base.contains('?')) '&' else '?'
        return "$base${separator}action=${URLEncoder.encode(action, "UTF-8")}"
    }

    /**
     * Builds one canonical comment target for every archive.
     * Database movies keep their real DB id. External archives use the exact
     * slug + archive prefix that movie.php uses on the website, so app and web
     * always read/write the same comment rows.
     */
    private fun commentItemPayload(item: JSONObject): JSONObject {
        val out = JSONObject(item.toString())
        val source = item.optString("source").trim().lowercase()
        val rawArchive = item.optInt("comment_archive",
            item.optInt("_origin_archive", item.optInt("archive", 1)))
        val apiDetail = item.optString("api_detail")
        val databaseItem = source in setOf("db_movies", "database", "local_db", "collection", "website_db") ||
            item.optInt("db_id", 0) > 0 ||
            (apiDetail.contains("app_api.php", true) && apiDetail.contains("archive=2", true))

        val canonicalArchive = when {
            item.optInt("comment_archive", 0) == 1 || source == "archive1" || source == "arc1" || rawArchive == 1 -> 1
            item.optInt("comment_archive", 0) == 3 || rawArchive == 3 || source.contains("archive3") || source.contains("arc3") -> 3
            item.optInt("comment_archive", 0) == 4 || source in setOf("serialblog", "archive2", "sb", "arc4") -> 4
            databaseItem -> 2
            rawArchive == 2 -> 4
            else -> 1
        }

        fun cleanIdentity(value: String): String {
            var v = Uri.decode(value.trim().trim('/'))
            v = v.replace(Regex("^arc[134]-", RegexOption.IGNORE_CASE), "")
            return v.trim().trim('/')
        }

        fun identityFromUrl(value: String): String {
            if (value.isBlank()) return ""
            return runCatching {
                val uri = Uri.parse(value)
                listOf("slug", "id").firstNotNullOfOrNull { key ->
                    uri.getQueryParameter(key)?.takeIf { it.isNotBlank() }?.let(::cleanIdentity)
                } ?: run {
                    val segments = uri.pathSegments
                    val arcSegment = segments.firstOrNull { it.matches(Regex("arc[134]-.+", RegexOption.IGNORE_CASE)) }
                    cleanIdentity(arcSegment ?: segments.lastOrNull().orEmpty())
                }
            }.getOrDefault("")
        }

        var identity = listOf("comment_identity", "source_slug", "slug", "detail_id")
            .asSequence()
            .map { cleanIdentity(item.optString(it)) }
            .firstOrNull { it.isNotBlank() }
            .orEmpty()
        if (identity.isBlank()) {
            identity = listOf("api_detail", "web_url_abs", "web_url", "source_url", "url")
                .asSequence().map { identityFromUrl(item.optString(it)) }
                .firstOrNull { it.isNotBlank() }.orEmpty()
        }
        if (identity.isBlank()) identity = cleanIdentity(item.optString("id").ifBlank { item.optString("movie_id") })

        out.put("comment_archive", canonicalArchive)
        if (identity.isNotBlank()) out.put("comment_identity", identity)
        if (!out.has("source") && source.isNotBlank()) out.put("source", source)
        return out
    }

    private fun hmacSha256Hex(value: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(APP_SECRET.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(value.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }

    private fun parseMessage(json: JSONObject?, fallback: String): String {
        return json?.optString("message")
            ?.takeIf { it.isNotBlank() }
            ?: json?.optString("error")?.takeIf { it.isNotBlank() }
            ?: fallback
    }

    private fun requestBlocking(
        context: Context,
        action: String,
        method: String = "GET",
        body: JSONObject? = null,
        requireToken: Boolean = false
    ): Result {
        val token = AccountSession.token(context)
        if (requireToken && token.isBlank()) return Result(false, message = "ابتدا وارد حساب کاربری شوید", statusCode = 401)

        var last = Result(false, message = "خطا در اتصال به سرور")
        val bases = accountEndpointBases(context)
        for (round in 0 until 2) {
          for (base in bases) {
            var connection: HttpURLConnection? = null
            try {
                val url = URL(endpoint(base, action))
                connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = method
                    connectTimeout = 12000
                    readTimeout = 18000
                    instanceFollowRedirects = true
                    useCaches = false
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("User-Agent", "BankmovieAndroidNative/2.1-Account")
                    setRequestProperty("Cache-Control", "no-cache")
                    val timestamp = (System.currentTimeMillis() / 1000L + clockOffsetSec).toString()
                    val pathQuery = url.path + if (url.query.isNullOrBlank()) "" else "?${url.query}"
                    setRequestProperty("X-BM-App-Key", APP_KEY)
                    setRequestProperty("X-BM-Ts", timestamp)
                    setRequestProperty("X-BM-Sign", hmacSha256Hex("$timestamp|$pathQuery"))
                    if (token.isNotBlank()) {
                        setRequestProperty("Authorization", "Bearer $token")
                        setRequestProperty("X-BM-User-Token", token)
                    }
                    if (method == "POST") doOutput = true
                }

                if (method == "POST") {
                    val bytes = (body ?: JSONObject()).toString().toByteArray(Charsets.UTF_8)
                    connection.setFixedLengthStreamingMode(bytes.size)
                    connection.outputStream.use { it.write(bytes) }
                }

                val code = connection.responseCode
                connection.getHeaderFieldDate("Date", -1L).takeIf { it > 0L }?.let { serverDate ->
                    clockOffsetSec = serverDate / 1000L - System.currentTimeMillis() / 1000L
                }
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                val json = runCatching { if (text.isBlank()) JSONObject() else JSONObject(text) }.getOrNull()
                val ok = code in 200..299 && (json?.optBoolean("success", true) != false)
                last = Result(
                    success = ok,
                    json = json,
                    message = parseMessage(json, if (ok) "" else "خطای ارتباط با حساب کاربری"),
                    statusCode = code
                )
                if (ok) {
                    context.getSharedPreferences(SMART_PREFS, Context.MODE_PRIVATE).edit().putString("account_api_url", base).apply()
                    return last
                }
                if (code == 401 && round > 0) return last
            } catch (_: Throwable) {
                last = Result(false, message = "اتصال به سرور برقرار نشد")
            } finally {
                runCatching { connection?.disconnect() }
            }
          }
        }
        return last
    }

    private fun run(callback: (Result) -> Unit, block: () -> Result) {
        Thread {
            val result = runCatching(block).getOrElse { Result(false, message = "خطای غیرمنتظره") }
            mainHandler.post { callback(result) }
        }.start()
    }

    fun loadConfig(context: Context, callback: (Result) -> Unit = {}) {
        run(callback) {
            val result = requestBlocking(context, "config")
            result.json?.optString("background_url")?.takeIf { it.isNotBlank() }?.let {
                AccountSession.setAuthBackground(context, it)
            }
            result.json?.optJSONObject("features")?.let { AccountSession.updateFeatures(context, it) }
            result
        }
    }

    fun login(context: Context, identity: String, password: String, callback: (Result) -> Unit) {
        run(callback) {
            val result = requestBlocking(
                context = context,
                action = "login",
                method = "POST",
                body = JSONObject().apply {
                    put("identity", identity.trim())
                    put("password", password)
                }
            )
            if (result.success) {
                val token = result.json?.optString("token").orEmpty()
                val user = result.json?.optJSONObject("user") ?: JSONObject()
                val stats = result.json?.optJSONObject("stats")
                if (token.isNotBlank()) AccountSession.saveAuth(context, token, user, stats)
            }
            result
        }
    }

    fun register(
        context: Context,
        username: String,
        email: String,
        password: String,
        confirmPassword: String,
        callback: (Result) -> Unit
    ) {
        run(callback) {
            val result = requestBlocking(
                context = context,
                action = "register",
                method = "POST",
                body = JSONObject().apply {
                    put("username", username.trim())
                    put("email", email.trim())
                    put("password", password)
                    put("confirm_password", confirmPassword)
                }
            )
            if (result.success) {
                val token = result.json?.optString("token").orEmpty()
                val user = result.json?.optJSONObject("user") ?: JSONObject()
                val stats = result.json?.optJSONObject("stats")
                if (token.isNotBlank()) AccountSession.saveAuth(context, token, user, stats)
            }
            result
        }
    }

    fun refreshMe(context: Context, callback: (Result) -> Unit = {}) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "وارد حساب نشده‌اید", statusCode = 401))
            return
        }
        run(callback) {
            val result = requestBlocking(context, "me", requireToken = true)
            if (result.success) {
                result.json?.optJSONObject("user")?.let { AccountSession.updateUser(context, it) }
                result.json?.optJSONObject("stats")?.let { AccountSession.updateStats(context, it) }
                result.json?.optJSONObject("features")?.let { AccountSession.updateFeatures(context, it) }
            } else if (result.statusCode == 401) {
                AccountSession.clear(context)
            }
            result
        }
    }

    fun logout(context: Context, callback: (Result) -> Unit = {}) {
        val hadSession = AccountSession.isLoggedIn(context)
        if (!hadSession) {
            AccountSession.clear(context)
            callback(Result(true))
            return
        }
        run(callback) {
            val result = requestBlocking(context, "logout", method = "POST", body = JSONObject(), requireToken = true)
            AccountSession.clear(context)
            result.copy(success = true)
        }
    }

    private fun localFavorites(context: Context): JSONArray {
        val raw = context.getSharedPreferences(SMART_PREFS, Context.MODE_PRIVATE)
            .getString(FAVORITES_KEY, "[]") ?: "[]"
        return runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
    }

    private fun saveFavorites(context: Context, array: JSONArray) {
        context.getSharedPreferences(SMART_PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(FAVORITES_KEY, array.toString())
            .apply()
    }

    fun syncWatchlist(context: Context, force: Boolean = false, callback: (Result) -> Unit = {}) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "وارد حساب نشده‌اید", statusCode = 401))
            return
        }
        if (!force && System.currentTimeMillis() - AccountSession.lastWatchlistSync(context) < 20_000L) {
            callback(Result(true, message = ""))
            return
        }
        synchronized(this) {
            if (syncRunning) {
                callback(Result(true, message = ""))
                return
            }
            syncRunning = true
        }

        run({ result ->
            syncRunning = false
            callback(result)
        }) {
            val removed = JSONArray()
            AccountSession.removedWatchlistKeys(context).forEach(removed::put)
            val result = requestBlocking(
                context = context,
                action = "watchlist_sync",
                method = "POST",
                body = JSONObject().apply {
                    put("items", localFavorites(context))
                    put("removed_keys", removed)
                },
                requireToken = true
            )
            if (result.success) {
                val items = result.json?.optJSONArray("items") ?: JSONArray()
                saveFavorites(context, items)
                AccountSession.clearRemovedWatchlistKeys(context)
                AccountSession.markWatchlistSynced(context)
            } else if (result.statusCode == 401) {
                AccountSession.clear(context)
            }
            result
        }
    }

    fun updateAvatar(context: Context, avatarKey: String, callback: (Result) -> Unit) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "ابتدا وارد حساب کاربری شوید", statusCode = 401))
            return
        }
        run(callback) {
            val result = requestBlocking(
                context = context,
                action = "avatar_update",
                method = "POST",
                body = JSONObject().put("avatar_key", avatarKey),
                requireToken = true
            )
            if (result.success) result.json?.optJSONObject("user")?.let { AccountSession.updateUser(context, it) }
            result
        }
    }

    fun uploadAvatar(context: Context, base64Image: String, mimeType: String, callback: (Result) -> Unit) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "ابتدا وارد حساب کاربری شوید", statusCode = 401))
            return
        }
        run(callback) {
            val result = requestBlocking(
                context = context,
                action = "avatar_upload",
                method = "POST",
                body = JSONObject().apply {
                    put("image_base64", base64Image)
                    put("mime_type", mimeType)
                },
                requireToken = true
            )
            if (result.success) result.json?.optJSONObject("user")?.let { AccountSession.updateUser(context, it) }
            result
        }
    }

    fun commentMediaCatalog(context: Context, callback: (Result) -> Unit) {
        run(callback) {
            requestBlocking(
                context = context,
                action = "comment_media_catalog",
                method = "POST",
                body = JSONObject()
            )
        }
    }

    fun listComments(
        context: Context,
        item: JSONObject,
        page: Int = 1,
        limit: Int = 10,
        sort: String = "latest",
        callback: (Result) -> Unit
    ) {
        run(callback) {
            requestBlocking(
                context = context,
                action = "comments_list",
                method = "POST",
                body = JSONObject().apply {
                    put("item", commentItemPayload(item))
                    put("page", page)
                    put("limit", limit)
                    put("sort", sort)
                }
            )
        }
    }

    fun addComment(
        context: Context,
        item: JSONObject,
        text: String,
        rating: Int,
        spoiler: Boolean,
        parentId: Long? = null,
        callback: (Result) -> Unit
    ) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "برای ثبت دیدگاه وارد حساب شوید", statusCode = 401))
            return
        }
        run(callback) {
            requestBlocking(
                context = context,
                action = if (parentId != null && parentId > 0L) "comment_reply" else "comment_add",
                method = "POST",
                body = JSONObject().apply {
                    put("item", commentItemPayload(item))
                    put("comment", text.trim())
                    put("rating", rating.coerceIn(0, 5))
                    put("spoiler", if (spoiler) 1 else 0)
                    parentId?.takeIf { it > 0L }?.let { put("parent_id", it) }
                },
                requireToken = true
            )
        }
    }

    fun voteComment(
        context: Context,
        item: JSONObject,
        commentId: Long,
        type: String,
        callback: (Result) -> Unit
    ) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "برای رأی دادن وارد حساب شوید", statusCode = 401))
            return
        }
        run(callback) {
            requestBlocking(
                context = context,
                action = "comment_vote",
                method = "POST",
                body = JSONObject().apply {
                    put("item", commentItemPayload(item))
                    put("comment_id", commentId)
                    put("type", type)
                },
                requireToken = true
            )
        }
    }

    fun deleteComment(context: Context, item: JSONObject, commentId: Long, callback: (Result) -> Unit) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "ابتدا وارد حساب شوید", statusCode = 401))
            return
        }
        run(callback) {
            requestBlocking(
                context = context,
                action = "comment_delete",
                method = "POST",
                body = JSONObject().apply {
                    put("item", commentItemPayload(item))
                    put("comment_id", commentId)
                },
                requireToken = true
            )
        }
    }

    fun editComment(
        context: Context,
        item: JSONObject,
        commentId: Long,
        text: String,
        spoiler: Boolean,
        callback: (Result) -> Unit
    ) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "ابتدا وارد حساب شوید", statusCode = 401))
            return
        }
        run(callback) {
            requestBlocking(
                context = context,
                action = "comment_edit",
                method = "POST",
                body = JSONObject().apply {
                    put("item", commentItemPayload(item))
                    put("comment_id", commentId)
                    put("comment", text.trim())
                    put("spoiler", if (spoiler) 1 else 0)
                },
                requireToken = true
            )
        }
    }

    fun pinComment(
        context: Context,
        item: JSONObject,
        commentId: Long,
        pinned: Boolean,
        callback: (Result) -> Unit
    ) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "ابتدا وارد حساب شوید", statusCode = 401))
            return
        }
        run(callback) {
            requestBlocking(
                context = context,
                action = "comment_pin",
                method = "POST",
                body = JSONObject().apply {
                    put("item", commentItemPayload(item))
                    put("comment_id", commentId)
                    put("pinned", if (pinned) 1 else 0)
                },
                requireToken = true
            )
        }
    }

    fun reportComment(
        context: Context,
        item: JSONObject,
        commentId: Long,
        reason: String,
        details: String = "",
        callback: (Result) -> Unit
    ) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "برای گزارش دیدگاه وارد حساب شوید", statusCode = 401))
            return
        }
        run(callback) {
            requestBlocking(
                context = context,
                action = "comment_report",
                method = "POST",
                body = JSONObject().apply {
                    put("item", commentItemPayload(item))
                    put("comment_id", commentId)
                    put("reason", reason)
                    put("details", details.trim())
                },
                requireToken = true
            )
        }
    }

    fun listNotifications(context: Context, page: Int = 1, limit: Int = 30, callback: (Result) -> Unit) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "ابتدا وارد حساب شوید", statusCode = 401))
            return
        }
        run(callback) {
            val result = requestBlocking(
                context = context,
                action = "notifications_list",
                method = "POST",
                body = JSONObject().apply { put("page", page); put("limit", limit) },
                requireToken = true
            )
            result.json?.optJSONObject("stats")?.let { AccountSession.updateStats(context, it) }
            result
        }
    }

    fun markNotificationRead(context: Context, notificationId: Long, callback: (Result) -> Unit = {}) {
        if (!AccountSession.isLoggedIn(context)) { callback(Result(false, statusCode = 401)); return }
        run(callback) {
            val result = requestBlocking(
                context = context,
                action = "notification_read",
                method = "POST",
                body = JSONObject().put("notification_id", notificationId),
                requireToken = true
            )
            result.json?.optJSONObject("stats")?.let { AccountSession.updateStats(context, it) }
            result
        }
    }

    fun deleteNotification(context: Context, notificationId: Long, callback: (Result) -> Unit = {}) {
        if (!AccountSession.isLoggedIn(context)) { callback(Result(false, statusCode = 401)); return }
        run(callback) {
            val result = requestBlocking(
                context = context,
                action = "notification_delete",
                method = "POST",
                body = JSONObject().put("notification_id", notificationId),
                requireToken = true
            )
            result.json?.optJSONObject("stats")?.let { AccountSession.updateStats(context, it) }
            result
        }
    }

    fun clearNotifications(context: Context, callback: (Result) -> Unit = {}) {
        if (!AccountSession.isLoggedIn(context)) { callback(Result(false, statusCode = 401)); return }
        run(callback) {
            val result = requestBlocking(
                context = context,
                action = "notifications_clear",
                method = "POST",
                body = JSONObject(),
                requireToken = true
            )
            result.json?.optJSONObject("stats")?.let { AccountSession.updateStats(context, it) }
            result
        }
    }

    fun markAllNotificationsRead(context: Context, callback: (Result) -> Unit = {}) {
        if (!AccountSession.isLoggedIn(context)) { callback(Result(false, statusCode = 401)); return }
        run(callback) {
            val result = requestBlocking(
                context = context,
                action = "notifications_read_all",
                method = "POST",
                body = JSONObject(),
                requireToken = true
            )
            result.json?.optJSONObject("stats")?.let { AccountSession.updateStats(context, it) }
            result
        }
    }


    // PASS 4 — Native Watch Party. These calls terminate in app_user_api.php,
    // which delegates to the website's existing Watch Party functions/tables.
    fun watchPartyGuestToken(context: Context): String {
        val prefs = context.getSharedPreferences(SMART_PREFS, Context.MODE_PRIVATE)
        val stored = prefs.getString("watch_party_guest_token", "").orEmpty()
        if (stored.matches(Regex("[A-Za-z0-9_-]{40,120}"))) return stored
        val fresh = (java.util.UUID.randomUUID().toString() + java.util.UUID.randomUUID().toString()).replace("-", "")
        prefs.edit().putString("watch_party_guest_token", fresh).apply()
        return fresh
    }

    private fun watchPartyBody(context: Context, roomCode: String = ""): JSONObject = JSONObject().apply {
        put("guest_token", watchPartyGuestToken(context))
        if (roomCode.isNotBlank()) put("room_code", roomCode)
    }

    private fun rememberedWatchPartyRoomCode(context: Context): String {
        return context.getSharedPreferences(SMART_PREFS, Context.MODE_PRIVATE)
            .getString("watch_party_host_room_code", "").orEmpty()
            .takeIf { it.matches(Regex("[A-Za-z0-9_-]{24,96}")) }.orEmpty()
    }

    private fun rememberWatchPartyRoomCode(context: Context, code: String) {
        val clean = code.trim()
        if (!clean.matches(Regex("[A-Za-z0-9_-]{24,96}"))) return
        context.getSharedPreferences(SMART_PREFS, Context.MODE_PRIVATE)
            .edit().putString("watch_party_host_room_code", clean).apply()
    }

    private fun clearRememberedWatchPartyRoomCode(context: Context) {
        context.getSharedPreferences(SMART_PREFS, Context.MODE_PRIVATE)
            .edit().remove("watch_party_host_room_code").apply()
    }

    fun watchPartyStatus(context: Context, callback: (Result) -> Unit) {
        run(callback) { requestBlocking(context, "watch_party_status", method = "POST", body = watchPartyBody(context), requireToken = false) }
    }

    fun watchPartyCreate(context: Context, item: JSONObject, link: JSONObject, callback: (Result) -> Unit) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "برای ساخت اتاق وارد حساب شوید", statusCode = 401)); return
        }
        run(callback) {
            val source = link.optString("url").trim()
            val subtitle = listOf("subtitle_url", "sub_url", "subtitle", "vtt_url")
                .asSequence().map { link.optString(it).trim() }.firstOrNull { it.startsWith("http", true) }.orEmpty()
            val archive = item.optInt("archive", item.optInt("_origin_archive", 1)).coerceIn(1, 9)
            val mediaType = when {
                link.optInt("episode", 0) > 0 -> "episode"
                item.optString("type").contains("series", true) || item.optString("type_fa").contains("سریال") -> "series"
                else -> "movie"
            }
            val id = item.optInt("db_id", 0).takeIf { it > 0 } ?: item.optInt("id", 0)
            val title = item.optString("title_fa").ifBlank { item.optString("title") }
            val poster = listOf("poster", "poster_url", "image", "cover_image", "thumbnail")
                .asSequence().map { item.optString(it).trim() }.firstOrNull { it.isNotBlank() }.orEmpty()
            val q = link.optString("quality").ifBlank { link.optString("display_label") }.ifBlank { "source" }
            val body = watchPartyBody(context).apply {
                rememberedWatchPartyRoomCode(context).takeIf { it.isNotBlank() }?.let { put("room_code", it) }
                put("movie_id", id)
                put("archive_no", archive)
                put("media_type", mediaType)
                put("source_ref", "android-movie-${item.optString("id")}-a$archive-${q.replace(Regex("[^A-Za-z0-9._-]+"), "-").take(48)}")
                put("source_url", source)
                put("subtitle_url", subtitle)
                put("content_title", title.take(190))
                put("poster_url", poster.take(600))
            }
            val result = requestBlocking(context, "watch_party_create", method = "POST", body = body, requireToken = true)
            if (result.success) {
                result.json?.optJSONObject("room")?.optString("invite_code")
                    ?.takeIf { it.isNotBlank() }?.let { rememberWatchPartyRoomCode(context, it) }
            }
            result
        }
    }

    fun watchPartyJoin(context: Context, roomCode: String, callback: (Result) -> Unit) {
        run(callback) {
            requestBlocking(context, "watch_party_join", method = "POST", body = watchPartyBody(context, roomCode), requireToken = false)
        }
    }

    fun watchPartyPoll(
        context: Context,
        roomCode: String,
        afterEventId: Long,
        afterMessageId: Long,
        afterVoiceSignalId: Long,
        callback: (Result) -> Unit
    ) {
        run(callback) {
            requestBlocking(context, "watch_party_poll", method = "POST", body = watchPartyBody(context, roomCode).apply {
                put("after_event_id", afterEventId)
                put("after_message_id", afterMessageId)
                put("after_voice_signal_id", afterVoiceSignalId)
            }, requireToken = false)
        }
    }

    fun watchPartyControl(
        context: Context,
        roomCode: String,
        event: String,
        currentTimeSeconds: Double,
        paused: Boolean,
        playbackRate: Float,
        buffering: Boolean = false,
        sourceUrl: String = "",
        subtitleUrl: String = "",
        sourceRef: String = "android",
        callback: (Result) -> Unit = {}
    ) {
        run(callback) {
            requestBlocking(context, "watch_party_control", method = "POST", body = watchPartyBody(context, roomCode).apply {
                put("event", event)
                put("current_time", currentTimeSeconds.coerceAtLeast(0.0))
                put("paused", paused)
                put("playback_rate", playbackRate.coerceIn(0.5f, 2f))
                put("buffering", buffering)
                if (sourceUrl.isNotBlank()) put("source_url", sourceUrl)
                if (subtitleUrl.isNotBlank()) put("subtitle_url", subtitleUrl)
                if (sourceRef.isNotBlank()) put("source_ref", sourceRef)
            }, requireToken = false)
        }
    }

    fun watchPartyRoomSettings(context: Context, roomCode: String, backgroundKey: String, callback: (Result) -> Unit) {
        run(callback) {
            requestBlocking(context, "watch_party_room_settings", method = "POST", body = watchPartyBody(context, roomCode).apply {
                put("background_key", backgroundKey)
            }, requireToken = false)
        }
    }

    fun watchPartyMessage(context: Context, roomCode: String, message: String, clientId: String, callback: (Result) -> Unit) {
        run(callback) {
            requestBlocking(context, "watch_party_message", method = "POST", body = watchPartyBody(context, roomCode).apply {
                put("message", message)
                put("client_message_id", clientId)
            }, requireToken = false)
        }
    }

    fun watchPartyVoiceStart(context: Context, roomCode: String, callback: (Result) -> Unit) {
        run(callback) { requestBlocking(context, "watch_party_voice_start", "POST", watchPartyBody(context, roomCode), false) }
    }

    fun watchPartyVoiceAction(context: Context, roomCode: String, callToken: String, action: String, muted: Boolean? = null, callback: (Result) -> Unit = {}) {
        run(callback) {
            requestBlocking(context, "watch_party_voice_action", "POST", watchPartyBody(context, roomCode).apply {
                put("call_token", callToken); put("voice_action", action); muted?.let { put("muted", it) }
            }, false)
        }
    }

    fun watchPartyVoiceSignal(context: Context, roomCode: String, callToken: String, signalType: String, clientSignalId: String, payload: JSONObject, callback: (Result) -> Unit = {}) {
        run(callback) {
            requestBlocking(context, "watch_party_voice_signal", "POST", watchPartyBody(context, roomCode).apply {
                put("call_token", callToken); put("signal_type", signalType); put("client_signal_id", clientSignalId); put("payload", payload)
            }, false)
        }
    }

    fun watchPartyLeave(context: Context, roomCode: String, close: Boolean, callback: (Result) -> Unit = {}) {
        run(callback) {
            val result = requestBlocking(context, if (close) "watch_party_close" else "watch_party_leave", "POST", watchPartyBody(context, roomCode), false)
            if (close && result.success) clearRememberedWatchPartyRoomCode(context)
            result
        }
    }

}
