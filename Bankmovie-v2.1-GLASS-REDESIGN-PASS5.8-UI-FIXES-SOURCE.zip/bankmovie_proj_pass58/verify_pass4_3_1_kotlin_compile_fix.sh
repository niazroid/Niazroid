#!/usr/bin/env bash
set -euo pipefail
P=app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt
G=app/build.gradle
M=app/src/main/AndroidManifest.xml

test -s "$P"
# Pass 4.3 remains chat-only: no WebRTC or mic permission may return.
! grep -q 'org.webrtc' "$P"
! grep -q 'webrtc-sdk' "$G"
! grep -q 'RECORD_AUDIO' "$M"
! grep -q 'releaseRtc()' "$P"

# Kotlin compile regressions seen in GitHub Actions run.
grep -Fq 'cornerRadii = floatArrayOf(dp(26).toFloat(), dp(26).toFloat(), dp(26).toFloat(), dp(26).toFloat(), 0f, 0f, 0f, 0f)' "$P"
! grep -Fq 'dp(26f)' "$P"
grep -Fq 'setBackgroundColor(Color.rgb(5, 27, 28))' "$P"
! grep -Fq 'background=Color.rgb(5,27,28)' "$P"
grep -Fq 'setBackgroundColor(Color.TRANSPARENT); loadPartyImage(url, this)' "$P"
! grep -Fq 'background=Color.TRANSPARENT;loadPartyImage' "$P"

echo PASS4_3_1_KOTLIN_COMPILE_FIX_OK
