#!/usr/bin/env bash
set -euo pipefail
P=app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt
G=app/build.gradle
M=app/src/main/AndroidManifest.xml
test -s "$P"
! grep -q 'org.webrtc' "$P"
! grep -q 'webrtc-sdk' "$G"
! grep -q 'RECORD_AUDIO' "$M"
grep -q 'private var partyPlaybackStarted = false' "$P"
grep -q 'پخش در سینمای خصوصی' "$P"
grep -q 'تنظیمات اتاق' "$P"
grep -q 'گفت‌وگوی خصوصی' "$P"
grep -q 'showPartyStickerPicker' "$P"
grep -q 'showPartyRoomSheet' "$P"
echo PASS4_3_WATCH_PARTY_CHAT_ONLY_OK
