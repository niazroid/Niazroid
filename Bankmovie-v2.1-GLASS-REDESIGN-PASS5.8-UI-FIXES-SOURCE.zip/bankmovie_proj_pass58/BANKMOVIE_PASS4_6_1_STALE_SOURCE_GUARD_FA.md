# Bankmovie Pass 4.6.1 — Stale Source / CI Guard

این نسخه منطق Pass 4.6 را نگه می‌دارد و فقط برای جلوگیری از کامپایل شدن تصادفی سورس قدیمی سخت‌گیری CI اضافه می‌کند.

- PlayerActivity دارای fingerprint اختصاصی Pass 4.6.1 است.
- باقی‌مانده WebRTC (`releaseRtc`) مجاز نیست.
- الگوهای خراب Pass 4.3 برای `background = Color.*` و `cornerRadii` مجاز نیستند.
- corner radii با setter صریح `setCornerRadii(floatArrayOf(...))` نوشته شده تا CI Kotlin ambiguity نداشته باشد.
- Workflow قبل از Gradle، SHA256 ZIP و PlayerActivity استخراج‌شده را چاپ و fingerprint را بررسی می‌کند.

اگر fingerprint پیدا نشود، Workflow قبل از Build متوقف می‌شود؛ بنابراین دیگر یک ZIP قدیمی با نام جدید به‌اشتباه build نخواهد شد.
