#!/usr/bin/env bash
set -euo pipefail

MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
PLAYER='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
ACCOUNT='app/src/main/java/ir/bankmoviee/app/AccountApi.kt'
API='server-required/app_user_api.php'
MANIFEST='app/src/main/AndroidManifest.xml'
GRADLE='app/build.gradle'

grep -F "implementation 'io.github.webrtc-sdk:android:144.7559.12'" "$GRADLE"
grep -F 'android.permission.RECORD_AUDIO' "$MANIFEST"
grep -F 'EXTRA_WATCH_PARTY_ROOM_CODE' "$PLAYER"
grep -F 'private fun pollWatchParty()' "$PLAYER"
grep -F 'private fun sendWatchPartyControl(event: String)' "$PLAYER"
grep -F 'private fun showWatchPartyChat()' "$PLAYER"
grep -F 'private fun ensureRtcPeer():Boolean' "$PLAYER"
grep -F 'private fun watchPartyQualityButton' "$MAIN"
grep -F 'private fun showWatchPartyJoinDialog()' "$MAIN"
grep -F 'fun watchPartyCreate' "$ACCOUNT"
grep -F "if (\$action === 'watch_party_create')" "$API"
grep -F 'bm_watch_party_start_or_reuse_room' "$API"
grep -F 'bm_watch_party_voice_signal' "$API"
for f in watch_party.php watch_party_voice.php vip_sales.php vip_features.php sticker_packs.php security_bootstrap.php user_avatar.php user_theme.php bm_private_cleanup.php; do
  test -s "server-required/includes/$f"
done
php -l "$API" >/dev/null
printf 'PASS4_WATCH_PARTY_VERIFY_OK\n'
