#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
test -s "$MAIN"
grep -F 'PASS 4.9: compact playback sheet spacing' "$MAIN"
grep -F 'setPadding(dp(14), dp(8), dp(14), dp(12))' "$MAIN"
grep -F 'LinearLayout.LayoutParams(-1, dp(60)).apply { bottomMargin = dp(9) }' "$MAIN"
grep -F 'LinearLayout.LayoutParams(-1, dp(66)).apply { bottomMargin = dp(8) }' "$MAIN"
grep -F 'LinearLayout.LayoutParams(0, dp(112), 1f).apply { marginStart = dp(4) }' "$MAIN"
grep -F 'LinearLayout.LayoutParams(0, dp(112), 1f).apply { marginEnd = dp(4) }' "$MAIN"
grep -F 'LinearLayout.LayoutParams(-1, dp(112)).apply { bottomMargin = dp(8) }' "$MAIN"
grep -F 'LinearLayout.LayoutParams(-1, dp(58)))' "$MAIN"
# Old oversized player tiles must not remain inside the playback method dialog block.
python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')
a=s.index('    private fun showPlaybackMethodDialog(')
b=s.index('\n\n    private fun openPlayer(', a)
block=s[a:b]
assert 'dp(132)' not in block, 'old 132dp external player cards still present'
assert 'LinearLayout.LayoutParams(-1, dp(74))' not in block, 'old 74dp Bankmovie row still present'
print('Pass 4.9 playback modal compact spacing guards passed.')
PY
