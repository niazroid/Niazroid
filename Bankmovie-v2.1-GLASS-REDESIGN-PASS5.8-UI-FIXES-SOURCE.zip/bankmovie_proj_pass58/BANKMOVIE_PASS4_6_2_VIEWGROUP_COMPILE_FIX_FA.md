# Bankmovie Pass 4.6.2 — ViewGroup Kotlin Compile Fix

این پاس فقط یک خطای کامپایل باقی‌مانده در `PlayerActivity.kt` را اصلاح می‌کند و رفتار Pass 4.6 را تغییر نمی‌دهد.

## خطای GitHub Actions
کامپایل Kotlin در تابع `setPlaybackControlTreeEnabled` روی `ViewGroup`، `childCount` و `getChildAt` متوقف می‌شد، چون `android.view.ViewGroup` در importهای PlayerActivity وجود نداشت.

## اصلاح
- `import android.view.ViewGroup` به `PlayerActivity.kt` اضافه شد.
- fingerprint سورس به Pass 4.6.2 ارتقا یافت.
- verifier جدید وجود import و تابع recursive کنترل مهمان را بررسی می‌کند.

تمام تغییرات lifecycle پلیر، قفل کنترل مهمان، تنظیمات Glass و Watch Party نسخه 4.6 بدون تغییر حفظ شده‌اند.
