# Bankmovie Pass 4.6 — Player Lifecycle / Guest Lock / Glass Settings

این پاس روی سه مشکل اصلی پلیر تمرکز دارد:

- بازگشت از قفل صفحه، Share Sheet، Home یا سوییچ بین برنامه‌ها دیگر MediaPlayer قدیمی را با Surface مرده reuse نمی‌کند. پلیر قدیمی بدون بلاک‌کردن UI آزاد می‌شود و VLC روی Surface تازه بازسازی می‌شود؛ زمان قبلی حفظ می‌شود.
- در Watch Party مهمان کنترل پخش ندارد. Play/Pause، Seek، جلو/عقب، Speed، Cast، PiP و تنظیمات پخش قفل می‌شوند و فقط کنترل صدای محلی آزاد است. Chat و تنظیمات اتاق مستقل باقی می‌مانند.
- تنظیمات پلیر و Sheetهای کیفیت/صدا/سرعت به زبان Charcoal Glass برنامه منتقل شدند.
- پیام Watch Party روی فیلم اکنون Avatar واقعی، نام، VIP/Admin badge و Bubble شیشه‌ای مرتب دارد.
- Retry پلیر همچنان ۵ تلاش است.

Build واقعی Kotlin/ABI در GitHub Actions انجام می‌شود.
