#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
PLAYER="$ROOT/app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt"
MANIFEST="$ROOT/app/src/main/AndroidManifest.xml"
API="$ROOT/server-required/app_api.php"

test -s "$ROOT/verify_phase9.sh"
chmod +x "$ROOT/verify_phase9.sh"
"$ROOT/verify_phase9.sh" >/dev/null

for f in "$MAIN" "$PLAYER" "$MANIFEST" "$API"; do test -s "$f"; done
test -s "$ROOT/app/src/main/res/drawable/ic_player_pip.xml"
test -s "$ROOT/app/src/main/res/drawable/ic_player_audio_subtitle.xml"

grep -F 'private fun detailMoreInfoCard(item: JSONObject)' "$MAIN" >/dev/null
grep -F 'item.optString("latest_status")' "$MAIN" >/dev/null
grep -F 'private fun animateExpandable(target: View, expand: Boolean' "$MAIN" >/dev/null
grep -F 'private fun actorPageLoadingSkeleton()' "$MAIN" >/dev/null
grep -F 'Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL' "$MAIN" >/dev/null
grep -F 'GridLayout.spec(grid.childCount % 2, 1f)' "$MAIN" >/dev/null

grep -F 'R.drawable.ic_player_audio_subtitle' "$PLAYER" >/dev/null
grep -F 'R.drawable.ic_player_pip' "$PLAYER" >/dev/null
grep -F 'override fun onUserLeaveHint()' "$PLAYER" >/dev/null
grep -F 'override fun onPictureInPictureModeChanged(' "$PLAYER" >/dev/null
! grep -F 'actions.addView(simplePlayerIcon(R.drawable.ic_player_quality)' "$PLAYER" >/dev/null
! grep -F 'actions.addView(simplePlayerIcon(R.drawable.ic_player_cc)' "$PLAYER" >/dev/null
grep -F 'android:supportsPictureInPicture="true"' "$MANIFEST" >/dev/null

grep -F 'function bm_app_enrich_db_movie_extra($row)' "$API" >/dev/null
grep -F "'latest_status' => bm_app_first_nonempty" "$API" >/dev/null
grep -F 'movie_extra_info WHERE imdb_code = ?' "$API" >/dev/null
php -l "$API" >/dev/null

# Legacy endpoints for old installed APKs must remain byte-identical.
echo '6ef23c64a58ffeb0f60d431f5ccfb7fcdbd75295e1a125b2ce075e0ea0c680e0  '"$ROOT/server-required/api5.php" | sha256sum -c - >/dev/null
echo '9a3357dfda36fe0548ee0049339f56a642c4727122a0c4ffc87b7cdf057ddfdb  '"$ROOT/server-required/api5_lib.php" | sha256sum -c - >/dev/null

python3 - "$MANIFEST" "$ROOT/app/src/main/res/drawable/ic_player_pip.xml" "$ROOT/app/src/main/res/drawable/ic_player_audio_subtitle.xml" <<'PY'
import sys, xml.etree.ElementTree as ET
for p in sys.argv[1:]:
    ET.parse(p)
PY

echo PHASE10_VERIFY_OK
