# Bankmovie Pass 4.1 — Kotlin Compile Fix

این پاس فقط خطاهای کامپایل گزارش‌شده در Watch Party Pass 4 را اصلاح می‌کند و رفتار/طراحی Watch Party را تغییر نمی‌دهد.

- `EditText.singleLine = true` به `setSingleLine(true)` تغییر کرد.
- فراخوانی `bankTintGlassDrawable` در کارت پلن VIP با امضای واقعی تابع هماهنگ شد: `(accent, radiusDp, fillAlpha, strength)`.
- `verify_phase11_1.sh` و `verify_pass4_watch_party.sh` بعد از تغییر پاس شدند.
