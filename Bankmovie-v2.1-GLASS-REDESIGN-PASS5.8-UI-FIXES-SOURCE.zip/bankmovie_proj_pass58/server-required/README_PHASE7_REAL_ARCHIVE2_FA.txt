BankMovie Phase 7 — Server Patch

1) app_api.php را در Root سایت (کنار config.php) جایگزین کنید.
2) api5.php و api5_lib.php را دست نزنید؛ نسخه‌های قدیمی اپ ممکن است هنوز از آن‌ها استفاده کنند.
3) APK جدید Archive 2 را فقط از دیتابیس اصلی سایت می‌خواند.
4) endpoint ping پس از نصب باید archive2_source=database بدهد و database باید vietop_bankmovie باشد.
5) تصاویر relative با https://bankmovie.top کامل می‌شوند و URLهای دانلود absolute بدون تغییر Host عبور می‌کنند.
