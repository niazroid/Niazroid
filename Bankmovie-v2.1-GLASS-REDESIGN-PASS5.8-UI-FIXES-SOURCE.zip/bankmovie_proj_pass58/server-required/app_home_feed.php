<?php
declare(strict_types=1);

@ini_set('display_errors', '0');
@ini_set('log_errors', '1');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Cache-Control: public, max-age=30, s-maxage=30, stale-while-revalidate=60');
header('X-Content-Type-Options: nosniff');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

require_once __DIR__ . '/config.php';

function bm_hf_json(array $data, int $code = 200): never {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (!isset($pdo) || !($pdo instanceof PDO)) {
    bm_hf_json(['status'=>'error','message'=>'database_not_ready'], 503);
}

function bm_hf_base(): string {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ((string)($_SERVER['SERVER_PORT'] ?? '') === '443');
    $scheme = $https ? 'https' : 'http';
    $host = trim((string)($_SERVER['HTTP_HOST'] ?? 'bankmovie.top')) ?: 'bankmovie.top';
    return $scheme . '://' . $host;
}

function bm_hf_abs(string $value): string {
    $value = trim($value);
    if ($value === '') return '';
    if (preg_match('~^https?://~i', $value)) return $value;
    if (str_starts_with($value, '//')) return 'https:' . $value;
    return rtrim(bm_hf_base(), '/') . '/' . ltrim($value, '/');
}

function bm_hf_norm_type(string $type): string {
    $type = strtolower(trim($type));
    return (str_contains($type, 'series') || str_contains($type, 'serial') || str_contains($type, 'tv') || str_contains($type, 'سریال')) ? 'series' : 'movie';
}

function bm_hf_slider_target(string $link): array {
    $out = ['target_archive'=>2,'target_id'=>'','target_type'=>'movie'];
    $link = trim($link);
    if ($link === '') return $out;
    $parts = @parse_url($link) ?: [];
    $query = [];
    if (!empty($parts['query'])) parse_str((string)$parts['query'], $query);
    if (!empty($query['arc']) && ctype_digit((string)$query['arc'])) $out['target_archive'] = (int)$query['arc'];
    if (!empty($query['type'])) $out['target_type'] = bm_hf_norm_type((string)$query['type']);
    if (!empty($query['slug'])) $out['target_id'] = trim((string)$query['slug']);
    if (!empty($query['imdb'])) $out['target_id'] = trim((string)$query['imdb']);

    $path = rawurldecode((string)($parts['path'] ?? $link));
    if ($out['target_id'] === '') {
        if (preg_match('~/movie/arc1-([^/?#]+)~i', $path, $m)) {
            $out['target_archive'] = 1; $out['target_id'] = $m[1];
        } elseif (preg_match('~/movie/arc3-([^/?#]+)~i', $path, $m)) {
            $out['target_archive'] = 3; $out['target_id'] = $m[1];
        } elseif (preg_match('~/movie/arc4-([^/?#]+)~i', $path, $m)) {
            $out['target_archive'] = 4; $out['target_id'] = $m[1];
        } elseif (preg_match('~/movie/([^/?#]+)~i', $path, $m)) {
            // Plain /movie/... routes are the website database/local archive.
            $out['target_archive'] = 2; $out['target_id'] = $m[1];
        }
    }
    return $out;
}

function bm_hf_sliders(PDO $pdo, int $limit): array {
    try {
        $limit = max(1, min(20, $limit));
        // The admin panel stores the visible order ASC. New slides are inserted at 0.
        // DESC caused new slides to disappear behind the LIMIT and reversed the carousel.
        $rows = $pdo->query("SELECT * FROM slider_slides WHERE is_active=1 ORDER BY slide_order ASC, id ASC LIMIT {$limit}")->fetchAll(PDO::FETCH_ASSOC) ?: [];
        $out = [];
        foreach ($rows as $row) {
            $link = trim((string)($row['link'] ?? ''));
            $target = bm_hf_slider_target($link);
            $out[] = array_merge([
                'id'=>(int)($row['id'] ?? 0),
                'title_fa'=>(string)($row['title_fa'] ?? ''),
                'title'=>(string)($row['title_en'] ?? ($row['title_fa'] ?? '')),
                'subtitle_fa'=>(string)($row['subtitle_fa'] ?? ''),
                'subtitle'=>(string)($row['subtitle_en'] ?? ''),
                'image'=>bm_hf_abs((string)($row['image_path'] ?? $row['image'] ?? '')),
                'link'=>$link,
                'link_abs'=>bm_hf_abs($link),
                'rating'=>isset($row['rating']) && $row['rating'] !== '' ? round((float)$row['rating'],1) : null,
                'votes'=>(string)($row['votes'] ?? ''),
                'order'=>(int)($row['slide_order'] ?? 0),
            ], $target);
        }
        return $out;
    } catch (Throwable $e) {
        return [];
    }
}

function bm_hf_day_defs(): array {
    return [
        'saturday'=>['fa'=>'شنبه','en'=>'Saturday','order'=>0],
        'sunday'=>['fa'=>'یکشنبه','en'=>'Sunday','order'=>1],
        'monday'=>['fa'=>'دوشنبه','en'=>'Monday','order'=>2],
        'tuesday'=>['fa'=>'سه‌شنبه','en'=>'Tuesday','order'=>3],
        'wednesday'=>['fa'=>'چهارشنبه','en'=>'Wednesday','order'=>4],
        'thursday'=>['fa'=>'پنجشنبه','en'=>'Thursday','order'=>5],
        'friday'=>['fa'=>'جمعه','en'=>'Friday','order'=>6],
    ];
}

function bm_hf_normalize_day_key(string $key): string {
    $raw = strtolower(trim($key));
    $map = [
        'sat'=>'saturday','شنبه'=>'saturday',
        'sun'=>'sunday','یکشنبه'=>'sunday',
        'mon'=>'monday','دوشنبه'=>'monday',
        'tue'=>'tuesday','tues'=>'tuesday','سه شنبه'=>'tuesday','سه‌شنبه'=>'tuesday',
        'wed'=>'wednesday','چهارشنبه'=>'wednesday',
        'thu'=>'thursday','thur'=>'thursday','پنجشنبه'=>'thursday','پنج‌شنبه'=>'thursday',
        'fri'=>'friday','جمعه'=>'friday',
    ];
    return $map[$raw] ?? $raw;
}

function bm_hf_today_key(): string {
    $map = [1=>'sunday',2=>'monday',3=>'tuesday',4=>'wednesday',5=>'thursday',6=>'friday',7=>'saturday'];
    return $map[(int)date('w') + 1] ?? 'saturday';
}

function bm_hf_weekly(PDO $pdo): array {
    $defaults = [
        'enabled'=>false,'title_fa'=>'پخش هفتگی','title_en'=>'Weekly Schedule',
        'subtitle_fa'=>'','subtitle_en'=>'','show_empty_days'=>false,'default_day_mode'=>'today'
    ];
    try {
        $settings = $pdo->query("SELECT * FROM weekly_schedule_settings WHERE id=1 LIMIT 1")->fetch(PDO::FETCH_ASSOC) ?: [];
        $defaults['enabled'] = !empty($settings['is_enabled']);
        $defaults['title_fa'] = trim((string)($settings['title_fa'] ?? '')) ?: 'پخش هفتگی';
        $defaults['title_en'] = trim((string)($settings['title_en'] ?? '')) ?: 'Weekly Schedule';
        $defaults['subtitle_fa'] = (string)($settings['subtitle_fa'] ?? '');
        $defaults['subtitle_en'] = (string)($settings['subtitle_en'] ?? '');
        $defaults['show_empty_days'] = !empty($settings['show_empty_days']);
        $defaults['default_day_mode'] = in_array((string)($settings['default_day_mode'] ?? 'today'), ['today','first'], true) ? (string)$settings['default_day_mode'] : 'today';
    } catch (Throwable $e) {
        return $defaults + ['default_day_key'=>'','days'=>[]];
    }

    $defs = bm_hf_day_defs();
    $grouped = [];
    foreach ($defs as $key=>$def) $grouped[$key] = [];
    try {
        $rows = $pdo->query("SELECT * FROM weekly_schedule_items WHERE is_active=1 ORDER BY item_order ASC, id DESC")->fetchAll(PDO::FETCH_ASSOC) ?: [];
        foreach ($rows as $row) {
            $key = bm_hf_normalize_day_key((string)($row['day_key'] ?? ''));
            if (!isset($grouped[$key])) continue;
            $source = strtolower(trim((string)($row['source_archive'] ?? 'manual')));
            $targetArchive = match ($source) {
                'archive1' => 1,
                'archive2', 'database', 'db' => 2,
                'archive3' => 3,
                'archive4' => 4,
                default => 0,
            };
            $grouped[$key][] = [
                'id'=>(int)($row['id'] ?? 0),
                'day_key'=>$key,
                'source_archive'=>$source,
                'source_id'=>(string)($row['source_id'] ?? ''),
                'target_id'=>(string)($row['source_id'] ?? ''),
                'target_archive'=>$targetArchive,
                'title'=>(string)($row['title'] ?? ''),
                'title_fa'=>(string)($row['title_fa'] ?? ''),
                'poster_url'=>bm_hf_abs((string)($row['poster_url'] ?? '')),
                'target_url'=>(string)($row['target_url'] ?? ''),
                'target_url_abs'=>bm_hf_abs((string)($row['target_url'] ?? '')),
                'media_type'=>bm_hf_norm_type((string)($row['media_type'] ?? 'series')),
                'release_year'=>(string)($row['release_year'] ?? ''),
                'episode_label'=>(string)($row['episode_label'] ?? ''),
                'order'=>(int)($row['item_order'] ?? 0),
            ];
        }
    } catch (Throwable $e) {
    }

    $days = [];
    foreach ($defs as $key=>$def) {
        if (!$defaults['show_empty_days'] && empty($grouped[$key])) continue;
        $days[] = [
            'key'=>$key,'label_fa'=>$def['fa'],'label_en'=>$def['en'],'order'=>$def['order'],'items'=>$grouped[$key]
        ];
    }
    $today = bm_hf_today_key();
    $defaultKey = '';
    if ($defaults['default_day_mode'] === 'today' && !empty($grouped[$today])) $defaultKey = $today;
    if ($defaultKey === '') {
        foreach ($days as $day) {
            if (!empty($day['items'])) { $defaultKey = $day['key']; break; }
        }
    }
    if ($defaultKey === '' && !empty($days)) $defaultKey = (string)$days[0]['key'];
    return $defaults + ['default_day_key'=>$defaultKey,'days'=>$days];
}

$limit = max(1, min(20, (int)($_GET['limit'] ?? 12)));
bm_hf_json([
    'status'=>'success',
    'version'=>'1.0',
    'generated_at'=>gmdate('c'),
    'sliders'=>bm_hf_sliders($pdo, $limit),
    'weekly_schedule'=>bm_hf_weekly($pdo),
]);
