BankMovie Android Phase 1 - Server Feed

فقط app_home_feed.php را در ROOT اصلی سایت، کنار config.php قرار دهید.
مثال:
/public_html/app_home_feed.php

این فایل Read-only است و فقط:
1) اسلایدر فعال را با ترتیب صحیح پنل می‌خواند.
2) پخش هفتگی فعلی سایت را می‌خواند.

مهم:
app_api.php داخل سورس Android را روی سایت فعلی Overwrite نکنید.

تست:
https://bankmovie.top/app_home_feed.php?limit=12

Rollback:
فقط app_home_feed.php را حذف کنید.
