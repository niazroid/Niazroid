<?php
/**
 * BankMovie user-avatar helpers.
 *
 * Custom uploads are reserved for active VIP accounts. Every signed-in user
 * may choose one of the local BankMovie preset avatars.
 */

declare(strict_types=1);

require_once __DIR__ . '/vip_features.php';

if (defined('BANKMOVIE_USER_AVATAR_LOADED')) {
    return;
}
define('BANKMOVIE_USER_AVATAR_LOADED', true);

if (!function_exists('bm_user_avatar_presets')) {
    function bm_user_avatar_presets(): array
    {
        return [
            'male_01'   => ['path' => 'assets/avatars/avatar_male_01.webp',   'label_fa' => 'کاراکتر آبی ۱',   'label_en' => 'Blue Hero 1'],
            'male_02'   => ['path' => 'assets/avatars/avatar_male_02.webp',   'label_fa' => 'کاراکتر آبی ۲',   'label_en' => 'Blue Hero 2'],
            'male_03'   => ['path' => 'assets/avatars/avatar_male_03.webp',   'label_fa' => 'کاراکتر آبی ۳',   'label_en' => 'Blue Hero 3'],
            'male_04'   => ['path' => 'assets/avatars/avatar_male_04.webp',   'label_fa' => 'کاراکتر آبی ۴',   'label_en' => 'Blue Hero 4'],
            'male_05'   => ['path' => 'assets/avatars/avatar_male_05.webp',   'label_fa' => 'کاراکتر آبی ۵',   'label_en' => 'Blue Hero 5'],
            'male_06'   => ['path' => 'assets/avatars/avatar_male_06.webp',   'label_fa' => 'کاراکتر آبی ۶',   'label_en' => 'Blue Hero 6'],
            'female_01' => ['path' => 'assets/avatars/avatar_female_01.webp', 'label_fa' => 'کاراکتر نئون ۱',  'label_en' => 'Neon Hero 1'],
            'female_02' => ['path' => 'assets/avatars/avatar_female_02.webp', 'label_fa' => 'کاراکتر نئون ۲',  'label_en' => 'Neon Hero 2'],
            'female_03' => ['path' => 'assets/avatars/avatar_female_03.webp', 'label_fa' => 'کاراکتر نئون ۳',  'label_en' => 'Neon Hero 3'],
            'female_04' => ['path' => 'assets/avatars/avatar_female_04.webp', 'label_fa' => 'کاراکتر نئون ۴',  'label_en' => 'Neon Hero 4'],
            'female_05' => ['path' => 'assets/avatars/avatar_female_05.webp', 'label_fa' => 'کاراکتر نئون ۵',  'label_en' => 'Neon Hero 5'],
            'female_06' => ['path' => 'assets/avatars/avatar_female_06.webp', 'label_fa' => 'کاراکتر نئون ۶',  'label_en' => 'Neon Hero 6'],
            'neon_01'   => ['path' => 'assets/avatars/avatar_neon_01.webp',   'label_fa' => 'ماسک نئون ۱',     'label_en' => 'Neon Mask 1'],
            'neon_02'   => ['path' => 'assets/avatars/avatar_neon_02.webp',   'label_fa' => 'ماسک نئون ۲',     'label_en' => 'Neon Mask 2'],
            'neon_03'   => ['path' => 'assets/avatars/avatar_neon_03.webp',   'label_fa' => 'ماسک نئون ۳',     'label_en' => 'Neon Mask 3'],
            'neon_04'   => ['path' => 'assets/avatars/avatar_neon_04.webp',   'label_fa' => 'ماسک نئون ۴',     'label_en' => 'Neon Mask 4'],
        ];
    }
}

if (!function_exists('bm_user_avatar_is_uploaded')) {
    function bm_user_avatar_is_uploaded(?string $path): bool
    {
        $path = ltrim(str_replace('\\', '/', trim((string)$path)), '/');
        return $path !== '' && !str_contains($path, '..') && str_starts_with($path, 'uploads/avatars/');
    }
}

if (!function_exists('bm_user_avatar_is_preset')) {
    function bm_user_avatar_is_preset(?string $path): bool
    {
        $path = ltrim(str_replace('\\', '/', trim((string)$path)), '/');
        if ($path === '' || str_contains($path, '..')) return false;
        if (!str_starts_with($path, 'assets/avatars/')) return false;
        $name = basename($path);
        return (bool)preg_match('/^[A-Za-z0-9._-]+\.(?:webp|png|jpe?g|svg)$/i', $name);
    }
}

if (!function_exists('bm_user_avatar_path')) {
    function bm_user_avatar_path(?string $path): string
    {
        $path = ltrim(str_replace('\\', '/', trim((string)$path)), '/');
        $fallback = 'assets/avatars/avatar_default.webp';
        if ($path === '' || str_contains($path, '..')) return $fallback;
        if (!bm_user_avatar_is_uploaded($path) && !bm_user_avatar_is_preset($path)) return $fallback;
        $absolute = dirname(__DIR__) . '/' . $path;
        return is_file($absolute) ? $path : $fallback;
    }
}

if (!function_exists('bm_user_avatar_url')) {
    function bm_user_avatar_url(?string $path): string
    {
        return '/' . bm_user_avatar_path($path);
    }
}

if (!function_exists('bm_user_avatar_can_upload')) {
    function bm_user_avatar_can_upload(?array $user): bool
    {
        return bm_vip_benefit_allowed('custom_avatar', $user);
    }
}

if (!function_exists('bm_user_avatar_preset_path')) {
    function bm_user_avatar_preset_path(string $key): ?string
    {
        $catalog = bm_user_avatar_presets();
        return isset($catalog[$key]) ? (string)$catalog[$key]['path'] : null;
    }
}
