<?php
/**
 * Central BankMovie user-theme + user-font runtime.
 * Paid appearance preferences are resolved at the very end of HTML rendering,
 * after the authenticated user has been loaded by config.php.
 */
declare(strict_types=1);

if (!function_exists('bm_theme_catalog')) {
    function bm_theme_catalog(): array
    {
        return [
            'dark-green'  => ['name'=>'آبی پیش‌فرض','name_en'=>'Default Blue','primary'=>'#2f7cff','rgb'=>'47,124,255','logo'=>'/assets/brand/themes/bankmovie-logo-dark-green.webp'],
            'dark-blue'   => ['name'=>'آبی مشکی','name_en'=>'Dark Blue','primary'=>'#3b82f6','rgb'=>'59,130,246','logo'=>'/assets/brand/themes/bankmovie-logo-dark-blue.webp'],
            'dark-purple' => ['name'=>'بنفش مشکی','name_en'=>'Dark Purple','primary'=>'#8b5cf6','rgb'=>'139,92,246','logo'=>'/assets/brand/themes/bankmovie-logo-dark-purple.webp'],
            'dark-pink'   => ['name'=>'صورتی مشکی','name_en'=>'Dark Pink','primary'=>'#ec4899','rgb'=>'236,72,153','logo'=>'/assets/brand/themes/bankmovie-logo-dark-pink.webp'],
            'dark-red'    => ['name'=>'قرمز مشکی','name_en'=>'Dark Red','primary'=>'#ef4444','rgb'=>'239,68,68','logo'=>'/assets/brand/themes/bankmovie-logo-dark-red.webp'],
            'dark-orange' => ['name'=>'نارنجی مشکی','name_en'=>'Dark Orange','primary'=>'#f97316','rgb'=>'249,115,22','logo'=>'/assets/brand/themes/bankmovie-logo-dark-orange.webp'],
            'dark-cyan'   => ['name'=>'فیروزه‌ای مشکی','name_en'=>'Dark Cyan','primary'=>'#06b6d4','rgb'=>'6,182,212','logo'=>'/assets/brand/themes/bankmovie-logo-dark-cyan.webp'],
            'dark-white'  => ['name'=>'سفید مشکی','name_en'=>'Dark White','primary'=>'#f4f4f5','rgb'=>'244,244,245','logo'=>'/assets/brand/themes/bankmovie-logo-dark-white.webp'],
            'dark-black'  => ['name'=>'دارک مطلق','name_en'=>'Pure Dark','primary'=>'#8b8b92','rgb'=>'139,139,146','logo'=>'/assets/brand/themes/bankmovie-logo-dark-black.webp'],
        ];
    }
}

if (!function_exists('bm_theme_is_valid')) {
    function bm_theme_is_valid($theme): bool
    {
        return is_string($theme) && isset(bm_theme_catalog()[$theme]);
    }
}

if (!function_exists('bm_theme_user_can_customize')) {
    function bm_theme_user_can_customize(?array $user): bool
    {
        if (!is_array($user) || empty($user['id'])) return false;
        if (function_exists('bm_vip_user_is_active')) {
            if (function_exists('bm_vip_feature_enabled') && !bm_vip_feature_enabled('custom_theme')) return false;
            return bm_vip_user_is_active($user);
        }
        $role = strtolower(trim((string)($user['role'] ?? 'user')));
        if (in_array($role, ['admin','administrator'], true)) return true;
        if (!in_array($role, ['vip','premium','special'], true)) return false;
        $expiry = trim((string)($user['vip_expires_at'] ?? ''));
        if ($expiry === '') return true;
        $ts = strtotime($expiry);
        return $ts !== false && $ts > time();
    }
}

if (!function_exists('bm_theme_resolve')) {
    function bm_theme_resolve(?array $user = null): string
    {
        if (!bm_theme_user_can_customize($user)) return 'dark-green';

        if (is_array($user)) {
            $userTheme = trim((string)($user['theme'] ?? ''));
            if (bm_theme_is_valid($userTheme)) return $userTheme;
        }

        $cookieTheme = trim((string)($_COOKIE['user_theme'] ?? ''));
        if (bm_theme_is_valid($cookieTheme)) return $cookieTheme;

        return 'dark-green';
    }
}


/* ---------------- User backgrounds + avatar frames ---------------- */
if (!function_exists('bm_user_background_catalog')) {
    function bm_user_background_catalog(): array
    {
        return [
            'simple'       => ['name'=>'ساده','name_en'=>'Simple'],
            'purple_dream' => ['name'=>'رویای بنفش','name_en'=>'Purple Dream'],
            'teal_mist'    => ['name'=>'مه آبی','name_en'=>'Teal Mist'],
            'golden'       => ['name'=>'طلایی','name_en'=>'Golden'],
            'forest'       => ['name'=>'جنگل','name_en'=>'Forest'],
            'pink_cloud'   => ['name'=>'ابر صورتی','name_en'=>'Pink Cloud'],
            'interstellar' => ['name'=>'میان ستاره‌ای','name_en'=>'Interstellar'],
            'pony'         => ['name'=>'رویای پونی','name_en'=>'Pony Dream'],
            'pizza'        => ['name'=>'پیتزا','name_en'=>'Pizza'],
            'darkness'     => ['name'=>'تاریکی','name_en'=>'Darkness'],
        ];
    }
}

if (!function_exists('bm_user_avatar_frame_catalog')) {
    function bm_user_avatar_frame_catalog(): array
    {
        return [
            'none'        => ['name'=>'بدون افکت','name_en'=>'No Effect'],
            'gold_glow'   => ['name'=>'درخشش طلایی','name_en'=>'Golden Glow'],
            'purple_glow' => ['name'=>'درخشش بنفش','name_en'=>'Purple Glow'],
            'rainbow'     => ['name'=>'رنگین','name_en'=>'Rainbow'],
            'starlight'   => ['name'=>'ستاره‌ای','name_en'=>'Starlight'],
            'light_flow'  => ['name'=>'جریان نور','name_en'=>'Light Flow'],
        ];
    }
}

if (!function_exists('bm_user_background_is_valid')) {
    function bm_user_background_is_valid($value): bool
    {
        return is_string($value) && isset(bm_user_background_catalog()[$value]);
    }
}

if (!function_exists('bm_user_appearance_can_customize')) {
    function bm_user_appearance_can_customize(?array $user): bool
    {
        if (!is_array($user)) return false;
        $identity = (int)($user['id'] ?? $user['user_id'] ?? 0);
        if ($identity <= 0) return false;
        $role = strtolower(trim((string)($user['role'] ?? 'user')));
        if (in_array($role, ['admin','administrator'], true)) return true;
        if (function_exists('bm_vip_user_is_active')) return bm_vip_user_is_active($user);
        if (!in_array($role, ['vip','premium','special'], true)) return false;
        $expiry = trim((string)($user['vip_expires_at'] ?? ''));
        if ($expiry === '') return true;
        $ts = strtotime($expiry);
        return $ts !== false && $ts > time();
    }
}
if (!function_exists('bm_user_avatar_frame_is_valid')) {
    function bm_user_avatar_frame_is_valid($value): bool
    {
        return is_string($value) && isset(bm_user_avatar_frame_catalog()[$value]);
    }
}

if (!function_exists('bm_user_appearance_ensure')) {
    function bm_user_appearance_ensure(PDO $pdo): bool
    {
        static $ready = null;
        if (is_bool($ready)) return $ready;
        try {
            $hasBackground = (bool)$pdo->query("SHOW COLUMNS FROM users LIKE 'background_key'")->fetch(PDO::FETCH_ASSOC);
            if (!$hasBackground) {
                $pdo->exec("ALTER TABLE users ADD COLUMN background_key VARCHAR(32) NOT NULL DEFAULT 'simple'");
            }
            $hasFrame = (bool)$pdo->query("SHOW COLUMNS FROM users LIKE 'avatar_frame'")->fetch(PDO::FETCH_ASSOC);
            if (!$hasFrame) {
                $pdo->exec("ALTER TABLE users ADD COLUMN avatar_frame VARCHAR(32) NOT NULL DEFAULT 'none'");
            }
            return $ready = true;
        } catch (Throwable $e) {
            error_log('User appearance schema error: ' . $e->getMessage());
            return $ready = false;
        }
    }
}

if (!function_exists('bm_user_background_resolve')) {
    function bm_user_background_resolve(?array $user = null): string
    {
        if (!bm_user_appearance_can_customize($user)) return 'simple';
        $value = is_array($user) ? trim((string)($user['background_key'] ?? '')) : '';
        if (bm_user_background_is_valid($value)) return $value;
        $cookie = trim((string)($_COOKIE['user_background'] ?? ''));
        return bm_user_background_is_valid($cookie) ? $cookie : 'simple';
    }
}

if (!function_exists('bm_user_avatar_frame_resolve')) {
    function bm_user_avatar_frame_resolve(?array $user = null): string
    {
        if (!bm_user_appearance_can_customize($user)) return 'none';
        $value = is_array($user) ? trim((string)($user['avatar_frame'] ?? '')) : '';
        if (bm_user_avatar_frame_is_valid($value)) return $value;
        $cookie = trim((string)($_COOKIE['user_avatar_frame'] ?? ''));
        return bm_user_avatar_frame_is_valid($cookie) ? $cookie : 'none';
    }
}

/* ---------------- VIP font personalization ---------------- */
if (!function_exists('bm_user_font_catalog')) {
    function bm_user_font_catalog(): array
    {
        if (!function_exists('bm_site_font_catalog')) return [];
        // All choices are bundled local assets from BankMovie; no external CDN.
        return bm_site_font_catalog();
    }
}

if (!function_exists('bm_user_font_is_valid')) {
    function bm_user_font_is_valid($font): bool
    {
        return is_string($font) && isset(bm_user_font_catalog()[$font]);
    }
}

if (!function_exists('bm_font_user_can_customize')) {
    function bm_font_user_can_customize(?array $user): bool
    {
        if (!is_array($user) || empty($user['id'])) return false;
        if (function_exists('bm_vip_user_is_active')) {
            if (function_exists('bm_vip_feature_enabled') && !bm_vip_feature_enabled('custom_font')) return false;
            return bm_vip_user_is_active($user);
        }
        $role = strtolower(trim((string)($user['role'] ?? 'user')));
        if (in_array($role, ['admin','administrator'], true)) return true;
        if (!in_array($role, ['vip','premium','special'], true)) return false;
        $expiry = trim((string)($user['vip_expires_at'] ?? ''));
        if ($expiry === '') return true;
        $ts = strtotime($expiry);
        return $ts !== false && $ts > time();
    }
}

if (!function_exists('bm_user_font_default_id')) {
    function bm_user_font_default_id(): string
    {
        if (function_exists('bm_site_active_font')) {
            $font = bm_site_active_font();
            $id = strtolower(trim((string)($font['id'] ?? 'bonvf')));
            if (bm_user_font_is_valid($id)) return $id;
        }
        return bm_user_font_is_valid('bonvf') ? 'bonvf' : (string)(array_key_first(bm_user_font_catalog()) ?? 'system');
    }
}

if (!function_exists('bm_user_font_resolve')) {
    function bm_user_font_resolve(?array $user = null): string
    {
        $default = bm_user_font_default_id();
        if (!bm_font_user_can_customize($user)) return $default;
        $cookieFont = strtolower(trim((string)($_COOKIE['user_font'] ?? '')));
        return bm_user_font_is_valid($cookieFont) ? $cookieFont : $default;
    }
}

if (!function_exists('bm_user_font_runtime_css')) {
    function bm_user_font_runtime_css(?array $user = null): string
    {
        if (!bm_font_user_can_customize($user)) return '';
        $id = bm_user_font_resolve($user);
        $catalog = bm_user_font_catalog();
        if (!isset($catalog[$id])) return '';
        $font = $catalog[$id];
        $faces = function_exists('bm_site_font_faces_css') ? bm_site_font_faces_css($font) : '';
        $stack = function_exists('bm_site_font_stack_by_id')
            ? bm_site_font_stack_by_id($id)
            : "Tahoma,Arial,system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif";
        $vars = [
            '--bm-user-font-stack:'.$stack,
            '--bm-site-font:var(--bm-user-font-stack)',
            '--bm-font-base:var(--bm-user-font-stack)',
            '--bm-font-header:var(--bm-user-font-stack)',
            '--bm-font-hero:var(--bm-user-font-stack)',
            '--bm-font-heading:var(--bm-user-font-stack)',
            '--bm-font-body:var(--bm-user-font-stack)',
            '--bm-font-card:var(--bm-user-font-stack)',
            '--bm-font-button:var(--bm-user-font-stack)',
            '--bm-font-form:var(--bm-user-font-stack)',
            '--bm-font-footer:var(--bm-user-font-stack)',
            '--bm-font-mobile:var(--bm-user-font-stack)',
            '--bm-font-meta:var(--bm-user-font-stack)',
        ];
        return $faces."\n:root{".implode(';', $vars)."}\n"
            ."html,body{font-family:var(--bm-user-font-stack)!important}"
            ."button,input,select,textarea{font-family:var(--bm-user-font-stack)!important}";
    }
}

if (!function_exists('bm_theme_current_user')) {
    function bm_theme_current_user(): ?array
    {
        foreach (['currentUser', 'user'] as $key) {
            if (isset($GLOBALS[$key]) && is_array($GLOBALS[$key])) return $GLOBALS[$key];
        }
        return null;
    }
}

if (!function_exists('bm_theme_runtime_markup')) {
    function bm_theme_runtime_markup(): string
    {
        $enabled = !function_exists('bm_site_bool') || bm_site_bool('ui_user_theme_enabled', true);
        $logoEnabled = !function_exists('bm_site_bool') || bm_site_bool('ui_theme_logo_enabled', true);
        $transitions = !function_exists('bm_site_bool') || bm_site_bool('ui_theme_transition_enabled', true);
        $user = bm_theme_current_user();
        $themeAllowed = $enabled && bm_theme_user_can_customize($user);
        $fontAllowed = bm_font_user_can_customize($user);
        $theme = $themeAllowed ? bm_theme_resolve($user) : 'dark-green';
        $font = bm_user_font_resolve($user);
        $background = bm_user_background_resolve($user);
        $avatarFrame = bm_user_avatar_frame_resolve($user);
        $payload = [
            'theme' => $theme,
            'themeAllowed' => $themeAllowed,
            'font' => $font,
            'fontAllowed' => $fontAllowed,
            'background' => $background,
            'avatarFrame' => $avatarFrame,
            'appearanceAllowed' => bm_user_appearance_can_customize($user),
            'authenticated' => is_array($user) && !empty($user['id']),
            'enabled' => $enabled,
            'logoEnabled' => $logoEnabled,
            'transitions' => $transitions,
            'themes' => bm_theme_catalog(),
        ];
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
        if (!is_string($json)) $json = '{}';

        $fontCss = bm_user_font_runtime_css($user);
        $fontMarkup = $fontCss !== '' ? "\n<style id=\"bm-user-font-runtime\">{$fontCss}</style>" : '';

        return '<script id="bm-user-theme-init">window.BM_THEME_SERVER=' . $json . ';(function(){try{var c=window.BM_THEME_SERVER||{},t=c.theme||"dark-green",a=["dark-green","dark-blue","dark-purple","dark-pink","dark-red","dark-orange","dark-cyan","dark-white","dark-black"];if(a.indexOf(t)<0)t="dark-green";document.documentElement.dataset.theme=t;document.documentElement.dataset.bmThemeLogo=c.logoEnabled===false?"0":"1";document.documentElement.dataset.bmThemeMotion=c.transitions===false?"0":"1";document.documentElement.dataset.bmBackground=c.background||"simple";document.documentElement.dataset.bmAvatarFrame=c.avatarFrame||"none";if(c.fontAllowed&&c.font)document.documentElement.dataset.bmUserFont=c.font;else delete document.documentElement.dataset.bmUserFont;}catch(e){}})();</script>'
            . $fontMarkup
            . "\n<link rel=\"stylesheet\" href=\"/assets/css/bm-user-themes-v14842.css?v=14842\">"
            . "\n<link rel=\"stylesheet\" href=\"/assets/css/bm-user-appearance-v14861928.css?v=14861932\">"
            . "\n<script src=\"/assets/js/bm-user-theme-v14842.js?v=14842\" defer></script>";
    }
}

if (!function_exists('bm_theme_runtime_boot')) {
    function bm_theme_runtime_boot(): void
    {
        if (PHP_SAPI === 'cli' || defined('BM_USER_THEME_BUFFER_STARTED')) return;
        define('BM_USER_THEME_BUFFER_STARTED', true);
        ob_start(static function (string $buffer): string {
            if (stripos($buffer, '</head>') === false || stripos($buffer, 'bm-user-theme-init') !== false) {
                return $buffer;
            }
            $markup = bm_theme_runtime_markup();
            return preg_replace('/<\/head>/i', $markup . "\n</head>", $buffer, 1) ?? $buffer;
        });
    }
}


/* BM_THEME_AUTOBOOT_V14861932: guarantee theme/background runtime on every public page that requires this helper.
 * The output-buffer callback resolves the authenticated user at render completion, so early bootstrap is safe. */
if (function_exists('bm_theme_runtime_boot')) {
    bm_theme_runtime_boot();
}

/* BM-INTEGRATED-V3: appearance cache v14861932 */
