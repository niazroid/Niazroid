<?php
/**
 * BankMovie bounded runtime-file cleanup.
 *
 * Only generated cache, lock, temporary, rate-limit and diagnostic log files
 * are touched. Secrets, settings, cookies, uploads, posters, crawler output and
 * sitemap source data are deliberately excluded.
 */
if (defined('BANKMOVIE_PRIVATE_CLEANUP_LOADED')) return;
define('BANKMOVIE_PRIVATE_CLEANUP_LOADED', true);

if (!function_exists('bm_cleanup_interval_seconds')) {
    function bm_cleanup_interval_seconds(): int
    {
        $raw = getenv('BANKMOVIE_CLEANUP_INTERVAL_SECONDS');
        $seconds = is_string($raw) && ctype_digit(trim($raw)) ? (int)$raw : 3600;
        return max(300, min(86400, $seconds));
    }
}

if (!function_exists('bm_cleanup_path_inside')) {
    function bm_cleanup_path_inside(string $path, string $base): bool
    {
        $realPath = @realpath($path);
        $realBase = @realpath($base);
        if (!is_string($realPath) || !is_string($realBase)) return false;
        $realBase = rtrim($realBase, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
        return str_starts_with($realPath, $realBase);
    }
}

if (!function_exists('bm_cleanup_delete_file')) {
    function bm_cleanup_delete_file(string $path, string $base, array &$result): bool
    {
        if (!is_file($path) || is_link($path) || !bm_cleanup_path_inside($path, $base)) return false;
        $size = max(0, (int)@filesize($path));
        if (!@unlink($path)) {
            $result['failed']++;
            return false;
        }
        $result['deleted']++;
        $result['bytes_freed'] += $size;
        return true;
    }
}

if (!function_exists('bm_cleanup_prune_family')) {
    /**
     * @param callable(string, SplFileInfo):bool $accept
     */
    function bm_cleanup_prune_family(
        string $dir,
        callable $accept,
        int $maxAge,
        int $maxFiles,
        int $maxBytes,
        array &$result,
        int $scanLimit = 50000
    ): void {
        if (!is_dir($dir) || !is_readable($dir)) return;
        $now = time();
        $files = [];
        $total = 0;
        $scanned = 0;
        try {
            $iterator = new DirectoryIterator($dir);
            foreach ($iterator as $entry) {
                if (++$scanned > $scanLimit) break;
                if ($entry->isDot() || !$entry->isFile() || $entry->isLink()) continue;
                $path = $entry->getPathname();
                if (!$accept($entry->getFilename(), $entry)) continue;
                $mtime = (int)$entry->getMTime();
                $size = max(0, (int)$entry->getSize());
                if ($maxAge > 0 && ($now - $mtime) > $maxAge) {
                    bm_cleanup_delete_file($path, $dir, $result);
                    continue;
                }
                $files[] = ['path' => $path, 'mtime' => $mtime, 'size' => $size];
                $total += $size;
            }
        } catch (Throwable $e) {
            $result['failed']++;
            return;
        }

        usort($files, static fn(array $a, array $b): int => $a['mtime'] <=> $b['mtime']);
        while (($maxFiles > 0 && count($files) > $maxFiles) || ($maxBytes > 0 && $total > $maxBytes)) {
            $oldest = array_shift($files);
            if (!$oldest) break;
            if (bm_cleanup_delete_file((string)$oldest['path'], $dir, $result)) {
                $total -= (int)$oldest['size'];
            }
        }
    }
}

if (!function_exists('bm_cleanup_rotate_log')) {
    function bm_cleanup_rotate_log(string $path, int $maxBytes, array &$result): void
    {
        if (!is_file($path) || is_link($path) || (int)@filesize($path) <= $maxBytes) return;
        $dir = dirname($path);
        if (!bm_cleanup_path_inside($path, $dir)) return;
        $backup = $path . '.1';
        if (is_file($backup)) bm_cleanup_delete_file($backup, $dir, $result);
        if (@rename($path, $backup)) {
            @chmod($backup, 0600);
            $result['rotated']++;
        } else {
            $result['failed']++;
        }
    }
}

if (!function_exists('bm_cleanup_rate_limits')) {
    function bm_cleanup_rate_limits(string $dir, array &$result): void
    {
        if (!is_dir($dir) || !is_readable($dir)) return;
        $now = time();
        $remaining = [];
        $scanned = 0;
        try {
            foreach (new DirectoryIterator($dir) as $entry) {
                if (++$scanned > 50000) break;
                if ($entry->isDot() || !$entry->isFile() || $entry->isLink()) continue;
                $name = $entry->getFilename();
                if (!preg_match('/^[a-f0-9]{64}\.json$/i', $name)) continue;
                $path = $entry->getPathname();
                $mtime = (int)$entry->getMTime();
                $expired = ($now - $mtime) > 172800;
                if (!$expired && $entry->getSize() <= 4096) {
                    $raw = @file_get_contents($path);
                    $state = is_string($raw) ? json_decode($raw, true) : null;
                    if (is_array($state) && (int)($state['reset_at'] ?? 0) > 0) {
                        $expired = (int)$state['reset_at'] < ($now - 3600);
                    }
                }
                if ($expired) {
                    bm_cleanup_delete_file($path, $dir, $result);
                } else {
                    $remaining[] = ['path' => $path, 'mtime' => $mtime, 'size' => max(0, (int)$entry->getSize())];
                }
            }
        } catch (Throwable $e) {
            $result['failed']++;
            return;
        }

        usort($remaining, static fn(array $a, array $b): int => $a['mtime'] <=> $b['mtime']);
        while (count($remaining) > 20000) {
            $oldest = array_shift($remaining);
            if (!$oldest) break;
            bm_cleanup_delete_file((string)$oldest['path'], $dir, $result);
        }
    }
}

if (!function_exists('bm_private_cleanup_run')) {
    /** @return array<string,mixed> */
    function bm_private_cleanup_run(bool $force = false): array
    {
        $started = microtime(true);
        $private = function_exists('bm_security_private_dir')
            ? bm_security_private_dir()
            : dirname(__DIR__) . DIRECTORY_SEPARATOR . '_bankmovie_private';
        if (!is_dir($private)) @mkdir($private, 0700, true);

        $result = [
            'success' => true,
            'skipped' => false,
            'deleted' => 0,
            'rotated' => 0,
            'failed' => 0,
            'bytes_freed' => 0,
            'interval_seconds' => bm_cleanup_interval_seconds(),
            'ran_at' => date('c'),
        ];
        if (!is_dir($private) || !is_writable($private)) {
            $result['success'] = false;
            $result['reason'] = 'private_directory_unavailable';
            return $result;
        }

        $stamp = $private . DIRECTORY_SEPARATOR . '.maintenance.stamp';
        if (!$force && is_file($stamp) && (time() - (int)@filemtime($stamp)) < bm_cleanup_interval_seconds()) {
            $result['skipped'] = true;
            $result['reason'] = 'interval_not_due';
            return $result;
        }

        $lockPath = $private . DIRECTORY_SEPARATOR . '.maintenance.lock';
        $lock = @fopen($lockPath, 'c+');
        if (!$lock || !@flock($lock, LOCK_EX | LOCK_NB)) {
            if (is_resource($lock)) @fclose($lock);
            $result['skipped'] = true;
            $result['reason'] = 'cleanup_already_running';
            return $result;
        }

        try {
            clearstatcache(true, $stamp);
            if (!$force && is_file($stamp) && (time() - (int)@filemtime($stamp)) < bm_cleanup_interval_seconds()) {
                $result['skipped'] = true;
                $result['reason'] = 'interval_not_due_after_lock';
                return $result;
            }

            // API2 root caches: ten-minute content, retained for at most one hour.
            bm_cleanup_prune_family(
                $private,
                static fn(string $name): bool => (bool)preg_match('/^api2_(?:html|json)_[a-f0-9]{40}\.cache$/i', $name),
                3600,
                500,
                128 * 1024 * 1024,
                $result
            );
            bm_cleanup_prune_family(
                $private,
                static fn(string $name): bool => (bool)preg_match('/^api2_(?:html|json)_[a-f0-9]{40}\.cache(?:\.lock|\.[^.]+\.tmp)$/i', $name),
                7200,
                1000,
                8 * 1024 * 1024,
                $result
            );

            // API6 already self-cleans on writes; this hourly pass is a second safety net.
            $api6 = $private . DIRECTORY_SEPARATOR . 'cache' . DIRECTORY_SEPARATOR . 'api6';
            bm_cleanup_prune_family(
                $api6,
                static fn(string $name): bool => (bool)preg_match('/\.html(?:\.gz)?$/i', $name),
                3600,
                300,
                64 * 1024 * 1024,
                $result
            );
            bm_cleanup_prune_family(
                $api6,
                static fn(string $name): bool => (bool)preg_match('/\.tmp$/i', $name),
                900,
                200,
                16 * 1024 * 1024,
                $result
            );

            // Movie detail cache is intentionally valid as stale fallback for seven days.
            $details = $private . DIRECTORY_SEPARATOR . 'cache' . DIRECTORY_SEPARATOR . 'movie-details';
            bm_cleanup_prune_family(
                $details,
                static fn(string $name): bool => (bool)preg_match('/^[a-z0-9_-]+-[a-f0-9]{40}\.json$/i', $name),
                8 * 86400,
                10000,
                512 * 1024 * 1024,
                $result
            );
            bm_cleanup_prune_family(
                $details,
                static fn(string $name): bool => (bool)preg_match('/\.(?:fetch\.lock|refresh|refresh\.lock|tmp)$/i', $name),
                2 * 86400,
                30000,
                32 * 1024 * 1024,
                $result
            );

            bm_cleanup_rate_limits($private . DIRECTORY_SEPARATOR . 'rate-limits', $result);

            // Archive1 live cache is stored in the system temp directory.
            $tmp = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR);
            bm_cleanup_prune_family(
                $tmp,
                static fn(string $name): bool => (bool)preg_match('/^bankmovie_a1_[a-f0-9]{64}\.json$/i', $name),
                3600,
                500,
                64 * 1024 * 1024,
                $result,
                20000
            );

            // Abandoned atomic-write files only. Stable settings/data are never matched.
            bm_cleanup_prune_family(
                $private,
                static fn(string $name): bool => (bool)preg_match('/\.tmp(?:\.[A-Za-z0-9_-]+)*$/', $name),
                21600,
                500,
                64 * 1024 * 1024,
                $result
            );

            $root = dirname(__DIR__);
            $logs = [
                $private . '/security-audit.log',
                $private . '/php-errors.log',
                $private . '/php-error.log',
                $private . '/admin-error.log',
                $private . '/slow-requests.log',
                $root . '/logs/php-errors.log',
                $root . '/logs/admin-error.log',
                $root . '/logs/bankmovie_admin_audit.log',
            ];
            foreach (array_unique($logs) as $logPath) {
                bm_cleanup_rotate_log($logPath, 8 * 1024 * 1024, $result);
            }

            $result['duration_ms'] = round((microtime(true) - $started) * 1000, 2);
            $summary = json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            @file_put_contents($stamp, is_string($summary) ? $summary : (string)time(), LOCK_EX);
            @chmod($stamp, 0600);
        } catch (Throwable $e) {
            $result['success'] = false;
            $result['failed']++;
            $result['reason'] = 'cleanup_exception';
            $result['duration_ms'] = round((microtime(true) - $started) * 1000, 2);
        } finally {
            @flock($lock, LOCK_UN);
            @fclose($lock);
        }
        return $result;
    }
}

if (!function_exists('bm_private_cleanup_maybe_schedule')) {
    function bm_private_cleanup_maybe_schedule(): void
    {
        if (PHP_SAPI === 'cli') return;
        $private = function_exists('bm_security_private_dir') ? bm_security_private_dir() : '';
        if ($private === '') return;
        $stamp = rtrim($private, '/\\') . DIRECTORY_SEPARATOR . '.maintenance.stamp';
        if (is_file($stamp) && (time() - (int)@filemtime($stamp)) < bm_cleanup_interval_seconds()) return;
        register_shutdown_function(static function (): void {
            bm_private_cleanup_run(false);
        });
    }
}
