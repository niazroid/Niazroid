<?php
/**
 * BankMovie VIP capability registry.
 *
 * Benefit switches enable an extra privilege for active VIP accounts.
 * Gate switches are intentionally disabled by default; while disabled the
 * related public feature remains available to every user. Enabling a gate
 * later makes only that feature VIP-only without changing its implementation.
 */
declare(strict_types=1);

require_once __DIR__ . '/security_bootstrap.php';

if (!function_exists('bm_vip_feature_catalog')) {
    function bm_vip_feature_catalog(): array
    {
        return [
            'ad_free' => [
                'label' => 'حذف کامل تبلیغات',
                'description' => 'بنرهای داخلی، تبلیغات شناور و یکتانت برای اعضای VIP نمایش داده نمی‌شوند تا تجربه تماشا تمیزتر و بدون مزاحمت باشد.',
                'group' => 'benefit', 'default' => true, 'icon' => 'fa-ban',
            ],
            'watch_party' => [
                'label' => 'Watch Party؛ تماشا + Voice Call + استیکر',
                'description' => 'عضو VIP اتاق خصوصی می‌سازد، پارتنر یا دوستش را رایگان دعوت می‌کند و با پخش همگام، چت، Voice Call و استیکر/GIF همزمان فیلم می‌بینند.',
                'group' => 'benefit', 'default' => true, 'icon' => 'fa-people-group',
            ],
            'custom_avatar' => [
                'label' => 'آپلود آواتار اختصاصی',
                'description' => 'اعضای VIP می‌توانند تصویر شخصی خود را برای آواتار بارگذاری کنند.',
                'group' => 'benefit', 'default' => true, 'icon' => 'fa-user-astronaut',
            ],
            'vip_badge' => [
                'label' => 'نشان VIP در پروفایل و چت',
                'description' => 'نمایش نشان اختصاصی عضویت در بخش‌های اجتماعی سایت.',
                'group' => 'benefit', 'default' => true, 'icon' => 'fa-crown',
            ],
            'vip_support' => [
                'label' => 'پشتیبانی VIP شبانه‌روزی',
                'description' => 'اولویت پاسخ‌گویی به اعضای VIP در مسیر پشتیبانی.',
                'group' => 'benefit', 'default' => true, 'icon' => 'fa-headset',
            ],
            'content_requests' => [
                'label' => 'درخواست فیلم و سریال',
                'description' => 'امکان ثبت درخواست با اولویت VIP.',
                'group' => 'benefit', 'default' => true, 'icon' => 'fa-clapperboard',
            ],
            'custom_theme' => [
                'label' => 'انتخاب تم اختصاصی سایت',
                'description' => 'انتخاب رنگ و ظاهر اختصاصی BankMovie فقط برای اعضای VIP فعال است.',
                'group' => 'benefit', 'default' => true, 'icon' => 'fa-palette',
            ],
            'custom_font' => [
                'label' => 'انتخاب فونت سایت',
                'description' => 'اعضای VIP می‌توانند فونت رابط BankMovie را از فونت‌های داخلی سایت شخصی‌سازی کنند.',
                'group' => 'benefit', 'default' => true, 'icon' => 'fa-font',
            ],
            // Prepared gates. They remain OFF so current free access is unchanged.
            'online_watch' => [
                'label' => 'تماشای آنلاین صفحه فیلم',
                'description' => 'در صورت فعال‌سازی، دکمه‌ها و مسیرهای تماشای آنلاین فقط برای VIP باز می‌شوند.',
                'group' => 'gate', 'default' => false, 'icon' => 'fa-circle-play',
            ],
            'downloads' => [
                'label' => 'دانلود فیلم و سریال',
                'description' => 'در صورت فعال‌سازی، لینک‌های دانلود فقط برای VIP قابل استفاده خواهند بود.',
                'group' => 'gate', 'default' => false, 'icon' => 'fa-download',
            ],
            'subtitle_downloads' => [
                'label' => 'دانلود زیرنویس',
                'description' => 'در صورت فعال‌سازی، دریافت فایل زیرنویس فقط برای VIP خواهد بود.',
                'group' => 'gate', 'default' => false, 'icon' => 'fa-closed-captioning',
            ],
            'online_player' => [
                'label' => 'پلیر آنلاین مستقل',
                'description' => 'در صورت فعال‌سازی، صفحه پلیر آنلاین فقط برای VIP باز می‌شود.',
                'group' => 'gate', 'default' => false, 'icon' => 'fa-display',
            ],
            'advanced_search' => [
                'label' => 'جستجوی پیشرفته',
                'description' => 'کلید آماده برای محدودکردن فیلترهای حرفه‌ای در آینده.',
                'group' => 'gate', 'default' => false, 'icon' => 'fa-magnifying-glass-plus',
            ],
            'watchlist' => [
                'label' => 'واچ‌لیست و علاقه‌مندی‌ها',
                'description' => 'کلید آماده برای تبدیل واچ‌لیست به قابلیت VIP در آینده.',
                'group' => 'gate', 'default' => false, 'icon' => 'fa-bookmark',
            ],
            'collections' => [
                'label' => 'کالکشن‌ها',
                'description' => 'کلید آماده برای محدودکردن کالکشن‌ها در آینده.',
                'group' => 'gate', 'default' => false, 'icon' => 'fa-layer-group',
            ],
            'comments_ratings' => [
                'label' => 'نظر و امتیاز کاربران',
                'description' => 'کلید آماده برای محدودکردن تعاملات اجتماعی در آینده.',
                'group' => 'gate', 'default' => false, 'icon' => 'fa-comments',
            ],
        ];
    }
}

if (!function_exists('bm_vip_features_path')) {
    function bm_vip_features_path(): string
    {
        return bm_security_private_path('vip-feature-settings.json');
    }
}

if (!function_exists('bm_vip_feature_defaults')) {
    function bm_vip_feature_defaults(): array
    {
        $values = [];
        foreach (bm_vip_feature_catalog() as $key => $meta) {
            $values[$key] = !empty($meta['default']);
        }
        return ['version' => 1, 'features' => $values];
    }
}

if (!function_exists('bm_vip_feature_settings')) {
    function bm_vip_feature_settings(bool $refresh = false): array
    {
        static $cache = null;
        if (!$refresh && is_array($cache)) return $cache;
        $defaults = bm_vip_feature_defaults();
        $raw = is_file(bm_vip_features_path()) ? @file_get_contents(bm_vip_features_path()) : false;
        $stored = is_string($raw) ? json_decode($raw, true) : null;
        $features = $defaults['features'];
        if (is_array($stored) && isset($stored['features']) && is_array($stored['features'])) {
            foreach ($features as $key => $default) {
                if (array_key_exists($key, $stored['features'])) $features[$key] = !empty($stored['features'][$key]);
            }
        }
        return $cache = ['version' => 1, 'features' => $features];
    }
}

if (!function_exists('bm_vip_feature_enabled')) {
    function bm_vip_feature_enabled(string $key): bool
    {
        $settings = bm_vip_feature_settings();
        return !empty($settings['features'][$key]);
    }
}

if (!function_exists('bm_vip_feature_save')) {
    function bm_vip_feature_save(array $input): bool
    {
        $features = [];
        foreach (bm_vip_feature_catalog() as $key => $meta) {
            $features[$key] = !empty($input[$key]);
        }
        $json = json_encode(['version' => 1, 'features' => $features], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) return false;
        $path = bm_vip_features_path();
        $dir = dirname($path);
        if (!is_dir($dir) && !@mkdir($dir, 0700, true) && !is_dir($dir)) return false;
        $tmp = $path . '.tmp.' . bin2hex(random_bytes(5));
        if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
        @chmod($tmp, 0600);
        if (!@rename($tmp, $path)) { @unlink($tmp); return false; }
        bm_vip_feature_settings(true);
        return true;
    }
}

if (!function_exists('bm_vip_ensure_history_columns')) {
    /**
     * Keep the last paid expiry so the profile can offer a renewal after the
     * active VIP role is normalized back to a regular user.
     */
    function bm_vip_ensure_history_columns(PDO $pdo): bool
    {
        static $ready = null;
        if ($ready !== null) return $ready;
        try {
            $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'vip_last_expires_at'");
            $exists = $stmt && $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$exists) {
                $pdo->exec("ALTER TABLE users ADD COLUMN vip_last_expires_at DATETIME NULL AFTER vip_expires_at");
                try { $pdo->exec("ALTER TABLE users ADD INDEX idx_users_vip_last_expiry (vip_last_expires_at)"); } catch (Throwable $ignored) {}
            }
            return $ready = true;
        } catch (Throwable $e) {
            error_log('VIP history column setup failed: ' . $e->getMessage());
            return $ready = false;
        }
    }
}

if (!function_exists('bm_vip_expire_user_if_needed')) {
    /**
     * Immediately demotes an expired VIP account so every role-based legacy
     * check sees a normal user on the very same request.
     */
    function bm_vip_expire_user_if_needed(PDO $pdo, ?array &$user): bool
    {
        if (!is_array($user) || empty($user['id'])) return false;
        $role = strtolower(trim((string)($user['role'] ?? 'user')));
        if (!in_array($role, ['vip', 'premium', 'special'], true)) return false;
        $expiry = trim((string)($user['vip_expires_at'] ?? ''));
        if ($expiry === '') return false; // lifetime / manually open membership
        $timestamp = strtotime($expiry);
        if ($timestamp !== false && $timestamp > time()) return false;

        try {
            $historyReady = bm_vip_ensure_history_columns($pdo);
            if ($historyReady) {
                $stmt = $pdo->prepare("UPDATE users SET vip_last_expires_at=vip_expires_at, role='user', vip_expires_at=NULL WHERE id=? AND LOWER(role) IN ('vip','premium','special')");
            } else {
                $stmt = $pdo->prepare("UPDATE users SET role='user', vip_expires_at=NULL WHERE id=? AND LOWER(role) IN ('vip','premium','special')");
            }
            $stmt->execute([(int)$user['id']]);
            // An already-open Watch Party is also a paid capability. Remove
            // rooms hosted by the expired account; dependent members/messages
            // are removed by the existing foreign-key cascade.
            try {
                $roomStmt = $pdo->prepare('DELETE FROM watch_party_rooms WHERE host_user_id=?');
                $roomStmt->execute([(int)$user['id']]);
            } catch (Throwable $ignored) {
                // The table may not exist on installations that never enabled Watch Party.
            }
        } catch (Throwable $e) {
            error_log('VIP expiry normalization failed: ' . $e->getMessage());
        }
        $user['role'] = 'user';
        $user['vip_last_expires_at'] = $expiry;
        $user['vip_expires_at'] = null;
        return true;
    }
}

if (!function_exists('bm_vip_remaining')) {
    function bm_vip_remaining(?array $user): array
    {
        $inactive = ['active'=>false,'lifetime'=>false,'expired'=>false,'seconds'=>0,'days'=>0,'hours'=>0,'minutes'=>0,'expires_at'=>null];
        if (!is_array($user)) return $inactive;
        $role = strtolower(trim((string)($user['role'] ?? 'user')));
        if (!in_array($role, ['vip','premium','special'], true)) return $inactive;
        $expiry = trim((string)($user['vip_expires_at'] ?? ''));
        if ($expiry === '') return ['active'=>true,'lifetime'=>true,'expired'=>false,'seconds'=>PHP_INT_MAX,'days'=>null,'hours'=>null,'minutes'=>null,'expires_at'=>null];
        $ts = strtotime($expiry);
        if ($ts === false || $ts <= time()) {
            return ['active'=>false,'lifetime'=>false,'expired'=>true,'seconds'=>0,'days'=>0,'hours'=>0,'minutes'=>0,'expires_at'=>$expiry];
        }
        $seconds = $ts - time();
        return [
            'active'=>true,'lifetime'=>false,'expired'=>false,'seconds'=>$seconds,
            'days'=>(int)ceil($seconds / 86400),
            'hours'=>(int)floor(($seconds % 86400) / 3600),
            'minutes'=>(int)floor(($seconds % 3600) / 60),
            'expires_at'=>$expiry,
        ];
    }
}

if (!function_exists('bm_vip_user_is_active')) {
    function bm_vip_user_is_active(?array $user): bool
    {
        if (!is_array($user)) return false;
        $role = strtolower(trim((string)($user['role'] ?? 'user')));
        if (in_array($role, ['admin', 'administrator'], true)) return true;
        if (!in_array($role, ['vip', 'premium', 'special'], true)) return false;
        $expiry = trim((string)($user['vip_expires_at'] ?? ''));
        if ($expiry === '') return true;
        $timestamp = strtotime($expiry);
        return $timestamp !== false && $timestamp > time();
    }
}

if (!function_exists('bm_vip_user_has_membership')) {
    function bm_vip_user_has_membership(?array $user): bool
    {
        if (!is_array($user)) return false;
        $role = strtolower(trim((string)($user['role'] ?? 'user')));
        if (in_array($role, ['admin', 'administrator'], true)) return true;
        if (!in_array($role, ['vip', 'premium', 'special'], true)) return false;
        return bm_vip_user_is_active($user);
    }
}

if (!function_exists('bm_vip_user_is_member_role')) {
    function bm_vip_user_is_member_role(?array $user): bool
    {
        if (!is_array($user)) return false;
        $role = strtolower(trim((string)($user['role'] ?? 'user')));
        return in_array($role, ['vip', 'premium', 'special'], true) && bm_vip_user_is_active($user);
    }
}

if (!function_exists('bm_vip_user_is_admin_role')) {
    function bm_vip_user_is_admin_role(?array $user): bool
    {
        if (!is_array($user)) return false;
        return in_array(strtolower(trim((string)($user['role'] ?? ''))), ['admin', 'administrator'], true);
    }
}

if (!function_exists('bm_vip_member_badge_html')) {
    function bm_vip_member_badge_html(?array $user, bool $compact = false): string
    {
        if (!bm_vip_feature_enabled('vip_badge') || !bm_vip_user_is_member_role($user)) return '';
        if (function_exists('bm_site_bool') && !bm_site_bool('ui_vip_member_badge_enabled', true)) return '';
        $class = 'bm-vip-member-badge' . ($compact ? ' is-compact' : '');
        return '<span class="' . $class . '" title="عضو VIP بانک مووی" aria-label="BankMovie VIP member">'
            . '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 7 4.5 4L12 4l4.5 7L21 7l-2 10H5L3 7Z"/><path d="M6 18h12"/></svg>'
            . '<span>VIP</span></span>';
    }
}

if (!function_exists('bm_vip_benefit_allowed')) {
    function bm_vip_benefit_allowed(string $key, ?array $user): bool
    {
        return bm_vip_feature_enabled($key) && bm_vip_user_is_active($user);
    }
}

if (!function_exists('bm_vip_gate_allows')) {
    function bm_vip_gate_allows(string $key, ?array $user): bool
    {
        return !bm_vip_feature_enabled($key) || bm_vip_user_is_active($user);
    }
}

if (!function_exists('bm_vip_ad_free_for_user')) {
    function bm_vip_ad_free_for_user(?array $user): bool
    {
        return bm_vip_benefit_allowed('ad_free', $user);
    }
}

if (!function_exists('bm_vip_sales_url')) {
    function bm_vip_sales_url(string $feature = '', ?string $returnUrl = null): string
    {
        $params = [];
        $feature = trim($feature);
        if ($feature !== '') $params['feature'] = $feature;
        $returnUrl = $returnUrl ?? (string)($_SERVER['REQUEST_URI'] ?? '');
        if ($returnUrl !== '') $params['return'] = $returnUrl;
        return '/vip' . ($params ? ('?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986)) : '');
    }
}

if (!function_exists('bm_vip_gate_require')) {
    function bm_vip_gate_require(string $key, ?array $user, bool $json = false): void
    {
        if (bm_vip_gate_allows($key, $user)) return;
        if ($json) {
            if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
            http_response_code(403);
            echo json_encode([
                'success' => false,
                'error' => 'vip_required',
                'message' => 'این قابلیت برای اعضای VIP فعال است.',
                'purchase_url' => bm_vip_sales_url($key),
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit;
        }
        if (function_exists('bm_vip_render_gate_screen')) {
            bm_vip_render_gate_screen($key, $user, (string)($_SERVER['REQUEST_URI'] ?? '/'));
        }
        header('Location: ' . bm_vip_sales_url($key));
        exit;
    }
}


if (!function_exists('bm_vip_safe_return_path')) {
    function bm_vip_safe_return_path(?string $value, string $fallback = '/'): string
    {
        $value = trim((string)$value);
        if ($value === '') return $fallback;
        if (preg_match('/[\r\n]/', $value)) return $fallback;
        if (str_starts_with($value, '/') && !str_starts_with($value, '//')) {
            return $value;
        }
        $parts = @parse_url($value);
        if (!is_array($parts) || empty($parts['host'])) return $fallback;
        $requestHost = strtolower(preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? '')));
        $returnHost = strtolower((string)$parts['host']);
        if ($requestHost === '' || !hash_equals($requestHost, $returnHost)) return $fallback;
        $path = (string)($parts['path'] ?? '/');
        if ($path === '' || $path[0] !== '/') $path = '/';
        if (isset($parts['query']) && $parts['query'] !== '') $path .= '?' . $parts['query'];
        if (isset($parts['fragment']) && $parts['fragment'] !== '') $path .= '#' . $parts['fragment'];
        return $path;
    }
}

if (!function_exists('bm_vip_gate_copy')) {
    function bm_vip_gate_copy(string $key): array
    {
        $map = [
            'watch_party' => ['تماشای دونفره با میزبان VIP', 'ساخت اتاق برای عضو VIP است؛ همراه با لینک دعوت، رایگان و بدون ثبت‌نام وارد اتاق می‌شود.'],
            'online_watch' => ['پخش آنلاین ویژه اعضای VIP', 'برای پخش مستقیم این فیلم یا سریال، اشتراک VIP فعال لازم است.'],
            'online_player' => ['پلیر آنلاین ویژه اعضای VIP', 'دسترسی به پلیر آنلاین مستقل برای اعضای VIP فعال شده است.'],
            'downloads' => ['دانلود ویژه اعضای VIP', 'برای دریافت این فایل، اشتراک VIP فعال لازم است.'],
            'subtitle_downloads' => ['زیرنویس ویژه اعضای VIP', 'برای دریافت فایل زیرنویس، اشتراک VIP فعال لازم است.'],
            'watchlist' => ['واچ‌لیست ویژه اعضای VIP', 'برای ذخیره عنوان‌ها و استفاده از واچ‌لیست، اشتراک VIP فعال لازم است.'],
            'comments_ratings' => ['تعاملات ویژه اعضای VIP', 'ثبت دیدگاه، پاسخ و امتیازدهی در این حالت برای اعضای VIP فعال است.'],
        ];
        return $map[$key] ?? ['این قابلیت ویژه اعضای VIP است', 'برای استفاده از این قابلیت، اشتراک VIP فعال لازم است.'];
    }
}

if (!function_exists('bm_vip_render_gate_screen')) {
    function bm_vip_render_gate_screen(string $key, ?array $user, ?string $returnUrl = null): never
    {
        [$title, $description] = bm_vip_gate_copy($key);
        $returnPath = bm_vip_safe_return_path($returnUrl ?? (string)($_SERVER['REQUEST_URI'] ?? '/'), '/');
        $purchaseUrl = bm_vip_sales_url($key, $returnPath);
        $loginUrl = '/login?' . http_build_query(['return' => $returnPath], '', '&', PHP_QUERY_RFC3986);
        $registerUrl = '/register?' . http_build_query(['return' => $returnPath], '', '&', PHP_QUERY_RFC3986);
        $loggedIn = is_array($user) && !empty($user['id']);
        if (!headers_sent()) {
            http_response_code(403);
            header('Content-Type: text/html; charset=utf-8');
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private');
            header('X-Robots-Tag: noindex, nofollow, noarchive', true);
        }
        $esc = static fn($value): string => htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        ?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="robots" content="noindex,nofollow,noarchive">
<meta name="theme-color" content="#070910">
<title><?= $esc($title) ?> | BankMovie</title>
<style>
@font-face{font-family:BonVF;src:url('/assets/fonts/bonVF.woff2') format('woff2');font-weight:100 900;font-display:swap}*{box-sizing:border-box}body{margin:0;min-height:100svh;display:grid;place-items:center;padding:18px;color:#fff;font-family:BonVF,Tahoma,system-ui,sans-serif;background:radial-gradient(circle at 18% 8%,rgba(99,72,255,.23),transparent 31%),radial-gradient(circle at 88% 90%,rgba(25,138,255,.16),transparent 32%),#070910}.veil{position:fixed;inset:0;background:linear-gradient(135deg,rgba(3,5,10,.24),rgba(3,5,10,.68));backdrop-filter:blur(4px);pointer-events:none}.gate{position:relative;width:min(470px,100%);overflow:hidden;border-radius:30px;padding:30px 27px 25px;text-align:center;background:linear-gradient(155deg,rgba(20,23,35,.985),rgba(8,10,18,.985));border:1px solid rgba(255,255,255,.10);box-shadow:0 38px 110px rgba(0,0,0,.62),0 0 55px rgba(93,64,255,.13)}.gate:before,.gate:after{content:"";position:absolute;width:230px;height:230px;border-radius:50%;pointer-events:none}.gate:before{top:-110px;right:-80px;background:radial-gradient(circle,rgba(122,86,255,.32),transparent 68%)}.gate:after{bottom:-130px;left:-80px;background:radial-gradient(circle,rgba(35,149,255,.18),transparent 68%)}.inner{position:relative;z-index:1}.emblem{width:74px;height:74px;margin:0 auto 15px;border-radius:25px;display:grid;place-items:center;color:#1b1000;background:linear-gradient(145deg,#fff5bb,#ffd45e 28%,#f7a916 62%,#fff0a0);box-shadow:0 16px 42px rgba(247,169,22,.24),inset 0 1px 0 rgba(255,255,255,.85)}.emblem svg{width:35px;height:35px;fill:none;stroke:currentColor;stroke-width:1.9}.tag{display:inline-flex;align-items:center;gap:7px;padding:6px 10px;border-radius:999px;background:rgba(255,196,54,.08);border:1px solid rgba(255,208,93,.18);color:#ffd978;font-size:9px;font-weight:1000;letter-spacing:.08em}.tag i{width:5px;height:5px;border-radius:50%;background:#ffe07d;box-shadow:0 0 13px #ffd45e}h1{margin:11px 0 0;font-size:clamp(22px,5vw,28px);line-height:1.4;letter-spacing:-.035em}p{margin:11px auto 0;max-width:390px;color:rgba(231,235,246,.66);font-size:12px;line-height:2}.note{margin-top:17px;padding:12px 13px;border-radius:16px;text-align:right;color:rgba(230,234,244,.58);font-size:10.5px;line-height:1.85;background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.065)}.actions{display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-top:19px}.actions.member{grid-template-columns:1fr}.btn{min-height:47px;padding:10px 13px;border-radius:14px;display:flex;align-items:center;justify-content:center;text-decoration:none;color:#eef2ff;font-size:11px;font-weight:950;background:rgba(255,255,255,.055);border:1px solid rgba(255,255,255,.09)}.btn.primary{grid-column:1/-1;color:#100b02;border:0;background:linear-gradient(135deg,#fff3a9,#ffc33d 48%,#f39a12);box-shadow:0 12px 30px rgba(243,154,18,.18)}.member .btn.primary{grid-column:auto}.btn.back{background:rgba(255,255,255,.035);color:rgba(236,239,248,.68)}.foot{margin-top:14px;color:rgba(230,234,244,.36);font-size:9.5px}@media(max-width:520px){body{align-items:end;padding:12px}.gate{border-radius:28px 28px 20px 20px;padding:27px 18px 20px}.actions{grid-template-columns:1fr}.btn.primary{grid-column:auto}}
</style>
</head>
<body>
<div class="veil"></div>
<main class="gate" role="dialog" aria-modal="true" aria-labelledby="vipGateTitle">
<div class="inner">
<div class="emblem" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="m3 7 4.5 4L12 4l4.5 7L21 7l-2 11H5L3 7Z"/><path d="M6 18h12"/></svg></div>
<span class="tag"><i></i>BANKMOVIE VIP</span>
<h1 id="vipGateTitle"><?= $esc($title) ?></h1>
<p><?= $esc($description) ?></p>
<div class="note"><?= $loggedIn ? 'حساب شما فعال است، اما اشتراک VIP ندارد. پلن موردنظر را انتخاب کنید و فعال‌سازی را با پشتیبانی بانک‌مووی هماهنگ کنید.' : 'ابتدا وارد حساب شوید یا رایگان ثبت‌نام کنید. سپس از صفحه VIP پلن خود را انتخاب و فعال‌سازی را با پشتیبانی هماهنگ کنید.' ?></div>
<div class="actions <?= $loggedIn ? 'member' : '' ?>">
<a class="btn primary" href="<?= $esc($purchaseUrl) ?>">مشاهده پلن‌ها و خرید VIP</a>
<?php if (!$loggedIn): ?><a class="btn" href="<?= $esc($loginUrl) ?>">ورود به حساب</a><a class="btn" href="<?= $esc($registerUrl) ?>">ثبت‌نام رایگان</a><?php endif; ?>
<a class="btn back" href="javascript:history.length>1?history.back():location.href='/'">بازگشت</a>
</div>
<div class="foot">فعال‌سازی اشتراک پس از هماهنگی با پشتیبانی بانک‌مووی انجام می‌شود.</div>
</div>
</main>
</body>
</html>
        <?php
        exit;
    }
}
