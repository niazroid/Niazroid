<?php
/**
 * Shared sticker / GIF pack registry for Watch Party and VIP movie comments.
 * Registry data is stored in the private BankMovie storage. Media files remain
 * in public site folders such as sticker/<pack> or uploads/<pack>.
 */
declare(strict_types=1);

require_once __DIR__ . '/security_bootstrap.php';

if (!function_exists('bm_sticker_pack_allowed_extensions')) {
    function bm_sticker_pack_allowed_extensions(): array
    {
        return ['webm','webp','gif','png','jpg','jpeg'];
    }
}

if (!function_exists('bm_sticker_pack_defaults')) {
    function bm_sticker_pack_defaults(): array
    {
        return [
            'duck' => [
                'label' => 'Duck',
                'path' => 'sticker/duck',
                'extensions' => ['webm'],
                'enabled' => true,
                // Compatibility with the deployment where numbered Duck files
                // were placed directly in /uploads.
                'fallback_paths' => [
                    ['path'=>'uploads/sticker/duck','numeric_only'=>false],
                    ['path'=>'uploads/duck','numeric_only'=>false],
                    ['path'=>'uploads','numeric_only'=>true],
                ],
            ],
            'pepe' => [
                'label' => 'Pepe',
                'path' => 'sticker/pepe',
                'extensions' => ['webp'],
                'enabled' => true,
                'fallback_paths' => [
                    ['path'=>'uploads/sticker/pepe','numeric_only'=>false],
                    ['path'=>'uploads/pepe','numeric_only'=>false],
                ],
            ],
        ];
    }
}

if (!function_exists('bm_sticker_pack_settings_path')) {
    function bm_sticker_pack_settings_path(): string
    {
        return bm_security_private_path('sticker-packs.json');
    }
}

if (!function_exists('bm_sticker_pack_slug')) {
    function bm_sticker_pack_slug(string $value): string
    {
        $value = strtolower(trim($value));
        $value = preg_replace('/[^a-z0-9_-]+/', '-', $value) ?? '';
        return substr(trim($value, '-_'), 0, 40);
    }
}

if (!function_exists('bm_sticker_pack_relative_path')) {
    function bm_sticker_pack_relative_path(string $value): string
    {
        $value = trim(str_replace('\\', '/', $value));
        $value = preg_replace('~/+~', '/', $value) ?? '';
        $value = trim($value, '/');
        if ($value === '' || str_contains($value, '..') || preg_match('/^[a-zA-Z]:/', $value)) return '';
        // Media packs are intentionally constrained to public media roots.
        if (!preg_match('~^(?:sticker|uploads)(?:/|$)~', $value)) return '';
        if (preg_match('/[\x00-\x1F\x7F]/', $value)) return '';
        return substr($value, 0, 220);
    }
}

if (!function_exists('bm_sticker_pack_normalize')) {
    function bm_sticker_pack_normalize(string $slug, array $pack): ?array
    {
        $slug = bm_sticker_pack_slug($slug);
        if ($slug === '') return null;
        $label = trim((string)($pack['label'] ?? $slug));
        if ($label === '') $label = ucfirst($slug);
        if (function_exists('mb_substr')) $label = mb_substr($label, 0, 60, 'UTF-8');
        else $label = substr($label, 0, 60);
        $path = bm_sticker_pack_relative_path((string)($pack['path'] ?? ('sticker/' . $slug)));
        if ($path === '') return null;
        $allowed = bm_sticker_pack_allowed_extensions();
        $extensions = [];
        foreach ((array)($pack['extensions'] ?? []) as $ext) {
            $ext = strtolower(ltrim(trim((string)$ext), '.'));
            if (in_array($ext, $allowed, true)) $extensions[$ext] = true;
        }
        if (!$extensions) $extensions['webp'] = true;
        $normalized = [
            'label' => $label,
            'path' => $path,
            'extensions' => array_keys($extensions),
            'enabled' => !empty($pack['enabled']),
        ];
        if (!empty($pack['fallback_paths']) && is_array($pack['fallback_paths'])) {
            $fallbacks = [];
            foreach ($pack['fallback_paths'] as $fallback) {
                if (is_string($fallback)) $fallback = ['path'=>$fallback];
                if (!is_array($fallback)) continue;
                $fallbackPath = bm_sticker_pack_relative_path((string)($fallback['path'] ?? ''));
                if ($fallbackPath === '' || $fallbackPath === $path) continue;
                $fallbacks[] = ['path'=>$fallbackPath,'numeric_only'=>!empty($fallback['numeric_only'])];
            }
            if ($fallbacks) $normalized['fallback_paths'] = $fallbacks;
        }
        return $normalized;
    }
}

if (!function_exists('bm_sticker_pack_registry')) {
    function bm_sticker_pack_registry(bool $refresh = false): array
    {
        static $cache = null;
        if (!$refresh && is_array($cache)) return $cache;
        $path = bm_sticker_pack_settings_path();
        $raw = is_file($path) ? @file_get_contents($path) : false;
        $json = is_string($raw) ? json_decode($raw, true) : null;
        $source = (is_array($json) && isset($json['packs']) && is_array($json['packs']))
            ? $json['packs']
            : bm_sticker_pack_defaults();
        $packs = [];
        foreach ($source as $slug => $pack) {
            if (!is_array($pack)) continue;
            $safeSlug = bm_sticker_pack_slug((string)$slug);
            $normalized = bm_sticker_pack_normalize($safeSlug, $pack);
            if ($safeSlug !== '' && $normalized) $packs[$safeSlug] = $normalized;
        }
        return $cache = $packs;
    }
}

if (!function_exists('bm_sticker_pack_save_registry')) {
    function bm_sticker_pack_save_registry(array $packs): bool
    {
        $clean = [];
        foreach ($packs as $slug => $pack) {
            if (!is_array($pack)) continue;
            $safeSlug = bm_sticker_pack_slug((string)$slug);
            $normalized = bm_sticker_pack_normalize($safeSlug, $pack);
            if ($safeSlug !== '' && $normalized) $clean[$safeSlug] = $normalized;
        }
        $payload = json_encode(['version'=>1,'packs'=>$clean], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if (!is_string($payload)) return false;
        $path = bm_sticker_pack_settings_path();
        $dir = dirname($path);
        if (!is_dir($dir) && !@mkdir($dir, 0700, true) && !is_dir($dir)) return false;
        $tmp = $path . '.tmp.' . bin2hex(random_bytes(5));
        if (@file_put_contents($tmp, $payload, LOCK_EX) === false) return false;
        @chmod($tmp, 0600);
        if (!@rename($tmp, $path)) { @unlink($tmp); return false; }
        bm_sticker_pack_registry(true);
        return true;
    }
}

if (!function_exists('bm_sticker_pack_abs_dir')) {
    function bm_sticker_pack_abs_dir(string $relative): string
    {
        $relative = bm_sticker_pack_relative_path($relative);
        return $relative === '' ? '' : dirname(__DIR__) . '/' . $relative;
    }
}

if (!function_exists('bm_sticker_pack_url_base')) {
    function bm_sticker_pack_url_base(string $relative): string
    {
        $relative = bm_sticker_pack_relative_path($relative);
        if ($relative === '') return '';
        return '/' . implode('/', array_map('rawurlencode', explode('/', $relative))) . '/';
    }
}

if (!function_exists('bm_sticker_pack_candidate_paths')) {
    /**
     * Returns every safe location that may contain a pack. Besides the configured
     * path, custom packs are also auto-discovered in the common public roots so a
     * pack extracted from cPanel keeps working even if it lands one level deeper.
     */
    function bm_sticker_pack_candidate_paths(string $slug, array $pack): array
    {
        $slug = bm_sticker_pack_slug($slug);
        $out = [];
        $push = static function ($candidate, bool $numericOnly = false) use (&$out): void {
            $relative = bm_sticker_pack_relative_path((string)$candidate);
            if ($relative === '') return;
            $key = $relative . '|' . ($numericOnly ? '1' : '0');
            if (!isset($out[$key])) $out[$key] = ['path'=>$relative,'numeric_only'=>$numericOnly];
        };

        $primary = bm_sticker_pack_relative_path((string)($pack['path'] ?? ''));
        if ($primary !== '') $push($primary, false);
        foreach ((array)($pack['fallback_paths'] ?? []) as $fallback) {
            if (is_string($fallback)) $fallback = ['path'=>$fallback];
            if (!is_array($fallback)) continue;
            $push((string)($fallback['path'] ?? ''), !empty($fallback['numeric_only']));
        }

        // cPanel ZIP extraction commonly creates either sticker/<name>/<inner-dir>
        // or places the folder under uploads. Scan all standard pack roots too.
        $names = [];
        if ($primary !== '') {
            $base = basename($primary);
            if ($base !== '' && $base !== '.' && $base !== '..') $names[$base] = true;
        }
        if ($slug !== '') $names[$slug] = true;
        foreach (array_keys($names) as $name) {
            $push('sticker/' . $name, false);
            $push('uploads/sticker/' . $name, false);
            $push('uploads/' . $name, false);
        }
        return array_values($out);
    }
}

if (!function_exists('bm_sticker_pack_scan_path')) {
    function bm_sticker_pack_scan_path(string $slug, string $relative, array $extensions, bool $numericOnly = false): array
    {
        $dir = bm_sticker_pack_abs_dir($relative);
        if ($dir === '' || !is_dir($dir) || !is_readable($dir)) return [];
        $allowed = bm_sticker_pack_allowed_extensions();
        $exts = [];
        foreach ($extensions as $ext) {
            $ext = strtolower(ltrim((string)$ext, '.'));
            if (in_array($ext, $allowed, true)) $exts[$ext] = true;
        }
        if (!$exts) return [];
        $urlBase = bm_sticker_pack_url_base($relative);
        $items = [];

        $append = static function (string $full, string $nestedName) use (&$items, $slug, $relative, $exts, $urlBase, $numericOnly): void {
            $nestedName = trim(str_replace('\\', '/', $nestedName), '/');
            if ($nestedName === '') return;
            $ext = strtolower(pathinfo($nestedName, PATHINFO_EXTENSION));
            if (!isset($exts[$ext])) return;
            // The legacy /uploads Duck fallback intentionally accepts numbered
            // files only and stays top-level so unrelated media are never exposed.
            if ($numericOnly && (str_contains($nestedName, '/') || !preg_match('/^\d+\.[a-z0-9]+$/i', $nestedName))) return;
            if (!is_file($full) || !is_readable($full)) return;
            $parts = array_map('rawurlencode', explode('/', $nestedName));
            $items[] = [
                // Keep top-level ids identical to earlier releases. Nested files
                // receive a deterministic id using their relative nested path.
                'id' => substr(hash('sha256', $slug . ':' . $relative . ':' . $nestedName), 0, 24),
                'url' => $urlBase . implode('/', $parts),
                'name' => basename($nestedName),
                'extension' => $ext,
                'media_type' => $ext === 'webm' ? 'video' : 'image',
                'bytes' => (int)(@filesize($full) ?: 0),
                'relative_path' => $relative . '/' . $nestedName,
                'nested_path' => $nestedName,
            ];
        };

        // First scan root files. This preserves the previous behavior and ordering.
        foreach ((scandir($dir) ?: []) as $name) {
            if ($name === '.' || $name === '..') continue;
            $full = $dir . '/' . $name;
            if (is_file($full)) $append($full, $name);
        }

        // ZIP packs frequently contain an extra directory. Scan up to 3 levels
        // deep (only for normal pack roots) and never follow symlinks.
        if (!$numericOnly && count($items) < 400) {
            try {
                $rootReal = realpath($dir);
                if ($rootReal !== false) {
                    $it = new RecursiveIteratorIterator(
                        new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS | FilesystemIterator::CURRENT_AS_FILEINFO),
                        RecursiveIteratorIterator::LEAVES_ONLY
                    );
                    foreach ($it as $fileInfo) {
                        if (!$fileInfo instanceof SplFileInfo || !$fileInfo->isFile() || $fileInfo->isLink()) continue;
                        if ($it->getDepth() > 2) continue; // root/sub1/sub2/sub3 max
                        $full = $fileInfo->getPathname();
                        $real = realpath($full);
                        if ($real === false || !str_starts_with($real, $rootReal . DIRECTORY_SEPARATOR)) continue;
                        $nested = ltrim(str_replace('\\', '/', substr($real, strlen($rootReal))), '/');
                        if ($nested === '' || !str_contains($nested, '/')) continue; // root files already added
                        $append($real, $nested);
                        if (count($items) >= 400) break;
                    }
                }
            } catch (Throwable $e) {
                // A bad nested entry must never break the public page; root files
                // that were already found remain usable.
            }
        }

        $unique = [];
        foreach ($items as $item) $unique[(string)$item['relative_path']] = $item;
        $items = array_values($unique);
        usort($items, static function(array $a, array $b): int {
            $aa = (string)($a['nested_path'] ?? $a['name'] ?? '');
            $bb = (string)($b['nested_path'] ?? $b['name'] ?? '');
            return strnatcasecmp($aa, $bb);
        });
        return array_slice($items, 0, 400);
    }
}

if (!function_exists('bm_sticker_pack_items')) {
    function bm_sticker_pack_items(string $slug, ?array $pack = null): array
    {
        $registry = bm_sticker_pack_registry();
        $slug = bm_sticker_pack_slug($slug);
        $pack = $pack ?? ($registry[$slug] ?? null);
        if (!$pack || empty($pack['enabled'])) return [];
        $merged = [];
        foreach (bm_sticker_pack_candidate_paths($slug, $pack) as $candidate) {
            $items = bm_sticker_pack_scan_path(
                $slug,
                (string)($candidate['path'] ?? ''),
                (array)$pack['extensions'],
                !empty($candidate['numeric_only'])
            );
            foreach ($items as $item) {
                $key = (string)($item['relative_path'] ?? $item['id'] ?? '');
                if ($key !== '') $merged[$key] = $item;
                if (count($merged) >= 400) break 2;
            }
        }
        return array_values($merged);
    }
}

if (!function_exists('bm_sticker_public_catalog')) {
    function bm_sticker_public_catalog(): array
    {
        $out = [];
        foreach (bm_sticker_pack_registry() as $slug => $pack) {
            if (empty($pack['enabled'])) continue;
            $out[$slug] = [
                'slug'=>$slug,
                'label'=>(string)$pack['label'],
                'path'=>(string)$pack['path'],
                'extensions'=>array_values((array)$pack['extensions']),
                'items'=>bm_sticker_pack_items($slug, $pack),
            ];
        }
        return $out;
    }
}

if (!function_exists('bm_sticker_parse_marker')) {
    /** Parse a legacy sticker-only comment. */
    function bm_sticker_parse_marker(string $value): ?array
    {
        if (!preg_match('/^\[bm-sticker:([a-z0-9_-]{1,40}):([a-f0-9]{24})\]$/i', trim($value), $m)) return null;
        return ['pack'=>strtolower($m[1]), 'id'=>strtolower($m[2]), 'raw'=>$m[0]];
    }
}

if (!function_exists('bm_sticker_find_marker')) {
    /** Find one sticker marker inside a normal text comment. */
    function bm_sticker_find_marker(string $value): ?array
    {
        if (!preg_match('/\[bm-sticker:([a-z0-9_-]{1,40}):([a-f0-9]{24})\]/i', $value, $m, PREG_OFFSET_CAPTURE)) return null;
        return [
            'pack'=>strtolower((string)$m[1][0]),
            'id'=>strtolower((string)$m[2][0]),
            'raw'=>(string)$m[0][0],
            'offset'=>(int)$m[0][1],
        ];
    }
}

if (!function_exists('bm_sticker_marker_count')) {
    function bm_sticker_marker_count(string $value): int
    {
        return preg_match_all('/\[bm-sticker:[a-z0-9_-]{1,40}:[a-f0-9]{24}\]/i', $value, $m) ?: 0;
    }
}

if (!function_exists('bm_sticker_comment_text')) {
    /** Return the human text after removing a single sticker marker. */
    function bm_sticker_comment_text(string $value): string
    {
        $clean = preg_replace('/\[bm-sticker:[a-z0-9_-]{1,40}:[a-f0-9]{24}\]/i', '', $value, 1) ?? $value;
        return trim($clean);
    }
}

if (!function_exists('bm_sticker_resolve_parts')) {
    function bm_sticker_resolve_parts(array $parsed): ?array
    {
        $registry = bm_sticker_pack_registry();
        $pack = $registry[$parsed['pack']] ?? null;
        if (!$pack || empty($pack['enabled'])) return null;
        foreach (bm_sticker_pack_items((string)$parsed['pack'], $pack) as $item) {
            if (hash_equals((string)$item['id'], (string)$parsed['id'])) {
                return ['pack'=>$parsed['pack'],'label'=>(string)$pack['label'],'item'=>$item];
            }
        }
        return null;
    }
}

if (!function_exists('bm_sticker_resolve_marker')) {
    /** Resolve sticker-only and sticker+text comments. */
    function bm_sticker_resolve_marker(string $value): ?array
    {
        $parsed = bm_sticker_find_marker($value);
        return $parsed ? bm_sticker_resolve_parts($parsed) : null;
    }
}

if (!function_exists('bm_comment_media_render_asset_html')) {
    function bm_comment_media_render_asset_html(array $media): string
    {
        $item = $media['item'];
        $label = htmlspecialchars((string)$media['label'], ENT_QUOTES, 'UTF-8');
        $url = htmlspecialchars((string)$item['url'], ENT_QUOTES, 'UTF-8');
        $pack = htmlspecialchars((string)$media['pack'], ENT_QUOTES, 'UTF-8');
        $kind = (string)($item['media_type'] ?? 'image');
        if ($kind === 'video') {
            return '<div class="bm-comment-media bm-comment-media-video" data-pack="'.$pack.'">'
                . '<video src="'.$url.'" autoplay loop muted playsinline preload="metadata" disablepictureinpicture aria-label="'.$label.'"></video>'
                . '</div>';
        }
        return '<div class="bm-comment-media bm-comment-media-image" data-pack="'.$pack.'">'
            . '<img src="'.$url.'" loading="lazy" decoding="async" draggable="false" alt="'.$label.'">'
            . '</div>';
    }
}

if (!function_exists('bm_comment_media_render_html')) {
    function bm_comment_media_render_html(string $value): ?string
    {
        $parsed = bm_sticker_find_marker($value);
        if (!$parsed) return null;
        $media = bm_sticker_resolve_parts($parsed);
        $text = bm_sticker_comment_text($value);
        if (!$media) {
            // Never leak the internal marker when a pack was removed. Keep any text.
            return $text !== '' ? nl2br(htmlspecialchars($text, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8')) : '';
        }
        $asset = bm_comment_media_render_asset_html($media);
        if ($text === '') return $asset;
        return '<div class="bm-comment-media-combo">'.$asset
            .'<div class="bm-comment-media-caption">'.nl2br(htmlspecialchars($text, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8')).'</div></div>';
    }
}

if (!function_exists('bm_comment_media_text_or_html')) {
    function bm_comment_media_text_or_html(string $value): string
    {
        $parsed = bm_sticker_find_marker($value);
        if ($parsed) return (string)bm_comment_media_render_html($value);
        return nl2br(htmlspecialchars($value, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'));
    }
}

if (!function_exists('bm_comment_media_admin_label')) {
    function bm_comment_media_admin_label(string $value): string
    {
        $media = bm_sticker_resolve_marker($value);
        if (!$media) return bm_sticker_comment_text($value) ?: $value;
        $ext = strtoupper((string)($media['item']['extension'] ?? ''));
        $kind = ((string)($media['item']['media_type'] ?? 'image')) === 'video' ? 'گیف/استیکر متحرک' : 'استیکر تصویری';
        $text = bm_sticker_comment_text($value);
        $label = $kind . ' · ' . (string)$media['label'] . ($ext !== '' ? ' · ' . $ext : '');
        if ($text !== '') $label .= ' — ' . $text;
        return $label;
    }
}
