<?php
/**
 * BankMovie VIP sales presentation settings.
 * Content only: no payment credentials or executable code are stored here.
 */
declare(strict_types=1);

require_once __DIR__ . '/security_bootstrap.php';

if (!function_exists('bm_vip_sales_defaults')) {
    function bm_vip_sales_defaults(): array
    {
        return [
            'version' => 6,
            'preview_badge' => '',
            'section_eyebrow' => 'CHOOSE YOUR PLAN',
            'section_title' => 'VIP فقط اشتراک نیست؛ تجربه کامل‌تر فیلم دیدنه',
            'section_description' => 'بدون تبلیغات فیلم ببین، ظاهر بانک‌مووی را شخصی‌سازی کن، فیلم و سریال درخواست بده و با Watch Party پارتنر یا دوستت را رایگان به اتاق خصوصی دعوت کن؛ پخش‌تان همزمان می‌ماند، وسط فیلم Voice Call داشته باشید، چت کنید و با استیکر و GIF به صحنه‌ها واکنش نشان بدهید. همه پلن‌ها همین امکانات VIP را دارند و فقط مدت و قیمتشان فرق می‌کند.',
            'watch_party_enabled' => true,
            'watch_party_kicker' => 'WATCH PARTY',
            'watch_party_title' => 'فیلم ببین، حرف بزن، واکنش بده — دقیقاً باهم',
            'watch_party_body' => "یک اتاق خصوصی Watch Party بساز و لینک را برای پارتنر یا دوستت بفرست؛ همراهت بدون خرید VIP و بدون ثبت‌نام وارد می‌شود. فیلم برای هر دو نفر روی یک تایم می‌ماند؛ Play، Pause و عقب‌وجلو رفتن هماهنگ است. همان موقع داخل اتاق Voice Call را روشن کنید و بدون خروج از فیلم با هم حرف بزنید، در چت پیام بفرستید و با استیکر و GIF به سکانس‌ها واکنش نشان بدهید. یعنی به‌جای دو تماشای جدا، یک سینمای دونفره واقعی داخل BankMovie دارید.",
            'watch_party_badges' => [
                'Voice Call همزمان با فیلم',
                'استیکر و GIF داخل Watch Party',
                'پخش کاملاً هماهنگ',
                'Play / Pause مشترک',
                'چت داخل پلیر',
                'دعوت رایگان پارتنر یا دوست',
            ],
            'card_subscription_title' => 'اشتراک BankMovie VIP',
            'currency_label' => "هزار\nتومان",
            'purchase_enabled' => true,
            'telegram_username' => 'bankmovie_supp',
            'purchase_instruction' => 'برای خرید و فعال‌سازی VIP، پلن موردنظرت را انتخاب کن. متن سفارش کپی می‌شود و تلگرام @bankmovie_supp برای هماهنگی باز خواهد شد.',
            'purchase_message_template' => 'سلام، برای خرید اشتراک {plan} بانک‌مووی به مبلغ {price} هزار تومان پیام می‌دهم.',
            'select_button_label' => 'خرید و هماهنگی',
            'features_label' => 'امکانات',
            'card_note' => 'پس از انتخاب پلن، متن سفارش را در تلگرام برای @bankmovie_supp ارسال کن.',
            'featured_ribbon_label' => 'محبوب‌ترین انتخاب',
            'toast_template' => 'متن سفارش پلن {plan} کپی شد؛ آن را برای پشتیبانی تلگرام ارسال کن.',
            'footer_title' => 'BankMovie VIP؛ فیلم دیدن را از حالت معمولی دربیار',
            'footer_description' => 'بدون تبلیغات، با ظاهر اختصاصی و یک Watch Party واقعی: پارتنر یا دوستت را دعوت کن، همزمان فیلم ببینید، Voice Call داشته باشید، چت کنید و استیکر بفرستید. برای فعال‌سازی پلن، در تلگرام به @bankmovie_supp پیام بده.',
            'footer_button_label' => 'پیام در تلگرام',
            'footer_button_url' => 'https://t.me/bankmovie_supp',
            'features' => [
                ['label' => 'حذف کامل تبلیغات؛ تمرکز فقط روی فیلم', 'enabled' => true],
                ['label' => 'Watch Party خصوصی؛ همراه رایگان', 'enabled' => true],
                ['label' => 'Voice Call با پارتنر یا دوست هنگام تماشا', 'enabled' => true],
                ['label' => 'استیکر و GIF زنده داخل Watch Party', 'enabled' => true],
                ['label' => 'چت همزمان بدون خروج از فیلم', 'enabled' => true],
                ['label' => 'آپلود آواتار اختصاصی VIP', 'enabled' => true],
                ['label' => 'نشان ویژه VIP در پروفایل و چت', 'enabled' => true],
                ['label' => 'پشتیبانی VIP شبانه‌روزی', 'enabled' => true],
                ['label' => 'درخواست فیلم و سریال با اولویت VIP', 'enabled' => true],
                ['label' => 'انتخاب تم اختصاصی سایت', 'enabled' => true],
                ['label' => 'انتخاب فونت سایت', 'enabled' => true],
            ],
            'plans' => [
                [
                    'name' => 'یک‌ماهه', 'latin' => 'MONTHLY', 'price' => '۵۰',
                    'period' => '۳۰ روز دسترسی VIP', 'badge' => 'شروع راحت',
                    'saving' => '', 'featured' => false, 'enabled' => true, 'tone' => 'blue',
                ],
                [
                    'name' => 'دوماهه', 'latin' => '2 MONTHS', 'price' => '۸۵',
                    'period' => '۶۰ روز دسترسی VIP', 'badge' => 'اقتصادی',
                    'saving' => '۱۵ هزار تومان به‌صرفه‌تر', 'featured' => false, 'enabled' => true, 'tone' => 'violet',
                ],
                [
                    'name' => 'شش‌ماهه', 'latin' => '6 MONTHS', 'price' => '۲۵۰',
                    'period' => '۱۸۰ روز دسترسی VIP', 'badge' => 'پیشنهاد بانک مووی',
                    'saving' => '۵۰ هزار تومان به‌صرفه‌تر', 'featured' => true, 'enabled' => true, 'tone' => 'premium',
                ],
                [
                    'name' => 'یک‌ساله', 'latin' => 'ANNUAL', 'price' => '۴۵۰',
                    'period' => '۳۶۵ روز دسترسی VIP', 'badge' => 'بیشترین ارزش',
                    'saving' => '۱۵۰ هزار تومان به‌صرفه‌تر', 'featured' => false, 'enabled' => true, 'tone' => 'gold',
                ],
            ],
        ];
    }
}

if (!function_exists('bm_vip_sales_path')) {
    function bm_vip_sales_path(): string
    {
        return bm_security_private_path('vip-sales-settings.json');
    }
}

if (!function_exists('bm_vip_sales_cut')) {
    function bm_vip_sales_cut(string $value, int $max): string
    {
        $value = trim(strip_tags($value));
        return function_exists('mb_substr') ? mb_substr($value, 0, $max, 'UTF-8') : substr($value, 0, $max);
    }
}

if (!function_exists('bm_vip_sales_settings')) {
    function bm_vip_sales_settings(bool $refresh = false): array
    {
        static $cache = null;
        if (!$refresh && is_array($cache)) return $cache;

        $defaults = bm_vip_sales_defaults();
        $raw = is_file(bm_vip_sales_path()) ? @file_get_contents(bm_vip_sales_path()) : false;
        $stored = is_string($raw) ? json_decode($raw, true) : null;
        if (!is_array($stored)) return $cache = $defaults;

        // v2 removes preview/test language and adds the ad-free benefit while
        // preserving every custom price, plan and text changed by the owner.
        if ((int)($stored['version'] ?? 1) < 2) {
            $legacyExact = [
                'preview_badge' => 'پیش‌نمایش مخفی فروش VIP — فقط مدیر سایت این صفحه را می‌بیند',
                'card_note' => 'خرید در این نسخه غیرفعال است و دکمه فقط برای بررسی ظاهر صفحه قرار گرفته.',
                'toast_template' => 'پلن {plan} انتخاب شد؛ اتصال به درگاه در مرحله بعد انجام می‌شود.',
                'footer_title' => 'این صفحه هنوز عمومی نشده است',
                'footer_description' => 'هیچ مسیر منوی عمومی یا لینک کاربری برای آن فعال نشده و فقط مدیر احراز هویت‌شده می‌تواند صفحه را باز کند.',
                'footer_button_label' => 'بازگشت به مدیریت کاربران',
                'footer_button_url' => '/admin.php#usersSection',
            ];
            foreach ($legacyExact as $key => $legacyValue) {
                if (($stored[$key] ?? null) === $legacyValue) $stored[$key] = $defaults[$key];
            }
            $stored['preview_badge'] = '';
            $featureRows = isset($stored['features']) && is_array($stored['features']) ? $stored['features'] : [];
            $nextFeatures = [];
            $hasAdFree = false;
            foreach ($featureRows as $row) {
                if (!is_array($row)) continue;
                $label = trim((string)($row['label'] ?? ''));
                if ($label === 'دسترسی زودتر به قابلیت‌های آزمایشی') continue;
                if ($label === 'حذف کامل تبلیغات') $hasAdFree = true;
                $nextFeatures[] = $row;
            }
            if (!$hasAdFree) array_unshift($nextFeatures, ['label' => 'حذف کامل تبلیغات', 'enabled' => true]);
            $stored['features'] = $nextFeatures ?: $defaults['features'];
            $stored['version'] = 2;
        }

        // v3 activates Telegram-based purchase coordination while preserving
        // any custom content already entered by the site owner.
        if ((int)($stored['version'] ?? 2) < 3) {
            $v2Exact = [
                'select_button_label' => 'انتخاب این پلن',
                'card_note' => 'خرید آنلاین اشتراک به‌زودی فعال می‌شود.',
                'toast_template' => 'خرید آنلاین پلن {plan} به‌زودی فعال می‌شود.',
                'footer_description' => 'امکانات VIP فعال‌اند و خرید آنلاین پس از اتصال درگاه پرداخت در همین صفحه در دسترس قرار می‌گیرد.',
                'footer_button_label' => 'بازگشت به خانه',
                'footer_button_url' => '/',
            ];
            foreach ($v2Exact as $key => $legacyValue) {
                if (($stored[$key] ?? null) === $legacyValue) $stored[$key] = $defaults[$key];
            }
            if (!array_key_exists('purchase_enabled', $stored)) $stored['purchase_enabled'] = true;
            if (trim((string)($stored['telegram_username'] ?? '')) === '') $stored['telegram_username'] = $defaults['telegram_username'];
            if (trim((string)($stored['purchase_instruction'] ?? '')) === '') $stored['purchase_instruction'] = $defaults['purchase_instruction'];
            if (trim((string)($stored['purchase_message_template'] ?? '')) === '') $stored['purchase_message_template'] = $defaults['purchase_message_template'];
            $stored['version'] = 3;
        }

        // v4 removes the old "coming soon" wording now that Watch Party is active.
        if ((int)($stored['version'] ?? 3) < 4) {
            $legacyWatchPartyBody = "قابلیت Watch Party بانک‌مووی به‌زودی برای اعضای VIP فعال می‌شود. با این امکان می‌توانی فیلم یا سریال را هم‌زمان با پارتنر یا دوستت تماشا کنی، بدون اینکه پخش دو نفر از هم عقب یا جلو بیفتد. شروع، توقف و جابه‌جایی در زمان ویدئو برای هر دو نفر هماهنگ می‌ماند و چت داخل پلیر هم اجازه می‌دهد بدون خروج از فیلم با هم گفتگو کنید. یک نفر اتاق خصوصی می‌سازد، لینک دعوت را می‌فرستد و تماشای مشترک شروع می‌شود.";
            $currentBody = trim((string)($stored['watch_party_body'] ?? ''));
            if ($currentBody === '' || $currentBody === $legacyWatchPartyBody || str_contains($currentBody, 'به‌زودی برای اعضای VIP فعال می‌شود')) {
                $stored['watch_party_body'] = $defaults['watch_party_body'];
            }
            $stored['version'] = 4;
        }

        // v5 adds the two real personalization benefits to existing VIP sales
        // configurations without overwriting any custom plan, price or copy.
        if ((int)($stored['version'] ?? 4) < 5) {
            $rows = isset($stored['features']) && is_array($stored['features']) ? $stored['features'] : [];
            $labels = [];
            foreach ($rows as $row) {
                if (!is_array($row)) continue;
                $label = trim((string)($row['label'] ?? ''));
                if ($label !== '') $labels[$label] = true;
            }
            foreach (['انتخاب تم اختصاصی سایت', 'انتخاب فونت سایت'] as $label) {
                if (!isset($labels[$label])) $rows[] = ['label' => $label, 'enabled' => true];
            }
            $stored['features'] = $rows;
            $stored['version'] = 5;
        }

        // v6 expands the public VIP pitch around the features that are now actually
        // available: synchronized Watch Party, voice call and live stickers/GIFs.
        // Exact old default copy is upgraded automatically; custom owner copy is kept.
        if ((int)($stored['version'] ?? 5) < 6) {
            $v5Exact = [
                'section_title' => 'مدت اشتراک موردنظرت را انتخاب کن',
                'section_description' => 'همه پلن‌ها امکانات VIP یکسانی دارند و فقط مدت و قیمت آن‌ها متفاوت است.',
                'watch_party_title' => 'تماشای دونفره، دقیقاً روی یک تایم',
                'watch_party_body' => "عضو VIP اتاق خصوصی Watch Party را می‌سازد و لینک دعوت را برای پارتنر یا دوستش می‌فرستد. همراه بدون ثبت‌نام و بدون خرید اشتراک وارد اتاق می‌شود. شروع، توقف و جابه‌جایی زمان ویدئو برای هر دو نفر هماهنگ می‌ماند و چت داخل پلیر نیز اجازه می‌دهد بدون خروج از فیلم با هم گفت‌وگو کنند.",
                'footer_title' => 'BankMovie VIP؛ تجربه کامل‌تر بانک مووی',
                'footer_description' => 'برای خرید اشتراک و فعال‌سازی حساب، در تلگرام به @bankmovie_supp پیام بده.',
            ];
            foreach ($v5Exact as $key => $oldValue) {
                $current = trim((string)($stored[$key] ?? ''));
                if ($current === '' || $current === $oldValue) $stored[$key] = $defaults[$key];
            }

            $oldBadges = ['پخش کاملاً هماهنگ','شروع، توقف و عقب‌وجلو مشترک','چت داخل پلیر','اتاق خصوصی دونفره'];
            $storedBadges = isset($stored['watch_party_badges']) && is_array($stored['watch_party_badges']) ? array_values($stored['watch_party_badges']) : [];
            if (!$storedBadges || $storedBadges === $oldBadges) {
                $stored['watch_party_badges'] = $defaults['watch_party_badges'];
            } else {
                foreach (['Voice Call همزمان با فیلم','استیکر و GIF داخل Watch Party'] as $label) {
                    if (!in_array($label, $storedBadges, true)) $storedBadges[] = $label;
                }
                $stored['watch_party_badges'] = $storedBadges;
            }

            $rows = isset($stored['features']) && is_array($stored['features']) ? $stored['features'] : [];
            $labels = [];
            foreach ($rows as $row) {
                if (!is_array($row)) continue;
                $label = trim((string)($row['label'] ?? ''));
                if ($label !== '') $labels[$label] = true;
            }
            foreach ([
                'Voice Call با پارتنر یا دوست هنگام تماشا',
                'استیکر و GIF زنده داخل Watch Party',
                'چت همزمان بدون خروج از فیلم',
            ] as $label) {
                if (!isset($labels[$label])) $rows[] = ['label' => $label, 'enabled' => true];
            }
            $stored['features'] = $rows ?: $defaults['features'];
            $stored['version'] = 6;
        }

        $merged = array_replace($defaults, $stored);
        $merged['plans'] = isset($stored['plans']) && is_array($stored['plans']) ? $stored['plans'] : $defaults['plans'];
        $merged['features'] = isset($stored['features']) && is_array($stored['features']) ? $stored['features'] : $defaults['features'];
        $merged['watch_party_badges'] = isset($stored['watch_party_badges']) && is_array($stored['watch_party_badges']) ? $stored['watch_party_badges'] : $defaults['watch_party_badges'];
        return $cache = $merged;
    }
}

if (!function_exists('bm_vip_sales_sanitize')) {
    function bm_vip_sales_sanitize(array $input): array
    {
        $defaults = bm_vip_sales_defaults();
        $textLimits = [
            'preview_badge' => 180,
            'section_eyebrow' => 80,
            'section_title' => 180,
            'section_description' => 600,
            'watch_party_kicker' => 80,
            'watch_party_title' => 180,
            'watch_party_body' => 2600,
            'card_subscription_title' => 120,
            'currency_label' => 40,
            'purchase_instruction' => 700,
            'purchase_message_template' => 700,
            'select_button_label' => 80,
            'features_label' => 60,
            'card_note' => 500,
            'featured_ribbon_label' => 80,
            'toast_template' => 240,
            'footer_title' => 160,
            'footer_description' => 700,
            'footer_button_label' => 100,
        ];

        $clean = $defaults;
        foreach ($textLimits as $key => $limit) {
            $clean[$key] = bm_vip_sales_cut((string)($input[$key] ?? $defaults[$key]), $limit);
        }
        $clean['watch_party_enabled'] = !empty($input['watch_party_enabled']);
        $clean['purchase_enabled'] = !empty($input['purchase_enabled']);

        $telegramUsername = ltrim(trim((string)($input['telegram_username'] ?? $defaults['telegram_username'])), '@');
        if (!preg_match('/^[A-Za-z0-9_]{5,32}$/', $telegramUsername)) {
            $telegramUsername = $defaults['telegram_username'];
        }
        $clean['telegram_username'] = $telegramUsername;

        $url = trim((string)($input['footer_button_url'] ?? $defaults['footer_button_url']));
        if ($url === '' || preg_match('~^(?:javascript|data|vbscript):~i', $url)) {
            $url = $defaults['footer_button_url'];
        } elseif (!str_starts_with($url, '/') && !filter_var($url, FILTER_VALIDATE_URL)) {
            $url = $defaults['footer_button_url'];
        }
        $clean['footer_button_url'] = bm_vip_sales_cut($url, 1000);

        $badges = $input['watch_party_badges'] ?? [];
        if (!is_array($badges)) $badges = [];
        $clean['watch_party_badges'] = [];
        foreach (array_slice($badges, 0, 12) as $badge) {
            $label = bm_vip_sales_cut((string)$badge, 100);
            if ($label !== '') $clean['watch_party_badges'][] = $label;
        }

        $features = $input['features'] ?? [];
        if (!is_array($features)) $features = [];
        $clean['features'] = [];
        foreach (array_slice($features, 0, 30) as $feature) {
            if (!is_array($feature)) continue;
            $label = bm_vip_sales_cut((string)($feature['label'] ?? ''), 180);
            if ($label === '') continue;
            $clean['features'][] = [
                'label' => $label,
                'enabled' => !empty($feature['enabled']),
            ];
        }

        $allowedTones = ['blue', 'violet', 'premium', 'gold'];
        $plans = $input['plans'] ?? [];
        if (!is_array($plans)) $plans = [];
        $clean['plans'] = [];
        foreach (array_slice($plans, 0, 12) as $plan) {
            if (!is_array($plan)) continue;
            $name = bm_vip_sales_cut((string)($plan['name'] ?? ''), 80);
            $price = bm_vip_sales_cut((string)($plan['price'] ?? ''), 40);
            if ($name === '' || $price === '') continue;
            $tone = strtolower(trim((string)($plan['tone'] ?? 'blue')));
            if (!in_array($tone, $allowedTones, true)) $tone = 'blue';
            $clean['plans'][] = [
                'name' => $name,
                'latin' => bm_vip_sales_cut((string)($plan['latin'] ?? ''), 60),
                'price' => $price,
                'period' => bm_vip_sales_cut((string)($plan['period'] ?? ''), 140),
                'badge' => bm_vip_sales_cut((string)($plan['badge'] ?? ''), 100),
                'saving' => bm_vip_sales_cut((string)($plan['saving'] ?? ''), 160),
                'featured' => !empty($plan['featured']),
                'enabled' => !empty($plan['enabled']),
                'tone' => $tone,
            ];
        }

        if (empty($input['plans_present']) && !$clean['plans']) $clean['plans'] = $defaults['plans'];
        if (empty($input['features_present']) && !$clean['features']) $clean['features'] = $defaults['features'];
        if (empty($input['watch_party_badges_present']) && !$clean['watch_party_badges']) $clean['watch_party_badges'] = $defaults['watch_party_badges'];
        $clean['version'] = 6;
        return $clean;
    }
}

if (!function_exists('bm_vip_sales_save')) {
    function bm_vip_sales_save(array $input): bool
    {
        $data = bm_vip_sales_sanitize($input);
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) return false;
        $path = bm_vip_sales_path();
        $dir = dirname($path);
        if (!is_dir($dir) && !@mkdir($dir, 0700, true)) return false;
        $tmp = $path . '.tmp.' . getmypid() . '.' . bin2hex(random_bytes(3));
        if (@file_put_contents($tmp, $json . PHP_EOL, LOCK_EX) === false) {
            @unlink($tmp);
            return false;
        }
        @chmod($tmp, 0600);
        if (!@rename($tmp, $path)) {
            @unlink($tmp);
            return false;
        }
        bm_vip_sales_settings(true);
        return true;
    }
}

if (!function_exists('bm_vip_sales_reset')) {
    function bm_vip_sales_reset(): bool
    {
        return bm_vip_sales_save(bm_vip_sales_defaults());
    }
}
