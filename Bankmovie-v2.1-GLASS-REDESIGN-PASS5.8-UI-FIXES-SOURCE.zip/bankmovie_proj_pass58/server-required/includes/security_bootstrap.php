<?php
/**
 * BankMovie security bootstrap.
 *
 * This file is intentionally dependency-free and safe to include more than once.
 * It hardens headers, secrets, CORS, rate limits, audit logs and outbound URLs
 * without changing the public response schemas of the existing site/API.
 */
if (defined('BANKMOVIE_SECURITY_BOOTSTRAP_LOADED')) {
    return;
}
define('BANKMOVIE_SECURITY_BOOTSTRAP_LOADED', true);

@ini_set('display_errors', '0');
@ini_set('display_startup_errors', '0');
@ini_set('log_errors', '1');
@ini_set('expose_php', '0');

if (!defined('BANKMOVIE_PRIVATE_DIR_ENV')) {
    define('BANKMOVIE_PRIVATE_DIR_ENV', 'BANKMOVIE_PRIVATE_DIR');
}

if (!function_exists('bm_security_env')) {
    function bm_security_env(string $name, ?string $default = null): ?string
    {
        $value = getenv($name);
        if ($value === false) {
            return $default;
        }
        return (string)$value;
    }
}

if (!function_exists('bm_security_env_bool')) {
    function bm_security_env_bool(string $name, bool $default = false): bool
    {
        $value = bm_security_env($name);
        if ($value === null || trim($value) === '') {
            return $default;
        }
        $parsed = filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
        return $parsed ?? $default;
    }
}

if (!function_exists('bm_security_private_dir')) {
    function bm_security_private_dir(): string
    {
        $env = bm_security_env(BANKMOVIE_PRIVATE_DIR_ENV);
        if (is_string($env) && trim($env) !== '') {
            $dir = rtrim(trim($env), "/\\");
        } else {
            $dir = dirname(__DIR__) . DIRECTORY_SEPARATOR . '_bankmovie_private';
        }

        if (!is_dir($dir)) {
            @mkdir($dir, 0700, true);
        }
        if (is_dir($dir)) {
            @chmod($dir, 0700);
        }
        return $dir;
    }
}

if (!function_exists('bm_security_private_path')) {
    function bm_security_private_path(string $filename): string
    {
        return bm_security_private_dir() . DIRECTORY_SEPARATOR . basename($filename);
    }
}

if (!function_exists('bm_security_private_config')) {
    function bm_security_private_config(): array
    {
        static $config = null;
        if (is_array($config)) {
            return $config;
        }

        $config = [];
        $candidate = bm_security_env('BANKMOVIE_SECRETS_FILE');
        $paths = [];
        if (is_string($candidate) && trim($candidate) !== '') {
            $paths[] = trim($candidate);
        }
        $paths[] = bm_security_private_path('secrets.php');

        foreach (array_unique($paths) as $path) {
            if (!is_file($path) || !is_readable($path)) {
                continue;
            }
            try {
                $loaded = require $path;
                if (is_array($loaded)) {
                    $config = $loaded;
                    break;
                }
            } catch (Throwable $e) {
                error_log('BankMovie secrets file could not be loaded: ' . $e->getMessage());
            }
        }
        return $config;
    }
}

if (!function_exists('bm_security_secret')) {
    /**
     * Read a secret from ENV first, then from the private secrets file.
     * The public source tree never needs to contain a credential.
     */
    function bm_security_secret(string $key, string $envName, string $default = ''): string
    {
        $env = bm_security_env($envName);
        if (is_string($env) && $env !== '') {
            return $env;
        }
        $config = bm_security_private_config();
        if (array_key_exists($key, $config) && is_scalar($config[$key])) {
            return (string)$config[$key];
        }
        return $default;
    }
}

if (!function_exists('bm_security_app_auth_pairs')) {
    /**
     * Return one or more active app signing credentials.
     * Multiple pairs allow a zero-downtime mobile/TV app key rotation: publish the
     * new client, accept old+new during the migration window, then remove the old pair.
     */
    function bm_security_app_auth_pairs(): array
    {
        static $pairs = null;
        if (is_array($pairs)) return $pairs;

        $pairs = [];
        $append = static function ($key, $secret) use (&$pairs): void {
            $key = trim((string)$key);
            $secret = trim((string)$secret);
            if ($key === '' || $secret === '') return;
            foreach ($pairs as $pair) {
                if (hash_equals((string)$pair['key'], $key)) return;
            }
            $pairs[] = ['key' => $key, 'secret' => $secret];
        };

        $envJson = bm_security_env('BANKMOVIE_APP_AUTH_PAIRS_JSON', '');
        if (is_string($envJson) && trim($envJson) !== '') {
            $decoded = json_decode($envJson, true);
            if (is_array($decoded)) {
                foreach ($decoded as $pair) {
                    if (is_array($pair)) $append($pair['key'] ?? '', $pair['secret'] ?? '');
                }
            }
        }

        $config = bm_security_private_config();
        $configuredPairs = $config['app_auth_pairs'] ?? [];
        if (is_array($configuredPairs)) {
            foreach ($configuredPairs as $pair) {
                if (is_array($pair)) $append($pair['key'] ?? '', $pair['secret'] ?? '');
            }
        }

        // Single-pair settings remain fully backward compatible.
        $append(
            bm_security_secret('app_auth_key', 'BANKMOVIE_APP_AUTH_KEY'),
            bm_security_secret('app_auth_secret', 'BANKMOVIE_APP_AUTH_SECRET')
        );
        return $pairs;
    }
}

$__bmLogDir = bm_security_private_dir();
if (is_dir($__bmLogDir) && is_writable($__bmLogDir)) {
    @ini_set('error_log', $__bmLogDir . DIRECTORY_SEPARATOR . 'php-errors.log');
}
unset($__bmLogDir);

if (!function_exists('bm_security_is_https')) {
    function bm_security_is_https(): bool
    {
        if (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') {
            return true;
        }
        if ((int)($_SERVER['SERVER_PORT'] ?? 0) === 443) {
            return true;
        }
        $forwarded = strtolower(trim((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')));
        return $forwarded === 'https';
    }
}

if (!function_exists('bm_security_request_id')) {
    function bm_security_request_id(): string
    {
        static $id = null;
        if (is_string($id)) {
            return $id;
        }
        $incoming = trim((string)($_SERVER['HTTP_X_REQUEST_ID'] ?? ''));
        if ($incoming !== '' && preg_match('/^[A-Za-z0-9._-]{8,80}$/', $incoming)) {
            $id = $incoming;
        } else {
            try {
                $id = bin2hex(random_bytes(8));
            } catch (Throwable $e) {
                $id = substr(hash('sha256', uniqid('', true)), 0, 16);
            }
        }
        return $id;
    }
}

if (!function_exists('bm_security_client_ip')) {
    function bm_security_client_ip(): string
    {
        // These headers are only useful when the origin is protected behind a CDN.
        // Set BANKMOVIE_TRUST_PROXY_HEADERS=0 if the origin is directly reachable.
        $trustProxy = bm_security_env_bool('BANKMOVIE_TRUST_PROXY_HEADERS', true);
        if ($trustProxy) {
            foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_TRUE_CLIENT_IP'] as $header) {
                $candidate = trim((string)($_SERVER[$header] ?? ''));
                if (filter_var($candidate, FILTER_VALIDATE_IP)) {
                    return $candidate;
                }
            }
            $xff = trim((string)($_SERVER['HTTP_X_FORWARDED_FOR'] ?? ''));
            if ($xff !== '') {
                $first = trim(explode(',', $xff)[0]);
                if (filter_var($first, FILTER_VALIDATE_IP)) {
                    return $first;
                }
            }
        }
        $remote = trim((string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'));
        return filter_var($remote, FILTER_VALIDATE_IP) ? $remote : '0.0.0.0';
    }
}

if (!function_exists('bm_security_audit')) {
    function bm_security_audit(string $event, array $context = []): void
    {
        $safeEvent = preg_replace('/[^A-Za-z0-9_.:-]/', '_', $event) ?: 'security_event';
        $payload = [
            'time' => gmdate('c'),
            'event' => $safeEvent,
            'request_id' => bm_security_request_id(),
            'ip' => bm_security_client_ip(),
            'method' => (string)($_SERVER['REQUEST_METHOD'] ?? 'CLI'),
            'uri' => substr((string)($_SERVER['REQUEST_URI'] ?? ''), 0, 1000),
            'context' => $context,
        ];
        $line = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($line)) {
            return;
        }
        $auditPath = bm_security_private_path('security-audit.log');
        clearstatcache(true, $auditPath);
        if (is_file($auditPath) && (int)@filesize($auditPath) > 8 * 1024 * 1024) {
            @unlink($auditPath . '.1');
            @rename($auditPath, $auditPath . '.1');
        }
        @file_put_contents($auditPath, $line . PHP_EOL, FILE_APPEND | LOCK_EX);
    }
}

if (!function_exists('bm_security_rate_limit')) {
    /**
     * Small file-backed fixed-window limiter. It fails open if storage is unavailable,
     * so a permissions issue cannot take the website offline.
     *
     * @return array{allowed:bool,remaining:int,retry_after:int,limit:int,window:int}
     */
    function bm_security_rate_limit(string $scope, int $limit, int $windowSeconds, string $identity = ''): array
    {
        $limit = max(1, $limit);
        $windowSeconds = max(1, $windowSeconds);
        $identity = $identity !== '' ? $identity : bm_security_client_ip();
        $key = hash('sha256', $scope . '|' . $identity);
        $dir = bm_security_private_dir() . DIRECTORY_SEPARATOR . 'rate-limits';
        if (!is_dir($dir)) {
            @mkdir($dir, 0700, true);
        }
        $file = $dir . DIRECTORY_SEPARATOR . $key . '.json';
        $now = time();
        $fp = @fopen($file, 'c+');
        if (!$fp) {
            return ['allowed' => true, 'remaining' => $limit, 'retry_after' => 0, 'limit' => $limit, 'window' => $windowSeconds];
        }

        $allowed = true;
        $remaining = $limit;
        $retryAfter = 0;
        try {
            if (!flock($fp, LOCK_EX)) {
                throw new RuntimeException('rate limit lock failed');
            }
            rewind($fp);
            $raw = stream_get_contents($fp);
            $state = is_string($raw) && $raw !== '' ? json_decode($raw, true) : null;
            if (!is_array($state) || (int)($state['reset_at'] ?? 0) <= $now) {
                $state = ['count' => 0, 'reset_at' => $now + $windowSeconds];
            }
            $state['count'] = (int)($state['count'] ?? 0) + 1;
            $allowed = $state['count'] <= $limit;
            $remaining = max(0, $limit - $state['count']);
            $retryAfter = $allowed ? 0 : max(1, (int)$state['reset_at'] - $now);
            ftruncate($fp, 0);
            rewind($fp);
            fwrite($fp, json_encode($state));
            fflush($fp);
            flock($fp, LOCK_UN);
        } catch (Throwable $e) {
            $allowed = true;
            $remaining = $limit;
            $retryAfter = 0;
        } finally {
            fclose($fp);
        }

        if (!$allowed) {
            bm_security_audit('rate_limit_block', ['scope' => $scope, 'retry_after' => $retryAfter]);
        }
        return ['allowed' => $allowed, 'remaining' => $remaining, 'retry_after' => $retryAfter, 'limit' => $limit, 'window' => $windowSeconds];
    }
}

if (!function_exists('bm_security_enforce_rate_limit')) {
    function bm_security_enforce_rate_limit(string $scope, int $limit, int $windowSeconds, string $identity = '', bool $json = true): void
    {
        $result = bm_security_rate_limit($scope, $limit, $windowSeconds, $identity);
        if (!headers_sent()) {
            header('X-RateLimit-Limit: ' . $result['limit']);
            header('X-RateLimit-Remaining: ' . $result['remaining']);
        }
        if ($result['allowed']) {
            return;
        }
        http_response_code(429);
        if (!headers_sent()) {
            header('Retry-After: ' . $result['retry_after']);
            header('Cache-Control: no-store');
        }
        if ($json) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'success' => false,
                'status' => 'error',
                'error' => 'too_many_requests',
                'message' => 'تعداد درخواست‌ها بیش از حد مجاز است. کمی بعد دوباره تلاش کنید.',
                'retry_after' => $result['retry_after'],
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        } else {
            echo 'تعداد درخواست‌ها بیش از حد مجاز است. کمی بعد دوباره تلاش کنید.';
        }
        exit;
    }
}

if (!function_exists('bm_security_origin_host')) {
    function bm_security_origin_host(string $origin): string
    {
        $parts = @parse_url($origin);
        return is_array($parts) ? strtolower((string)($parts['host'] ?? '')) : '';
    }
}

if (!function_exists('bm_security_request_host')) {
    function bm_security_request_host(): string
    {
        $host = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? '')));
        $host = preg_replace('/:\d+$/', '', $host) ?: '';
        return preg_match('/^[a-z0-9.-]+$/', $host) ? $host : '';
    }
}

if (!function_exists('bm_security_cors')) {
    /**
     * Apply CORS without affecting native Android clients (native requests have no Origin).
     * Set $publicWildcard only for read-only/public APIs.
     */
    function bm_security_cors(array $methods, array $headers, bool $publicWildcard = false): void
    {
        $origin = trim((string)($_SERVER['HTTP_ORIGIN'] ?? ''));
        $allowedOrigin = '';
        if ($origin !== '') {
            $originHost = bm_security_origin_host($origin);
            $requestHost = bm_security_request_host();
            if ($originHost !== '' && $requestHost !== '' && hash_equals($requestHost, $originHost)) {
                $allowedOrigin = $origin;
            } else {
                $configured = array_values(array_filter(array_map('trim', explode(',', (string)bm_security_env('BANKMOVIE_CORS_ORIGINS', '')))));
                foreach ($configured as $item) {
                    if ($item === $origin) {
                        $allowedOrigin = $origin;
                        break;
                    }
                }
                if ($allowedOrigin === '' && $publicWildcard && bm_security_env_bool('BANKMOVIE_PUBLIC_API_CORS', true)) {
                    $allowedOrigin = '*';
                }
            }
        } elseif ($publicWildcard && bm_security_env_bool('BANKMOVIE_PUBLIC_API_CORS', true)) {
            // No Origin means a native/server client. ACAO is harmless and preserves legacy behavior.
            $allowedOrigin = '*';
        }

        if (!headers_sent()) {
            if ($allowedOrigin !== '') {
                header('Access-Control-Allow-Origin: ' . $allowedOrigin);
                if ($allowedOrigin !== '*') {
                    header('Vary: Origin', false);
                }
            }
            header('Access-Control-Allow-Methods: ' . implode(', ', $methods));
            header('Access-Control-Allow-Headers: ' . implode(', ', $headers));
            header('Access-Control-Max-Age: 600');
        }

        if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'OPTIONS') {
            if ($origin !== '' && $allowedOrigin === '') {
                bm_security_audit('cors_denied', ['origin' => substr($origin, 0, 300)]);
                http_response_code(403);
            } else {
                http_response_code(204);
            }
            exit;
        }
    }
}

if (!function_exists('bm_security_enforce_body_size')) {
    function bm_security_enforce_body_size(int $maxBytes, bool $json = true): void
    {
        $length = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
        if ($length <= 0 || $length <= $maxBytes) {
            return;
        }
        http_response_code(413);
        if ($json) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['success' => false, 'status' => 'error', 'error' => 'payload_too_large'], JSON_UNESCAPED_UNICODE);
        }
        exit;
    }
}

if (!function_exists('bm_security_normalize_cookie')) {
    function bm_security_normalize_cookie(string $cookie): string
    {
        $cookie = trim($cookie);
        if (stripos($cookie, 'Cookie:') === 0) {
            $cookie = trim(substr($cookie, 7));
        }
        return str_replace(["\r", "\n"], '', $cookie);
    }
}

if (!function_exists('bm_security_safe_text')) {
    function bm_security_safe_text($text): string
    {
        $text = html_entity_decode((string)$text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = strip_tags($text);
        $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $text);
        $text = preg_replace('/\s+/u', ' ', $text);
        return trim((string)$text);
    }
}


if (!function_exists('bm_security_limit_text')) {
    function bm_security_limit_text($text, int $maxLength = 300): string
    {
        $text = bm_security_safe_text($text);
        if ($maxLength < 1) return '';
        return function_exists('mb_substr')
            ? mb_substr($text, 0, $maxLength, 'UTF-8')
            : substr($text, 0, $maxLength);
    }
}

if (!function_exists('bm_security_safe_year')) {
    function bm_security_safe_year($value): string
    {
        $value = bm_security_limit_text($value, 10);
        if ($value === '') return '';
        return preg_match('/^(?:18|19|20|21)\d{2}(?:\s*[-–]\s*(?:18|19|20|21)\d{2})?$/u', $value) ? $value : '';
    }
}

if (!function_exists('bm_security_safe_rating')) {
    function bm_security_safe_rating($value): ?float
    {
        if ($value === null || $value === '' || !is_numeric($value)) return null;
        $rating = (float)$value;
        if (!is_finite($rating)) return null;
        return max(0.0, min(10.0, round($rating, 1)));
    }
}

if (!function_exists('bm_security_safe_media_type')) {
    function bm_security_safe_media_type($value): string
    {
        $type = strtolower(bm_security_limit_text($value, 24));
        $aliases = [
            'tv' => 'series', 'tvseries' => 'series', 'tv_series' => 'series',
            'tvmini-series' => 'series', 'tvminiseries' => 'series',
            'anime' => 'animation', 'cartoon' => 'animation',
        ];
        if (isset($aliases[$type])) $type = $aliases[$type];
        // Preserve existing/custom media categories while allowing only a harmless
        // identifier. This avoids breaking older app data that used categories beyond
        // movie/series, without permitting markup or script content.
        return preg_match('/^[a-z0-9_-]{1,24}$/', $type) ? $type : 'movie';
    }
}

if (!function_exists('bm_security_safe_url')) {
    function bm_security_safe_url($url, array $schemes = ['http', 'https']): string
    {
        $url = html_entity_decode(trim((string)$url), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if ($url === '' || preg_match('/[\x00-\x1F\x7F]/', $url)) {
            return '';
        }
        $parts = @parse_url($url);
        if (!is_array($parts) || empty($parts['scheme'])) {
            return '';
        }
        $scheme = strtolower((string)$parts['scheme']);
        if (!in_array($scheme, $schemes, true)) {
            return '';
        }
        if (in_array($scheme, ['http', 'https'], true) && empty($parts['host'])) {
            return '';
        }
        if (isset($parts['user']) || isset($parts['pass'])) {
            return '';
        }
        return $url;
    }
}

if (!function_exists('bm_security_is_private_ip')) {
    function bm_security_is_private_ip(string $ip): bool
    {
        $ip = trim($ip, "[] \t\n\r\0\x0B");
        if ($ip === '') {
            return true;
        }
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            $long = ip2long($ip);
            if ($long === false) {
                return true;
            }
            $ranges = [
                ['0.0.0.0', '0.255.255.255'],
                ['10.0.0.0', '10.255.255.255'],
                ['100.64.0.0', '100.127.255.255'],
                ['127.0.0.0', '127.255.255.255'],
                ['169.254.0.0', '169.254.255.255'],
                ['172.16.0.0', '172.31.255.255'],
                ['192.0.0.0', '192.0.0.255'],
                ['192.168.0.0', '192.168.255.255'],
                ['198.18.0.0', '198.19.255.255'],
                ['224.0.0.0', '239.255.255.255'],
                ['240.0.0.0', '255.255.255.255'],
            ];
            foreach ($ranges as $range) {
                if ($long >= ip2long($range[0]) && $long <= ip2long($range[1])) {
                    return true;
                }
            }
            return false;
        }
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            $packed = @inet_pton($ip);
            if ($packed === false) {
                return true;
            }
            return $ip === '::1'
                || str_starts_with(strtolower($ip), 'fc')
                || str_starts_with(strtolower($ip), 'fd')
                || str_starts_with(strtolower($ip), 'fe8')
                || str_starts_with(strtolower($ip), 'fe9')
                || str_starts_with(strtolower($ip), 'fea')
                || str_starts_with(strtolower($ip), 'feb')
                || str_starts_with(strtolower($ip), 'ff');
        }
        return true;
    }
}

if (!function_exists('bm_security_host_resolves_public')) {
    function bm_security_host_resolves_public(string $host): bool
    {
        $host = strtolower(trim($host, "[] \t\n\r\0\x0B."));
        if ($host === '' || $host === 'localhost' || str_ends_with($host, '.local') || str_ends_with($host, '.internal')) {
            return false;
        }
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            return !bm_security_is_private_ip($host);
        }
        if (!preg_match('/^[a-z0-9.-]+$/', $host)) {
            return false;
        }
        $ips = [];
        $a = @gethostbynamel($host);
        if (is_array($a)) {
            $ips = array_merge($ips, $a);
        }
        if (function_exists('dns_get_record')) {
            $records = @dns_get_record($host, DNS_A | DNS_AAAA);
            if (is_array($records)) {
                foreach ($records as $record) {
                    if (!empty($record['ip'])) {
                        $ips[] = $record['ip'];
                    }
                    if (!empty($record['ipv6'])) {
                        $ips[] = $record['ipv6'];
                    }
                }
            }
        }
        $ips = array_values(array_unique(array_filter($ips)));
        if (!$ips) {
            return false;
        }
        foreach ($ips as $ip) {
            if (bm_security_is_private_ip((string)$ip)) {
                return false;
            }
        }
        return true;
    }
}

if (!function_exists('bm_security_public_http_url')) {
    function bm_security_public_http_url($url): string
    {
        $safe = bm_security_safe_url($url, ['http', 'https']);
        if ($safe === '') {
            return '';
        }
        $parts = parse_url($safe);
        $host = strtolower((string)($parts['host'] ?? ''));
        if ($host === '' || !bm_security_host_resolves_public($host)) {
            return '';
        }
        $port = isset($parts['port']) ? (int)$parts['port'] : 0;
        if ($port !== 0 && !in_array($port, [80, 443, 8080, 8443], true)) {
            return '';
        }
        return $safe;
    }
}


if (!function_exists('bm_security_resolve_url')) {
    function bm_security_resolve_url(string $base, string $location): string
    {
        $location = html_entity_decode(trim($location), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if ($location === '' || preg_match('/[\x00-\x1F\x7F]/', $location)) return '';
        if (preg_match('~^https?://~i', $location)) return $location;
        if (str_starts_with($location, '//')) {
            $scheme = strtolower((string)(parse_url($base, PHP_URL_SCHEME) ?: 'https'));
            return $scheme . ':' . $location;
        }
        $parts = parse_url($base);
        if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) return '';
        $origin = strtolower((string)$parts['scheme']) . '://' . $parts['host'];
        if (!empty($parts['port'])) $origin .= ':' . (int)$parts['port'];
        if (str_starts_with($location, '/')) return $origin . $location;
        $path = (string)($parts['path'] ?? '/');
        $dir = preg_replace('~/[^/]*$~', '/', $path) ?: '/';
        $combined = $dir . $location;
        $segments = [];
        foreach (explode('/', $combined) as $segment) {
            if ($segment === '' || $segment === '.') continue;
            if ($segment === '..') { array_pop($segments); continue; }
            $segments[] = $segment;
        }
        return $origin . '/' . implode('/', $segments);
    }
}

if (!function_exists('bm_security_public_ip_for_host')) {
    function bm_security_public_ip_for_host(string $host): string
    {
        $host = trim($host, "[] \t\n\r\0\x0B");
        if ($host === '') return '';
        if (filter_var($host, FILTER_VALIDATE_IP)) {
            return bm_security_is_private_ip($host) ? '' : $host;
        }
        if (function_exists('idn_to_ascii')) {
            $ascii = @idn_to_ascii($host, IDNA_DEFAULT, INTL_IDNA_VARIANT_UTS46);
            if (is_string($ascii) && $ascii !== '') $host = $ascii;
        }
        $records = @dns_get_record($host, DNS_A | DNS_AAAA);
        if (is_array($records)) {
            // Prefer IPv4 because CURLOPT_RESOLVE support is most consistent on shared hosts.
            usort($records, static fn(array $a, array $b): int => isset($a['ip']) ? -1 : (isset($b['ip']) ? 1 : 0));
            foreach ($records as $record) {
                $ip = (string)($record['ip'] ?? $record['ipv6'] ?? '');
                if ($ip !== '' && !bm_security_is_private_ip($ip)) return $ip;
            }
        }
        $fallback = @gethostbyname($host);
        return ($fallback !== $host && !bm_security_is_private_ip($fallback)) ? $fallback : '';
    }
}

if (!function_exists('bm_security_http_get_public')) {
    /**
     * Fetch a public HTTP(S) page with DNS/private-network protection, TLS checks,
     * bounded response size and per-hop redirect validation.
     */
    function bm_security_http_get_public($url, int $timeout = 12, int $maxBytes = 5242880, array $headers = [], string $userAgent = 'BankMovie/1.0'): string
    {
        $current = bm_security_public_http_url($url);
        if ($current === '' || $maxBytes < 1) return '';
        $timeout = max(2, min(60, $timeout));
        $maxBytes = max(1024, min(20 * 1024 * 1024, $maxBytes));

        for ($redirects = 0; $redirects <= 4; $redirects++) {
            $current = bm_security_public_http_url($current);
            if ($current === '') return '';
            $parts = parse_url($current);
            $host = strtolower((string)($parts['host'] ?? ''));
            $scheme = strtolower((string)($parts['scheme'] ?? ''));
            $port = (int)($parts['port'] ?? ($scheme === 'https' ? 443 : 80));
            $ip = bm_security_public_ip_for_host($host);
            if ($host === '' || $ip === '') return '';

            if (function_exists('curl_init')) {
                $body = '';
                $location = '';
                $ch = curl_init($current);
                $opts = [
                    CURLOPT_RETURNTRANSFER => false,
                    CURLOPT_FOLLOWLOCATION => false,
                    CURLOPT_CONNECTTIMEOUT => min(6, $timeout),
                    CURLOPT_TIMEOUT => $timeout,
                    CURLOPT_SSL_VERIFYPEER => true,
                    CURLOPT_SSL_VERIFYHOST => 2,
                    CURLOPT_ENCODING => '',
                    CURLOPT_USERAGENT => $userAgent,
                    CURLOPT_HTTPHEADER => $headers,
                    CURLOPT_HEADERFUNCTION => static function ($ch, string $line) use (&$location): int {
                        if (stripos($line, 'Location:') === 0) $location = trim(substr($line, 9));
                        return strlen($line);
                    },
                    CURLOPT_WRITEFUNCTION => static function ($ch, string $chunk) use (&$body, $maxBytes): int {
                        if (strlen($body) + strlen($chunk) > $maxBytes) return 0;
                        $body .= $chunk;
                        return strlen($chunk);
                    },
                ];
                if (defined('CURLOPT_PROTOCOLS')) $opts[CURLOPT_PROTOCOLS] = CURLPROTO_HTTP | CURLPROTO_HTTPS;
                if (defined('CURLOPT_REDIR_PROTOCOLS')) $opts[CURLOPT_REDIR_PROTOCOLS] = CURLPROTO_HTTP | CURLPROTO_HTTPS;
                if (defined('CURLOPT_RESOLVE')) {
                    $resolvedIp = str_contains($ip, ':') ? '[' . trim($ip, '[]') . ']' : $ip;
                    $opts[CURLOPT_RESOLVE] = [$host . ':' . $port . ':' . $resolvedIp];
                }
                curl_setopt_array($ch, $opts);
                $ok = curl_exec($ch);
                $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $errno = curl_errno($ch);
                curl_close($ch);
                if ($errno !== 0 || $ok === false) return '';
                if ($status >= 300 && $status < 400 && $location !== '') {
                    $current = bm_security_resolve_url($current, $location);
                    continue;
                }
                return ($status >= 200 && $status < 300) ? $body : '';
            }

            // Safe compatibility fallback for hosts without cURL. Redirects are manual.
            $ctx = stream_context_create([
                'http' => [
                    'method' => 'GET', 'timeout' => $timeout, 'ignore_errors' => true,
                    'follow_location' => 0, 'max_redirects' => 0,
                    'header' => 'User-Agent: ' . str_replace(["\r", "\n"], '', $userAgent) . "\r\n" . implode("\r\n", $headers) . "\r\n",
                ],
                'ssl' => ['verify_peer' => true, 'verify_peer_name' => true, 'SNI_enabled' => true],
            ]);
            $body = @file_get_contents($current, false, $ctx, 0, $maxBytes + 1);
            $responseHeaders = isset($http_response_header) && is_array($http_response_header) ? $http_response_header : [];
            $status = 0; $location = '';
            foreach ($responseHeaders as $line) {
                if (preg_match('~^HTTP/\S+\s+(\d{3})~i', $line, $m)) $status = (int)$m[1];
                if (stripos($line, 'Location:') === 0) $location = trim(substr($line, 9));
            }
            if ($status >= 300 && $status < 400 && $location !== '') {
                $current = bm_security_resolve_url($current, $location);
                continue;
            }
            if (!is_string($body) || strlen($body) > $maxBytes) return '';
            return ($status >= 200 && $status < 300) ? $body : '';
        }
        return '';
    }
}

if (!function_exists('bm_security_safe_navigation_url')) {
    function bm_security_safe_navigation_url($url, bool $allowRelative = true): string
    {
        $url = html_entity_decode(trim((string)$url), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if ($url === '' || preg_match('/[\x00-\x1F\x7F]/', $url)) return '';
        if ($allowRelative && str_starts_with($url, '/') && !str_starts_with($url, '//')) {
            return $url;
        }
        return bm_security_safe_url($url, ['http', 'https']);
    }
}

if (!function_exists('bm_security_allowed_upload')) {
    function bm_security_allowed_upload(array $file, array $allowedExt, array $allowedMime, int $maxBytes = 5242880): array
    {
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            return [false, 'خطای آپلود فایل'];
        }
        $size = (int)($file['size'] ?? 0);
        if ($size <= 0 || $size > $maxBytes) {
            return [false, 'حجم فایل مجاز نیست'];
        }
        $name = (string)($file['name'] ?? '');
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if (!in_array($ext, $allowedExt, true)) {
            return [false, 'پسوند فایل مجاز نیست'];
        }
        $danger = ['php', 'phtml', 'phar', 'html', 'htm', 'js', 'svg', 'shtml', 'cgi', 'pl', 'py', 'asp', 'aspx', 'jsp', 'htaccess'];
        if (in_array($ext, $danger, true)) {
            return [false, 'فایل اجرایی مجاز نیست'];
        }
        $tmp = (string)($file['tmp_name'] ?? '');
        if ($tmp === '' || !is_uploaded_file($tmp)) {
            return [false, 'فایل آپلودی معتبر نیست'];
        }
        $mime = '';
        if (function_exists('finfo_open')) {
            $finfo = @finfo_open(FILEINFO_MIME_TYPE);
            if ($finfo) {
                $mime = (string)@finfo_file($finfo, $tmp);
                @finfo_close($finfo);
            }
        }
        if ($mime === '' && function_exists('mime_content_type')) {
            $mime = (string)@mime_content_type($tmp);
        }
        if ($mime !== '' && !in_array($mime, $allowedMime, true)) {
            return [false, 'نوع فایل مجاز نیست'];
        }
        return [true, ''];
    }
}

if (!function_exists('bm_security_generic_error')) {
    function bm_security_generic_error(Throwable $e, string $publicMessage = 'خطای داخلی سرور'): string
    {
        $id = bm_security_request_id();
        error_log(sprintf('[%s] %s: %s in %s:%d', $id, get_class($e), $e->getMessage(), $e->getFile(), $e->getLine()));
        return $publicMessage . ' (شناسه: ' . $id . ')';
    }
}

// Headers chosen to be compatible with the current inline-heavy frontend.
if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-Frame-Options: SAMEORIGIN');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=(), payment=()');
    header('X-Permitted-Cross-Domain-Policies: none');
    header('X-Request-ID: ' . bm_security_request_id());
    if (bm_security_is_https() && bm_security_env_bool('BANKMOVIE_HSTS', true)) {
        header('Strict-Transport-Security: max-age=15552000; includeSubDomains');
    }
}

// Runtime-generated files are pruned at most once per hour after a response.
// The standalone bankmovie_cleanup.php CLI remains the authoritative cron path.
require_once __DIR__ . '/bm_private_cleanup.php';
if (function_exists('bm_private_cleanup_maybe_schedule')) {
    bm_private_cleanup_maybe_schedule();
}
