<?php
/**
 * BankMovie Watch Party — experimental two-person WebRTC voice signaling.
 *
 * Audio media never passes through PHP/MySQL. These tables hold only short-lived
 * signaling metadata (offer/answer/ICE/call state) and are deleted with the room.
 * Access is available to room VIP members and, when enabled by admin, the one anonymous
 * invited companion. A per-session nonce, CSRF, same-origin checks, room membership
 * checks and strict signaling validation provide defense in depth.
 */

declare(strict_types=1);

if (defined('BANKMOVIE_WATCH_PARTY_VOICE_LOADED')) return;
define('BANKMOVIE_WATCH_PARTY_VOICE_LOADED', true);

if (!function_exists('bm_watch_party_voice_enabled')) {
    function bm_watch_party_voice_enabled(): bool
    {
        return !function_exists('bm_site_bool') || bm_site_bool('watch_party_voice_enabled', true);
    }
}

if (!function_exists('bm_watch_party_voice_guests_enabled')) {
    function bm_watch_party_voice_guests_enabled(): bool
    {
        return !function_exists('bm_site_bool') || bm_site_bool('watch_party_voice_guests_enabled', true);
    }
}

if (!function_exists('bm_watch_party_voice_guest_hash')) {
    function bm_watch_party_voice_guest_hash(?array $actor): string
    {
        if (!is_array($actor)) return '';
        $stored = strtolower(trim((string)($actor['watch_party_guest_hash'] ?? '')));
        if (preg_match('/^[a-f0-9]{64}$/', $stored)) return $stored;
        if (function_exists('bm_watch_party_actor_guest_hash')) {
            $hash = strtolower(trim((string)bm_watch_party_actor_guest_hash($actor)));
            if (preg_match('/^[a-f0-9]{64}$/', $hash)) return $hash;
        }
        return '';
    }
}

if (!function_exists('bm_watch_party_voice_actor_id')) {
    function bm_watch_party_voice_actor_id(?array $actor): int
    {
        if (!is_array($actor)) return 0;
        $userId = (int)($actor['id'] ?? 0);
        if ($userId > 0) return $userId;
        $hash = bm_watch_party_voice_guest_hash($actor);
        if ($hash === '') return 0;
        // 52 bits of the guest hash + a high reserved prefix. This remains inside
        // JavaScript's safe-integer range and cannot collide with realistic user IDs.
        $tail = hexdec(substr($hash, 0, 13));
        return 4000000000000000 + (int)$tail;
    }
}

if (!function_exists('bm_watch_party_voice_actor_id_is_guest')) {
    function bm_watch_party_voice_actor_id_is_guest(int $actorId): bool
    {
        return $actorId >= 4000000000000000;
    }
}

if (!function_exists('bm_watch_party_voice_test_allowed')) {
    function bm_watch_party_voice_test_allowed(?array $user): bool
    {
        if (!bm_watch_party_voice_enabled() || !is_array($user)) return false;
        if (function_exists('bm_watch_party_actor_is_guest') && bm_watch_party_actor_is_guest($user)) {
            return bm_watch_party_voice_guests_enabled() && bm_watch_party_voice_guest_hash($user) !== '';
        }
        if (!empty($user['is_watch_party_guest']) || bm_watch_party_voice_guest_hash($user) !== '') {
            return bm_watch_party_voice_guests_enabled() && bm_watch_party_voice_guest_hash($user) !== '';
        }
        if ((int)($user['id'] ?? 0) <= 0) return false;
        if (function_exists('bm_watch_party_is_admin') && bm_watch_party_is_admin($user)) return true;
        return function_exists('bm_watch_party_is_vip') && bm_watch_party_is_vip($user);
    }
}


if (!function_exists('bm_watch_party_voice_session_nonce')) {
    function bm_watch_party_voice_session_nonce(?array $user): string
    {
        if (!bm_watch_party_voice_test_allowed($user)) return '';
        if (session_status() !== PHP_SESSION_ACTIVE) return '';
        $key = 'bm_watch_party_voice_nonce_v2';
        $current = (string)($_SESSION[$key] ?? '');
        if (!preg_match('/^[a-f0-9]{64}$/', $current)) {
            try { $current = bin2hex(random_bytes(32)); }
            catch (Throwable $e) { return ''; }
            $_SESSION[$key] = $current;
        }
        return $current;
    }
}

if (!function_exists('bm_watch_party_voice_verify_session_nonce')) {
    function bm_watch_party_voice_verify_session_nonce(?array $user, string $provided): bool
    {
        $expected = bm_watch_party_voice_session_nonce($user);
        $provided = strtolower(trim($provided));
        return $expected !== '' && preg_match('/^[a-f0-9]{64}$/', $provided) && hash_equals($expected, $provided);
    }
}

if (!function_exists('bm_watch_party_voice_schema')) {
    function bm_watch_party_voice_schema(PDO $pdo): bool
    {
        static $ready = [];
        $key = spl_object_id($pdo);
        if (array_key_exists($key, $ready)) return $ready[$key];
        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS watch_party_voice_calls (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                room_id BIGINT UNSIGNED NOT NULL,
                call_token CHAR(32) NOT NULL,
                caller_user_id BIGINT UNSIGNED NOT NULL,
                callee_user_id BIGINT UNSIGNED NOT NULL,
                caller_name VARCHAR(80) NULL,
                caller_avatar VARCHAR(255) NULL,
                callee_name VARCHAR(80) NULL,
                callee_avatar VARCHAR(255) NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'ringing',
                caller_muted TINYINT(1) NOT NULL DEFAULT 0,
                callee_muted TINYINT(1) NOT NULL DEFAULT 0,
                created_at DATETIME NOT NULL,
                answered_at DATETIME NULL,
                connected_at DATETIME NULL,
                ended_at DATETIME NULL,
                updated_at DATETIME NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uq_wp_voice_call_token (call_token),
                KEY idx_wp_voice_room_status (room_id,status,id),
                KEY idx_wp_voice_caller (caller_user_id,status),
                KEY idx_wp_voice_callee (callee_user_id,status),
                CONSTRAINT fk_wp_voice_calls_room FOREIGN KEY (room_id) REFERENCES watch_party_rooms(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            $pdo->exec("CREATE TABLE IF NOT EXISTS watch_party_voice_signals (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                room_id BIGINT UNSIGNED NOT NULL,
                call_token CHAR(32) NOT NULL,
                sender_user_id BIGINT UNSIGNED NOT NULL,
                target_user_id BIGINT UNSIGNED NOT NULL,
                signal_type VARCHAR(20) NOT NULL,
                client_signal_id VARCHAR(64) NOT NULL,
                payload_json MEDIUMTEXT NULL,
                created_at DATETIME NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uq_wp_voice_signal_client (room_id,client_signal_id),
                KEY idx_wp_voice_signal_target (room_id,target_user_id,id),
                KEY idx_wp_voice_signal_call (room_id,call_token,id),
                CONSTRAINT fk_wp_voice_signals_room FOREIGN KEY (room_id) REFERENCES watch_party_rooms(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            // Upgrade already-created beta tables without dropping active-room data.
            $extraColumns = [
                'caller_name' => "VARCHAR(80) NULL AFTER callee_user_id",
                'caller_avatar' => "VARCHAR(255) NULL AFTER caller_name",
                'callee_name' => "VARCHAR(80) NULL AFTER caller_avatar",
                'callee_avatar' => "VARCHAR(255) NULL AFTER callee_name",
            ];
            foreach ($extraColumns as $column => $definition) {
                $exists = function_exists('bm_watch_party_column_exists')
                    ? bm_watch_party_column_exists($pdo, 'watch_party_voice_calls', $column)
                    : false;
                if (!$exists) {
                    try { $pdo->exec("ALTER TABLE watch_party_voice_calls ADD COLUMN {$column} {$definition}"); }
                    catch (Throwable $e) { /* another request may have upgraded it */ }
                }
            }
            $ready[$key] = true;
            return true;
        } catch (Throwable $e) {
            $GLOBALS['bm_watch_party_voice_schema_error'] = $e->getMessage();
            error_log('Watch Party voice schema error: ' . $e->getMessage());
            $ready[$key] = false;
            return false;
        }
    }
}

if (!function_exists('bm_watch_party_voice_config_value')) {
    function bm_watch_party_voice_config_value(string $name, string $default = ''): string
    {
        if (defined($name)) {
            $value = constant($name);
            if (is_scalar($value)) return trim((string)$value);
        }
        $env = getenv($name);
        return $env !== false ? trim((string)$env) : $default;
    }
}

if (!function_exists('bm_watch_party_voice_ice_servers')) {
    function bm_watch_party_voice_ice_servers(array $user): array
    {
        if (!bm_watch_party_voice_test_allowed($user)) return [];

        $stunRaw = bm_watch_party_voice_config_value(
            'BM_WATCH_PARTY_STUN_URLS',
            'stun:stun.l.google.com:19302,stun:stun1.l.google.com:19302'
        );
        $stunUrls = array_values(array_filter(array_map('trim', explode(',', $stunRaw)), static fn($v) => str_starts_with($v, 'stun:')));
        $servers = [];
        if ($stunUrls) $servers[] = ['urls' => $stunUrls];

        $turnRaw = bm_watch_party_voice_config_value('BM_WATCH_PARTY_TURN_URLS', '');
        $turnUrls = array_values(array_filter(array_map('trim', explode(',', $turnRaw)), static fn($v) => str_starts_with($v, 'turn:') || str_starts_with($v, 'turns:')));
        if ($turnUrls) {
            $username = bm_watch_party_voice_config_value('BM_WATCH_PARTY_TURN_USERNAME', '');
            $credential = bm_watch_party_voice_config_value('BM_WATCH_PARTY_TURN_CREDENTIAL', '');
            $secret = bm_watch_party_voice_config_value('BM_WATCH_PARTY_TURN_SECRET', '');
            if ($secret !== '') {
                // coturn REST-style short-lived credentials; the shared secret itself never reaches the browser.
                $username = (string)(time() + 3600) . ':' . bm_watch_party_voice_actor_id($user);
                $credential = base64_encode(hash_hmac('sha1', $username, $secret, true));
            }
            if ($username !== '' && $credential !== '') {
                $servers[] = ['urls' => $turnUrls, 'username' => $username, 'credential' => $credential];
            }
        }
        return $servers;
    }
}

if (!function_exists('bm_watch_party_voice_turn_ready')) {
    function bm_watch_party_voice_turn_ready(array $user): bool
    {
        foreach (bm_watch_party_voice_ice_servers($user) as $server) {
            foreach ((array)($server['urls'] ?? []) as $url) {
                if (str_starts_with((string)$url, 'turn:') || str_starts_with((string)$url, 'turns:')) return true;
            }
        }
        return false;
    }
}


if (!function_exists('bm_watch_party_voice_validate_signal_payload')) {
    function bm_watch_party_voice_validate_signal_payload(string $signalType, $payload): array
    {
        if (!is_array($payload)) throw new RuntimeException('voice_invalid_signal', 422);

        if ($signalType === 'offer' || $signalType === 'answer') {
            $expected = $signalType;
            $type = strtolower(trim((string)($payload['type'] ?? '')));
            $sdp = (string)($payload['sdp'] ?? '');
            if ($type !== $expected || $sdp === '' || strlen($sdp) > 32768) {
                throw new RuntimeException('voice_invalid_signal', 422);
            }
            // SDP is text, never executable content. Reject control bytes except CR/LF/TAB.
            if (preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', $sdp)) {
                throw new RuntimeException('voice_invalid_signal', 422);
            }
            return ['type' => $type, 'sdp' => $sdp];
        }

        if ($signalType === 'ice') {
            $candidate = trim((string)($payload['candidate'] ?? ''));
            if ($candidate === '' || strlen($candidate) > 4096 || stripos($candidate, 'candidate:') === false) {
                throw new RuntimeException('voice_invalid_signal', 422);
            }
            $mid = isset($payload['sdpMid']) ? trim((string)$payload['sdpMid']) : null;
            if ($mid !== null && strlen($mid) > 64) throw new RuntimeException('voice_invalid_signal', 422);
            $index = isset($payload['sdpMLineIndex']) ? (int)$payload['sdpMLineIndex'] : null;
            if ($index !== null && ($index < 0 || $index > 16)) throw new RuntimeException('voice_invalid_signal', 422);
            $ufrag = isset($payload['usernameFragment']) ? trim((string)$payload['usernameFragment']) : null;
            if ($ufrag !== null && strlen($ufrag) > 256) throw new RuntimeException('voice_invalid_signal', 422);
            return array_filter([
                'candidate' => $candidate,
                'sdpMid' => $mid,
                'sdpMLineIndex' => $index,
                'usernameFragment' => $ufrag,
            ], static fn($v) => $v !== null);
        }

        if ($signalType === 'reconnect') {
            $reason = preg_replace('/[^a-z0-9_-]/i', '', (string)($payload['reason'] ?? ''));
            if ($reason === '') $reason = 'network';
            return ['reason' => substr($reason, 0, 32)];
        }

        throw new RuntimeException('voice_invalid_signal', 422);
    }
}

if (!function_exists('bm_watch_party_voice_start_rate_guard')) {
    function bm_watch_party_voice_start_rate_guard(PDO $pdo, int $roomId, int $actorId): void
    {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM watch_party_voice_calls
            WHERE room_id=? AND caller_user_id=? AND created_at>=DATE_SUB(NOW(),INTERVAL 60 SECOND)");
        $stmt->execute([$roomId, $actorId]);
        if ((int)$stmt->fetchColumn() >= 4) throw new RuntimeException('voice_rate_limited', 429);
    }
}

if (!function_exists('bm_watch_party_voice_peer')) {
    function bm_watch_party_voice_peer(PDO $pdo, int $roomId, array $actor): ?array
    {
        $actorVoiceId = bm_watch_party_voice_actor_id($actor);
        if ($roomId <= 0 || $actorVoiceId <= 0) return null;
        $stmt = $pdo->prepare("SELECT m.user_id,m.guest_token_hash,m.guest_name,m.guest_avatar,m.last_seen_at,
                    u.username,u.avatar,u.role,u.vip_expires_at
                FROM watch_party_members m
                LEFT JOIN users u ON u.id=m.user_id
                WHERE m.room_id=? AND m.last_seen_at>=DATE_SUB(NOW(),INTERVAL 30 SECOND)
                ORDER BY m.id ASC LIMIT 4");
        $stmt->execute([$roomId]);
        foreach (($stmt->fetchAll(PDO::FETCH_ASSOC) ?: []) as $row) {
            if ((int)($row['user_id'] ?? 0) > 0) {
                $candidate = [
                    'id' => (int)$row['user_id'],
                    'username' => (string)($row['username'] ?? ('کاربر #' . (int)$row['user_id'])),
                    'avatar' => (string)($row['avatar'] ?? ''),
                    'role' => (string)($row['role'] ?? 'user'),
                    'vip_expires_at' => $row['vip_expires_at'] ?? null,
                ];
            } else {
                $guestHash = strtolower(trim((string)($row['guest_token_hash'] ?? '')));
                if (!preg_match('/^[a-f0-9]{64}$/', $guestHash)) continue;
                $candidate = [
                    'id' => 0,
                    'username' => trim((string)($row['guest_name'] ?? '')) ?: 'همراه مهمان',
                    'avatar' => (string)($row['guest_avatar'] ?? ''),
                    'role' => 'guest',
                    'is_watch_party_guest' => true,
                    'watch_party_guest_hash' => $guestHash,
                ];
            }
            $candidateVoiceId = bm_watch_party_voice_actor_id($candidate);
            if ($candidateVoiceId <= 0 || $candidateVoiceId === $actorVoiceId) continue;
            if (bm_watch_party_voice_test_allowed($candidate)) {
                $candidate['_voice_actor_id'] = $candidateVoiceId;
                return $candidate;
            }
        }
        return null;
    }
}

if (!function_exists('bm_watch_party_voice_call_row')) {
    function bm_watch_party_voice_call_row(PDO $pdo, int $roomId, int $actorVoiceId, ?string $callToken = null): ?array
    {
        $where = 'c.room_id=? AND (c.caller_user_id=? OR c.callee_user_id=?)';
        $params = [$roomId, $actorVoiceId, $actorVoiceId];
        if ($callToken !== null && $callToken !== '') {
            $where .= ' AND c.call_token=?';
            $params[] = $callToken;
        }
        $sql = "SELECT c.*,
                    COALESCE(NULLIF(c.caller_name,''),caller.username) caller_username,
                    COALESCE(NULLIF(c.caller_avatar,''),caller.avatar) caller_avatar,
                    COALESCE(NULLIF(c.callee_name,''),callee.username) callee_username,
                    COALESCE(NULLIF(c.callee_avatar,''),callee.avatar) callee_avatar
                FROM watch_party_voice_calls c
                LEFT JOIN users caller ON caller.id=c.caller_user_id
                LEFT JOIN users callee ON callee.id=c.callee_user_id
                WHERE {$where}
                ORDER BY c.id DESC LIMIT 1";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return is_array($row) ? $row : null;
    }
}

if (!function_exists('bm_watch_party_voice_serialize_call')) {
    function bm_watch_party_voice_serialize_call(array $call, int $actorVoiceId): array
    {
        $isCaller = (int)$call['caller_user_id'] === $actorVoiceId;
        $peerVoiceId = $isCaller ? (int)$call['callee_user_id'] : (int)$call['caller_user_id'];
        $peerName = $isCaller ? (string)($call['callee_username'] ?? '') : (string)($call['caller_username'] ?? '');
        $peerAvatar = $isCaller ? (string)($call['callee_avatar'] ?? '') : (string)($call['caller_avatar'] ?? '');
        $mineMuted = $isCaller ? (bool)$call['caller_muted'] : (bool)$call['callee_muted'];
        $peerMuted = $isCaller ? (bool)$call['callee_muted'] : (bool)$call['caller_muted'];
        $peerIsGuest = bm_watch_party_voice_actor_id_is_guest($peerVoiceId);
        return [
            'token' => (string)$call['call_token'],
            'status' => (string)$call['status'],
            'is_caller' => $isCaller,
            'mine_muted' => $mineMuted,
            'peer_muted' => $peerMuted,
            'created_at' => (string)$call['created_at'],
            'answered_at' => (string)($call['answered_at'] ?? ''),
            'connected_at' => (string)($call['connected_at'] ?? ''),
            'ended_at' => (string)($call['ended_at'] ?? ''),
            'peer' => [
                'user_id' => $peerIsGuest ? 0 : $peerVoiceId,
                'is_guest' => $peerIsGuest,
                'username' => $peerName !== '' ? $peerName : ($peerIsGuest ? 'همراه مهمان' : 'همراه'),
                'avatar_url' => function_exists('bm_user_avatar_url') ? bm_user_avatar_url($peerAvatar) : $peerAvatar,
            ],
        ];
    }
}

if (!function_exists('bm_watch_party_voice_cleanup')) {
    function bm_watch_party_voice_cleanup(PDO $pdo, int $roomId): void
    {
        if ($roomId <= 0) return;
        $pdo->prepare("UPDATE watch_party_voice_calls SET status='missed',ended_at=NOW(),updated_at=NOW() WHERE room_id=? AND status='ringing' AND created_at<DATE_SUB(NOW(),INTERVAL 45 SECOND)")->execute([$roomId]);
        $pdo->prepare("UPDATE watch_party_voice_calls SET status='ended',ended_at=NOW(),updated_at=NOW() WHERE room_id=? AND status='connecting' AND updated_at<DATE_SUB(NOW(),INTERVAL 90 SECOND)")->execute([$roomId]);

        // End a live call only if one of its actor identities really disappeared from
        // the room. Anonymous companions are represented by a stable high virtual ID.
        $active = $pdo->prepare("SELECT id,caller_user_id,callee_user_id FROM watch_party_voice_calls WHERE room_id=? AND status IN ('ringing','connecting','active') ORDER BY id DESC LIMIT 1");
        $active->execute([$roomId]);
        $call = $active->fetch(PDO::FETCH_ASSOC);
        if ($call) {
            $memberStmt = $pdo->prepare("SELECT user_id,guest_token_hash,last_seen_at,(last_seen_at>=DATE_SUB(NOW(),INTERVAL 240 SECOND)) fresh FROM watch_party_members WHERE room_id=?");
            $memberStmt->execute([$roomId]);
            $present = [];
            foreach (($memberStmt->fetchAll(PDO::FETCH_ASSOC) ?: []) as $member) {
                $id = (int)($member['user_id'] ?? 0);
                if ($id <= 0) {
                    $hash = strtolower(trim((string)($member['guest_token_hash'] ?? '')));
                    if (preg_match('/^[a-f0-9]{64}$/', $hash)) {
                        $id = 4000000000000000 + (int)hexdec(substr($hash, 0, 13));
                    }
                }
                if ($id > 0) $present[$id] = !empty($member['fresh']);
            }
            if (empty($present[(int)$call['caller_user_id']]) || empty($present[(int)$call['callee_user_id']])) {
                $pdo->prepare("UPDATE watch_party_voice_calls SET status='ended',ended_at=NOW(),updated_at=NOW() WHERE id=?")->execute([(int)$call['id']]);
            }
        }

        if (random_int(1, 12) === 1) {
            $pdo->prepare("DELETE FROM watch_party_voice_signals WHERE room_id=? AND created_at<DATE_SUB(NOW(),INTERVAL 5 MINUTE)")->execute([$roomId]);
            try {
                $pdo->prepare("DELETE FROM watch_party_voice_signals WHERE room_id=? AND id NOT IN (SELECT id FROM (SELECT id FROM watch_party_voice_signals WHERE room_id=? ORDER BY id DESC LIMIT 160) t)")->execute([$roomId, $roomId]);
            } catch (Throwable $e) { /* optimization only */ }
            try {
                $pdo->prepare("DELETE FROM watch_party_voice_calls WHERE room_id=? AND status IN ('ended','rejected','missed') AND ended_at<DATE_SUB(NOW(),INTERVAL 10 MINUTE)")->execute([$roomId]);
            } catch (Throwable $e) { /* optimization only */ }
        }
    }
}

if (!function_exists('bm_watch_party_voice_start_call')) {
    function bm_watch_party_voice_start_call(PDO $pdo, array $room, array $actor): array
    {
        if (!bm_watch_party_voice_test_allowed($actor)) throw new RuntimeException('voice_test_forbidden', 403);
        if (!bm_watch_party_voice_schema($pdo)) throw new RuntimeException('voice_schema_unavailable', 503);
        $roomId = (int)($room['id'] ?? 0);
        $actorId = bm_watch_party_voice_actor_id($actor);
        if ($actorId <= 0) throw new RuntimeException('voice_test_forbidden', 403);
        $peer = bm_watch_party_voice_peer($pdo, $roomId, $actor);
        if (!$peer) throw new RuntimeException('voice_peer_unavailable', 409);
        $peerId = (int)($peer['_voice_actor_id'] ?? bm_watch_party_voice_actor_id($peer));
        if ($peerId <= 0 || $peerId === $actorId) throw new RuntimeException('voice_peer_unavailable', 409);

        bm_watch_party_voice_cleanup($pdo, $roomId);
        bm_watch_party_voice_start_rate_guard($pdo, $roomId, $actorId);
        $pdo->beginTransaction();
        try {
            $busy = $pdo->prepare("SELECT * FROM watch_party_voice_calls WHERE room_id=? AND status IN ('ringing','connecting','active') ORDER BY id DESC LIMIT 1 FOR UPDATE");
            $busy->execute([$roomId]);
            $existing = $busy->fetch(PDO::FETCH_ASSOC);
            if ($existing) {
                $pdo->rollBack();
                if (((int)$existing['caller_user_id'] === $actorId || (int)$existing['callee_user_id'] === $actorId)
                    && ((int)$existing['caller_user_id'] === $peerId || (int)$existing['callee_user_id'] === $peerId)) {
                    $row = bm_watch_party_voice_call_row($pdo, $roomId, $actorId, (string)$existing['call_token']);
                    return ['call' => $row ? bm_watch_party_voice_serialize_call($row, $actorId) : null, 'reused' => true];
                }
                throw new RuntimeException('voice_busy', 409);
            }
            $token = bin2hex(random_bytes(16));
            $actorName = trim((string)($actor['username'] ?? '')) ?: 'همراه';
            $actorAvatar = trim((string)($actor['avatar'] ?? ''));
            $peerName = trim((string)($peer['username'] ?? '')) ?: 'همراه';
            $peerAvatar = trim((string)($peer['avatar'] ?? ''));
            $stmt = $pdo->prepare("INSERT INTO watch_party_voice_calls(room_id,call_token,caller_user_id,callee_user_id,caller_name,caller_avatar,callee_name,callee_avatar,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,'ringing',NOW(),NOW())");
            $stmt->execute([$roomId, $token, $actorId, $peerId, $actorName, $actorAvatar !== '' ? $actorAvatar : null, $peerName, $peerAvatar !== '' ? $peerAvatar : null]);
            $pdo->commit();
            $row = bm_watch_party_voice_call_row($pdo, $roomId, $actorId, $token);
            return ['call' => $row ? bm_watch_party_voice_serialize_call($row, $actorId) : null, 'reused' => false];
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }
    }
}

if (!function_exists('bm_watch_party_voice_action')) {
    function bm_watch_party_voice_action(PDO $pdo, array $room, array $actor, string $callToken, string $voiceAction, array $input = []): array
    {
        if (!bm_watch_party_voice_test_allowed($actor)) throw new RuntimeException('voice_test_forbidden', 403);
        if (!bm_watch_party_voice_schema($pdo)) throw new RuntimeException('voice_schema_unavailable', 503);
        $roomId = (int)($room['id'] ?? 0);
        $actorId = bm_watch_party_voice_actor_id($actor);
        if ($actorId <= 0) throw new RuntimeException('voice_test_forbidden', 403);
        $callToken = strtolower(trim($callToken));
        if (!preg_match('/^[a-f0-9]{32}$/', $callToken)) throw new RuntimeException('voice_call_not_found', 404);
        $call = bm_watch_party_voice_call_row($pdo, $roomId, $actorId, $callToken);
        if (!$call) throw new RuntimeException('voice_call_not_found', 404);
        $isCaller = (int)$call['caller_user_id'] === $actorId;
        $status = (string)$call['status'];
        $voiceAction = strtolower(trim($voiceAction));

        if ($voiceAction === 'accept') {
            if ($isCaller || $status !== 'ringing') throw new RuntimeException('voice_action_invalid', 409);
            $pdo->prepare("UPDATE watch_party_voice_calls SET status='connecting',answered_at=COALESCE(answered_at,NOW()),updated_at=NOW() WHERE room_id=? AND call_token=? AND status='ringing'")->execute([$roomId, $callToken]);
        } elseif ($voiceAction === 'reject') {
            if ($isCaller || !in_array($status, ['ringing','connecting'], true)) throw new RuntimeException('voice_action_invalid', 409);
            $pdo->prepare("UPDATE watch_party_voice_calls SET status='rejected',ended_at=NOW(),updated_at=NOW() WHERE room_id=? AND call_token=?")->execute([$roomId, $callToken]);
        } elseif ($voiceAction === 'cancel') {
            if (!$isCaller || !in_array($status, ['ringing','connecting'], true)) throw new RuntimeException('voice_action_invalid', 409);
            $pdo->prepare("UPDATE watch_party_voice_calls SET status='ended',ended_at=NOW(),updated_at=NOW() WHERE room_id=? AND call_token=?")->execute([$roomId, $callToken]);
        } elseif ($voiceAction === 'hangup') {
            if (!in_array($status, ['ringing','connecting','active'], true)) return ['call' => bm_watch_party_voice_serialize_call($call, $actorId)];
            $pdo->prepare("UPDATE watch_party_voice_calls SET status='ended',ended_at=NOW(),updated_at=NOW() WHERE room_id=? AND call_token=?")->execute([$roomId, $callToken]);
        } elseif ($voiceAction === 'connected') {
            if (in_array($status, ['ringing','connecting','active'], true)) {
                $pdo->prepare("UPDATE watch_party_voice_calls SET status='active',connected_at=COALESCE(connected_at,NOW()),answered_at=COALESCE(answered_at,NOW()),updated_at=NOW() WHERE room_id=? AND call_token=? AND status IN ('ringing','connecting','active')")->execute([$roomId, $callToken]);
            }
        } elseif ($voiceAction === 'mute') {
            if (!in_array($status, ['connecting','active'], true)) throw new RuntimeException('voice_action_invalid', 409);
            $muted = !empty($input['muted']) && !in_array(strtolower((string)$input['muted']), ['0','false','off','no'], true);
            $column = $isCaller ? 'caller_muted' : 'callee_muted';
            $pdo->prepare("UPDATE watch_party_voice_calls SET {$column}=?,updated_at=NOW() WHERE room_id=? AND call_token=?")->execute([$muted ? 1 : 0, $roomId, $callToken]);
        } else {
            throw new RuntimeException('voice_action_invalid', 422);
        }

        $fresh = bm_watch_party_voice_call_row($pdo, $roomId, $actorId, $callToken);
        return ['call' => $fresh ? bm_watch_party_voice_serialize_call($fresh, $actorId) : null];
    }
}

if (!function_exists('bm_watch_party_voice_signal')) {
    function bm_watch_party_voice_signal(PDO $pdo, array $room, array $actor, string $callToken, string $signalType, string $clientSignalId, $payload): array
    {
        if (!bm_watch_party_voice_test_allowed($actor)) throw new RuntimeException('voice_test_forbidden', 403);
        if (!bm_watch_party_voice_schema($pdo)) throw new RuntimeException('voice_schema_unavailable', 503);
        $roomId = (int)($room['id'] ?? 0);
        $actorId = bm_watch_party_voice_actor_id($actor);
        if ($actorId <= 0) throw new RuntimeException('voice_test_forbidden', 403);
        $callToken = strtolower(trim($callToken));
        $signalType = strtolower(trim($signalType));
        $clientSignalId = trim($clientSignalId);
        if (!preg_match('/^[a-f0-9]{32}$/', $callToken)) throw new RuntimeException('voice_call_not_found', 404);
        if (!in_array($signalType, ['offer','answer','ice','reconnect'], true)) throw new RuntimeException('voice_invalid_signal', 422);
        if (!preg_match('/^[A-Za-z0-9_-]{12,64}$/', $clientSignalId)) throw new RuntimeException('voice_invalid_signal', 422);

        $call = bm_watch_party_voice_call_row($pdo, $roomId, $actorId, $callToken);
        if (!$call || !in_array((string)$call['status'], ['ringing','connecting','active'], true)) throw new RuntimeException('voice_call_not_found', 404);
        $isCaller = (int)$call['caller_user_id'] === $actorId;
        $callStatus = (string)$call['status'];
        if ($signalType === 'offer' && !$isCaller) throw new RuntimeException('voice_invalid_signal', 403);
        if ($signalType === 'answer' && $isCaller) throw new RuntimeException('voice_invalid_signal', 403);
        if ($signalType === 'answer' && !in_array($callStatus, ['connecting','active'], true)) throw new RuntimeException('voice_invalid_signal', 409);
        if ($signalType === 'reconnect' && !in_array($callStatus, ['connecting','active'], true)) throw new RuntimeException('voice_invalid_signal', 409);
        if ($signalType === 'ice' && !$isCaller && $callStatus === 'ringing') throw new RuntimeException('voice_invalid_signal', 409);
        $targetId = $isCaller ? (int)$call['callee_user_id'] : (int)$call['caller_user_id'];
        if ($targetId <= 0 || $targetId === $actorId) throw new RuntimeException('voice_invalid_signal', 403);

        $payload = bm_watch_party_voice_validate_signal_payload($signalType, $payload);
        $encoded = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($encoded === false || strlen($encoded) > 32768) throw new RuntimeException('voice_invalid_signal', 422);

        $rate = $pdo->prepare('SELECT COUNT(*) FROM watch_party_voice_signals WHERE room_id=? AND call_token=? AND sender_user_id=? AND created_at>=DATE_SUB(NOW(),INTERVAL 10 SECOND)');
        $rate->execute([$roomId, $callToken, $actorId]);
        if ((int)$rate->fetchColumn() >= 45) throw new RuntimeException('voice_rate_limited', 429);
        if ($signalType === 'ice') {
            $iceRate = $pdo->prepare("SELECT COUNT(*) FROM watch_party_voice_signals WHERE room_id=? AND call_token=? AND sender_user_id=? AND signal_type='ice'");
            $iceRate->execute([$roomId, $callToken, $actorId]);
            if ((int)$iceRate->fetchColumn() >= 140) throw new RuntimeException('voice_rate_limited', 429);
        }

        try {
            $stmt = $pdo->prepare('INSERT INTO watch_party_voice_signals(room_id,call_token,sender_user_id,target_user_id,signal_type,client_signal_id,payload_json,created_at) VALUES(?,?,?,?,?,?,?,NOW())');
            $stmt->execute([$roomId, $callToken, $actorId, $targetId, $signalType, $clientSignalId, $encoded]);
            return ['signal_id' => (int)$pdo->lastInsertId(), 'duplicate' => false];
        } catch (PDOException $e) {
            if ((string)$e->getCode() === '23000') {
                $stmt = $pdo->prepare('SELECT id FROM watch_party_voice_signals WHERE room_id=? AND client_signal_id=? LIMIT 1');
                $stmt->execute([$roomId, $clientSignalId]);
                return ['signal_id' => (int)$stmt->fetchColumn(), 'duplicate' => true];
            }
            throw $e;
        }
    }
}

if (!function_exists('bm_watch_party_voice_poll')) {
    function bm_watch_party_voice_poll(PDO $pdo, array $room, array $actor, int $afterSignalId = 0): array
    {
        if (!bm_watch_party_voice_test_allowed($actor)) return ['enabled' => false];
        if (!bm_watch_party_voice_schema($pdo)) return ['enabled' => true, 'schema_ready' => false, 'peer_available' => false, 'call' => null, 'signals' => []];
        $roomId = (int)($room['id'] ?? 0);
        $actorId = bm_watch_party_voice_actor_id($actor);
        if ($actorId <= 0) return ['enabled' => false];
        bm_watch_party_voice_cleanup($pdo, $roomId);
        $peer = bm_watch_party_voice_peer($pdo, $roomId, $actor);
        $call = bm_watch_party_voice_call_row($pdo, $roomId, $actorId);
        $serialized = null;
        if ($call) {
            $created = strtotime((string)($call['created_at'] ?? '')) ?: 0;
            $final = in_array((string)$call['status'], ['ended','rejected','missed'], true);
            if (!$final || $created >= time() - 120) $serialized = bm_watch_party_voice_serialize_call($call, $actorId);
        }

        $signals = [];
        $lastSignalId = max(0, $afterSignalId);
        if ($serialized) {
            $stmt = $pdo->prepare('SELECT id,call_token,sender_user_id,signal_type,payload_json,created_at FROM watch_party_voice_signals WHERE room_id=? AND call_token=? AND target_user_id=? AND id>? ORDER BY id ASC LIMIT 60');
            $stmt->execute([$roomId, (string)$serialized['token'], $actorId, $lastSignalId]);
            $signals = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
            foreach ($signals as &$signal) {
                $signal['id'] = (int)$signal['id'];
                $lastSignalId = max($lastSignalId, $signal['id']);
                $signal['sender_user_id'] = (int)$signal['sender_user_id'];
                $signal['payload'] = json_decode((string)($signal['payload_json'] ?? 'null'), true);
                unset($signal['payload_json']);
            }
            unset($signal);
        }

        return [
            'enabled' => true,
            'schema_ready' => true,
            'beta' => false,
            'peer_available' => (bool)$peer,
            'peer' => $peer ? [
                'user_id' => (int)($peer['id'] ?? 0),
                'is_guest' => !empty($peer['is_watch_party_guest']),
                'username' => (string)($peer['username'] ?? 'همراه'),
                'avatar_url' => function_exists('bm_user_avatar_url') ? bm_user_avatar_url((string)($peer['avatar'] ?? '')) : (string)($peer['avatar'] ?? ''),
            ] : null,
            'call' => $serialized,
            'signals' => $signals,
            'last_signal_id' => $lastSignalId,
        ];
    }
}
