# Bankmovie Pass 4.3.1 — Kotlin Compile Fix

این پچ چهار خطای کامپایل `PlayerActivity.kt` در Pass 4.3 را اصلاح می‌کند:

- آرایه‌ی `cornerRadii` اکنون Float واقعی دریافت می‌کند و دیگر `dp(26f)` به تابع `dp(Int)` پاس داده نمی‌شود.
- برای پس‌زمینه‌ی Composer از `setBackgroundColor(...)` استفاده می‌شود؛ پراپرتی `background` نیاز به `Drawable` دارد.
- پس‌زمینه‌ی ImageView استیکر نیز با `setBackgroundColor(Color.TRANSPARENT)` تنظیم می‌شود.
- فراخوانی باقیمانده‌ی `releaseRtc()` حذف شد، چون WebRTC در نسخه Chat-Only عمداً حذف شده است.

فایل `verify_pass4_3_1_kotlin_compile_fix.sh` از بازگشت همین خطاها جلوگیری می‌کند.
