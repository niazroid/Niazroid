# Bankmovie V2.1 — Glass Redesign Pass 3

این پاس ادامه مستقیم Pass 2 است و هدفش یک‌دست‌کردن زبان طراحی شیشه‌ای کل اپ با صفحه Detail است.

## تغییرات Detail

- نوار «آپدیت شد» مستقیماً زیر تصویر Hero قرار گرفت.
- باکس امتیاز دیگر سال، زمان یا متن ساختگی نشان نمی‌دهد.
- IMDb و رضایت/لایک آرشیو ۱ در یک Glass Strip تمیز نمایش داده می‌شوند.
- اگر نه IMDb وجود داشته باشد و نه رضایت/لایک، کل Glass Strip مخفی می‌شود.
- مدت زمان به «اطلاعات بیشتر» منتقل شد.
- کشور برای آرشیو ۱ و ۳ از JSON Array به متن تمیز تبدیل می‌شود و دیگر `[کشور]` یا `["کشور"]` دیده نمی‌شود.
- کشور، مدت زمان، سال، زبان، وضعیت، شبکه و استودیو در اطلاعات بیشتر نرمال شده‌اند.

## داده رضایت آرشیو ۱

`server-required/app_api.php` اکنون مقدار `feedback_satisfaction` منبع Archive 1 را بدون حذف به اپ می‌فرستد و alias `likes` نیز دارد.
برای دیده‌شدن این مقدار در APK، نسخه جدید `app_api.php` باید روی سایت نیز جایگزین شود.

## یک‌دست‌سازی UI

- رنگ Dark Mode از Blue-Black به Charcoal Glass تغییر کرد.
- Bottom Navigation به Glass Surface مشترک منتقل شد.
- Drawer و آیتم‌های آن Glass شدند.
- Modal buttonها، انتخاب‌ها، کارت‌های تنظیمات/پروفایل و چندین surface مشترک MainActivity از همان Glass Design System استفاده می‌کنند.
- Download Manager نیز Glass Surface و Accent Glass مشترک گرفته است.
- دکمه اصلی Auth به Accent Glass تبدیل شد.
- Focus و TV scaling قبلی حفظ شده است.

## فایل‌های اصلی

- `app/src/main/java/ir/bankmoviee/app/MainActivity.kt`
- `app/src/main/java/ir/bankmoviee/app/UiPreferences.kt`
- `app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt`
- `app/src/main/java/ir/bankmoviee/app/AuthActivity.kt`
- `server-required/app_api.php`

## تست

- `verify_phase11_1.sh`
- `php -l server-required/app_api.php`


## Pass 3.1 — Kotlin compile fix
- خطای `Unresolved reference: palette` در `DownloadsActivity.kt` رفع شد.
- توابع `glass()` و `glassTint()` اکنون پالت فعال را با `UiPreferences.palette(this)` دریافت می‌کنند.
- ظاهر Glass Pass 3 بدون تغییر حفظ شده است.
