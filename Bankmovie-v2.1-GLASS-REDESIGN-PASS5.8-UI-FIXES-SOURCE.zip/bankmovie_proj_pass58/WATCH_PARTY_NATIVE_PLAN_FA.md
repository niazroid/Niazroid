# Bankmovie Android — Watch Party Native Integration Plan

این سند از روی پیاده‌سازی فعلی سایت (`watch_party_api.php`, `includes/watch_party.php`, `watch_party_lab.php`) تهیه شده است.

## اصل معماری

اپ نباید Watch Party جداگانه بسازد. Android و وب باید دقیقاً به همان اتاق‌ها، همان state، همان messages و همان member list متصل شوند تا کاربر سایت و کاربر اپ بتوانند داخل یک اتاق مشترک باشند.

## قابلیت‌های موجود در سایت که باید Native شوند

- ساخت اتاق توسط VIP، حداکثر دو اتاق فعال برای هر میزبان.
- ورود با invite code و ظرفیت اتاق.
- انقضای اتاق و countdown واقعی سرور.
- host-only playback control.
- sync state: play / pause / seek / state / buffering / source_change.
- sequence number + server_time_ms برای جلوگیری از loop و drift.
- source URL و subtitle URL مشترک.
- member list همراه avatar، VIP/admin badges و role.
- chat polling با after_message_id و delivery receipt خودکار.
- client_message_id برای retry بدون duplicate.
- rate limit پیام.
- تاریخچه chat صفحه‌بندی‌شده.
- sticker/GIF با marker استاندارد `[bm-sticker:PACK:ID]` و catalog مشترک سایت.
- sticker overlay روی فیلم برای پیام جدید.
- unread counter / preview toast / chat sound.
- room settings، scheduled start و background/theme.

## Bridge مناسب اپ

`watch_party_api.php` وب به session cookie و CSRF وابسته است. Android از token و HMAC فعلی `app_user_api.php` استفاده می‌کند. بنابراین برای Native باید endpoint اپ با همان APP signature + user token ساخته شود و داخل آن همان توابع `includes/watch_party.php` فراخوانی شوند. این کار باعث می‌شود دیتابیس و منطق sync یکی بماند اما امنیت اپ با معماری فعلی Bankmovie هماهنگ باشد.

## UI

UI نهایی بعد از دریافت اسکرین‌شات مرجع کاربر ساخته می‌شود و باید با Glass Design System فعلی Bankmovie یکی باشد، نه WebView خام.

## Pass 3.2

Archive selector در Home/TV/Search به همان charcoal glass rail + active accent segment صفحه Categories منتقل شد تا آرشیوها در تمام اپ یک زبان بصری داشته باشند.
