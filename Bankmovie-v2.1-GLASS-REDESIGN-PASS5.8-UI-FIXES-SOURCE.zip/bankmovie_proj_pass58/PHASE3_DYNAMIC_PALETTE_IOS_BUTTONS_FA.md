# Bankmovie v2.1 — Phase 3: Dynamic Palette + iOS / ChatGPT-style Detail UI

این نسخه بر پایه سورس کامل Phase 2 ساخته شده و فقط رابط صفحه جزئیات موبایل را مدرن می‌کند؛ منطق TV دست‌نخورده مانده است.

## تغییرات اصلی
- ساخت پالت رنگی پویا از Poster/Backdrop خود هر عنوان با نمونه‌برداری سبک 32×32، بدون وابستگی جدید.
- کش پالت روی همان دستگاه (Memory + SharedPreferences) تا 7 روز برای جلوگیری از Flash و محاسبه مجدد.
- پس‌زمینه سینمایی کل صفحه جزئیات + هماهنگ شدن Status Bar با رنگ عنوان.
- Hero تمام‌عرض با Fade به پالت فیلم، عنوان/متا/ژانر/خلاصه روی تصویر.
- دکمه Play سبز و Premium باقی مانده ولی به Capsule مدرن تبدیل شده است.
- Trailer / Back / Watchlist با ظاهر Glass/iPhone/ChatGPT-style و حاشیه ظریف.
- کارت بازیگران و Download Box با Surface و Border گرفته‌شده از همان پالت.
- دکمه Copy All سریال با Glass + Dynamic Accent.
- دکمه‌های Play/Download هر کیفیت بازطراحی شده‌اند: Play سبز Premium، Download Glass.
- اکشن‌های دیدگاه‌ها iOS-like شده‌اند؛ Like/Dislike داخل یک Segmented Capsule مشترک قرار گرفته‌اند.
- صفحه TV از طراحی Phase 2 استفاده می‌کند تا Remote navigation تغییر نکند.

## Performance
- هیچ کتابخانه Palette جدیدی اضافه نشده است.
- استخراج رنگ فقط از Bitmap کوچک 32×32 انجام می‌شود.
- اگر پوستر از صفحه قبلی در Image LRU Cache موجود باشد، رنگ پیش از رندر Detail آماده است.
- پالت روی دستگاه Cache می‌شود؛ بازگشت‌های بعدی بدون محاسبه و بدون پرش رنگ انجام می‌شوند.
