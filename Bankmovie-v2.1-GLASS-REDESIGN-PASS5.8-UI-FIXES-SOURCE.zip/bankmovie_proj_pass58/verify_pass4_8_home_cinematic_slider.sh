#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
start=s.index('    private fun siteSlider(items: JSONArray): View {')
end=s.index('    private fun addCollectionsRail(page: LinearLayout) {', start)
fn=s[start:end]
assert 'PASS 4.8: clean cinematic Home hero.' in fn
assert 'tag = "bm_home_cinematic_slider"' in fn
assert 'LinearLayout.LayoutParams(-1, dp(505))' in fn
assert 'tag = "bm_home_slider_title"' in fn
assert 'bottomMargin = dp(48)' in fn
assert 'bottomMargin = dp(22)' in fn
assert 'if (selected) p.primary' in fn
assert 'fun openCurrent()' in fn
assert 'openCurrent()' in fn
assert 'iconActionButton(t("تماشا کنید", "Watch Now")' not in fn
assert 'val watchButton =' not in fn
assert 'contentBox.addView(watchButton' not in fn
assert 'val genre = TextView' not in fn
assert 'val desc = TextView' not in fn
assert 'val meta = LinearLayout' not in fn
home=s[s.index('    private fun showHome() {'):s.index('    private fun openTelegramChannel()', s.index('    private fun showHome() {'))]
assert 'PASS 4.8: a compact context strip closes the Hero' in home
assert 'page.addView(playlistGuideCard(compact = true)' in home
assert 'topMargin = dp(5)' in home
print('PASS4_8_HOME_CINEMATIC_SLIDER_OK')
PY
