# Phase 11.1 — Kotlin Compile Fix

این نسخه فقط خطاهای کامپایل مشاهده‌شده در GitHub Actions برای Phase 11 را اصلاح می‌کند و قابلیت‌های Phase 11 را تغییر نمی‌دهد.

اصلاح‌ها:

- فراخوانی‌های `sectionHeader` که به‌خاطر قرار گرفتن پارامتر Boolean بعد از lambda با trailing-lambda اشتباه bind می‌شدند، با آرگومان نام‌دار `more = { ... }` اصلاح شدند.
- `GridLayout.gravity` که API معتبری نیست حذف شد و مرکزچینی Grid موبایل از طریق `LinearLayout.LayoutParams.gravity` انجام می‌شود.
- import جاافتاده `android.graphics.drawable.GradientDrawable` به `PlayerActivity.kt` اضافه شد.
- `verify_phase11_1.sh` برای جلوگیری از بازگشت همین خطاهای کامپایل اضافه شد.

فایل‌های Legacy سرور (`api5.php` و `api5_lib.php`) بدون تغییر مانده‌اند.
