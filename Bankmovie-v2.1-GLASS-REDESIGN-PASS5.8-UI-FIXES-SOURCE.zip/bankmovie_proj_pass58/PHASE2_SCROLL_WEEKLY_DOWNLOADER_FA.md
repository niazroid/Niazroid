# Bankmovie Android V2.1 — Phase 2

این سورس کامل پروژه اندروید است و روی Phase 1 ساخته شده است.

تغییرات این مرحله:
- ذخیره موقعیت اسکرول صفحه جزئیات فیلم/سریال تا ۱ ساعت روی همان دستگاه و بازیابی بعد از بازگشت.
- بازگشت هوشمند در صفحات Home/List/Search/Collection و سایر ScrollViewها نیز موقعیت قبلی را تا ۱ ساعت در history همان اجرای اپ برمی‌گرداند؛ restore چندمرحله‌ای جلوی پرش به بالا در محتوای async را می‌گیرد.
- پخش هفتگی موبایل به شکل کامپکت دو ستونه با پوستر کوچک و چیپ روزها؛ لینک تلگرام بلافاصله بالای آن باقی مانده است.
- نمایش مستقیم «کپی لینک همه قسمت‌ها» در باکس دانلود سریال، انتخاب کیفیت، کپی یک URL در هر خط و «دانلود همه» همان کیفیت.
- نام فایل دانلود: اولویت با نام واقعی فایل از URL/متادیتا؛ fallback با عنوان اصلی انگلیسی و SxxExx/Eyy.
- دانلودر داخلی: زمان‌بندی شروع، Alarm پس از ریبوت، حالت Scheduled، و درخواست اختیاری مجوز Exact Alarm برای دقت بهتر در Android 12+.
- افزودن لیست لینک‌ها از Clipboard (تا ۵۰۰ URL یکتا) به صف دانلود داخلی.
- دانلود فعال هنگام تنظیم زمان‌بندی عمداً قطع نمی‌شود؛ فایل‌های جدید/منتظر طبق زمان شروع می‌شوند.

فایل‌های اصلی تغییرکرده/اضافه‌شده:
- app/src/main/java/ir/bankmoviee/app/MainActivity.kt
- app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt
- app/src/main/java/ir/bankmoviee/app/InternalDownloadService.kt
- app/src/main/java/ir/bankmoviee/app/InternalDownloadStore.kt
- app/src/main/java/ir/bankmoviee/app/DownloadBootReceiver.kt
- app/src/main/java/ir/bankmoviee/app/DownloadScheduleManager.kt
- app/src/main/AndroidManifest.xml
