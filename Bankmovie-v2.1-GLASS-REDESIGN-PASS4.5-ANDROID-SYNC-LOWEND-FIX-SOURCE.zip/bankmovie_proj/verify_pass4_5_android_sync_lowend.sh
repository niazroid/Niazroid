#!/usr/bin/env bash
set -euo pipefail
P=app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt
U=server-required/app_user_api.php
S=server-required/includes/watch_party.php
G=app/build.gradle
MAN=app/src/main/AndroidManifest.xml

test -s "$P"
test -s "$U"
test -s "$S"

# Keep chat-only Watch Party compact.
! grep -q 'org.webrtc' "$P"
! grep -q 'webrtc-sdk' "$G"
! grep -q 'RECORD_AUDIO' "$MAN"

# Android -> Android playback must create the guest player when host is already playing.
grep -Fq 'partyGuestAutoStarting' "$P"
grep -Fq 'if (state != null && !state.optBoolean("paused", true) && sharedSource.isNotBlank() && (!partyPlaybackStarted || player == null))' "$P"
grep -Fq 'partyLobbyDialog?.dismiss()' "$P"
grep -Fq 'sendWatchPartyControl("play")' "$P"
grep -Fq 'retryAttempt < 1' "$P"

# Low-end exit/background ANR guards.
grep -Fq 'PASS 4.5 low-end ANR fix' "$P"
grep -Fq 'private fun releasePlayerAsyncForExit()' "$P"
grep -Fq '"BM-VLC-Release"' "$P"
grep -Fq 'releasePlayerAsyncForExit()' "$P"
grep -Fq 'val existing = player' "$P"

# Real avatars: selected preset avatar_key + custom avatar, and absolute URL for Android.
grep -Fq 'private fun partyAbsoluteUrl(' "$P"
grep -Fq "COALESCE(u.avatar_key,'') avatar_key" "$S"
grep -Fq 'bm_user_avatar_preset_path' "$S"
grep -Fq '$bmWpAbsoluteUrl' "$U"

# Normal player keeps five retries.
grep -Fq 'private val maxPlaybackRetries = 5' "$P"

php -l "$U" >/dev/null
php -l "$S" >/dev/null

echo PASS4_5_ANDROID_SYNC_LOWEND_OK
