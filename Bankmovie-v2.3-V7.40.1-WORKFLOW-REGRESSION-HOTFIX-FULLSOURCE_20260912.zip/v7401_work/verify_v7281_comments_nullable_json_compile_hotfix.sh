#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'

# All V7.28 features/regressions must remain intact first.
bash verify_v728_social_tv_loader_sheets_weekly.sh

# Both social comment loaders stabilize the nullable Result.json into local vals.
grep -Fq 'val mobileCommentsPayload = result.json' "$MAIN"
grep -Fq 'if (!result.success || mobileCommentsPayload == null)' "$MAIN"
grep -Fq 'knownTotal = mobileCommentsPayload.optInt("total")' "$MAIN"
grep -Fq 'val items = mobileCommentsPayload.optJSONArray("items") ?: JSONArray()' "$MAIN"
grep -Fq 'val commentsPayload = result.json' "$MAIN"
grep -Fq 'if (!result.success || commentsPayload == null)' "$MAIN"
grep -Fq 'val total = commentsPayload.optInt("total")' "$MAIN"
grep -Fq 'val avg = commentsPayload.optDouble("rating_avg", 0.0)' "$MAIN"
grep -Fq 'val items = commentsPayload.optJSONArray("items") ?: JSONArray()' "$MAIN"

# Guard specifically against the unsafe V7.28 accesses that GitHub Kotlin rejected.
python3 - "$MAIN" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
for start_name, end_name in [
    ('private fun renderMobileCommentsSectionV727(', 'private fun showCommentComposer('),
    ('private fun renderCommentsSection(', 'private fun playTrailer('),
]:
    a=s.index(start_name)
    b=s.index(end_name,a)
    block=s[a:b]
    assert 'result.json.optInt("total")' not in block
    assert 'result.json.optDouble("rating_avg", 0.0)' not in block
    assert 'result.json.optJSONArray("items")' not in block
PY

grep -Fq 'sourceMainUpdateNinthHotfixCompileTag=BANKMOVIE-2.3-V7281-20260911' BANKMOVIE_BUILD_SOURCE_2_3.txt

echo V7281_COMMENTS_NULLABLE_JSON_COMPILE_HOTFIX_OK
