#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
PLAYER='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
RES='app/src/main/res/drawable'

# Stable regressions from the previous line.
bash verify_v726_mobile_nav_player_polish.sh
bash verify_v722_cast_removed_player_retained.sh
bash verify_v723_player_last_frame_hold.sh

# V7.27 supplied icon pack and real Collection art stay intact.
for icon in ic_player_fit.xml ic_player_lock.xml ic_player_unlock.xml ic_player_pip.xml ic_speedometer.xml ic_notifications_ui.xml ic_edit_avatar.xml ic_admin_verified.xml; do
  test -s "$RES/$icon"
done
grep -Fq 'R.drawable.bm_category_collections){ showCollections() }' "$MAIN"
test -s app/src/main/res/drawable-nodpi/bm_category_collections.webp

# Social comments now shared by mobile and TV.
grep -Fq 'V7.28: the same social-card comment language is used on phone and TV.' "$MAIN"
grep -Fq 'renderMobileCommentsSectionV727(page, item)' "$MAIN"
grep -Fq 'if (isTvLike()) root.post { applyTvFocusToClickableTree(root) }' "$MAIN"
grep -Fq 'phone and TV share the same social reply composer' "$MAIN"
grep -Fq 'styleShownDialog(dialog, sheet, preferredFocus = send, maxWidthDp = 760' "$MAIN"

# Admin badge must keep the green drawable itself, not be tinted blue in comments.
grep -Fq 'setImageResource(R.drawable.ic_admin_verified); contentDescription = t("تأییدشده", "Verified")' "$MAIN"
! grep -Fq 'setImageResource(R.drawable.ic_admin_verified); setColorFilter(accent)' "$MAIN"

# Main comment composer has real spoiler state.
grep -Fq 'var spoiler = false' "$MAIN"
grep -Fq 'text = t("این دیدگاه اسپویل دارد", "This comment contains spoilers")' "$MAIN"
grep -Fq 'AccountApi.addComment(this@MainActivity, item, value, 0, spoiler, null)' "$MAIN"

# Reply composer exposes only one Sticker media action.
python3 - "$MAIN" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
a=s.index('private fun showMobileCommentComposerV727(')
b=s.index('private fun showCommentComposer(',a)
block=s[a:b]
assert 'tool(t("استیکر", "Sticker")' in block
assert 'tools.addView(tool("GIF"' not in block
PY

# Supplied Uiverse-inspired loader is native and wired into splash/load-more/comments.
test -s app/src/main/java/ir/bankmoviee/app/TriRingLoaderView.kt
test -s app/src/main/java/ir/bankmoviee/app/LoadMoreLoaderButtonView.kt
grep -Fq 'Color.rgb(244, 67, 54)' app/src/main/java/ir/bankmoviee/app/TriRingLoaderView.kt
grep -Fq 'Color.rgb(255, 193, 7)' app/src/main/java/ir/bankmoviee/app/TriRingLoaderView.kt
grep -Fq 'Color.rgb(139, 195, 74)' app/src/main/java/ir/bankmoviee/app/TriRingLoaderView.kt
grep -Fq 'loading.addView(TriRingLoaderView(this@MainActivity)' "$MAIN"
grep -Fq 'return LoadMoreLoaderButtonView(this).apply {' "$MAIN"
grep -Fq 'addView(TriRingLoaderView(this@MainActivity), FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER))' "$MAIN"

# Telegram/home, draggable player/download sheets, and weekly mobile redesign.
grep -Fq 'Telegram Channel @${AppConfig.TELEGRAM_HANDLE}' "$MAIN"
grep -Fq 'private fun wireV728DraggableBottomSheet(' "$MAIN"
[[ "$(grep -Fc 'wireV728DraggableBottomSheet(dialog, shell, dragHandle)' "$MAIN")" -ge 2 ]]
grep -Fq 'private fun showDownloadChoiceModal(item: JSONObject, link: JSONObject)' "$MAIN"
grep -Fq 'BankMovie internal downloader' "$MAIN"
grep -Fq 'private fun addWeeklyScheduleSectionMobileV728(' "$MAIN"
grep -Fq 'Latest episodes through the week' "$MAIN"
grep -Fq 'addWeeklyScheduleSectionMobileV728(page, weekly, available, selectedIndex)' "$MAIN"
# TV Weekly remains on the old explicit focus registration path.
grep -Fq 'tvHomeWeeklyFocusRegistration = HomeTvWeeklyFocusRegistration(' "$MAIN"
grep -Fq 'wireV70WeeklySurface()' "$MAIN"

# Player frame bridge + no Cast regressions.
grep -Fq 'PLAYER_FRAME_PROBE_TIMEOUT_MS = 12_000L' "$PLAYER"
grep -Fq 'lifecycleFrameProbeReadySamples >= 2' "$PLAYER"
! grep -Eq 'CastContext|RemoteMediaClient|MediaRoute|DlnaController|Chromecast' "$PLAYER"
! grep -Eq 'play-services-cast|androidx\.mediarouter' app/build.gradle

grep -Fq 'sourceMainUpdateNinthHotfixTag=BANKMOVIE-2.3-V728-20260911' BANKMOVIE_BUILD_SOURCE_2_3.txt

echo V728_SOCIAL_TV_LOADER_SHEETS_WEEKLY_OK
