# Bankmovie V7.27 — Mobile Comments Social UI + Icon Refresh

این نسخه روی V7.26 ساخته شده و فیکس‌های Player frame bridge، retained Search scroll، Mobile Navigation personalization و همه اصلاحات TV قبلی را نگه می‌دارد.

تغییرات این نسخه:
- Fullscreen/Fit، Lock، Unlock، PiP/Popup و Speedometer پلیر با SVGهای جدید جایگزین شدند.
- آیکن اعلان جدید فقط برای UI برنامه استفاده می‌شود؛ آیکن solid سرویس Notification دست‌نخورده نگه داشته شده تا small-icon اندروید خراب نشود.
- آیکن Edit Avatar/Profile با SVG جدید جایگزین شد.
- تصویر واقعی `bm_category_collections.webp` دوباره روی کارت کالکشن صفحه Categories استفاده می‌شود؛ `ic_nav_collection` فقط نقش آیکن را دارد.
- کامنت‌های موبایل از نو طراحی شدند: هدر، Composer سریع، Sort pill، کارت dark-social، verified/admin badge، time/menu، Reply، Like/Dislike و reply thread.
- Reply composer موبایل به شکل bottom sheet با handle، target row، input بزرگ، GIF/Sticker، spoiler toggle و دکمه ارسال آبی بازطراحی شد.
- TV عمداً از UI جدید کامنت‌ها مستثنا شده و همان مسیر قبلی را حفظ می‌کند تا remote focus و routing تغییر نکند.
