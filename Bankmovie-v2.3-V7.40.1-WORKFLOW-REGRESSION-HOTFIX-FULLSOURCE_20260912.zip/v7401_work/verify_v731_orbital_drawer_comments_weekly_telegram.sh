#!/usr/bin/env bash
set -euo pipefail

main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
loader='app/src/main/java/ir/bankmoviee/app/OrbitalGlowLoaderView.kt'
draw='app/src/main/res/drawable'

[[ -s "$main" && -s "$loader" ]]
grep -Fq 'sourceMainUpdateTwelfthHotfixTag=BANKMOVIE-2.3-V731-20260911' BANKMOVIE_BUILD_SOURCE_2_3.txt
grep -Fq 'sourceMainUpdateThirteenthHotfixTag=BANKMOVIE-2.3-V732-20260911' BANKMOVIE_BUILD_SOURCE_2_3.txt

# Splash loader replacement.
grep -Fq 'loading.addView(OrbitalGlowLoaderView(this@MainActivity)' "$main"
grep -Fq 'class OrbitalGlowLoaderView' "$loader"
grep -Fq 'DashPathEffect(floatArrayOf(44f, 1111f), dashOffset)' "$loader"
grep -Fq 'duration = 3000L' "$loader"
grep -Fq 'PathInterpolator(0.42f, 0.17f, 0.75f, 0.83f)' "$loader"
grep -Fq 'M92,15.492S78.194,4.967,66.743,16.887' "$loader"
grep -Fq 'LinearLayout.LayoutParams(dp(128), dp(128))' "$main"

# Mobile drawer is themed and has a real sign-out row; TV quick menu remains separate.
grep -Fq 'private fun drawerItem(' "$main"
grep -Fq 'selected: Boolean = false' "$main"
grep -Fq 'danger: Boolean = false' "$main"
grep -Fq 'R.drawable.ic_logout' "$main"
grep -Fq 'if (isTvLike()) {' "$main"
grep -Fq 'showTvQuickMenu()' "$main"
test -s "$draw/ic_logout.xml"

# Comments page at five items + styled three-dot actions sheet.
grep -Fq 'requestedPage, 5, selectedSort' "$main"
grep -Fq 'requestedPage, 5, apiSort' "$main"
grep -Fq 'private fun showCommentActionsSheetV731' "$main"
grep -Fq 'R.drawable.ic_edit_avatar' "$main"
grep -Fq 'R.drawable.ic_report' "$main"
grep -Fq 'R.drawable.ic_comment_pin' "$main"
grep -Fq 'R.drawable.ic_comment_delete' "$main"
! grep -Fq 'android.widget.PopupMenu' "$main"
grep -Fq 'showChoiceSheetV731(t("مرتب‌سازی دیدگاه‌ها", "Sort comments")' "$main"

# Standard mobile dialog styling follows the Player/Downloader sheet language.
grep -Fq 'all standard mobile dialogs share the Player/Downloader sheet language.' "$main"
grep -Fq 'win.setGravity(Gravity.BOTTOM)' "$main"
grep -Fq 'private fun showChoiceSheetV731' "$main"
grep -Fq 'private fun showConfirmSheetV731' "$main"
grep -Fq 'private fun ensureV732MobileSheetHandle' "$main"
grep -Fq 'wireV728DraggableBottomSheet(dialog, body, mobileDragHandle)' "$main"

# V7.32 downloader settings are user-facing and wired into the real service.
downloads='app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt'
download_prefs='app/src/main/java/ir/bankmoviee/app/DownloadPreferences.kt'
download_service='app/src/main/java/ir/bankmoviee/app/InternalDownloadService.kt'
[[ -s "$downloads" && -s "$download_prefs" && -s "$download_service" ]]
grep -Fq 'showDownloadSettingsSheet()' "$downloads"
grep -Fq 'تعداد کانکشن برای هر فایل' "$downloads"
grep -Fq 'اعلان اتمام دانلود' "$downloads"
grep -Fq 'MODE_SEQUENTIAL' "$download_prefs"
grep -Fq 'connectionsPerFile(context: Context): Int' "$download_prefs"
grep -Fq 'DownloadPreferences.mode(this) == DownloadPreferences.MODE_SEQUENTIAL' "$download_service"
grep -Fq 'DownloadPreferences.connectionsPerFile(this).coerceIn(1, 8)' "$download_service"
grep -Fq 'DownloadPreferences.completionNotificationEnabled(this)' "$download_service"

# Player settings sheets also get the same bottom-sheet drag language.
# Playback-quality group no longer shows the redundant download icon.
grep -Fq 'no redundant download icon beside the playback-quality group title.' "$main"

# Weekly icon + today selection + current-day scroll, while keeping two columns.
test -s "$draw/ic_weekly_schedule.xml"
grep -Fq 'R.drawable.ic_weekly_schedule' "$main"
grep -Fq 'val todayKey = when (java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_WEEK))' "$main"
grep -Fq 'tabsScroll.smoothScrollTo(targetX, 0)' "$main"
grep -Fq 'columnCount = 2' "$main"

# Telegram uses one component everywhere and no fixed undersized wrappers remain.
grep -Fq 'return telegramJoinButton()' "$main"
grep -Fq 'minimumHeight = dp(78)' "$main"
! grep -Fq 'telegramJoinButton(), LinearLayout.LayoutParams(-1, dp(50))' "$main"
! grep -Fq 'telegramJoinButton(), LinearLayout.LayoutParams(-1, dp(52))' "$main"
! grep -Fq 'telegramJoinButton(), LinearLayout.LayoutParams(-1, dp(54))' "$main"

# Keep critical regressions intact without recursively running the full historical verifier chain.
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
grep -Fq 'private fun ensurePlayerModalDragHandle' "$player"
grep -Fq 'wirePlayerModalDrag(dialog, mobileDragHandle)' "$player"
manifest='app/src/main/AndroidManifest.xml'
grep -Fq 'PLAYER_UTILITY_ICON_DP = 24' "$player"
grep -Fq 'BANKMOVIE_V7_23_PLAYER_LAST_FRAME_HOLD' "$player"
grep -Fq 'V7.24: retaining the real Search View tree prevents refetching' "$main"
grep -Fq 'BANKMOVIE_V7_26_MOBILE_NAV_PERSONALIZATION' "$main"
! grep -Eq 'CastContext|RemoteMediaClient|MediaRoute|DlnaController|Chromecast' "$player"
! grep -Eq 'play-services-cast|androidx\.mediarouter' app/build.gradle
! grep -Eq 'OPTIONS_PROVIDER_CLASS_NAME|CHANGE_WIFI_MULTICAST_STATE' "$manifest"

python3 - <<'PY'
from pathlib import Path
import xml.etree.ElementTree as ET
for name in ('ic_logout.xml','ic_weekly_schedule.xml','ic_comment_like.xml','ic_comment_dislike.xml','ic_comment_reply.xml','ic_comment_pin.xml','ic_comment_delete.xml'):
    ET.parse(Path('app/src/main/res/drawable')/name)
print('V731_XML_OK')
PY

echo V731_ORBITAL_DRAWER_COMMENTS_WEEKLY_TELEGRAM_OK
