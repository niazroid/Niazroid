# BankMovie 2.3 — V7.28

این نسخه روی V7.27 ساخته شده و تغییرات زیر را اضافه می‌کند:

- ظاهر Social Comments نسخه V7.27 برای TV هم فعال شده و بعد از هر بار render، focus tree تلویزیون دوباره سیم‌کشی می‌شود.
- Composer اصلی قبل از ارسال دیدگاه گزینه Spoiler دارد و مقدار واقعی spoiler را به API می‌فرستد.
- تیک Admin در کامنت دیگر tint آبی نمی‌گیرد و همان drawable سبز پروفایل استفاده می‌شود.
- در Reply فقط یک گزینه Sticker نمایش داده می‌شود؛ مسیر رسانه همان picker مشترک قبلی است.
- TriRingLoaderView بومی Android بر اساس loader سه حلقه قرمز/زرد/سبز اضافه شده و در Splash، loaderهای عمومی و Comment loading استفاده می‌شود.
- دکمه‌های Load more که از moreButton مشترک استفاده می‌کنند به loader متحرک تبدیل شده‌اند؛ action و focus قبلی حفظ شده است.
- کارت Telegram Home با گرادیان آبی، لوگوی دایره‌ای، متن دو خط و chevron بازطراحی شده است.
- Download Choice modal هم‌خانواده Player Chooser شده و روی موبایل از پایین صفحه نمایش داده می‌شود.
- Player Chooser و Download Choice با handle وسط قابل drag هستند: بالا = expanded، پایین = collapsed، کشیدن بیشتر به پایین = dismiss.
- Weekly Schedule موبایل با header تقویم، day pills و ردیف‌های پوستر/عنوان/قسمت/سال بازطراحی شده است. مسیر Weekly تلویزیون و focus registration قبلی دست‌نخورده مانده است.
- فیکس V7.25 مربوط به نگه داشتن فریم Player، V7.24 Search Scroll، V7.26 Mobile Navigation و عکس واقعی Collections حفظ شده‌اند.
