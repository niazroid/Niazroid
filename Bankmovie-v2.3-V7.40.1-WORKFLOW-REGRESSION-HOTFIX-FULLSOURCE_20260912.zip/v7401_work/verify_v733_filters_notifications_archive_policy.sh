#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
down='app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt'
admin='server-required/bm_admin.php'
config='server-required/app_config.php'
api='server-required/app_api.php'
api4='server-required/api4.php'
policy='server-required/includes/app_archive_policy.php'

# Version/source marker.
grep -Fq 'sourceMainUpdateFourteenthHotfixTag=BANKMOVIE-2.3-V733-20260911' BANKMOVIE_BUILD_SOURCE_2_3.txt

# Country/genre choice sheets: all rows remain in a scrollable bottom sheet.
grep -Fq 'val choicesScroll = BankmovieSmoothScrollView(this)' "$main"
grep -Fq 'isVerticalScrollBarEnabled = true' "$main"
grep -Fq 'choicesScroll.smoothScrollTo' "$main"

# Notification center: full message body, mobile action spacing and per-type accent.
grep -Fq 'maxLines = Int.MAX_VALUE' "$main"
if grep -Fq 'val notificationAccent = when' "$main"; then
  : # V7.33 legacy per-type accent implementation.
elif grep -Fq 'val notificationAccent = notificationPalette.primary' "$main"; then
  : # V7.40+ user-palette accent implementation.
else
  echo 'Notification accent implementation is missing' >&2
  exit 1
fi
grep -Fq 'notificationActions.addView(readAll' "$main"
grep -Fq 'notificationActions.addView(clearAll' "$main"

# Downloader main page cleanup + moved settings.
grep -Fq 'private fun compactDownloadMeta' "$down"
! grep -Fq 'private fun downloadHelpCard' "$down"
! grep -Fq 'content.addView(downloadHelpCard()' "$down"
! grep -Fq 'content.addView(downloadScheduleCard()' "$down"
grep -Fq 'val scheduleCard = sectionCard()' "$down"
grep -Fq 'text = "مسیر ذخیره‌سازی"' "$down"
grep -Fq 'content.addView(bulkImportCard()' "$down"

# All four archive policies are independently managed by BM Admin.
grep -Fq "'app_archive_policy'=>[" "$admin"
grep -Fq "'archive4'=>['enabled'" "$admin"
grep -Fq 'کنترل مستقل' "$admin"
grep -Fq 'bm-switch-row' "$admin"
grep -Fq 'home_archive4_' "$admin"
! grep -Fq 'archive_api_settings.json' "$admin"

# Empty Home section selection is intentional and must survive recursive config merge.
grep -Fq "array_key_exists(\$key, \$saved['home'])" "$config"
grep -Fq "array_key_exists(\$key, \$saved['home'])" "$admin"
grep -Fq 'remoteHomeSectionsConfigured[selectedArchive] == true' "$main"

# Android archive policy is separated from website archive policy.
grep -Fq 'bm_app_archive_apply_payload_policy' "$api"
grep -Fq 'bm_app_policy_current_user' "$policy"
grep -Fq 'bm_app_archive_apply_payload_policy' "$api4"
grep -Fq "if (strtolower(trim((string)(\$_GET['client'] ?? ''))) === 'app') return true;" "$api4"

# Archive 4 exact web API path is tagged as Android without corrupting its query.
grep -Fq 'private fun archive4ApiUrl(params: String = "")' "$main"
grep -Fq 'val base = "$archive4SiteApiBase${separator}client=app"' "$main"
! grep -Fq '$archive4SiteApiBase?section=' "$main"
! grep -Fq '$archive4SiteApiBase?s=' "$main"
! grep -Fq '$archive4SiteApiBase?id=' "$main"
grep -Fq 'val directAppClient = u.query.orEmpty()' "$main"
grep -Fq 'X-BM-User-Token' "$main"
grep -Fq 'remoteArchiveAccessScopes' "$main"
grep -Fq 'archiveAccessAllowedClient' "$main"

# Schema and PHP syntax.
grep -Fq "'schema_version' => 7" "$config"
grep -Fq "'schema_version' => 7" "$admin"
test -s "$policy"
php -l "$admin" >/dev/null
php -l "$config" >/dev/null
php -l "$api" >/dev/null
php -l "$api4" >/dev/null
php -l "$policy" >/dev/null

echo V733_VERIFY_OK
