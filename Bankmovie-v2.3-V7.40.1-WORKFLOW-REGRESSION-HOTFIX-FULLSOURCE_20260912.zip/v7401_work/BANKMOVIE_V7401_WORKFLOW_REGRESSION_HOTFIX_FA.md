BANKMOVIE V7.40.1 — WORKFLOW REGRESSION HOTFIX
==============================================

مشکل:
Workflow بعد از پاس شدن verifierهای V7.40، V7.39 و V7.36 روی verifier قدیمی V7.33 با exit code 1 متوقف می‌شد.

علت:
V7.33 دقیقاً دنبال عبارت قدیمی `val notificationAccent = when` می‌گشت، در حالی که V7.40 عمداً سیستم رنگ اعلان را به `val notificationAccent = notificationPalette.primary` تغییر داده بود تا رنگ اعلان از تم کاربر گرفته شود.

رفع:
- verifier V7.33 backward-compatible شد و هر دو implementation معتبر را قبول می‌کند.
- verifier جدید V7.40.1 اضافه شد.
- هیچ قابلیت یا UI اپ rollback نشده است.
- Workflow جدید قبل از build همه regression verifierها را دوباره اجرا می‌کند.
