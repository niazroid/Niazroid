#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
source='BANKMOVIE_BUILD_SOURCE_2_3.txt'

grep -Fq 'sourceMainUpdateEighteenthHotfixTag=BANKMOVIE-2.3-V737-20260912' "$source"
grep -Fq 'Triple(R.drawable.ic_telegram, t("خرید در تلگرام"' "$main"
grep -Fq 'Triple(R.drawable.ic_watch_party, t("Watch Party"' "$main"
grep -Fq 'addProfileContinueSection(page)' "$main"
grep -Fq 'addLocalRail(page, t("آخرین بازدیدها"' "$main"
grep -Fq 'profileActionTile(t("دانلودهای من"' "$main"
grep -Fq 'profileActionTile(t("تماشای دونفره"' "$main"
grep -Fq 'profileActionTile(t("مدیریت اشتراک"' "$main"
grep -Fq 'page.addView(telegramProCard()' "$main"
grep -Fq 'bottomNav.visibility = View.GONE' "$main"
grep -Fq 'section.addView(posterFrame, LinearLayout.LayoutParams(dp(200), dp(300))' "$main"
grep -Fq 'metricRow(t("فروش آخر هفته:"' "$main"
grep -Fq 'metricRow(t("فروش کل:"' "$main"
# The V7.36 fake profile rows must not exist inside the V7.37 mobile profile function.
profile_block="$(sed -n '/private fun showProfileMobileV736()/,/private fun showProfile()/p' "$main")"
if grep -Fq 't("امنیت حساب"' <<<"$profile_block"; then
  echo 'fake account security row still exists in mobile profile' >&2
  exit 1
fi
if grep -Fq 't("اطلاعات حساب"' <<<"$profile_block"; then
  echo 'fake account information row still exists in mobile profile' >&2
  exit 1
fi
if grep -Fq 'val email =' <<<"$profile_block"; then
  echo 'email is still rendered in mobile profile' >&2
  exit 1
fi
vip_block="$(sed -n '/private fun showVipPlansMobileV736()/,/private fun showVipPlansDialog(/p' "$main")"
if grep -Fq 'دانلود با سرعت بالا' <<<"$vip_block"; then
  echo 'old VIP speed-download benefit still exists' >&2
  exit 1
fi
if grep -Fq 'text = t("♛  VIP"' <<<"$vip_block"; then
  echo 'top VIP badge still exists' >&2
  exit 1
fi

echo V737_PROFILE_VIP_BOXOFFICE_VERIFY_OK
