# BankMovie 2.3 — V7.28.1

این نسخه فقط hotfix کامپایل V7.28 است.

- در callback دریافت دیدگاه‌ها، `result.json` از نوع nullable بود و Kotlin اجازه فراخوانی مستقیم `optInt/optDouble/optJSONArray` را نمی‌داد.
- payload یک‌بار در متغیر محلی `commentsPayload` ذخیره می‌شود، null-check می‌شود و سپس تمام خواندن‌ها از همان reference non-null انجام می‌شوند.
- هیچ رفتار UI، Loader، Weekly Schedule، Draggable Sheet، Player، TV Focus یا Comments design نسبت به V7.28 تغییر نکرده است.
