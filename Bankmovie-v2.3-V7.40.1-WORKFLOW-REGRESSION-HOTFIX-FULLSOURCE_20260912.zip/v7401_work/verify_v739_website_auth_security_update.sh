#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
auth='app/src/main/java/ir/bankmoviee/app/AuthActivity.kt'
api='app/src/main/java/ir/bankmoviee/app/AccountApi.kt'
ui='app/src/main/java/ir/bankmoviee/app/UiPreferences.kt'
server='server-required/app_user_api.php'
source='BANKMOVIE_BUILD_SOURCE_2_3.txt'

grep -Fq 'sourceMainUpdateTwentiethHotfixTag=BANKMOVIE-2.3-V739-20260912' "$source"
grep -Fq 'ساخت حساب بانک مووی' "$auth"
grep -Fq 'ورود به بانک مووی' "$auth"
grep -Fq 'تأیید امنیتی' "$auth"
grep -Fq 'عدد ۴ رقمی تصویر را وارد کنید' "$auth"
grep -Fq 'private fun refreshSecurityChallenge()' "$auth"
grep -Fq 'AccountApi.authChallenge(this)' "$auth"
grep -Fq 'private fun validateSecurityCode()' "$auth"
grep -Fq 'challenge_token' "$api"
grep -Fq 'security_code' "$api"
grep -Fq 'private fun syncWebsiteTheme(context: Context, user: JSONObject)' "$api"
grep -Fq '"dark-orange" -> "orange"' "$api"
grep -Fq '"pink" -> Color.rgb(236, 72, 153)' "$ui"
grep -Fq 'function bm_user_api_auth_challenge(): array' "$server"
grep -Fq 'function bm_user_api_validate_auth_challenge(): void' "$server"
grep -Fq "if (\$action === 'auth_challenge')" "$server"
grep -Fq 'bm_user_api_validate_auth_challenge();' "$server"
grep -Fq 't("آپدیت الزامی", "Update required")' "$main"
grep -Fq 't("↻  آپدیت کردم، دوباره بررسی کن", "↻  I updated, check again")' "$main"
grep -Fq 'val accent = p.primary' "$main"
php -l "$server" >/dev/null

echo V739_WEBSITE_AUTH_SECURITY_UPDATE_VERIFY_OK
