#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
source='BANKMOVIE_BUILD_SOURCE_2_3.txt'

grep -Fq 'sourceMainUpdateNineteenthHotfixTag=BANKMOVIE-2.3-V738-20260912' "$source"
grep -Fq 't("خرید همین پلن در تلگرام", "Buy this plan on Telegram")' "$main"
grep -Fq 'Triple(R.drawable.ic_archive_database, t("آرشیوهای بیشتر"' "$main"
grep -Fq 'Triple(R.drawable.ic_watch_party, t("Watch Party"' "$main"
grep -Fq 'Triple(R.drawable.ic_close_clean, t("بدون تبلیغات"' "$main"
grep -Fq 'fun heroAuthButton(label: String, primary: Boolean, register: Boolean)' "$main"
grep -Fq 'heroAuthButton(t("ورود به حساب", "Sign in")' "$main"
grep -Fq 'heroAuthButton(t("ثبت‌نام", "Register")' "$main"
grep -Fq 'topMargin = dp(10); bottomMargin = dp(14)' "$main"
grep -Fq 'text = if (compact) t("${dayLabel} روز باقی‌مانده"' "$main" || grep -Fq 'if (compact) t("${dayLabel} روز باقی‌مانده"' "$main"
grep -Fq 'setImageResource(R.drawable.ic_chevron_right)' "$main"
grep -Fq 'LinearLayout.LayoutParams(dp(42), dp(42))' "$main"

vip_block="$(awk '/private fun showVipPlansMobileV736/{f=1} f{print} /private fun showVipPlansDialog/{exit}' "$main")"
if grep -Fq 'کیفیت‌های بالاتر' <<<"$vip_block"; then
  echo 'unwanted higher quality VIP benefit still exists' >&2
  exit 1
fi
if grep -Fq 'خرید در تلگرام", "Buy on Telegram"' <<<"$vip_block"; then
  echo 'telegram purchase still appears as a benefit card instead of CTA only' >&2
  exit 1
fi
feature_count="$(grep -c 'Triple(R.drawable' <<<"$vip_block" || true)"
if [[ "$feature_count" -ne 3 ]]; then
  echo "expected exactly 3 VIP benefit cards, got $feature_count" >&2
  exit 1
fi

echo V738_PROFILE_VIP_BOXOFFICE_MICRO_POLISH_VERIFY_OK
