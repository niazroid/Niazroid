#!/usr/bin/env bash
set -euo pipefail

main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
downloads='app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt'
service='app/src/main/java/ir/bankmoviee/app/InternalDownloadService.kt'
prefs='app/src/main/java/ir/bankmoviee/app/DownloadPreferences.kt'
loader='app/src/main/java/ir/bankmoviee/app/OrbitalGlowLoaderView.kt'

for f in "$main" "$player" "$downloads" "$service" "$prefs" "$loader"; do
  test -s "$f"
done

grep -Fq 'sourceMainUpdateThirteenthHotfixTag=BANKMOVIE-2.3-V732-20260911' BANKMOVIE_BUILD_SOURCE_2_3.txt

# Exact supplied Uiverse worm loader: 128 viewBox geometry, 3s animations,
# supplied cubic-bezier and supplied dash/path values.
grep -Fq 'duration = 3000L' "$loader"
grep -Fq 'PathInterpolator(0.42f, 0.17f, 0.75f, 0.83f)' "$loader"
grep -Fq 'DashPathEffect(floatArrayOf(44f, 1111f), dashOffset)' "$loader"
grep -Fq 'lerp(10f, 295f, local)' "$loader"
grep -Fq 'lerp(295f, 1165f, local)' "$loader"
grep -Fq 'M92,15.492S78.194,4.967,66.743,16.887' "$loader"
grep -Fq 'Color.rgb(37, 199, 244)' "$loader"
grep -Fq 'Color.rgb(37, 95, 244)' "$loader"
grep -Fq 'LinearLayout.LayoutParams(dp(128), dp(128))' "$main"

# Main + player + downloader sheets use the bottom-sheet drag affordance.
grep -Fq 'private fun ensureV732MobileSheetHandle' "$main"
grep -Fq 'wireV728DraggableBottomSheet(dialog, body, mobileDragHandle)' "$main"
grep -Fq 'private fun ensurePlayerModalDragHandle' "$player"
grep -Fq 'wirePlayerModalDrag(dialog, mobileDragHandle)' "$player"
grep -Fq 'private fun showDownloadsSheetDialog' "$downloads"
grep -Fq 'private fun wireDownloadsSheetDrag' "$downloads"

# Downloader settings from the supplied reference are present and functional.
grep -Fq 'text = "تنظیمات دانلود"' "$downloads"
grep -Fq 'text = "حالت دانلود"' "$downloads"
grep -Fq 'text = "تعداد کانکشن برای هر فایل"' "$downloads"
grep -Fq 'text = "اعلان اتمام دانلود"' "$downloads"
grep -Fq 'text = "مسیر ذخیره‌سازی"' "$downloads"
grep -Fq 'text = "▣  ذخیره تنظیمات"' "$downloads"
grep -Fq 'MODE_SIMULTANEOUS' "$prefs"
grep -Fq 'MODE_SEQUENTIAL' "$prefs"
grep -Fq 'coerceIn(1, 8)' "$prefs"
grep -Fq 'DownloadPreferences.mode(this) == DownloadPreferences.MODE_SEQUENTIAL' "$service"
grep -Fq 'DownloadPreferences.connectionsPerFile(this).coerceIn(1, 8)' "$service"
grep -Fq 'DownloadPreferences.completionNotificationEnabled(this)' "$service"

bash verify_v731_orbital_drawer_comments_weekly_telegram.sh
bash verify_release.sh

echo V732_UIVERSE_DOWNLOADER_SETTINGS_OK
