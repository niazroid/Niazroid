# BankMovie 2.3 — V7.30

## تغییرات این نسخه

- آیکن‌های بخش دیدگاه‌ها با SVGهای ارسالی کاربر جایگزین شدند:
  - Like
  - Dislike
  - Reply
  - Pin
  - Delete
- آیکن‌های Like/Dislike در هر دو UI موبایل و TV از drawableهای جدید استفاده می‌کنند.
- Reply از SVG جدید استفاده می‌کند.
- در اکشن‌های مدیریتی TV، Pin و Delete نیز آیکن اختصاصی جدید دارند.
- در منوی سه‌نقطه موبایل برای Pin/Delete نیز drawable جدید به MenuItem متصل شده است.
- رنگ‌بندی Weekly Schedule موبایل از رنگ‌های ثابت آبی جدا شد و به `UiPreferences.palette()` متصل شد:
  - پس‌زمینه: `panel`
  - کارت‌ها: `card`
  - حاشیه‌ها: `stroke`
  - متن‌ها: `text/muted`
  - حالت فعال روز: `primary/primary2/onPrimary`
- چیدمان دو ستونه Weekly از V7.29 دست نخورده است.
- لودینگ Speeder، pagination سریع، Telegram fix، Player و TV focus دست نخورده‌اند.

## محدودیت تست

در محیط فعلی Android SDK/Gradle کامل اجرا نمی‌شود؛ Workflow همراه سورس، Kotlin/Android build واقعی را در GitHub Actions انجام می‌دهد.
