package ir.bankmoviee.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min

/**
 * Native Android recreation of the supplied three-ring Uiverse loader.
 * No WebView/CSS: three nested top/left arc strokes rotate as a single unit.
 */
class TriRingLoaderView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private var angle = 0f
    private var animator: ValueAnimator? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!isInEditMode) start()
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    private fun start() {
        if (animator?.isRunning == true) return
        animator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 1500L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                angle = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val size = min(width, height).toFloat()
        if (size <= 0f) return
        val cx = width / 2f
        val cy = height / 2f
        canvas.save()
        canvas.rotate(angle, cx, cy)
        drawRing(canvas, cx, cy, size * 0.39f, Color.rgb(244, 67, 54), size * 0.055f)
        drawRing(canvas, cx, cy, size * 0.29f, Color.rgb(255, 193, 7), size * 0.052f)
        drawRing(canvas, cx, cy, size * 0.19f, Color.rgb(139, 195, 74), size * 0.050f)
        canvas.restore()
    }

    private fun drawRing(canvas: Canvas, cx: Float, cy: Float, radius: Float, color: Int, stroke: Float) {
        paint.color = color
        paint.strokeWidth = stroke.coerceAtLeast(2f * density)
        // Top + left border feel from the CSS reference, with the open side kept visible.
        val rect = RectF(cx - radius, cy - radius, cx + radius, cy + radius)
        canvas.drawArc(rect, 178f, 188f, false, paint)
    }
}
