package ir.bankmoviee.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.animation.LinearInterpolator
import android.widget.TextView
import kotlin.math.min

/**
 * Keeps the existing TextView API used by the pagination code, while rendering
 * the V7.28 three-ring loader instead of a literal "load more / loading" label.
 */
class LoadMoreLoaderButtonView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : TextView(context, attrs) {
    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private var angle = 0f
    private var animator: ValueAnimator? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!isInEditMode && animator?.isRunning != true) {
            animator = ValueAnimator.ofFloat(0f, 360f).apply {
                duration = 1500L
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener { angle = it.animatedValue as Float; invalidate() }
                start()
            }
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel(); animator = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        // Background is drawn by View.draw() before onDraw. Intentionally skip
        // TextView's text glyphs and render the compact loader as the action face.
        val size = min(width, height).toFloat().coerceAtMost(46f * density)
        if (size <= 0f) return
        val cx = width / 2f
        val cy = height / 2f
        canvas.save()
        canvas.rotate(angle, cx, cy)
        ring(canvas, cx, cy, size * .40f, Color.rgb(244,67,54), size*.065f)
        ring(canvas, cx, cy, size * .29f, Color.rgb(255,193,7), size*.060f)
        ring(canvas, cx, cy, size * .18f, Color.rgb(139,195,74), size*.058f)
        canvas.restore()
    }

    private fun ring(canvas: Canvas, cx: Float, cy: Float, r: Float, color: Int, stroke: Float) {
        paint.color = color
        paint.strokeWidth = stroke.coerceAtLeast(1.7f * density)
        canvas.drawArc(RectF(cx-r, cy-r, cx+r, cy+r), 178f, 188f, false, paint)
    }
}
