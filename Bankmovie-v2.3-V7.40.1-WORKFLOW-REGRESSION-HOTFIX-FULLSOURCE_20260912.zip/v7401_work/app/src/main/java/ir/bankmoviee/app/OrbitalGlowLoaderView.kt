package ir.bankmoviee.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import android.view.animation.PathInterpolator
import androidx.core.graphics.PathParser
import kotlin.math.min

/**
 * Native Android rendering of the exact Uiverse loader supplied by the project owner.
 *
 * Source geometry/animation kept 1:1 with:
 * - viewBox 0 0 128 128
 * - ring r=56, cx/cy=64, stroke-width=16
 * - worm path data, dasharray 44 1111, dashoffset 10
 * - 3s bump9 linear + worm9 cubic-bezier(0.42,0.17,0.75,0.83), infinite
 */
class OrbitalGlowLoaderView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.argb(26, 28, 23, 23) // hsla(0,10%,10%,0.1)
    }
    private val wormPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val wormPath: Path = PathParser.createPathFromPathData(
        "M92,15.492S78.194,4.967,66.743,16.887c-17.231,17.938-28.26,96.974-28.26,96.974L119.85,59.892l-99-31.588,57.528,89.832L97.8,19.349,13.636,88.51l89.012,16.015S81.908,38.332,66.1,22.337C50.114,6.156,36,15.492,36,15.492a56,56,0,1,0,56,0Z"
    ) ?: Path()

    private val wormBounds = RectF().also { wormPath.computeBounds(it, true) }
    private val wormInterpolator = PathInterpolator(0.42f, 0.17f, 0.75f, 0.83f)
    private var animationProgress = 0f
    private var animator: ValueAnimator? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!isInEditMode && animator?.isRunning != true) {
            animator = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 3000L
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener {
                    animationProgress = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val scale = min(width, height).toFloat() / 128f
        if (scale <= 0f) return
        val offsetX = (width - 128f * scale) / 2f
        val offsetY = (height - 128f * scale) / 2f
        val (bumpX, bumpY) = bumpTransform(animationProgress)

        canvas.save()
        canvas.translate(offsetX + bumpX * 128f * scale, offsetY + bumpY * 128f * scale)
        canvas.scale(scale, scale)

        ringPaint.strokeWidth = 16f
        canvas.drawCircle(64f, 64f, 56f, ringPaint)

        wormPaint.strokeWidth = 16f
        wormPaint.shader = LinearGradient(
            0f,
            wormBounds.top,
            0f,
            wormBounds.bottom,
            intArrayOf(
                Color.rgb(37, 199, 244), // hsl(193,90%,55%)
                Color.rgb(37, 95, 244)   // hsl(223,90%,55%)
            ),
            floatArrayOf(0f, 1f),
            Shader.TileMode.CLAMP
        )
        val dashOffset = wormDashOffset(animationProgress)
        wormPaint.pathEffect = DashPathEffect(floatArrayOf(44f, 1111f), dashOffset)
        canvas.drawPath(wormPath, wormPaint)
        wormPaint.pathEffect = null
        wormPaint.shader = null

        canvas.restore()
    }

    /** CSS bump9 keyframes. Translation percentages are relative to the SVG element itself. */
    private fun bumpTransform(progress: Float): Pair<Float, Float> {
        val percent = progress.coerceIn(0f, 1f) * 100f
        val frames = BUMP_FRAMES
        if (percent <= frames.first().p) return frames.first().x to frames.first().y
        if (percent >= frames.last().p) return frames.last().x to frames.last().y
        for (i in 0 until frames.lastIndex) {
            val a = frames[i]
            val b = frames[i + 1]
            if (percent in a.p..b.p) {
                val span = (b.p - a.p).coerceAtLeast(0.0001f)
                val t = (percent - a.p) / span
                return (a.x + (b.x - a.x) * t) to (a.y + (b.y - a.y) * t)
            }
        }
        return 0f to 0f
    }

    /** CSS worm9 keyframes with cubic-bezier timing on each keyframe interval. */
    private fun wormDashOffset(progress: Float): Float {
        val p = progress.coerceIn(0f, 1f)
        return if (p <= 0.25f) {
            val local = wormInterpolator.getInterpolation(p / 0.25f)
            lerp(10f, 295f, local)
        } else {
            val local = wormInterpolator.getInterpolation((p - 0.25f) / 0.75f)
            lerp(295f, 1165f, local)
        }
    }

    private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

    private data class BumpFrame(val p: Float, val x: Float, val y: Float)

    companion object {
        // Values are percentages converted to fractions (e.g. 1.33% -> 0.0133).
        private val BUMP_FRAMES = listOf(
            BumpFrame(0f, 0f, 0f),
            BumpFrame(42f, 0f, 0f),
            BumpFrame(44f, 0.0133f, 0.0675f),
            BumpFrame(46f, 0f, 0f),
            BumpFrame(51f, 0f, 0f),
            BumpFrame(53f, -0.1667f, -0.0054f),
            BumpFrame(55f, 0f, 0f),
            BumpFrame(59f, 0f, 0f),
            BumpFrame(61f, 0.0366f, -0.0246f),
            BumpFrame(63f, 0f, 0f),
            BumpFrame(67f, 0f, 0f),
            BumpFrame(69f, -0.0059f, 0.1527f),
            BumpFrame(71f, 0f, 0f),
            BumpFrame(74f, 0f, 0f),
            BumpFrame(76f, -0.0192f, -0.0468f),
            BumpFrame(78f, 0f, 0f),
            BumpFrame(81f, 0f, 0f),
            BumpFrame(83f, 0.0938f, 0.0096f),
            BumpFrame(85f, 0f, 0f),
            BumpFrame(88f, 0f, 0f),
            BumpFrame(90f, -0.0455f, 0.0198f),
            BumpFrame(92f, 0f, 0f),
            BumpFrame(100f, 0f, 0f)
        )
    }
}
