package ir.bankmoviee.app

import android.content.Context

/** User-facing downloader preferences. Server feature flags still remain authoritative. */
object DownloadPreferences {
    private const val PREFS = "bankmovie_download_user_settings"
    private const val KEY_MODE = "mode"
    private const val KEY_CONNECTIONS = "connections_per_file"
    private const val KEY_COMPLETION_NOTIFICATION = "completion_notification"

    const val MODE_SIMULTANEOUS = "simultaneous"
    const val MODE_SEQUENTIAL = "sequential"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun mode(context: Context): String = prefs(context).getString(KEY_MODE, MODE_SIMULTANEOUS)
        ?.takeIf { it == MODE_SIMULTANEOUS || it == MODE_SEQUENTIAL }
        ?: MODE_SIMULTANEOUS

    fun connectionsPerFile(context: Context): Int = prefs(context).getInt(KEY_CONNECTIONS, 1).coerceIn(1, 8)

    fun completionNotificationEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_COMPLETION_NOTIFICATION, true)

    fun save(context: Context, mode: String, connections: Int, completionNotification: Boolean) {
        prefs(context).edit()
            .putString(KEY_MODE, if (mode == MODE_SEQUENTIAL) MODE_SEQUENTIAL else MODE_SIMULTANEOUS)
            .putInt(KEY_CONNECTIONS, connections.coerceIn(1, 8))
            .putBoolean(KEY_COMPLETION_NOTIFICATION, completionNotification)
            .apply()
    }
}
