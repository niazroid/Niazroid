BANKMOVIE V7.39 — WEBSITE STYLE AUTH + SECURITY CHALLENGE + UPDATE DIALOG
=======================================================================

این نسخه روی V7.38 ساخته شده و فقط مسیرهای ورود/ثبت‌نام، تأیید امنیتی، همگام‌سازی رنگ کاربر و مودال آپدیت را تغییر می‌دهد.

1) ورود و ثبت‌نام نزدیک به ظاهر سایت
- همان بک‌گراند سینمایی لاگین استفاده می‌شود.
- کارت اصلی تیره با Border رنگ انتخابی کاربر ساخته شده.
- تیترهای «ورود به بانک مووی» و «ساخت حساب بانک مووی» با Accent کاربر نمایش داده می‌شوند.
- فیلدها مثل سایت Underline هستند و آیکن در سمت راست دارند.
- نمایش/مخفی‌کردن رمز عبور حفظ شده.
- لینک جابه‌جایی ورود / ثبت‌نام و «بازگشت به بانک مووی» حفظ شده.
- لینک بازیابی رمز برای فرم ورود اضافه شده.

2) تأیید امنیتی واقعی برای کلاینت جدید
- endpoint جدید auth_challenge در app_user_api.php اضافه شده.
- سرور یک کد چهار رقمی با Challenge Token امضاشده HMAC می‌دهد.
- Android کد را نشان می‌دهد و کاربر باید همان 4 رقم را وارد کند.
- login/register جدید token + security_code را به سرور می‌فرستند.
- پاسخ غلط یا منقضی Challenge جدید می‌گیرد.
- برای نسخه‌های قدیمی Android compatibility نگه داشته شده تا بعد از آپلود پچ هاست لاگین نسخه‌های قبلی ناگهان از کار نیفتد.

3) رنگ ظاهر بر اساس تنظیم کاربر
- Auth و Update dialog مستقیماً از UiPreferences.palette().primary استفاده می‌کنند.
- بعد از login/register/refresh، theme سایت کاربر به Accent اپ sync می‌شود.
- مقادیر Orange/Red/Purple/Pink/Cyan/White/Gray با catalog سایت هماهنگ شده‌اند.

4) مودال Update جدید
- ظاهر نزدیک به رفرنس Update Required شده: کارت مشکی جمع‌وجور، آیکن Accent، نسخه نصب‌شده/جدید، لیست What is new با تیک‌ها، CTA بزرگ و لینک بررسی دوباره.
- رنگ CTA، Border، icon و checkها براساس Accent کاربر است.
- Force Update همچنان dismiss عادی ندارد.

فایل‌های اصلی:
- app/src/main/java/ir/bankmoviee/app/AuthActivity.kt
- app/src/main/java/ir/bankmoviee/app/AccountApi.kt
- app/src/main/java/ir/bankmoviee/app/UiPreferences.kt
- app/src/main/java/ir/bankmoviee/app/MainActivity.kt
- server-required/app_user_api.php
