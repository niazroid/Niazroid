#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
auth='app/src/main/java/ir/bankmoviee/app/AuthActivity.kt'
source='BANKMOVIE_BUILD_SOURCE_2_3.txt'
draw='app/src/main/res/drawable'

grep -Fq 'sourceMainUpdateTwentyFirstHotfixTag=BANKMOVIE-2.3-V740-20260912' "$source"
test -s "$draw/ic_auth_refresh.xml"
grep -Fq 'R.drawable.ic_auth_refresh' "$auth"
! grep -Fq 'text = "↻"' "$auth"
grep -Fq 't("ثبت‌نام / ورود", "Register / Sign in")' "$main"
grep -Fq 'text = "قسمت بعدی آماده است"' "$player"
grep -Fq 'text = "▶  بله، پخش کن"' "$player"
grep -Fq 'UiPreferences.palette(this@PlayerActivity).onPrimary' "$player"
! grep -Fq '.setTitle("قسمت بعدی آماده است")' "$player"
grep -Fq 'val notificationAccent = notificationPalette.primary' "$main"
grep -Fq 'text = t("جدید", "NEW")' "$main"
grep -Fq 'if (::bottomNav.isInitialized) bottomNav.visibility = View.GONE' "$main"
grep -Fq 'showConfirmSheetV731(' "$main"

echo V740_PLAYER_AUTH_NOTIFICATION_POLISH_VERIFY_OK
