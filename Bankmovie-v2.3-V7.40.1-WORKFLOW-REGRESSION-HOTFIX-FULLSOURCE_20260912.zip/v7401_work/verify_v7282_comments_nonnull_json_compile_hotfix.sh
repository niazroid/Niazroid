#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'

# Preserve the whole V7.28 feature set.
bash verify_v728_social_tv_loader_sheets_weekly.sh

# Both comment loaders must turn ApiResult.json into an explicitly non-null JSONObject.
grep -Fq 'val mobileCommentsPayload: JSONObject = result.json ?: run {' "$MAIN"
grep -Fq 'val commentsPayload: JSONObject = result.json ?: run {' "$MAIN"
grep -Fq 'knownTotal = mobileCommentsPayload.optInt("total")' "$MAIN"
grep -Fq 'val items = mobileCommentsPayload.optJSONArray("items") ?: JSONArray()' "$MAIN"
grep -Fq 'val total = commentsPayload.optInt("total")' "$MAIN"
grep -Fq 'val avg = commentsPayload.optDouble("rating_avg", 0.0)' "$MAIN"
grep -Fq 'val items = commentsPayload.optJSONArray("items") ?: JSONArray()' "$MAIN"

# Reject the two nullable-smart-cast shapes that failed on GitHub.
! grep -Fq 'if (!result.success || commentsPayload == null)' "$MAIN"
! grep -Fq 'if (!result.success || mobileCommentsPayload == null)' "$MAIN"
! grep -Fq 'val commentsPayload = result.json' "$MAIN"
! grep -Fq 'val mobileCommentsPayload = result.json' "$MAIN"

grep -Fq 'sourceMainUpdateNinthHotfixCompileSecondTag=BANKMOVIE-2.3-V7282-20260911' BANKMOVIE_BUILD_SOURCE_2_3.txt

echo V7282_COMMENTS_NONNULL_JSON_COMPILE_HOTFIX_OK
