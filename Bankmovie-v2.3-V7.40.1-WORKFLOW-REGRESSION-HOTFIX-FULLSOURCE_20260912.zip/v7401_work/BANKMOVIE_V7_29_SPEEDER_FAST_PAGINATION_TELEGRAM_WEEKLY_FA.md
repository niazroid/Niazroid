# BankMovie V7.29 — Speeder splash + fast pagination + Telegram + weekly compact

این نسخه روی V7.28.2 ساخته شده و فقط چهار ناحیه را تغییر می‌دهد:

- لودینگ ورودی اصلی با بازسازی Native Android از Speeder/Uiverse جایگزین شد. طراحی بدنه و خطوط سرعت با Canvas/ValueAnimator است و WebView/CSS اضافه نشده است.
- دکمه‌های «مشاهده بیشتر / Load more» به TextView سریع و قابل‌فهم نسخه V7.27 برگشتند. Spinner دائمی روی خود دکمه حذف شد؛ منطق pagination و endpointها تغییر نکردند.
- لوگوی کارت Telegram از drawable گرد رسمی داخلی (`ic_telegram`) استفاده می‌کند تا نسبت تصویر خراب/کشیده نشود.
- Weekly Schedule موبایل دوباره دو ستونه و compact است. Weekly تلویزیون و routing فوکس آن دست نخورده است.

فیکس‌های V7.28.2 شامل non-null JSON کامنت، Social comments، Spoiler، draggable sheets، Player frame bridge، Search state و TV focus حفظ شده‌اند.
