BANKMOVIE V7.36 — HOME TOGGLE HARD FIX + PER-ARCHIVE PLAYER GATES + PROFILE/VIP/BOXOFFICE REDESIGN
====================================================================================================

1) رفع نهایی باگ برگشتن بخش‌های خاموش صفحه اصلی
- home_section_policy دیگر فقط scope متنی نیست.
- هر بخش حالا هم enabled واقعی دارد و هم access_scope مستقل.
- app_config.php برای تمام بخش‌های آرشیوهای 1 تا 4 یک policy کامل {enabled, access_scope} برمی‌گرداند.
- Android این policy را منبع اصلی نمایش ریل‌ها می‌داند؛ بنابراین اگر Animation آرشیو 4 خاموش شود، بعد از بستن/بازکردن برنامه دوباره ظاهر نمی‌شود.
- cache key و revision key به V7.36 ارتقا داده شدند تا state قدیمی V7.35 دوباره بخش خاموش را برنگرداند.
- config_revision با میلی‌ثانیه ذخیره می‌شود تا حتی چند ذخیره پشت‌سرهم در یک ثانیه هم قابل تشخیص باشند.

2) قفل‌های مستقل برای هر آرشیو
برای Archive 1 / 2 / 3 / 4 به صورت جداگانه:
- دسترسی خود آرشیو
- دانلود
- پخش آنلاین
- Watch Party
- پلیر داخلی BankMovie
- پلیرهای خارجی (VLC / MX / Other)
- قفل کلی همه پلیرها

هر مورد یکی از این scopeها را می‌گیرد:
public / member / vip / admin / disabled

Global scope قبلی فقط fallback است؛ policy خود آرشیو اولویت بالاتر دارد.

3) پروفایل موبایل بازطراحی شد
- هدر سینمایی و شیشه‌ای
- آواتار با حلقه Cyan و دکمه ویرایش
- نام، ایمیل، Verified badge و وضعیت VIP
- مدیریت/تمدید اشتراک
- کارت آمار دانلودها، علاقه‌مندی‌ها و بازدیدها
- Continue Watching افقی با progress واقعی
- اطلاعات حساب، امنیت حساب و اعلان‌ها
- Bottom Navigation قبلی حفظ شده و پروفایل active می‌شود.

4) صفحه VIP موبایل بازطراحی شد
- ظاهر سینمایی Dark Navy + Gold
- تاج VIP، badge، توضیح و چهار مزیت اصلی
- کارت‌های پلن با انتخاب واقعی
- پلن انتخاب‌شده Gold outline دارد
- CTA خرید پلن و ورود/ثبت‌نام
- داده پلن‌ها همچنان مستقیم از VIP config سایت خوانده می‌شود؛ قیمت hard-code نشده است.

5) Box Office موبایل بازطراحی شد
- کارت‌های رتبه‌بندی premium
- رتبه 01 با Gold highlight
- پوستر، عنوان، ژانر، هفته‌های اکران، فروش آخر هفته و فروش کل
- داده همچنان از api_boxoffice.php می‌آید.
- نسخه TV دست‌نخورده مانده تا regression روی فوکوس TV ایجاد نشود.

فایل‌های اصلی تغییرکرده:
- app/src/main/java/ir/bankmoviee/app/MainActivity.kt
- server-required/bm_admin.php
- server-required/app_config.php
- server-required/includes/app_archive_policy.php
