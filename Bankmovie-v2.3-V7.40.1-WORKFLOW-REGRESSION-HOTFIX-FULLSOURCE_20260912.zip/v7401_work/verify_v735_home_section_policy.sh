#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
ADMIN="$ROOT/server-required/bm_admin.php"
CONFIG="$ROOT/server-required/app_config.php"

grep -q 'remote_home_controls_v735' "$MAIN"
grep -q 'home_section_policy' "$MAIN"
grep -q '_bmv=' "$MAIN"
grep -q 'last_remote_config_revision_v735' "$MAIN"
grep -q 'renderHomeSectionWithPolicy' "$MAIN"
grep -q 'collectionsEnabled' "$MAIN"
grep -q '_scope" style="width:148px' "$ADMIN"
grep -Fq "'home_section_policy'=>\$homeSectionPolicy" "$ADMIN"
grep -Fq "'home_section_policy' =>" "$CONFIG"
grep -q 'config_revision' "$CONFIG"
php -l "$ADMIN" >/dev/null
php -l "$CONFIG" >/dev/null
printf 'V735_HOME_SECTION_POLICY_VERIFY_OK\n'
