#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
legacy='verify_v733_filters_notifications_archive_policy.sh'

# Exact source marker for this workflow-only hotfix.
grep -Fq 'sourceMainUpdateTwentySecondHotfixTag=BANKMOVIE-2.3-V7401-20260912' BANKMOVIE_BUILD_SOURCE_2_3.txt

# The V7.33 regression verifier must accept both its original notification
# accent implementation and the newer V7.40 user-palette implementation.
grep -Fq "val notificationAccent = notificationPalette.primary" "$main"
grep -Fq "V7.40+ user-palette accent implementation" "$legacy"
grep -Fq "Notification accent implementation is missing" "$legacy"

# Keep all current V7.40 feature checks intact.
bash verify_v740_player_auth_notification_polish.sh
bash verify_v739_website_auth_security_update.sh
bash verify_v736_home_archive_gates_profile_vip_boxoffice.sh
bash verify_v733_filters_notifications_archive_policy.sh
bash verify_v732_uiverse_downloader_settings.sh
bash verify_release.sh

echo V7401_WORKFLOW_REGRESSION_HOTFIX_VERIFY_OK
