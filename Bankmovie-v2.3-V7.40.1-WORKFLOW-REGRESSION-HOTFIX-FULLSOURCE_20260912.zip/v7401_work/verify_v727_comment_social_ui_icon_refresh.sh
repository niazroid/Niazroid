#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
PLAYER='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
RES='app/src/main/res/drawable'

bash verify_v726_mobile_nav_player_polish.sh

# New icon assets supplied by the user.
for icon in ic_player_fit.xml ic_player_lock.xml ic_player_unlock.xml ic_player_pip.xml ic_speedometer.xml ic_notifications_ui.xml ic_edit_avatar.xml; do
  test -s "$RES/$icon"
done

grep -Fq 'M1.25,4C1.25,2.48122' "$RES/ic_player_fit.xml"
grep -Fq 'M2,16C2,13.1716' "$RES/ic_player_lock.xml"
grep -Fq 'M6,10V8C6,4.68629' "$RES/ic_player_unlock.xml"
grep -Fq 'M28,4H10' "$RES/ic_player_pip.xml"
grep -Fq 'M326.1,231.9l-47.5,75.5' "$RES/ic_speedometer.xml"
grep -Fq 'M12.0196,2.91016' "$RES/ic_notifications_ui.xml"
grep -Fq 'M20.71,16.09L15.8,21H13V18.2' "$RES/ic_edit_avatar.xml"

# Keep Android's actual notification small-icon solid and separate from the UI bell.
grep -Fq 'R.drawable.ic_notifications_ui' "$MAIN"
grep -Fq '.setSmallIcon(R.drawable.ic_notifications)' app/src/main/java/ir/bankmoviee/app/AdminPushJobService.kt

# Collection category card must use the real artwork, not the nav glyph.
grep -Fq 'R.drawable.bm_category_collections){ showCollections() }' "$MAIN"
! grep -Fq '"کالکشن‌ها","COLLECTIONS","مجموعه‌های دنباله‌دار","تمام قسمت‌های هر فرنچایز و مجموعه فیلم، مرتب و یکجا.",R.drawable.ic_nav_collection' "$MAIN"
test -s app/src/main/res/drawable-nodpi/bm_category_collections.webp

# Mobile-only social comments; TV must keep legacy comments.
grep -Fq 'V7.27 — mobile comment UI rebuilt' "$MAIN"
grep -Fq 'private fun mobileInlineCommentComposerV727(' "$MAIN"
grep -Fq 'private fun mobileCommentCardV727(' "$MAIN"
grep -Fq 'private fun renderMobileCommentsSectionV727(' "$MAIN"
grep -Fq 'private fun showMobileCommentComposerV727(' "$MAIN"
grep -Fq 'if (!isTvLike()) return mobileCommentCardV727' "$MAIN"
grep -Fq 'if (!isTvLike()) {' "$MAIN"
grep -Fq 'renderMobileCommentsSectionV727(page, item)' "$MAIN"
grep -Fq 'showMobileCommentComposerV727(item, parentId, parentName, onDone)' "$MAIN"
grep -Fq 'text = "⋮"' "$MAIN"
grep -Fq 'text = "⇆  $sortLabel  ⌄"' "$MAIN"
grep -Fq 'BmToggleView(this).apply { setChecked(false, false); setOnCheckedChangeListener { spoiler = it } }' "$MAIN"

# Player behavior from V7.25/26 remains unchanged apart from drawable contents.
grep -Fq 'PLAYER_FRAME_PROBE_TIMEOUT_MS = 12_000L' "$PLAYER"
grep -Fq 'lifecycleFrameProbeReadySamples >= 2' "$PLAYER"
grep -Fq 'PLAYER_UTILITY_ICON_DP = 24' "$PLAYER"
! grep -Eq 'CastContext|RemoteMediaClient|MediaRoute|DlnaController|Chromecast' "$PLAYER"
! grep -Eq 'play-services-cast|androidx\.mediarouter' app/build.gradle

grep -Fq 'sourceMainUpdateEighthHotfixTag=BANKMOVIE-2.3-V727-20260911' BANKMOVIE_BUILD_SOURCE_2_3.txt

echo V727_COMMENT_SOCIAL_UI_ICON_REFRESH_OK
