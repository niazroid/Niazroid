BANKMOVIE V7.38 — VIP / PROFILE HERO / BOX OFFICE MICRO POLISH
==============================================================

تغییرات این پاس فقط روی Android انجام شده و تنظیمات هاست V7.36/V7.37 را تغییر نمی‌دهد.

VIP موبایل
- کارت‌های مزایا دقیقاً به سه مورد محدود شدند:
  1) آرشیوهای بیشتر
  2) Watch Party
  3) بدون تبلیغات
- کارت «خرید در تلگرام» از مزایا حذف شد.
- کارت «کیفیت‌های بالاتر» حذف شد.
- دکمه خرید اصلی به «خرید همین پلن در تلگرام» تغییر کرد و همچنان پلن انتخاب‌شده را مستقیم به تلگرام می‌فرستد.

پروفایل موبایل
- در حالت خروج از حساب، داخل Hero دو دکمه واقعی «ورود به حساب» و «ثبت‌نام» اضافه شد.
- Hero کمی پایین‌تر قرار گرفت تا به Status Bar نچسبد.
- نمایش روزهای باقی‌مانده طوری اصلاح شد که عدد قبل از «روز» باقی بماند و LTR token مثل VIP ترتیب فارسی را خراب نکند.

Box Office موبایل
- دکمه برگشت کوچک‌تر شد.
- Chevron با ImageView در مرکز واقعی دکمه قرار گرفت.
- طراحی لیست/پوستر/فروش همان طراحی V7.37 حفظ شد.

Verification
- verify_v738_profile_vip_boxoffice_micro_polish.sh
- verify_v736_home_archive_gates_profile_vip_boxoffice.sh
- verify_v733_filters_notifications_archive_policy.sh
- verify_v732_uiverse_downloader_settings.sh
- verify_release.sh
