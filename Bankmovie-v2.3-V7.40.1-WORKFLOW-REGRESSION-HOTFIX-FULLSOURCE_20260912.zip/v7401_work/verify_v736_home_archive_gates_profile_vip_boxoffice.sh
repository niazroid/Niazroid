#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
ADMIN="$ROOT/server-required/bm_admin.php"
CONFIG="$ROOT/server-required/app_config.php"
POLICY="$ROOT/server-required/includes/app_archive_policy.php"
BUILD="$ROOT/BANKMOVIE_BUILD_SOURCE_2_3.txt"

grep -Fq 'sourceMainUpdateSeventeenthHotfixTag=BANKMOVIE-2.3-V736-20260912' "$BUILD"
grep -Fq 'remote_home_controls_v736' "$MAIN"
grep -Fq 'last_remote_config_revision_v736' "$MAIN"
grep -Fq 'cached_remote_config_v5' "$MAIN"
grep -Fq 'remoteHomeSectionEnabled' "$MAIN"
grep -Fq 'homeSectionEnabled(archive: Int, section: String)' "$MAIN"
grep -Fq 'hasVisibilityPolicy' "$MAIN"
grep -Fq 'showProfileMobileV736' "$MAIN"
grep -Fq 'showVipPlansMobileV736' "$MAIN"
grep -Fq 'showBoxOfficeMobileV736' "$MAIN"
grep -Fq 'archiveRuntimeScope(item, "watch_party")' "$MAIN"
grep -Fq 'archiveRuntimeScope(item, "external_player")' "$MAIN"
grep -Fq 'archiveRuntimeScope(item, "internal_player")' "$MAIN"
grep -Fq 'archiveRuntimeScope(item, "all_players")' "$MAIN"
grep -Fq 'remoteArchiveExternalPlayerScopes' "$MAIN"
grep -Fq 'remoteArchiveInternalPlayerScopes' "$MAIN"
grep -Fq 'remoteArchiveWatchPartyScopes' "$MAIN"
grep -Fq 'remoteArchiveAllPlayerScopes' "$MAIN"
grep -Fq "'enabled' => !empty(\$_POST['home_archive' . \$arcNo . '_' . \$sectionKey])" "$ADMIN"
grep -Fq "'watch_party_access_scope'=>\$archiveWatchPartyScopes[1]" "$ADMIN"
grep -Fq "'external_player_access_scope'=>\$archiveExternalPlayerScopes[4]" "$ADMIN"
grep -Fq 'home_section_policy' "$CONFIG"
grep -Fq 'V7.36: home-section visibility is authoritative per section' "$CONFIG"
grep -Fq 'config_revision' "$CONFIG"
grep -Fq 'watch_party_access_scope' "$POLICY"
grep -Fq 'external_player_access_scope' "$POLICY"
php -l "$ADMIN" >/dev/null
php -l "$CONFIG" >/dev/null
php -l "$POLICY" >/dev/null
printf 'V736_HOME_ARCHIVE_GATES_PROFILE_VIP_BOXOFFICE_VERIFY_OK\n'
