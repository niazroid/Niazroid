<?php
/**
 * App-only archive policy.
 *
 * The website archive manager and the Android app controller intentionally use
 * different policy stores. Website VIP/visibility changes must not silently
 * lock Android. BM Admin writes the app policy into bankmovie_remote_config.json.
 */
require_once __DIR__ . '/archive_control.php';

if (!function_exists('bm_app_policy_header_value')) {
    function bm_app_policy_header_value(string $name): string {
        $key = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
        return trim((string)($_SERVER[$key] ?? ''));
    }
}

if (!function_exists('bm_app_policy_current_user')) {
    function bm_app_policy_current_user() {
        static $resolved = false;
        static $viewer = null;
        if ($resolved) return $viewer;
        $resolved = true;
        $token = bm_app_policy_header_value('X-BM-User-Token');
        if ($token === '') {
            $authorization = bm_app_policy_header_value('Authorization');
            if (preg_match('/^Bearer\s+(.+)$/i', $authorization, $m)) $token = trim((string)$m[1]);
        }
        if ($token === '' || !class_exists('User')) return null;
        global $pdo;
        if (!($pdo instanceof PDO)) return null;
        try {
            $candidate = (new User($pdo))->checkSession($token);
            if (is_array($candidate)) $viewer = $candidate;
        } catch (Throwable $e) {
            error_log('BankMovie app archive session lookup failed: ' . $e->getMessage());
        }
        return $viewer;
    }
}

if (!function_exists('bm_app_archive_policy_config')) {
    function bm_app_archive_policy_config(): array {
        $path = dirname(__DIR__) . '/bankmovie_remote_config.json';
        $saved = [];
        if (is_file($path)) {
            $raw = @file_get_contents($path);
            $json = is_string($raw) ? json_decode($raw, true) : null;
            if (is_array($json)) $saved = $json;
        }
        return $saved;
    }
}

if (!function_exists('bm_app_archive_policy_row')) {
    function bm_app_archive_policy_row(string $archiveId): array {
        $archiveId = strtolower(trim($archiveId));
        if (!preg_match('/^archive([1-4])$/', $archiveId, $m)) return [];
        $n = (int)$m[1];
        $cfg = bm_app_archive_policy_config();
        $features = is_array($cfg['features']['archives'] ?? null) ? $cfg['features']['archives'] : [];
        $policies = is_array($cfg['app_archive_policy'] ?? null) ? $cfg['app_archive_policy'] : [];
        $row = is_array($policies[$archiveId] ?? null) ? $policies[$archiveId] : [];
        $enabled = array_key_exists('enabled', $row) ? !empty($row['enabled']) : !array_key_exists("archive{$n}_enabled", $features) || !empty($features["archive{$n}_enabled"]);
        $hidden = array_key_exists('hidden', $row) ? !empty($row['hidden']) : !empty($features["archive{$n}_hidden"]);
        $downloadScope = strtolower(trim((string)($row['download_access_scope'] ?? (!empty($features["archive{$n}_download_vip"]) ? 'vip' : 'public'))));
        $streamScope = strtolower(trim((string)($row['stream_access_scope'] ?? (!empty($features["archive{$n}_stream_vip"]) ? 'vip' : 'public'))));
        $accessScope = strtolower(trim((string)($row['access_scope'] ?? 'public')));
        $appFeatures = is_array($cfg['features'] ?? null) ? $cfg['features'] : [];
        $watchPartyScope = strtolower(trim((string)($row['watch_party_access_scope'] ?? ($appFeatures['watch_party_scope'] ?? 'vip'))));
        $internalPlayerScope = strtolower(trim((string)($row['internal_player_access_scope'] ?? ($appFeatures['internal_player_scope'] ?? 'public'))));
        $externalPlayerScope = strtolower(trim((string)($row['external_player_access_scope'] ?? ($appFeatures['external_player_scope'] ?? 'public'))));
        $allPlayersScope = strtolower(trim((string)($row['all_players_access_scope'] ?? ($appFeatures['all_players_scope'] ?? 'public'))));
        $allowed = ['public','member','vip','admin','disabled'];
        if (!in_array($downloadScope, $allowed, true)) $downloadScope = 'public';
        if (!in_array($streamScope, $allowed, true)) $streamScope = 'public';
        if (!in_array($accessScope, ['public','member','vip','admin'], true)) $accessScope = 'public';
        if (!in_array($watchPartyScope, $allowed, true)) $watchPartyScope = 'vip';
        if (!in_array($internalPlayerScope, $allowed, true)) $internalPlayerScope = 'public';
        if (!in_array($externalPlayerScope, $allowed, true)) $externalPlayerScope = 'public';
        if (!in_array($allPlayersScope, $allowed, true)) $allPlayersScope = 'public';
        return [
            'enabled'=>$enabled,
            'hidden'=>$hidden,
            'access_scope'=>$accessScope,
            'download_access_scope'=>$downloadScope,
            'stream_access_scope'=>$streamScope,
            'watch_party_access_scope'=>$watchPartyScope,
            'internal_player_access_scope'=>$internalPlayerScope,
            'external_player_access_scope'=>$externalPlayerScope,
            'all_players_access_scope'=>$allPlayersScope,
            'disabled_message'=>(string)($row['disabled_message'] ?? "این آرشیو در اپ موقتاً غیرفعال است."),
        ];
    }
}

if (!function_exists('bm_app_archive_is_enabled')) {
    function bm_app_archive_is_enabled(string $archiveId): bool { return !empty(bm_app_archive_policy_row($archiveId)['enabled']); }
}
if (!function_exists('bm_app_archive_user_can_access')) {
    function bm_app_archive_user_can_access(string $archiveId, $user = null): bool {
        $scope = (string)(bm_app_archive_policy_row($archiveId)['access_scope'] ?? 'public');
        return function_exists('bm_archive_scope_allows') ? bm_archive_scope_allows($scope, $user) : $scope === 'public';
    }
}
if (!function_exists('bm_app_archive_feature_scope')) {
    function bm_app_archive_feature_scope(string $archiveId, string $feature): string {
        $row = bm_app_archive_policy_row($archiveId);
        return (string)($row[$feature === 'stream' ? 'stream_access_scope' : 'download_access_scope'] ?? 'public');
    }
}
if (!function_exists('bm_app_archive_feature_user_can_access')) {
    function bm_app_archive_feature_user_can_access(string $archiveId, string $feature, $user = null): bool {
        if (!bm_app_archive_is_enabled($archiveId) || !bm_app_archive_user_can_access($archiveId, $user)) return false;
        $scope = bm_app_archive_feature_scope($archiveId, $feature);
        if ($scope === 'disabled') return false;
        return function_exists('bm_archive_scope_allows') ? bm_archive_scope_allows($scope, $user) : $scope === 'public';
    }
}
if (!function_exists('bm_app_archive_apply_payload_policy')) {
    function bm_app_archive_apply_payload_policy(string $archiveId, $payload, $user = null, array $context = []) {
        if (!is_array($payload)) return $payload;
        $isList = array_is_list($payload);
        $downloadScope = bm_app_archive_feature_scope($archiveId, 'download');
        $streamScope = bm_app_archive_feature_scope($archiveId, 'stream');
        $downloadAllowed = bm_app_archive_feature_user_can_access($archiveId, 'download', $user);
        $streamAllowed = bm_app_archive_feature_user_can_access($archiveId, 'stream', $user);
        // Preserve per-title emergency blocks maintained by the shared archive manager.
        if ($downloadAllowed && function_exists('bm_archive_item_downloads_blocked')) {
            $downloadAllowed = !bm_archive_item_downloads_blocked($archiveId, $payload, $context);
        }
        if (!$downloadAllowed && function_exists('bm_archive_strip_download_payload')) $payload = bm_archive_strip_download_payload($payload);
        if (!$streamAllowed && function_exists('bm_archive_strip_stream_payload')) $payload = bm_archive_strip_stream_payload($payload);
        if (!$isList) {
            $policy = ['download_access_scope'=>$downloadScope, 'stream_access_scope'=>$streamScope];
            $payload['archive_policy'] = $policy;
            foreach (['item','movie'] as $key) {
                if (isset($payload[$key]) && is_array($payload[$key]) && !array_is_list($payload[$key])) {
                    $payload[$key]['archive_policy'] = $policy;
                    $payload[$key]['download_access_scope'] = $downloadScope;
                    $payload[$key]['stream_access_scope'] = $streamScope;
                }
            }
        }
        if (!$isList && !$downloadAllowed) {
            $msg = $downloadScope === 'vip' ? 'دانلود این آرشیو در اپ ویژه اعضای VIP است.' : 'لینک‌های دانلود این عنوان در اپ در دسترس نیست.';
            $payload['downloads_locked'] = true; $payload['download_message'] = $msg;
            if ($downloadScope === 'vip') $payload['download_gate'] = 'vip';
            foreach (['item','movie'] as $key) if (isset($payload[$key]) && is_array($payload[$key])) {
                $payload[$key]['downloads_locked'] = true; $payload[$key]['download_message'] = $msg;
                if ($downloadScope === 'vip') $payload[$key]['download_gate'] = 'vip';
            }
        }
        if (!$isList && !$streamAllowed) {
            $msg = $streamScope === 'vip' ? 'پخش آنلاین این آرشیو در اپ ویژه اعضای VIP است.' : 'پخش آنلاین این آرشیو در اپ برای حساب شما فعال نیست.';
            $payload['stream_locked'] = true; $payload['stream_message'] = $msg;
            if ($streamScope === 'vip') $payload['stream_gate'] = 'vip';
            foreach (['item','movie'] as $key) if (isset($payload[$key]) && is_array($payload[$key])) {
                $payload[$key]['stream_locked'] = true; $payload[$key]['stream_message'] = $msg;
                if ($streamScope === 'vip') $payload[$key]['stream_gate'] = 'vip';
            }
        }
        return $payload;
    }
}

if (!function_exists('bm_app_archive_sections')) {
    function bm_app_archive_sections(string $archiveId, array $fallback = []): array {
        if (!preg_match('/^archive([1-4])$/', $archiveId, $m)) return $fallback;
        $cfg = bm_app_archive_policy_config();
        $key = 'archive' . (int)$m[1] . '_sections';
        if (!array_key_exists($key, (array)($cfg['home'] ?? []))) return $fallback;
        $rows = is_array($cfg['home'][$key] ?? null) ? $cfg['home'][$key] : [];
        $out=[];
        foreach ($rows as $row) { $v=trim((string)$row); if ($v!=='' && !in_array($v,$out,true)) $out[]=$v; }
        return $out;
    }
}
