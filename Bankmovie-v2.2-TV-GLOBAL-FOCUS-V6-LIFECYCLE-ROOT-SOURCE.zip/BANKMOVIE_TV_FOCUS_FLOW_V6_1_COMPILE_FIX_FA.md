# BankMovie TV Focus Flow V6.1 - Kotlin Compile Fix

- خطای `MainActivity.kt:2711` به خاطر ناسازگاری نوع `ViewGroup` با `LinearLayout` بود.
- رجیستری Home عمداً `row` را به صورت `ViewGroup` نگه می‌دارد، بنابراین helper مشترک `positionRailAtNewest` هم باید `ViewGroup` بپذیرد.
- امضای تابع به `row: ViewGroup` اصلاح شد.
- verifier نسخه V6 اکنون این ناسازگاری را در مرحله preflight می‌گیرد تا Build بعداً در Kotlin compile شکست نخورد.
