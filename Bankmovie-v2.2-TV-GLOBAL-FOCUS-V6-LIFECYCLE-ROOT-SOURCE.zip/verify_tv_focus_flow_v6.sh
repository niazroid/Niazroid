#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
MANIFEST='app/src/main/AndroidManifest.xml'
need() { grep -Fq "$2" "$1" || { echo "Missing marker: $2" >&2; exit 1; }; }

# V6 lifecycle root cause: MainActivity is singleTask, so TV launcher re-entry
# must explicitly rebuild/rebind Home instead of assuming onCreate runs again.
need "$MANIFEST" 'android:launchMode="singleTask"'
need "$MAIN" 'TV ROOT FOCUS V6: MainActivity is singleTask.'
need "$MAIN" 'val tvLauncherReentry = isTvLike() &&'
need "$MAIN" 'launchIntent.action == Intent.ACTION_MAIN'
need "$MAIN" 'showHome()'
need "$MAIN" 'private var tvHomeWasStopped = false'
need "$MAIN" 'override fun onStop()'
need "$MAIN" 'root.postDelayed({ rebindHomeTvFocusAfterLifecycle() }, 70L)'
need "$MAIN" 'private fun rebindHomeTvFocusAfterLifecycle()'
need "$MAIN" 'armTvFocusScrollGuards(content)'
need "$MAIN" 'resetHomeTvRailViewportsToNewest()'

# V6 must never swallow a D-pad direction when requestFocus did not actually move.
need "$MAIN" 'never report success until Android confirms that real focus moved.'
need "$MAIN" 'val moved = focused || view.hasFocus() || currentFocus === view || isDescendantOf(currentFocus, view)'
need "$MAIN" 'if (!moved) return false'
need "$MAIN" 'Do not consume a direction that failed to move real focus.'
need "$MAIN" 'return false'

# Archive rebuild must block platform auto-focus until the intended archive exists.
need "$MAIN" 'content.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS'
need "$MAIN" 'descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS'
need "$MAIN" 'content.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS'
need "$MAIN" 'page.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS'
need "$MAIN" 'tvFocusIndexByScreen.remove("home")'

# Every Home rail must be anchored to logical child #0 (newest/rightmost), not a
# firmware-restored middle HorizontalScrollView offset.
need "$MAIN" 'anchor the rail to logical child #0 itself instead of fullScroll().'
need "$MAIN" 'val first = row.getChildAt(0)'
need "$MAIN" '(first.right - scroller.width + scroller.paddingRight).coerceAtLeast(0)'


# V6.1 compile guard: HomeTvRailRegistration.row is ViewGroup, so the shared
# viewport helper must accept ViewGroup too. This catches the exact Kotlin type
# mismatch that otherwise only appears during compileAbi2LiteReleaseKotlin.
need "$MAIN" 'private fun positionRailAtNewest('
need "$MAIN" 'row: ViewGroup,'
if grep -A4 -F 'private fun positionRailAtNewest(' "$MAIN" | grep -Fq 'row: LinearLayout,'; then
  echo 'V6 compile guard failed: positionRailAtNewest still requires LinearLayout' >&2
  exit 1
fi

# V5 registry invariants still apply.
bash verify_tv_focus_flow_v5.sh

echo 'TV_FOCUS_FLOW_V6_LIFECYCLE_ROOT_OK'
