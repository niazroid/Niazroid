package ir.bankmoviee.app

import android.content.Context
import android.util.AttributeSet
import android.graphics.Rect
import android.view.View
import android.widget.ScrollView
import kotlin.math.roundToInt

/**
 * Drop-in vertical scroller tuned for the native BankMovie screens.
 *
 * It intentionally stays a platform ScrollView (instead of adding another UI
 * dependency), so all existing focus/restore code keeps working. Phone flings
 * are only lightly damped to remove the abrupt "throw" feeling while keeping
 * Android's native physics and 60/90/120 Hz frame pacing. TV is left untouched
 * because D-pad focus, not touch inertia, owns navigation there.
 */
internal class BankmovieSmoothScrollView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.scrollViewStyle
) : ScrollView(context, attrs, defStyleAttr) {

    private val tvLike = DeviceProfile.isTv(context)
    private var suppressTvFocusReveal = tvLike

    init {
        isVerticalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        isSmoothScrollingEnabled = !tvLike
        clipToPadding = false
        isFillViewport = false
        if (android.os.Build.VERSION.SDK_INT >= 26) defaultFocusHighlightEnabled = false
    }


    /**
     * TV screen construction can assign focus before the page is fully measured.
     * Platform ScrollView normally scrolls immediately to reveal that focused child,
     * which made freshly opened screens jump to a control in the middle of the page.
     * Keep focus-driven reveal blocked until the user actually presses a DPAD key.
     */
    fun armTvInitialFocusGuard() {
        if (tvLike) suppressTvFocusReveal = true
    }

    fun releaseTvInitialFocusGuard() {
        suppressTvFocusReveal = false
    }

    override fun requestChildFocus(child: View, focused: View) {
        if (tvLike && suppressTvFocusReveal) {
            parent?.requestChildFocus(this, focused)
            return
        }
        super.requestChildFocus(child, focused)
    }

    override fun requestChildRectangleOnScreen(child: View, rectangle: Rect, immediate: Boolean): Boolean {
        if (tvLike && suppressTvFocusReveal) return false
        return super.requestChildRectangleOnScreen(child, rectangle, immediate)
    }

    override fun fling(velocityY: Int) {
        if (tvLike) {
            super.fling(velocityY)
            return
        }
        // Small damping keeps long pages readable and makes the deceleration feel
        // closer to modern social/streaming feeds without fighting native touch.
        val tuned = (velocityY * 0.90f).roundToInt()
        super.fling(tuned)
    }
}

/**
 * Matching lightweight horizontal scroller for poster rails/chips. It keeps the
 * platform implementation and only removes overscroll/scrollbar noise.
 */
internal class HorizontalBankmovieSmoothScrollView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.scrollViewStyle
) : android.widget.HorizontalScrollView(context, attrs, defStyleAttr) {
    private val tvLike = DeviceProfile.isTv(context)
    private var suppressTvFocusReveal = tvLike

    init {
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        isSmoothScrollingEnabled = !tvLike
        clipToPadding = false
        if (android.os.Build.VERSION.SDK_INT >= 26) defaultFocusHighlightEnabled = false
    }

    fun armTvInitialFocusGuard() {
        if (tvLike) suppressTvFocusReveal = true
    }

    fun releaseTvInitialFocusGuard() {
        suppressTvFocusReveal = false
    }

    override fun requestChildFocus(child: View, focused: View) {
        if (tvLike && suppressTvFocusReveal) {
            parent?.requestChildFocus(this, focused)
            return
        }
        super.requestChildFocus(child, focused)
    }

    override fun requestChildRectangleOnScreen(child: View, rectangle: Rect, immediate: Boolean): Boolean {
        if (tvLike && suppressTvFocusReveal) return false
        return super.requestChildRectangleOnScreen(child, rectangle, immediate)
    }
}
