# BankMovie TV Focus Flow V5 — Root Registry Fix

## چیزی که ویدیوی واقعی مشخص کرد
در ویدیو، پوسترهای ردیف اول از قبل کاملاً لود شده بودند اما `DPAD_DOWN` همچنان روی ردیف آرشیو مصرف می‌شد. بنابراین مشکل اصلی دیگر race شبکه نبود؛ مسیر V4 هنوز برای پیدا کردن اولین پوستر، بخشی از ViewTree را اسکن می‌کرد و روی بعضی TVها مقصد واقعی resolve نمی‌شد.

## اصلاح V5
- هر ریل Home همان لحظه‌ای که ساخته می‌شود داخل `tvHomeRailRegistry` ثبت می‌شود.
- ترتیب رجیستری دقیقاً ترتیب ساخت صفحه است؛ پس ریل دوم هرگز نمی‌تواند جای ریل اول را بگیرد.
- Archive -> Poster دیگر برای مسیر اصلی به اسکن Header/ViewTree یا مختصات وابسته نیست.
- `DPAD_DOWN` علاوه بر router سراسری Activity، روی خود Archive segment هم fallback مستقیم دارد.
- قبل از انتقال فوکوس برنامه‌ای، guardهای ScrollView/HorizontalScrollView صریحاً آزاد می‌شوند.
- generation هر Home build ثبت می‌شود تا callbackهای Home قبلی نتوانند رجیستری صفحه جدید را آلوده کنند.
- ریل معمولی، Search rail و Collections rail همگی از یک رجیستری استفاده می‌کنند.
- verifier قدیمی `verify_tv_focus_flow_v2.sh` اکنون verifier V5 را هم اجرا می‌کند، بنابراین Workflow فعلی بدون تغییر این اصلاح را validate می‌کند.

## رفتار مورد انتظار
`Archive 1 -> DOWN -> اولین پوستر واقعی سمت راست ردیف اول`

سپس:
`Poster 1 -> LEFT -> Poster 2 -> ... -> آخرین Poster -> LEFT -> مشاهده همه`

## تست
- `verify_tv_focus_flow_v5.sh`
- `verify_tv_focus_flow_v2.sh`
- `verify_tv_focus_flow_v4.sh`
- `verify_tv_global_focus_bootstrap_fix.sh`
- `verify_tv_right_sidenav_focus_fix.sh`
- `verify_release.sh`
