# BankMovie TV Focus + Archive fixes

- سریال چینی آرشیو ۱ از `archive1_live.php?section=chinese_series` خوانده می‌شود؛ همان parser دسته `category/chinese_series` سایت.
- برترین‌های 2026 از سکشن واقعی `top_2026` گرفته می‌شود و دیگر Search سال نیست.
- ریل‌های TV بعد از لود روی لبه جدیدترین آیتم position می‌شوند بدون دزدیدن Focus.
- ترتیب Focus خانه: مشاهده همه -> پوسترهای همان ردیف -> مشاهده همه بعدی.
- منوی سریع TV وسط صفحه باز می‌شود.
- Downloader برای UP/DOWN اهداف مخفی را نادیده می‌گیرد تا روی کنترل‌های نامرئی گیر نکند.
- ته Hero یک محافظ مشکی 8dp دارد تا ColorWash وارد نوار Update/Story نشود.
- کنترل یکپارچه Archive 4 به پنل bm_admin اضافه شد: فعال/غیرفعال/مخفی + Scope دانلود و پخش (public/member/vip/admin/disabled).
