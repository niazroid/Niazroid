#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
need() { grep -Fq "$2" "$1" || { echo "Missing marker: $2" >&2; exit 1; }; }

# V5 root fix: Home rails are registered at build time; Archive -> poster entry
# must not depend on a ViewTree/header scan once a registered rail exists.
need "$MAIN" 'private var tvHomeBuildGeneration = 0'
need "$MAIN" 'private val tvHomeRailRegistry = mutableListOf<HomeTvRailRegistration>()'
need "$MAIN" 'private fun registerHomeTvRail('
need "$MAIN" 'private fun registeredHomeTvCards(registration: HomeTvRailRegistration): List<View>'
need "$MAIN" 'val firstRegistered = tvHomeRailRegistry.firstOrNull {'
need "$MAIN" 'return registeredHomeTvCards(firstRegistered).firstOrNull()'
need "$MAIN" 'tvHomeBuildGeneration++'
need "$MAIN" 'tvHomeRailRegistry.clear()'

# Standard Home rails, search rails and collections must enter the same registry.
count="$(grep -Fc 'registerHomeTvRail(box, header, row, scroller)' "$MAIN")"
if [[ "$count" -lt 3 ]]; then
  echo "Expected at least 3 registered Home rail builders; found $count" >&2
  exit 1
fi

# DOWN has a view-level fallback on archive segments in addition to Activity routing.
need "$MAIN" 'Direct view-level fallback.'
need "$MAIN" 'keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN'
need "$MAIN" 'requestHomeFirstPosterFromArchive()'

# Programmatic Home focus transfer must explicitly release both bootstrap guards.
need "$MAIN" 'tvFocusRevealUnlockedForScreen = true'
need "$MAIN" 'tvInitialFocusPending = false'
need "$MAIN" 'releaseTvFocusScrollGuards(content)'

# V4 invariants remain: logical RTL poster order and View all after final poster.
need "$MAIN" 'val nextCard = section.cardsRightToLeft.getOrNull(cardIndex + 1)'
need "$MAIN" 'requestHomeTvFocus(nextCard ?: section.more)'
need "$MAIN" 'val previousCard = section.cardsRightToLeft.getOrNull(cardIndex - 1)'

# Guard against reintroducing geometry as the primary Home navigation source.
if grep -Fq '.sortedByDescending { it.centerX }' "$MAIN"; then
  echo 'Geometry-based Home row ordering is back.' >&2
  exit 1
fi

echo 'TV_FOCUS_FLOW_V5_ROOT_OK'
