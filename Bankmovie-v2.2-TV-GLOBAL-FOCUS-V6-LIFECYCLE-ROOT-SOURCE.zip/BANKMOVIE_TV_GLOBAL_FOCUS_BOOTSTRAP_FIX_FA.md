# اصلاح سراسری فوکوس Android TV / Remote

این پچ مشکل پرش صفحه هنگام ورود، شروع فوکوس از بخش‌های میانی و دسترسی سخت به باکس جستجو را به‌صورت سراسری اصلاح می‌کند.

## تغییرات اصلی

- Home در TV همیشه از بالای صفحه و CTA اصلی اسلایدر شروع می‌شود؛ فوکوس اولیه دیگر باعث Scroll ناخواسته نمی‌شود.
- EditText جستجو وارد گراف فوکوس TV شده و مقصد مستقیم ورود از SideNav است.
- Profile یک مقصد اولیه مشخص در کارت حساب دارد و دیگر به rail/history وسط صفحه نمی‌پرد.
- ScrollViewهای اصلی TV هنگام bootstrap، reveal خودکار Android برای focus را موقتاً مسدود می‌کنند؛ با اولین DPAD واقعی این محافظ آزاد می‌شود.
- ScrollViewهای افقی که بعداً به‌صورت async ساخته می‌شوند نیز بعد از شروع حرکت کاربر به حالت عادی برمی‌گردند.
- Detail بعد از شروع حرکت کاربر، فوکوس را با callbackهای دیرهنگام دوباره به بالای صفحه نمی‌دزدد.
- Downloads از همان محافظ bootstrap استفاده می‌کند و ورود اولیه از بالای صفحه انجام می‌شود.
- LEFT/RIGHT داخل EditText برای حرکت cursor به Android سپرده شده و UP/DOWN برای خروج اصولی از فیلد وارد گراف TV می‌شود.

## فایل‌های اصلی تغییرکرده

- `app/src/main/java/ir/bankmoviee/app/MainActivity.kt`
- `app/src/main/java/ir/bankmoviee/app/BankmovieSmoothScrollView.kt`
- `app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt`
- `verify_tv_global_focus_bootstrap_fix.sh`

## اعتبارسنجی

اسکریپت‌های TV و release موجود در سورس به‌همراه `verify_tv_global_focus_bootstrap_fix.sh` اجرا و پاس شدند.
