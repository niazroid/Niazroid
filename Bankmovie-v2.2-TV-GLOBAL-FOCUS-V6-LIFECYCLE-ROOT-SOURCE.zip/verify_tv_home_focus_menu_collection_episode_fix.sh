#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
markers=(
  'val initialTarget = preferredArchive ?: firstQuickTab ?: watch'
  'setTvSideNavExpanded(false, animate = false)'
  'tvLastContentFocus = initialTarget'
  'if (tv) setTag(R.id.bm_tv_item_json, item.toString())'
  'Do not auto-open episode 1 on TV or mobile; selection is user-driven.'
  'Triple(t("باکس آفیس", "Box Office"), Pair("boxoffice", R.drawable.ic_imdb), { showBoxOffice() })'
  'Triple(t("واچ پارتی", "Watch Party"), Pair("watch_party", R.drawable.ic_watch_party), { showWatchPartyJoinDialog() })'
  'Triple(t("دانلودها", "Downloads"), Pair("downloads", R.drawable.ic_download)'
  't("ورود / ثبت‌نام", "Sign in / Register")'
  'val visibleRows = tvSideNavItems.filter { it.visibility == View.VISIBLE && it.isFocusable && it.isEnabled }'
  'currentScreen == "home" -> 0'
  'Archive 1 -> newest/rightmost poster -> remaining posters -> View all.'
  'leftmost.nextFocusLeftId = section.more.id'
)
for marker in "${markers[@]}"; do
  grep -Fq "$marker" "$main" || { echo "Missing marker: $marker" >&2; exit 1; }
done
if grep -Fq 'bottomNav.postDelayed({ requestTvSideNavFocus(preferMenu = true) }, 80L)' "$main"; then
  echo 'Startup still forces navigation drawer focus' >&2
  exit 1
fi
if grep -Fq 'visibility = if (episodeIndex == 0) View.VISIBLE else View.GONE' "$main"; then
  echo 'Episode 1 is still auto-expanded' >&2
  exit 1
fi
bash verify_tv_right_sidenav_focus_fix.sh >/dev/null
bash verify_tv_filmio_glass_polish.sh >/dev/null
bash verify_release.sh >/dev/null
echo 'TV_HOME_FOCUS_MENU_COLLECTION_EPISODE_FIX_OK'
