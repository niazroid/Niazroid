# BankMovie TV Focus Flow V6 — Lifecycle Root Fix

این نسخه دو علت ریشه‌ای باقی‌مانده در Home تلویزیون را اصلاح می‌کند:

1. `MainActivity` در Manifest با `singleTask` اجرا می‌شود. در نتیجه باز کردن دوباره برنامه از لانچر TV الزاماً `onCreate()` جدید نمی‌سازد و state فوکوس قبلی می‌تواند زنده بماند. V6 در `onNewIntent()` ورود مجدد لانچر را تشخیص می‌دهد و Home را به‌صورت clean session بازسازی می‌کند. همچنین `onStop/onResume` برای برگشت از Activityهای خارجی، رجیستری و فوکوس Home را دوباره bind می‌کند.
2. نسخه‌های قبلی `requestHomeTvFocus()` حتی در صورت شکست واقعی `requestFocus()` مقدار `true` برمی‌گرداندند. در نتیجه `dispatchKeyEvent()` کلید DOWN را می‌بلعید و فوکوس روی Archive می‌ماند. V6 فقط وقتی کلید را مصرف می‌کند که فوکوس واقعاً جابه‌جا شده باشد؛ اگر مقصد موجود باشد ولی requestFocus شکست بخورد، مسیر native با `nextFocusDownId` فرصت اجرا پیدا می‌کند.

برای تغییر Archive نیز هنگام rebuild، `descendantFocusability` موقتاً روی `FOCUS_BLOCK_DESCENDANTS` قرار می‌گیرد تا Android وسط یکی از ریل‌ها فوکوس خودکار نسازد. بعد از آماده‌شدن صفحه، قفل باز می‌شود، فوکوس روی Archive انتخاب‌شده قرار می‌گیرد و همه ریل‌ها روی child شماره ۰ (پوستر جدید/سمت راست) anchor می‌شوند.

مسیر مورد انتظار Home روی TV:

`Archive -> Poster 1 (rightmost/newest) -> Poster 2 -> ... -> Last Poster -> View all`

ورود مجدد از لانچر نیز از Archive 1 شروع می‌شود، نه state باقی‌مانده از اجرای قبلی.
