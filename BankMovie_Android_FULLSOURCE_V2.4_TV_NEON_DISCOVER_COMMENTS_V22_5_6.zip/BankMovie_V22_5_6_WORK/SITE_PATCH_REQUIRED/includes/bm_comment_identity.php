<?php
/** BankMovie V22.5.6: common, read-only external comment identity resolver.
 * Runs equally from movie.php and app_user_api.php. Never rewrites user comments.
 * A leading numeric scraper prefix (12345__) can name the same external item.
 * Metadata / matching title and year guards prevent merging unrelated titles.
 */
if (!function_exists('bm_comment_thread_identity')) {
    function bm_comment_thread_lower(string $value): string {
        return function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
    }
    function bm_comment_thread_identity(string $slug, int $archive): string {
        $slug = trim(rawurldecode($slug), "/ \t\n\r");
        $slug = preg_replace('~^arc[134567]-~i', '', $slug);
        $slug = preg_replace('~^[0-9]{3,}__~', '', $slug);
        return bm_comment_thread_lower($slug);
    }
    function bm_comment_thread_group(PDO $pdo, int $archive, string $slug, int $incomingId,
                                     string $title = '', string $year = ''): array {
        $archive = in_array($archive, [1,3,4,5,6,7], true) ? $archive : 1;
        $normalized = bm_comment_thread_identity($slug, $archive);
        $year = trim($year);
        $title = trim($title);
        if ($normalized === '') return ['id'=>$incomingId, 'ids'=>[$incomingId]];
        // Deterministic fallback for new items not yet in archive1_items.
        $standardId = 1000000000 + (abs(crc32('arc'.$archive.':'.$normalized)) % 1000000000);
        $candidates = [$incomingId, $standardId];
        $matches = [];
        try {
            // Title is a search hint only. A matching canonical slug and compatible
            // metadata are still REQUIRED before an old id becomes an alias.
            $stmt = $pdo->prepare('SELECT virtual_movie_id, slug, item_title, item_title_fa, item_year, item_type
                                   FROM archive1_items
                                   WHERE archive_no=? AND (slug=? OR slug=? OR slug LIKE ? OR item_title=? OR item_title_fa=?) LIMIT 200');
            $stmt->execute([$archive, $slug, $normalized, '%__'.$normalized, $title, $title]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
            $anchorType = '';
            foreach ($rows as $row) {
                if (bm_comment_thread_identity((string)$row['slug'], $archive) === $normalized) {
                    $anchorType = strtolower(trim((string)($row['item_type'] ?? '')));
                    if ($anchorType !== '') break;
                }
            }
            foreach ($rows as $row) {
                $slugMatches = bm_comment_thread_identity((string)$row['slug'], $archive) === $normalized;
                $oldYear = trim((string)($row['item_year'] ?? ''));
                if ($year !== '' && $year !== '0' && $oldYear !== '' && $oldYear !== '0' && $year !== $oldYear) continue;
                $oldTitle = trim((string)($row['item_title'] ?? ''));
                $oldFa = trim((string)($row['item_title_fa'] ?? ''));
                $titleMatches = $title !== '' && (
                    bm_comment_thread_lower($title) === bm_comment_thread_lower($oldTitle) ||
                    bm_comment_thread_lower($title) === bm_comment_thread_lower($oldFa));
                // A different slug may be an alias ONLY with identical nonzero year,
                // exact title and matching media type (the same-film guard).
                $strongTitleYear = $titleMatches && $year !== '' && $year !== '0'
                    && $oldYear !== '' && $oldYear !== '0' && $year === $oldYear;
                $rowType = strtolower(trim((string)($row['item_type'] ?? '')));
                if (!$slugMatches && (!$strongTitleYear || $anchorType === '' || $rowType !== $anchorType)) continue;
                // Exact normalized slug is strong evidence even if a scraper changed the display title.
                $id = (int)$row['virtual_movie_id'];
                if ($id > 0) $matches[] = $id;
            }
        } catch (Throwable $error) {
            // An old install without metadata still handles new comments using
            // the deterministic id. Do not weaken filters on DB failures.
            error_log('BM comment identity lookup: '.$error->getMessage());
        }
        $candidates = array_values(array_unique(array_filter(array_merge($candidates,$matches),
            static fn($id) => (int)$id > 0)));
        sort($candidates, SORT_NUMERIC);
        // Stable canonical id: prefer an existing metadata row. No UPDATE/DELETE.
        $canonical = $matches ? min($matches) : $standardId;
        return ['id'=>$canonical, 'ids'=>$candidates];
    }
}
