#!/usr/bin/env bash
set -euo pipefail

FONT_DIR="app/src/main/assets/fonts"
FONT_ZIP="../irancell [@fontbazi].zip"
mkdir -p "$FONT_DIR"
test -f "$FONT_ZIP"

python3 - <<'PY'
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import re

archive = Path('../irancell [@fontbazi].zip')
output = Path('app/src/main/assets/fonts')
output.mkdir(parents=True, exist_ok=True)

targets = {
    1: 'irancell_bold.ttf',
    2: 'irancell_regular.ttf',
    3: 'irancell_black.ttf',
    4: 'irancell_semibold.ttf',
    5: 'irancell_medium.ttf',
}

with ZipFile(archive) as zf:
    fonts = [item for item in zf.infolist() if not item.is_dir() and item.filename.lower().endswith('.ttf')]
    indexed = {}
    for item in fonts:
        name = PurePosixPath(item.filename).name
        match = re.search(r'irancell[^0-9]*([1-5])', name, re.IGNORECASE)
        if match:
            indexed[int(match.group(1))] = item

    missing = [number for number in targets if number not in indexed]
    if missing:
        found = ', '.join(item.filename for item in fonts)
        raise SystemExit(f'Missing Irancell font numbers {missing}. Found: {found}')

    for number, target_name in targets.items():
        data = zf.read(indexed[number], pwd=b'fontbazi')
        if len(data) < 1024:
            raise SystemExit(f'Extracted font {indexed[number].filename} is unexpectedly small')
        (output / target_name).write_bytes(data)
        print(f'{indexed[number].filename} -> {target_name} ({len(data)} bytes)')
PY

for font in regular medium semibold bold black; do
  test -s "$FONT_DIR/irancell_${font}.ttf"
done

echo 'Irancell fonts installed successfully.'
