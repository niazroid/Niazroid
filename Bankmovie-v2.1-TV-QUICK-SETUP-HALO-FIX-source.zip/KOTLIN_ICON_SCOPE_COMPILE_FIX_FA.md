# رفع خطای Compile دکمه‌های متحرک

- خطای `Unresolved reference: icon` در `MainActivity.kt` برطرف شد.
- نمونه‌ی `ImageView` قبل از ساخت لایه‌ی داخلی تعریف شد تا در Listener کلیک نیز در Scope معتبر باشد.
- رفتار و انیمیشن دکمه تغییری نکرده است.
