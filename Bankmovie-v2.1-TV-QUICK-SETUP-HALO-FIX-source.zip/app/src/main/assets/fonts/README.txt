Font assets are injected by GitHub Actions from files stored at the repository root.

Required repository-root files:
- irancell [@fontbazi].zip
- Cinema.otf
- Diako Hima Regular-@Fontsplua.ttf
- Nic [@fontbazi].ttf
- IRANSansXFaNum-regular*.woff2
- IRANSansXFaNum-medium*.woff2
- IRANSansXFaNum-bold*.woff2

Generated Android asset names:
- irancell_regular.ttf
- irancell_medium.ttf
- irancell_semibold.ttf
- irancell_bold.ttf
- irancell_black.ttf
- cinema.otf
- diako_hima.ttf
- nic.ttf
- iransansx_regular.ttf
- iransansx_medium.ttf
- iransansx_bold.ttf

The three IRANSansX WOFF2 files are converted to TTF during GitHub Actions before the Android build.
