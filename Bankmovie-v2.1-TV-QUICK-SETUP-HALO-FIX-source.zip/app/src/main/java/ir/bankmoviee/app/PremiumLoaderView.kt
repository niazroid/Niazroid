package ir.bankmoviee.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min
import kotlin.math.sin

/**
 * Lightweight native recreation of the reference loader video.
 *
 * One rounded blue stroke contracts to a dot, grows into an upper arc,
 * rolls into a smiling face, expands into a nearly complete ring and then
 * contracts again. It uses a single Canvas and animator so it remains smooth
 * on older phones without allocating drawables on every frame.
 */
class PremiumLoaderView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val density = resources.displayMetrics.density
    private val lowEnd = DeviceProfile.isLowEnd(context)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val arcRect = RectF()
    private var phase = 0f
    private var animator: ValueAnimator? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        start()
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    fun start() {
        if (animator?.isRunning == true) return
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = if (lowEnd) 3900L else 3720L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                phase = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun stop() {
        animator?.cancel()
        animator = null
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val size = min(width, height).toFloat()
        if (size <= 0f) return

        val cx = width / 2f
        val cy = height / 2f
        val radius = size * 0.34f
        val stroke = (size * 0.072f).coerceAtLeast(2.25f * density)
        val blue = Color.rgb(13, 157, 255)
        val lightBlue = Color.rgb(54, 181, 255)

        strokePaint.strokeWidth = stroke
        strokePaint.color = blue
        strokePaint.alpha = 255
        dotPaint.color = lightBlue
        dotPaint.alpha = 255
        arcRect.set(cx - radius, cy - radius, cx + radius, cy + radius)

        when {
            phase < 0.17f -> {
                // Reference begins with an upper arc that contracts into a dash.
                val t = easeInOut(phase / 0.17f)
                canvas.drawArc(
                    arcRect,
                    lerp(184f, 346f, t),
                    lerp(168f, 10f, t),
                    false,
                    strokePaint
                )
            }

            phase < 0.35f -> {
                // The small dash opens back into the upper arch.
                val t = easeOut((phase - 0.17f) / 0.18f)
                canvas.drawArc(
                    arcRect,
                    lerp(346f, 181f, t),
                    lerp(10f, 170f, t),
                    false,
                    strokePaint
                )
            }

            phase < 0.57f -> {
                // The arch rolls down and becomes the mouth of the face.
                val t = easeInOut((phase - 0.35f) / 0.22f)
                val start = lerp(181f, 3f, t)
                val sweep = lerp(170f, 174f, t)
                canvas.drawArc(arcRect, start, sweep, false, strokePaint)

                val eyes = smoothStep(((t - 0.48f) / 0.52f).coerceIn(0f, 1f))
                drawEyes(canvas, cx, cy, radius, size, eyes, 0f)
            }

            phase < 0.72f -> {
                // Full smile; the tiny motion keeps it alive like the video.
                val t = (phase - 0.57f) / 0.15f
                val wobble = sin(t * Math.PI).toFloat()
                val smileRect = RectF(
                    cx - radius,
                    cy - radius * (0.90f - 0.04f * wobble),
                    cx + radius,
                    cy + radius * (1.08f + 0.03f * wobble)
                )
                canvas.drawArc(smileRect, 3f + 3f * wobble, 174f - 5f * wobble, false, strokePaint)
                drawEyes(canvas, cx, cy, radius, size, 1f, wobble)
            }

            phase < 0.87f -> {
                // Smile unfolds into the large C-shaped ring seen near the end.
                val t = easeInOut((phase - 0.72f) / 0.15f)
                canvas.drawArc(
                    arcRect,
                    lerp(3f, 42f, t),
                    lerp(174f, 282f, t),
                    false,
                    strokePaint
                )
                drawEyes(canvas, cx, cy, radius, size, 1f - t, 0f)
            }

            else -> {
                // The ring rotates and collapses back to the short stroke.
                val t = easeIn((phase - 0.87f) / 0.13f)
                val alpha = (255f * (1f - 0.08f * t)).toInt().coerceIn(0, 255)
                strokePaint.alpha = alpha
                canvas.drawArc(
                    arcRect,
                    lerp(42f, 252f, t),
                    lerp(282f, 11f, t),
                    false,
                    strokePaint
                )
            }
        }
    }

    private fun drawEyes(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        radius: Float,
        size: Float,
        amount: Float,
        wobble: Float
    ) {
        val a = amount.coerceIn(0f, 1f)
        if (a <= 0f) return
        dotPaint.alpha = (255f * a).toInt().coerceIn(0, 255)
        val eyeR = size * 0.038f * (0.72f + 0.28f * a)
        val y = cy - radius * 0.34f - radius * 0.025f * wobble
        val spread = radius * (0.43f + 0.015f * wobble)
        canvas.drawCircle(cx - spread, y, eyeR, dotPaint)
        canvas.drawCircle(cx + spread, y, eyeR, dotPaint)
        dotPaint.alpha = 255
    }

    private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t.coerceIn(0f, 1f)

    private fun easeOut(t: Float): Float {
        val x = t.coerceIn(0f, 1f)
        return 1f - (1f - x) * (1f - x)
    }

    private fun easeIn(t: Float): Float {
        val x = t.coerceIn(0f, 1f)
        return x * x
    }

    private fun easeInOut(t: Float): Float {
        val x = t.coerceIn(0f, 1f)
        return x * x * (3f - 2f * x)
    }

    private fun smoothStep(t: Float): Float {
        val x = t.coerceIn(0f, 1f)
        return x * x * (3f - 2f * x)
    }
}
