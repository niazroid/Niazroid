package ir.bankmoviee.app

import android.content.Context
import org.json.JSONArray

/**
 * Keeps notification deletions durable on the device. Some older server builds
 * return the broadcast feed again after a delete; tombstones stop those rows
 * from being recreated or marked as new on the next sync.
 */
object NotificationDismissStore {
    private const val PREFS = "bankmovie_notification_dismissals"
    private const val KEY_REMOTE_IDS = "remote_ids"
    private const val KEY_LOCAL_IDS = "local_ids"
    private const val KEY_CLEAR_REMOTE_THROUGH = "clear_remote_through"
    private const val MAX_IDS = 500

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun readIds(context: Context, key: String): LinkedHashSet<Long> {
        val raw = prefs(context).getString(key, "[]").orEmpty()
        val array = runCatching { JSONArray(raw) }.getOrDefault(JSONArray())
        val result = linkedSetOf<Long>()
        for (i in 0 until array.length()) {
            val id = array.optLong(i, 0L)
            if (id > 0L) result.add(id)
        }
        return result
    }

    private fun writeIds(context: Context, key: String, ids: Collection<Long>) {
        val trimmed = ids.toList().takeLast(MAX_IDS)
        val array = JSONArray()
        trimmed.forEach { array.put(it) }
        prefs(context).edit().putString(key, array.toString()).apply()
    }

    fun dismissRemote(context: Context, id: Long) {
        if (id <= 0L) return
        val ids = readIds(context, KEY_REMOTE_IDS)
        ids.add(id)
        writeIds(context, KEY_REMOTE_IDS, ids)
    }

    fun dismissLocal(context: Context, id: Long) {
        if (id <= 0L) return
        val ids = readIds(context, KEY_LOCAL_IDS)
        ids.add(id)
        writeIds(context, KEY_LOCAL_IDS, ids)
    }

    fun isRemoteDismissed(context: Context, id: Long): Boolean {
        if (id <= 0L) return false
        val through = prefs(context).getLong(KEY_CLEAR_REMOTE_THROUGH, 0L)
        return id <= through || readIds(context, KEY_REMOTE_IDS).contains(id)
    }

    fun isLocalDismissed(context: Context, id: Long): Boolean =
        id > 0L && readIds(context, KEY_LOCAL_IDS).contains(id)

    fun clearRemoteThrough(context: Context, maxId: Long) {
        if (maxId <= 0L) return
        val old = prefs(context).getLong(KEY_CLEAR_REMOTE_THROUGH, 0L)
        prefs(context).edit().putLong(KEY_CLEAR_REMOTE_THROUGH, maxOf(old, maxId)).apply()
    }

    fun clearLocal(context: Context, ids: Collection<Long>) {
        val old = readIds(context, KEY_LOCAL_IDS)
        old.addAll(ids.filter { it > 0L })
        writeIds(context, KEY_LOCAL_IDS, old)
    }
}
