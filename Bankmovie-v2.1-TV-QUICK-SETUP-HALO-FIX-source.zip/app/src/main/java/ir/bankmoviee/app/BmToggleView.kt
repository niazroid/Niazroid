package ir.bankmoviee.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.PathInterpolator

/** Compact enabled/disabled switch inspired by the supplied Uiverse control. */
class BmToggleView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var progress = 0f
    private var animator: ValueAnimator? = null
    private var listener: ((Boolean) -> Unit)? = null
    var isCheckedState: Boolean = false
        private set

    init {
        isClickable = true
        isFocusable = true
        setOnClickListener { setChecked(!isCheckedState, true, true) }
    }

    fun setOnCheckedChangeListener(block: (Boolean) -> Unit) { listener = block }

    fun setChecked(checked: Boolean, animate: Boolean = false, notify: Boolean = false) {
        isCheckedState = checked
        val target = if (checked) 1f else 0f
        animator?.cancel()
        if (animate) {
            animator = ValueAnimator.ofFloat(progress, target).apply {
                duration = 360L
                interpolator = PathInterpolator(0.22f, 1f, 0.36f, 1f)
                addUpdateListener { progress = it.animatedValue as Float; invalidate() }
                start()
            }
        } else {
            progress = target
            invalidate()
        }
        contentDescription = if (checked) "فعال" else "غیرفعال"
        if (notify) listener?.invoke(checked)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val accent = UiPreferences.palette(context).primary
        val h = height.toFloat()
        val w = width.toFloat()
        val radius = h / 2f
        rect.set(0f, 0f, w, h)
        paint.style = Paint.Style.FILL
        paint.color = blend(Color.rgb(60, 60, 60), accent, progress)
        canvas.drawRoundRect(rect, radius, radius, paint)

        val thumbR = h * 0.37f
        val start = radius
        val end = w - radius
        val x = start + (end - start) * progress
        paint.color = Color.WHITE
        paint.setShadowLayer(h * 0.09f, 0f, h * 0.04f, Color.argb(90, 0, 0, 0))
        setLayerType(LAYER_TYPE_SOFTWARE, paint)
        canvas.drawCircle(x, h / 2f, thumbR, paint)
        paint.clearShadowLayer()

        paint.textAlign = Paint.Align.CENTER
        paint.textSize = h * 0.29f
        paint.typeface = BankmovieFonts.bold(context)
        paint.color = Color.WHITE
        val label = if (isCheckedState) "فعال" else "غیرفعال"
        val labelX = if (isCheckedState) w * 0.27f else w * 0.67f
        val baseline = h / 2f - (paint.ascent() + paint.descent()) / 2f
        canvas.drawText(label, labelX, baseline, paint)
    }

    private fun blend(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )
}
