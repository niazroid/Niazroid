<?php
/**
 * پاک‌سازی یک‌باره کش حجیم API6.
 * این فایل فقط فایل‌های کش با پسوند html/html.gz/tmp را در پوشه cache/api6 حذف می‌کند.
 * پس از اجرا خودش را حذف می‌کند.
 */
require_once __DIR__ . '/security_bootstrap.php';
header('Content-Type: text/plain; charset=utf-8');

$expected = '7c5848239a6e4a1dbf163e35d298753b';
$provided = isset($_GET['key']) ? (string)$_GET['key'] : '';
if (!hash_equals($expected, $provided)) {
    http_response_code(403);
    exit("کلید پاک‌سازی نامعتبر است.\n");
}

$base = function_exists('bm_security_private_dir')
    ? rtrim(bm_security_private_dir(), '/\\')
    : (__DIR__ . '/_bankmovie_private');
$dir = $base . DIRECTORY_SEPARATOR . 'cache' . DIRECTORY_SEPARATOR . 'api6';

if (!is_dir($dir)) {
    exit("پوشه کش API6 پیدا نشد: {$dir}\nهیچ فایلی حذف نشد.\n");
}

$deleted = 0;
$bytes = 0;
$failed = 0;
$it = new DirectoryIterator($dir);
foreach ($it as $entry) {
    if ($entry->isDot() || !$entry->isFile()) continue;
    $name = $entry->getFilename();
    if (!preg_match('/(?:\.html|\.html\.gz|\.tmp)$/i', $name)) continue;
    $size = max(0, (int)$entry->getSize());
    if (@unlink($entry->getPathname())) {
        $deleted++;
        $bytes += $size;
    } else {
        $failed++;
    }
}

@unlink($dir . '/.cleanup.stamp');
@unlink($dir . '/.cleanup.lock');
$selfDeleted = @unlink(__FILE__);

echo "پاک‌سازی API6 انجام شد.\n";
echo "تعداد فایل حذف‌شده: {$deleted}\n";
echo "فضای آزادشده: " . number_format($bytes / 1024 / 1024, 2) . " MB\n";
echo "خطای حذف: {$failed}\n";
echo $selfDeleted ? "فایل پاک‌سازی نیز خودکار حذف شد.\n" : "فایل پاک‌سازی را دستی حذف کن.\n";
