@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js is required.& pause & exit /b 1)
if not exist node_modules call npm install
if errorlevel 1 (echo npm install failed.& pause & exit /b 1)
call npm run build:win
if errorlevel 1 (echo Build failed.& pause & exit /b 1)
echo.
echo Setup is available under dist\
pause
