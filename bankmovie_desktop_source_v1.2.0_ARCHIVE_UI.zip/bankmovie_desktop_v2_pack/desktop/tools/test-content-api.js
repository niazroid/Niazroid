const crypto = require('crypto');
const AUTH = require('../electron/desktop-auth.generated');

const base = process.argv[2] || 'https://bankmovie.top/desktop_api.php';
const url = new URL(base);
url.searchParams.set('action', 'ping');
const ts = String(Math.floor(Date.now() / 1000));
const pathQuery = url.pathname + url.search;
const sign = crypto.createHmac('sha256', AUTH.appSecret).update(`${ts}|${pathQuery}`).digest('hex');

(async () => {
  const res = await fetch(url, {
    headers: {
      'Accept': 'application/json',
      'X-BM-App-Key': AUTH.appKey,
      'X-BM-Ts': ts,
      'X-BM-Sign': sign,
      'X-BM-Client': 'windows',
      'X-BM-Download-System': '2'
    }
  });
  const text = await res.text();
  console.log(`HTTP ${res.status}`);
  console.log(text);
  process.exit(res.ok ? 0 : 1);
})().catch((err) => { console.error(err); process.exit(2); });
