const { app, BrowserWindow, ipcMain, dialog, shell, session, safeStorage } = require('electron');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { spawn, execFileSync } = require('child_process');
const AUTH = require('./desktop-auth.generated');

const DEFAULT = Object.freeze({
  controllerUrl: 'https://bankmovie.top/desktop_config.php',
  domain: 'https://bankmovie.top',
  apiUrl: 'https://bankmovie.top/desktop_api.php',
  fallbackApiUrl: 'https://bankmovie.top/app_api.php',
  accountApiUrl: 'https://bankmovie.top/app_user_api.php'
});

let win = null;
let runtimeConfig = null;
const pendingDownloadMeta = new Map();
const downloadItems = new Map();

function statePath() { return path.join(app.getPath('userData'), 'desktop-state.json'); }
function readState() {
  try { return JSON.parse(fs.readFileSync(statePath(), 'utf8')); } catch { return {}; }
}
function writeState(next) {
  const current = readState();
  const merged = { ...current, ...next };
  fs.mkdirSync(path.dirname(statePath()), { recursive: true });
  fs.writeFileSync(statePath(), JSON.stringify(merged, null, 2));
  return merged;
}
function saveToken(token) {
  if (!token) return writeState({ authToken: '' });
  if (safeStorage.isEncryptionAvailable()) {
    return writeState({ authToken: safeStorage.encryptString(token).toString('base64'), authEncrypted: true });
  }
  return writeState({ authToken: token, authEncrypted: false });
}
function loadToken() {
  const s = readState();
  if (!s.authToken) return '';
  try {
    return s.authEncrypted && safeStorage.isEncryptionAvailable()
      ? safeStorage.decryptString(Buffer.from(s.authToken, 'base64'))
      : String(s.authToken);
  } catch { return ''; }
}
function settings() {
  const s = readState();
  return {
    downloadDir: s.downloadDir || app.getPath('downloads'),
    preferredArchive: Number(s.preferredArchive || 1),
    preferredPlayer: String(s.preferredPlayer || 'auto'),
    controllerUrl: s.controllerUrl || DEFAULT.controllerUrl
  };
}
function normalizeBase(url, fallback) {
  try { const u = new URL(url || fallback); return u.toString(); } catch { return fallback; }
}
async function fetchJson(url, options = {}, timeoutMs = 22000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...options, signal: ctrl.signal, headers: { 'Accept': 'application/json', 'X-BM-Client': 'windows', ...(options.headers || {}) } });
    const text = await res.text();
    let data;
    try { data = JSON.parse(text); } catch { throw new Error(`پاسخ JSON معتبر نیست (${res.status})`); }
    if (!res.ok && !data?.success) throw new Error(data?.message || `HTTP ${res.status}`);
    return data;
  } finally { clearTimeout(timer); }
}
async function loadRemoteConfig(force = false) {
  if (runtimeConfig && !force) return runtimeConfig;
  const local = settings();
  const controller = normalizeBase(local.controllerUrl, DEFAULT.controllerUrl);
  try {
    const remote = await fetchJson(controller, { cache: 'no-store' }, 12000);
    const domain = String(remote.active_domain || remote.desktop?.active_domain || DEFAULT.domain).replace(/\/$/, '');
    runtimeConfig = {
      ...remote,
      active_domain: domain,
      api_url: remote.desktop_api_url || remote.api_url || `${domain}/desktop_api.php`,
      account_api_url: remote.account_api_url || `${domain}/app_user_api.php`,
      controller_url: controller,
      _online: true
    };
  } catch (error) {
    runtimeConfig = {
      platform: 'windows', active_domain: DEFAULT.domain,
      api_url: DEFAULT.fallbackApiUrl, desktop_api_url: DEFAULT.apiUrl,
      account_api_url: DEFAULT.accountApiUrl, controller_url: controller,
      features: {}, desktop: { enabled: true, features: {} }, _online: false,
      _error: error.message
    };
  }
  return runtimeConfig;
}
function queryUrl(base, params = {}) {
  const u = new URL(base);
  Object.entries(params).forEach(([k,v]) => {
    if (v === undefined || v === null || v === '') return;
    if (Array.isArray(v)) v.forEach(x => u.searchParams.append(k, String(x)));
    else u.searchParams.set(k, String(v));
  });
  return u;
}
async function contentRequest(action, params = {}) {
  const cfg = await loadRemoteConfig();
  const candidates = [cfg.api_url, cfg.desktop_api_url, DEFAULT.fallbackApiUrl].filter(Boolean);
  let last;
  for (const base of [...new Set(candidates)]) {
    const url = queryUrl(base, { action, ...params }).toString();
    try {
      const { ts, sign } = signFor(url);
      const token = loadToken();
      const headers = {
        'X-BM-App-Key': AUTH.appKey,
        'X-BM-Ts': ts,
        'X-BM-Sign': sign,
        'X-BM-Client': 'windows',
        'X-BM-Download-System': '2'
      };
      if (token) {
        headers.Authorization = `Bearer ${token}`;
        headers['X-BM-User-Token'] = token;
      }
      return await fetchJson(url, { cache: 'no-store', headers });
    } catch (e) { last = e; }
  }
  throw last || new Error('سرور محتوا در دسترس نیست');
}
function signFor(url) {
  const u = new URL(url);
  const ts = String(Math.floor(Date.now() / 1000));
  const pathQuery = u.pathname + (u.search ? u.search : '');
  const sign = crypto.createHmac('sha256', AUTH.appSecret).update(`${ts}|${pathQuery}`).digest('hex');
  return { ts, sign };
}
async function userRequest(action, body = {}, method = 'POST') {
  const cfg = await loadRemoteConfig();
  const url = queryUrl(cfg.account_api_url || DEFAULT.accountApiUrl, method === 'GET' ? { action, ...body } : {});
  const { ts, sign } = signFor(url);
  const token = loadToken();
  const headers = {
    'X-BM-App-Key': AUTH.appKey,
    'X-BM-Ts': ts,
    'X-BM-Sign': sign,
    'X-BM-Notification-Protocol': '2',
    'Content-Type': 'application/json'
  };
  if (token) headers.Authorization = `Bearer ${token}`;
  const opts = { method, headers, cache: 'no-store' };
  if (method !== 'GET') opts.body = JSON.stringify({ action, ...body });
  const data = await fetchJson(url.toString(), opts);
  if ((action === 'login' || action === 'register') && data?.token) saveToken(data.token);
  if (action === 'logout') saveToken('');
  return data;
}
function safeFileName(name) {
  return String(name || 'BankMovie').replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/\s+/g, ' ').trim().slice(0, 150) || 'BankMovie';
}

const PLAYER_DEFS = [
  {
    id: 'potplayer', name: 'PotPlayer', score: 100,
    exes: ['PotPlayerMini64.exe','PotPlayerMini.exe','PotPlayer.exe'],
    paths: [
      ['ProgramFiles','DAUM','PotPlayer','PotPlayerMini64.exe'],
      ['ProgramFiles','PotPlayer','PotPlayerMini64.exe'],
      ['ProgramFiles(x86)','DAUM','PotPlayer','PotPlayerMini.exe'],
      ['ProgramFiles(x86)','PotPlayer','PotPlayerMini.exe']
    ]
  },
  {
    id: 'vlc', name: 'VLC', score: 95,
    exes: ['vlc.exe'],
    paths: [
      ['ProgramFiles','VideoLAN','VLC','vlc.exe'],
      ['ProgramFiles(x86)','VideoLAN','VLC','vlc.exe']
    ]
  },
  {
    id: 'kmplayer', name: 'KMPlayer', score: 80,
    exes: ['KMPlayer64.exe','KMPlayer.exe'],
    paths: [
      ['ProgramFiles','KMPlayer 64X','KMPlayer64.exe'],
      ['ProgramFiles','KMPlayer','KMPlayer.exe'],
      ['ProgramFiles(x86)','The KMPlayer','KMPlayer.exe'],
      ['ProgramFiles(x86)','KMPlayer','KMPlayer.exe']
    ]
  }
];

function uniqExisting(paths) {
  const seen = new Set();
  return paths.filter(p => {
    if (!p) return false;
    const q = path.resolve(p);
    if (seen.has(q.toLowerCase()) || !fs.existsSync(q)) return false;
    seen.add(q.toLowerCase());
    return true;
  });
}
function appPathFromRegistry(exe) {
  if (process.platform !== 'win32') return '';
  const roots = ['HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\App Paths', 'HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\App Paths'];
  for (const root of roots) {
    try {
      const out = execFileSync('reg.exe', ['query', `${root}\\${exe}`, '/ve'], { encoding:'utf8', windowsHide:true, timeout:1800 });
      const m = out.match(/REG_(?:EXPAND_)?SZ\s+(.+)$/mi);
      if (m && fs.existsSync(m[1].trim())) return m[1].trim();
    } catch {}
  }
  return '';
}
function appPathFromWhere(exe) {
  if (process.platform !== 'win32') return '';
  try {
    const out = execFileSync('where.exe', [exe], { encoding:'utf8', windowsHide:true, timeout:1800 });
    return out.split(/\r?\n/).map(x=>x.trim()).find(x=>x && fs.existsSync(x)) || '';
  } catch { return ''; }
}
function detectPlayers() {
  if (process.platform !== 'win32') return [];
  const found = [];
  for (const def of PLAYER_DEFS) {
    const candidates = [];
    for (const parts of def.paths) {
      const root = process.env[parts[0]];
      if (root) candidates.push(path.join(root, ...parts.slice(1)));
    }
    for (const exe of def.exes) {
      candidates.push(appPathFromRegistry(exe));
      candidates.push(appPathFromWhere(exe));
    }
    const existing = uniqExisting(candidates);
    if (existing.length) {
      const executable = existing.find(x => /64\.exe$/i.test(x)) || existing[0];
      found.push({ id:def.id, name:def.name, path:executable, score:def.score, subtitleSupport:def.id !== 'kmplayer' });
    }
  }
  return found.sort((a,b)=>b.score-a.score);
}
function selectedPlayer(preferred = 'auto') {
  const players = detectPlayers();
  if (!players.length) return null;
  if (preferred && preferred !== 'auto') return players.find(p=>p.id===preferred) || players[0];
  return players[0];
}
async function materializeSubtitle(url) {
  if (!url || !/^https?:\/\//i.test(url)) return '';
  const ctrl = new AbortController();
  const timer = setTimeout(()=>ctrl.abort(), 15000);
  try {
    const res = await fetch(url, { signal:ctrl.signal, redirect:'follow' });
    if (!res.ok) return '';
    const buf = Buffer.from(await res.arrayBuffer());
    if (!buf.length || buf.length > 8 * 1024 * 1024) return '';
    let ext = '.srt';
    try {
      const e = path.extname(new URL(url).pathname).toLowerCase();
      if (['.srt','.vtt','.ass','.ssa','.sub'].includes(e)) ext = e;
    } catch {}
    const dir = path.join(app.getPath('temp'), 'BankMovie', 'subtitles');
    fs.mkdirSync(dir, { recursive:true });
    const file = path.join(dir, `${crypto.createHash('sha1').update(url).digest('hex')}${ext}`);
    fs.writeFileSync(file, buf);
    return file;
  } catch { return ''; }
  finally { clearTimeout(timer); }
}
async function launchExternalPlayer(meta = {}) {
  const url = String(meta.url || '');
  if (!/^https?:\/\//i.test(url)) throw new Error('لینک پخش معتبر نیست');
  const pref = String(meta.preferredPlayer || settings().preferredPlayer || 'auto');
  const player = selectedPlayer(pref);
  if (!player) throw new Error('هیچ‌کدام از VLC، PotPlayer یا KMPlayer روی ویندوز پیدا نشد. یکی از آن‌ها را نصب کن.');
  const subtitlePath = await materializeSubtitle(String(meta.subtitleUrl || ''));
  const args = [];
  if (player.id === 'vlc') {
    args.push(url, '--one-instance');
    if (subtitlePath) args.push(`--sub-file=${subtitlePath}`);
  } else if (player.id === 'potplayer') {
    args.push(url);
    if (subtitlePath) args.push(`/sub=${subtitlePath}`);
  } else {
    args.push(url);
  }
  try {
    const child = spawn(player.path, args, { detached:true, stdio:'ignore', windowsHide:false });
    child.unref();
  } catch (e) {
    throw new Error(`اجرای ${player.name} ناموفق بود: ${e.message}`);
  }
  return { ok:true, player:{ id:player.id, name:player.name, path:player.path }, subtitleApplied:Boolean(subtitlePath && player.subtitleSupport) };
}

function installDownloadHooks() {
  session.defaultSession.on('will-download', (_event, item, sourceWebContents) => {
    const url = item.getURL();
    const chain = typeof item.getURLChain === 'function' ? item.getURLChain() : [url];
    const metaKey = chain.find(u => pendingDownloadMeta.has(u)) || (pendingDownloadMeta.has(url) ? url : '');
    const meta = metaKey ? (pendingDownloadMeta.get(metaKey) || {}) : {};
    if (metaKey) pendingDownloadMeta.delete(metaKey);
    const id = meta.id || crypto.randomUUID();
    const folder = settings().downloadDir;
    fs.mkdirSync(folder, { recursive: true });
    let ext = '.mp4';
    try { ext = path.extname(new URL(url).pathname) || '.mp4'; } catch {}
    const requestedName = meta.fileName || item.getFilename() || `BankMovie-${id}${ext}`;
    item.setSavePath(path.join(folder, safeFileName(requestedName)));
    downloadItems.set(id, item);

    const send = (payload) => {
      const target = sourceWebContents && typeof sourceWebContents.isDestroyed === 'function' && !sourceWebContents.isDestroyed()
        ? sourceWebContents
        : (win && !win.isDestroyed() && win.webContents && !win.webContents.isDestroyed() ? win.webContents : null);
      if (!target) return;
      try { target.send('download:update', { id, url, ...meta, ...payload }); } catch {}
    };

    send({ state: 'starting', received: 0, total: item.getTotalBytes(), savePath: item.getSavePath() });
    item.on('updated', (_e, state) => send({ state, received: item.getReceivedBytes(), total: item.getTotalBytes(), paused: item.isPaused(), savePath: item.getSavePath() }));
    item.once('done', (_e, state) => {
      send({ state, received: item.getReceivedBytes(), total: item.getTotalBytes(), paused:false, savePath: item.getSavePath() });
      downloadItems.delete(id);
    });
  });
}
function createWindow() {
  win = new BrowserWindow({
    width: 1480, height: 920, minWidth: 1100, minHeight: 700,
    frame: false, backgroundColor: '#060708', show: false,
    icon: path.join(__dirname, '../src/assets/bankmovie-icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  win.loadFile(path.join(__dirname, '../src/index.html'));
  win.once('ready-to-show', () => win.show());
}

app.whenReady().then(() => { installDownloadHooks(); createWindow(); app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); }); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('bootstrap', async () => ({ config: await loadRemoteConfig(true), settings: settings(), players: detectPlayers(), hasToken: Boolean(loadToken()), version: app.getVersion() }));
ipcMain.handle('content:request', (_e, action, params) => contentRequest(action, params));
ipcMain.handle('user:request', (_e, action, body, method) => userRequest(action, body || {}, method || 'POST'));
ipcMain.handle('auth:clear', () => { saveToken(''); return true; });
ipcMain.handle('settings:get', () => settings());
ipcMain.handle('settings:set', (_e, patch) => { writeState(patch || {}); runtimeConfig = null; return settings(); });
ipcMain.handle('settings:choose-download-dir', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openDirectory', 'createDirectory'], defaultPath: settings().downloadDir });
  if (r.canceled || !r.filePaths[0]) return settings().downloadDir;
  writeState({ downloadDir: r.filePaths[0] }); return r.filePaths[0];
});
ipcMain.handle('download:add', (_e, meta) => {
  if (!meta?.url || !/^https?:\/\//i.test(meta.url)) throw new Error('لینک دانلود معتبر نیست');
  const id = crypto.randomUUID();
  pendingDownloadMeta.set(meta.url, { ...meta, id });
  if (win && !win.isDestroyed() && win.webContents && !win.webContents.isDestroyed()) win.webContents.downloadURL(meta.url);
  else session.defaultSession.downloadURL(meta.url);
  return { id };
});
ipcMain.handle('download:action', (_e, id, action) => {
  const item = downloadItems.get(id); if (!item) return false;
  if (action === 'pause') item.pause(); else if (action === 'resume') item.resume(); else if (action === 'cancel') item.cancel();
  return true;
});
ipcMain.handle('player:list', () => detectPlayers());
ipcMain.handle('player:play', (_e, meta) => launchExternalPlayer(meta || {}));
ipcMain.handle('shell:open', (_e, url) => shell.openExternal(url));
ipcMain.handle('shell:show-item', (_e, filePath) => { shell.showItemInFolder(filePath); return true; });
ipcMain.on('window:minimize', () => win?.minimize());
ipcMain.on('window:maximize', () => win?.isMaximized() ? win.unmaximize() : win?.maximize());
ipcMain.on('window:close', () => win?.close());
