// Generated specifically for the Windows client. Rotate both this file and
// server/includes/desktop_app_auth.php before a public release if desired.
module.exports = Object.freeze({
  appKey: 'bm_windows_v1_b3a9a48d9f35',
  appSecret: '7addd06d74f3d8fc7734d05b9ab6790c19c7c4d1eb323ed9e2efb9cc96f473df'
});
