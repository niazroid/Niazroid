const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('bankmovie', {
  bootstrap: () => ipcRenderer.invoke('bootstrap'),
  content: (action, params = {}) => ipcRenderer.invoke('content:request', action, params),
  user: (action, body = {}, method = 'POST') => ipcRenderer.invoke('user:request', action, body, method),
  logoutLocal: () => ipcRenderer.invoke('auth:clear'),
  getSettings: () => ipcRenderer.invoke('settings:get'),
  setSettings: (patch) => ipcRenderer.invoke('settings:set', patch),
  chooseDownloadDir: () => ipcRenderer.invoke('settings:choose-download-dir'),
  download: (meta) => ipcRenderer.invoke('download:add', meta),
  downloadAction: (id, action) => ipcRenderer.invoke('download:action', id, action),
  getPlayers: () => ipcRenderer.invoke('player:list'),
  playExternal: (meta) => ipcRenderer.invoke('player:play', meta),
  openExternal: (url) => ipcRenderer.invoke('shell:open', url),
  showItem: (filePath) => ipcRenderer.invoke('shell:show-item', filePath),
  onDownload: (cb) => ipcRenderer.on('download:update', (_e, payload) => cb(payload)),
  window: {
    minimize: () => ipcRenderer.send('window:minimize'),
    maximize: () => ipcRenderer.send('window:maximize'),
    close: () => ipcRenderer.send('window:close')
  }
});
