# BankMovie 2.3 — V7.20 Main Update

## بازگشت از صفحه فیلم به جستجوی پیشرفته

در نتایج جستجوی پیشرفته، ورود به صفحه جزئیات فیلم دیگر باعث از دست رفتن لیست صفحه‌بندی‌شده نمی‌شود. برنامه snapshot نتایج بارگذاری‌شده، `nextPage` و `hasMore` را در حافظه نگه می‌دارد. هنگام Back، کارت‌ها قبل از بازیابی scroll به‌صورت synchronous بازسازی می‌شوند و page 1 دوباره درخواست نمی‌شود. cache حداکثر چهار جستجو و ۶ ساعت نگه داشته می‌شود تا حتی بعد از تماشای طولانی، بازگشت به نتایج از اول شروع نشود.

## Cast / Renderer واقعی

Player موجود LibVLC با سه transport کار می‌کند: Local LibVLC، Google Cast و UPnP/DLNA MediaRenderer.

- AndroidX `MediaRouteButton` و `MediaRouter` پنجره Route Picker را باز می‌کنند.
- Google Cast Sender با Default Media Receiver، `CastSession` و `RemoteMediaClient` رسانه جاری را با position فعلی ارسال می‌کند.
- UPnP/DLNA با SSDP `M-SEARCH` واقعی، Device Description، سرویس `AVTransport` و SOAP کنترل می‌شود.
- فرمان‌های DLNA شامل `SetAVTransportURI`, `Play`, `Pause`, `Stop`, `Seek`, `GetPositionInfo`, `GetTransportInfo` هستند.
- Play/Pause/Seek و تعویض track در Player به transport فعال هدایت می‌شوند.
- هنگام Stop/Disconnect قابل‌کنترل، position برای برگشت به پلیر محلی نگه داشته می‌شود.

### محدودیت Renderer

Renderer مقصد باید URL فعلی را خودش بتواند با HTTP/HTTPS دریافت کند. URLهای محلی، لینک‌های وابسته به Cookie/Header خصوصی، DRM یا codec/container خارج از توان دستگاه مقصد به proxy/transcoder یا receiver اختصاصی نیاز دارند. این نسخه transcoding server روی گوشی اضافه نمی‌کند.
