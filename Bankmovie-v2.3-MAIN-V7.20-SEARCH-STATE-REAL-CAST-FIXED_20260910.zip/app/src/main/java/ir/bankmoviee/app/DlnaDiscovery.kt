package ir.bankmoviee.app

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

data class DlnaDevice(
    val routeId: String,
    val friendlyName: String,
    val location: String,
    val controlUrl: String,
    val serviceType: String,
    val udn: String
)

/**
 * Small, dependency-free SSDP/UPnP MediaRenderer discovery engine.
 *
 * It performs real M-SEARCH discovery and resolves each device description to an
 * AVTransport control endpoint. Discovery only runs while MediaRouter asks for it.
 */
class DlnaDiscovery(
    context: Context,
    private val onDevices: (List<DlnaDevice>) -> Unit
) {
    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)
    private val rescanRequested = AtomicBoolean(false)
    @Volatile private var activeScanRequested = false
    @Volatile private var scanThread: Thread? = null
    @Volatile private var multicastLock: WifiManager.MulticastLock? = null

    fun start(activeScan: Boolean) {
        activeScanRequested = activeScan
        if (!running.compareAndSet(false, true)) {
            if (activeScan) rescanRequested.set(true)
            return
        }
        rescanRequested.set(false)
        scanThread = Thread({ scanLoop() }, "BM-DLNA-Discovery").apply {
            priority = Thread.NORM_PRIORITY - 1
            start()
        }
    }

    fun stop() {
        running.set(false)
        scanThread?.interrupt()
        scanThread = null
        releaseMulticastLock()
    }

    private fun scanLoop() {
        acquireMulticastLock()
        try {
            // While the chooser is open AndroidX asks for an active scan. Keep a small
            // refresh cadence so devices that wake up after the dialog opens still show.
            do {
                val devices = runCatching { scanOnce() }.getOrDefault(emptyList())
                if (running.get()) main.post { onDevices(devices) }
                var waited = 0L
                rescanRequested.set(false)
                while (running.get()) {
                    val waitMs = if (activeScanRequested) 6500L else 18000L
                    if (waited >= waitMs || rescanRequested.getAndSet(false)) break
                    Thread.sleep(250L)
                    waited += 250L
                }
            } while (running.get())
        } catch (_: InterruptedException) {
            // Normal shutdown.
        } finally {
            releaseMulticastLock()
        }
    }

    private fun acquireMulticastLock() {
        runCatching {
            val wifi = appContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager ?: return
            multicastLock = wifi.createMulticastLock("bankmovie-dlna-discovery").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
    }

    private fun releaseMulticastLock() {
        runCatching { multicastLock?.takeIf { it.isHeld }?.release() }
        multicastLock = null
    }

    private fun scanOnce(): List<DlnaDevice> {
        val locations = linkedSetOf<String>()
        DatagramSocket().use { socket ->
            socket.soTimeout = 700
            socket.broadcast = true
            val target = InetAddress.getByName("239.255.255.250")
            val searchTargets = listOf(
                "urn:schemas-upnp-org:device:MediaRenderer:1",
                "urn:schemas-upnp-org:service:AVTransport:1",
                "ssdp:all"
            )
            searchTargets.forEach { st ->
                val body = buildString {
                    append("M-SEARCH * HTTP/1.1\r\n")
                    append("HOST: 239.255.255.250:1900\r\n")
                    append("MAN: \"ssdp:discover\"\r\n")
                    append("MX: 2\r\n")
                    append("ST: $st\r\n\r\n")
                }.toByteArray(Charsets.UTF_8)
                runCatching { socket.send(DatagramPacket(body, body.size, target, 1900)) }
            }

            val deadline = System.currentTimeMillis() + 4200L
            val buffer = ByteArray(24 * 1024)
            while (running.get() && System.currentTimeMillis() < deadline) {
                try {
                    val packet = DatagramPacket(buffer, buffer.size)
                    socket.receive(packet)
                    val text = String(packet.data, packet.offset, packet.length, Charsets.UTF_8)
                    headerValue(text, "location")?.trim()?.takeIf { it.startsWith("http", true) }?.let { locations += it }
                } catch (_: java.net.SocketTimeoutException) {
                    // Keep polling until deadline.
                } catch (_: Throwable) {
                    break
                }
            }
        }

        return locations.mapNotNull { location ->
            if (!running.get()) null else runCatching { resolveDevice(location) }.getOrNull()
        }.distinctBy { it.udn.ifBlank { it.controlUrl }.lowercase(Locale.US) }
            .sortedBy { it.friendlyName.lowercase(Locale.getDefault()) }
    }

    private fun headerValue(response: String, name: String): String? {
        val wanted = name.lowercase(Locale.US)
        return response.lineSequence().map { it.trim() }.firstOrNull { line ->
            val colon = line.indexOf(':')
            colon > 0 && line.substring(0, colon).trim().lowercase(Locale.US) == wanted
        }?.substringAfter(':')?.trim()
    }

    private fun resolveDevice(location: String): DlnaDevice? {
        val xml = httpGet(location) ?: return null
        val parser = XmlPullParserFactory.newInstance().newPullParser().apply {
            setInput(xml.reader())
        }

        var friendlyName = ""
        var udn = ""
        var deviceType = ""
        var inService = false
        var serviceType = ""
        var controlUrl = ""
        var selectedServiceType = ""
        var selectedControlUrl = ""
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    when (parser.name.substringAfter(':')) {
                        "service" -> {
                            inService = true
                            serviceType = ""
                            controlUrl = ""
                        }
                        "friendlyName" -> if (friendlyName.isBlank()) friendlyName = parser.nextText().trim()
                        "UDN" -> if (udn.isBlank()) udn = parser.nextText().trim()
                        "deviceType" -> if (deviceType.isBlank()) deviceType = parser.nextText().trim()
                        "serviceType" -> if (inService) serviceType = parser.nextText().trim()
                        "controlURL" -> if (inService) controlUrl = parser.nextText().trim()
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name.substringAfter(':') == "service") {
                        if (selectedControlUrl.isBlank() && serviceType.contains("AVTransport", true) && controlUrl.isNotBlank()) {
                            selectedServiceType = serviceType
                            selectedControlUrl = controlUrl
                        }
                        inService = false
                    }
                }
            }
            event = parser.next()
        }

        // Some renderers omit the MediaRenderer device type in quirky descriptions,
        // but an AVTransport service is still enough to control them.
        if (selectedControlUrl.isBlank()) return null
        val rendererLike = deviceType.contains("MediaRenderer", true) || selectedServiceType.contains("AVTransport", true)
        if (!rendererLike) return null

        val absoluteControl = URL(URL(location), selectedControlUrl).toString()
        val stableIdentity = udn.ifBlank { absoluteControl }
        val routeId = "dlna-" + UUID.nameUUIDFromBytes(stableIdentity.toByteArray(Charsets.UTF_8)).toString()
        return DlnaDevice(
            routeId = routeId,
            friendlyName = friendlyName.ifBlank { "DLNA Renderer" },
            location = location,
            controlUrl = absoluteControl,
            serviceType = selectedServiceType.ifBlank { "urn:schemas-upnp-org:service:AVTransport:1" },
            udn = udn
        )
    }

    private fun httpGet(url: String): String? {
        var c: HttpURLConnection? = null
        return try {
            c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 2600
            c.readTimeout = 3400
            c.instanceFollowRedirects = true
            c.setRequestProperty("Accept", "text/xml, application/xml, */*")
            c.setRequestProperty("User-Agent", "Bankmovie/2.3 UPnP/1.1")
            if (c.responseCode !in 200..299) return null
            c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (_: Throwable) {
            null
        } finally {
            runCatching { c?.disconnect() }
        }
    }
}
