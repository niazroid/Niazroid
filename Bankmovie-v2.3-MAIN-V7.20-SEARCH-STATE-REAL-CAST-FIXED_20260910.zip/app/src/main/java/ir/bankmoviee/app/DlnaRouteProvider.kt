package ir.bankmoviee.app

import android.content.Context
import android.content.IntentFilter
import android.os.Bundle
import androidx.mediarouter.media.MediaRouteDescriptor
import androidx.mediarouter.media.MediaRouteDiscoveryRequest
import androidx.mediarouter.media.MediaRouteProvider
import androidx.mediarouter.media.MediaRouteProviderDescriptor
import androidx.mediarouter.media.MediaRouteSelector
import androidx.mediarouter.media.MediaRouter

/** Publishes SSDP-discovered UPnP/DLNA MediaRenderers into AndroidX MediaRouter. */
class DlnaRouteProvider(context: Context) : MediaRouteProvider(context) {
    companion object {
        const val CONTROL_CATEGORY = "ir.bankmoviee.app.media.DLNA_RENDERER"
        const val EXTRA_ROUTE_KIND = "bm_route_kind"
        const val EXTRA_ROUTE_KIND_DLNA = "dlna"
        const val EXTRA_CONTROL_URL = "bm_dlna_control_url"
        const val EXTRA_SERVICE_TYPE = "bm_dlna_service_type"
        const val EXTRA_LOCATION = "bm_dlna_location"
        const val EXTRA_UDN = "bm_dlna_udn"

        fun selector(): MediaRouteSelector = MediaRouteSelector.Builder()
            .addControlCategory(CONTROL_CATEGORY)
            .build()

        fun isDlnaRoute(route: MediaRouter.RouteInfo): Boolean =
            route.supportsControlCategory(CONTROL_CATEGORY) ||
                route.extras?.getString(EXTRA_ROUTE_KIND) == EXTRA_ROUTE_KIND_DLNA

        fun deviceFrom(route: MediaRouter.RouteInfo): DlnaDevice? {
            if (!isDlnaRoute(route)) return null
            val extras = route.extras ?: return null
            val control = extras.getString(EXTRA_CONTROL_URL).orEmpty()
            val service = extras.getString(EXTRA_SERVICE_TYPE).orEmpty()
            if (control.isBlank() || service.isBlank()) return null
            return DlnaDevice(
                routeId = route.id,
                friendlyName = route.name.toString(),
                location = extras.getString(EXTRA_LOCATION).orEmpty(),
                controlUrl = control,
                serviceType = service,
                udn = extras.getString(EXTRA_UDN).orEmpty()
            )
        }
    }

    private val discovered = linkedMapOf<String, DlnaDevice>()
    private val connectionStates = mutableMapOf<String, Int>()
    private val discovery = DlnaDiscovery(context) { devices ->
        val fresh = devices.associateBy { it.routeId }
        // A sleeping renderer can miss one SSDP response. Never remove the route that
        // is currently connecting/connected or MediaRouter would tear down playback.
        discovered.keys.toList().forEach { id ->
            val state = connectionStates[id] ?: MediaRouter.RouteInfo.CONNECTION_STATE_DISCONNECTED
            if (id !in fresh && state == MediaRouter.RouteInfo.CONNECTION_STATE_DISCONNECTED) discovered.remove(id)
        }
        fresh.values.forEach { discovered[it.routeId] = it }
        publishRoutes()
    }

    init {
        publishRoutes()
    }

    override fun onDiscoveryRequestChanged(request: MediaRouteDiscoveryRequest?) {
        val interested = request?.selector?.hasControlCategory(CONTROL_CATEGORY) == true
        if (interested) discovery.start(request?.isActiveScan == true) else discovery.stop()
    }

    override fun onCreateRouteController(routeId: String): RouteController? {
        if (!discovered.containsKey(routeId)) return null
        return object : RouteController() {
            override fun onSelect() {
                setConnectionState(routeId, MediaRouter.RouteInfo.CONNECTION_STATE_CONNECTING)
            }

            override fun onUnselect(reason: Int) {
                setConnectionState(routeId, MediaRouter.RouteInfo.CONNECTION_STATE_DISCONNECTED)
            }

            override fun onRelease() {
                if (connectionStates[routeId] != MediaRouter.RouteInfo.CONNECTION_STATE_CONNECTED) {
                    setConnectionState(routeId, MediaRouter.RouteInfo.CONNECTION_STATE_DISCONNECTED)
                }
            }
        }
    }

    fun setConnectionState(routeId: String, state: Int) {
        if (!discovered.containsKey(routeId)) return
        connectionStates[routeId] = state
        publishRoutes()
    }

    fun stopDiscovery() {
        discovery.stop()
    }

    private fun publishRoutes() {
        val provider = MediaRouteProviderDescriptor.Builder()
        val filter = IntentFilter().apply { addCategory(CONTROL_CATEGORY) }
        discovered.values.forEach { device ->
            val extras = Bundle().apply {
                putString(EXTRA_ROUTE_KIND, EXTRA_ROUTE_KIND_DLNA)
                putString(EXTRA_CONTROL_URL, device.controlUrl)
                putString(EXTRA_SERVICE_TYPE, device.serviceType)
                putString(EXTRA_LOCATION, device.location)
                putString(EXTRA_UDN, device.udn)
            }
            provider.addRoute(
                MediaRouteDescriptor.Builder(device.routeId, device.friendlyName)
                    .setDescription("UPnP / DLNA MediaRenderer")
                    .setEnabled(true)
                    .setPlaybackType(MediaRouter.RouteInfo.PLAYBACK_TYPE_REMOTE)
                    .setVolumeHandling(MediaRouter.RouteInfo.PLAYBACK_VOLUME_FIXED)
                    .setConnectionState(connectionStates[device.routeId] ?: MediaRouter.RouteInfo.CONNECTION_STATE_DISCONNECTED)
                    .setCanDisconnect(true)
                    .setExtras(extras)
                    .addControlFilter(filter)
                    .build()
            )
        }
        setDescriptor(provider.build())
    }
}
