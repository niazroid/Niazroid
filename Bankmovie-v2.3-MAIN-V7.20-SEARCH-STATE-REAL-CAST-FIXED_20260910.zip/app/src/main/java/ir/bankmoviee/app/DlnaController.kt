package ir.bankmoviee.app

import android.os.Handler
import android.os.Looper
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

data class DlnaPlaybackState(
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val playing: Boolean = false
)

/** Controls a UPnP AVTransport renderer using real SOAP commands. */
class DlnaController(private val device: DlnaDevice) {
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "BM-DLNA-Control") }
    private val main = Handler(Looper.getMainLooper())
    private val closed = AtomicBoolean(false)

    fun load(url: String, title: String, positionMs: Long, autoplay: Boolean, cb: (Boolean, String?) -> Unit) {
        execute {
            val didl = didlMetadata(url, title)
            val setOk = soap(
                "SetAVTransportURI",
                "<InstanceID>0</InstanceID>" +
                    "<CurrentURI>${xmlEscape(url)}</CurrentURI>" +
                    "<CurrentURIMetaData>${xmlEscape(didl)}</CurrentURIMetaData>"
            ) != null
            if (!setOk) return@execute Result.failure(IllegalStateException("Renderer rejected media URL"))
            if (positionMs > 1200L) {
                soap(
                    "Seek",
                    "<InstanceID>0</InstanceID><Unit>REL_TIME</Unit><Target>${formatClock(positionMs)}</Target>"
                )
            }
            if (autoplay) {
                val playOk = soap("Play", "<InstanceID>0</InstanceID><Speed>1</Speed>") != null
                if (!playOk) return@execute Result.failure(IllegalStateException("Renderer could not start playback"))
            }
            Result.success(Unit)
        } { result -> cb(result.isSuccess, result.exceptionOrNull()?.message) }
    }

    fun play(cb: ((Boolean) -> Unit)? = null) {
        command("Play", "<InstanceID>0</InstanceID><Speed>1</Speed>", cb)
    }

    fun pause(cb: ((Boolean) -> Unit)? = null) {
        command("Pause", "<InstanceID>0</InstanceID>", cb)
    }

    fun stop(cb: ((Boolean) -> Unit)? = null) {
        command("Stop", "<InstanceID>0</InstanceID>", cb)
    }

    fun seek(positionMs: Long, cb: ((Boolean) -> Unit)? = null) {
        command(
            "Seek",
            "<InstanceID>0</InstanceID><Unit>REL_TIME</Unit><Target>${formatClock(positionMs)}</Target>",
            cb
        )
    }

    fun poll(cb: (DlnaPlaybackState?) -> Unit) {
        if (closed.get()) return
        executor.execute {
            val positionXml = soap("GetPositionInfo", "<InstanceID>0</InstanceID>")
            val transportXml = soap("GetTransportInfo", "<InstanceID>0</InstanceID>")
            val state = if (positionXml == null && transportXml == null) null else {
                val position = parseClock(tagValue(positionXml.orEmpty(), "RelTime"))
                val duration = parseClock(tagValue(positionXml.orEmpty(), "TrackDuration"))
                val transport = tagValue(transportXml.orEmpty(), "CurrentTransportState").uppercase(Locale.US)
                DlnaPlaybackState(position, duration, transport == "PLAYING" || transport == "TRANSITIONING")
            }
            if (!closed.get()) main.post { cb(state) }
        }
    }

    fun close(stopRemote: Boolean) {
        if (!closed.compareAndSet(false, true)) return
        if (stopRemote) {
            // Never block the UI thread waiting for a LAN renderer. The close flag
            // rejects new commands while this final SOAP Stop is allowed through.
            executor.execute {
                soap("Stop", "<InstanceID>0</InstanceID>", allowClosed = true)
                executor.shutdown()
            }
        } else {
            executor.shutdownNow()
        }
    }

    private fun command(action: String, body: String, cb: ((Boolean) -> Unit)?) {
        execute({
            if (soap(action, body) != null) Result.success(Unit)
            else Result.failure(IllegalStateException("UPnP command failed"))
        }) { result -> cb?.invoke(result.isSuccess) }
    }

    private fun <T> execute(block: () -> Result<T>, cb: (Result<T>) -> Unit) {
        if (closed.get()) return
        executor.execute {
            val result = runCatching { block() }.getOrElse { Result.failure(it) }
            if (!closed.get()) main.post { cb(result) }
        }
    }

    private fun soap(action: String, inner: String, allowClosed: Boolean = false): String? {
        if (closed.get() && !allowClosed) return null
        val envelope = """<?xml version="1.0" encoding="utf-8"?>
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
<s:Body><u:$action xmlns:u="${xmlEscape(device.serviceType)}">$inner</u:$action></s:Body>
</s:Envelope>"""
        var c: HttpURLConnection? = null
        return try {
            c = URL(device.controlUrl).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 4200
            c.readTimeout = 5200
            c.doOutput = true
            c.instanceFollowRedirects = true
            c.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"")
            c.setRequestProperty("SOAPACTION", "\"${device.serviceType}#$action\"")
            c.setRequestProperty("User-Agent", "Bankmovie/2.3 UPnP/1.1")
            c.outputStream.use { it.write(envelope.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code in 200..299) text else null
        } catch (_: Throwable) {
            null
        } finally {
            runCatching { c?.disconnect() }
        }
    }

    private fun didlMetadata(url: String, title: String): String {
        val mime = when {
            url.substringBefore('?').endsWith(".m3u8", true) -> "application/vnd.apple.mpegurl"
            url.substringBefore('?').endsWith(".mpd", true) -> "application/dash+xml"
            url.substringBefore('?').endsWith(".webm", true) -> "video/webm"
            url.substringBefore('?').endsWith(".mp3", true) -> "audio/mpeg"
            else -> "video/mp4"
        }
        return "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" " +
            "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" " +
            "xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\">" +
            "<item id=\"bankmovie-current\" parentID=\"0\" restricted=\"1\">" +
            "<dc:title>${xmlEscape(title.ifBlank { "Bankmovie" })}</dc:title>" +
            "<upnp:class>object.item.videoItem</upnp:class>" +
            "<res protocolInfo=\"http-get:*:$mime:*\">${xmlEscape(url)}</res>" +
            "</item></DIDL-Lite>"
    }

    private fun tagValue(xml: String, tag: String): String {
        val rx = Regex("<(?:[^:>]+:)?${Regex.escape(tag)}(?:\\s[^>]*)?>(.*?)</(?:[^:>]+:)?${Regex.escape(tag)}>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        return rx.find(xml)?.groupValues?.getOrNull(1)?.trim().orEmpty()
    }

    private fun formatClock(ms: Long): String {
        val total = (ms.coerceAtLeast(0L) / 1000L)
        val h = total / 3600L
        val m = (total % 3600L) / 60L
        val s = total % 60L
        return String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
    }

    private fun parseClock(value: String): Long {
        val clean = value.substringBefore('.').trim()
        val parts = clean.split(':')
        if (parts.size != 3) return 0L
        val h = parts[0].toLongOrNull() ?: return 0L
        val m = parts[1].toLongOrNull() ?: return 0L
        val s = parts[2].toLongOrNull() ?: return 0L
        return (h * 3600L + m * 60L + s) * 1000L
    }

    private fun xmlEscape(value: String): String = value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")
}
