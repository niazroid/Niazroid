# GohstVpn v0.4 – Build/Test notes

Changes in this overlay:
- Neutral black/white light/dark palettes, limited red accents, including persisted default red theme.
- Real Flutter animated ON/OFF switch for VPN state, inspired by supplied design.
- Smart Connect runs live Mihomo latency tests and chooses the lowest nonzero latency in a user-selectable proxy group; never chooses DIRECT or rejects.
- Clear old pings before Smart tests; avoid reporting stale success.
- Display current selection, country when embedded as a flag, measured ping, live up/down throughput.
- Refresh enabled remote subscriptions on each cold launch, with an hourly check while the app is running. Existing profile auto-update preferences remain respected.
- Read real announce/Subscription-Announcement headers including base64: encoded announcement text; no fabricated notice.

Important limitations:
- This is SOURCE code, not a built or tested APK. The full Flutter/Android build must run on GitHub Actions.
- The hourly timer cannot run reliably if Android has terminated/suspended the process; exact background scheduling needs Android WorkManager and OS-specific tests.
- Lowest HTTP URL-test latency is not necessarily the fastest download or a guarantee of successful connectivity.
- Mihomo compatibility is not equivalent to Xray/sing-box for every VLESS transport.
- There is no portless or DNS-less remote connection. Network port and resolution behavior remain defined by each server config and the core.
- Provider announcements require that the provider actually return compatible announcement headers; missing headers cannot be guessed.

GitHub instructions (KEEP EXISTING ZIP FILES):
1. Upload GohstVpn-v0.4.0-update.zip to the repository ROOT next to existing v0.1 original and v0.2/v0.3 overlays.
2. Replace .github/workflows/gohstvpn-android.yml with the CONTENT of gohstvpn-android-V8-smart-ui.yml.
3. Commit to main and start a NEW workflow: GohstVpn V8 - Smart UI.
4. After a green workflow, install artifact APK and test subscription refresh, live Smart and VPN on a real device.
