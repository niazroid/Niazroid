import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Optional plain-text notices from subscription response headers.
/// No HTML execution and no external service is used to resolve messages.
class GohstSubscriptionNotice {
  GohstSubscriptionNotice._();
  static final instance = GohstSubscriptionNotice._();
  static const _prefix = 'gohstvpn.notice.';
  final ValueNotifier<Map<int, String>> notices = ValueNotifier(<int, String>{});
  Future<void>? _loading;

  Future<void> ensureLoaded() => _loading ??= _load();

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final loaded = <int, String>{};
    for (final key in prefs.getKeys()) {
      if (!key.startsWith(_prefix)) continue;
      final id = int.tryParse(key.substring(_prefix.length));
      final value = prefs.getString(key);
      if (id != null && value != null && value.isNotEmpty) loaded[id] = value;
    }
    notices.value = {...loaded, ...notices.value};
  }

  Future<void> save(int profileId, String? content) async {
    await ensureLoaded();
    var clean = (content ?? '').trim();
    if (clean.toLowerCase().startsWith('base64:')) {
      final encoded = clean.substring(7).trim();
      try {
        clean = utf8.decode(base64.decode(base64.normalize(encoded)));
      } on FormatException {
        // Invalid provider metadata must not appear as a fake message.
        clean = '';
      }
    }
    if (clean.contains('%')) {
      try { clean = Uri.decodeComponent(clean); } on FormatException { /* keep */ }
    }
    clean = clean.replaceAll(RegExp(r'[\u0000-\u0008\u000B\u000C\u000E-\u001F]'), '');
    if (clean.length > 600) clean = clean.substring(0, 600);
    final next = {...notices.value};
    if (clean.isEmpty) { next.remove(profileId); } else { next[profileId] = clean; }
    notices.value = next;
    final prefs = await SharedPreferences.getInstance();
    if (clean.isEmpty) {
      await prefs.remove('$_prefix$profileId');
    } else {
      await prefs.setString('$_prefix$profileId', clean);
    }
  }
}
