import 'package:flutter/material.dart' as m;
import 'package:fl_clash/common/common.dart';
import 'package:fl_clash/common/gohst_display_name.dart';
import 'package:fl_clash/common/gohst_subscription_notice.dart';
import 'package:fl_clash/enum/enum.dart';
import 'package:fl_clash/icons/icons.dart';
import 'package:fl_clash/models/models.dart';
import 'package:fl_clash/providers/providers.dart';
import 'package:fl_clash/widgets/widgets.dart';
import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class GohstDashboardView extends ConsumerWidget {
  const GohstDashboardView({super.key});

  String _label(BuildContext context, String fa, String en) =>
      Localizations.localeOf(context).languageCode == 'fa' ? fa : en;

  void _open(WidgetRef ref, PageLabel page) {
    ref.read(currentPageLabelProvider.notifier).toPage(page);
  }

  String _countryName(String rawName) {
    final flags = rawName.runes.where((r) => r >= 0x1F1E6 && r <= 0x1F1FF).take(2).toList();
    if (flags.length != 2) return 'Country: --';
    final code = String.fromCharCodes(flags.map((r) => r - 0x1F1E6 + 65));
    const countries = {
      'FI': 'Finland', 'DE': 'Germany', 'TR': 'Turkey',
      'FR': 'France', 'NL': 'Netherlands', 'US': 'United States',
      'GB': 'United Kingdom', 'CA': 'Canada', 'LV': 'Latvia',
      'SE': 'Sweden', 'SG': 'Singapore', 'AE': 'UAE',
    };
    return 'Country: ${countries[code] ?? code}';
  }

  Widget _metric(BuildContext context, String label, String value) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: ShapeDecoration(
          color: context.colorScheme.surfaceContainerHighest,
          shape: AppShape.lg,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: context.textTheme.labelMedium),
            const SizedBox(height: 6),
            Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: context.textTheme.titleMedium?.toSoftBold,
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    GohstSubscriptionNotice.instance.ensureLoaded();
    final profile = ref.watch(currentProfileProvider);
    final isStarted = ref.watch(isStartProvider);
    final isSuspended = ref.watch(suspendProvider);
    // Use the real core groups, not the selection-stripped UI view.
    final groups = ref.watch(groupsProvider);
    final activeGroup = groups.where((g) => g.name == profile?.currentGroupName &&
        g.type == GroupType.Selector).firstOrNull ??
        groups.where((g) => g.type == GroupType.Selector).firstOrNull;
    final selected = activeGroup == null ? null :
        ref.watch(selectedProxyNameProvider(activeGroup.name));
    final realName = selected == null || selected.isEmpty ? '' :
        ref.watch(realSelectedProxyStateProvider(selected)).proxyName;
    final selectedNode = realName.isEmpty ? null : realName;
    final info = profile?.subscriptionInfo;
    final used = (info?.upload ?? 0) + (info?.download ?? 0);
    final total = info?.total ?? 0;
    final hasTraffic = total > 0;
    final int? remaining = hasTraffic ? (total > used ? total - used : 0) : null;
    final expire = info?.expire ?? 0;
    final daysLeft = expire > 0
        ? ((DateTime.fromMillisecondsSinceEpoch(expire * 1000)
                        .difference(DateTime.now())
                        .inHours +
                    23) ~/
                24)
            .clamp(0, 999999)
        : null;
    final connectedText = isStarted
        ? (isSuspended
              ? _label(context, 'اتصال موقتاً متوقف است', 'Connection suspended')
              : _label(context, 'متصل', 'Connected'))
        : _label(context, 'قطع', 'Disconnected');

    return CommonScaffold(
      title: 'GohstVpn',
      body: ListView(
        padding: EdgeInsets.fromLTRB(
          16,
          20 + context.appBarInset,
          16,
          28 + BottomInsetScope.of(context),
        ),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 26),
              child: Column(
                children: [
                  // Real VPN on/off switch: no misleading decorative state.
                  GohstConnectionToggle(
                    connected: isStarted,
                    enabled: profile != null,
                    onToggle: () => ref.read(commonActionProvider.notifier).toggleRunning(),
                  ),
                  const SizedBox(height: 14),
                  Text(connectedText, style: context.textTheme.headlineSmall?.toSoftBold),
                  const SizedBox(height: 8),
                  Text(profile?.realLabel ?? _label(context, 'اشتراکی وارد نشده', 'No subscription'),
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 12),
                  const GohstSmartConnect(),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: InkWell(
              customBorder: AppShape.xl,
              onTap: () => _open(ref, PageLabel.proxies),
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Row(
                  children: [
                    const GlyphIcon(AppGlyphs.proxies),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _label(context, 'سرور انتخاب‌شده', 'Selected server'),
                            style: context.textTheme.labelMedium,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            selectedNode == null
                                ? _label(context, 'انتخاب سرور / تست پینگ', 'Choose server / Ping test')
                                : gohstDisplayName(selectedNode),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: context.textTheme.titleMedium,
                          ),
                          if (selectedNode != null) ...[
                            const SizedBox(height: 5),
                            Text(
                              _countryName(selectedNode),
                              style: context.textTheme.labelSmall,
                            ),
                            const SizedBox(height: 5),
                            Builder(builder: (context) {
                              final delay = ref.watch(delayProvider(proxyName: selectedNode));
                              return Text(
                                delay == null ? 'Ping: --' : (delay > 0 ? 'Ping: $delay ms' : 'Ping: Timeout'),
                                style: context.textTheme.bodySmall,
                              );
                            }),
                          ],
                        ],
                      ),
                    ),
                    const GlyphIcon(AppGlyphs.chevronForward),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          // Speed values are sampled from the live Mihomo traffic API.
          Card(child: Padding(
            padding: const EdgeInsets.all(14),
            child: Builder(builder: (context) {
              final sample = ref.watch(trafficsProvider).list.safeLast(const Traffic());
              return Row(children: [
                _metric(context, _label(context, 'دانلود', 'Download'), '${sample.down.traffic.show}/s'),
                const SizedBox(width: 10),
                _metric(context, _label(context, 'آپلود', 'Upload'), '${sample.up.traffic.show}/s'),
              ]);
            }),
          )),
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          _label(context, 'اشتراک من', 'My subscription'),
                          style: context.textTheme.titleMedium?.toSoftBold,
                        ),
                      ),
                      TextButton(
                        onPressed: () => _open(ref, PageLabel.profiles),
                        child: Text(_label(context, 'مدیریت', 'Manage')),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _metric(
                        context,
                        _label(context, 'حجم باقی‌مانده', 'Remaining data'),
                        remaining?.traffic.show ?? _label(context, 'نامشخص', 'Unknown'),
                      ),
                      const SizedBox(width: 10),
                      _metric(
                        context,
                        _label(context, 'روز باقی‌مانده', 'Days left'),
                        daysLeft?.toString() ?? _label(context, 'نامشخص', 'Unknown'),
                      ),
                    ],
                  ),
                  if (hasTraffic) ...[
                    const SizedBox(height: 14),
                    LinearProgressIndicator(
                      value: (used / total).clamp(0, 1).toDouble(),
                      minHeight: 6,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '${_label(context, 'مصرف شده', 'Used')}: ${used.traffic.show} / ${total.traffic.show}',
                      style: context.textTheme.bodySmall,
                    ),
                  ] else ...[
                    const SizedBox(height: 12),
                    Text(
                      _label(
                        context,
                        'نمایش حجم و انقضا به اطلاعات ارسالی سرویس‌دهنده بستگی دارد.',
                        'Data and expiry require subscription metadata from your provider.',
                      ),
                      style: context.textTheme.bodySmall,
                    ),
                  ],
                ],
              ),
            ),
          ),
          ValueListenableBuilder<Map<int, String>>(
            valueListenable: GohstSubscriptionNotice.instance.notices,
            builder: (context, notices, _) {
              final notice = profile == null ? null : notices[profile.id];
              if (notice == null || notice.isEmpty) return const SizedBox.shrink();
              return Padding(
                padding: const EdgeInsets.only(top: 14),
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        m.Icon(m.Icons.campaign_outlined, color: context.colorScheme.primary),
                        const SizedBox(width: 12),
                        Expanded(child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(_label(context, 'اطلاعیه اشتراک', 'Subscription notice'),
                              style: context.textTheme.titleSmall?.toSoftBold),
                            const SizedBox(height: 6),
                            SelectableText(notice, style: context.textTheme.bodyMedium),
                          ],
                        )),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}

/// Holographic sliding switch inspired by the user-supplied CSS. Implemented
/// in Flutter so it controls the real VPN state and supports accessibility.
class GohstConnectionToggle extends StatelessWidget {
  const GohstConnectionToggle({
    super.key,
    required this.connected,
    required this.enabled,
    required this.onToggle,
  });

  final bool connected;
  final bool enabled;
  final VoidCallback onToggle;

  @override
  Widget build(BuildContext context) {
    final accent = context.colorScheme.primary;
    return m.Semantics(
      label: connected ? 'Disconnect VPN' : 'Connect VPN',
      button: true,
      toggled: connected,
      enabled: enabled,
      child: m.Opacity(
        opacity: enabled ? 1 : 0.4,
        child: m.InkWell(
          borderRadius: m.BorderRadius.circular(40),
          onTap: enabled ? onToggle : null,
          child: m.AnimatedContainer(
            duration: const Duration(milliseconds: 360),
            curve: m.Curves.easeOutCubic,
            width: 174,
            height: 62,
            padding: const EdgeInsets.all(5),
            decoration: m.BoxDecoration(
              borderRadius: m.BorderRadius.circular(35),
              gradient: m.LinearGradient(colors: [
                context.colorScheme.surfaceContainerHighest,
                context.colorScheme.surfaceContainerLow,
              ]),
              border: m.Border.all(color: connected ? accent : context.colorScheme.outlineVariant, width: 1.5),
              boxShadow: connected
                  ? [m.BoxShadow(color: accent.withValues(alpha: 0.24), blurRadius: 16)]
                  : null,
            ),
            child: m.Stack(children: [
              m.Align(
                alignment: connected ? m.Alignment.centerLeft : m.Alignment.centerRight,
                child: m.Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 19),
                  child: m.Text(connected ? 'ON' : 'OFF',
                      style: m.TextStyle(color: connected ? accent : context.colorScheme.onSurfaceVariant,
                          fontSize: 12, fontWeight: m.FontWeight.bold, letterSpacing: 2)),
                ),
              ),
              m.AnimatedAlign(
                duration: const Duration(milliseconds: 360),
                curve: m.Curves.easeOutCubic,
                alignment: connected ? m.Alignment.centerRight : m.Alignment.centerLeft,
                child: m.Container(
                  height: 50,
                  width: 50,
                  decoration: m.BoxDecoration(
                    shape: m.BoxShape.circle,
                    gradient: m.RadialGradient(colors: connected
                        ? [accent.withValues(alpha: 0.9), accent]
                        : [const m.Color(0xFF35383C), const m.Color(0xFF17191D)]),
                    boxShadow: [m.BoxShadow(color: connected
                        ? accent.withValues(alpha: 0.35)
                        : const m.Color(0x44000000), blurRadius: 10)],
                  ),
                  child: m.Icon(connected ? m.Icons.shield_outlined : m.Icons.power_settings_new,
                      color: m.Colors.white, size: 24),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

/// Performs a *real* URL delay test, discards failed/timeout results, then
/// changes only a user-selectable group. No fabricated ping measurements.
class GohstSmartConnect extends ConsumerStatefulWidget {
  const GohstSmartConnect({super.key});

  @override
  ConsumerState<GohstSmartConnect> createState() => _GohstSmartConnectState();
}

class _GohstSmartConnectState extends ConsumerState<GohstSmartConnect> {
  bool _running = false;

  Future<void> _chooseBest() async {
    if (_running) return;
    setState(() => _running = true);
    try {
      final selectableGroups = ref.read(groupsProvider)
          .where((g) => g.type == GroupType.Selector && g.all.any((p) => _usable(p)))
          .toList();
      if (selectableGroups.isEmpty) {
        throw StateError('No selectable server groups');
      }
      // Use the primary selector, not GLOBAL or rule-created nested groups.
      final group = selectableGroups.firstWhere(
        (g) => g.name != 'GLOBAL',
        orElse: () => selectableGroups.first,
      );
      ref.read(delayDataSourceProvider.notifier)
          .clearNodeDelays(group.all.map((p) => p.name));
      await ref.read(proxiesActionProvider.notifier).delayTestGroups([group]);
      final allDelays = ref.read(delayDataSourceProvider);
      Proxy? winner;
      int? minDelay;
      for (final proxy in group.all) {
        if (!_usable(proxy)) continue;
        int? delay;
        for (final values in allDelays.values) {
          final value = values[proxy.name];
          if (value != null && value > 0 && (delay == null || value < delay)) {
            delay = value;
          }
        }
        if (delay != null && (minDelay == null || delay < minDelay)) {
          minDelay = delay;
          winner = proxy;
        }
      }
      if (winner == null) {
        throw StateError('All tested servers timed out');
      }
      await ref.read(proxiesActionProvider.notifier).changeProxy(
        groupName: group.name, proxyName: winner.name,
      );
      if (ref.read(currentProfileProvider)?.selectedMap[group.name] != winner.name) {
        throw StateError('Server selection was not accepted by the core');
      }
      if (!ref.read(isStartProvider)) {
        ref.read(commonActionProvider.notifier).toggleRunning();
      }
      if (mounted) {
        m.ScaffoldMessenger.of(context).showSnackBar(m.SnackBar(
          content: Text('${gohstDisplayName(winner.name)} · $minDelay ms'),
        ));
      }
    } catch (error) {
      if (mounted) {
        m.ScaffoldMessenger.of(context).showSnackBar(m.SnackBar(
          content: Text('Smart Connect: $error'),
        ));
      }
    } finally {
      if (mounted) setState(() => _running = false);
    }
  }

  bool _usable(Proxy p) =>
      !{'DIRECT', 'REJECT', 'REJECT-DROP', 'COMPATIBLE', 'PASS'}.contains(p.name.toUpperCase()) &&
      !{'direct', 'reject', 'selector', 'url-test', 'fallback', 'load-balance'}.contains(p.type.toLowerCase());

  @override
  Widget build(BuildContext context) => m.OutlinedButton.icon(
    onPressed: _running ? null : _chooseBest,
    icon: _running
        ? const m.SizedBox(width: 16, height: 16, child: m.CircularProgressIndicator(strokeWidth: 2))
        : const m.Icon(m.Icons.auto_awesome_outlined, size: 18),
    label: Text(_running ? 'Testing...' : 'Smart Connect'),
  );
}
