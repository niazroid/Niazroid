part of '../state.dart';

typedef DynamicColorSeeds = ({
  Color? lightSeed,
  Color? darkSeed,
  Color accentColor,
});

@Riverpod(keepAlive: true)
class DynamicColor extends _$DynamicColor {
  @override
  DynamicColorSeeds build() {
    return (
      lightSeed: null,
      darkSeed: null,
      accentColor: const Color(defaultPrimaryColor),
    );
  }

  void seed({Color? lightSeed, Color? darkSeed, required Color accentColor}) {
    state = (
      lightSeed: lightSeed,
      darkSeed: darkSeed,
      accentColor: accentColor,
    );
  }
}

@riverpod
ColorScheme genColorScheme(
  Ref ref,
  Brightness brightness, {
  Color? color,
  bool ignoreConfig = false,
  bool? pureBlack,
}) {
  final themeSetting = ref.watch(
    themeSettingProvider.select(
      (state) => (
        primaryColor: state.primaryColor,
        schemeVariant: state.schemeVariant,
        pureBlack: state.pureBlack,
      ),
    ),
  );
  final dynamicColor = ref.watch(dynamicColorProvider);
  final Color seedColor;
  if (color == null &&
      (ignoreConfig == true || themeSetting.primaryColor == null)) {
    final seed = switch (brightness) {
      Brightness.light => dynamicColor.lightSeed,
      Brightness.dark => dynamicColor.darkSeed,
    };
    seedColor = seed ?? dynamicColor.accentColor;
  } else {
    seedColor = color ?? Color(themeSetting.primaryColor!);
  }
  final scheme = ColorScheme.fromSeed(
    seedColor: seedColor,
    brightness: brightness,
    dynamicSchemeVariant: themeSetting.schemeVariant,
  ).toPureBlack(pureBlack ?? themeSetting.pureBlack);
  // Force genuinely neutral surfaces even with a persisted default red seed.
  // Preview a user-requested arbitrary color without overriding it.
  if (color != null) return scheme;
  if (brightness == Brightness.dark) {
    return scheme.copyWith(
      primary: const Color(0xFFF4434D),
      onPrimary: Colors.white,
      primaryContainer: const Color(0xFF26282C),
      onPrimaryContainer: const Color(0xFFF8F9FA),
      surface: const Color(0xFF101114),
      onSurface: const Color(0xFFF7F7F7),
      surfaceContainerLowest: const Color(0xFF0A0B0D),
      surfaceContainerLow: const Color(0xFF16181B),
      surfaceContainer: const Color(0xFF1B1D22),
      surfaceContainerHigh: const Color(0xFF22252B),
      surfaceContainerHighest: const Color(0xFF292C31),
      secondaryContainer: const Color(0xFF25282D),
      onSecondaryContainer: const Color(0xFFEFEFF1),
    );
  }
  return scheme.copyWith(
    primary: const Color(0xFFCE2632),
    onPrimary: Colors.white,
    primaryContainer: const Color(0xFFF0F1F3),
    onPrimaryContainer: const Color(0xFF242529),
    surface: const Color(0xFFFAFAFB),
    onSurface: const Color(0xFF18191D),
    surfaceContainerLowest: Colors.white,
    surfaceContainerLow: const Color(0xFFFFFFFF),
    surfaceContainer: const Color(0xFFF5F6F7),
    surfaceContainerHigh: const Color(0xFFF0F1F3),
    surfaceContainerHighest: const Color(0xFFE7E9ED),
    secondaryContainer: const Color(0xFFF0F1F3),
    onSecondaryContainer: const Color(0xFF22252A),
  );
}

typedef WindowBlurRequest = ({bool enabled, Brightness brightness, Color tint});

@riverpod
WindowBlurRequest windowBlurRequest(Ref ref) {
  final enabled =
      feature.sidebarBlur &&
      ref.watch(themeSettingProvider.select((state) => state.sidebarBlur));
  final brightness = ref.watch(currentBrightnessProvider);
  final colorScheme = ref.watch(genColorSchemeProvider(brightness));
  return (
    enabled: enabled,
    brightness: brightness,
    tint: colorScheme.surfaceContainer,
  );
}

@riverpod
Brightness currentBrightness(Ref ref) {
  final themeMode = ref.watch(
    themeSettingProvider.select((state) => state.themeMode),
  );
  final systemBrightness = ref.watch(systemBrightnessProvider);
  return switch (themeMode) {
    ThemeMode.system => systemBrightness,
    ThemeMode.light => Brightness.light,
    ThemeMode.dark => Brightness.dark,
  };
}
