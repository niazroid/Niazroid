<?php
/**
 * Standalone API5 for SerialBlog metadata/listing parser.
 * Put api5.php and api5_lib.php in the same folder and call this file directly.
 */
require_once __DIR__ . '/api5_lib.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function api5_json($payload, $code = 200) {
    http_response_code($code);
    echo json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function api5_page_param() {
    foreach (['page', 'paged', 'continue', 'cursor'] as $key) {
        if (isset($_GET[$key]) && (int)$_GET[$key] > 0) {
            return max(1, (int)$_GET[$key]);
        }
    }
    return 1;
}

try {
    if (isset($_GET['ping'])) {
        api5_json([
            'status' => 'success',
            'api' => 'api5',
            'source' => 'serialblog',
            'base_url' => SERIALBLOG_BASE_URL,
            'mode' => 'standalone_metadata',
            'version' => '1.2.0-v14-related-resume-signature-fix'
        ]);
    }

    if (isset($_GET['sections'])) {
        $sections = [];
        foreach (serialblog_section_catalog() as $slug => $def) {
            $sections[] = [
                'slug' => $slug,
                'title' => $def['fa'] ?? $slug,
                'title_en' => $def['en'] ?? $slug,
                'type' => $def['type'] ?? 'all',
                'genre' => $def['genre'] ?? ''
            ];
        }
        api5_json([
            'status' => 'success',
            'source' => 'serialblog',
            'sections' => $sections
        ]);
    }

    if (isset($_GET['genres'])) {
        api5_json([
            'status' => 'success',
            'source' => 'serialblog',
            'genres' => serialblog_genres_list(),
            'count' => count(serialblog_genres_list())
        ]);
    }

    if (isset($_GET['id']) || isset($_GET['url'])) {
        $identifier = isset($_GET['url']) ? (string)$_GET['url'] : (string)$_GET['id'];
        $type = isset($_GET['type']) ? trim((string)$_GET['type']) : '';
        api5_json(serialblog_get_details($identifier, $type));
    }

    if (isset($_GET['imdb'])) {
        $page = api5_page_param();
        $result = serialblog_search_by_imdb((string)$_GET['imdb'], $page);
        api5_json(array_merge(['status' => 'success'], $result));
    }

    if (isset($_GET['genre'])) {
        $page = api5_page_param();
        $genre = trim((string)$_GET['genre']);
        $type = isset($_GET['type']) ? trim((string)$_GET['type']) : 'movie';
        $result = serialblog_get_genre($genre, $type, $page);
        api5_json(array_merge(['status' => 'success'], $result));
    }

    if (isset($_GET['section'])) {
        $section = trim((string)$_GET['section']);
        $page = api5_page_param();
        $result = serialblog_get_section($section, $page);
        api5_json(array_merge(['status' => 'success'], $result));
    }

    if (isset($_GET['updates']) || isset($_GET['archive'])) {
        $kind = isset($_GET['updates']) ? trim((string)$_GET['updates']) : trim((string)$_GET['archive']);
        $page = api5_page_param();
        if ($kind === 'series') {
            $section = 'new_series';
        } elseif ($kind === 'movies' || $kind === 'movie') {
            $section = 'new_movies';
        } else {
            $section = $kind;
        }
        $result = serialblog_get_section($section, $page);
        api5_json(array_merge(['status' => 'success'], $result));
    }

    $params = [
        's' => isset($_GET['s']) ? trim((string)$_GET['s']) : '',
        'type' => isset($_GET['type']) ? trim((string)$_GET['type']) : 'all',
        'page' => api5_page_param(),
    ];
    if (isset($_GET['q']) && $params['s'] === '') {
        $params['s'] = trim((string)$_GET['q']);
    }

    if ($params['s'] !== '') {
        $result = serialblog_search($params);
        api5_json(array_merge(['status' => 'success'], $result));
    }

    $result = serialblog_get_section('home', api5_page_param());
    api5_json(array_merge(['status' => 'success'], $result));
} catch (Throwable $e) {
    api5_json([
        'status' => 'error',
        'source' => 'serialblog',
        'error' => 'internal_error',
        'message' => $e->getMessage()
    ], 500);
}
