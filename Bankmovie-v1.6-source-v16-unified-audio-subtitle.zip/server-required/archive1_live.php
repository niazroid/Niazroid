<?php
require_once __DIR__ . '/archive1_live_lib.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Cache-Control: public, max-age=120');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function bma1_json($payload, $code = 200) {
    http_response_code($code);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

try {
    if (isset($_GET['ping'])) {
        bma1_json([
            'status' => 'success',
            'api' => 'archive1_live',
            'source' => 'oldtowns',
            'version' => '1.1.0-dubbed-chinese'
        ]);
    }

    $section = trim((string)($_GET['section'] ?? 'dubbed'));
    if (!in_array($section, ['dubbed', 'chinese_series'], true)) {
        bma1_json(['status' => 'error', 'error' => 'unsupported_section'], 400);
    }
    $page = max(1, (int)($_GET['page'] ?? 1));
    $limit = max(1, min(60, (int)($_GET['limit'] ?? 24)));
    $url = bma1_section_url($section, $page);

    $cacheKey = hash('sha256', $url . '|' . $limit);
    $cacheFile = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'bankmovie_a1_' . $cacheKey . '.json';
    if (is_file($cacheFile) && (time() - filemtime($cacheFile)) < 180) {
        $cached = @file_get_contents($cacheFile);
        if (is_string($cached) && $cached !== '') {
            header('X-Bankmovie-Cache: HIT');
            echo $cached;
            exit;
        }
    }

    $html = bma1_fetch_html($url);
    $result = bma1_parse_listing_html($html, $url, $section, $page, $limit);
    $encoded = json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if (is_string($encoded)) @file_put_contents($cacheFile, $encoded, LOCK_EX);
    header('X-Bankmovie-Cache: MISS');
    echo $encoded;
} catch (Throwable $e) {
    bma1_json([
        'status' => 'error',
        'source' => 'archive1_live',
        'error' => 'temporary_upstream_error',
        'message' => $e->getMessage()
    ], 502);
}
