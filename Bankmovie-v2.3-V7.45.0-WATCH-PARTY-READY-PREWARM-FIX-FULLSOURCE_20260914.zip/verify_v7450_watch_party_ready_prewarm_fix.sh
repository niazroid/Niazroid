#!/usr/bin/env bash
set -euo pipefail
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
marker='BANKMOVIE_BUILD_SOURCE_2_3.txt'

# Keep the approved V7.44.6 Watch Party neon UI/player chips.
bash verify_v7446_watch_party_neon_ui.sh

grep -Fq 'sourceMainUpdateThirtySixthHotfixTag=BANKMOVIE-2.3-V7450-20260914' "$marker"

# Lobby remains a hard Ready gate.
grep -Fq 'if (!partyActive || partyRoomCode.isBlank() || partyReadyConfirmed) return' "$player"
grep -Fq 'if (partyLobbyDialog?.isShowing == true) return' "$player"
grep -Fq 'AlertDialog.Builder(this).setView(shell).setCancelable(false).create()' "$player"
grep -Fq 'dialog.setCanceledOnTouchOutside(false)' "$player"

# New stable transition: VLC is created before Ready, and Ready reuses it.
grep -Fq 'private var partyPrewarming = false' "$player"
grep -Fq 'partyPrewarming = true' "$player"
grep -Fq 'launchPlayerSafely(videoUrl)' "$player"
grep -Fq 'val prepared = player' "$player"
grep -Fq 'runCatching { prepared.play() }' "$player"
grep -Fq 'if (partyActive && partyPrewarming && !partyReadyConfirmed)' "$player"
grep -Fq 'runCatching { mp.pause() }' "$player"
grep -Fq 'if (partyActive && partyIsHost && partyReadyConfirmed && !partyApplyingRemote)' "$player"

# No heartbeat/lifecycle side effects before Ready.
grep -Fq 'if (!partyActive || !partyReadyConfirmed || !partyIsHost || partyApplyingRemote' "$player"
grep -Fq 'lifecycleRestorePending = videoUrl.isNotBlank() && current != null && !(partyActive && !partyReadyConfirmed)' "$player"
grep -Fq 'if (partyActive && partyReadyConfirmed && partyIsHost && lifecycleWasPlaying)' "$player"

# Watch Party prewarm must not resume local history before room sync.
grep -Fq 'val resumeBeforePlay = if (partyActive && !partyReadyConfirmed)' "$player"
grep -Fq 'val saved = if (partyActive) requestedResumePosition.coerceAtLeast(0L)' "$player"

# Explicitly reject the earlier unstable Ready state machine.
! grep -Fq 'partyReadyLaunchInFlight' "$player"
! grep -Fq 'STATE_PARTY_READY_CONFIRMED' "$player"
! grep -Fq 'STATE_PARTY_PLAYBACK_STARTED' "$player"

python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt').read_text()
stack=[]; i=0; state='code'; n=len(s)
while i<n:
    c=s[i]; nx=s[i+1] if i+1<n else ''
    if state=='code':
        if c=='/' and nx=='/': state='line'; i+=2; continue
        if c=='/' and nx=='*': state='block'; i+=2; continue
        if s[i:i+3]=='"""': state='triple'; i+=3; continue
        if c=='"': state='string'; i+=1; continue
        if c=="'": state='char'; i+=1; continue
        if c in '([{': stack.append(c)
        elif c in ')]}':
            pairs={')':'(',']':'[','}':'{'}
            assert stack and stack[-1]==pairs[c], (c,i,stack[-1:] if stack else [])
            stack.pop()
        i+=1; continue
    if state=='line':
        if c=='\n': state='code'
        i+=1; continue
    if state=='block':
        if c=='*' and nx=='/': state='code'; i+=2; continue
        i+=1; continue
    if state=='string':
        if c=='\\': i+=2; continue
        if c=='"': state='code'
        i+=1; continue
    if state=='char':
        if c=='\\': i+=2; continue
        if c=="'": state='code'
        i+=1; continue
    if state=='triple':
        if s[i:i+3]=='"""': state='code'; i+=3; continue
        i+=1
assert state=='code' and not stack, (state, stack[-10:])
print('V7450_KOTLIN_SHAPE_OK')
PY

echo V7450_WATCH_PARTY_READY_PREWARM_FIX_VERIFY_OK
