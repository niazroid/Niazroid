# BankMovie V7.45.0 — فیکس کرش Ready در Watch Party

ویدیوی ارسالی نشان می‌دهد ورود به PlayerActivity و خود Lobby سالم است؛ بعد از زدن «شروع تماشا / آماده‌ام» لابی بسته می‌شود، پلیر وارد حالت اتاق می‌شود و چند ثانیه بعد پروسه Force Close می‌شود. بنابراین این پاس فقط مسیر Ready -> Player را تغییر می‌دهد و ظاهر V7.44.6/V7.44.9 را دست نمی‌زند.

## تغییر اصلی
قبلاً با لمس Ready همان لحظه `launchPlayerSafely(videoUrl)` اجرا و LibVLC ساخته می‌شد. این ساخت native player هم‌زمان با dismiss شدن Dialog و شروع poll/sync انجام می‌شد.

در V7.45.0 پلیر از همان مسیر سالم پلیر عادی، پشت Lobby، یک بار pre-warm می‌شود و بلافاصله Pause می‌شود. لمس Ready دیگر LibVLC جدید نمی‌سازد؛ فقط همان player آماده را برای Host Play می‌کند یا برای Guest منتظر state میزبان نگه می‌دارد.

## محافظت‌ها
- قبل از Ready هیچ heartbeat پخش از Host ارسال نمی‌شود.
- pre-warm هیچ PLAY event به اتاق منتشر نمی‌کند.
- قبل از Ready lifecycle restore برای player گرم‌شده فعال نمی‌شود؛ Share/Chooser باعث rebuild نمی‌شود.
- Watch Party قبل از sync از progress محلی فیلم Resume نمی‌شود.
- Gate غیرقابل‌بستن Lobby حفظ شده است.
- Server/Host تغییری ندارد.

## فایل اصلی تغییرکرده
`app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt`
